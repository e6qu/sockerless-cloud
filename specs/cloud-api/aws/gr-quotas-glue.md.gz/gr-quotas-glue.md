

# AWS Glue endpoints and quotas
<a name="glue"></a>

To connect programmatically to an AWS service, you use an endpoint. AWS services offer the following endpoint types in some or all of the AWS Regions that the service supports: IPv4 endpoints, dual-stack endpoints, and FIPS endpoints. Some services provide global endpoints. For more information, see [AWS service endpoints](rande.md).

Service quotas, also referred to as limits, are the maximum number of service resources or operations for your AWS account. For more information, see [AWS service quotas](aws_service_limits.md).

The following are the service endpoints and service quotas for this service.

## Service endpoints
<a name="glue_region"></a>


| Region Name | Region | Endpoint | Protocol | 
| --- | --- | --- | --- | 
| US East (Ohio) | us-east-2 |  glue.us-east-2.amazonaws.com <br /> glue-fips.us-east-2.api.aws <br /> glue-fips.us-east-2.amazonaws.com <br /> glue.us-east-2.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| US East (N. Virginia) | us-east-1 |  glue.us-east-1.amazonaws.com <br /> glue-fips.us-east-1.api.aws <br /> glue-fips.us-east-1.amazonaws.com <br /> glue.us-east-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| US West (N. California) | us-west-1 |  glue.us-west-1.amazonaws.com <br /> glue-fips.us-west-1.api.aws <br /> glue-fips.us-west-1.amazonaws.com <br /> glue.us-west-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| US West (Oregon) | us-west-2 |  glue.us-west-2.amazonaws.com <br /> glue-fips.us-west-2.api.aws <br /> glue-fips.us-west-2.amazonaws.com <br /> glue.us-west-2.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Africa (Cape Town) | af-south-1 |  glue.af-south-1.amazonaws.com <br /> glue.af-south-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Hong Kong) | ap-east-1 |  glue.ap-east-1.amazonaws.com <br /> glue.ap-east-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Hyderabad) | ap-south-2 |  glue.ap-south-2.amazonaws.com <br /> glue.ap-south-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Jakarta) | ap-southeast-3 |  glue.ap-southeast-3.amazonaws.com <br /> glue.ap-southeast-3.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Malaysia) | ap-southeast-5 |  glue.ap-southeast-5.amazonaws.com <br /> glue.ap-southeast-5.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Melbourne) | ap-southeast-4 |  glue.ap-southeast-4.amazonaws.com <br /> glue.ap-southeast-4.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Mumbai) | ap-south-1 |  glue.ap-south-1.amazonaws.com <br /> glue.ap-south-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (New Zealand) | ap-southeast-6 |  glue.ap-southeast-6.amazonaws.com <br /> glue.ap-southeast-6.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Osaka) | ap-northeast-3 |  glue.ap-northeast-3.amazonaws.com <br /> glue.ap-northeast-3.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Seoul) | ap-northeast-2 |  glue.ap-northeast-2.amazonaws.com <br /> glue.ap-northeast-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Singapore) | ap-southeast-1 |  glue.ap-southeast-1.amazonaws.com <br /> glue.ap-southeast-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Sydney) | ap-southeast-2 |  glue.ap-southeast-2.amazonaws.com <br /> glue.ap-southeast-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Taipei) | ap-east-2 |  glue.ap-east-2.amazonaws.com <br /> glue.ap-east-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Thailand) | ap-southeast-7 |  glue.ap-southeast-7.amazonaws.com <br /> glue.ap-southeast-7.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Tokyo) | ap-northeast-1 |  glue.ap-northeast-1.amazonaws.com <br /> glue.ap-northeast-1.api.aws  | HTTPS<br />HTTPS | 
| Canada (Central) | ca-central-1 |  glue.ca-central-1.amazonaws.com <br /> glue-fips.ca-central-1.api.aws <br /> glue-fips.ca-central-1.amazonaws.com <br /> glue.ca-central-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Canada West (Calgary) | ca-west-1 |  glue.ca-west-1.amazonaws.com <br /> glue-fips.ca-west-1.api.aws <br /> glue-fips.ca-west-1.amazonaws.com <br /> glue.ca-west-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Europe (Frankfurt) | eu-central-1 |  glue.eu-central-1.amazonaws.com <br /> glue.eu-central-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Ireland) | eu-west-1 |  glue.eu-west-1.amazonaws.com <br /> glue.eu-west-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (London) | eu-west-2 |  glue.eu-west-2.amazonaws.com <br /> glue.eu-west-2.api.aws  | HTTPS<br />HTTPS | 
| Europe (Milan) | eu-south-1 |  glue.eu-south-1.amazonaws.com <br /> glue.eu-south-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Paris) | eu-west-3 |  glue.eu-west-3.amazonaws.com <br /> glue.eu-west-3.api.aws  | HTTPS<br />HTTPS | 
| Europe (Spain) | eu-south-2 |  glue.eu-south-2.amazonaws.com <br /> glue.eu-south-2.api.aws  | HTTPS<br />HTTPS | 
| Europe (Stockholm) | eu-north-1 |  glue.eu-north-1.amazonaws.com <br /> glue.eu-north-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Zurich) | eu-central-2 |  glue.eu-central-2.amazonaws.com <br /> glue.eu-central-2.api.aws  | HTTPS<br />HTTPS | 
| Israel (Tel Aviv) | il-central-1 |  glue.il-central-1.amazonaws.com <br /> glue.il-central-1.api.aws  | HTTPS<br />HTTPS | 
| Mexico (Central) | mx-central-1 |  glue.mx-central-1.amazonaws.com <br /> glue.mx-central-1.api.aws  | HTTPS<br />HTTPS | 
| Middle East (Bahrain) | me-south-1 |  glue.me-south-1.amazonaws.com <br /> glue.me-south-1.api.aws  | HTTPS<br />HTTPS | 
| Middle East (UAE) | me-central-1 |  glue.me-central-1.amazonaws.com <br /> glue.me-central-1.api.aws  | HTTPS<br />HTTPS | 
| South America (São Paulo) | sa-east-1 |  glue.sa-east-1.amazonaws.com <br /> glue.sa-east-1.api.aws  | HTTPS<br />HTTPS | 
|  AWS GovCloud (US-East) | us-gov-east-1 |  glue.us-gov-east-1.amazonaws.com <br /> glue-fips.us-gov-east-1.api.aws <br /> glue-fips.us-gov-east-1.amazonaws.com <br /> glue.us-gov-east-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
|  AWS GovCloud (US-West) | us-gov-west-1 |  glue.us-gov-west-1.amazonaws.com <br /> glue-fips.us-gov-west-1.api.aws <br /> glue-fips.us-gov-west-1.amazonaws.com <br /> glue.us-gov-west-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 

## Service quotas
<a name="limits_glue"></a>


| Name | Default | Adjustable | Description | 
| --- | --- | --- | --- | 
| Concurrent compute capacity for Ray worker instances in M-DPUs per account. | Each supported Region: 50 | No | The maximum number of data processing units that can be concurrently used by Ray jobs or interactive sessions in this account. The capacity provided by a Ray worker instance type is measured in memory optimized data processing units (M-DPUs). | 
| Concurrent machine learning task runs per transform | Each supported Region: 3 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/glue/quotas/L-E15CE20A)  | The maximum number of concurrent task runs per machine learning transform for this account. | 
| Global max tags | Each supported Region: 10,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/glue/quotas/L-785C1F39)  | Catalog: global max tags | 
| Global maximum administrators | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/glue/quotas/L-D90AC94B)  | Catalog: global maximum administrators | 
| Global maximum paths | Each supported Region: 30,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/glue/quotas/L-FB210BD9)  | Catalog: global maximum paths | 
| Global s3 path max length | Each supported Region: 2,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/glue/quotas/L-4F4B522D)  | Catalog: global s3 path max length | 
| Label file size | Each supported Region: 10 Megabytes |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/glue/quotas/L-B78896B9)  | The maximum file size of an individual label file that can be imported. | 
| Max DPUs per dev endpoint | Each supported Region: 50 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/glue/quotas/L-76EC689B)  | The maximum number of DPUs in your development endpoint. | 
| Max Named Tag Expressions | Each supported Region: 25,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/glue/quotas/L-EAC30D24)  | The maximum number of named tag expression allowed per account | 
| Max concurrent data quality ruleset evaluation runs per account | Each supported Region: 50 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/glue/quotas/L-C3952F6C)  | The maximum number of concurrent data quality ruleset evaluation runs in your account. | 
| Max concurrent data quality ruleset recommendation runs per account | Each supported Region: 25 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/glue/quotas/L-ACAC12B6)  | The maximum number of concurrent data quality ruleset recommendation runs in your account. | 
| Max concurrent job runs per account | Each supported Region: 2,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/glue/quotas/L-5E4153CA)  | The maximum number of concurrent job runs in your account. | 
| Max concurrent job runs per job | Each supported Region: 4,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/glue/quotas/L-F574AED9)  | The maximum number of concurrent job runs for a job. | 
| Max concurrent observations generation runs per account | Each supported Region: 10 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/glue/quotas/L-2E9FB93F)  | The maximum number of concurrent observations generation runs | 
| Max connection per account | Each supported Region: 1,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/glue/quotas/L-4256D6D2)  | The maximum number of connections in your account. | 
| Max data quality rulesets per account | Each supported Region: 1,000,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/glue/quotas/L-87F5991C)  | The maximum number of data quality rulesets per account. | 
| Max databases per account | Each supported Region: 10,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/glue/quotas/L-F953935E)  | The maximum number of databases in your account. | 
| Max databases per catalog | Each supported Region: 10,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/glue/quotas/L-A57B5BCE)  | The maximum number of databases per catalog. | 
| Max development endpoint per account | Each supported Region: 25 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/glue/quotas/L-DBA56E2F)  | The maximum number of development endpoints in your account. | 
| Max functions per account | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/glue/quotas/L-D987EC31)  | The maximum number of functions in your account. | 
| Max functions per database | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/glue/quotas/L-1DD415D5)  | The maximum number of functions per database. | 
| Max jobs per account | Each supported Region: 2,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/glue/quotas/L-611FDDE4)  | The maximum number of jobs in your account. | 
| Max jobs per trigger | Each supported Region: 50 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/glue/quotas/L-EEC98450)  | The maximum number of jobs that a trigger can start. | 
| Max partitions per account | Each supported Region: 20,000,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/glue/quotas/L-FEBBFA7A)  | The maximum number of partitions in your account. | 
| Max partitions per table | Each supported Region: 10,000,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/glue/quotas/L-2C3F5401)  | The maximum number of partitions per table. | 
| Max security configurations per account | Each supported Region: 250 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/glue/quotas/L-83192DBF)  | The maximum number of security configurations in your account. | 
| Max spare compute capacity consumed in data processing units (DPUs) per account. | Each supported Region: 4,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/glue/quotas/L-096DBB95)  | The maximum spare compute capacity in data processing units (DPUs) you can use concurrently in your account. | 
| Max table versions per account | Each supported Region: 1,000,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/glue/quotas/L-337244C9)  | The maximum number of table versions in your account. | 
| Max table versions per table | Each supported Region: 100,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/glue/quotas/L-071ABE08)  | The maximum number of table versions per table. | 
| Max tables per account | Each supported Region: 1,000,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/glue/quotas/L-94D025B7)  | The maximum number of tables in your account. | 
| Max tables per database | Each supported Region: 200,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/glue/quotas/L-B8497671)  | The maximum number of tables per database. | 
| Max task DPUs per account | us-east-1: 1,000<br />us-east-2: 1,000<br />us-west-2: 1,000<br />ap-northeast-1: 1,000<br />ap-southeast-2: 1,000<br />eu-west-1: 1,000<br />Each of the other supported Regions: 500 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/glue/quotas/L-08F3B322)  | The maximum compute capacity in data processing units (DPUs) you can use concurrently in your account. | 
| Max triggers per account | Each supported Region: 1,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/glue/quotas/L-F1653A6D)  | The maximum number of triggers in your account. | 
| Maximum number of in-flight completion requests allowed per account | Each supported Region: 10 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/glue/quotas/L-958728D1)  | The maximum number of concurrent generative AI completion requests allowed per account in the current Region. These requests are used for code generation and Spark troubleshooting in AWS Glue. | 
| Maximum number of queued job runs | Each supported Region: 1,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/glue/quotas/L-A457CBAB)  | Orchestration: maximum number of queued job runs | 
| Number of Schema Registries. | Each supported Region: 100 | No | The maximum number of Schema Registries per AWS Region for this account. | 
| Number of Schema Versions. | Each supported Region: 10,000 | No | The maximum number of Schema Versions per AWS Region for this account. | 
| Number of column statistics tasks running concurrently per account | Each supported Region: 50 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/glue/quotas/L-3890A802)  | The maximum number of column statistics tasks running concurrently in your account. | 
| Number of connection types | Each supported Region: 1,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/glue/quotas/L-F545C262)  | The maximum number of connection types per AWS Region for this account. | 
| Number of crawlers per account | Each supported Region: 1,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/glue/quotas/L-11FA2C1A)  | The maximum number of crawlers in your account. | 
| Number of crawlers running concurrently per account | Each supported Region: 150 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/glue/quotas/L-4071B0E3)  | The maximum number of crawlers running concurrently in your account. | 
| Number of integrations | Each supported Region: 40 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/glue/quotas/L-F1AAB534)  | The maximum number of integrations per AWS Region for this account. | 
| Number of machine learning transforms | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/glue/quotas/L-04CEE988)  | The maximum number of machine learning transforms for this account. | 
| Number of metadata key value pairs per Schema Version. | Each supported Region: 10 | No | The maximum number of Schema Version metadata key value pairs per Schema Version. | 
| Number of workflows | Each supported Region: 1,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/glue/quotas/L-7DD7C33A)  | The maximum number of workflows in your account. | 
| The maximum number of concurrent materialized view refresh task runs. | Each supported Region: 50 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/glue/quotas/L-B4840D4D)  | The maximum number of concurrent materialized view refresh task runs. | 
| Total concurrent machine learning task runs for transforms per account | Each supported Region: 30 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/glue/quotas/L-83A59AA6)  | The total number of concurrent machine learning transform task runs for machine learning transforms for this account. | 

For more information, see [AWS Glue](https://docs.aws.amazon.com/govcloud-us/latest/UserGuide/govcloud-glue.html) in the *AWS GovCloud (US) User Guide*.