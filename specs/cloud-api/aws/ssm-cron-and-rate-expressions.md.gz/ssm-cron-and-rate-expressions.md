

# Reference: Cron and rate expressions for Systems Manager
<a name="reference-cron-and-rate-expressions"></a>

When you create a State Manager association or a maintenance window in AWS Systems Manager, you specify a schedule for when the window or the association should run. You can specify a schedule as either a time-based entry, called a *cron expression*, or a frequency-based entry, called a *rate expression*. 

## General information about cron and rate expressions
<a name="reference-cron-and-rate-expressions-intro"></a>

The following information applies to cron and rate expressions for both maintenance windows and associations.

**Single-run schedules**  
When you create an association or a maintenance window, you can specify a timestamp in Coordinated Universal Time (UTC) format so that it runs once at the specified time. For example: `"at(2020-07-07T15:55:00)"`

**Schedule offsets**  
Associations and maintenance windows support *schedule offsets* for cron expressions only. A schedule offset is the number of days to wait after the date and time specified by a cron expression before running the association or maintenance window.   
In the following command, the cron expression schedules a maintenance window to run the third Tuesday of every month at 11:30 PM. However, because the schedule offset is `2`, the maintenance window won't run until 11:30 PM two days later.  

```
aws ssm create-maintenance-window \
    --name "My-Cron-Offset-Maintenance-Window" \
    --allow-unassociated-targets \
    --schedule "cron(30 23 ? * TUE#3 *)" \
    --duration 4 \
    --cutoff 1 \
    --schedule-offset 2
```
In the following command, the cron expression schedules an association to run the second Thursday of each month. However, because the schedule offset is `3`, the assocation won't run until the next Sunday, three days later.  

```
aws ssm create-association \
    --name "AWS-UpdateSSMAgent" \
    --targets "Key=instanceids,Values=i-0cb2b964d3e14fd9f" \
    --schedule-expression "cron(0 0 ? * THU#2 *)"  \
    --schedule-offset 3
    --apply-only-at-cron-interval
```
To use an offset with an assocation, you must specify the `--apply-only-at-cron-interval` option. This option tells the system not to run an association immediately after you create it.
If you create an association or a maintenance window with a cron expression that targets a day that has already passed in the current period, but add a schedule offset date that falls in the future, the association or maintenance window won't run in the period. It will go into effect in the following period. For example, if you specify a cron expression that would have run a maintenance window yesterday and add a schedule offset of two days, the maintenance window won't run tomorrow. 

**Required fields**  
Cron expressions for maintenance windows have six required fields. Cron expressions for associations have five. (State Manager doesn't currently support specifying months in cron expressions for associations.) An additional field, the `Seconds` field (the first in a cron expression), is optional. Fields are separated by a space.  


**Cron expression examples**  

<table>
<thead>
  <tr><th>Minutes</th><th>Hours</th><th>Day of month</th><th>Month</th><th>Day of week</th><th>Year</th><th>Meaning</th></tr>
</thead>
<tbody>
  <tr><td>0</td><td>10</td><td>*</td><td>*</td><td>?</td><td>*</td><td>Run at 10:00 am (UTC) every day</td></tr>
  <tr><td>15</td><td>12</td><td>*</td><td>*</td><td>?</td><td>*</td><td>Run at 12:15 PM (UTC) every day</td></tr>
  <tr><td>0</td><td>18</td><td>?</td><td>*</td><td>MON-FRI</td><td>*</td><td>Run at 6:00 PM (UTC) every Monday through Friday (maintenance windows only)</td></tr>
  <tr><td>0</td><td>8</td><td>1</td><td>*</td><td>?</td><td>*</td><td>Run at 8:00 AM (UTC) every 1st day of the month</td></tr>
</tbody>
</table>

Day-of-week ranges (such as `MON-FRI`) and comma-separated day lists (such as `MON,TUE,WED`) are supported for maintenance windows only. For associations, you must specify a single day (such as `MON`) or use `*` for every day.

**Supported values**  
The following table shows supported values for required cron entries.  


**Supported values for cron expressions**  

<table>
<thead>
  <tr><th>Field</th><th>Values</th><th>Wildcards</th></tr>
</thead>
<tbody>
  <tr><td>Minutes</td><td><code>0</code>-<code>59</code></td><td><code>, - * /</code></td></tr>
  <tr><td>Hours</td><td><code>0</code>-<code>23</code></td><td><code>, - * /</code></td></tr>
  <tr><td>Day-of-month</td><td><code>1</code>-<code>31</code></td><td><code>, - * ? / L W</code></td></tr>
  <tr><td>Month (maintenance windows only)</td><td><code>1</code>-<code>12</code> or <code>JAN</code>-<code>DEC</code></td><td><code>, - * /</code></td></tr>
  <tr><td>Day-of-week</td><td><code>1</code>-<code>7</code> or <code>SUN</code>-<code>SAT</code></td><td><code>, - * ? / L #</code></td></tr>
  <tr><td>Year</td><td><code>1970</code>-<code>2199</code></td><td><code>, - * /</code></td></tr>
</tbody>
</table>

You can't specify a value in the day-of-month and in the day-of-week fields in the same cron expression. If you specify a value in one of the fields, use a ? (question mark) in the other field.

**Wildcards for cron expressions**  
The following table shows the wildcard values that cron expressions support.  
Systems Manager doesn't support cron expressions that lead to rates faster than 5 minutes for maintenance windows. For State Manager associations, you must use a scheduling interval of at least 30 minutes. For more information about association scheduling limitations, see [Cron and rate expressions for associations](#reference-cron-and-rate-expressions-association). Support for specifying both a day-of-week and a day-of-month value isn't complete. Use the question mark (?) character in one of these fields. 


**Supported wildcards for cron expressions**  

<table>
<thead>
  <tr><th>Wildcard</th><th>Description</th></tr>
</thead>
<tbody>
  <tr><td><b>,</b></td><td>The <code>,</code> (comma) wildcard includes additional values. In the Month field, JAN,FEB,MAR would include January, February, and March.</td></tr>
  <tr><td><b>-</b></td><td>The <code>-</code> (dash) wildcard specifies ranges. In the Day field, 1-15 would include days 1 through 15 of the specified month.</td></tr>
  <tr><td><b>*</b></td><td>The <code>*</code> (asterisk) wildcard includes all values in the field. In the Hours field, * would include every hour.</td></tr>
  <tr><td><b>/</b></td><td>The <code>/</code> (forward slash) wildcard specifies increments. In the Minutes field, you could enter 1/10 to specify every tenth minute, starting from the first minute of the hour. So 1/10 specifies the first, 11th, 21st, and 31st minute, and so on.</td></tr>
  <tr><td><b>?</b></td><td>The <code>?</code> (question mark) wildcard specifies one or another. In the Day-of-month field you could enter 7 and if you didn't care what day of the week the 7th was, you could enter ? in the Day-of-week field.</td></tr>
  <tr><td><b>L</b></td><td>The <code>L</code> wildcard in the Day-of-month or Day-of-week fields specifies the last day of the month or week.</td></tr>
  <tr><td><b>W</b></td><td>The <code>W</code> wildcard in the Day-of-month field specifies a weekday. In the Day-of-month field, 3W specifies the day closest to the third weekday of the month.</td></tr>
  <tr><td><b>#</b></td><td>The <code>#</code> wildcard in the day-of-week field followed by a number between one and five specifies a given day of the month. 5#3 specifies the 3rd Thursday of the month.</td></tr>
</tbody>
</table>


**Rate expressions**  
Rate expressions have the following two required fields. Fields are separated by spaces.  


**Required fields for rate expressions**  

<table>
<thead>
  <tr><th>Field</th><th>Values</th></tr>
</thead>
<tbody>
  <tr><td>Value</td><td>positive number, such as <code>1</code> or <code>15</code></td></tr>
  <tr><td>Unit</td><td><code>minute</code><br /><code>minutes</code><br /><code>hour</code><br /><code>hours</code><br /><code>day</code><br /><code>days</code></td></tr>
</tbody>
</table>

If the value is equal to `1`, then the unit must be singular. Similarly, for values greater than `1`, the unit must be plural. For example, `rate(1 hours)` and `rate(5 hour)` aren't valid, but `rate(1 hour)` and `rate(5 hours)` are valid.

**Topics**
+ [General information about cron and rate expressions](#reference-cron-and-rate-expressions-intro)
+ [Cron and rate expressions for associations](#reference-cron-and-rate-expressions-association)
+ [Cron and rate expressions for maintenance windows](#reference-cron-and-rate-expressions-maintenance-window)

## Cron and rate expressions for associations
<a name="reference-cron-and-rate-expressions-association"></a>

This section includes examples of cron and rate expressions for State Manager associations. Before you create one of these expressions, be aware of the following information:

**Important**  
For State Manager associations, you must use a scheduling interval of at least 30 minutes. You can't use cron or rate expressions that result in intervals shorter than 30 minutes. For example, you can't use `cron(0/5 * * * ? *)` (every 5 minutes) or `rate(15 minutes)`. The 5-minute minimum described in the general cron expressions section applies to maintenance windows only, not to associations.
+ Associations support the following cron expressions: Every 1/2, 1, 2, 4, 8, or 12 hours; every day, every week, or every specified day and time of the week; a specific day in a specific week of the month, or the last `x` day of the month at a specific time. 
+ Associations support the following rate expressions: intervals of 30 minutes or greater and less than 31 days.
+ If you specify the optional `Seconds` field, its value can be 0 (zero). For example: `cron(0 */30 * * * ? *)`
+ For an association that collects metadata for Inventory, we recommend using a rate expression.
+ State Manager doesn't currently support specifying months in cron expressions for associations.

Associations support cron expressions that include a day of the week and the number sign (\#) to designate the *n*th day of a month to run an association. Here is an example that runs a cron schedule on the third Tuesday of every month at 23:30 UTC:

`cron(30 23 ? * TUE#3 *)`

Here is an example that runs on the second Thursday of every month at midnight UTC:

`cron(0 0 ? * THU#2 *)`

Associations also support the (L) sign to indicate the last *X* day of the month. Here is an example that runs a cron schedule on the last Tuesday of every month at midnight UTC:

`cron(0 0 ? * 3L *)`

To further control when an association runs, for example if you want to run an association two days after patch Tuesday, you can specify an offset. An *offset* defines how many days to wait after the scheduled day to run an association. For example, if you specified a cron schedule of `cron(0 0 ? * THU#2 *)`, you could specify the number 3 in the **Schedule offset** field to run the association each Sunday after the second Thursday of the month.

To use offsets, you must either choose the **Apply association only at the next specified Cron interval** option in the console or you must specify the use `--apply-only-at-cron-interval` parameter from the command line. This option tells State Manager not to run an association immediately after you create it.

The following table presents cron examples for associations.


**Cron examples for associations**  

| Example | Details | 
| --- | --- | 
| cron(0/30 \* \* \* ? \*) | Every 30 minutes | 
| cron(0 0/1 \* \* ? \*) | Every hour | 
| cron(0 0/2 \* \* ? \*) | Every 2 hours | 
| cron(0 0/4 \* \* ? \*) | Every 4 hours | 
| cron(0 0/8 \* \* ? \*) | Every 8 hours | 
| cron(0 0/12 \* \* ? \*) | Every 12 hours | 
| cron(15 13 ? \* \* \*) | Every day at 1:15 PM | 
| cron(15 13 ? \* MON \*) | Every Monday at 1:15 PM | 
| cron(30 23 ? \* TUE\#3 \*) | The third Tuesday of every month at 11:30 PM | 

Here are some rate examples for associations.


**Rate examples for associations**  

| Example | Details | 
| --- | --- | 
| rate(30 minutes) | Every 30 minutes | 
| rate(1 hour) | Every hour | 
| rate(5 hours) | Every 5 hours | 
| rate(15 days) | Every 15 days | 

****AWS CLI examples for associations****  
To create State Manager associations using the AWS CLI, you include the `--schedule-expression` parameter with a cron or rate expression. The following examples use the AWS CLI on a local Linux machine.

**Note**  
By default, when you create a new association, the system runs it immediately after it's created and then according to the schedule you specified. Specify `--apply-only-at-cron-interval` so that the association doesn't run immediately after you create it. This parameter isn't supported for rate expressions.

```
aws ssm create-association \
    --association-name "My-Cron-Association" \
    --schedule-expression "cron(0 2 ? * SUN *)" \
    --targets Key=tag:ServerRole,Values=WebServer \
    --name AWS-UpdateSSMAgent
```

```
aws ssm create-association \
    --association-name "My-Rate-Association" \
    --schedule-expression "rate(7 days)" \
    --targets Key=tag:ServerRole,Values=WebServer \
    --name AWS-UpdateSSMAgent
```

```
aws ssm create-association \
    --association-name "My-Rate-Association" \
    --schedule-expression "at(2020-07-07T15:55:00)" \
    --targets Key=tag:ServerRole,Values=WebServer \
    --name AWS-UpdateSSMAgent \
    --apply-only-at-cron-interval
```

## Cron and rate expressions for maintenance windows
<a name="reference-cron-and-rate-expressions-maintenance-window"></a>

This section includes examples of cron and rate expressions for maintenance windows.

Unlike State Manager associations, maintenance windows support all cron and rate expressions. This includes support for values in the seconds field.

For example, the following 6-field cron expression runs a maintenance window at 9:30 AM every day.

```
cron(30 09 ? * * *)
```

By adding a value to the `Seconds` field, the following 7-field cron expression runs a maintenance window at 9:30:24 AM every day.

```
cron(24 30 09 ? * * *)
```

The following table provides additional 6-field cron examples for maintenance windows.


**Cron examples for maintenance windows**  

| Example | Details | 
| --- | --- | 
| cron(0 2 ? \* THU\#3 \*) | 02:00 AM the third Thursday of every month | 
| cron(15 10 ? \* \* \*) | 10:15 AM every day | 
| cron(15 10 ? \* MON-FRI \*) | 10:15 AM every Monday, Tuesday, Wednesday, Thursday and Friday | 
| cron(0 2 L \* ? \*) | 02:00 AM on the last day of every month | 
| cron(15 10 ? \* 6L \*) | 10:15 AM on the last Friday of every month | 

The following table provides rate examples for maintenance windows.


**Rate examples for maintenance windows**  

| Example | Details | 
| --- | --- | 
| rate(30 minutes) | Every 30 minutes | 
| rate(1 hour) | Every hour | 
| rate(5 hours) | Every 5 hours | 
| rate(25 days) | Every 25 days | 

****AWS CLI examples for maintenance windows****  
To create maintenance windows using the AWS CLI, you include the `--schedule` parameter with a cron or rate expression or a timestamp. The following examples use the AWS CLI on a local Linux machine. 

```
aws ssm create-maintenance-window \
    --name "My-Cron-Maintenance-Window" \
    --allow-unassociated-targets \
    --schedule "cron(0 16 ? * TUE *)" \
    --schedule-timezone "America/Los_Angeles" \
    --start-date 2021-01-01T00:00:00-08:00 \
    --end-date 2021-06-30T00:00:00-08:00 \
    --duration 4 \
    --cutoff 1
```

```
aws ssm create-maintenance-window \
    --name "My-Rate-Maintenance-Window" \
    --allow-unassociated-targets \
    --schedule "rate(7 days)" \
    --duration 4 \
    --schedule-timezone "America/Los_Angeles" \
    --cutoff 1
```

```
aws ssm create-maintenance-window \
    --name "My-TimeStamp-Maintenance-Window" \
    --allow-unassociated-targets \
    --schedule "at(2021-07-07T13:15:30)" \
    --duration 4 \
    --schedule-timezone "America/Los_Angeles" \
    --cutoff 1
```

**More info**  
[CRON expression](https://en.wikipedia.org/wiki/Cron#CRON_expression) at the *Wikipedia website*