

# Amazon EventBridge Scheduler endpoints and quotas
<a name="eventbridgescheduler"></a>

To connect programmatically to an AWS service, you use an endpoint. AWS services offer the following endpoint types in some or all of the AWS Regions that the service supports: IPv4 endpoints, dual-stack endpoints, and FIPS endpoints. Some services provide global endpoints. For more information, see [AWS service endpoints](rande.md).

Service quotas, also referred to as limits, are the maximum number of service resources or operations for your AWS account. For more information, see [AWS service quotas](aws_service_limits.md).

The following are the service endpoints and service quotas for this service.

## Service endpoints
<a name="eventbridgescheduler_region"></a>


| Region Name | Region | Endpoint | Protocol | 
| --- | --- | --- | --- | 
| US East (Ohio) | us-east-2 |  scheduler.us-east-2.amazonaws.com <br /> scheduler-fips.us-east-2.amazonaws.com <br /> scheduler-fips.us-east-2.api.aws <br /> scheduler.us-east-2.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| US East (N. Virginia) | us-east-1 |  scheduler.us-east-1.amazonaws.com <br /> scheduler-fips.us-east-1.amazonaws.com <br /> scheduler-fips.us-east-1.api.aws <br /> scheduler.us-east-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| US West (N. California) | us-west-1 |  scheduler.us-west-1.amazonaws.com <br /> scheduler-fips.us-west-1.amazonaws.com <br /> scheduler-fips.us-west-1.api.aws <br /> scheduler.us-west-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| US West (Oregon) | us-west-2 |  scheduler.us-west-2.amazonaws.com <br /> scheduler-fips.us-west-2.amazonaws.com <br /> scheduler-fips.us-west-2.api.aws <br /> scheduler.us-west-2.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Africa (Cape Town) | af-south-1 |  scheduler.af-south-1.amazonaws.com <br /> scheduler.af-south-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Hong Kong) | ap-east-1 |  scheduler.ap-east-1.amazonaws.com <br /> scheduler.ap-east-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Hyderabad) | ap-south-2 |  scheduler.ap-south-2.amazonaws.com <br /> scheduler.ap-south-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Jakarta) | ap-southeast-3 |  scheduler.ap-southeast-3.amazonaws.com <br /> scheduler.ap-southeast-3.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Malaysia) | ap-southeast-5 |  scheduler.ap-southeast-5.amazonaws.com <br /> scheduler.ap-southeast-5.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Melbourne) | ap-southeast-4 |  scheduler.ap-southeast-4.amazonaws.com <br /> scheduler.ap-southeast-4.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Mumbai) | ap-south-1 |  scheduler.ap-south-1.amazonaws.com <br /> scheduler.ap-south-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (New Zealand) | ap-southeast-6 |  scheduler.ap-southeast-6.amazonaws.com <br /> scheduler.ap-southeast-6.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Osaka) | ap-northeast-3 |  scheduler.ap-northeast-3.amazonaws.com <br /> scheduler.ap-northeast-3.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Seoul) | ap-northeast-2 |  scheduler.ap-northeast-2.amazonaws.com <br /> scheduler.ap-northeast-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Singapore) | ap-southeast-1 |  scheduler.ap-southeast-1.amazonaws.com <br /> scheduler.ap-southeast-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Sydney) | ap-southeast-2 |  scheduler.ap-southeast-2.amazonaws.com <br /> scheduler.ap-southeast-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Taipei) | ap-east-2 |  scheduler.ap-east-2.amazonaws.com <br /> scheduler.ap-east-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Thailand) | ap-southeast-7 |  scheduler.ap-southeast-7.amazonaws.com <br /> scheduler.ap-southeast-7.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Tokyo) | ap-northeast-1 |  scheduler.ap-northeast-1.amazonaws.com <br /> scheduler.ap-northeast-1.api.aws  | HTTPS<br />HTTPS | 
| Canada (Central) | ca-central-1 |  scheduler.ca-central-1.amazonaws.com <br /> scheduler-fips.ca-central-1.amazonaws.com <br /> scheduler-fips.ca-central-1.api.aws <br /> scheduler.ca-central-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Canada West (Calgary) | ca-west-1 |  scheduler.ca-west-1.amazonaws.com <br /> scheduler-fips.ca-west-1.amazonaws.com <br /> scheduler-fips.ca-west-1.api.aws <br /> scheduler.ca-west-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Europe (Frankfurt) | eu-central-1 |  scheduler.eu-central-1.amazonaws.com <br /> scheduler.eu-central-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Ireland) | eu-west-1 |  scheduler.eu-west-1.amazonaws.com <br /> scheduler.eu-west-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (London) | eu-west-2 |  scheduler.eu-west-2.amazonaws.com <br /> scheduler.eu-west-2.api.aws  | HTTPS<br />HTTPS | 
| Europe (Milan) | eu-south-1 |  scheduler.eu-south-1.amazonaws.com <br /> scheduler.eu-south-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Paris) | eu-west-3 |  scheduler.eu-west-3.amazonaws.com <br /> scheduler.eu-west-3.api.aws  | HTTPS<br />HTTPS | 
| Europe (Spain) | eu-south-2 |  scheduler.eu-south-2.amazonaws.com <br /> scheduler.eu-south-2.api.aws  | HTTPS<br />HTTPS | 
| Europe (Stockholm) | eu-north-1 |  scheduler.eu-north-1.amazonaws.com <br /> scheduler.eu-north-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Zurich) | eu-central-2 |  scheduler.eu-central-2.amazonaws.com <br /> scheduler.eu-central-2.api.aws  | HTTPS<br />HTTPS | 
| Israel (Tel Aviv) | il-central-1 |  scheduler.il-central-1.amazonaws.com <br /> scheduler.il-central-1.api.aws  | HTTPS<br />HTTPS | 
| Mexico (Central) | mx-central-1 |  scheduler.mx-central-1.amazonaws.com <br /> scheduler.mx-central-1.api.aws  | HTTPS<br />HTTPS | 
| Middle East (Bahrain) | me-south-1 |  scheduler.me-south-1.amazonaws.com <br /> scheduler.me-south-1.api.aws  | HTTPS<br />HTTPS | 
| Middle East (UAE) | me-central-1 |  scheduler.me-central-1.amazonaws.com <br /> scheduler.me-central-1.api.aws  | HTTPS<br />HTTPS | 
| South America (São Paulo) | sa-east-1 |  scheduler.sa-east-1.amazonaws.com <br /> scheduler.sa-east-1.api.aws  | HTTPS<br />HTTPS | 
|  AWS GovCloud (US-East) | us-gov-east-1 |  scheduler.us-gov-east-1.amazonaws.com <br /> scheduler-fips.us-gov-east-1.amazonaws.com <br /> scheduler-fips.us-gov-east-1.api.aws <br /> scheduler.us-gov-east-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
|  AWS GovCloud (US-West) | us-gov-west-1 |  scheduler.us-gov-west-1.amazonaws.com <br /> scheduler-fips.us-gov-west-1.amazonaws.com <br /> scheduler-fips.us-gov-west-1.api.aws <br /> scheduler.us-gov-west-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 

## Service quotas
<a name="eventbridgescheduler_limits"></a>


| Name | Default | Adjustable | Description | 
| --- | --- | --- | --- | 
| CreateSchedule request rate | us-east-1: 5,000<br />us-east-2: 5,000<br />us-west-2: 5,000<br />ap-northeast-1: 5,000<br />ap-south-1: 5,000<br />ap-southeast-1: 5,000<br />ap-southeast-2: 5,000<br />eu-central-1: 5,000<br />eu-west-1: 5,000<br />eu-west-2: 5,000<br />sa-east-1: 5,000<br />Each of the other supported Regions: 250 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/scheduler/quotas/L-6F4B17DE)  | Maximum CreateSchedule requests per second. When you reach this quota, EventBridge Scheduler rejects requests for this operation for the remainder of the interval. This is adjustable to tens of thousands of requests per second. | 
| CreateScheduleGroup request rate | Each supported Region: 10 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/scheduler/quotas/L-21ED5C4A)  | Maximum CreateScheduleGroup requests per second. When you reach this quota, EventBridge Scheduler rejects requests for this operation for the remainder of the interval. | 
| DeleteSchedule request rate | us-east-1: 1,000<br />us-east-2: 1,000<br />us-west-2: 1,000<br />ap-northeast-1: 1,000<br />ap-south-1: 1,000<br />ap-southeast-1: 1,000<br />ap-southeast-2: 1,000<br />eu-central-1: 1,000<br />eu-west-1: 1,000<br />eu-west-2: 1,000<br />sa-east-1: 1,000<br />Each of the other supported Regions: 250 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/scheduler/quotas/L-53944E21)  | Maximum DeleteSchedule requests per second. When you reach this quota, EventBridge Scheduler rejects requests for this operation for the remainder of the interval. This is adjustable to tens of thousands of requests per second. | 
| DeleteScheduleGroup request rate | Each supported Region: 10 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/scheduler/quotas/L-4F80D7BE)  | Maximum DeleteScheduleGroup requests per second. When you reach this quota, EventBridge Scheduler rejects requests for this operation for the remainder of the interval. | 
| GetSchedule request rate | us-east-1: 1,000<br />us-east-2: 1,000<br />us-west-2: 1,000<br />ap-northeast-1: 1,000<br />ap-south-1: 1,000<br />ap-southeast-1: 1,000<br />ap-southeast-2: 1,000<br />eu-central-1: 1,000<br />eu-west-1: 1,000<br />eu-west-2: 1,000<br />sa-east-1: 1,000<br />Each of the other supported Regions: 250 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/scheduler/quotas/L-FB03E819)  | Maximum GetSchedule requests per second. When you reach this quota, EventBridge Scheduler rejects requests for this operation for the remainder of the interval. This is adjustable to tens of thousands of requests per second. | 
| GetScheduleGroup request rate | Each supported Region: 10 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/scheduler/quotas/L-754C8BBA)  | Maximum GetScheduleGroup requests per second. When you reach this quota, EventBridge Scheduler rejects requests for this operation for the remainder of the interval. | 
| Invocations throttle limit in transactions per second | us-east-1: 1,000<br />us-east-2: 1,000<br />us-west-2: 1,000<br />ap-northeast-1: 1,000<br />ap-south-1: 1,000<br />ap-southeast-1: 1,000<br />ap-southeast-2: 1,000<br />eu-central-1: 1,000<br />eu-west-1: 1,000<br />eu-west-2: 1,000<br />sa-east-1: 1,000<br />Each of the other supported Regions: 500 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/scheduler/quotas/L-F6D2596E)  | An invocation is a schedule payload being delivered to the defined target. After the limit is reached, the invocations are throttled; that is, they still happen but they are delayed. This is adjustable to tens of thousands of transactions per second. | 
| ListScheduleGroups request rate | Each supported Region: 10 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/scheduler/quotas/L-03C881B9)  | Maximum ListScheduleGroups requests per second. When you reach this quota, EventBridge Scheduler rejects requests for this operation for the remainder of the interval. | 
| ListSchedules request rate | Each supported Region: 50 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/scheduler/quotas/L-66629D52)  | Maximum ListSchedules requests per second. When you reach this quota, EventBridge Scheduler rejects requests for this operation for the remainder of the interval. | 
| ListTagsForResource request rate | Each supported Region: 10 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/scheduler/quotas/L-1DC60392)  | Lists the tags associated with the Scheduler resource. | 
| Number of schedule groups | Each supported Region: 500 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/scheduler/quotas/L-A632CD40)  | Maximum number of schedule groups per region. | 
| Number of schedules | Each supported Region: 10,000,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/scheduler/quotas/L-EE5D6FF0)  | The maximum number of schedules per region. This quota includes one-time schedules that have completed running. We recommend configuring your schedules to automatically delete after completion using the ActionAfterCompletion feature. This is adjustable to billions of schedules. | 
| TagResource request rate | Each supported Region: 1 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/scheduler/quotas/L-E7A3E659)  | Assigns one or more tags (key-value pairs) to the specified Scheduler resource. | 
| UntagResource request rate | Each supported Region: 1 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/scheduler/quotas/L-44A0C1A0)  | Removes one or more tags from the specified Scheduler resource. | 
| UpdateSchedule request rate | us-east-1: 1,000<br />us-east-2: 1,000<br />us-west-2: 1,000<br />ap-northeast-1: 1,000<br />ap-south-1: 1,000<br />ap-southeast-1: 1,000<br />ap-southeast-2: 1,000<br />eu-central-1: 1,000<br />eu-west-1: 1,000<br />eu-west-2: 1,000<br />sa-east-1: 1,000<br />Each of the other supported Regions: 250 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/scheduler/quotas/L-B7845AAE)  | Maximum UpdateSchedule requests per second. When you reach this quota, EventBridge Scheduler rejects requests for this operation for the remainder of the interval. This is adjustable to tens of thousands of requests per second. | 