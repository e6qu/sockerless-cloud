

# Amazon API Gateway endpoints and quotas
<a name="apigateway"></a>

To connect programmatically to an AWS service, you use an endpoint. AWS services offer the following endpoint types in some or all of the AWS Regions that the service supports: IPv4 endpoints, dual-stack endpoints, and FIPS endpoints. Some services provide global endpoints. For more information, see [AWS service endpoints](rande.md).

Service quotas, also referred to as limits, are the maximum number of service resources or operations for your AWS account. For more information, see [AWS service quotas](aws_service_limits.md).

The following are the service endpoints and service quotas for this service.

## Service endpoints
<a name="apigateway_region"></a>

Amazon API Gateway includes the API Gateway Control Plane (for creating and managing APIs) and the API Gateway Data Plane (for calling deployed APIs).

The Route 53 Hosted Zone ID column shows the Route 53 Hosted Zone IDs for API Gateway Regional endpoints. Route 53 Hosted Zone IDs are for use with the `execute-api` (API Gateway component service for API execution) domain. For edge-optimized endpoints, the Route 53 Hosted Zone ID is Z2FDTNDATAQYW2 for all Regions.

### Amazon API Gateway control plane
<a name="apigateway_region_control_plane"></a>


| Region Name | Region | Endpoint | Protocol | 
| --- | --- | --- | --- | 
| US East (Ohio) | us-east-2 |  apigateway.us-east-2.amazonaws.com <br /> apigateway-fips.us-east-2.amazonaws.com <br /> apigateway.us-east-2.api.aws  | HTTPS<br />HTTPS<br />HTTPS | 
| US East (N. Virginia) | us-east-1 |  apigateway.us-east-1.amazonaws.com <br /> apigateway-fips.us-east-1.amazonaws.com <br /> apigateway.us-east-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS | 
| US West (N. California) | us-west-1 |  apigateway.us-west-1.amazonaws.com <br /> apigateway-fips.us-west-1.amazonaws.com <br /> apigateway.us-west-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS | 
| US West (Oregon) | us-west-2 |  apigateway.us-west-2.amazonaws.com <br /> apigateway-fips.us-west-2.amazonaws.com <br /> apigateway.us-west-2.api.aws  | HTTPS<br />HTTPS<br />HTTPS | 
| Africa (Cape Town) | af-south-1 |  apigateway.af-south-1.amazonaws.com <br /> apigateway.af-south-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Hong Kong) | ap-east-1 |  apigateway.ap-east-1.amazonaws.com <br /> apigateway.ap-east-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Hyderabad) | ap-south-2 |  apigateway.ap-south-2.amazonaws.com <br /> apigateway.ap-south-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Jakarta) | ap-southeast-3 |  apigateway.ap-southeast-3.amazonaws.com <br /> apigateway.ap-southeast-3.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Malaysia) | ap-southeast-5 |  apigateway.ap-southeast-5.amazonaws.com <br /> apigateway.ap-southeast-5.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Melbourne) | ap-southeast-4 |  apigateway.ap-southeast-4.amazonaws.com <br /> apigateway.ap-southeast-4.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Mumbai) | ap-south-1 |  apigateway.ap-south-1.amazonaws.com <br /> apigateway.ap-south-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (New Zealand) | ap-southeast-6 |  apigateway.ap-southeast-6.amazonaws.com <br /> apigateway.ap-southeast-6.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Osaka) | ap-northeast-3 |  apigateway.ap-northeast-3.amazonaws.com <br /> apigateway.ap-northeast-3.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Seoul) | ap-northeast-2 |  apigateway.ap-northeast-2.amazonaws.com <br /> apigateway.ap-northeast-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Singapore) | ap-southeast-1 |  apigateway.ap-southeast-1.amazonaws.com <br /> apigateway.ap-southeast-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Sydney) | ap-southeast-2 |  apigateway.ap-southeast-2.amazonaws.com <br /> apigateway.ap-southeast-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Taipei) | ap-east-2 |  apigateway.ap-east-2.amazonaws.com <br /> apigateway.ap-east-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Thailand) | ap-southeast-7 |  apigateway.ap-southeast-7.amazonaws.com <br /> apigateway.ap-southeast-7.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Tokyo) | ap-northeast-1 |  apigateway.ap-northeast-1.amazonaws.com <br /> apigateway.ap-northeast-1.api.aws  | HTTPS<br />HTTPS | 
| Canada (Central) | ca-central-1 |  apigateway.ca-central-1.amazonaws.com <br /> apigateway-fips.ca-central-1.amazonaws.com <br /> apigateway.ca-central-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS | 
| Canada West (Calgary) | ca-west-1 |  apigateway.ca-west-1.amazonaws.com <br /> apigateway-fips.ca-west-1.amazonaws.com <br /> apigateway.ca-west-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS | 
| Europe (Frankfurt) | eu-central-1 |  apigateway.eu-central-1.amazonaws.com <br /> apigateway.eu-central-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Ireland) | eu-west-1 |  apigateway.eu-west-1.amazonaws.com <br /> apigateway.eu-west-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (London) | eu-west-2 |  apigateway.eu-west-2.amazonaws.com <br /> apigateway.eu-west-2.api.aws  | HTTPS<br />HTTPS | 
| Europe (Milan) | eu-south-1 |  apigateway.eu-south-1.amazonaws.com <br /> apigateway.eu-south-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Paris) | eu-west-3 |  apigateway.eu-west-3.amazonaws.com <br /> apigateway.eu-west-3.api.aws  | HTTPS<br />HTTPS | 
| Europe (Spain) | eu-south-2 |  apigateway.eu-south-2.amazonaws.com <br /> apigateway.eu-south-2.api.aws  | HTTPS<br />HTTPS | 
| Europe (Stockholm) | eu-north-1 |  apigateway.eu-north-1.amazonaws.com <br /> apigateway.eu-north-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Zurich) | eu-central-2 |  apigateway.eu-central-2.amazonaws.com <br /> apigateway.eu-central-2.api.aws  | HTTPS<br />HTTPS | 
| Israel (Tel Aviv) | il-central-1 |  apigateway.il-central-1.amazonaws.com <br /> apigateway.il-central-1.api.aws  | HTTPS<br />HTTPS | 
| Mexico (Central) | mx-central-1 |  apigateway.mx-central-1.amazonaws.com <br /> apigateway.mx-central-1.api.aws  | HTTPS<br />HTTPS | 
| Middle East (Bahrain) | me-south-1 |  apigateway.me-south-1.amazonaws.com <br /> apigateway.me-south-1.api.aws  | HTTPS<br />HTTPS | 
| Middle East (UAE) | me-central-1 |  apigateway.me-central-1.amazonaws.com <br /> apigateway.me-central-1.api.aws  | HTTPS<br />HTTPS | 
| South America (São Paulo) | sa-east-1 |  apigateway.sa-east-1.amazonaws.com <br /> apigateway.sa-east-1.api.aws  | HTTPS<br />HTTPS | 
|  AWS GovCloud (US-East) | us-gov-east-1 |  apigateway.us-gov-east-1.amazonaws.com <br /> apigateway-fips.us-gov-east-1.amazonaws.com <br /> apigateway.us-gov-east-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS | 
|  AWS GovCloud (US-West) | us-gov-west-1 |  apigateway.us-gov-west-1.amazonaws.com <br /> apigateway-fips.us-gov-west-1.amazonaws.com <br /> apigateway.us-gov-west-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS | 

### Amazon API Gateway data plane
<a name="apigateway_region_data_plane"></a>


| Region Name | Region | Endpoint | Protocol | Route 53 Hosted Zone ID | 
| --- | --- | --- | --- | --- | 
| US East (Ohio) | us-east-2 |  execute-api.us-east-2.amazonaws.com  | HTTPS | ZOJJZC49E0EPZ | 
| US East (N. Virginia) | us-east-1 |  execute-api.us-east-1.amazonaws.com  | HTTPS | Z1UJRXOUMOOFQ8 | 
| US West (N. California) | us-west-1 |  execute-api.us-west-1.amazonaws.com  | HTTPS | Z2MUQ32089INYE | 
| US West (Oregon) | us-west-2 |  execute-api.us-west-2.amazonaws.com  | HTTPS | Z2OJLYMUO9EFXC | 
| Africa (Cape Town) | af-south-1 |  execute-api.af-south-1.amazonaws.com  | HTTPS | Z2DHW2332DAMTN | 
| Asia Pacific (Hong Kong) | ap-east-1 |  execute-api.ap-east-1.amazonaws.com  | HTTPS | Z3FD1VL90ND7K5 | 
| Asia Pacific (Hyderabad) | ap-south-2 |  execute-api.ap-south-2.amazonaws.com  | HTTPS | Z0853509Q1135NJ66RUH | 
| Asia Pacific (Jakarta) | ap-southeast-3 |  execute-api.ap-southeast-3.amazonaws.com  | HTTPS | Z10132843TYUYSLUG4HA3 | 
| Asia Pacific (Malaysia) | ap-southeast-5 |  execute-api.ap-southeast-5.amazonaws.com  | HTTPS | Z0314042F0KBUTZ3X5HF | 
| Asia Pacific (Melbourne) | ap-southeast-4 |  execute-api.ap-southeast-4.amazonaws.com  | HTTPS | Z092189423Y7RJK61311D | 
| Asia Pacific (Mumbai) | ap-south-1 |  execute-api.ap-south-1.amazonaws.com  | HTTPS | Z3VO1THU9YC4UR | 
| Asia Pacific (Osaka) | ap-northeast-3 |  execute-api.ap-northeast-3.amazonaws.com  | HTTPS | Z22ILHG95FLSZ2 | 
| Asia Pacific (Seoul) | ap-northeast-2 |  execute-api.ap-northeast-2.amazonaws.com  | HTTPS | Z20JF4UZKIW1U8 | 
| Asia Pacific (Singapore) | ap-southeast-1 |  execute-api.ap-southeast-1.amazonaws.com  | HTTPS | ZL327KTPIQFUL | 
| Asia Pacific (Sydney) | ap-southeast-2 |  execute-api.ap-southeast-2.amazonaws.com  | HTTPS | Z2RPCDW04V8134 | 
| Asia Pacific (Taipei) | ap-east-2 |  execute-api.ap-east-2.amazonaws.com  | HTTPS | Z02909591O7FG9Q56HWB1 | 
| Asia Pacific (Thailand) | ap-southeast-7 |  execute-api.ap-southeast-7.amazonaws.com  | HTTPS | Z048508712PZLK5NKG8R0 | 
| Asia Pacific (Tokyo) | ap-northeast-1 |  execute-api.ap-northeast-1.amazonaws.com  | HTTPS | Z1YSHQZHG15GKL | 
| Canada (Central) | ca-central-1 |  execute-api.ca-central-1.amazonaws.com  | HTTPS | Z19DQILCV0OWEC | 
| Canada West (Calgary) | ca-west-1 |  execute-api.ca-west-1.amazonaws.com  | HTTPS | Z04745493436AWVTG1OQY | 
| Europe (Frankfurt) | eu-central-1 |  execute-api.eu-central-1.amazonaws.com  | HTTPS | Z1U9ULNL0V5AJ3 | 
| Europe (Ireland) | eu-west-1 |  execute-api.eu-west-1.amazonaws.com  | HTTPS | ZLY8HYME6SFDD | 
| Europe (London) | eu-west-2 |  execute-api.eu-west-2.amazonaws.com  | HTTPS | ZJ5UAJN8Y3Z2Q | 
| Europe (Milan) | eu-south-1 |  execute-api.eu-south-1.amazonaws.com  | HTTPS | Z3BT4WSQ9TDYZV | 
| Europe (Paris) | eu-west-3 |  execute-api.eu-west-3.amazonaws.com  | HTTPS | Z3KY65QIEKYHQQ | 
| Europe (Spain) | eu-south-2 |  execute-api.eu-south-2.amazonaws.com  | HTTPS | Z02499852UI5HEQ5JVWX3 | 
| Europe (Stockholm) | eu-north-1 |  execute-api.eu-north-1.amazonaws.com  | HTTPS | Z3UWIKFBOOGXPP | 
| Europe (Zurich) | eu-central-2 |  execute-api.eu-central-2.amazonaws.com  | HTTPS | Z09222482MK253X48U76H | 
| Israel (Tel Aviv) | il-central-1 |  execute-api.il-central-1.amazonaws.com  | HTTPS | Z07264553HBI44N5X2CKP | 
| Mexico (Central) | mx-central-1 |  execute-api.mx-central-1.amazonaws.com  | HTTPS | Z00020171WIGL5M88SHRM | 
| Middle East (Bahrain) | me-south-1 |  execute-api.me-south-1.amazonaws.com  | HTTPS | Z20ZBPC0SS8806 | 
| Middle East (UAE) | me-central-1 |  execute-api.me-central-1.amazonaws.com  | HTTPS | Z08780021BKYYY8U0YHTV | 
| South America (São Paulo) | sa-east-1 |  execute-api.sa-east-1.amazonaws.com  | HTTPS | ZCMLWB8V5SYIT | 
|  AWS GovCloud (US-East) | us-gov-east-1 |  execute-api.us-gov-east-1.amazonaws.com  | HTTPS | Z3SE9ATJYCRCZJ | 
|  AWS GovCloud (US-West) | us-gov-west-1 |  execute-api.us-gov-west-1.amazonaws.com  | HTTPS | Z1K6XKP9SAGWDV | 

## Service quotas
<a name="limits_apigateway"></a>


| Name | Default | Adjustable | Description | 
| --- | --- | --- | --- | 
| API Payload Size | Each supported Region: 10 Megabytes | No | Maximum payload size for non WebSocket API. | 
| API Stage throttles in a usage plan | Each supported Region: 20 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/apigateway/quotas/L-A9DBC573)  | The maximum number of API-stage throttle settings you can create in a usage plan in this account in the current region | 
| API keys | Each supported Region: 10,000 | No | The maximum number of API keys that you can create in this account in the current region | 
|  AWS Lambda authorizer result size | Each supported Region: 8 Kilobytes | No | The maximum size of AWS Lambda authorizer result. | 
| Client certificates | Each supported Region: 60 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/apigateway/quotas/L-824C9E42)  | The maximum number of certificates that you can associate with this account in the current region | 
| Connection duration for WebSocket API | Each supported Region: 7,200 Seconds | No | Maximum duration for WebSocket API connection. | 
| Custom Domain Names | Each supported Region: 120 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/apigateway/quotas/L-A93447B8)  | The maximum number of Custom domain names that you can create in this account in the current region | 
| Domain name access associations | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/apigateway/quotas/L-4D98A8A5)  | The maximum number of domain name access associations that you can create in this account in the current region | 
| Edge API URL Length | Each supported Region: 8,192 | No | Length, in characters, of the URL for an edge-optimized API. | 
| Edge-optimized APIs | Each supported Region: 120 | No | The maximum number of edge-optimized APIs that you can create in this account in the current region | 
| Maximum API caching TTL | Each supported Region: 3,600 Seconds | No | The maximum API caching TTL you can have in this account in the current region. | 
| Maximum Authorizers per Portal | Each supported Region: 1 | No | The maximum number of authorizer per portal | 
| Maximum Cached Response Size | Each supported Region: 1,048,576 Bytes | No | Maximum size of cached response in bytes | 
| Maximum Combined Header Size | Each supported Region: 10,240 Bytes | No | Maximum combined size of all header values | 
| Maximum Custom Domain Names per Portal | Each supported Region: 1 | No | The maximum number of custom domain names per portal | 
| Maximum Documentation Size per ProductRestEndpointPage | Each supported Region: 32,768 Bytes | No | The maximum documentation size per ProductRestEndpointPage | 
| Maximum Iterations In Mapping Template | Each supported Region: 1,000 | No | Maximum number of iterations in a \#foreach ... \#end loop in mapping templates | 
| Maximum Logo Size | Each supported Region: 200 Kilobytes | No | The maximum size of a logo | 
| Maximum Size per ProductPage body | Each supported Region: 32,768 Bytes | No | The maximum size per ProductPage body | 
| Maximum integration timeout in milliseconds | Each supported Region: 29,000 Milliseconds |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/apigateway/quotas/L-E5AE38E3)  | The maximum integration timeout (in milliseconds) allowed for your account in the current region. This limit can only be increased for Regional and private APIs. | 
| Maximum resource policy size in bytes | Each supported Region: 8,192 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/apigateway/quotas/L-8B81B02C)  | The maximum resource policy size in bytes you can have in this account in the current region. | 
| Method ARN Length | Each supported Region: 1,600 Bytes | No | ARN length of a method with authorization | 
| PortalProducts per Portal | Each supported Region: 200 | No | The maximum number of PortalProducts per Portal | 
| PortalProducts per account | Each supported Region: 500 | No | The maximum number of PortalProducts per account | 
| Portals per account | Each supported Region: 15 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/apigateway/quotas/L-F8BD84D3)  | The maximum number of Portals per account | 
| Private APIs | Each supported Region: 600 | No | The maximum number of private APIs that you can create in this account in the current region | 
| Private custom domain names | Each supported Region: 50 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/apigateway/quotas/L-24E7E662)  | The maximum number of private custom domain names that you can create in this account in the current region | 
| ProductPages per PortalProduct | Each supported Region: 40 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/apigateway/quotas/L-154598D1)  | The maximum number of ProductPages per PortalProduct | 
| ProductRestEndpointPages per PortalProduct | Each supported Region: 40 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/apigateway/quotas/L-05295E0B)  | The maximum number of ProductRestEndpointPages per PortalProduct | 
| Regional API URL Length | Each supported Region: 10,240 | No | Length, in characters, of the URL for a regional API | 
| Regional APIs | Each supported Region: 600 | No | The maximum number of regional APIs that you can create in this account in the current region | 
| Resources/Routes per REST/WebSocket API | Each supported Region: 300 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/apigateway/quotas/L-01C8A9E0)  | The maximum number of resources/routes that you can include in a REST or WebSocket API | 
| Routes per HTTP API | Each supported Region: 300 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/apigateway/quotas/L-65B5C802)  | The maximum number of routes that you can include in an HTTP API | 
| RoutingRules Per Domain Name | Each supported Region: 50 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/apigateway/quotas/L-68B79FF0)  | The maximum number of RoutingRules per DomainName that you can create in this account in the current region | 
| Stage Variable Key Length | Each supported Region: 64 | No | Length, in characters, of the key in a stage variable | 
| Stage Variable Value Length | Each supported Region: 512 | No | Length, in characters, of the value in a stage variable | 
| Stage variables per stage | Each supported Region: 100 | No | Stage variables per stage | 
| Stages per API | Each supported Region: 10 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/apigateway/quotas/L-379E48B0)  | The maximum number of stages that you can create for an API | 
| Subnets per VPC link(V2) | Each supported Region: 10 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/apigateway/quotas/L-668C9B28)  | The maximum number of subnets per V2 VPC link in this account in the current Region | 
| Tags Per Stage | Each supported Region: 50 | No | Maximum tags per stage. | 
| Throttle burst rate | af-south-1: 1,250<br />ap-east-2: 1,250<br />ap-south-2: 1,250<br />ap-southeast-3: 1,250<br />ap-southeast-4: 1,250<br />ap-southeast-5: 1,250<br />ap-southeast-6: 1,250<br />ap-southeast-7: 1,250<br />ca-west-1: 1,250<br />eu-central-2: 1,250<br />eu-south-1: 1,250<br />eu-south-2: 1,250<br />il-central-1: 1,250<br />mx-central-1: 1,250<br />Each of the other supported Regions: 5,000 | No | The maximum number of additional requests per second (RPS) that you can send in one burst in this account in the current region | 
| Throttle rate | af-south-1: 2,500<br />ap-east-2: 2,500<br />ap-south-2: 2,500<br />ap-southeast-3: 2,500<br />ap-southeast-4: 2,500<br />ap-southeast-5: 2,500<br />ap-southeast-6: 2,500<br />ap-southeast-7: 2,500<br />ca-west-1: 2,500<br />eu-central-2: 2,500<br />eu-south-1: 2,500<br />eu-south-2: 2,500<br />il-central-1: 2,500<br />mx-central-1: 2,500<br />Each of the other supported Regions: 10,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/apigateway/quotas/L-8A5B8E43)  | The maximum number of requests per second that your APIs can receive in this account in the current region | 
| Usage plans | Each supported Region: 300 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/apigateway/quotas/L-E8693075)  | The maximum number of usage plans that you can create in this account in the current region | 
| Usage plans per API key | Each supported Region: 10 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/apigateway/quotas/L-985EB478)  | The maximum number of usage plans that you can associate with an API key | 
| VPC links | Each supported Region: 20 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/apigateway/quotas/L-A4C7274F)  | The maximum number of VPC links that you can create in this account in the current region | 
| VPC links(V2) | Each supported Region: 10 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/apigateway/quotas/L-608BDCD4)  | The maximum number of V2 VPC links that you can create in this account in the current Region | 
| WebSocket Idle Connection Timeout | Each supported Region: 600 Seconds | No | WebSocket API idle connection timeout. | 
| WebSocket frame size | Each supported Region: 32 Kilobytes | No | Maximum WebSocket frame size. | 
| WebSocket message payload size | Each supported Region: 128 Kilobytes | No | Maximum WebSocket message payload size. | 
| WebSocket new connections burst rate | Each supported Region: 500 | No | New connections in burst capacity per account (across all WebSocket APIs) per region | 
| WebSocket new connections rate | Each supported Region: 500 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/apigateway/quotas/L-9ED1E49A)  | New connections per second per account (across all WebSocket APIs) per region | 

For more information, see [Quotas in Amazon API Gateway](https://docs.aws.amazon.com/apigateway/latest/developerguide/limits.html) in the *API Gateway Developer Guide*.