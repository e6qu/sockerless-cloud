

# CloudWatch metrics that are available for your instances
<a name="viewing_metrics_with_cloudwatch"></a>

Amazon EC2 sends metrics to Amazon CloudWatch. You can use the AWS Management Console, the AWS CLI, or an API to list the metrics that Amazon EC2 sends to CloudWatch. By default, each data point covers the 5 minutes that follow the start time of activity for the instance. If you've enabled detailed monitoring, each data point covers the next minute of activity from the start time. Note that for the Minimum, Maximum, and Average statistics, the minimum granularity for the metrics that EC2 provides is 1 minute.

For information about how to view the available metrics using the AWS Management Console or the AWS CLI, see [View available metrics](https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/viewing_metrics_with_cloudwatch.html) in the *Amazon CloudWatch User Guide*.

For information about getting the statistics for these metrics, see [Statistics for CloudWatch metrics for your instances](monitoring_get_statistics.md).

**Topics**
+ [Instance metrics](#ec2-cloudwatch-metrics)
+ [Accelerator metrics](#accelerator-metrics)
+ [CPU credit metrics](#cpu-credit-metrics)
+ [Dedicated Host metrics](#dh-metrics)
+ [Amazon EBS metrics for Nitro-based instances](#ebs-metrics-nitro)
+ [Status check metrics](#status-check-metrics)
+ [Traffic mirroring metrics](#traffic-mirroring-metrics)
+ [Auto Scaling group metrics](#autoscaling-metrics)
+ [Amazon EC2 metric dimensions](#ec2-cloudwatch-dimensions)
+ [Amazon EC2 usage metrics](#service-quota-metrics)

## Instance metrics
<a name="ec2-cloudwatch-metrics"></a>

The `AWS/EC2` namespace includes the following instance metrics.


| Metric | Description | Unit | Meaningful statistics | 
| --- | --- | --- | --- | 
| CPUUtilization | The percentage of physical CPU time that Amazon EC2 uses to run the EC2 instance, which includes time spent to run both the user code and the Amazon EC2 code.<br />At a very high level, `CPUUtilization` is the sum of guest `CPUUtilization` and hypervisor `CPUUtilization`.<br />Tools in your operating system can show a different percentage than CloudWatch due to factors such as legacy device simulation, configuration of non-legacy devices, interrupt-heavy workloads, live migration, and live update. | Percent |  +  Average <br />+  Minimum <br />+  Maximum   | 
| DiskReadOps | Completed read operations from all instance store volumes available to the instance in a specified period of time.<br />To calculate the average I/O operations per second (IOPS) for the period, divide the total operations in the period by the number of seconds in that period.<br />If there are no instance store volumes, either the value is 0 or the metric is not reported. | Count |  +  Sum <br />+  Average <br />+  Minimum <br />+  Maximum   | 
| DiskWriteOps | Completed write operations to all instance store volumes available to the instance in a specified period of time.<br />To calculate the average I/O operations per second (IOPS) for the period, divide the total operations in the period by the number of seconds in that period.<br />If there are no instance store volumes, either the value is 0 or the metric is not reported. | Count |  +  Sum <br />+  Average <br />+  Minimum <br />+  Maximum   | 
| DiskReadBytes | Bytes read from all instance store volumes available to the instance.<br />This metric is used to determine the volume of the data the application reads from the hard disk of the instance. This can be used to determine the speed of the application.<br />The number reported is the number of bytes received during the period. If you are using basic (5-minute) monitoring, you can divide this number by 300 to find Bytes/second. If you have detailed (1-minute) monitoring, divide it by 60. You can also use the CloudWatch metric math function `DIFF_TIME` to find the bytes per second. For example, if you have graphed `DiskReadBytes` in CloudWatch as `m1`, the metric math formula `m1/(DIFF_TIME(m1))` returns the metric in bytes/second. For more information about `DIFF_TIME` and other metric math functions, see [Use metric math](https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/using-metric-math.html) in the *Amazon CloudWatch User Guide*.<br />If there are no instance store volumes, either the value is 0 or the metric is not reported. | Bytes |  +  Sum <br />+  Average <br />+  Minimum <br />+  Maximum   | 
| DiskWriteBytes | Bytes written to all instance store volumes available to the instance.<br />This metric is used to determine the volume of the data the application writes onto the hard disk of the instance. This can be used to determine the speed of the application.<br />The number reported is the number of bytes received during the period. If you are using basic (5-minute) monitoring, you can divide this number by 300 to find Bytes/second. If you have detailed (1-minute) monitoring, divide it by 60. You can also use the CloudWatch metric math function `DIFF_TIME` to find the bytes per second. For example, if you have graphed `DiskWriteBytes` in CloudWatch as `m1`, the metric math formula `m1/(DIFF_TIME(m1))` returns the metric in bytes/second. For more information about `DIFF_TIME` and other metric math functions, see [Use metric math](https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/using-metric-math.html) in the *Amazon CloudWatch User Guide*.<br />If there are no instance store volumes, either the value is 0 or the metric is not reported. | Bytes |  +  Sum <br />+  Average <br />+  Minimum <br />+  Maximum   | 
| MetadataNoToken | The number of times the Instance Metadata Service (IMDS) was successfully accessed using a method that does not use a token.<br />This metric is used to determine if there are any processes accessing instance metadata that are using Instance Metadata Service Version 1 (IMDSv1), which does not use a token. If all requests use token-backed sessions, that is, Instance Metadata Service Version 2 (IMDSv2), the value is 0. For more information, see [Transition to using Instance Metadata Service Version 2](instance-metadata-transition-to-version-2.md). | Count |  +  Sum <br />+  Percentiles   | 
| MetadataNoTokenRejected | The number of times an IMDSv1 call was attempted after IMDSv1 was disabled.<br />If this metric appears, it indicates that an IMDSv1 call was attempted and rejected. You can either re-enable IMDSv1 or make sure all of your calls use IMDSv2. For more information, see [Transition to using Instance Metadata Service Version 2](instance-metadata-transition-to-version-2.md). | Count |  +  Sum <br />+  Percentiles   | 
| ImdsV1Enabled | Indicates whether an instance is configured to allow IMDSv1. A value of `1` indicates that IMDSv1 is enabled (`httpTokens` is set to `optional`); a value of `0` indicates that IMDSv1 is disabled (`httpTokens` is set to `required`).<br />The `MetadataNoToken` metric emits only when IMDSv1 is used. In contrast, Amazon EC2 publishes the `ImdsV1Enabled` metric based on the instance's configuration. As a result, you can identify instances that still allow IMDSv1 even when no IMDSv1 calls are being made. Use this metric to track your migration to IMDSv2 across your accounts and Regions. For more information, see [Transition to using Instance Metadata Service Version 2](instance-metadata-transition-to-version-2.md). | Count |  +  Sum <br />+  Average <br />+  Maximum   | 
| NetworkIn | The number of bytes received by the instance on all network interfaces. This metric identifies the volume of incoming network traffic to a single instance.<br />The number reported is the number of bytes received during the period. If you are using basic (5-minute) monitoring and the statistic is Sum, you can divide this number by 300 to find Bytes/second. If you have detailed (1-minute) monitoring and the statistic is Sum, divide it by 60. | Bytes |  +  Sum <br />+  Average <br />+  Minimum <br />+  Maximum   | 
| NetworkOut | The number of bytes sent out by the instance on all network interfaces. This metric identifies the volume of outgoing network traffic from a single instance.<br />The number reported is the number of bytes sent during the period. If you are using basic (5-minute) monitoring and the statistic is Sum, you can divide this number by 300 to find Bytes/second. If you have detailed (1-minute) monitoring and the statistic is Sum, divide it by 60. | Bytes |  +  Sum <br />+  Average <br />+  Minimum <br />+  Maximum   | 
| NetworkPacketsIn | The number of packets received by the instance on all network interfaces. This metric identifies the volume of incoming traffic in terms of the number of packets on a single instance.<br />This metric is available for basic monitoring only (5-minute periods). To calculate the number of packets per second (PPS) your instance received for the 5 minutes, divide the Sum statistic value by 300. | Count |  +  Sum <br />+  Average <br />+  Minimum <br />+  Maximum   | 
| NetworkPacketsOut | The number of packets sent out by the instance on all network interfaces. This metric identifies the volume of outgoing traffic in terms of the number of packets on a single instance.<br />This metric is available for basic monitoring only (5-minute periods). To calculate the number of packets per second (PPS) your instance sent for the 5 minutes, divide the Sum statistic value by 300. | Count |  +  Sum <br />+  Average <br />+  Minimum <br />+  Maximum   | 

## Accelerator metrics
<a name="accelerator-metrics"></a>

The `AWS/EC2` namespace includes the following accelerator metric for your [accelerated computing instances](https://docs.aws.amazon.com/ec2/latest/instancetypes/ac.html). Only supported on a subset of accelerated computing instance types.


| Metric | Description | Unit | Meaningful statistics | 
| --- | --- | --- | --- | 
| GPUPowerUtilization | Active power usage as a percentage of maximum active power. | Percent |  +  Average <br />+  Minimum <br />+  Maximum   | 

## CPU credit metrics
<a name="cpu-credit-metrics"></a>

The `AWS/EC2` namespace includes the following CPU credit metrics for your [burstable performance instances](burstable-performance-instances.md).


| Metric | Description | Unit | Meaningful statistics | 
| --- | --- | --- | --- | 
| CPUCreditUsage | The number of CPU credits spent by the instance for CPU utilization. One CPU credit equals one vCPU running at 100% utilization for one minute or an equivalent combination of vCPUs, utilization, and time (for example, one vCPU running at 50% utilization for two minutes or two vCPUs running at 25% utilization for two minutes).<br />CPU credit metrics are available at a 5-minute frequency only. If you specify a period greater than five minutes, use the `Sum` statistic instead of the `Average` statistic. | Credits (vCPU-minutes) |  +  Sum <br />+  Average <br />+  Minimum <br />+  Maximum   | 
| CPUCreditBalance | The number of earned CPU credits that an instance has accrued since it was launched or started. For T2 Standard, the `CPUCreditBalance` also includes the number of launch credits that have been accrued.<br />Credits are accrued in the credit balance after they are earned, and removed from the credit balance when they are spent. The credit balance has a maximum limit, determined by the instance size. After the limit is reached, any new credits that are earned are discarded. For T2 Standard, launch credits do not count towards the limit.<br />The credits in the `CPUCreditBalance` are available for the instance to spend to burst beyond its baseline CPU utilization.<br />When an instance is running, credits in the `CPUCreditBalance` do not expire. When a T3 or T3a instance stops, the `CPUCreditBalance` value persists for seven days. Thereafter, all accrued credits are lost. When a T2 instance stops, the `CPUCreditBalance` value does not persist, and all accrued credits are lost.<br />CPU credit metrics are available at a 5-minute frequency only. | Credits (vCPU-minutes) |  +  Sum <br />+  Average <br />+  Minimum <br />+  Maximum   | 
| CPUSurplusCreditBalance  | The number of surplus credits that have been spent by an `unlimited` instance when its `CPUCreditBalance` value is zero.<br />The `CPUSurplusCreditBalance` value is paid down by earned CPU credits. If the number of surplus credits exceeds the maximum number of credits that the instance can earn in a 24-hour period, the spent surplus credits above the maximum incur an additional charge.<br />CPU credit metrics are available at a 5-minute frequency only. | Credits (vCPU-minutes) |  +  Sum <br />+  Average <br />+  Minimum <br />+  Maximum   | 
| CPUSurplusCreditsCharged | The number of spent surplus credits that are not paid down by earned CPU credits, and which thus incur an additional charge.<br />Spent surplus credits are charged when any of the following occurs: +  The spent surplus credits exceed the maximum number of credits that the instance can earn in a 24-hour period. Spent surplus credits above the maximum are charged at the end of the hour. <br />+  The instance is stopped or terminated. <br />+  The instance is switched from `unlimited` to `standard`. <br />CPU credit metrics are available at a 5-minute frequency only. | Credits (vCPU-minutes) |  +  Sum <br />+  Average <br />+  Minimum <br />+  Maximum   | 

## Dedicated Host metrics
<a name="dh-metrics"></a>

The `AWS/EC2` namespace includes the following metrics for T3 Dedicated Hosts.


| Metric | Description | Unit | Meaningful statistics | 
| --- | --- | --- | --- | 
|  DedicatedHostCPUUtilization | The percentage of allocated compute capacity that is currently in use by the instances running on the Dedicated Host. | Percent |  +  Sum <br />+  Average <br />+  Minimum <br />+  Maximum   | 

## Amazon EBS metrics for Nitro-based instances
<a name="ebs-metrics-nitro"></a>

The `AWS/EC2` namespace includes additional Amazon EBS metrics for volumes that are attached to Nitro-based instances that are not bare metal instances.


| Metric | Description | Unit | Meaningful statistics | 
| --- | --- | --- | --- | 
|  InstanceEBSIOPSExceededCheck  | Reports whether an application attempted to drive IOPS that exceeds the maximum EBS IOPS limits for the instance within the last minute. This metric can be either `0` (IOPS not exceeded) or `1` (IOPS exceeded). | None |  +  Sum <br />+  Average <br />+  Minimum <br />+  Maximum   | 
|  InstanceEBSThroughputExceededCheck  | Reports whether an application attempted to drive throughput that exceeds the maximum EBS throughput limits for the instance within the last minute. This metric can be either `0` (throughput not exceeded) or `1` (throughput exceeded). | None |  +  Sum <br />+  Average <br />+  Minimum <br />+  Maximum   | 
|  EBSReadOps | Completed read operations from all Amazon EBS volumes attached to the instance in a specified period of time.<br />To calculate the average read I/O operations per second (Read IOPS) for the period, divide the total operations in the period by the number of seconds in that period. If you are using basic (5-minute) monitoring, you can divide this number by 300 to calculate the Read IOPS. If you have detailed (1-minute) monitoring, divide it by 60. You can also use the CloudWatch metric math function `DIFF_TIME` to find the operations per second. For example, if you have graphed `EBSReadOps` in CloudWatch as `m1`, the metric math formula `m1/(DIFF_TIME(m1))` returns the metric in operations/second. For more information about `DIFF_TIME` and other metric math functions, see [Use metric math](https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/using-metric-math.html) in the *Amazon CloudWatch User Guide*. | Count |  +  Sum <br />+  Average <br />+  Minimum <br />+  Maximum   | 
|  EBSWriteOps  | Completed write operations to all EBS volumes attached to the instance in a specified period of time.<br />To calculate the average write I/O operations per second (Write IOPS) for the period, divide the total operations in the period by the number of seconds in that period. If you are using basic (5-minute) monitoring, you can divide this number by 300 to calculate the Write IOPS. If you have detailed (1-minute) monitoring, divide it by 60. You can also use the CloudWatch metric math function `DIFF_TIME` to find the operations per second. For example, if you have graphed `EBSWriteOps` in CloudWatch as `m1`, the metric math formula `m1/(DIFF_TIME(m1))` returns the metric in operations/second. For more information about `DIFF_TIME` and other metric math functions, see [Use metric math](https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/using-metric-math.html) in the *Amazon CloudWatch User Guide*. | Count |  +  Sum <br />+  Average <br />+  Minimum <br />+  Maximum   | 
|  EBSReadBytes  | Bytes read from all EBS volumes attached to the instance in a specified period of time.<br />The number reported is the number of bytes read during the period. If you are using basic (5-minute) monitoring, you can divide this number by 300 to find Read Bytes/second. If you have detailed (1-minute) monitoring, divide it by 60. You can also use the CloudWatch metric math function `DIFF_TIME` to find the bytes per second. For example, if you have graphed `EBSReadBytes` in CloudWatch as `m1`, the metric math formula `m1/(DIFF_TIME(m1))` returns the metric in bytes/second. For more information about `DIFF_TIME` and other metric math functions, see [Use metric math](https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/using-metric-math.html) in the *Amazon CloudWatch User Guide*. | Bytes |  +  Sum <br />+  Average <br />+  Minimum <br />+  Maximum   | 
|  EBSWriteBytes  | Bytes written to all EBS volumes attached to the instance in a specified period of time.<br />The number reported is the number of bytes written during the period. If you are using basic (5-minute) monitoring, you can divide this number by 300 to find Write Bytes/second. If you have detailed (1-minute) monitoring, divide it by 60. You can also use the CloudWatch metric math function `DIFF_TIME` to find the bytes per second. For example, if you have graphed `EBSWriteBytes` in CloudWatch as `m1`, the metric math formula `m1/(DIFF_TIME(m1))` returns the metric in bytes/second. For more information about `DIFF_TIME` and other metric math functions, see [Use metric math](https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/using-metric-math.html) in the *Amazon CloudWatch User Guide*. | Bytes |  +  Sum <br />+  Average <br />+  Minimum <br />+  Maximum   | 
|  EBSIOBalance%  | Provides information about the percentage of I/O credits remaining in the burst bucket. This metric is available for basic monitoring only.<br />This metric is available only for some `*.4xlarge` instance sizes and smaller that burst to their maximum performance for only 30 minutes at least once every 24 hours.<br />The `Sum` statistic is not applicable to this metric. | Percent |  +  Minimum <br />+  Maximum   | 
|  EBSByteBalance%  | Provides information about the percentage of throughput credits remaining in the burst bucket. This metric is available for basic monitoring only.<br />This metric is available only for some `*.4xlarge` instance sizes and smaller that burst to their maximum performance for only 30 minutes at least once every 24 hours.<br />The `Sum` statistic is not applicable to this metric. | Percent |  +  Minimum <br />+  Maximum   | 

For information about the metrics provided for your EBS volumes, see [Metrics for Amazon EBS volumes](https://docs.aws.amazon.com/ebs/latest/userguide/using_cloudwatch_ebs.html#ebs-volume-metrics) in the *Amazon EBS User Guide*. For information about the metrics provided for your EC2 Fleets and Spot Fleets, see [Monitor your EC2 Fleet or Spot Fleet using CloudWatch](ec2-fleet-cloudwatch-metrics.md).

## Status check metrics
<a name="status-check-metrics"></a>

By default, status check metrics are available at a 1-minute frequency at no charge. For a newly-launched instance, status check metric data is only available after the instance has completed the initialization state (within a few minutes of the instance entering the `running` state). For more information about EC2 status checks, see [Status checks for Amazon EC2 instances](monitoring-system-instance-status-check.md).

The `AWS/EC2` namespace includes the following status check metrics.


| Metric | Description | Unit | Meaningful statistics | 
| --- | --- | --- | --- | 
| StatusCheckFailed | Reports whether the instance has passed all status checks in the last minute.<br />This metric can be either `0` (passed) or `1` (failed).<br />By default, this metric is available at a 1-minute frequency at no charge. | Count |  +  Average <br />+  Minimum <br />+  Maximum   | 
| StatusCheckFailed\_Instance | Reports whether the instance has passed the instance status check in the last minute.<br />This metric can be either `0` (passed) or `1` (failed).<br />By default, this metric is available at a 1-minute frequency at no charge. | Count |  +  Average <br />+  Minimum <br />+  Maximum   | 
| StatusCheckFailed\_System | Reports whether the instance has passed the system status check in the last minute.<br />This metric can be either `0` (passed) or `1` (failed).<br />By default, this metric is available at a 1-minute frequency at no charge. | Count |  +  Average <br />+  Minimum <br />+  Maximum   | 
| StatusCheckFailed\_AttachedEBS | Reports whether the instance has passed the attached EBS status check in the last minute.<br />This metric can be either `0` (passed) or `1` (failed).<br />By default, this metric is available at a 1-minute frequency at no charge. | Count |  +  Average <br />+  Minimum <br />+  Maximum   | 
| StatusCheckFailed\_Performance | Reports whether the instance has passed the performance status checks in the last minute.<br />This metric can be either `0` (passed) or `1` (failed).<br />By default, this metric is available at a 1-minute frequency at no charge. | Count |  +  Average <br />+  Minimum <br />+  Maximum   | 

The `AWS/EBS` namespace includes the following status check metric.


| Metric | Description | Unit | Meaningful statistics | 
| --- | --- | --- | --- | 
| VolumeStalledIOCheck | **Note: **For Nitro instances only. Not published for volumes attached to Amazon ECS and AWS Fargate tasks.<br />Reports whether a volume has passed or failed a *stalled IO check* in the last minute. This metric can be either `0` (passed) or `1` (failed). | None |  +  Average <br />+  Minimum <br />+  Maximum   | 

## Traffic mirroring metrics
<a name="traffic-mirroring-metrics"></a>

The `AWS/EC2` namespace includes metrics for mirrored traffic. For more information, see [Monitor mirrored traffic using Amazon CloudWatch](https://docs.aws.amazon.com/vpc/latest/mirroring/traffic-mirror-cloudwatch.html) in the *Amazon VPC Traffic Mirroring Guide*.

## Auto Scaling group metrics
<a name="autoscaling-metrics"></a>

The `AWS/AutoScaling` namespace includes metrics for Auto Scaling groups. For more information, see [Monitor CloudWatch metrics for your Auto Scaling groups and instances](https://docs.aws.amazon.com/autoscaling/ec2/userguide/ec2-auto-scaling-cloudwatch-monitoring.html) in the *Amazon EC2 Auto Scaling User Guide*.

## Amazon EC2 metric dimensions
<a name="ec2-cloudwatch-dimensions"></a>

You can use the following dimensions to refine the metrics listed in the previous tables.


| Dimension | Description | 
| --- | --- | 
|  AutoScalingGroupName  | This dimension filters the data you request for all instances in a specified capacity group. An *Auto Scaling group* is a collection of instances you define if you're using Auto Scaling. This dimension is available only for Amazon EC2 metrics when the instances are in such an Auto Scaling group. Available for instances with Detailed or Basic Monitoring enabled. | 
|  ImageId  | This dimension filters the data you request for all instances running this Amazon EC2 Amazon Machine Image (AMI). Available for instances with Detailed Monitoring enabled. | 
|  InstanceId  | This dimension filters the data you request for the identified instance only. This helps you pinpoint an exact instance from which to monitor data. | 
|  InstanceType  | This dimension filters the data you request for all instances running with this specified instance type. This helps you categorize your data by the type of instance running. For example, you might compare data from an m1.small instance and an m1.large instance to determine which has the better business value for your application. Available for instances with Detailed Monitoring enabled. | 

## Amazon EC2 usage metrics
<a name="service-quota-metrics"></a>

You can use CloudWatch usage metrics to provide visibility into your account's usage of resources. Use these metrics to visualize your current service usage on CloudWatch graphs and dashboards.

Amazon EC2 usage metrics correspond to AWS service quotas. You can configure alarms that alert you when your usage approaches a service quota. For more information about CloudWatch integration with service quotas, see [AWS usage metrics](https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/CloudWatch-Service-Quota-Integration.html) in the *Amazon CloudWatch User Guide*.

Amazon EC2 publishes the following metrics in the `AWS/Usage` namespace.


| Metric | Description | 
| --- | --- | 
| `ResourceCount` | The number of the specified resources running in your account. The resources are defined by the dimensions associated with the metric.<br />The most useful statistic for this metric is `MAXIMUM`, which represents the maximum number of resources used during the 1-minute period. | 

The following dimensions are used to refine the usage metrics that are published by Amazon EC2.


| Dimension | Description | 
| --- | --- | 
|  Service  | The name of the AWS service containing the resource. For Amazon EC2 usage metrics, the value for this dimension is `EC2`. | 
|  Type  | The type of entity that is being reported. Currently, the only valid value for Amazon EC2 usage metrics is `Resource`. | 
|  Resource  | The type of resource that is running. Currently, the only valid value for Amazon EC2 usage metrics is `vCPU`, which returns information on instances that are running. | 
|  Class  | The class of resource being tracked. For Amazon EC2 usage metrics with `vCPU` as the value of the `Resource` dimension, the valid values are `Standard/OnDemand`, `F/OnDemand`, `G/OnDemand`, `Inf/OnDemand`, `P/OnDemand`, and `X/OnDemand`.<br />The values for this dimension define the first letter of the instance types that are reported by the metric. For example, `Standard/OnDemand` returns information about all running instances with types that start with A, C, D, H, I, M, R, T, and Z, and `G/OnDemand` returns information about all running instances with types that start with G. | 