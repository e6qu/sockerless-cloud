

# Amazon Elastic Block Store endpoints and quotas
<a name="ebs-service"></a>

To connect programmatically to an AWS service, you use an endpoint. AWS services offer the following endpoint types in some or all of the AWS Regions that the service supports: IPv4 endpoints, dual-stack endpoints, and FIPS endpoints. Some services provide global endpoints. For more information, see [AWS service endpoints](rande.md).

Service quotas, also referred to as limits, are the maximum number of service resources or operations for your AWS account. For more information, see [AWS service quotas](aws_service_limits.md).

The following are the service endpoints and service quotas for this service.

## Service endpoints
<a name="ebs_region"></a>

**Topics**
+ [Endpoints for Amazon EBS in Amazon EC2](#ebs_in_ec2)
+ [Endpoints for the EBS direct APIs](#ebs_direct_apis)

### Endpoints for Amazon EBS in Amazon EC2
<a name="ebs_in_ec2"></a>

The API actions to manage EBS volumes, snapshots, and encryption are part of the Amazon EC2 API. For more information, see [Amazon EBS actions](https://docs.aws.amazon.com/AWSEC2/latest/APIReference/OperationList-query-ebs.html) in the *Amazon EC2 API Reference*.

For the service endpoints for Amazon EC2, see [Amazon EC2 endpoints and quotas](ec2-service.md).

### Endpoints for the EBS direct APIs
<a name="ebs_direct_apis"></a>

Use the EBS direct APIs endpoints to directly read the data on your Amazon EBS snapshots, and identify the difference between two snapshots. For more information, see [Use EBS direct APIs to access the contents of an Amazon EBS snapshot](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/ebs-accessing-snapshot.html) in the *Amazon Elastic Compute Cloud User Guide*.


| Region Name | Region | Endpoint | Protocol | 
| --- | --- | --- | --- | 
| US East (Ohio) | us-east-2 |  ebs.us-east-2.amazonaws.com <br /> ebs-fips.us-east-2.api.aws <br /> ebs.us-east-2.api.aws <br /> ebs-fips.us-east-2.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| US East (N. Virginia) | us-east-1 |  ebs.us-east-1.amazonaws.com <br /> ebs-fips.us-east-1.api.aws <br /> ebs-fips.us-east-1.amazonaws.com <br /> ebs.us-east-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| US West (N. California) | us-west-1 |  ebs.us-west-1.amazonaws.com <br /> ebs.us-west-1.api.aws <br /> ebs-fips.us-west-1.api.aws <br /> ebs-fips.us-west-1.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| US West (Oregon) | us-west-2 |  ebs.us-west-2.amazonaws.com <br /> ebs-fips.us-west-2.api.aws <br /> ebs.us-west-2.api.aws <br /> ebs-fips.us-west-2.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Africa (Cape Town) | af-south-1 |  ebs.af-south-1.amazonaws.com <br /> ebs.af-south-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Hong Kong) | ap-east-1 |  ebs.ap-east-1.amazonaws.com <br /> ebs.ap-east-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Hyderabad) | ap-south-2 |  ebs.ap-south-2.amazonaws.com <br /> ebs.ap-south-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Jakarta) | ap-southeast-3 |  ebs.ap-southeast-3.amazonaws.com <br /> ebs.ap-southeast-3.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Malaysia) | ap-southeast-5 |  ebs.ap-southeast-5.amazonaws.com <br /> ebs.ap-southeast-5.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Melbourne) | ap-southeast-4 |  ebs.ap-southeast-4.amazonaws.com <br /> ebs.ap-southeast-4.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Mumbai) | ap-south-1 |  ebs.ap-south-1.amazonaws.com <br /> ebs.ap-south-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (New Zealand) | ap-southeast-6 |  ebs.ap-southeast-6.amazonaws.com <br /> ebs.ap-southeast-6.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Osaka) | ap-northeast-3 |  ebs.ap-northeast-3.amazonaws.com <br /> ebs.ap-northeast-3.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Seoul) | ap-northeast-2 |  ebs.ap-northeast-2.amazonaws.com <br /> ebs.ap-northeast-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Singapore) | ap-southeast-1 |  ebs.ap-southeast-1.amazonaws.com <br /> ebs.ap-southeast-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Sydney) | ap-southeast-2 |  ebs.ap-southeast-2.amazonaws.com <br /> ebs.ap-southeast-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Taipei) | ap-east-2 |  ebs.ap-east-2.amazonaws.com <br /> ebs.ap-east-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Thailand) | ap-southeast-7 |  ebs.ap-southeast-7.amazonaws.com <br /> ebs.ap-southeast-7.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Tokyo) | ap-northeast-1 |  ebs.ap-northeast-1.amazonaws.com <br /> ebs.ap-northeast-1.api.aws  | HTTPS<br />HTTPS | 
| Canada (Central) | ca-central-1 |  ebs.ca-central-1.amazonaws.com <br /> ebs.ca-central-1.api.aws <br /> ebs-fips.ca-central-1.amazonaws.com <br /> ebs-fips.ca-central-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Canada West (Calgary) | ca-west-1 |  ebs.ca-west-1.amazonaws.com <br /> ebs.ca-west-1.api.aws <br /> ebs-fips.ca-west-1.amazonaws.com <br /> ebs-fips.ca-west-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Europe (Frankfurt) | eu-central-1 |  ebs.eu-central-1.amazonaws.com <br /> ebs.eu-central-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Ireland) | eu-west-1 |  ebs.eu-west-1.amazonaws.com <br /> ebs.eu-west-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (London) | eu-west-2 |  ebs.eu-west-2.amazonaws.com <br /> ebs.eu-west-2.api.aws  | HTTPS<br />HTTPS | 
| Europe (Milan) | eu-south-1 |  ebs.eu-south-1.amazonaws.com <br /> ebs.eu-south-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Paris) | eu-west-3 |  ebs.eu-west-3.amazonaws.com <br /> ebs.eu-west-3.api.aws  | HTTPS<br />HTTPS | 
| Europe (Spain) | eu-south-2 |  ebs.eu-south-2.amazonaws.com <br /> ebs.eu-south-2.api.aws  | HTTPS<br />HTTPS | 
| Europe (Stockholm) | eu-north-1 |  ebs.eu-north-1.amazonaws.com <br /> ebs.eu-north-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Zurich) | eu-central-2 |  ebs.eu-central-2.amazonaws.com <br /> ebs.eu-central-2.api.aws  | HTTPS<br />HTTPS | 
| Israel (Tel Aviv) | il-central-1 |  ebs.il-central-1.amazonaws.com <br /> ebs.il-central-1.api.aws  | HTTPS<br />HTTPS | 
| Mexico (Central) | mx-central-1 |  ebs.mx-central-1.amazonaws.com <br /> ebs.mx-central-1.api.aws  | HTTPS<br />HTTPS | 
| Middle East (Bahrain) | me-south-1 |  ebs.me-south-1.amazonaws.com <br /> ebs.me-south-1.api.aws  | HTTPS<br />HTTPS | 
| Middle East (UAE) | me-central-1 |  ebs.me-central-1.amazonaws.com <br /> ebs.me-central-1.api.aws  | HTTPS<br />HTTPS | 
| South America (São Paulo) | sa-east-1 |  ebs.sa-east-1.amazonaws.com <br /> ebs.sa-east-1.api.aws  | HTTPS<br />HTTPS | 
|  AWS GovCloud (US-East) | us-gov-east-1 |  ebs.us-gov-east-1.amazonaws.com <br /> ebs.us-gov-east-1.api.aws <br /> ebs-fips.us-gov-east-1.amazonaws.com <br /> ebs-fips.us-gov-east-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
|  AWS GovCloud (US-West) | us-gov-west-1 |  ebs.us-gov-west-1.amazonaws.com <br /> ebs-fips.us-gov-west-1.amazonaws.com <br /> ebs-fips.us-gov-west-1.api.aws <br /> ebs.us-gov-west-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 

## Service quotas
<a name="limits_ebs"></a>

Your quotas can change over time. Amazon EBS constantly monitors your provisioned storage and IOPS usage within each Region and might automatically increase your quotas, on a per-Region basis, based on your usage.

Even though Amazon EBS automatically increases your quotas based on your usage, you can request a quota increase if needed. For example, if you intend to use more `gp3` storage in US East (N. Virginia) than your current quota allows, you can request a quota increase for that volume type in that Region. To request a quota increase, use the [AWS Service Quotas console](https://console.aws.amazon.com/servicequotas/).

**Considerations**
+ The quota for **Concurrent snapshot copies per destination Region** is not adjustable using Service Quotas. However, you can request an increase for this quota by contacting AWS Support.
+ The **IOPS modifications and Storage modifications** quotas apply to the aggregated current value (for *size* or *IOPS*, depending on the quota) of volumes that can undergo modifications concurrently. You can make concurrent modification requests for volumes that have combined current value (for *size* or *IOPS*) up to the quota. For example, if your **IOPS modifications for Provisioned IOPS SSD (io1) volumes** quota is `50,000`, you can make concurrent IOPS modifications requests for any number of `io1` volumes as long as their combined current IOPS is equal to or less than `50,000`. If you have three `io1` volumes provisioned with `20,000` IOPS each, you can request IOPS modifications for two volumes concurrently (`20,000 * 2 < 50,000`). If you submit a concurrent IOPS modification request for the third volume, you exceed your quota and that request fails (`20,000 * 3 > 50,000`). 
+ Amazon EBS has the following non-adjustable limits for the number of EBS volumes per instance launch request.
  + `2500` — `us-east-1`, `us-west-2`, `eu-west-1`, and `ap-northeast-1`
  + `500` — all other Regions

  This limit applies to instance launch requests that you make, and to instance launch requests made by AWS services, such as Amazon EMR, on your behalf. If your instance launch request fails as a result of exceeding this limit, we recommend that you adjust the EBS volume configuration in the launch request to ensure the number of volumes is below the limit, or that you work with your technical account manager (TAM) to explore other options for launching your cluster without exceeding the limit.


| Name | Default | Adjustable | Description | 
| --- | --- | --- | --- | 
| Archived snapshots per volume | Each supported Region: 25 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ebs/quotas/L-E20676C1)  | The maximum number of archived snapshots per volume. | 
| CompleteSnapshot requests per account | Each supported Region: 10 per second | No | The maximum number of CompleteSnapshot requests allowed per account. | 
| Concurrent snapshot copies per destination Region | Each supported Region: 20 | No | The maximum number of concurrent snapshot copies to a single destination Region. | 
| Concurrent snapshots per Cold HDD (sc1) volume | Each supported Region: 1 | No | The maximum number of concurrent snapshots per Cold HDD (sc1) volume in this Region. | 
| Concurrent snapshots per General Purpose SSD (gp2) volume | Each supported Region: 5 | No | The maximum number of concurrent snapshots per General Purpose SSD (gp2) volume in this Region. | 
| Concurrent snapshots per General Purpose SSD (gp3) volume | Each supported Region: 5 | No | The maximum number of concurrent snapshots per General Purpose SSD (gp3) volume in this Region. | 
| Concurrent snapshots per Magnetic (standard) volume | Each supported Region: 5 | No | The maximum number of concurrent snapshots per Magnetic (standard) volume in this Region. | 
| Concurrent snapshots per Provisioned IOPS SSD (io1) volume | Each supported Region: 5 | No | The maximum number of concurrent snapshots per Provisioned IOPS SSD (io1) volume in this Region. | 
| Concurrent snapshots per Provisioned IOPS SSD (io2) volume | Each supported Region: 5 | No | The maximum number of concurrent snapshots per Provisioned IOPS SSD (io2) volume in this Region. | 
| Concurrent snapshots per Throughput Optimized HDD (st1) volume | Each supported Region: 1 | No | The maximum number of concurrent snapshots per Throughput Optimized HDD (st1) volume in this Region. | 
| Fast snapshot restore | Each supported Region: 5 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ebs/quotas/L-631ECBD3)  | The maximum number of snapshots that can be enabled for fast snapshot restore in this Region. | 
| GetSnapshotBlock requests per account | us-east-1: 5,000 per second<br />us-east-2: 5,000 per second<br />us-west-2: 5,000 per second<br />ap-southeast-1: 5,000 per second<br />eu-west-1: 5,000 per second<br />Each of the other supported Regions: 1,000 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ebs/quotas/L-C125AE42)  | The maximum number of GetSnapshotBlock requests allowed per account. | 
| GetSnapshotBlock requests per snapshot | Each supported Region: 1,000 per second | No | The maximum number of GetSnapshotBlock requests allowed per snapshot. | 
| IOPS for Provisioned IOPS SSD (io1) volumes | Each supported Region: 300,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ebs/quotas/L-B3A130E6)  | The maximum aggregated number of IOPS that can be provisioned across Provisioned IOPS SSD (io1) volumes in this Region. | 
| IOPS for Provisioned IOPS SSD (io2) volumes | Each supported Region: 100,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ebs/quotas/L-8D977E7E)  | The maximum aggregated number of IOPS that can be provisioned across Provisioned IOPS SSD (io2) volumes in this Region. | 
| IOPS modifications for Provisioned IOPS SSD (io1) volumes | Each supported Region: 500,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ebs/quotas/L-98A0B26D)  | The maximum aggregated number of IOPS that can be requested in volume modifications across Provisioned IOPS SSD (io1) volumes in this Region. | 
| IOPS modifications for Provisioned IOPS SSD (io2) volumes | Each supported Region: 100,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ebs/quotas/L-35B31D98)  | The maximum current (from) and requested (to) IOPS for volume modification requests across Provisioned IOPS SSD (io2) volumes in this Region. | 
| In-progress snapshot archives per account | Each supported Region: 25 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ebs/quotas/L-3A0E616D)  | The maximum number of in-progress snapshot archives per account. | 
| In-progress snapshot restores from archive per account | Each supported Region: 5 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ebs/quotas/L-07399329)  | The maximum number of in-progress snapshot restores from archive per account. | 
| ListChangedBlocks requests per account | Each supported Region: 50 per second | No | The maximum number of ListChangedBlocks requests allowed per account. | 
| ListSnapshotBlocks requests per account | Each supported Region: 50 per second | No | The maximum number of ListSnapshotBlocks requests allowed per account. | 
| Max concurrent copy volume operations per account | Each supported Region: 5 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ebs/quotas/L-39BD5252)  | Maximum number of concurrent copy volume operations allowed per account in this region. | 
| Provisioned Rate for Volume Initialization across concurrent volume creation requests per Region | Each supported Region: 5,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ebs/quotas/L-A37D9CF3)  | The maximum aggregated Provisioned Rate for Volume Initialization, in MiB/s, that can be requested across concurrent volume creation requests in this Region. | 
| PutSnapshotBlock requests per account | us-east-1: 5,000 per second<br />us-east-2: 5,000 per second<br />us-west-2: 5,000 per second<br />ap-southeast-1: 5,000 per second<br />eu-west-1: 5,000 per second<br />Each of the other supported Regions: 1,000 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ebs/quotas/L-AFAE1BE8)  | The maximum number of PutSnapshotBlock requests allowed per account. | 
| PutSnapshotBlock requests per snapshot | Each supported Region: 1,000 per second | No | The maximum number of PutSnapshotBlock requests allowed per snapshot. | 
| Snapshots per Region | Each supported Region: 100,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ebs/quotas/L-309BACF6)  | The maximum number of snapshots per Region. | 
| StartSnapshot pending snapshots per account | Each supported Region: 100 | No | The maximum number of pending snapshots per account that can be created using the StartSnapshot API. | 
| StartSnapshot requests per account | Each supported Region: 10 per second | No | The maximum number of StartSnapshot requests allowed per account. | 
| Storage for Cold HDD (sc1) volumes, in TiB | us-east-1: 50<br />us-east-2: 50<br />us-west-1: 50<br />us-west-2: 50<br />ap-northeast-1: 50<br />ap-northeast-2: 50<br />ap-south-1: 50<br />ap-southeast-1: 50<br />ap-southeast-2: 50<br />ca-central-1: 50<br />eu-central-1: 50<br />eu-north-1: 50<br />eu-west-1: 50<br />eu-west-2: 50<br />eu-west-3: 50<br />sa-east-1: 50<br />Each of the other supported Regions: 300 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ebs/quotas/L-17AF77E8)  | The maximum aggregated amount of storage, in TiB, that can be provisioned across Cold HDD (sc1) volumes in this Region. | 
| Storage for General Purpose SSD (gp2) volumes, in TiB | us-east-1: 50<br />us-east-2: 50<br />us-west-1: 50<br />us-west-2: 50<br />ap-northeast-1: 50<br />ap-northeast-2: 50<br />ap-south-1: 50<br />ap-southeast-1: 50<br />ap-southeast-2: 50<br />ca-central-1: 50<br />eu-central-1: 50<br />eu-north-1: 50<br />eu-west-1: 50<br />eu-west-2: 50<br />eu-west-3: 50<br />sa-east-1: 50<br />Each of the other supported Regions: 300 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ebs/quotas/L-D18FCD1D)  | The maximum aggregated amount of storage, in TiB, that can be provisioned across General Purpose SSD (gp2) volumes in this Region. | 
| Storage for General Purpose SSD (gp3) volumes, in TiB | af-south-1: 300<br />ap-east-1: 300<br />ap-east-2: 300<br />ap-northeast-3: 300<br />ap-south-2: 300<br />ap-southeast-4: 300<br />ap-southeast-5: 300<br />ap-southeast-6: 300<br />ap-southeast-7: 300<br />ca-west-1: 300<br />eu-central-2: 300<br />eu-south-1: 300<br />eu-south-2: 300<br />il-central-1: 300<br />mx-central-1: 300<br />Each of the other supported Regions: 50 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ebs/quotas/L-7A658B76)  | The maximum aggregated amount of storage, in TiB, that can be provisioned across General Purpose SSD (gp3) volumes in this Region. | 
| Storage for Magnetic (standard) volumes, in TiB | us-east-1: 50<br />us-east-2: 50<br />us-west-1: 50<br />us-west-2: 50<br />ap-northeast-1: 50<br />ap-northeast-2: 50<br />ap-south-1: 50<br />ap-southeast-1: 50<br />ap-southeast-2: 50<br />ca-central-1: 50<br />eu-central-1: 50<br />eu-north-1: 50<br />eu-west-1: 50<br />eu-west-2: 50<br />eu-west-3: 50<br />sa-east-1: 50<br />Each of the other supported Regions: 300 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ebs/quotas/L-9CF3C2EB)  | The maximum aggregated amount of storage, in TiB, that can be provisioned across Magnetic (standard) volumes in this Region. | 
| Storage for Provisioned IOPS SSD (io1) volumes, in TiB | us-east-1: 50<br />us-east-2: 50<br />us-west-1: 50<br />us-west-2: 50<br />ap-northeast-1: 50<br />ap-northeast-2: 50<br />ap-south-1: 50<br />ap-southeast-1: 50<br />ap-southeast-2: 50<br />ca-central-1: 50<br />eu-central-1: 50<br />eu-north-1: 50<br />eu-west-1: 50<br />eu-west-2: 50<br />eu-west-3: 50<br />sa-east-1: 50<br />Each of the other supported Regions: 300 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ebs/quotas/L-FD252861)  | The maximum aggregated amount of storage, in TiB, that can be provisioned across Provisioned IOPS SSD (io1) volumes in this Region. | 
| Storage for Provisioned IOPS SSD (io2) volumes, in TiB | Each supported Region: 20 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ebs/quotas/L-09BD8365)  | The maximum aggregated amount of storage, in TiB, that can be provisioned across Provisioned IOPS SSD (io2) volumes in this Region. | 
| Storage for Throughput Optimized HDD (st1) volumes, in TiB | us-east-1: 50<br />us-east-2: 50<br />us-west-1: 50<br />us-west-2: 50<br />ap-northeast-1: 50<br />ap-northeast-2: 50<br />ap-south-1: 50<br />ap-southeast-1: 50<br />ap-southeast-2: 50<br />ca-central-1: 50<br />eu-central-1: 50<br />eu-north-1: 50<br />eu-west-1: 50<br />eu-west-2: 50<br />eu-west-3: 50<br />sa-east-1: 50<br />Each of the other supported Regions: 300 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ebs/quotas/L-82ACEF56)  | The maximum aggregated amount of storage, in TiB, that can be provisioned across Throughput Optimized HDD (st1) volumes in this Region. | 
| Storage modifications for Cold HDD (sc1) volumes, in TiB | Each supported Region: 500 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ebs/quotas/L-651D1834)  | The maximum aggregated amount of storage, in TiB, that can be requested in volume modifications across Cold HDD (sc1) volumes in this Region. | 
| Storage modifications for General Purpose SSD (gp2) volumes, in TiB | Each supported Region: 500 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ebs/quotas/L-F06E64A8)  | The maximum aggregated amount of storage, in TiB, that can be requested in volume modifications across General Purpose SSD (gp2) volumes in this Region. | 
| Storage modifications for General Purpose SSD (gp3) volumes, in TiB | Each supported Region: 500 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ebs/quotas/L-59C8FC87)  | The maximum aggregated amount of storage, in TiB, that can be requested in volume modifications across General Purpose SSD (gp3) volumes in this Region. | 
| Storage modifications for Magnetic (standard) volumes, in TiB | Each supported Region: 500 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ebs/quotas/L-B9F7C487)  | The maximum aggregated amount of storage, in TiB, that can be requested in volume modifications across Magnetic (standard) volumes in this Region. | 
| Storage modifications for Provisioned IOPS SSD (io1) volumes, in TiB | Each supported Region: 500 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ebs/quotas/L-5F80CA91)  | The maximum aggregated amount of storage, in TiB, that can be requested in volume modifications across Provisioned IOPS SSD (io1) volumes in this Region. | 
| Storage modifications for Provisioned IOPS SSD (io2) volumes, in TiB | Each supported Region: 20 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ebs/quotas/L-9A0E0F82)  | The maximum aggregated amount of storage, in TiB, that can be requested in volume modifications across Provisioned IOPS SSD (io2) volumes in this Region. | 
| Storage modifications for Throughput Optimized HDD (st1) volumes, in TiB | Each supported Region: 500 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ebs/quotas/L-87C9DEA6)  | The maximum aggregated amount of storage, in TiB, that can be requested in volume modifications across Throughput Optimized HDD (st1) volumes in this Region. | 
| Time-based snapshot copy throughput per destination Region | Each supported Region: 2,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ebs/quotas/L-E137849C)  | The maximum account-level throughput, in MiB/sec, for time-based snapshot copy operations per destination Region. | 