
* What Grafana version and what operating system are you using?
Grafana v10.1.5 (849c612fcb)
* **What** are you trying to achieve?
Create anomaly detection bands using Cloudwatch anomaly detection function for Cloudwatch metrics
* **How** are you trying to achieve it?
Tried in two different ways: Using Metrics Insights 
SELECT ANOMALY_DETECTION_BAND(<metric-name>) from "<aws namespace>"
which seems to be limited to only  AVG, COUNT, MAX, MIN, and SUM functions. It gives me metric validation error. 
Also tried with Expression->Math and calling ANOMALY_DETECTION_BAND($A).It gives me Query error 500
* What happened?
 I get "metric request error: \"ValidationError: Error in expression 'query189c3d5142e44f8d9fc8aef2bc745cca': Invalid syntax. 'ANOMALY_DETECTION_BAND' is not a valid aggregate function\\n\\tstatus code: 400, request id: 348c396c-911d-4552-99b7-c6ab86a59988\
* What did you **expect** to happen?
Expected to see two new time series for the upper and lower anomaly detection bands
* Can you copy/paste the configuration(s) that you are having problems with?

* Did you receive any errors in the Grafana UI or in related logs? If so, please tell us **exactly** what they were.
 \"ValidationError: Error in expression 'query189c3d5142e44f8d9fc8aef2bc745cca': Invalid syntax. 'ANOMALY_DETECTION_BAND' is not a valid aggregate function\\n\\tstatus code: 400, request id: 348c396c-911d-4552-99b7-c6ab86a59988\

url:"api/ds/query?ds_type=__expr__&expression=true&requestId=Q167"

method:"POST"

data:Object

requestId:"Q167"

hideFromInspector:false

headers:Object

retry:0

traceId:undefined

message:"Query error: 500 "
* Did you follow any online instructions? If so, what is the URL?
https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/using-metric-math.html
https://grafana.com/docs/grafana/latest/datasources/aws-cloudwatch/query-editor/