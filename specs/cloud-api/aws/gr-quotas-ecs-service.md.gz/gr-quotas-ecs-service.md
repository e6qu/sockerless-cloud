

# Amazon ECS endpoints and quotas
<a name="ecs-service"></a>

To connect programmatically to an AWS service, you use an endpoint. AWS services offer the following endpoint types in some or all of the AWS Regions that the service supports: IPv4 endpoints, dual-stack endpoints, and FIPS endpoints. Some services provide global endpoints. For more information, see [AWS service endpoints](rande.md).

Service quotas, also referred to as limits, are the maximum number of service resources or operations for your AWS account. For more information, see [AWS service quotas](aws_service_limits.md).

The following are the service endpoints and service quotas for this service.

## Service endpoints
<a name="ecs_region"></a>


| Region Name | Region | Endpoint | Protocol | 
| --- | --- | --- | --- | 
| US East (Ohio) | us-east-2 |  ecs.us-east-2.amazonaws.com <br /> ecs-fips.us-east-2.amazonaws.com <br /> ecs-fips.us-east-2.api.aws <br /> ecs.us-east-2.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| US East (N. Virginia) | us-east-1 |  ecs.us-east-1.amazonaws.com <br /> ecs-fips.us-east-1.amazonaws.com <br /> ecs-fips.us-east-1.api.aws <br /> ecs.us-east-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| US West (N. California) | us-west-1 |  ecs.us-west-1.amazonaws.com <br /> ecs-fips.us-west-1.amazonaws.com <br /> ecs-fips.us-west-1.api.aws <br /> ecs.us-west-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| US West (Oregon) | us-west-2 |  ecs.us-west-2.amazonaws.com <br /> ecs-fips.us-west-2.amazonaws.com <br /> ecs-fips.us-west-2.api.aws <br /> ecs.us-west-2.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Africa (Cape Town) | af-south-1 |  ecs.af-south-1.amazonaws.com <br /> ecs.af-south-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Hong Kong) | ap-east-1 |  ecs.ap-east-1.amazonaws.com <br /> ecs.ap-east-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Hyderabad) | ap-south-2 |  ecs.ap-south-2.amazonaws.com <br /> ecs.ap-south-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Jakarta) | ap-southeast-3 |  ecs.ap-southeast-3.amazonaws.com <br /> ecs.ap-southeast-3.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Malaysia) | ap-southeast-5 |  ecs.ap-southeast-5.amazonaws.com  | HTTPS | 
| Asia Pacific (Melbourne) | ap-southeast-4 |  ecs.ap-southeast-4.amazonaws.com <br /> ecs.ap-southeast-4.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Mumbai) | ap-south-1 |  ecs.ap-south-1.amazonaws.com <br /> ecs.ap-south-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (New Zealand) | ap-southeast-6 |  ecs.ap-southeast-6.amazonaws.com <br /> ecs.ap-southeast-6.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Osaka) | ap-northeast-3 |  ecs.ap-northeast-3.amazonaws.com <br /> ecs.ap-northeast-3.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Seoul) | ap-northeast-2 |  ecs.ap-northeast-2.amazonaws.com <br /> ecs.ap-northeast-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Singapore) | ap-southeast-1 |  ecs.ap-southeast-1.amazonaws.com <br /> ecs.ap-southeast-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Sydney) | ap-southeast-2 |  ecs.ap-southeast-2.amazonaws.com <br /> ecs.ap-southeast-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Taipei) | ap-east-2 |  ecs.ap-east-2.amazonaws.com  | HTTPS | 
| Asia Pacific (Thailand) | ap-southeast-7 |  ecs.ap-southeast-7.amazonaws.com  | HTTPS | 
| Asia Pacific (Tokyo) | ap-northeast-1 |  ecs.ap-northeast-1.amazonaws.com <br /> ecs.ap-northeast-1.api.aws  | HTTPS<br />HTTPS | 
| Canada (Central) | ca-central-1 |  ecs.ca-central-1.amazonaws.com <br /> ecs.ca-central-1.api.aws  | HTTPS<br />HTTPS | 
| Canada West (Calgary) | ca-west-1 |  ecs.ca-west-1.amazonaws.com <br /> ecs.ca-west-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Frankfurt) | eu-central-1 |  ecs.eu-central-1.amazonaws.com <br /> ecs.eu-central-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Ireland) | eu-west-1 |  ecs.eu-west-1.amazonaws.com <br /> ecs.eu-west-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (London) | eu-west-2 |  ecs.eu-west-2.amazonaws.com <br /> ecs.eu-west-2.api.aws  | HTTPS<br />HTTPS | 
| Europe (Milan) | eu-south-1 |  ecs.eu-south-1.amazonaws.com <br /> ecs.eu-south-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Paris) | eu-west-3 |  ecs.eu-west-3.amazonaws.com <br /> ecs.eu-west-3.api.aws  | HTTPS<br />HTTPS | 
| Europe (Spain) | eu-south-2 |  ecs.eu-south-2.amazonaws.com <br /> ecs.eu-south-2.api.aws  | HTTPS<br />HTTPS | 
| Europe (Stockholm) | eu-north-1 |  ecs.eu-north-1.amazonaws.com <br /> ecs.eu-north-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Zurich) | eu-central-2 |  ecs.eu-central-2.amazonaws.com <br /> ecs.eu-central-2.api.aws  | HTTPS<br />HTTPS | 
| Israel (Tel Aviv) | il-central-1 |  ecs.il-central-1.amazonaws.com <br /> ecs.il-central-1.api.aws  | HTTPS<br />HTTPS | 
| Mexico (Central) | mx-central-1 |  ecs.mx-central-1.amazonaws.com  | HTTPS | 
| Middle East (Bahrain) | me-south-1 |  ecs.me-south-1.amazonaws.com <br /> ecs.me-south-1.api.aws  | HTTPS<br />HTTPS | 
| Middle East (UAE) | me-central-1 |  ecs.me-central-1.amazonaws.com <br /> ecs.me-central-1.api.aws  | HTTPS<br />HTTPS | 
| South America (São Paulo) | sa-east-1 |  ecs.sa-east-1.amazonaws.com <br /> ecs.sa-east-1.api.aws  | HTTPS<br />HTTPS | 
|  AWS GovCloud (US-East) | us-gov-east-1 |  ecs.us-gov-east-1.amazonaws.com <br /> ecs-fips.us-gov-east-1.amazonaws.com <br /> ecs-fips.us-gov-east-1.api.aws <br /> ecs.us-gov-east-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
|  AWS GovCloud (US-West) | us-gov-west-1 |  ecs.us-gov-west-1.amazonaws.com <br /> ecs-fips.us-gov-west-1.amazonaws.com <br /> ecs-fips.us-gov-west-1.api.aws <br /> ecs.us-gov-west-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 

## Service quotas
<a name="limits_ecs"></a>

The following are Amazon ECS service quotas.

Most of these service quotas, but not all, are listed under the Amazon Elastic Container Service (Amazon ECS) namespace in the Service Quotas console. To request a quota increase, see [Requesting a quota increase](https://docs.aws.amazon.com/servicequotas/latest/userguide/request-increase.html) in the *Service Quotas User Guide*.


| Name | Default | Adjustable | Description | 
| --- | --- | --- | --- | 
| Burst rate of agent modify actions (or bucket maximum capacity) | Each supported Region: 200 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ecs/quotas/L-886BDC21)  | The maximum burst number of requests per second for agent modify actions. | 
| Burst rate of capacity provider modify actions (or bucket maximum capacity) | Each supported Region: 10 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ecs/quotas/L-3E3D55FE)  | The maximum burst number of requests per second for capacity provider modify actions. | 
| Burst rate of capacity provider read actions (or bucket maximum capacity) | Each supported Region: 50 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ecs/quotas/L-5A5FEADE)  | The maximum burst number of requests per second for capacity provider read actions. | 
| Burst rate of cluster modify actions (or bucket maximum capacity) | Each supported Region: 20 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ecs/quotas/L-62DC78F9)  | The maximum burst number of requests per second for cluster modify actions. | 
| Burst rate of cluster read actions (or bucket maximum capacity) | Each supported Region: 50 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ecs/quotas/L-35D944A8)  | The maximum burst number of requests per second for cluster read actions. | 
| Burst rate of cluster resource modify actions (or bucket maximum capacity) | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ecs/quotas/L-3B4FAC68)  | The maximum burst number of requests per second for cluster resource modify actions. | 
| Burst rate of cluster resource read actions (or bucket maximum capacity) | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ecs/quotas/L-281CBA4C)  | The maximum burst number of requests per second for cluster resource read actions. | 
| Burst rate of cluster service resource read actions (or bucket maximum capacity) | Each supported Region: 10 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ecs/quotas/L-424FFC53)  | The maximum burst number of requests per second for cluster service resource read actions. | 
| Burst rate of service deployment read actions (or bucket maximum capacity) | Each supported Region: 50 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ecs/quotas/L-A2AA9478)  | The maximum burst number of requests per second for service deployment and revision read actions. | 
| Burst rate of service modify actions (or bucket maximum capacity) | Each supported Region: 50 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ecs/quotas/L-AA0D4951)  | The maximum burst number of requests per second for service modify actions. | 
| Burst rate of service read actions (or bucket maximum capacity) | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ecs/quotas/L-22AE4B75)  | The maximum burst number of requests per second for service read actions. | 
| Burst rate of setting modify actions (or bucket maximum capacity) | Each supported Region: 10 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ecs/quotas/L-D95BCB5D)  | The maximum burst number of requests per second for setting modify actions. | 
| Burst rate of setting read actions (or bucket maximum capacity) | Each supported Region: 50 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ecs/quotas/L-3CA4FC4A)  | The maximum burst number of requests per second for setting read actions. | 
| Burst rate of tag modify actions (or bucket maximum capacity) | Each supported Region: 20 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ecs/quotas/L-678F155F)  | The maximum burst number of requests per second for tag modify actions. | 
| Burst rate of tag read actions (or bucket maximum capacity) | Each supported Region: 50 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ecs/quotas/L-B4EF2B3D)  | The maximum burst number of requests per second for tag read actions. | 
| Burst rate of task definition deletion actions (or bucket maximum capacity) | Each supported Region: 5 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ecs/quotas/L-9383BF97)  | The maximum burst number of requests per second for task definition deletion actions. | 
| Burst rate of task definition modify actions (or bucket maximum capacity) | Each supported Region: 20 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ecs/quotas/L-CDF9F16B)  | The maximum burst number of requests per second for task definition modify actions. | 
| Burst rate of task definition read actions (or bucket maximum capacity) | Each supported Region: 50 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ecs/quotas/L-924E3D47)  | The maximum burst number of requests per second for task definition read actions. | 
| Burst rate of task protection read actions (or bucket maximum capacity) | Each supported Region: 200 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ecs/quotas/L-660A3A36)  | The maximum burst number of requests per second for task protection read actions. | 
| Burst rate of task protection write actions (or bucket maximum capacity) | Each supported Region: 200 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ecs/quotas/L-A04BC52C)  | The maximum burst number of requests per second for task protection write actions. | 
| Burst rate of task set modify actions (or bucket maximum capacity) | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ecs/quotas/L-B45594D8)  | The maximum burst number of requests per second for task set modify actions. | 
| Capacity providers per cluster | Each supported Region: 20 | No | The maximum number of capacity providers that can be associated with a cluster. | 
| Classic Load Balancers per service | Each supported Region: 1 | No | The maximum number of Classic Load Balancers per service. | 
| Clusters per account | Each supported Region: 10,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ecs/quotas/L-21C621EB)  | Number of clusters per account | 
| Container instances per cluster | Each supported Region: 5,000 | No | Number of container instances per cluster | 
| Container instances per start-task | Each supported Region: 10 | No | The maximum number of container instances specified in a StartTask API action. | 
| Containers per task definition | Each supported Region: 10 | No | The maximum number of containers definitions within a task definition. | 
| ECS Exec sessions | Each supported Region: 1,000 | No | The maximum number of ECS Exec sessions per container. | 
| Rate of tasks launched by a service on AWS Fargate | af-south-1: 125<br />ap-east-1: 125<br />ap-east-2: 125<br />ap-northeast-3: 125<br />ap-south-2: 125<br />ap-southeast-3: 125<br />ap-southeast-4: 125<br />ap-southeast-5: 125<br />ap-southeast-6: 125<br />ap-southeast-7: 125<br />ca-west-1: 125<br />eu-central-2: 125<br />eu-south-1: 125<br />eu-south-2: 125<br />il-central-1: 125<br />mx-central-1: 125<br />Each of the other supported Regions: 500 | No | The maximum number of tasks that can be provisioned per service per minute on Fargate by the Amazon ECS service scheduler. Note: For Regions introduced after May 20, 2025, the maximum is 125 | 
| Rate of tasks launched by a service on an Amazon EC2 or External instance | Each supported Region: 500 | No | The maximum number of tasks that can be provisioned per service per minute on an Amazon EC2 or External instance by the Amazon ECS service scheduler. | 
| Revisions per task definition family | Each supported Region: 1,000,000 | No | The maximum number of revisions per task definition family. Deregistering or deleting a task definition revision does not exclude it from being included in this limit. | 
| Security groups per awsvpcConfiguration | Each supported Region: 5 | No | The maximum number of security groups specified within an awsvpcConfiguration. | 
| Services per cluster | Each supported Region: 5,000 | No | The maximum number of services per cluster | 
| Services per namespace | Each supported Region: 300 | No | The maximum number of services that can be running within a namespace. | 
| Subnets per awsvpcConfiguration | Each supported Region: 16 | No | The maximum number of subnets specified within an awsvpcConfiguration. | 
| Sustained rate of agent modify actions (or bucket refill rate) | Each supported Region: 120 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ecs/quotas/L-553993D4)  | The maximum sustained number of requests per second for agent modify actions. | 
| Sustained rate of capacity provider modify actions (or bucket refill rate) | Each supported Region: 1 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ecs/quotas/L-A9E5EB0F)  | The maximum sustained number of requests per second for capacity provider modify actions. | 
| Sustained rate of capacity provider read actions (or bucket refill rate) | Each supported Region: 20 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ecs/quotas/L-42E25F2A)  | The maximum sustained number of requests per second for capacity provider read actions. | 
| Sustained rate of cluster modify actions (or bucket refill rate) | Each supported Region: 1 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ecs/quotas/L-D5AA0F33)  | The maximum sustained number of requests per second for cluster modify actions. | 
| Sustained rate of cluster read actions (or bucket refill rate) | Each supported Region: 20 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ecs/quotas/L-43D4E76A)  | The maximum sustained number of requests per second for cluster read actions. | 
| Sustained rate of cluster resource modify actions (or bucket refill rate) | Each supported Region: 40 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ecs/quotas/L-C3AEE9D2)  | The maximum sustained number of requests per second for cluster resource modify actions. | 
| Sustained rate of cluster resource read actions (or bucket refill rate) | Each supported Region: 20 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ecs/quotas/L-80627E8A)  | The maximum sustained number of requests per second for cluster resource read actions. | 
| Sustained rate of cluster service resource read actions (or bucket refill rate) | Each supported Region: 1 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ecs/quotas/L-64FE0575)  | The maximum sustained number of requests per second for cluster service resource read actions. | 
| Sustained rate of service deployment read actions (or bucket refill rate) | Each supported Region: 20 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ecs/quotas/L-A2DBEAC1)  | The maximum sustained number of requests per second for service deployment and revision read actions. | 
| Sustained rate of service modify actions (or bucket refill rate) | Each supported Region: 5 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ecs/quotas/L-C5297B3A)  | The maximum sustained number of requests per second for service modify actions. | 
| Sustained rate of service read actions (or bucket refill rate) | Each supported Region: 20 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ecs/quotas/L-321A0372)  | The maximum sustained number of requests per second for service read actions. | 
| Sustained rate of setting modify actions (or bucket refill rate) | Each supported Region: 1 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ecs/quotas/L-40D1D4C5)  | The maximum sustained number of requests per second for setting modify actions. | 
| Sustained rate of setting read actions (or bucket refill rate) | Each supported Region: 20 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ecs/quotas/L-CA95243C)  | The maximum sustained number of requests per second for setting read actions. | 
| Sustained rate of tag modify actions (or bucket refill rate) | Each supported Region: 10 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ecs/quotas/L-8F66404D)  | The maximum sustained number of requests per second for tag modify actions. | 
| Sustained rate of tag read actions (or bucket refill rate) | Each supported Region: 20 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ecs/quotas/L-9440138C)  | The maximum sustained number of requests per second for tag read actions. | 
| Sustained rate of task definition deletion actions (or bucket refill rate) | Each supported Region: 1 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ecs/quotas/L-29793C9D)  | The maximum sustained number of requests per second for task definition deletion actions. | 
| Sustained rate of task definition modify actions (or bucket refill rate) | Each supported Region: 1 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ecs/quotas/L-1E6DEB89)  | The maximum sustained number of requests per second for task definition modify actions. | 
| Sustained rate of task definition read actions (or bucket refill rate) | Each supported Region: 20 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ecs/quotas/L-538D7426)  | The maximum sustained number of requests per second for task definition read actions. | 
| Sustained rate of task protection read actions (or bucket refill rate) | Each supported Region: 80 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ecs/quotas/L-A8AC1C0F)  | The maximum sustained number of requests per second for task protection read actions. | 
| Sustained rate of task protection write actions (or bucket refill rate) | Each supported Region: 80 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ecs/quotas/L-C26103FB)  | The maximum sustained number of requests per second for task protection write actions. | 
| Sustained rate of task set modify actions (or bucket refill rate) | Each supported Region: 20 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/ecs/quotas/L-4C90BDD4)  | The maximum sustained number of requests per second for task set modify actions. | 
| Tags per resource | Each supported Region: 50 | No | The maximum number of tags per resource. This applies to task definitions, clusters, tasks, and services. | 
| Target groups per service | Each supported Region: 5 | No | The maximum number of target groups per service, if using an Application Load Balancer or a Network Load Balancer. | 
| Task definition size | Each supported Region: 64 Kilobytes | No | The maximum size, in KiB, of a task definition. | 
| Tasks in PROVISIONING state per cluster | Each supported Region: 500 | No | The maximum number of tasks waiting in the PROVISIONING state per cluster. This quota only applies to tasks launched using an EC2 Auto Scaling group capacity provider. | 
| Tasks launched per run-task | Each supported Region: 10 | No | The maximum number of tasks that can be launched per RunTask API action. | 
| Tasks per service | Each supported Region: 5,000 | No | The maximum number of tasks per service (the desired count). | 

**Note**  
<a name="service-quotas-ecs-note-1"></a>Services configured to use Amazon ECS service discovery have a limit of 1,000 tasks per service. This is due to the AWS Cloud Map service quota for the number of instances per service. For more information, see [AWS Cloud Map service quotas](https://docs.aws.amazon.com/general/latest/gr/cloud_map.html) in the *Amazon Web Services General Reference*.

**Note**  
<a name="service-quotas-ecs-note-2"></a>In practice, task launch rates are also dependent on other considerations such as container images to be downloaded and unpacked, health checks and other integrations enabled, such as registering tasks with a load balancer. You will see variations in task launch rates compared with the quotas represented above based on the features that you have enabled for your Amazon ECS services. For more information, see [speeding up Amazon ECS deployments](https://docs.aws.amazon.com/AmazonECS/latest/bestpracticesguide/deployment.html) in the Amazon ECS Best Practices Guide.

## AWS Fargate quotas
<a name="service-quotas-fargate"></a>

The following are Amazon ECS on AWS Fargate service quotas and are listed under the **AWS Fargate** service in the Service Quotas console.

New AWS accounts might have initial lower quotas that can increase over time. Fargate constantly monitors the account usage within each Region, and then automatically increases the quotas based on your usage. You can also request a quota increase for values that are shown as adjustable, see [Requesting a quota increase](https://docs.aws.amazon.com/servicequotas/latest/userguide/request-increase.html) in the *Service Quotas User Guide*.


| Name | Default | Adjustable | Description | 
| --- | --- | --- | --- | 
| Fargate On-Demand Burst Launch Rate | af-south-1: 25<br />ap-east-1: 25<br />ap-east-2: 25<br />ap-northeast-3: 25<br />ap-south-2: 25<br />ap-southeast-3: 25<br />ap-southeast-4: 25<br />ap-southeast-5: 25<br />ap-southeast-6: 25<br />ap-southeast-7: 25<br />ca-west-1: 25<br />eu-central-2: 25<br />eu-south-1: 25<br />eu-south-2: 25<br />il-central-1: 25<br />mx-central-1: 25<br />Each of the other supported Regions: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/fargate/quotas/L-6BAD92DD)  | The maximum number of on-demand Amazon ECS tasks or Amazon EKS pods launched in a single burst (burst rate) in this account in the current region. Note: For Regions introduced after May 20, 2025, the maximum is 25 | 
| Fargate On-Demand Sustained Launch Rate | af-south-1: 5<br />ap-east-1: 5<br />ap-east-2: 5<br />ap-northeast-3: 5<br />ap-south-2: 5<br />ap-southeast-3: 5<br />ap-southeast-4: 5<br />ap-southeast-5: 5<br />ap-southeast-6: 5<br />ap-southeast-7: 5<br />ca-west-1: 5<br />eu-central-2: 5<br />eu-south-1: 5<br />eu-south-2: 5<br />il-central-1: 5<br />mx-central-1: 5<br />Each of the other supported Regions: 20 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/fargate/quotas/L-551A4E9D)  | The maximum number of on-demand Amazon ECS tasks or Amazon EKS pods launched per second (sustained rate) in this account in the current region. Note: For Regions introduced after May 20, 2025, the maximum is 5 | 
| Fargate On-Demand vCPU resource count | Each supported Region: 6 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/fargate/quotas/L-3032A538)  | The number of Fargate vCPUs running concurrently as Fargate On-Demand in this account in the current Region. | 
| Fargate Spot Burst Launch Rate | af-south-1: 25<br />ap-east-1: 25<br />ap-east-2: 25<br />ap-northeast-3: 25<br />ap-south-2: 25<br />ap-southeast-3: 25<br />ap-southeast-4: 25<br />ap-southeast-5: 25<br />ap-southeast-6: 25<br />ap-southeast-7: 25<br />ca-west-1: 25<br />eu-central-2: 25<br />eu-south-1: 25<br />eu-south-2: 25<br />il-central-1: 25<br />mx-central-1: 25<br />Each of the other supported Regions: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/fargate/quotas/L-F6E37E82)  | The maximum number of Spot Amazon ECS tasks launched in a single burst (burst rate) in this account in the current region. Note: For Regions introduced after May 20, 2025, the maximum is 25 | 
| Fargate Spot Sustained Launch Rate | af-south-1: 5<br />ap-east-1: 5<br />ap-east-2: 5<br />ap-northeast-3: 5<br />ap-south-2: 5<br />ap-southeast-3: 5<br />ap-southeast-4: 5<br />ap-southeast-5: 5<br />ap-southeast-6: 5<br />ap-southeast-7: 5<br />ca-west-1: 5<br />eu-central-2: 5<br />eu-south-1: 5<br />eu-south-2: 5<br />il-central-1: 5<br />mx-central-1: 5<br />Each of the other supported Regions: 20 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/fargate/quotas/L-FAA52651)  | The maximum number of Spot Amazon ECS tasks launched per second (sustained rate) in this account in the current region. Note: For Regions introduced after May 20, 2025, the maximum is 5 | 
| Fargate Spot vCPU resource count | Each supported Region: 6 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/fargate/quotas/L-36FBB829)  | The number of Fargate vCPUs running concurrently as Fargate Spot in this account in the current Region. | 

**Note**  
The default values are the initial quotas set by AWS, which are separate from the actual applied quota value and maximum possible service quota. For more information, see [Terminology in Service Quotas](https://docs.aws.amazon.com/servicequotas/latest/userguide/intro.html#intro_getting-started) in the *Service Quotas User Guide*.

**Note**  
Fargate additionally enforces Amazon ECS tasks and Amazon EKS pods launch rate limits. For more information, see [AWS Fargate throttling quotas](https://docs.aws.amazon.com/AmazonECS/latest/developerguide/throttling.html) in the *Amazon ECS Developer Guide*.