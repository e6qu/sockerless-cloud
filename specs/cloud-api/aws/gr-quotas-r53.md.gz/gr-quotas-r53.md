

# Amazon Route 53 endpoints and quotas
<a name="r53"></a>

To connect programmatically to an AWS service, you use an endpoint. AWS services offer the following endpoint types in some or all of the AWS Regions that the service supports: IPv4 endpoints, dual-stack endpoints, and FIPS endpoints. Some services provide global endpoints. For more information, see [AWS service endpoints](rande.md).

Service quotas, also referred to as limits, are the maximum number of service resources or operations for your AWS account. For more information, see [AWS service quotas](aws_service_limits.md).

The following are the service endpoints and service quotas for this service.

## Service endpoints
<a name="r53_region"></a>

### Hosted zones, records, health checks, DNS query logs, reusable delegation sets, traffic policies, and cost allocation tags
<a name="r53_region_hosted_zones"></a>

When you use the **AWS CLI or SDKs** to submit requests, you can either leave the Region and endpoint unspecified, or specify the applicable Region:
+ Route 53 in AWS Regions other than the Beijing and Ningxia Regions: specify us-east-1 as the Region.
+ Route 53 in the Beijing and Ningxia Regions: specify cn-northwest-1.

When you use the **Route 53 API** to submit requests, use the same Regions as above to sign requests. The IPv4 service endpoint is route53.amazonaws.com and the dual-stack service endpoint is route53.global.api.aws.


| Region Name | Region | Endpoint | Protocol | 
| --- | --- | --- | --- | 
| US East (Ohio) | us-east-2 |  route53.amazonaws.com  | HTTPS | 
| US East (N. Virginia) | us-east-1 |  route53.amazonaws.com  | HTTPS | 
| US West (N. California) | us-west-1 |  route53.amazonaws.com  | HTTPS | 
| US West (Oregon) | us-west-2 |  route53.amazonaws.com  | HTTPS | 
| Africa (Cape Town) | af-south-1 |  route53.amazonaws.com  | HTTPS | 
| Asia Pacific (Hong Kong) | ap-east-1 |  route53.amazonaws.com  | HTTPS | 
| Asia Pacific (Hyderabad) | ap-south-2 |  route53.amazonaws.com  | HTTPS | 
| Asia Pacific (Jakarta) | ap-southeast-3 |  route53.amazonaws.com  | HTTPS | 
| Asia Pacific (Malaysia) | ap-southeast-5 |  route53.amazonaws.com  | HTTPS | 
| Asia Pacific (Melbourne) | ap-southeast-4 |  route53.amazonaws.com  | HTTPS | 
| Asia Pacific (Mumbai) | ap-south-1 |  route53.amazonaws.com  | HTTPS | 
| Asia Pacific (New Zealand) | ap-southeast-6 |  route53.amazonaws.com  | HTTPS | 
| Asia Pacific (Osaka) | ap-northeast-3 |  route53.amazonaws.com  | HTTPS | 
| Asia Pacific (Seoul) | ap-northeast-2 |  route53.amazonaws.com  | HTTPS | 
| Asia Pacific (Singapore) | ap-southeast-1 |  route53.amazonaws.com  | HTTPS | 
| Asia Pacific (Sydney) | ap-southeast-2 |  route53.amazonaws.com  | HTTPS | 
| Asia Pacific (Taipei) | ap-east-2 |  route53.amazonaws.com  | HTTPS | 
| Asia Pacific (Thailand) | ap-southeast-7 |  route53.amazonaws.com  | HTTPS | 
| Asia Pacific (Tokyo) | ap-northeast-1 |  route53.amazonaws.com  | HTTPS | 
| Canada (Central) | ca-central-1 |  route53.amazonaws.com  | HTTPS | 
| Canada West (Calgary) | ca-west-1 |  route53.amazonaws.com  | HTTPS | 
| Europe (Frankfurt) | eu-central-1 |  route53.amazonaws.com  | HTTPS | 
| Europe (Ireland) | eu-west-1 |  route53.amazonaws.com  | HTTPS | 
| Europe (London) | eu-west-2 |  route53.amazonaws.com  | HTTPS | 
| Europe (Milan) | eu-south-1 |  route53.amazonaws.com  | HTTPS | 
| Europe (Paris) | eu-west-3 |  route53.amazonaws.com  | HTTPS | 
| Europe (Spain) | eu-south-2 |  route53.amazonaws.com  | HTTPS | 
| Europe (Stockholm) | eu-north-1 |  route53.amazonaws.com  | HTTPS | 
| Europe (Zurich) | eu-central-2 |  route53.amazonaws.com  | HTTPS | 
| Israel (Tel Aviv) | il-central-1 |  route53.amazonaws.com  | HTTPS | 
| Mexico (Central) | mx-central-1 |  route53.amazonaws.com  | HTTPS | 
| Middle East (Bahrain) | me-south-1 |  route53.amazonaws.com  | HTTPS | 
| Middle East (UAE) | me-central-1 |  route53.amazonaws.com  | HTTPS | 
| South America (São Paulo) | sa-east-1 |  route53.amazonaws.com  | HTTPS | 
|  AWS GovCloud (US-East) | us-gov-east-1 |  route53.us-gov.amazonaws.com  | HTTPS | 
|  AWS GovCloud (US-West) | us-gov-west-1 |  route53.us-gov.amazonaws.com  | HTTPS | 

### Requests for domain registration
<a name="r53_region_domain_registration"></a>


| Region Name | Region | Endpoint | Protocol | 
| --- | --- | --- | --- | 
| US East (N. Virginia) | us-east-1 |  route53domains.us-east-1.amazonaws.com  | HTTPS | 

### Requests for Route 53 Resolver
<a name="r53_region_resolver"></a>


| Region Name | Region | Endpoint | Protocol | 
| --- | --- | --- | --- | 
| US East (Ohio) | us-east-2 |  route53resolver.us-east-2.amazonaws.com  | HTTPS | 
| US East (N. Virginia) | us-east-1 |  route53resolver.us-east-1.amazonaws.com  | HTTPS | 
| US West (N. California) | us-west-1 |  route53resolver.us-west-1.amazonaws.com  | HTTPS | 
| US West (Oregon) | us-west-2 |  route53resolver.us-west-2.amazonaws.com  | HTTPS | 
| Africa (Cape Town) | af-south-1 |  route53resolver.af-south-1.amazonaws.com  | HTTPS | 
| Asia Pacific (Hong Kong) | ap-east-1 |  route53resolver.ap-east-1.amazonaws.com  | HTTPS | 
| Asia Pacific (Hyderabad) | ap-south-2 |  route53resolver.ap-south-2.amazonaws.com  | HTTPS | 
| Asia Pacific (Jakarta) | ap-southeast-3 |  route53resolver.ap-southeast-3.amazonaws.com  | HTTPS | 
| Asia Pacific (Malaysia) | ap-southeast-5 |  route53resolver.ap-southeast-5.amazonaws.com  | HTTPS | 
| Asia Pacific (Melbourne) | ap-southeast-4 |  route53resolver.ap-southeast-4.amazonaws.com  | HTTPS | 
| Asia Pacific (Mumbai) | ap-south-1 |  route53resolver.ap-south-1.amazonaws.com  | HTTPS | 
| Asia Pacific (New Zealand) | ap-southeast-6 |  route53resolver.ap-southeast-6.amazonaws.com  | HTTPS | 
| Asia Pacific (Osaka) | ap-northeast-3 |  route53resolver.ap-northeast-3.amazonaws.com  | HTTPS | 
| Asia Pacific (Seoul) | ap-northeast-2 |  route53resolver.ap-northeast-2.amazonaws.com  | HTTPS | 
| Asia Pacific (Singapore) | ap-southeast-1 |  route53resolver.ap-southeast-1.amazonaws.com  | HTTPS | 
| Asia Pacific (Sydney) | ap-southeast-2 |  route53resolver.ap-southeast-2.amazonaws.com  | HTTPS | 
| Asia Pacific (Taipei) | ap-east-2 |  route53resolver.ap-east-2.amazonaws.com  | HTTPS | 
| Asia Pacific (Thailand) | ap-southeast-7 |  route53resolver.ap-southeast-7.amazonaws.com  | HTTPS | 
| Asia Pacific (Tokyo) | ap-northeast-1 |  route53resolver.ap-northeast-1.amazonaws.com  | HTTPS | 
| Canada (Central) | ca-central-1 |  route53resolver.ca-central-1.amazonaws.com  | HTTPS | 
| Canada West (Calgary) | ca-west-1 |  route53resolver.ca-west-1.amazonaws.com  | HTTPS | 
| Europe (Frankfurt) | eu-central-1 |  route53resolver.eu-central-1.amazonaws.com  | HTTPS | 
| Europe (Ireland) | eu-west-1 |  route53resolver.eu-west-1.amazonaws.com  | HTTPS | 
| Europe (London) | eu-west-2 |  route53resolver.eu-west-2.amazonaws.com  | HTTPS | 
| Europe (Milan) | eu-south-1 |  route53resolver.eu-south-1.amazonaws.com  | HTTPS | 
| Europe (Paris) | eu-west-3 |  route53resolver.eu-west-3.amazonaws.com  | HTTPS | 
| Europe (Spain) | eu-south-2 |  route53resolver.eu-south-2.amazonaws.com  | HTTPS | 
| Europe (Stockholm) | eu-north-1 |  route53resolver.eu-north-1.amazonaws.com  | HTTPS | 
| Europe (Zurich) | eu-central-2 |  route53resolver.eu-central-2.amazonaws.com  | HTTPS | 
| Israel (Tel Aviv) | il-central-1 |  route53resolver.il-central-1.amazonaws.com  | HTTPS | 
| Mexico (Central) | mx-central-1 |  route53resolver.mx-central-1.amazonaws.com  | HTTPS | 
| Middle East (Bahrain) | me-south-1 |  route53resolver.me-south-1.amazonaws.com  | HTTPS | 
| Middle East (UAE) | me-central-1 |  route53resolver.me-central-1.amazonaws.com  | HTTPS | 
| South America (São Paulo) | sa-east-1 |  route53resolver.sa-east-1.amazonaws.com  | HTTPS | 
|  AWS GovCloud (US-East) | us-gov-east-1 |  route53resolver.us-gov-east-1.amazonaws.com  | HTTPS | 
|  AWS GovCloud (US-West) | us-gov-west-1 |  route53resolver.us-gov-west-1.amazonaws.com  | HTTPS | 

### Requests for Route 53 Global Resolver
<a name="r53_region_global_resolver"></a>


| Region Name | Region | Endpoint | Protocol | 
| --- | --- | --- | --- | 
| US East (Ohio) | us-east-2 | route53globalresolver.us-east-2.api.aws<br />route53globalresolver-fips.us-east-2.api.aws | HTTPS<br />HTTPS | 

### Requests for Route 53 Profiles
<a name="r53_region_r53-profiles"></a>


| Region Name | Region | Endpoint | Protocol | 
| --- | --- | --- | --- | 
| US East (Ohio) | us-east-2 |  route53profiles.us-east-2.amazonaws.com <br /> route53profiles-fips.us-east-2.api.aws <br /> route53profiles.us-east-2.api.aws  | HTTPS<br />HTTPS<br />HTTPS | 
| US East (N. Virginia) | us-east-1 |  route53profiles.us-east-1.amazonaws.com <br /> route53profiles-fips.us-east-1.api.aws <br /> route53profiles.us-east-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS | 
| US West (N. California) | us-west-1 |  route53profiles.us-west-1.amazonaws.com <br /> route53profiles-fips.us-west-1.api.aws <br /> route53profiles.us-west-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS | 
| US West (Oregon) | us-west-2 |  route53profiles.us-west-2.amazonaws.com <br /> route53profiles-fips.us-west-2.api.aws <br /> route53profiles.us-west-2.api.aws  | HTTPS<br />HTTPS<br />HTTPS | 
| Africa (Cape Town) | af-south-1 |  route53profiles.af-south-1.amazonaws.com <br /> route53profiles.af-south-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Hong Kong) | ap-east-1 |  route53profiles.ap-east-1.amazonaws.com <br /> route53profiles.ap-east-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Hyderabad) | ap-south-2 |  route53profiles.ap-south-2.amazonaws.com <br /> route53profiles.ap-south-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Jakarta) | ap-southeast-3 |  route53profiles.ap-southeast-3.amazonaws.com <br /> route53profiles.ap-southeast-3.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Malaysia) | ap-southeast-5 |  route53profiles.ap-southeast-5.amazonaws.com <br /> route53profiles.ap-southeast-5.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Melbourne) | ap-southeast-4 |  route53profiles.ap-southeast-4.amazonaws.com <br /> route53profiles.ap-southeast-4.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Mumbai) | ap-south-1 |  route53profiles.ap-south-1.amazonaws.com <br /> route53profiles.ap-south-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (New Zealand) | ap-southeast-6 |  route53profiles.ap-southeast-6.amazonaws.com <br /> route53profiles.ap-southeast-6.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Osaka) | ap-northeast-3 |  route53profiles.ap-northeast-3.amazonaws.com <br /> route53profiles.ap-northeast-3.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Seoul) | ap-northeast-2 |  route53profiles.ap-northeast-2.amazonaws.com <br /> route53profiles.ap-northeast-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Singapore) | ap-southeast-1 |  route53profiles.ap-southeast-1.amazonaws.com <br /> route53profiles.ap-southeast-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Sydney) | ap-southeast-2 |  route53profiles.ap-southeast-2.amazonaws.com <br /> route53profiles.ap-southeast-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Taipei) | ap-east-2 |  route53profiles.ap-east-2.amazonaws.com <br /> route53profiles.ap-east-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Thailand) | ap-southeast-7 |  route53profiles.ap-southeast-7.amazonaws.com <br /> route53profiles.ap-southeast-7.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Tokyo) | ap-northeast-1 |  route53profiles.ap-northeast-1.amazonaws.com <br /> route53profiles.ap-northeast-1.api.aws  | HTTPS<br />HTTPS | 
| Canada (Central) | ca-central-1 |  route53profiles.ca-central-1.amazonaws.com <br /> route53profiles-fips.ca-central-1.api.aws <br /> route53profiles.ca-central-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS | 
| Canada West (Calgary) | ca-west-1 |  route53profiles.ca-west-1.amazonaws.com <br /> route53profiles.ca-west-1.api.aws <br /> route53profiles-fips.ca-west-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS | 
| Europe (Frankfurt) | eu-central-1 |  route53profiles.eu-central-1.amazonaws.com <br /> route53profiles.eu-central-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Ireland) | eu-west-1 |  route53profiles.eu-west-1.amazonaws.com <br /> route53profiles.eu-west-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (London) | eu-west-2 |  route53profiles.eu-west-2.amazonaws.com <br /> route53profiles.eu-west-2.api.aws  | HTTPS<br />HTTPS | 
| Europe (Milan) | eu-south-1 |  route53profiles.eu-south-1.amazonaws.com <br /> route53profiles.eu-south-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Paris) | eu-west-3 |  route53profiles.eu-west-3.amazonaws.com <br /> route53profiles.eu-west-3.api.aws  | HTTPS<br />HTTPS | 
| Europe (Spain) | eu-south-2 |  route53profiles.eu-south-2.amazonaws.com <br /> route53profiles.eu-south-2.api.aws  | HTTPS<br />HTTPS | 
| Europe (Stockholm) | eu-north-1 |  route53profiles.eu-north-1.amazonaws.com <br /> route53profiles.eu-north-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Zurich) | eu-central-2 |  route53profiles.eu-central-2.amazonaws.com <br /> route53profiles.eu-central-2.api.aws  | HTTPS<br />HTTPS | 
| Israel (Tel Aviv) | il-central-1 |  route53profiles.il-central-1.amazonaws.com <br /> route53profiles.il-central-1.api.aws  | HTTPS<br />HTTPS | 
| Mexico (Central) | mx-central-1 |  route53profiles.mx-central-1.amazonaws.com <br /> route53profiles.mx-central-1.api.aws  | HTTPS<br />HTTPS | 
| Middle East (Bahrain) | me-south-1 |  route53profiles.me-south-1.amazonaws.com <br /> route53profiles.me-south-1.api.aws  | HTTPS<br />HTTPS | 
| Middle East (UAE) | me-central-1 |  route53profiles.me-central-1.amazonaws.com <br /> route53profiles.me-central-1.api.aws  | HTTPS<br />HTTPS | 
| South America (São Paulo) | sa-east-1 |  route53profiles.sa-east-1.amazonaws.com <br /> route53profiles.sa-east-1.api.aws  | HTTPS<br />HTTPS | 
|  AWS GovCloud (US-East) | us-gov-east-1 |  route53profiles.us-gov-east-1.amazonaws.com <br /> route53profiles.us-gov-east-1.api.aws <br /> route53profiles-fips.us-gov-east-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS | 
|  AWS GovCloud (US-West) | us-gov-west-1 |  route53profiles.us-gov-west-1.amazonaws.com <br /> route53profiles-fips.us-gov-west-1.api.aws <br /> route53profiles.us-gov-west-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS | 

### Requests for Route 53 auto naming
<a name="r53_region_cloud_map"></a>

Amazon Route 53 auto naming has been released as a separate service, AWS Cloud Map. For a list of service endpoints, see [Service endpoints](cloud_map.md#cloud_map_region). For AWS Cloud Map documentation, see [AWS Cloud Map Documentation](https://docs.aws.amazon.com/cloud-map/index.html). 

## Service quotas
<a name="limits_route53"></a>

The following are the service quotas for Route 53


| Name | Default | Adjustable | Description | 
| --- | --- | --- | --- | 
| Amazon VPCs that you can associate with a private hosted zone | Each supported Region: 300 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/route53/quotas/L-84B40094)  | The maximum number of Amazon VPCs that you can associate with a private hosted zone | 
| CIDR blocks per collection | Each supported Region: 1,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/route53/quotas/L-945D15E5)  | The maximum number of CIDR blocks that you can create per CIDR collection | 
| CIDR collections | Each supported Region: 5 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/route53/quotas/L-AD61772F)  | The maximum number of CIDR collections that you can create per account | 
| Child health checks that a calculated health check can monitor | Each supported Region: 255 | No | The maximum number of child health checks that a calculated health check can monitor | 
| Domain count limit | Each supported Region: 20 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/route53/quotas/L-F767CB15)  | The maximum number of domains you can register using this account | 
| Health checks | Each supported Region: 200 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/route53/quotas/L-ACB674F3)  | The maximum number of health checks that you can create using this account | 
| Hosted zones | Each supported Region: 500 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/route53/quotas/L-4EA4796A)  | The maximum number of hosted zones that you can create using this account | 
| Hosted zones that can use the same reusable delegation set | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/route53/quotas/L-FF06D527)  | The maximum number of hosted zones that can use the same reusable delegation set | 
| Records per hosted zone | Each supported Region: 10,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/route53/quotas/L-E209CC9F)  | The maximum number of records that you can create in a hosted zone | 
| Reusable delegation sets | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/route53/quotas/L-A72C7724)  | The maximum number of reusable delegation sets that you can create using this account | 
| Traffic flow policies | Each supported Region: 50 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/route53/quotas/L-FC688E7C)  | The maximum number of traffic flow policies that you can create using this account | 
| Traffic flow policy records | Each supported Region: 5 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/route53/quotas/L-628D5A56)  | The maximum number of traffic flow policy records that you can create using this account | 

The following quotas are for Route 53 Resolver.


| Name | Default | Adjustable | Description | 
| --- | --- | --- | --- | 
| Associations between resolver rules and VPCs per AWS Region | Each supported Region: 2,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/route53resolver/quotas/L-94E19253)  | Maximum number of associations between resolver rules and VPCs per AWS Region | 
| DNS Firewall rule group associations per VPC | Each supported Region: 5 | No | The maximum number of DNS Firewall rule groups that you can associate to a VPC. | 
| DNS Firewall rule groups associations to a Route 53 Profile. | Each supported Region: 5 | No | The maximum number of DNS Firewall rule groups that can be associated to a Route 53 Profile. | 
| DNS Firewall rules groups per Region | Each supported Region: 1,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/route53resolver/quotas/L-02CC8B74)  | The maximum number of DNS Firewall rules groups per Region. | 
| Domain lists per account | Each supported Region: 1,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/route53resolver/quotas/L-9FA3C0A4)  | The maximum number of domain lists for an account. | 
| Domains in a file imported from S3 | Each supported Region: 250,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/route53resolver/quotas/L-1B2BDF0A)  | The maximum number of domains that you can import from a single file thats stored in an Amazon S3 bucket. | 
| Domains per account | Each supported Region: 100,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/route53resolver/quotas/L-740A4B31)  | The maximum number of domains that you can specify across all of the domain lists for an account. | 
| IP addresses per resolver endpoint | Each supported Region: 6 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/route53resolver/quotas/L-D2FE9758)  | Maximum number of IP addresses per resolver endpoint | 
| Maximum number of resolver endpoints per AWS Region | Each supported Region: 4 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/route53resolver/quotas/L-4A669CC0)  | Resolver endpoints per AWS Region | 
| Resolver rule associations to a Route 53 Profile. | Each supported Region: 1,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/route53resolver/quotas/L-8B4B9B75)  | The maximum number of Resolver rule associations per Route 53 Profile. | 
| Resolver rules per AWS Region | Each supported Region: 1,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/route53resolver/quotas/L-51D8A1FB)  | Maximum number of resolver rules per AWS Region | 
| Rules in a DNS Firewall rule group | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/route53resolver/quotas/L-F763F4D9)  | The maximum number of rules in a DNS Firewall rule group. | 
| Target IP addresses per resolver rule | Each supported Region: 6 | No | Maximum number of target IP addresses per resolver rule | 

The following quotas are for Route 53 Profiles


| Name | Default | Adjustable | Description | 
| --- | --- | --- | --- | 
| Private hosted zone associations to a Route 53 Profile. | Each supported Region: 5,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/route53profiles/quotas/L-BA3424AB)  | The maximum number of private hosted zones that can be associated to a Route 53 Profile. | 
| Route 53 Profiles per account per Region. | Each supported Region: 5 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/route53profiles/quotas/L-D9B2356C)  | The maximum number of Route 53 Profiles per AWS account per Region. | 
| VPC Endpoint associations to a Route 53 Profile. | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/route53profiles/quotas/L-0B404E57)  | The maximum number of VPC Endpoints that can be associated to a Route 53 Profile. | 
| VPC to Route 53 Profile associations per Region | Each supported Region: 1,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/route53profiles/quotas/L-9BABD1D7)  | The maximum number of VPCs that can be associated to a Route 53 Profile. | 

For more information, see [Route 53 quotas](https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/DNSLimitations.html) in the *Amazon Route 53 Developer Guide*.