* What Grafana version and what operating system are you using?

Grafana v10.4.2 (701c851be7) from Docker image “grafana/grafana-oss:10.4.2”

* **What** are you trying to achieve?

Build an alert rule based on CloudWatch metric `HTTPCode_ELB_5XX_Count` (no data gaps are common)

* **How** are you trying to achieve it?
Following recommendations in https://community.grafana.com/t/how-to-populate-cloudwatch-metric-with-zeros/125950, I'm trying to create an alert rule.

* What happened?

When I build a series in a data source explorer or in a "Time series" visualization, the `FILL()` works well.
![image|687x500](upload://y9UqH4p3n2CzPcq2WJIfSdJIGcU.png)

However, when I try to use the same function while building the alert rule, it doesn't work.

![image|631x500](upload://xXOg7u7pfcvuew1ehOER1MUH6pb.png)

Should I use some other ID instead of `t5xx`? I tried `D` to no avail. Can `FILL()`work at all in the alert rules? I saw in docs a paragraph:

> If you use the expression field to reference another query, like `queryA * 2`, you can’t create an alert rule based on that query.

but honestly, I don't understand if that applies here.

* What did you **expect** to happen?

`FILL(t5xx, 0)` would produce a series with zeroes where t5xx has no values.

* Did you receive any errors in the Grafana UI or in related logs? If so, please tell us **exactly** what they were.

The error was
```
[sse.dataQueryError] failed to execute query [E]: metric request error: "ValidationError: Error in expression 'queryd2a8fefdcf004519a6f2d8edcb28730b': ID 't5xx' not found\n\tstatus code: 400, request id: e1fbdb41-2db1-45b7-b7a0-22b45d0f0fd0"
```

* Did you follow any online instructions? If so, what is the URL?
Mostly used guidance from https://community.grafana.com/t/how-to-populate-cloudwatch-metric-with-zeros/125950 when I successfully graphed a success raio metric.