

# Amazon EventBridge endpoints and quotas
<a name="ev"></a>

To connect programmatically to an AWS service, you use an endpoint. AWS services offer the following endpoint types in some or all of the AWS Regions that the service supports: IPv4 endpoints, dual-stack endpoints, and FIPS endpoints. Some services provide global endpoints. For more information, see [AWS service endpoints](rande.md).

Service quotas, also referred to as limits, are the maximum number of service resources or operations for your AWS account. For more information, see [AWS service quotas](aws_service_limits.md).

The following are the service endpoints and service quotas for this service.

## Service endpoints
<a name="ev_region"></a>


| Region Name | Region | Endpoint | Protocol | 
| --- | --- | --- | --- | 
| US East (Ohio) | us-east-2 |  events.us-east-2.amazonaws.com <br /> events-fips.us-east-2.api.aws <br /> events-fips.us-east-2.amazonaws.com <br /> events.us-east-2.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| US East (N. Virginia) | us-east-1 |  events.us-east-1.amazonaws.com <br /> events-fips.us-east-1.api.aws <br /> events-fips.us-east-1.amazonaws.com <br /> events.us-east-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| US West (N. California) | us-west-1 |  events.us-west-1.amazonaws.com <br /> events-fips.us-west-1.api.aws <br /> events-fips.us-west-1.amazonaws.com <br /> events.us-west-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| US West (Oregon) | us-west-2 |  events.us-west-2.amazonaws.com <br /> events-fips.us-west-2.api.aws <br /> events-fips.us-west-2.amazonaws.com <br /> events.us-west-2.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Africa (Cape Town) | af-south-1 |  events.af-south-1.amazonaws.com <br /> events.af-south-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Hong Kong) | ap-east-1 |  events.ap-east-1.amazonaws.com <br /> events.ap-east-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Hyderabad) | ap-south-2 |  events.ap-south-2.amazonaws.com <br /> events.ap-south-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Jakarta) | ap-southeast-3 |  events.ap-southeast-3.amazonaws.com <br /> events.ap-southeast-3.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Malaysia) | ap-southeast-5 |  events.ap-southeast-5.amazonaws.com <br /> events.ap-southeast-5.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Melbourne) | ap-southeast-4 |  events.ap-southeast-4.amazonaws.com <br /> events.ap-southeast-4.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Mumbai) | ap-south-1 |  events.ap-south-1.amazonaws.com <br /> events.ap-south-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (New Zealand) | ap-southeast-6 |  events.ap-southeast-6.amazonaws.com <br /> events.ap-southeast-6.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Osaka) | ap-northeast-3 |  events.ap-northeast-3.amazonaws.com <br /> events.ap-northeast-3.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Seoul) | ap-northeast-2 |  events.ap-northeast-2.amazonaws.com <br /> events.ap-northeast-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Singapore) | ap-southeast-1 |  events.ap-southeast-1.amazonaws.com <br /> events.ap-southeast-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Sydney) | ap-southeast-2 |  events.ap-southeast-2.amazonaws.com <br /> events.ap-southeast-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Taipei) | ap-east-2 |  events.ap-east-2.amazonaws.com <br /> events.ap-east-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Thailand) | ap-southeast-7 |  events.ap-southeast-7.amazonaws.com <br /> events.ap-southeast-7.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Tokyo) | ap-northeast-1 |  events.ap-northeast-1.amazonaws.com <br /> events.ap-northeast-1.api.aws  | HTTPS<br />HTTPS | 
| Canada (Central) | ca-central-1 |  events.ca-central-1.amazonaws.com <br /> events-fips.ca-central-1.api.aws <br /> events-fips.ca-central-1.amazonaws.com <br /> events.ca-central-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Canada West (Calgary) | ca-west-1 |  events.ca-west-1.amazonaws.com <br /> events-fips.ca-west-1.api.aws <br /> events-fips.ca-west-1.amazonaws.com <br /> events.ca-west-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Europe (Frankfurt) | eu-central-1 |  events.eu-central-1.amazonaws.com <br /> events.eu-central-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Ireland) | eu-west-1 |  events.eu-west-1.amazonaws.com <br /> events.eu-west-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (London) | eu-west-2 |  events.eu-west-2.amazonaws.com <br /> events.eu-west-2.api.aws  | HTTPS<br />HTTPS | 
| Europe (Milan) | eu-south-1 |  events.eu-south-1.amazonaws.com <br /> events.eu-south-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Paris) | eu-west-3 |  events.eu-west-3.amazonaws.com <br /> events.eu-west-3.api.aws  | HTTPS<br />HTTPS | 
| Europe (Spain) | eu-south-2 |  events.eu-south-2.amazonaws.com <br /> events.eu-south-2.api.aws  | HTTPS<br />HTTPS | 
| Europe (Stockholm) | eu-north-1 |  events.eu-north-1.amazonaws.com <br /> events.eu-north-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Zurich) | eu-central-2 |  events.eu-central-2.amazonaws.com <br /> events.eu-central-2.api.aws  | HTTPS<br />HTTPS | 
| Israel (Tel Aviv) | il-central-1 |  events.il-central-1.amazonaws.com <br /> events.il-central-1.api.aws  | HTTPS<br />HTTPS | 
| Mexico (Central) | mx-central-1 |  events.mx-central-1.amazonaws.com <br /> events.mx-central-1.api.aws  | HTTPS<br />HTTPS | 
| Middle East (Bahrain) | me-south-1 |  events.me-south-1.amazonaws.com <br /> events.me-south-1.api.aws  | HTTPS<br />HTTPS | 
| Middle East (UAE) | me-central-1 |  events.me-central-1.amazonaws.com <br /> events.me-central-1.api.aws  | HTTPS<br />HTTPS | 
| South America (São Paulo) | sa-east-1 |  events.sa-east-1.amazonaws.com <br /> events.sa-east-1.api.aws  | HTTPS<br />HTTPS | 
|  AWS GovCloud (US-East) | us-gov-east-1 |  events.us-gov-east-1.amazonaws.com <br /> events.us-gov-east-1.api.aws  | HTTPS<br />HTTPS | 
|  AWS GovCloud (US-West) | us-gov-west-1 |  events.us-gov-west-1.amazonaws.com <br /> events.us-gov-west-1.api.aws  | HTTPS<br />HTTPS | 

## Service quotas
<a name="limits_eventbridge"></a>


| Name | Default | Adjustable | Description | 
| --- | --- | --- | --- | 
| Api destinations | Each supported Region: 3,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/events/quotas/L-FB1C3A6D)  | The maximum number of API destinations per account per Region. | 
| Connections | Each supported Region: 3,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/events/quotas/L-595D6D42)  | The maximum number of connections per account per Region. | 
| CreateEndpoint throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of requests per second for CreateEndpoint API. Additional requests are throttled. | 
| DeleteEndpoint throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of requests per second for DeleteEndpoint API. Additional requests are throttled. | 
| Endpoints | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/events/quotas/L-EAC9A2AC)  | The maximum number of endpoints per account per Region. | 
| Event bus policy size | Each supported Region: 10,240 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/events/quotas/L-FC354966)  | Maximum policy size, in characters. This policy size increases each time you grant access to another account. You can see your current policy and its size by using the DescribeEventBus API. | 
| Event buses | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/events/quotas/L-658A4FD9)  | Maximum event buses per account. | 
| Event pattern size | Each supported Region: 2,048 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/events/quotas/L-664C5505)  | Maximum size of an event pattern, in characters. | 
| Invocations throttle limit in transactions per second | us-east-1: 18,750 per second<br />us-east-2: 4,500 per second<br />us-west-1: 2,250 per second<br />us-west-2: 18,750 per second<br />ap-east-1: 1,100 per second<br />ap-northeast-1: 2,250 per second<br />ap-northeast-2: 1,100 per second<br />ap-south-1: 1,100 per second<br />ap-southeast-1: 2,250 per second<br />ap-southeast-2: 2,250 per second<br />ca-central-1: 1,100 per second<br />eu-central-1: 4,500 per second<br />eu-north-1: 1,100 per second<br />eu-south-2: 4,500 per second<br />eu-west-1: 18,750 per second<br />eu-west-2: 2,250 per second<br />eu-west-3: 1,100 per second<br />sa-east-1: 1,100 per second<br />Each of the other supported Regions: 750 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/events/quotas/L-5540C5E3)  | An invocation is an event matching a rule and being sent on to the rules targets. After the limit is reached, the invocations are throttled; that is, they still happen but they are delayed. | 
| Number of rules | af-south-1: 100<br />eu-south-1: 100<br />Each of the other supported Regions: 300 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/events/quotas/L-244521F2)  | Maximum number of rules an account can have per event bus | 
| PutEvents throttle limit in transactions per second | us-east-1: 10,000 per second<br />us-east-2: 2,400 per second<br />us-west-1: 1,200 per second<br />us-west-2: 10,000 per second<br />ap-east-1: 600 per second<br />ap-northeast-1: 1,200 per second<br />ap-northeast-2: 600 per second<br />ap-south-1: 600 per second<br />ap-southeast-1: 1,200 per second<br />ap-southeast-2: 1,200 per second<br />ca-central-1: 600 per second<br />eu-central-1: 2,400 per second<br />eu-north-1: 600 per second<br />eu-south-2: 2,400 per second<br />eu-west-1: 10,000 per second<br />eu-west-2: 1,200 per second<br />eu-west-3: 600 per second<br />sa-east-1: 600 per second<br />Each of the other supported Regions: 400 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/events/quotas/L-9B653E91)  | Maximum number of requests per second for PutEvents API. Additional requests are throttled. | 
| Rate of invocations per API destination | Each supported Region: 300 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/events/quotas/L-755FD01C)  | The maximum number of invocations per second to send to each API destination endpoint per account per Region. Once the quota is met, future invocations to that API endpoint are throttled. The invocations will still occur, but are delayed. | 
| Targets per rule | Each supported Region: 5 | No | Maximum number of targets that can be associated with a rule | 
| Throttle limit in transactions per second for control plane APIs | Each supported Region: 50 per second | No | Maximum number of requests per second for EventBridge control plane API operations. Additional requests are throttled. | 
| UpdateEndpoint throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of requests per second for UpdateEndpoint API. Additional requests are throttled. | 
| [EventsV2] Combined ingestion throughput and count per Event Group per second | Each supported Region: 1,500 per second | No | The maximum event throughput per Event Group per Second. Counted as the sum of (number of events) \+ (total size of those events in KB) delivered to a given event group within any one-second window. | 
| [EventsV2] Event Buses | Each supported Region: 5 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/events/quotas/L-DF788473)  | The maximum number of V2 Event Buses owned by this account per Region. Does not include buses shared with this account. | 
| [EventsV2] Event Sources | Each supported Region: 200 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/events/quotas/L-D082A4F6)  | The maximum number of Event Sources owned by this account per Region. | 
| [EventsV2] Events per second per custom event bus | Each supported Region: 500,000 per second | No | The maximum number of events per second ingested per custom event bus, counted across all event sources and all accounts the bus is shared with. | 
| [EventsV2] Resource policy size per event bus | Each supported Region: 20,480 Bytes |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/events/quotas/L-5D1D13E3)  | The maximum size, in bytes, of the customer-managed (default) resource policy of a V2 event bus. Policies that AWS Resource Access Manager writes for a shared bus do not count against this quota. | 
| [EventsV2] Subscribers per V2 Event Bus | Each supported Region: 10,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/events/quotas/L-39263BDC)  | The maximum number of Subscribers that can be associated with each V2 Event Bus owned by this account, across all accounts it is shared with. | 