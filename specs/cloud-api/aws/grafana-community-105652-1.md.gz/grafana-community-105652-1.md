* What Grafana version and what operating system are you using?

Grafana v10.1.4 (a676a96d91)
Debian

* **What** are you trying to achieve?

I want to have the EFS bandwidth percent usage thanks to these queries : 
![image|690x190](upload://w9Ei611tlhjhUFuSAOlqBjAaaD3.png)

* **How** are you trying to achieve it?

I have no problem to add the Cloudwatch metrics `PermittedThroughput` and `MeteredIOBytes`, but when I try to set  `(m1/1048576)/PERIOD(m1)` I have an error.
![image|690x112](upload://8D3VmG97RB1yCQQ4ikYXSoYPZVe.png)

Error is : 
"metric request error: \"ValidationError: Error in expression 'queryfb003148d6a3456bb93bcaaf27a40534': Unsupported operand type(s) for PERIOD: '[Array[TimeSeries]]'\\n\\tstatus code: 400, request id: 070e0d09-31f7-4345-8074-d94bd48723ac\""

I have the same error if I try to use function `TIME_SERIES`. I did not try others.

* What happened?

I don't understand why, because if I use another function like SUM, LAST, it works. Moreover in the field there is autocompletion and function `PERIOD` is proposed. All the functions in https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/using-metric-math.html are proposed.

* What did you **expect** to happen?

I want to use the function `PERIOD`

* Can you copy/paste the configuration(s) that you are having problems with?

I can send code if needed, adding attachment is disable for new users :( 

* Did you receive any errors in the Grafana UI or in related logs? If so, please tell us **exactly** what they were.

In UI, I get the error : 
"metric request error: \"ValidationError: Error in expression 'queryfb003148d6a3456bb93bcaaf27a40534': Unsupported operand type(s) for PERIOD: '[Array[TimeSeries]]'\\n\\tstatus code: 400, request id: 070e0d09-31f7-4345-8074-d94bd48723ac\""