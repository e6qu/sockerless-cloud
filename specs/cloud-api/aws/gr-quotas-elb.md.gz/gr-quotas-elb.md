

# Elastic Load Balancing endpoints and quotas
<a name="elb"></a>

To connect programmatically to an AWS service, you use an endpoint. AWS services offer the following endpoint types in some or all of the AWS Regions that the service supports: IPv4 endpoints, dual-stack endpoints, and FIPS endpoints. Some services provide global endpoints. For more information, see [AWS service endpoints](rande.md).

Service quotas, also referred to as limits, are the maximum number of service resources or operations for your AWS account. For more information, see [AWS service quotas](aws_service_limits.md).

The following are the service endpoints and service quotas for this service.

## Service endpoints
<a name="elb_region"></a>


| Region Name | Region | Endpoint | Route 53 Hosted Zone ID (Application Load Balancers, Classic Load Balancers) | Route 53 Hosted Zone ID (Network Load Balancers) | 
| --- | --- | --- | --- | --- | 
| US East (Ohio) | us-east-2 | elasticloadbalancing.us-east-2.amazonaws.com<br />elasticloadbalancing-fips.us-east-2.amazonaws.com | Z3AADJGX6KTTL2 | ZLMOA37VPKANP | 
| US East (N. Virginia) | us-east-1 | elasticloadbalancing.us-east-1.amazonaws.com<br />elasticloadbalancing-fips.us-east-1.amazonaws.com | Z35SXDOTRQ7X7K | Z26RNL4JYFTOTI | 
| US West (N. California) | us-west-1 | elasticloadbalancing.us-west-1.amazonaws.com<br />elasticloadbalancing-fips.us-west-1.amazonaws.com | Z368ELLRRE2KJ0 | Z24FKFUX50B4VW | 
| US West (Oregon) | us-west-2 | elasticloadbalancing.us-west-2.amazonaws.com<br />elasticloadbalancing-fips.us-west-2.amazonaws.com | Z1H1FL5HABSF5 | Z18D5FSROUN65G | 
| Africa (Cape Town) | af-south-1 | elasticloadbalancing.af-south-1.amazonaws.com | Z268VQBMOI5EKX | Z203XCE67M25HM | 
| Asia Pacific (Hong Kong) | ap-east-1 | elasticloadbalancing.ap-east-1.amazonaws.com | Z3DQVH9N71FHZ0 | Z12Y7K3UBGUAD1 | 
| Asia Pacific (Hyderabad) | ap-south-2 | elasticloadbalancing.ap-south-2.amazonaws.com | Z0173938T07WNTVAEPZN | Z0711778386UTO08407HT | 
| Asia Pacific (Jakarta) | ap-southeast-3 | elasticloadbalancing.ap-southeast-3.amazonaws.com | Z08888821HLRG5A9ZRTER | Z01971771FYVNCOVWJU1G | 
| Asia Pacific (Malaysia) | ap-southeast-5 | elasticloadbalancing.ap-southeast-5.amazonaws.com | Z06010284QMVVW7WO5J | Z026317210H9ACVTRO6FB | 
| Asia Pacific (Melbourne) | ap-southeast-4 | elasticloadbalancing.ap-southeast-4.amazonaws.com | Z09517862IB2WZLPXG76F | Z01156963G8MIIL7X90IV | 
| Asia Pacific (Mumbai) | ap-south-1 | elasticloadbalancing.ap-south-1.amazonaws.com | ZP97RAFLXTNZK | ZVDDRBQ08TROA | 
| Asia Pacific (New Zealand) | ap-southeast-6 | elasticloadbalancing.ap-southeast-6.amazonaws.com | Z023301818UFJ50CIO0MV | Z01392953RKV2Q3RBP0KU | 
| Asia Pacific (Osaka) | ap-northeast-3 | elasticloadbalancing.ap-northeast-3.amazonaws.com | Z5LXEXXYW11ES | Z1GWIQ4HH19I5X | 
| Asia Pacific (Seoul) | ap-northeast-2 | elasticloadbalancing.ap-northeast-2.amazonaws.com | ZWKZPGTI48KDX | ZIBE1TIR4HY56 | 
| Asia Pacific (Singapore) | ap-southeast-1 | elasticloadbalancing.ap-southeast-1.amazonaws.com | Z1LMS91P8CMLE5 | ZKVM4W9LS7TM | 
| Asia Pacific (Sydney) | ap-southeast-2 | elasticloadbalancing.ap-southeast-2.amazonaws.com | Z1GM3OXH4ZPM65 | ZCT6FZBF4DROD | 
| Asia Pacific (Taipei) | ap-east-2 | elasticloadbalancing.ap-east-2.amazonaws.com | Z02789141MW7T1WBU19PO | Z09176273OC2HWIAUNYW | 
| Asia Pacific (Thailand) | ap-southeast-7 | elasticloadbalancing.ap-southeast-7.amazonaws.com | Z0390008CMBRTHFGWBCB | Z054363131YWATEMWRG5L | 
| Asia Pacific (Tokyo) | ap-northeast-1 | elasticloadbalancing.ap-northeast-1.amazonaws.com | Z14GRHDCWA56QT | Z31USIVHYNEOWT | 
| Canada (Central) | ca-central-1 | elasticloadbalancing.ca-central-1.amazonaws.com | ZQSVJUPU6J1EY | Z2EPGBW3API2WT | 
| Canada West (Calgary) | ca-west-1 | elasticloadbalancing.ca-west-1.amazonaws.com | Z06473681N0SF6OS049SD | Z02754302KBB00W2LKWZ9 | 
| China (Beijing) | cn-north-1 | elasticloadbalancing.cn-north-1.amazonaws.com.cn | Z1GDH35T77C1KE | Z3QFB96KMJ7ED6 | 
| China (Ningxia) | cn-northwest-1 | elasticloadbalancing.cn-northwest-1.amazonaws.com.cn | ZM7IZAIOVVDZF | ZQEIKTCZ8352D | 
| Europe (Frankfurt) | eu-central-1 | elasticloadbalancing.eu-central-1.amazonaws.com | Z215JYRZR1TBD5 | Z3F0SRJ5LGBH90 | 
| Europe (Ireland) | eu-west-1 | elasticloadbalancing.eu-west-1.amazonaws.com | Z32O12XQLNTSW2 | Z2IFOLAFXWLO4F | 
| Europe (London) | eu-west-2 | elasticloadbalancing.eu-west-2.amazonaws.com | ZHURV8PSTC4K8 | ZD4D7Y8KGAS4G | 
| Europe (Milan) | eu-south-1 | elasticloadbalancing.eu-south-1.amazonaws.com | Z3ULH7SSC9OV64 | Z23146JA1KNAFP | 
| Europe (Paris) | eu-west-3 | elasticloadbalancing.eu-west-3.amazonaws.com | Z3Q77PNBQS71R4 | Z1CMS0P5QUZ6D5 | 
| Europe (Spain) | eu-south-2 | elasticloadbalancing.eu-south-2.amazonaws.com | Z0956581394HF5D5LXGAP | Z1011216NVTVYADP1SSV | 
| Europe (Stockholm) | eu-north-1 | elasticloadbalancing.eu-north-1.amazonaws.com | Z23TAZ6LKFMNIO | Z1UDT6IFJ4EJM | 
| Europe (Zurich) | eu-central-2 | elasticloadbalancing.eu-central-2.amazonaws.com | Z06391101F2ZOEP8P5EB3 | Z02239872DOALSIDCX66S | 
| Israel (Tel Aviv) | il-central-1 | elasticloadbalancing.il-central-1.amazonaws.com | Z09170902867EHPV2DABU | Z0313266YDI6ZRHTGQY4 | 
| Mexico (Central) | mx-central-1 | elasticloadbalancing.mx-central-1.amazonaws.com | Z023552324OKD1BB28BH5 | Z02031231H3ID6HYJ9A7U | 
| Middle East (Bahrain) | me-south-1 | elasticloadbalancing.me-south-1.amazonaws.com | ZS929ML54UICD | Z3QSRYVP46NYYV | 
| Middle East (UAE) | me-central-1 | elasticloadbalancing.me-central-1.amazonaws.com | Z08230872XQRWHG2XF6I | Z00282643NTTLPANJJG2P | 
| South America (São Paulo) | sa-east-1 | elasticloadbalancing.sa-east-1.amazonaws.com | Z2P70J7HTTTPLU | ZTK26PT1VY4CU | 
| AWS GovCloud (US-East) | us-gov-east-1 | elasticloadbalancing.us-gov-east-1.amazonaws.com | Z166TLBEWOO7G0 | Z1ZSMQQ6Q24QQ8 | 
| AWS GovCloud (US-West) | us-gov-west-1 | elasticloadbalancing.us-gov-west-1.amazonaws.com | Z33AYJ8TM3BH4J | ZMG1MZ2THAWF1 | 

## Service quotas
<a name="limits_elastic_load_balancer"></a>

The following quotas are for Application Load Balancers.


| Name | Default | Adjustable | 
| --- | --- | --- | 
|  Application Load Balancers per Region  |  50  | [Yes](https://console.aws.amazon.com/servicequotas/home/services/elasticloadbalancing/quotas/L-53DA6B97) | 
|  Certificates per Application Load Balancer  |  25  | [Yes](https://console.aws.amazon.com/servicequotas/home/services/elasticloadbalancing/quotas/L-9365A611) | 
|  Condition Values per Rule  |  5  | No | 
|  Condition Wildcards per Rule  |  6  | No | 
|  Listeners per Application Load Balancer  |  50  | [Yes](https://console.aws.amazon.com/servicequotas/home/services/elasticloadbalancing/quotas/L-B6DF7632) | 
|  Reserved Application Load Balancer Capacity Units (LCU) per Region  |  0  | [Yes](https://console.aws.amazon.com/servicequotas/home/services/elasticloadbalancing/quotas/L-8A66D0E6) | 
|  Rules per Application Load Balancer  |  100  | [Yes](https://console.aws.amazon.com/servicequotas/home/services/elasticloadbalancing/quotas/L-7EED9B64) | 
|  Target Groups per Action per Application Load Balancer  |  5  | No | 
|  Target Groups per Application Load Balancer  |  100  | No | 
|  Targets per Application Load Balancer  |  1,000  | [Yes](https://console.aws.amazon.com/servicequotas/home/services/elasticloadbalancing/quotas/L-7E6692B2) | 

The following quotas are for Network Load Balancers.


| Name | Default | Adjustable | 
| --- | --- | --- | 
|  Certificates per Network Load Balancer  |  25  | [Yes](https://console.aws.amazon.com/servicequotas/home/services/elasticloadbalancing/quotas/L-52964454) | 
|  Listeners per Network Load Balancer  |  50  | No | 
|  Network Load Balancer ENIs per VPC  |  1,200  | [Yes](https://console.aws.amazon.com/servicequotas/home/services/elasticloadbalancing/quotas/L-23568085) | 
|  Network Load Balancers per Region  |  50  | [Yes](https://console.aws.amazon.com/servicequotas/home/services/elasticloadbalancing/quotas/L-69A177A2) | 
|  Reserved Network Load Balancer Capacity Units (LCU) per Region  |  0  | [Yes](https://console.aws.amazon.com/servicequotas/home/services/elasticloadbalancing/quotas/L-723DCCB6) | 
|  Targets per Availability Zone per Network Load Balancer  |  500  | [Yes](https://console.aws.amazon.com/servicequotas/home/services/elasticloadbalancing/quotas/L-B211E961) | 
|  Targets per Network Load Balancer  |  3,000  | [Yes](https://console.aws.amazon.com/servicequotas/home/services/elasticloadbalancing/quotas/L-EEF1AD04) | 

The following quotas are for Gateway Load Balancers.


| Name | Default | Adjustable | 
| --- | --- | --- | 
| Gateway Load Balancers per Region | 100 | Yes | 
| Gateway Load Balancers per VPC | 100 | Yes | 
| Gateway Load Balancer ENIs per VPC | 300 \* | Yes | 
| GENEVE target groups per Region | 100 | Yes | 
| Listeners per Gateway Load Balancer | 1 | No | 
|  Reserved Gateway Load Balancer Capacity Units (LCU) per Region  |  0  | [Yes](https://console.aws.amazon.com/servicequotas/home/services/elasticloadbalancing/quotas/L-7A15E3C5) | 
| Targets per Availability Zone per GENEVE target group | 300 | No | 
| Targets per Availability Zone per Gateway Load Balancer | 300 | No | 
| Targets per Gateway Load Balancer | 300 | No | 

The following quotas are for target groups.


| Name | Default | Adjustable | 
| --- | --- | --- | 
|  Target Groups per Region  |  3,000  | [Yes](https://console.aws.amazon.com/servicequotas/home/services/elasticloadbalancing/quotas/L-B22855CB) | 
|  Targets per Target Group per Region  |  1,000  | [Yes](https://console.aws.amazon.com/servicequotas/home/services/elasticloadbalancing/quotas/L-A0D0B863) | 

The following quotas are for Classic Load Balancers.


| Name | Default | Adjustable | 
| --- | --- | --- | 
|  Classic Load Balancers per Region  |  20  | [Yes](https://console.aws.amazon.com/servicequotas/home/services/elasticloadbalancing/quotas/L-E9E9831D) | 
|  Listeners per Classic Load Balancer  |  100  | [Yes](https://console.aws.amazon.com/servicequotas/home/services/elasticloadbalancing/quotas/L-1A491844) | 
|  Registered Instances per Classic Load Balancer  |  1,000  | [Yes](https://console.aws.amazon.com/servicequotas/home/services/elasticloadbalancing/quotas/L-CE3125E5) | 

For more information, see the following:
+ [Quotas for your Application Load Balancers](https://docs.aws.amazon.com/elasticloadbalancing/latest/application/load-balancer-limits.html)
+ [Quotas for your Network Load Balancers](https://docs.aws.amazon.com/elasticloadbalancing/latest/network/load-balancer-limits.html)
+ [Quotas for your Classic Load Balancers](https://docs.aws.amazon.com/elasticloadbalancing/latest/classic/elb-limits.html)
+ [Quotas for your Gateway Load Balancers](https://docs.aws.amazon.com/elasticloadbalancing/latest/gateway/quotas-limits.html)