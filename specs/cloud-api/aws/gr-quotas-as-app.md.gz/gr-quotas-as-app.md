

# Application Auto Scaling endpoints and quotas
<a name="as-app"></a>

To connect programmatically to an AWS service, you use an endpoint. AWS services offer the following endpoint types in some or all of the AWS Regions that the service supports: IPv4 endpoints, dual-stack endpoints, and FIPS endpoints. Some services provide global endpoints. For more information, see [AWS service endpoints](rande.md).

Service quotas, also referred to as limits, are the maximum number of service resources or operations for your AWS account. For more information, see [AWS service quotas](aws_service_limits.md).

The following are the service endpoints and service quotas for this service.

## Service endpoints
<a name="as-app_region"></a>


| Region Name | Region | Endpoint | Protocol | 
| --- | --- | --- | --- | 
| US East (Ohio) | us-east-2 |  application-autoscaling.us-east-2.amazonaws.com  | HTTP and HTTPS | 
| US East (N. Virginia) | us-east-1 |  application-autoscaling.us-east-1.amazonaws.com  | HTTP and HTTPS | 
| US West (N. California) | us-west-1 |  application-autoscaling.us-west-1.amazonaws.com  | HTTP and HTTPS | 
| US West (Oregon) | us-west-2 |  application-autoscaling.us-west-2.amazonaws.com  | HTTP and HTTPS | 
| Africa (Cape Town) | af-south-1 |  application-autoscaling.af-south-1.amazonaws.com  | HTTP and HTTPS | 
| Asia Pacific (Hong Kong) | ap-east-1 |  application-autoscaling.ap-east-1.amazonaws.com  | HTTP and HTTPS | 
| Asia Pacific (Hyderabad) | ap-south-2 |  application-autoscaling.ap-south-2.amazonaws.com  | HTTP and HTTPS | 
| Asia Pacific (Jakarta) | ap-southeast-3 |  application-autoscaling.ap-southeast-3.amazonaws.com  | HTTP and HTTPS | 
| Asia Pacific (Malaysia) | ap-southeast-5 |  application-autoscaling.ap-southeast-5.amazonaws.com  | HTTP and HTTPS | 
| Asia Pacific (Melbourne) | ap-southeast-4 |  application-autoscaling.ap-southeast-4.amazonaws.com  | HTTP and HTTPS | 
| Asia Pacific (Mumbai) | ap-south-1 |  application-autoscaling.ap-south-1.amazonaws.com  | HTTP and HTTPS | 
| Asia Pacific (New Zealand) | ap-southeast-6 |  application-autoscaling.ap-southeast-6.amazonaws.com  | HTTP and HTTPS | 
| Asia Pacific (Osaka) | ap-northeast-3 |  application-autoscaling.ap-northeast-3.amazonaws.com  | HTTP and HTTPS | 
| Asia Pacific (Seoul) | ap-northeast-2 |  application-autoscaling.ap-northeast-2.amazonaws.com  | HTTP and HTTPS | 
| Asia Pacific (Singapore) | ap-southeast-1 |  application-autoscaling.ap-southeast-1.amazonaws.com  | HTTP and HTTPS | 
| Asia Pacific (Sydney) | ap-southeast-2 |  application-autoscaling.ap-southeast-2.amazonaws.com  | HTTP and HTTPS | 
| Asia Pacific (Taipei) | ap-east-2 |  application-autoscaling.ap-east-2.amazonaws.com  | HTTP and HTTPS | 
| Asia Pacific (Thailand) | ap-southeast-7 |  application-autoscaling.ap-southeast-7.amazonaws.com  | HTTP and HTTPS | 
| Asia Pacific (Tokyo) | ap-northeast-1 |  application-autoscaling.ap-northeast-1.amazonaws.com  | HTTP and HTTPS | 
| Canada (Central) | ca-central-1 |  application-autoscaling.ca-central-1.amazonaws.com  | HTTP and HTTPS | 
| Canada West (Calgary) | ca-west-1 |  application-autoscaling.ca-west-1.amazonaws.com  | HTTP and HTTPS | 
| Europe (Frankfurt) | eu-central-1 |  application-autoscaling.eu-central-1.amazonaws.com  | HTTP and HTTPS | 
| Europe (Ireland) | eu-west-1 |  application-autoscaling.eu-west-1.amazonaws.com  | HTTP and HTTPS | 
| Europe (London) | eu-west-2 |  application-autoscaling.eu-west-2.amazonaws.com  | HTTP and HTTPS | 
| Europe (Milan) | eu-south-1 |  application-autoscaling.eu-south-1.amazonaws.com  | HTTP and HTTPS | 
| Europe (Paris) | eu-west-3 |  application-autoscaling.eu-west-3.amazonaws.com  | HTTP and HTTPS | 
| Europe (Spain) | eu-south-2 |  application-autoscaling.eu-south-2.amazonaws.com  | HTTP and HTTPS | 
| Europe (Stockholm) | eu-north-1 |  application-autoscaling.eu-north-1.amazonaws.com  | HTTP and HTTPS | 
| Europe (Zurich) | eu-central-2 |  application-autoscaling.eu-central-2.amazonaws.com  | HTTP and HTTPS | 
| Israel (Tel Aviv) | il-central-1 |  application-autoscaling.il-central-1.amazonaws.com  | HTTP and HTTPS | 
| Mexico (Central) | mx-central-1 |  application-autoscaling.mx-central-1.amazonaws.com  | HTTP and HTTPS | 
| Middle East (Bahrain) | me-south-1 |  application-autoscaling.me-south-1.amazonaws.com  | HTTP and HTTPS | 
| Middle East (UAE) | me-central-1 |  application-autoscaling.me-central-1.amazonaws.com  | HTTP and HTTPS | 
| South America (São Paulo) | sa-east-1 |  application-autoscaling.sa-east-1.amazonaws.com  | HTTP and HTTPS | 
|  AWS GovCloud (US-East) | us-gov-east-1 |  application-autoscaling.us-gov-east-1.amazonaws.com  | HTTP and HTTPS | 
|  AWS GovCloud (US-West) | us-gov-west-1 |  application-autoscaling.us-gov-west-1.amazonaws.com  | HTTP and HTTPS | 

## Service quotas
<a name="limits_as-app"></a>


| Name | Default | Adjustable | Description | 
| --- | --- | --- | --- | 
| Scalable targets for Amazon ElastiCache | Each supported Region: 500 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/application-autoscaling/quotas/L-60E4E5E2)  | The maximum number of scalable targets that you can register for the ElastiCache namespace in this account in the current Region. A scalable target identifies the resource that Application Auto Scaling can scale. | 
| Scalable targets for Amazon Keyspaces | Each supported Region: 1,500 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/application-autoscaling/quotas/L-799ACCDF)  | The maximum number of scalable targets that you can register for the Cassandra namespace in this account in the current Region. A scalable target identifies the resource that Application Auto Scaling can scale. | 
| Scalable targets for Amazon MSK | Each supported Region: 500 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/application-autoscaling/quotas/L-1A11EB4B)  | The maximum number of scalable targets that you can register for the Kafka namespace in this account in the current Region. A scalable target identifies the resource that Application Auto Scaling can scale. | 
| Scalable targets for AppStream | Each supported Region: 500 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/application-autoscaling/quotas/L-8998F403)  | The maximum number of scalable targets that you can register for the AppStream namespace in this account in the current Region. A scalable target identifies the resource that Application Auto Scaling can scale. | 
| Scalable targets for Comprehend | Each supported Region: 500 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/application-autoscaling/quotas/L-17D5F681)  | The maximum number of scalable targets that you can register for the Comprehend namespace in this account in the current Region. A scalable target identifies the resource that Application Auto Scaling can scale. | 
| Scalable targets for DynamoDB | Each supported Region: 5,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/application-autoscaling/quotas/L-A1D42901)  | The maximum number of scalable targets that you can register for the DynamoDB namespace in this account in the current Region. A scalable target identifies the resource that Application Auto Scaling can scale. | 
| Scalable targets for EC2 | Each supported Region: 500 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/application-autoscaling/quotas/L-297D9EC9)  | The maximum number of scalable targets that you can register for the EC2 namespace in this account in the current Region. A scalable target identifies the resource that Application Auto Scaling can scale. | 
| Scalable targets for ECS | Each supported Region: 3,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/application-autoscaling/quotas/L-782A3EE2)  | The maximum number of scalable targets that you can register for the ECS namespace in this account in the current Region. A scalable target identifies the resource that Application Auto Scaling can scale. | 
| Scalable targets for EMR | Each supported Region: 500 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/application-autoscaling/quotas/L-D75CA9D2)  | The maximum number of scalable targets that you can register for the Elastic MapReduce (EMR) namespace in this account in the current Region. A scalable target identifies the resource that Application Auto Scaling can scale. | 
| Scalable targets for Lambda | Each supported Region: 500 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/application-autoscaling/quotas/L-A2AD6458)  | The maximum number of scalable targets that you can register for the Lambda namespace in this account in the current Region. A scalable target identifies the resource that Application Auto Scaling can scale. | 
| Scalable targets for RDS | Each supported Region: 500 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/application-autoscaling/quotas/L-800F6F7B)  | The maximum number of scalable targets that you can register for the RDS namespace in this account in the current Region. A scalable target identifies the resource that Application Auto Scaling can scale. | 
| Scalable targets for SageMaker | Each supported Region: 500 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/application-autoscaling/quotas/L-1AAF0700)  | The maximum number of scalable targets that you can register for the SageMaker namespace in this account in the current Region. A scalable target identifies the resource that Application Auto Scaling can scale. | 
| Scalable targets for custom resources | Each supported Region: 500 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/application-autoscaling/quotas/L-4A11ECEB)  | The maximum number of scalable targets that you can register for the custom resource namespace in this account in the current Region. A scalable target identifies the resource that Application Auto Scaling can scale. | 
| Scaling policies per scalable target | Each supported Region: 50 | No | The maximum number of scaling policies per scalable target. | 
| Scheduled actions per scalable target | Each supported Region: 200 | No | The maximum number of scheduled actions per scalable target. | 
| Step adjustments per step scaling policy | Each supported Region: 20 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/application-autoscaling/quotas/L-9C25247C)  | The maximum number of step adjustments per step scaling policy. | 

For more information, see [Quotas for Application Auto Scaling](https://docs.aws.amazon.com/autoscaling/application/userguide/application-auto-scaling-quotas.html) in the *Application Auto Scaling User Guide*.