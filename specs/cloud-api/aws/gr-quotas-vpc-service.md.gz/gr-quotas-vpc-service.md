

# Amazon Virtual Private Cloud endpoints and quotas
<a name="vpc-service"></a>

To connect programmatically to an AWS service, you use an endpoint. AWS services offer the following endpoint types in some or all of the AWS Regions that the service supports: IPv4 endpoints, dual-stack endpoints, and FIPS endpoints. Some services provide global endpoints. For more information, see [AWS service endpoints](rande.md).

Service quotas, also referred to as limits, are the maximum number of service resources or operations for your AWS account. For more information, see [AWS service quotas](aws_service_limits.md).

The following are the service endpoints and service quotas for this service.

## Service endpoints
<a name="vpc_region"></a>

The API actions to manage Amazon VPC resources (for example, virtual private clouds, subnets, and gateways) are part of the Amazon EC2 API. For more information, see [Amazon VPC actions](https://docs.aws.amazon.com/AWSEC2/latest/APIReference/OperationList-query-vpc.html) in the *Amazon EC2 API Reference*.

For the service endpoints for Amazon EC2, see [Amazon EC2 endpoints and quotas](ec2-service.md).

## Service quotas
<a name="vpc-quotas"></a>


| Name | Default | Adjustable | Description | 
| --- | --- | --- | --- | 
| Active VPC peering connections per VPC | Each supported Region: 50 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/vpc/quotas/L-7E9ECCDB)  | The maximum number of active VPC peering connections per VPC. This quota can be increased up to a maximum of 125. | 
| Characters per VPC endpoint policy | Each supported Region: 20,480 | No | The maximum number of characters in a VPC endpoint policy, including white space. | 
| Egress-only internet gateways per Region | Each supported Region: 5 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/vpc/quotas/L-45FE3B85)  | The maximum number of egress-only (outbound-only) internet gateways per Region. This quota is directly tied to the maximum number of VPCs per Region. To increase this quota, increase the number of VPCs per Region. | 
| Elastic IP address quota per NAT gateway | Each supported Region: 2 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/vpc/quotas/L-5F53652F)  | The maximum number of Elastic IP addresses that can be associated with a single NAT Gateway of connectivity type public. | 
| Gateway VPC endpoints per Region | Each supported Region: 20 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/vpc/quotas/L-1B52E74A)  | The maximum number of gateway VPC endpoints per Region. The maximum is 255 gateway endpoints per VPC. | 
| IPv4 CIDR blocks per VPC | Each supported Region: 5 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/vpc/quotas/L-83CA0A9D)  | The maximum number of IPv4 CIDR blocks per VPC. The primary CIDR block and all secondary CIDR blocks count toward this quota. This quota can be increased up to a maximum of 50. | 
| IPv6 CIDR blocks per VPC | Each supported Region: 5 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/vpc/quotas/L-085A6257)  | The maximum number of IPv6 CIDR blocks per VPC. | 
| Inbound or outbound rules per security group | Each supported Region: 60 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/vpc/quotas/L-0EA8095F)  | The maximum number of inbound or outbound rules per VPC security group (120 rules in total). This quota is enforced separately for IPv4 and IPv6 rules. A rule that references a security group or prefix list ID counts as one rule each for IPv4 and IPv6. This quota multiplied by the security groups per network interface quota cannot exceed 1000. | 
| Interface VPC endpoints per VPC | Each supported Region: 50 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/vpc/quotas/L-29B6F2EB)  | The maximum number of interface and gatewayLoadBalancer VPC endpoints per VPC. | 
| Internet gateways per Region | Each supported Region: 5 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/vpc/quotas/L-A4707A72)  | The maximum number of internet gateways per Region. This quota is directly tied to the maximum number of VPCs per Region. To increase this quota, increase the number of VPCs per Region. | 
| NAT gateways per Availability Zone | Each supported Region: 5 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/vpc/quotas/L-FE5A380F)  | The maximum number of NAT gateways per Availability Zone. This includes NAT gateways in the pending, active, or deleting state. | 
| Network ACLs per VPC | Each supported Region: 200 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/vpc/quotas/L-B4A6D682)  | The maximum number of network ACLs per VPC. | 
| Network Address Usage | Each supported Region: 64,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/vpc/quotas/L-BB24F6E5)  | The maximum Network Address Usage for a single VPC. | 
| Network interfaces per Region | Each supported Region: 5,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/vpc/quotas/L-DF5E4CA3)  | The maximum number of network interfaces per Availability Zone in a Region. | 
| Outstanding VPC peering connection requests | Each supported Region: 25 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/vpc/quotas/L-DC9F7029)  | The maximum number of outstanding VPC peering connection requests that youve requested. | 
| Participant accounts per VPC | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/vpc/quotas/L-2C462E13)  | The maximum number of distinct participant accounts that subnets in a VPC can be shared with. This is a per VPC quota and applies across all the subnets shared in a VPC. | 
| Peered Network Address Usage | Each supported Region: 128,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/vpc/quotas/L-CD17FD4B)  | The maximum Network Address Usage for a VPC and its peers. | 
| Private IP address quota per NAT gateway | Each supported Region: 8 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/vpc/quotas/L-DFA99DE7)  | The maximum number of private IP addresses that can be assigned to a single NAT Gateway of connectivity type private. | 
| Regional NAT gateways per VPC | Each supported Region: 5 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/vpc/quotas/L-12E49864)  | The maximum number of regional NAT gateways per VPC. This includes regional NAT gateways in the pending, active, or deleting state. | 
| Route tables per VPC | Each supported Region: 200 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/vpc/quotas/L-589F43AA)  | The maximum number of route tables per VPC. The main route table counts toward this quota. | 
| Routes per route table | Each supported Region: 500 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/vpc/quotas/L-93826ACB)  | The maximum number of non-propagated routes per route table. This quota can be increased up to a maximum of 1000; however, network performance might be impacted. This quota is enforced separately for IPv4 and IPv6 routes. | 
| Rules per network ACL | Each supported Region: 20 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/vpc/quotas/L-2AEEBF1A)  | The maximum number of inbound rules or outbound rules per network ACL (a total of 40 rules). This includes both IPv4 and IPv6 rules, and the default deny rules. This quota can be increased up to a maximum of 40; however, network performance might be impacted. | 
| Security groups per network interface | Each supported Region: 5 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/vpc/quotas/L-2AFB9258)  | The maximum number of security groups per network interface. The maximum is 16. This quota, multiplied by the quota for rules per security group, cannot exceed 1000. | 
| Subnets per VPC | Each supported Region: 200 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/vpc/quotas/L-407747CB)  | The maximum number of subnets per VPC. | 
| Subnets that can be shared with an account | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/vpc/quotas/L-44499CD2)  | The maximum number of subnets that can be shared with an AWS account. | 
| VPC Block Public Access exclusions per account per Region | Each supported Region: 50 | No | The maximum number of VPC Block Public Access exclusions that an account can have in a single Region at a time. | 
| VPC associations per security group | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/vpc/quotas/L-A272D574)  | The maximum number of VPC associations per security group. | 
| VPC endpoints of type resource per VPC | Each supported Region: 500 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/vpc/quotas/L-CA6CC422)  | The maximum number of single resource endpoints in a VPC. For additional capacity and limit increases, contact AWS Support. | 
| VPC endpoints of type service network per VPC | Each supported Region: 500 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/vpc/quotas/L-3B4E38D2)  | The maximum number of service network endpoints in a VPC. For additional capacity and limit increases, contact AWS Support. | 
| VPC peering connection request expiry hours | Each supported Region: 168 | No | The maximum number of hours after which an unaccepted VPC peering connection request expires. The default value is 168 hours (one week). | 
| VPC security groups per Region | Each supported Region: 2,500 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/vpc/quotas/L-E79EC296)  | The maximum number of VPC security groups per Region. | 
| VPCs per Region | Each supported Region: 5 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/vpc/quotas/L-F678F1CE)  | The maximum number of VPCs per Region. This quota is directly tied to the maximum number of internet gateways per Region. | 

**Note**  
The *VPC Block Public Access exclusions per account per Region* quota is adjustable. To request an adjustment, [open a service limit increase case](https://support.console.aws.amazon.com/support/home#/case/create?issueType=service-limit-increase) using the AWS Support Center Console.

For more information, see the following:
+ [Amazon VPC quotas](https://docs.aws.amazon.com/vpc/latest/userguide/amazon-vpc-limits.html)
+ [VPC peering quotas](https://docs.aws.amazon.com/vpc/latest/peering/vpc-peering-connection-quotas.html)
+ [Traffic Mirroring quotas](https://docs.aws.amazon.com/vpc/latest/mirroring/traffic-mirroring-limits.html)
+ [AWS Transit Gateway quotas](https://docs.aws.amazon.com/vpc/latest/tgw/transit-gateway-limits.html)
+ [AWS Network Manager quotas](https://docs.aws.amazon.com/network-manager/latest/tgwnm/nm-quotas.html)
+ [Reachability Analyzer quotas](https://docs.aws.amazon.com/vpc/latest/reachability/reachability-analyzer-limits.html)
+ [Network Access Analyzer quotas](https://docs.aws.amazon.com/vpc/latest/network-access-analyzer/network-access-analyzer-limits.html)
+ [AWS PrivateLink quotas](https://docs.aws.amazon.com/vpc/latest/privatelink/vpc-limits-endpoints.html)
+ [AWS Client VPN quotas](https://docs.aws.amazon.com/vpn/latest/clientvpn-admin/limits.html)
+ [Site-to-Site VPN quotas](https://docs.aws.amazon.com/vpn/latest/s2svpn/vpn-limits.html)