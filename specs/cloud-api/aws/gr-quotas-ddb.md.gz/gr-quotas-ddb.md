

# Amazon DynamoDB endpoints and quotas
<a name="ddb"></a>

To connect programmatically to an AWS service, you use an endpoint. AWS services offer the following endpoint types in some or all of the AWS Regions that the service supports: IPv4 endpoints, dual-stack endpoints, and FIPS endpoints. Some services provide global endpoints. For more information, see [AWS service endpoints](rande.md).

Service quotas, also referred to as limits, are the maximum number of service resources or operations for your AWS account. For more information, see [AWS service quotas](aws_service_limits.md).

The following are the service endpoints and service quotas for this service.

For more information about this topic specific to DynamoDB, see [Quotas in Amazon DynamoDB](https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/Limits.html).

## Service endpoints
<a name="ddb_region"></a>

### DynamoDB
<a name="ddb-core"></a>

Newer versions of the AWS SDK connect to Amazon DynamoDB using the AWS-account-based endpoints listed below. For more information, see [Account-based endpoints ](https://docs.aws.amazon.com/sdkref/latest/guide/feature-account-endpoints.html).


| Region Name | Region | Endpoint | Protocol | 
| --- | --- | --- | --- | 
| US East (Ohio) | us-east-2 |  dynamodb.us-east-2.amazonaws.com <br /> account-id.ddb.us-east-2.api.aws <br /> dynamodb.us-east-2.api.aws <br /> dynamodb-fips.us-east-2.api.aws <br /> dynamodb-fips.us-east-2.amazonaws.com <br /> account-id.ddb.us-east-2.amazonaws.com  | HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS<br />HTTPS<br />HTTPS<br />HTTP and HTTPS | 
| US East (N. Virginia) | us-east-1 |  dynamodb.us-east-1.amazonaws.com <br /> dynamodb-fips.us-east-1.amazonaws.com <br /> account-id.ddb.us-east-1.api.aws <br /> account-id.ddb.us-east-1.amazonaws.com <br /> dynamodb.us-east-1.api.aws <br /> dynamodb-fips.us-east-1.api.aws  | HTTP and HTTPS<br />HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS<br />HTTPS | 
| US West (N. California) | us-west-1 |  dynamodb.us-west-1.amazonaws.com <br /> dynamodb.us-west-1.api.aws <br /> dynamodb-fips.us-west-1.api.aws <br /> dynamodb-fips.us-west-1.amazonaws.com <br /> account-id.ddb.us-west-1.amazonaws.com <br /> account-id.ddb.us-west-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS<br />HTTPS<br />HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS | 
| US West (Oregon) | us-west-2 |  dynamodb.us-west-2.amazonaws.com <br /> account-id.ddb.us-west-2.amazonaws.com <br /> dynamodb-fips.us-west-2.amazonaws.com <br /> dynamodb.us-west-2.api.aws <br /> account-id.ddb.us-west-2.api.aws <br /> dynamodb-fips.us-west-2.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS<br />HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS<br />HTTPS | 
| Africa (Cape Town) | af-south-1 |  dynamodb.af-south-1.amazonaws.com <br /> account-id.ddb.af-south-1.amazonaws.com <br /> dynamodb.af-south-1.api.aws <br /> account-id.ddb.af-south-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (Hong Kong) | ap-east-1 |  dynamodb.ap-east-1.amazonaws.com <br /> dynamodb.ap-east-1.api.aws <br /> account-id.ddb.ap-east-1.amazonaws.com <br /> account-id.ddb.ap-east-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (Hyderabad) | ap-south-2 |  dynamodb.ap-south-2.amazonaws.com <br /> account-id.ddb.ap-south-2.api.aws <br /> dynamodb.ap-south-2.api.aws <br /> account-id.ddb.ap-south-2.amazonaws.com  | HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (Jakarta) | ap-southeast-3 |  dynamodb.ap-southeast-3.amazonaws.com <br /> dynamodb.ap-southeast-3.api.aws <br /> account-id.ddb.ap-southeast-3.amazonaws.com <br /> account-id.ddb.ap-southeast-3.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (Malaysia) | ap-southeast-5 |  dynamodb.ap-southeast-5.amazonaws.com <br /> account-id.ddb.ap-southeast-5.api.aws <br /> account-id.ddb.ap-southeast-5.amazonaws.com <br /> dynamodb.ap-southeast-5.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (Melbourne) | ap-southeast-4 |  dynamodb.ap-southeast-4.amazonaws.com <br /> account-id.ddb.ap-southeast-4.api.aws <br /> dynamodb.ap-southeast-4.api.aws <br /> account-id.ddb.ap-southeast-4.amazonaws.com  | HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (Mumbai) | ap-south-1 |  dynamodb.ap-south-1.amazonaws.com <br /> dynamodb.ap-south-1.api.aws <br /> account-id.ddb.ap-south-1.amazonaws.com <br /> account-id.ddb.ap-south-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (New Zealand) | ap-southeast-6 |  dynamodb.ap-southeast-6.amazonaws.com <br /> account-id.ddb.ap-southeast-6.amazonaws.com <br /> dynamodb.ap-southeast-6.api.aws <br /> account-id.ddb.ap-southeast-6.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (Osaka) | ap-northeast-3 |  dynamodb.ap-northeast-3.amazonaws.com <br /> account-id.ddb.ap-northeast-3.api.aws <br /> account-id.ddb.ap-northeast-3.amazonaws.com <br /> dynamodb.ap-northeast-3.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (Seoul) | ap-northeast-2 |  dynamodb.ap-northeast-2.amazonaws.com <br /> account-id.ddb.ap-northeast-2.api.aws <br /> dynamodb.ap-northeast-2.api.aws <br /> account-id.ddb.ap-northeast-2.amazonaws.com  | HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (Singapore) | ap-southeast-1 |  dynamodb.ap-southeast-1.amazonaws.com <br /> account-id.ddb.ap-southeast-1.amazonaws.com <br /> dynamodb.ap-southeast-1.api.aws <br /> account-id.ddb.ap-southeast-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (Sydney) | ap-southeast-2 |  dynamodb.ap-southeast-2.amazonaws.com <br /> account-id.ddb.ap-southeast-2.api.aws <br /> account-id.ddb.ap-southeast-2.amazonaws.com <br /> dynamodb.ap-southeast-2.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (Taipei) | ap-east-2 |  dynamodb.ap-east-2.amazonaws.com <br /> account-id.ddb.ap-east-2.amazonaws.com <br /> account-id.ddb.ap-east-2.api.aws <br /> dynamodb.ap-east-2.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (Thailand) | ap-southeast-7 |  dynamodb.ap-southeast-7.amazonaws.com <br /> account-id.ddb.ap-southeast-7.api.aws <br /> dynamodb.ap-southeast-7.api.aws <br /> account-id.ddb.ap-southeast-7.amazonaws.com  | HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (Tokyo) | ap-northeast-1 |  dynamodb.ap-northeast-1.amazonaws.com <br /> account-id.ddb.ap-northeast-1.api.aws <br /> account-id.ddb.ap-northeast-1.amazonaws.com <br /> dynamodb.ap-northeast-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS | 
| Canada (Central) | ca-central-1 |  dynamodb.ca-central-1.amazonaws.com <br /> dynamodb.ca-central-1.api.aws <br /> account-id.ddb.ca-central-1.amazonaws.com <br /> dynamodb-fips.ca-central-1.amazonaws.com <br /> account-id.ddb.ca-central-1.api.aws <br /> dynamodb-fips.ca-central-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS<br />HTTPS<br />HTTP and HTTPS<br />HTTPS | 
| Canada West (Calgary) | ca-west-1 |  dynamodb.ca-west-1.amazonaws.com <br /> dynamodb-fips.ca-west-1.amazonaws.com <br /> account-id.ddb.ca-west-1.api.aws <br /> dynamodb.ca-west-1.api.aws <br /> account-id.ddb.ca-west-1.amazonaws.com <br /> dynamodb-fips.ca-west-1.api.aws  | HTTP and HTTPS<br />HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS<br />HTTPS | 
| Europe (Frankfurt) | eu-central-1 |  dynamodb.eu-central-1.amazonaws.com <br /> dynamodb.eu-central-1.api.aws <br /> account-id.ddb.eu-central-1.amazonaws.com <br /> account-id.ddb.eu-central-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS | 
| Europe (Ireland) | eu-west-1 |  dynamodb.eu-west-1.amazonaws.com <br /> account-id.ddb.eu-west-1.amazonaws.com <br /> dynamodb.eu-west-1.api.aws <br /> account-id.ddb.eu-west-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS | 
| Europe (London) | eu-west-2 |  dynamodb.eu-west-2.amazonaws.com <br /> dynamodb.eu-west-2.api.aws <br /> account-id.ddb.eu-west-2.amazonaws.com <br /> account-id.ddb.eu-west-2.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS | 
| Europe (Milan) | eu-south-1 |  dynamodb.eu-south-1.amazonaws.com <br /> account-id.ddb.eu-south-1.api.aws <br /> account-id.ddb.eu-south-1.amazonaws.com <br /> dynamodb.eu-south-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS | 
| Europe (Paris) | eu-west-3 |  dynamodb.eu-west-3.amazonaws.com <br /> account-id.ddb.eu-west-3.api.aws <br /> dynamodb.eu-west-3.api.aws <br /> account-id.ddb.eu-west-3.amazonaws.com  | HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS | 
| Europe (Spain) | eu-south-2 |  dynamodb.eu-south-2.amazonaws.com <br /> account-id.ddb.eu-south-2.api.aws <br /> dynamodb.eu-south-2.api.aws <br /> account-id.ddb.eu-south-2.amazonaws.com  | HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS | 
| Europe (Stockholm) | eu-north-1 |  dynamodb.eu-north-1.amazonaws.com <br /> dynamodb.eu-north-1.api.aws <br /> account-id.ddb.eu-north-1.api.aws <br /> account-id.ddb.eu-north-1.amazonaws.com  | HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS | 
| Europe (Zurich) | eu-central-2 |  dynamodb.eu-central-2.amazonaws.com <br /> account-id.ddb.eu-central-2.api.aws <br /> account-id.ddb.eu-central-2.amazonaws.com <br /> dynamodb.eu-central-2.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS | 
| Israel (Tel Aviv) | il-central-1 |  dynamodb.il-central-1.amazonaws.com <br /> account-id.ddb.il-central-1.amazonaws.com <br /> account-id.ddb.il-central-1.api.aws <br /> dynamodb.il-central-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS | 
| Mexico (Central) | mx-central-1 |  dynamodb.mx-central-1.amazonaws.com <br /> account-id.ddb.mx-central-1.api.aws <br /> dynamodb.mx-central-1.api.aws <br /> account-id.ddb.mx-central-1.amazonaws.com  | HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS | 
| Middle East (Bahrain) | me-south-1 |  dynamodb.me-south-1.amazonaws.com <br /> account-id.ddb.me-south-1.amazonaws.com  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Middle East (UAE) | me-central-1 |  dynamodb.me-central-1.amazonaws.com <br /> account-id.ddb.me-central-1.amazonaws.com  | HTTP and HTTPS<br />HTTP and HTTPS | 
| South America (São Paulo) | sa-east-1 |  dynamodb.sa-east-1.amazonaws.com <br /> dynamodb.sa-east-1.api.aws <br /> account-id.ddb.sa-east-1.amazonaws.com <br /> account-id.ddb.sa-east-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS<br />HTTP and HTTPS | 
|  AWS GovCloud (US-East) | us-gov-east-1 |  dynamodb.us-gov-east-1.amazonaws.com <br /> dynamodb-fips.us-gov-east-1.amazonaws.com <br /> dynamodb.us-gov-east-1.api.aws <br /> dynamodb-fips.us-gov-east-1.api.aws  | HTTP and HTTPS<br />HTTPS<br />HTTP and HTTPS<br />HTTPS | 
|  AWS GovCloud (US-West) | us-gov-west-1 |  dynamodb.us-gov-west-1.amazonaws.com <br /> dynamodb-fips.us-gov-west-1.api.aws <br /> dynamodb.us-gov-west-1.api.aws <br /> dynamodb-fips.us-gov-west-1.amazonaws.com  | HTTP and HTTPS<br />HTTPS<br />HTTP and HTTPS<br />HTTPS | 

### DynamoDB Accelerator (DAX)
<a name="ddb_dax"></a>


| Region Name | Region | Endpoint | Protocol | 
| --- | --- | --- | --- | 
| US East (Ohio) | us-east-2 |  dax.us-east-2.amazonaws.com <br /> dax.us-east-2.api.aws  | HTTP and HTTPS<br />HTTPS | 
| US East (N. Virginia) | us-east-1 |  dax.us-east-1.amazonaws.com <br /> dax.us-east-1.api.aws  | HTTP and HTTPS<br />HTTPS | 
| US West (N. California) | us-west-1 |  dax.us-west-1.amazonaws.com <br /> dax.us-west-1.api.aws  | HTTP and HTTPS<br />HTTPS | 
| US West (Oregon) | us-west-2 |  dax.us-west-2.amazonaws.com <br /> dax.us-west-2.api.aws  | HTTP and HTTPS<br />HTTPS | 
| Africa (Cape Town) | af-south-1 |  dax.af-south-1.amazonaws.com <br /> dax.af-south-1.api.aws  | HTTP and HTTPS<br />HTTPS | 
| Asia Pacific (Hong Kong) | ap-east-1 |  dax.ap-east-1.amazonaws.com <br /> dax.ap-east-1.api.aws  | HTTP and HTTPS<br />HTTPS | 
| Asia Pacific (Hyderabad) | ap-south-2 |  dax.ap-south-2.amazonaws.com <br /> dax.ap-south-2.api.aws  | HTTP and HTTPS<br />HTTPS | 
| Asia Pacific (Jakarta) | ap-southeast-3 |  dax.ap-southeast-3.amazonaws.com <br /> dax.ap-southeast-3.api.aws  | HTTP and HTTPS<br />HTTPS | 
| Asia Pacific (Malaysia) | ap-southeast-5 |  dax.ap-southeast-5.amazonaws.com <br /> dax.ap-southeast-5.api.aws  | HTTP and HTTPS<br />HTTPS | 
| Asia Pacific (Melbourne) | ap-southeast-4 |  dax.ap-southeast-4.amazonaws.com <br /> dax.ap-southeast-4.api.aws  | HTTP and HTTPS<br />HTTPS | 
| Asia Pacific (Mumbai) | ap-south-1 |  dax.ap-south-1.amazonaws.com <br /> dax.ap-south-1.api.aws  | HTTP and HTTPS<br />HTTPS | 
| Asia Pacific (New Zealand) | ap-southeast-6 |  dax.ap-southeast-6.amazonaws.com <br /> dax.ap-southeast-6.api.aws  | HTTP and HTTPS<br />HTTPS | 
| Asia Pacific (Osaka) | ap-northeast-3 |  dax.ap-northeast-3.amazonaws.com <br /> dax.ap-northeast-3.api.aws  | HTTP and HTTPS<br />HTTPS | 
| Asia Pacific (Seoul) | ap-northeast-2 |  dax.ap-northeast-2.amazonaws.com <br /> dax.ap-northeast-2.api.aws  | HTTP and HTTPS<br />HTTPS | 
| Asia Pacific (Singapore) | ap-southeast-1 |  dax.ap-southeast-1.amazonaws.com <br /> dax.ap-southeast-1.api.aws  | HTTP and HTTPS<br />HTTPS | 
| Asia Pacific (Sydney) | ap-southeast-2 |  dax.ap-southeast-2.amazonaws.com <br /> dax.ap-southeast-2.api.aws  | HTTP and HTTPS<br />HTTPS | 
| Asia Pacific (Taipei) | ap-east-2 |  dax.ap-east-2.amazonaws.com <br /> dax.ap-east-2.api.aws  | HTTP and HTTPS<br />HTTPS | 
| Asia Pacific (Thailand) | ap-southeast-7 |  dax.ap-southeast-7.amazonaws.com <br /> dax.ap-southeast-7.api.aws  | HTTP and HTTPS<br />HTTPS | 
| Asia Pacific (Tokyo) | ap-northeast-1 |  dax.ap-northeast-1.amazonaws.com <br /> dax.ap-northeast-1.api.aws  | HTTP and HTTPS<br />HTTPS | 
| Canada (Central) | ca-central-1 |  dax.ca-central-1.amazonaws.com <br /> dax.ca-central-1.api.aws  | HTTP and HTTPS<br />HTTPS | 
| Canada West (Calgary) | ca-west-1 |  dax.ca-west-1.amazonaws.com <br /> dax.ca-west-1.api.aws  | HTTP and HTTPS<br />HTTPS | 
| Europe (Frankfurt) | eu-central-1 |  dax.eu-central-1.amazonaws.com <br /> dax.eu-central-1.api.aws  | HTTP and HTTPS<br />HTTPS | 
| Europe (Ireland) | eu-west-1 |  dax.eu-west-1.amazonaws.com <br /> dax.eu-west-1.api.aws  | HTTP and HTTPS<br />HTTPS | 
| Europe (London) | eu-west-2 |  dax.eu-west-2.amazonaws.com <br /> dax.eu-west-2.api.aws  | HTTP and HTTPS<br />HTTPS | 
| Europe (Milan) | eu-south-1 |  dax.eu-south-1.amazonaws.com <br /> dax.eu-south-1.api.aws  | HTTP and HTTPS<br />HTTPS | 
| Europe (Paris) | eu-west-3 |  dax.eu-west-3.amazonaws.com <br /> dax.eu-west-3.api.aws  | HTTP and HTTPS<br />HTTPS | 
| Europe (Spain) | eu-south-2 |  dax.eu-south-2.amazonaws.com <br /> dax.eu-south-2.api.aws  | HTTP and HTTPS<br />HTTPS | 
| Europe (Stockholm) | eu-north-1 |  dax.eu-north-1.amazonaws.com <br /> dax.eu-north-1.api.aws  | HTTP and HTTPS<br />HTTPS | 
| Europe (Zurich) | eu-central-2 |  dax.eu-central-2.amazonaws.com <br /> dax.eu-central-2.api.aws  | HTTP and HTTPS<br />HTTPS | 
| Israel (Tel Aviv) | il-central-1 |  dax.il-central-1.amazonaws.com <br /> dax.il-central-1.api.aws  | HTTP and HTTPS<br />HTTPS | 
| Mexico (Central) | mx-central-1 |  dax.mx-central-1.amazonaws.com <br /> dax.mx-central-1.api.aws  | HTTP and HTTPS<br />HTTPS | 
| South America (São Paulo) | sa-east-1 |  dax.sa-east-1.amazonaws.com <br /> dax.sa-east-1.api.aws  | HTTP and HTTPS<br />HTTPS | 
|  AWS GovCloud (US-East) | us-gov-east-1 |  dax.us-gov-east-1.amazonaws.com <br /> dax-fips.us-gov-east-1.amazonaws.com <br /> dax.us-gov-east-1.api.aws <br /> dax-fips.us-gov-east-1.api.aws  | HTTP and HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
|  AWS GovCloud (US-West) | us-gov-west-1 |  dax.us-gov-west-1.amazonaws.com <br /> dax-fips.us-gov-west-1.api.aws <br /> dax.us-gov-west-1.api.aws <br /> dax-fips.us-gov-west-1.amazonaws.com  | HTTP and HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 

### Amazon DynamoDB Streams
<a name="ddb_streams"></a>


| Region Name | Region | Endpoint | Protocol | 
| --- | --- | --- | --- | 
| US East (Ohio) | us-east-2 |  streams.dynamodb.us-east-2.amazonaws.com <br /> streams-dynamodb-fips.us-east-2.api.aws <br /> streams.dynamodb-fips.us-east-2.amazonaws.com <br /> streams-dynamodb.us-east-2.api.aws  | HTTP and HTTPS<br />HTTPS<br />HTTPS<br />HTTP and HTTPS | 
| US East (N. Virginia) | us-east-1 |  streams.dynamodb.us-east-1.amazonaws.com <br /> streams-dynamodb-fips.us-east-1.api.aws <br /> streams.dynamodb-fips.us-east-1.amazonaws.com <br /> streams-dynamodb.us-east-1.api.aws  | HTTP and HTTPS<br />HTTPS<br />HTTPS<br />HTTP and HTTPS | 
| US West (N. California) | us-west-1 |  streams.dynamodb.us-west-1.amazonaws.com <br /> streams-dynamodb-fips.us-west-1.api.aws <br /> streams.dynamodb-fips.us-west-1.amazonaws.com <br /> streams-dynamodb.us-west-1.api.aws  | HTTP and HTTPS<br />HTTPS<br />HTTPS<br />HTTP and HTTPS | 
| US West (Oregon) | us-west-2 |  streams.dynamodb.us-west-2.amazonaws.com <br /> streams-dynamodb-fips.us-west-2.api.aws <br /> streams.dynamodb-fips.us-west-2.amazonaws.com <br /> streams-dynamodb.us-west-2.api.aws  | HTTP and HTTPS<br />HTTPS<br />HTTPS<br />HTTP and HTTPS | 
| Africa (Cape Town) | af-south-1 |  streams.dynamodb.af-south-1.amazonaws.com <br /> streams-dynamodb.af-south-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (Hong Kong) | ap-east-1 |  streams.dynamodb.ap-east-1.amazonaws.com <br /> streams-dynamodb.ap-east-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (Hyderabad) | ap-south-2 |  streams.dynamodb.ap-south-2.amazonaws.com <br /> streams-dynamodb.ap-south-2.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (Jakarta) | ap-southeast-3 |  streams.dynamodb.ap-southeast-3.amazonaws.com <br /> streams-dynamodb.ap-southeast-3.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (Malaysia) | ap-southeast-5 |  streams.dynamodb.ap-southeast-5.amazonaws.com <br /> streams-dynamodb.ap-southeast-5.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (Melbourne) | ap-southeast-4 |  streams.dynamodb.ap-southeast-4.amazonaws.com <br /> streams-dynamodb.ap-southeast-4.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (Mumbai) | ap-south-1 |  streams.dynamodb.ap-south-1.amazonaws.com <br /> streams-dynamodb.ap-south-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (New Zealand) | ap-southeast-6 |  streams.dynamodb.ap-southeast-6.amazonaws.com <br /> streams-dynamodb.ap-southeast-6.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (Osaka) | ap-northeast-3 |  streams.dynamodb.ap-northeast-3.amazonaws.com <br /> streams-dynamodb.ap-northeast-3.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (Seoul) | ap-northeast-2 |  streams.dynamodb.ap-northeast-2.amazonaws.com <br /> streams-dynamodb.ap-northeast-2.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (Singapore) | ap-southeast-1 |  streams.dynamodb.ap-southeast-1.amazonaws.com <br /> streams-dynamodb.ap-southeast-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (Sydney) | ap-southeast-2 |  streams.dynamodb.ap-southeast-2.amazonaws.com <br /> streams-dynamodb.ap-southeast-2.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (Taipei) | ap-east-2 |  streams.dynamodb.ap-east-2.amazonaws.com <br /> streams-dynamodb.ap-east-2.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (Thailand) | ap-southeast-7 |  streams.dynamodb.ap-southeast-7.amazonaws.com <br /> streams-dynamodb.ap-southeast-7.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (Tokyo) | ap-northeast-1 |  streams.dynamodb.ap-northeast-1.amazonaws.com <br /> streams-dynamodb.ap-northeast-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Canada (Central) | ca-central-1 |  streams.dynamodb.ca-central-1.amazonaws.com <br /> streams-dynamodb-fips.ca-central-1.api.aws <br /> streams.dynamodb-fips.ca-central-1.amazonaws.com <br /> streams-dynamodb.ca-central-1.api.aws  | HTTP and HTTPS<br />HTTPS<br />HTTPS<br />HTTP and HTTPS | 
| Canada West (Calgary) | ca-west-1 |  streams.dynamodb.ca-west-1.amazonaws.com <br /> streams-dynamodb-fips.ca-west-1.api.aws <br /> streams.dynamodb-fips.ca-west-1.amazonaws.com <br /> streams-dynamodb.ca-west-1.api.aws  | HTTP and HTTPS<br />HTTPS<br />HTTPS<br />HTTP and HTTPS | 
| Europe (Frankfurt) | eu-central-1 |  streams.dynamodb.eu-central-1.amazonaws.com <br /> streams-dynamodb.eu-central-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Europe (Ireland) | eu-west-1 |  streams.dynamodb.eu-west-1.amazonaws.com <br /> streams-dynamodb.eu-west-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Europe (London) | eu-west-2 |  streams.dynamodb.eu-west-2.amazonaws.com <br /> streams-dynamodb.eu-west-2.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Europe (Milan) | eu-south-1 |  streams.dynamodb.eu-south-1.amazonaws.com <br /> streams-dynamodb.eu-south-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Europe (Paris) | eu-west-3 |  streams.dynamodb.eu-west-3.amazonaws.com <br /> streams-dynamodb.eu-west-3.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Europe (Spain) | eu-south-2 |  streams.dynamodb.eu-south-2.amazonaws.com <br /> streams-dynamodb.eu-south-2.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Europe (Stockholm) | eu-north-1 |  streams.dynamodb.eu-north-1.amazonaws.com <br /> streams-dynamodb.eu-north-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Europe (Zurich) | eu-central-2 |  streams.dynamodb.eu-central-2.amazonaws.com <br /> streams-dynamodb.eu-central-2.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Israel (Tel Aviv) | il-central-1 |  streams.dynamodb.il-central-1.amazonaws.com <br /> streams-dynamodb.il-central-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Mexico (Central) | mx-central-1 |  streams.dynamodb.mx-central-1.amazonaws.com <br /> streams-dynamodb.mx-central-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Middle East (Bahrain) | me-south-1 |  streams.dynamodb.me-south-1.amazonaws.com <br /> streams-dynamodb.me-south-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Middle East (UAE) | me-central-1 |  streams.dynamodb.me-central-1.amazonaws.com <br /> streams-dynamodb.me-central-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| South America (São Paulo) | sa-east-1 |  streams.dynamodb.sa-east-1.amazonaws.com <br /> streams-dynamodb.sa-east-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
|  AWS GovCloud (US-East) | us-gov-east-1 |  streams.dynamodb.us-gov-east-1.amazonaws.com <br /> streams-dynamodb-fips.us-gov-east-1.api.aws <br /> streams.dynamodb-fips.us-gov-east-1.amazonaws.com <br /> streams-dynamodb.us-gov-east-1.api.aws  | HTTP and HTTPS<br />HTTPS<br />HTTPS<br />HTTP and HTTPS | 
|  AWS GovCloud (US-West) | us-gov-west-1 |  streams.dynamodb.us-gov-west-1.amazonaws.com <br /> streams-dynamodb-fips.us-gov-west-1.api.aws <br /> streams.dynamodb-fips.us-gov-west-1.amazonaws.com <br /> streams-dynamodb.us-gov-west-1.api.aws  | HTTP and HTTPS<br />HTTPS<br />HTTPS<br />HTTP and HTTPS | 

## Service quotas
<a name="limits_dynamodb"></a>


| Name | Default | Adjustable | Description | 
| --- | --- | --- | --- | 
| Account-level read throughput limit (Provisioned mode) | Each supported Region: 80,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/dynamodb/quotas/L-34F6A552)  | The maximum number of read capacity units allocated for the account; applicable only for tables (including all associated global secondary indexes) in provisioned read/write capacity mode. For more information, see https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/Limits.html\#default-limits-throughput-capacity-modes | 
| Account-level write throughput limit (Provisioned mode) | Each supported Region: 80,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/dynamodb/quotas/L-34F8CCC8)  | The maximum number of write capacity units allocated for the account; applicable only for tables (including all associated global secondary indexes) in provisioned read/write capacity mode. For more information, see https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/Limits.html\#default-limits-throughput-capacity-modes | 
| Concurrent BulkPutItems operations (Accelerated performance tier) | Each supported Region: 5 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/dynamodb/quotas/L-FBBCE3E7)  | The maximum number of BulkPutItems operations that can run concurrently at the Accelerated performance tier. For more information, see https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/ServiceQuotas.html\#limits-bulk-put-items | 
| Concurrent BulkPutItems operations (Standard performance tier) | Each supported Region: 5 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/dynamodb/quotas/L-0726A3CF)  | The maximum number of BulkPutItems operations that can run concurrently at the Standard performance tier. For more information, see https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/ServiceQuotas.html\#limits-bulk-put-items | 
| Concurrent control plane operations | Each supported Region: 500 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/dynamodb/quotas/L-1BB77E89)  | The maximum number of allowed concurrent control plane operations. For more information, see https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/Limits.html\#limits-api | 
| Global Secondary Indexes per table | Each supported Region: 20 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/dynamodb/quotas/L-F7858A77)  | The maximum number of global secondary indexes that can be created for a table. For more information, see, https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/ServiceQuotas.html\#limits-secondary-indexes | 
| Maximum BulkPutItems data size (Accelerated performance tier) | Each supported Region: 1 Terabytes |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/dynamodb/quotas/L-2AFF8965)  | The maximum limit on total input size for a single BulkPutItems operation at the Accelerated performance tier. For more information, see https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/ServiceQuotas.html\#limits-bulk-put-items | 
| Maximum BulkPutItems data size (Standard performance tier) | Each supported Region: 100 Gigabytes |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/dynamodb/quotas/L-B32F4AF0)  | The maximum limit on total input size for a single BulkPutItems operation at the Standard performance tier. For more information, see https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/ServiceQuotas.html\#limits-bulk-put-items | 
| Maximum Incremental Export concurrent data size | Each supported Region: 100 Terabytes |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/dynamodb/quotas/L-2A593B99)  | Maximum limit on size of in flight incremental export requests. For more information, see https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/ServiceQuotas.html\#limits-table-export | 
| Maximum Incremental Export concurrent requests | Each supported Region: 300 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/dynamodb/quotas/L-D98E8184)  | Maximum limit on number of in flight incremental export requests. For more information, see https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/ServiceQuotas.html\#limits-table-export | 
| Maximum Incremental Export period window | Each supported Region: 24 | No | The limit on the maximum export period (in hours) for an incremental export request. For more information, see https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/ServiceQuotas.html\#limits-table-export | 
| Maximum number of objects per BulkPutItems operation | Each supported Region: 50,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/dynamodb/quotas/L-B0A68893)  | The maximum limit on total number of objects for a BulkPutItems operation. For more information, see https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/ServiceQuotas.html\#limits-bulk-put-items | 
| Maximum number of tables | Each supported Region: 2,500 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/dynamodb/quotas/L-F98FE922)  | The maximum number of tables that can be created per region. For more information, see https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/ServiceQuotas.html\#limits-tables | 
| Minimum Incremental Export period window | Each supported Region: 15 | No | The limit on the minimum export period (in minutes) for an incremental export request. For more information, see https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/ServiceQuotas.html\#limits-table-export | 
| Provisioned capacity decreases per day | Each supported Region: 27 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/dynamodb/quotas/L-F3CA5463)  | A decrease is allowed up to four times any time per day (GMT time zone). Also, if there was no decrease in the past hour, an additional decrease is allowed, effectively bringing the maximum number of decreases in a day to 27 times. For more information, see https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/ServiceQuotas.html | 
| Table-level read throughput limit | Each supported Region: 40,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/dynamodb/quotas/L-CF0CBE56)  | The maximum number of read throughput allocated for a table or global secondary index. For more information, see https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/Limits.html\#default-limits-throughput-capacity-modes | 
| Table-level write throughput limit | Each supported Region: 40,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/dynamodb/quotas/L-AB614373)  | The maximum number of write throughput allocated for a table or global secondary index. For more information, see https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/Limits.html\#default-limits-throughput-capacity-modes | 
| Write throughput limit for DynamoDB Streams (Provisioned mode) | Each supported Region: 40,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/dynamodb/quotas/L-923BEB7A)  | The maximum number of write capacity units allowed for a table with streams enabled; applicable only for tables in provisioned read/write capacity mode. Other quotas might also apply. For more information, see https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/ServiceQuotas.html\#limits-dynamodb-streams | 

DAX has the following quotas.


| Name | Default | Adjustable | Description | 
| --- | --- | --- | --- | 
| Nodes per cluster | Each supported Region: 11 | No | The maximum number of nodes per cluster, including the primary node as well as any read replica nodes. | 
| Parameter groups | Each supported Region: 20 | No | The maximum number of parameter groups in a single AWS region. | 
| Subnet groups | Each supported Region: 50 | No | The maximum number of subnet groups in a single AWS region. | 
| Subnets per subnet group | Each supported Region: 20 | No | The maximum number of subnets per subnet group in a single AWS region. | 
| Total number of nodes | Each supported Region: 50 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/dax/quotas/L-AB139030)  | The maximum total number of nodes per AWS account in a single AWS region. | 