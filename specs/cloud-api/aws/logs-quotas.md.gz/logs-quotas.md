

# CloudWatch Logs quotas
<a name="cloudwatch_limits_cwl"></a>

 You can use the table in this section to review the default service quotas, also referred to as limits, for an AWS account in Amazon CloudWatch Logs. Most of the service quotas, but not all, are listed under the Amazon CloudWatch Logs namespace in the Service Quotas console. 

**Note**  
 If you want to request a quota increase for any of these quotas, see [the procedure](https://docs.aws.amazon.com/AmazonCloudWatch/latest/logs/cloudwatch_limits_cwl.html#service-quotas-manage) in this section. 


| Name | Default | Adjustable | Description | 
| --- | --- | --- | --- | 
| Active export task | Each supported Region: 1 | No | The number of active (running or pending) export tasks per account | 
| AssociateKmsKey throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of associate-kms-key calls per second per account/per region | 
| AssociateSourceToS3TableIntegration throttle limit in transactions per second | Each supported Region: 5 | No | The maximum number of AssociateSourceToS3TableIntegration calls per second per account/per region | 
| AssociateSourceToS3TableIntegration throttle limit in transactions per second in a burst | Each supported Region: 10 | No | The maximum number of AssociateSourceToS3TableIntegration calls per second per account/per region in a burst | 
| Batch size | Each supported Region: 1 Megabytes | No | The maximum batch size in MB of a put-log-events request | 
| CancelExportTask throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of cancel-export-task calls per second per account/per region | 
| CancelImportTask throttle limit in transactions per second | Each supported Region: 1 | No | The maximum number of CancelImportTask calls per second per account/per region | 
| CancelImportTask throttle limit in transactions per second in a burst | Each supported Region: 1 | No | The maximum number of CancelImportTask calls per second per account/per region in a burst | 
| CreateExportTask throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of create-export-task calls per second per account/per region | 
| CreateImportTask throttle limit in transactions per second | Each supported Region: 1 | No | The maximum number of CreateImportTask calls per second per account/per region | 
| CreateImportTask throttle limit in transactions per second in a burst | Each supported Region: 1 | No | The maximum number of CreateImportTask calls per second per account/per region in a burst | 
| CreateLogGroup throttle limit in transactions per second | Each supported Region: 10 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/logs/quotas/L-D2832119)  | The maximum number of create-log-group calls per second per account/per region | 
| CreateLogStream throttle limit in transactions per second | Each supported Region: 50 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/logs/quotas/L-76507CEF)  | The maximum number of create-log-stream calls per second per account/per region | 
| Data archiving | Each supported Region: 5 Gigabytes | No | The maximum size in GB of free data archiving | 
| DeleteDataProtectionPolicy throttle limit in transactions per second | Each supported Region: 5 | No | The maximum number of delete-data-protection-policy calls per second per account/per region | 
| DeleteDestination throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of delete-destination calls per second per account/per region | 
| DeleteLogGroup throttle limit in transactions per second | Each supported Region: 10 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/logs/quotas/L-07A912D5)  | The maximum number of delete-log-group calls per second per account/per region | 
| DeleteLogStream throttle limit in transactions per second | Each supported Region: 15 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/logs/quotas/L-C029A21C)  | The maximum number of delete-log-stream calls per second per account/per region | 
| DeleteMetricFilter throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of delete-metric-filter calls per second per account/per region | 
| DeleteRetentionPolicy throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of delete-retention-policy calls per second per account/per region | 
| DeleteSubscriptionFilter throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of delete-subscription-filter calls per second per account/per region | 
| DeleteTransformer throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of delete-transformer calls per second per account/per region | 
| DescribeDestinations throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of describe-destinations calls per second per account/per region | 
| DescribeExportTasks throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of describe-export-tasks calls per second per account/per region | 
| DescribeImportTaskBatches throttle limit in transactions per second | Each supported Region: 10 | No | The maximum number of DescribeImportTaskBatches calls per second per account/per region | 
| DescribeImportTaskBatches throttle limit in transactions per second in a burst | Each supported Region: 10 | No | The maximum number of DescribeImportTaskBatches calls per second per account/per region in a burst | 
| DescribeImportTasks throttle limit in transactions per second | Each supported Region: 10 | No | The maximum number of DescribeImportTasks calls per second per account/per region | 
| DescribeImportTasks throttle limit in transactions per second in a burst | Each supported Region: 10 | No | The maximum number of DescribeImportTasks calls per second per account/per region in a burst | 
| DescribeLogGroups throttle limit in transactions per second | Each supported Region: 10 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/logs/quotas/L-4284EEDE)  | The maximum number of describe-log-groups calls per second per account/per region | 
| DescribeLogStreams throttle limit in transactions per second | Each supported Region: 25 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/logs/quotas/L-3F243AD0)  | The maximum number of describe-log-streams calls per second per account/per region | 
| DescribeMetricFilters throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of describe-metric-filters calls per second per account/per region | 
| DescribeSubscriptionFilters throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of describe-subscription-filters calls per second per account/per region | 
| DisassociateSourceFromS3TableIntegration throttle limit in transactions per second | Each supported Region: 5 | No | The maximum number of DisassociateSourceFromS3TableIntegration calls per second per account/per region | 
| DisassociateSourceFromS3TableIntegration throttle limit in transactions per second in a burst | Each supported Region: 10 | No | The maximum number of DisassociateSourceFromS3TableIntegration calls per second per account/per region in a burst | 
| Event size | Each supported Region: 1,024 Kilobytes | No | The maximum log event size in KB | 
| FilterLogEvents throttle limit in transactions per second | us-east-1: 25 per second<br />ap-northeast-3: 5 per second<br />ap-southeast-3: 5 per second<br />ca-west-1: 5 per second<br />eu-central-1: 5 per second<br />il-central-1: 5 per second<br />Each of the other supported Regions: 10 per second | No | The maximum number of filter-log-events calls per second per account/per region | 
| GetDataProtectionPolicy throttle limit in transactions per second | Each supported Region: 5 | No | The maximum number of get-data-protection-policy calls per second per account/per region | 
| GetLogEvents throttle limit in transactions per second | us-west-2: 10 per second<br />ap-northeast-3: 10 per second<br />ap-southeast-3: 10 per second<br />ca-west-1: 10 per second<br />eu-central-1: 10 per second<br />eu-west-1: 10 per second<br />eu-west-3: 30 per second<br />il-central-1: 10 per second<br />Each of the other supported Regions: 25 per second | No | The maximum number of get-log-events calls per second per account/per region | 
| GetQueryResults throttle limit in transactions per second | Each supported Region: 10 | No | The maximum number of get-query-results calls per second per account/per region | 
| GetTransformer throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of get-transformer calls per second per account/per region | 
| ListSourcesForS3TableIntegration throttle limit in transactions per second | Each supported Region: 5 | No | The maximum number of ListSourcesForS3TableIntegration calls per second per account/per region | 
| ListSourcesForS3TableIntegration throttle limit in transactions per second in a burst | Each supported Region: 10 | No | The maximum number of ListSourcesForS3TableIntegration calls per second per account/per region in a burst | 
| ListTagsForResource throttle limit in transactions per second | Each supported Region: 30 per second | No | The maximum number of list-tags-for-resource calls per second per account/per region | 
| ListTagsLogGroup throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of list-tags-log-group calls per second per account/per region | 
| Live Tail concurrent sessions limit | Each supported Region: 15 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/logs/quotas/L-D6990B80)  | The maximum number of concurrent active Live Tail sessions per account | 
| Log groups | Each supported Region: 1,000,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/logs/quotas/L-C7B9AAAB)  | The maximum number of log groups an account can have | 
| Log groups scanned per Live Tail session | Each supported Region: 10 | No | The maximum number of log groups that can be scanned per Live Tail session | 
| Metrics filters per log group | Each supported Region: 100 | No | The number of metric filters per log group | 
| PutBearerTokenAuthentication throttle limit in transactions per second | Each supported Region: 5 | No | The maximum number of put-bearer-token-authentication calls per second per account/per region | 
| PutBearerTokenAuthentication throttle limit in transactions per second in a burst | Each supported Region: 10 | No | The maximum number of put-bearer-token-authentication calls per second per account/per region in a burst | 
| PutDataProtectionPolicy throttle limit in transactions per second | Each supported Region: 5 | No | The maximum number of put-data-protection-policy calls per second per account/per region | 
| PutDestination throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of put-destination calls per second per account/per region | 
| PutDestinationPolicy throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of put-destination-policy calls per second per account/per region | 
| PutLogEvents throttle limit in transactions per second | Each supported Region: 5,000 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/logs/quotas/L-7E1FAE88)  | The maximum number of put-log-events calls per second per account/per region | 
| PutMetricFilter throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of put-metric-filter calls per second per account/per region | 
| PutRetentionPolicy throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of put-retention-policy calls per second per account/per region | 
| PutSubscriptionFilter throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of put-subscription-filter calls per second per account/per region | 
| PutTransformer throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of put-transformer calls per second per account/per region | 
| Resource policies | Each supported Region: 10 | No | The maximum number of resource policies per account/per region | 
| StartLiveTail throttle limit in transactions per second | Each supported Region: 5 | No | The maximum number of start-live-tail calls per second per account/per region. This limit applies independently to both console and API | 
| StartQuery throttle limit in transactions per second | Each supported Region: 10 | No | The maximum number of start-query calls per second per account/per region | 
| Subscription filters per log group | Each supported Region: 5 | No | The number of subscription filters per log group | 
| TagLogGroup throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of tag-log-group calls per second per account/per region | 
| TagResource throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of tag-resource calls per second per account/per region | 
| TestMetricFilter throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of test-metric-filter calls per second per account/per region | 
| TestTransformer throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of test-transformer calls per second per account/per region | 
| UntagLogGroup throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of untag-log-group calls per second per account/per region | 
| UntagResource throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of untag-resource calls per second per account/per region | 
| logs anomaly detectors | Each supported Region: 500 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/logs/quotas/L-B53B9649)  | The maximum number of active log anomaly detectors | 

## Managing your CloudWatch Logs service quotas
<a name="service-quotas-manage"></a>

CloudWatch Logs has integrated with Service Quotas, an AWS service that enables you to view and manage your quotas from a central location. For more information, see [What Is Service Quotas?](https://docs.aws.amazon.com/servicequotas/latest/userguide/intro.html) in the *Service Quotas User Guide*.

Service Quotas makes it easy to look up the value of your CloudWatch Logs service quotas.

------
#### [ AWS Management Console ]

**To view CloudWatch Logs service quotas using the console**

1. Open the Service Quotas console at [https://console.aws.amazon.com/servicequotas/](https://console.aws.amazon.com/servicequotas/).

1. In the navigation pane, choose **AWS services**.

1. From the **AWS services** list, search for and select **Amazon CloudWatch Logs**.

   In the **Service quotas** list, you can see the service quota name, applied value (if it is available), AWS default quota, and whether the quota value is adjustable.

1. To view additional information about a service quota, such as the description, choose the quota name.

1. (Optional) To request a quota increase, select the quota that you want to increase, select **Request quota increase**, enter or select the required information, and select **Request**.

To work more with service quotas using the console see the [Service Quotas User Guide](https://docs.aws.amazon.com/servicequotas/latest/userguide/intro.html). To request a quota increase, see [Requesting a quota increase](https://docs.aws.amazon.com/servicequotas/latest/userguide/request-quota-increase.html) in the *Service Quotas User Guide*.

------
#### [ AWS CLI ]

**To view CloudWatch Logs service quotas using the AWS CLI**  
Run the following command to view the default CloudWatch Logs quotas.

```
aws service-quotas list-aws-default-service-quotas \
    --query 'Quotas[*].{Adjustable:Adjustable,Name:QuotaName,Value:Value,Code:QuotaCode}' \
    --service-code logs \
    --output table
```

To work more with service quotas using the AWS CLI, see the [Service Quotas AWS CLI Command Reference](https://docs.aws.amazon.com/cli/latest/reference/service-quotas/index.html#cli-aws-service-quotas). To request a quota increase, see the [`request-service-quota-increase`](https://docs.aws.amazon.com/cli/latest/reference/service-quotas/request-service-quota-increase.html) command in the [AWS CLI Command Reference](https://docs.aws.amazon.com/cli/latest/reference/service-quotas/index.html#cli-aws-service-quotas).

------