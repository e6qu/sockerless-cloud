

# AWS CodeBuild endpoints and quotas
<a name="codebuild"></a>

To connect programmatically to an AWS service, you use an endpoint. AWS services offer the following endpoint types in some or all of the AWS Regions that the service supports: IPv4 endpoints, dual-stack endpoints, and FIPS endpoints. Some services provide global endpoints. For more information, see [AWS service endpoints](rande.md).

Service quotas, also referred to as limits, are the maximum number of service resources or operations for your AWS account. For more information, see [AWS service quotas](aws_service_limits.md).

The following are the service endpoints and service quotas for this service.

## Service endpoints
<a name="codebuild_region"></a>


| Region Name | Region | Endpoint | Protocol | 
| --- | --- | --- | --- | 
| US East (Ohio) | us-east-2 |  codebuild.us-east-2.amazonaws.com <br /> codebuild-fips.us-east-2.amazonaws.com  | HTTPS<br />HTTPS | 
| US East (N. Virginia) | us-east-1 |  codebuild.us-east-1.amazonaws.com <br /> codebuild-fips.us-east-1.amazonaws.com  | HTTPS<br />HTTPS | 
| US West (N. California) | us-west-1 |  codebuild.us-west-1.amazonaws.com <br /> codebuild-fips.us-west-1.amazonaws.com  | HTTPS<br />HTTPS | 
| US West (Oregon) | us-west-2 |  codebuild.us-west-2.amazonaws.com <br /> codebuild-fips.us-west-2.amazonaws.com  | HTTPS<br />HTTPS | 
| Africa (Cape Town) | af-south-1 |  codebuild.af-south-1.amazonaws.com  | HTTPS | 
| Asia Pacific (Hong Kong) | ap-east-1 |  codebuild.ap-east-1.amazonaws.com  | HTTPS | 
| Asia Pacific (Hyderabad) | ap-south-2 |  codebuild.ap-south-2.amazonaws.com  | HTTPS | 
| Asia Pacific (Jakarta) | ap-southeast-3 |  codebuild.ap-southeast-3.amazonaws.com  | HTTPS | 
| Asia Pacific (Malaysia) | ap-southeast-5 |  codebuild.ap-southeast-5.amazonaws.com  | HTTPS | 
| Asia Pacific (Melbourne) | ap-southeast-4 |  codebuild.ap-southeast-4.amazonaws.com  | HTTPS | 
| Asia Pacific (Mumbai) | ap-south-1 |  codebuild.ap-south-1.amazonaws.com  | HTTPS | 
| Asia Pacific (New Zealand) | ap-southeast-6 |  codebuild.ap-southeast-6.amazonaws.com  | HTTPS | 
| Asia Pacific (Osaka) | ap-northeast-3 |  codebuild.ap-northeast-3.amazonaws.com  | HTTPS | 
| Asia Pacific (Seoul) | ap-northeast-2 |  codebuild.ap-northeast-2.amazonaws.com  | HTTPS | 
| Asia Pacific (Singapore) | ap-southeast-1 |  codebuild.ap-southeast-1.amazonaws.com  | HTTPS | 
| Asia Pacific (Sydney) | ap-southeast-2 |  codebuild.ap-southeast-2.amazonaws.com  | HTTPS | 
| Asia Pacific (Thailand) | ap-southeast-7 |  codebuild.ap-southeast-7.amazonaws.com  | HTTPS | 
| Asia Pacific (Tokyo) | ap-northeast-1 |  codebuild.ap-northeast-1.amazonaws.com  | HTTPS | 
| Canada (Central) | ca-central-1 |  codebuild.ca-central-1.amazonaws.com  | HTTPS | 
| Europe (Frankfurt) | eu-central-1 |  codebuild.eu-central-1.amazonaws.com  | HTTPS | 
| Europe (Ireland) | eu-west-1 |  codebuild.eu-west-1.amazonaws.com  | HTTPS | 
| Europe (London) | eu-west-2 |  codebuild.eu-west-2.amazonaws.com  | HTTPS | 
| Europe (Milan) | eu-south-1 |  codebuild.eu-south-1.amazonaws.com  | HTTPS | 
| Europe (Paris) | eu-west-3 |  codebuild.eu-west-3.amazonaws.com  | HTTPS | 
| Europe (Spain) | eu-south-2 |  codebuild.eu-south-2.amazonaws.com  | HTTPS | 
| Europe (Stockholm) | eu-north-1 |  codebuild.eu-north-1.amazonaws.com  | HTTPS | 
| Europe (Zurich) | eu-central-2 |  codebuild.eu-central-2.amazonaws.com  | HTTPS | 
| Israel (Tel Aviv) | il-central-1 |  codebuild.il-central-1.amazonaws.com  | HTTPS | 
| Middle East (Bahrain) | me-south-1 |  codebuild.me-south-1.amazonaws.com  | HTTPS | 
| Middle East (UAE) | me-central-1 |  codebuild.me-central-1.amazonaws.com  | HTTPS | 
| South America (São Paulo) | sa-east-1 |  codebuild.sa-east-1.amazonaws.com  | HTTPS | 
|  AWS GovCloud (US-East) | us-gov-east-1 |  codebuild.us-gov-east-1.amazonaws.com <br /> codebuild-fips.us-gov-east-1.amazonaws.com  | HTTPS<br />HTTPS | 
|  AWS GovCloud (US-West) | us-gov-west-1 |  codebuild.us-gov-west-1.amazonaws.com <br /> codebuild-fips.us-gov-west-1.amazonaws.com  | HTTPS<br />HTTPS | 

## Service quotas
<a name="limits_codebuild"></a>


| Name | Default | Adjustable | Description | 
| --- | --- | --- | --- | 
| Associated tags per project | Each supported Region: 50 | No | Maximum number of tags you can associate with a build project | 
| Build projects | Each supported Region: 5,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/codebuild/quotas/L-ACCF6C0D)  | Maximum number of build projects | 
| Build timeout in minutes | Each supported Region: 2,160 | No | Maximum build timeout in minutes | 
| Concurrent request for information about builds | Each supported Region: 100 | No | Maximum number of builds you can request information about at any one time using the AWS CLI or an AWS SDK. | 
| Concurrent requests for information on build projects | Each supported Region: 100 | No | Maximum number of build projects you can request information about at any one time using the AWS CLI or an AWS SDK. | 
| Concurrently running builds for ARM Lambda/10GB environment | Each supported Region: 1 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/codebuild/quotas/L-36AF3CA5)  | Maximum number of concurrently running builds for ARM Lambda/10GB environment | 
| Concurrently running builds for ARM Lambda/1GB environment | Each supported Region: 1 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/codebuild/quotas/L-FD92223D)  | Maximum number of concurrently running builds for ARM Lambda/1GB environment | 
| Concurrently running builds for ARM Lambda/2GB environment | Each supported Region: 1 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/codebuild/quotas/L-DE99852F)  | Maximum number of concurrently running builds for ARM Lambda/2GB environment | 
| Concurrently running builds for ARM Lambda/4GB environment | Each supported Region: 1 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/codebuild/quotas/L-72045165)  | Maximum number of concurrently running builds for ARM Lambda/4GB environment | 
| Concurrently running builds for ARM Lambda/8GB environment | Each supported Region: 1 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/codebuild/quotas/L-546A802A)  | Maximum number of concurrently running builds for ARM Lambda/8GB environment | 
| Concurrently running builds for ARM/2XLarge environment | Each supported Region: 1 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/codebuild/quotas/L-1E43FDE0)  | Maximum number of concurrently running builds for ARM/2XLarge environment | 
| Concurrently running builds for ARM/Large environment | Each supported Region: 1 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/codebuild/quotas/L-596BEAB4)  | Maximum number of concurrently running builds for ARM/Large environment | 
| Concurrently running builds for ARM/Medium environment | Each supported Region: 1 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/codebuild/quotas/L-DF544FF3)  | Maximum number of concurrently running builds for ARM/Medium environment | 
| Concurrently running builds for ARM/Small environment | Each supported Region: 1 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/codebuild/quotas/L-5ED1D25B)  | Maximum number of concurrently running builds for ARM/Small environment | 
| Concurrently running builds for ARM/XLarge environment | Each supported Region: 1 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/codebuild/quotas/L-8D06F3EA)  | Maximum number of concurrently running builds for ARM/XLarge environment | 
| Concurrently running builds for Linux GPU Large environment | Each supported Region: 0 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/codebuild/quotas/L-D906BEE7)  | Maximum number of concurrently running builds for Linux GPU/Large environment | 
| Concurrently running builds for Linux GPU Small environment | Each supported Region: 0 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/codebuild/quotas/L-F1FE1B52)  | Maximum number of concurrently running builds for Linux GPU/Small environment | 
| Concurrently running builds for Linux Lambda/10GB environment | Each supported Region: 1 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/codebuild/quotas/L-E692F494)  | Maximum number of concurrently running builds for Linux Lambda/10GB environment | 
| Concurrently running builds for Linux Lambda/1GB environment | Each supported Region: 1 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/codebuild/quotas/L-03FBB1ED)  | Maximum number of concurrently running builds for Linux Lambda/1GB environment | 
| Concurrently running builds for Linux Lambda/2GB environment | Each supported Region: 1 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/codebuild/quotas/L-1DFDD5F9)  | Maximum number of concurrently running builds for Linux Lambda/2GB environment | 
| Concurrently running builds for Linux Lambda/4GB environment | Each supported Region: 1 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/codebuild/quotas/L-39DB2B0B)  | Maximum number of concurrently running builds for Linux Lambda/4GB environment | 
| Concurrently running builds for Linux Lambda/8GB environment | Each supported Region: 1 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/codebuild/quotas/L-049948E0)  | Maximum number of concurrently running builds for Linux Lambda/8GB environment | 
| Concurrently running builds for Linux/2XLarge environment | Each supported Region: 0 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/codebuild/quotas/L-0397D009)  | Maximum number of concurrently running builds for Linux/2XLarge environment | 
| Concurrently running builds for Linux/Large environment | Each supported Region: 1 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/codebuild/quotas/L-4DDC4A99)  | Maximum number of concurrently running builds for Linux/Large environment | 
| Concurrently running builds for Linux/Medium environment | Each supported Region: 1 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/codebuild/quotas/L-2DC20C30)  | Maximum number of concurrently running builds for Linux/Medium environment | 
| Concurrently running builds for Linux/Small environment | Each supported Region: 1 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/codebuild/quotas/L-9D07B6EF)  | Maximum number of concurrently running builds for Linux/Small environment | 
| Concurrently running builds for Linux/XLarge environment | Each supported Region: 1 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/codebuild/quotas/L-04E5CA62)  | Maximum number of concurrently running builds for Linux/XLarge environment | 
| Concurrently running builds for Windows Server 2019/Large environment | Each supported Region: 1 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/codebuild/quotas/L-2C3490D7)  | Maximum number of concurrently running builds for Windows Server 2019/Large environment | 
| Concurrently running builds for Windows Server 2019/Medium environment | Each supported Region: 1 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/codebuild/quotas/L-ECF1B2A0)  | Maximum number of concurrently running builds for Windows Server 2019/Medium environment | 
| Concurrently running builds for Windows Server 2022/2XLarge environment | Each supported Region: 1 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/codebuild/quotas/L-0DED26C7)  | Maximum number of concurrently running builds for Windows Server 2022/2XLarge environment | 
| Concurrently running builds for Windows Server 2022/Large environment | Each supported Region: 1 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/codebuild/quotas/L-C3D92D78)  | Maximum number of concurrently running builds for Windows Server 2022/Large environment | 
| Concurrently running builds for Windows Server 2022/Medium environment | Each supported Region: 1 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/codebuild/quotas/L-0544DB6A)  | Maximum number of concurrently running builds for Windows Server 2022/Medium environment | 
| Concurrently running builds for Windows Server 2022/XLarge environment | Each supported Region: 1 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/codebuild/quotas/L-F2D50796)  | Maximum number of concurrently running builds for Windows Server 2022/XLarge environment | 
| Concurrently running builds for Windows/Large environment | Each supported Region: 1 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/codebuild/quotas/L-4135EDF8)  | Maximum number of concurrently running builds for Windows/Large environment | 
| Concurrently running builds for Windows/Medium environment | Each supported Region: 1 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/codebuild/quotas/L-B4157408)  | Maximum number of concurrently running builds for Windows/Medium environment | 
| Minimum period for build timeout in minutes | Each supported Region: 5 | No | Minimum build timeout in minutes | 
| Security groups under VPC configuration | Each supported Region: 5 | No | Security groups available for VPC configuration | 
| Subnets under VPC configuration | Each supported Region: 16 | No | Subnets available for VPC configuration | 

**Note**  
Internal metrics will determine the default quotas for concurrent running builds.

For more information, see [Quotas for CodeBuild](https://docs.aws.amazon.com/codebuild/latest/userguide/limits.html) in the *AWS CodeBuild User Guide*.