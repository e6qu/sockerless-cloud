

# Amazon Simple Storage Service endpoints and quotas
<a name="s3"></a>

To connect programmatically to an AWS service, you use an endpoint. AWS services offer the following endpoint types in some or all of the AWS Regions that the service supports: IPv4 endpoints, dual-stack endpoints, and FIPS endpoints. Some services provide global endpoints. For more information, see [AWS service endpoints](rande.md).

Service quotas, also referred to as limits, are the maximum number of service resources or operations for your AWS account. For more information, see [AWS service quotas](aws_service_limits.md).

The following are the service endpoints and service quotas for this service.

## Service endpoints
<a name="s3_region"></a>

### Amazon S3 endpoints
<a name="s3-core"></a>

When you use the REST API to send requests to the endpoints shown in the following table, you can use the virtual-hosted style and path-style methods. For more information, see [Virtual hosting of buckets](https://docs.aws.amazon.com/AmazonS3/latest/userguide/VirtualHosting.html).

**Note**  
Some Regions support legacy endpoints. For information about Amazon S3 backward compatibility for path-style and virtual-hosted–style URL requests, see [Backward compatibility](https://docs.aws.amazon.com/AmazonS3/latest/userguide/VirtualHosting.html#VirtualHostingBackwardsCompatibility).

#### Amazon S3 regular endpoints
<a name="auto-endpoints-s3"></a>


| Region Name | Region | Endpoint | Protocol | Signature Version(s) Support | 
| --- | --- | --- | --- | --- | 
| US East (Ohio) | us-east-2 |  s3.us-east-2.amazonaws.com <br /> s3.dualstack.us-east-2.amazonaws.com <br /> s3-fips.dualstack.us-east-2.amazonaws.com <br /> s3-fips.us-east-2.amazonaws.com  | HTTP and HTTPS<br />HTTP and HTTPS<br />HTTPS<br />HTTPS | 4<br /><br /><br /> | 
| US East (N. Virginia) | us-east-1 |  s3.us-east-1.amazonaws.com <br /> s3.dualstack.us-east-1.amazonaws.com <br /> s3-fips.us-east-1.amazonaws.com <br /> s3-fips.dualstack.us-east-1.amazonaws.com  | HTTP and HTTPS<br />HTTP and HTTPS<br />HTTPS<br />HTTPS | 2 & 4<br /><br /><br /> | 
| US West (N. California) | us-west-1 |  s3.us-west-1.amazonaws.com <br /> s3.dualstack.us-west-1.amazonaws.com <br /> s3-fips.dualstack.us-west-1.amazonaws.com <br /> s3-fips.us-west-1.amazonaws.com  | HTTP and HTTPS<br />HTTP and HTTPS<br />HTTPS<br />HTTPS | 2 & 4<br /><br /><br /> | 
| US West (Oregon) | us-west-2 |  s3.us-west-2.amazonaws.com <br /> s3.dualstack.us-west-2.amazonaws.com <br /> s3-fips.dualstack.us-west-2.amazonaws.com <br /> s3-fips.us-west-2.amazonaws.com  | HTTP and HTTPS<br />HTTP and HTTPS<br />HTTPS<br />HTTPS | 2 & 4<br /><br /><br /> | 
| Africa (Cape Town) | af-south-1 |  s3.af-south-1.amazonaws.com <br /> s3.dualstack.af-south-1.amazonaws.com  | HTTP and HTTPS<br />HTTP and HTTPS | 4<br /> | 
| Asia Pacific (Hong Kong) | ap-east-1 |  s3.ap-east-1.amazonaws.com <br /> s3.dualstack.ap-east-1.amazonaws.com  | HTTP and HTTPS<br />HTTP and HTTPS | 4<br /> | 
| Asia Pacific (Hyderabad) | ap-south-2 |  s3.ap-south-2.amazonaws.com <br /> s3.dualstack.ap-south-2.amazonaws.com  | HTTP and HTTPS<br />HTTP and HTTPS | 4<br /> | 
| Asia Pacific (Jakarta) | ap-southeast-3 |  s3.ap-southeast-3.amazonaws.com <br /> s3.dualstack.ap-southeast-3.amazonaws.com  | HTTP and HTTPS<br />HTTP and HTTPS | 4<br /> | 
| Asia Pacific (Malaysia) | ap-southeast-5 |  s3.ap-southeast-5.amazonaws.com <br /> s3.dualstack.ap-southeast-5.amazonaws.com  | HTTP and HTTPS<br />HTTP and HTTPS | 4<br /> | 
| Asia Pacific (Melbourne) | ap-southeast-4 |  s3.ap-southeast-4.amazonaws.com <br /> s3.dualstack.ap-southeast-4.amazonaws.com  | HTTP and HTTPS<br />HTTP and HTTPS | 4<br /> | 
| Asia Pacific (Mumbai) | ap-south-1 |  s3.ap-south-1.amazonaws.com <br /> s3.dualstack.ap-south-1.amazonaws.com  | HTTP and HTTPS<br />HTTP and HTTPS | 4<br /> | 
| Asia Pacific (New Zealand) | ap-southeast-6 |  s3.ap-southeast-6.amazonaws.com <br /> s3.dualstack.ap-southeast-6.amazonaws.com  | HTTP and HTTPS<br />HTTP and HTTPS | 4<br /> | 
| Asia Pacific (Osaka) | ap-northeast-3 |  s3.ap-northeast-3.amazonaws.com <br /> s3.dualstack.ap-northeast-3.amazonaws.com  | HTTP and HTTPS<br />HTTP and HTTPS | 4<br /> | 
| Asia Pacific (Seoul) | ap-northeast-2 |  s3.ap-northeast-2.amazonaws.com <br /> s3.dualstack.ap-northeast-2.amazonaws.com  | HTTP and HTTPS<br />HTTP and HTTPS | 4<br /> | 
| Asia Pacific (Singapore) | ap-southeast-1 |  s3.ap-southeast-1.amazonaws.com <br /> s3.dualstack.ap-southeast-1.amazonaws.com  | HTTP and HTTPS<br />HTTP and HTTPS | 2 & 4<br /> | 
| Asia Pacific (Sydney) | ap-southeast-2 |  s3.ap-southeast-2.amazonaws.com <br /> s3.dualstack.ap-southeast-2.amazonaws.com  | HTTP and HTTPS<br />HTTP and HTTPS | 2 & 4<br /> | 
| Asia Pacific (Taipei) | ap-east-2 |  s3.ap-east-2.amazonaws.com <br /> s3.dualstack.ap-east-2.amazonaws.com  | HTTP and HTTPS<br />HTTP and HTTPS | 4<br /> | 
| Asia Pacific (Thailand) | ap-southeast-7 |  s3.ap-southeast-7.amazonaws.com <br /> s3.dualstack.ap-southeast-7.amazonaws.com  | HTTP and HTTPS<br />HTTP and HTTPS | 4<br /> | 
| Asia Pacific (Tokyo) | ap-northeast-1 |  s3.ap-northeast-1.amazonaws.com <br /> s3.dualstack.ap-northeast-1.amazonaws.com  | HTTP and HTTPS<br />HTTP and HTTPS | 2 & 4<br /> | 
| Canada (Central) | ca-central-1 |  s3.ca-central-1.amazonaws.com <br /> s3.dualstack.ca-central-1.amazonaws.com <br /> s3-fips.dualstack.ca-central-1.amazonaws.com <br /> s3-fips.ca-central-1.amazonaws.com  | HTTP and HTTPS<br />HTTP and HTTPS<br />HTTPS<br />HTTPS | 4<br /><br /><br /> | 
| Canada West (Calgary) | ca-west-1 |  s3.ca-west-1.amazonaws.com <br /> s3.dualstack.ca-west-1.amazonaws.com <br /> s3-fips.dualstack.ca-west-1.amazonaws.com <br /> s3-fips.ca-west-1.amazonaws.com  | HTTP and HTTPS<br />HTTP and HTTPS<br />HTTPS<br />HTTPS | 4<br /><br /><br /> | 
| Europe (Frankfurt) | eu-central-1 |  s3.eu-central-1.amazonaws.com <br /> s3.dualstack.eu-central-1.amazonaws.com  | HTTP and HTTPS<br />HTTP and HTTPS | 4<br /> | 
| Europe (Ireland) | eu-west-1 |  s3.eu-west-1.amazonaws.com <br /> s3.dualstack.eu-west-1.amazonaws.com  | HTTP and HTTPS<br />HTTP and HTTPS | 2 & 4<br /> | 
| Europe (London) | eu-west-2 |  s3.eu-west-2.amazonaws.com <br /> s3.dualstack.eu-west-2.amazonaws.com  | HTTP and HTTPS<br />HTTP and HTTPS | 4<br /> | 
| Europe (Milan) | eu-south-1 |  s3.eu-south-1.amazonaws.com <br /> s3.dualstack.eu-south-1.amazonaws.com  | HTTP and HTTPS<br />HTTP and HTTPS | 4<br /> | 
| Europe (Paris) | eu-west-3 |  s3.eu-west-3.amazonaws.com <br /> s3.dualstack.eu-west-3.amazonaws.com  | HTTP and HTTPS<br />HTTP and HTTPS | 4<br /> | 
| Europe (Spain) | eu-south-2 |  s3.eu-south-2.amazonaws.com <br /> s3.dualstack.eu-south-2.amazonaws.com  | HTTP and HTTPS<br />HTTP and HTTPS | 4<br /> | 
| Europe (Stockholm) | eu-north-1 |  s3.eu-north-1.amazonaws.com <br /> s3.dualstack.eu-north-1.amazonaws.com  | HTTP and HTTPS<br />HTTP and HTTPS | 4<br /> | 
| Europe (Zurich) | eu-central-2 |  s3.eu-central-2.amazonaws.com <br /> s3.dualstack.eu-central-2.amazonaws.com  | HTTP and HTTPS<br />HTTP and HTTPS | 4<br /> | 
| Israel (Tel Aviv) | il-central-1 |  s3.il-central-1.amazonaws.com <br /> s3.dualstack.il-central-1.amazonaws.com  | HTTP and HTTPS<br />HTTP and HTTPS | 4<br /> | 
| Mexico (Central) | mx-central-1 |  s3.mx-central-1.amazonaws.com <br /> s3.dualstack.mx-central-1.amazonaws.com  | HTTP and HTTPS<br />HTTP and HTTPS | 4<br /> | 
| Middle East (Bahrain) | me-south-1 |  s3.me-south-1.amazonaws.com <br /> s3.dualstack.me-south-1.amazonaws.com  | HTTP and HTTPS<br />HTTP and HTTPS | 4<br /> | 
| Middle East (UAE) | me-central-1 |  s3.me-central-1.amazonaws.com <br /> s3.dualstack.me-central-1.amazonaws.com  | HTTP and HTTPS<br />HTTP and HTTPS | 4<br /> | 
| South America (São Paulo) | sa-east-1 |  s3.sa-east-1.amazonaws.com <br /> s3.dualstack.sa-east-1.amazonaws.com  | HTTP and HTTPS<br />HTTP and HTTPS | 2 & 4<br /> | 
|  AWS GovCloud (US-East) | us-gov-east-1 |  s3.us-gov-east-1.amazonaws.com <br /> s3-fips.dualstack.us-gov-east-1.amazonaws.com <br /> s3.dualstack.us-gov-east-1.amazonaws.com <br /> s3-fips.us-gov-east-1.amazonaws.com  | HTTP and HTTPS<br />HTTPS<br />HTTP and HTTPS<br />HTTP | 4<br /><br /><br /> | 
|  AWS GovCloud (US-West) | us-gov-west-1 |  s3.us-gov-west-1.amazonaws.com <br /> s3-fips.dualstack.us-gov-west-1.amazonaws.com <br /> s3.dualstack.us-gov-west-1.amazonaws.com <br /> s3-fips.us-gov-west-1.amazonaws.com  | HTTP and HTTPS<br />HTTPS<br />HTTP and HTTPS<br />HTTP | 2 & 4<br /><br /><br /> | 

#### Amazon S3 Tables endpoints
<a name="s3-tables"></a>

The `s3-tables` endpoints are used only with Amazon S3 Tables operations. For more information, see [Working with Amazon S3 Tables and table buckets](https://docs.aws.amazon.com/AmazonS3/latest/userguide/s3-tables.html). 


| Region Name | Region | Endpoint | Protocol | 
| --- | --- | --- | --- | 
| US East (Ohio) | us-east-2 |  s3tables.us-east-2.amazonaws.com  | HTTPS | 
| US East (N. Virginia) | us-east-1 |  s3tables.us-east-1.amazonaws.com  | HTTPS | 
| US West (N. California) | us-west-1 |  s3tables.us-west-1.amazonaws.com  | HTTPS | 
| US West (Oregon) | us-west-2 |  s3tables.us-west-2.amazonaws.com  | HTTPS | 
| Africa (Cape Town) | af-south-1 |  s3tables.af-south-1.amazonaws.com  | HTTPS | 
| Asia Pacific (Hong Kong) | ap-east-1 |  s3tables.ap-east-1.amazonaws.com  | HTTPS | 
| Asia Pacific (Hyderabad) | ap-south-2 |  s3tables.ap-south-2.amazonaws.com  | HTTPS | 
| Asia Pacific (Jakarta) | ap-southeast-3 |  s3tables.ap-southeast-3.amazonaws.com  | HTTPS | 
| Asia Pacific (Malaysia) | ap-southeast-5 |  s3tables.ap-southeast-5.amazonaws.com  | HTTPS | 
| Asia Pacific (Melbourne) | ap-southeast-4 |  s3tables.ap-southeast-4.amazonaws.com  | HTTPS | 
| Asia Pacific (Mumbai) | ap-south-1 |  s3tables.ap-south-1.amazonaws.com  | HTTPS | 
| Asia Pacific (New Zealand) | ap-southeast-6 |  s3tables.ap-southeast-6.amazonaws.com  | HTTPS | 
| Asia Pacific (Osaka) | ap-northeast-3 |  s3tables.ap-northeast-3.amazonaws.com  | HTTPS | 
| Asia Pacific (Seoul) | ap-northeast-2 |  s3tables.ap-northeast-2.amazonaws.com  | HTTPS | 
| Asia Pacific (Singapore) | ap-southeast-1 |  s3tables.ap-southeast-1.amazonaws.com  | HTTPS | 
| Asia Pacific (Sydney) | ap-southeast-2 |  s3tables.ap-southeast-2.amazonaws.com  | HTTPS | 
| Asia Pacific (Taipei) | ap-east-2 |  s3tables.ap-east-2.amazonaws.com  | HTTPS | 
| Asia Pacific (Thailand) | ap-southeast-7 |  s3tables.ap-southeast-7.amazonaws.com  | HTTPS | 
| Asia Pacific (Tokyo) | ap-northeast-1 |  s3tables.ap-northeast-1.amazonaws.com  | HTTPS | 
| Canada (Central) | ca-central-1 |  s3tables.ca-central-1.amazonaws.com  | HTTPS | 
| Canada West (Calgary) | ca-west-1 |  s3tables.ca-west-1.amazonaws.com  | HTTPS | 
| Europe (Frankfurt) | eu-central-1 |  s3tables.eu-central-1.amazonaws.com  | HTTPS | 
| Europe (Ireland) | eu-west-1 |  s3tables.eu-west-1.amazonaws.com  | HTTPS | 
| Europe (London) | eu-west-2 |  s3tables.eu-west-2.amazonaws.com  | HTTPS | 
| Europe (Milan) | eu-south-1 |  s3tables.eu-south-1.amazonaws.com  | HTTPS | 
| Europe (Paris) | eu-west-3 |  s3tables.eu-west-3.amazonaws.com  | HTTPS | 
| Europe (Spain) | eu-south-2 |  s3tables.eu-south-2.amazonaws.com  | HTTPS | 
| Europe (Stockholm) | eu-north-1 |  s3tables.eu-north-1.amazonaws.com  | HTTPS | 
| Europe (Zurich) | eu-central-2 |  s3tables.eu-central-2.amazonaws.com  | HTTPS | 
| Israel (Tel Aviv) | il-central-1 |  s3tables.il-central-1.amazonaws.com  | HTTPS | 
| Mexico (Central) | mx-central-1 |  s3tables.mx-central-1.amazonaws.com  | HTTPS | 
| Middle East (Bahrain) | me-south-1 |  s3tables.me-south-1.amazonaws.com  | HTTPS | 
| Middle East (UAE) | me-central-1 |  s3tables.me-central-1.amazonaws.com  | HTTPS | 
| South America (São Paulo) | sa-east-1 |  s3tables.sa-east-1.amazonaws.com  | HTTPS | 
|  AWS GovCloud (US-East) | us-gov-east-1 |  s3tables.us-gov-east-1.amazonaws.com  | HTTPS | 
|  AWS GovCloud (US-West) | us-gov-west-1 |  s3tables.us-gov-west-1.amazonaws.com  | HTTPS | 

#### Amazon S3 Access Point endpoints
<a name="auto-endpoints-ap-s3"></a>

The `s3-accesspoint` endpoints are used only to make requests through Amazon S3 Access Points. For more information, see [Working with Amazon S3 Access Points](https://docs.aws.amazon.com/AmazonS3/latest/dev/access-points.html).

To interact with these endpoints you must precede the endpoint name with the relevant Access Point name in one of the following formats:

{{access-point}}.s3-accesspoint.{{AWS Region code}}.amazonaws.com

{{access-point}}.s3-accesspoint-fips.dualstack.{{AWS Region code}}.amazonaws.com

{{access-point}}.s3-accesspoint-fips.{{AWS Region code}}.amazonaws.com

{{access-point}}.s3-accesspoint.dualstack.{{AWS Region code}}.amazonaws.com


| Region Name | Region | Endpoint | Protocol | 
| --- | --- | --- | --- | 
| US East (Ohio) | us-east-2 |  s3-accesspoint.us-east-2.amazonaws.com <br /> s3-accesspoint-fips.dualstack.us-east-2.amazonaws.com <br /> s3-accesspoint-fips.us-east-2.amazonaws.com <br /> s3-accesspoint.dualstack.us-east-2.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| US East (N. Virginia) | us-east-1 |  s3-accesspoint.us-east-1.amazonaws.com <br /> s3-accesspoint-fips.dualstack.us-east-1.amazonaws.com <br /> s3-accesspoint-fips.us-east-1.amazonaws.com <br /> s3-accesspoint.dualstack.us-east-1.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| US West (N. California) | us-west-1 |  s3-accesspoint.us-west-1.amazonaws.com <br /> s3-accesspoint-fips.dualstack.us-west-1.amazonaws.com <br /> s3-accesspoint-fips.us-west-1.amazonaws.com <br /> s3-accesspoint.dualstack.us-west-1.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| US West (Oregon) | us-west-2 |  s3-accesspoint.us-west-2.amazonaws.com <br /> s3-accesspoint-fips.dualstack.us-west-2.amazonaws.com <br /> s3-accesspoint-fips.us-west-2.amazonaws.com <br /> s3-accesspoint.dualstack.us-west-2.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Africa (Cape Town) | af-south-1 |  s3-accesspoint.af-south-1.amazonaws.com <br /> s3-accesspoint.dualstack.af-south-1.amazonaws.com  | HTTPS<br />HTTPS | 
| Asia Pacific (Hong Kong) | ap-east-1 |  s3-accesspoint.ap-east-1.amazonaws.com <br /> s3-accesspoint.dualstack.ap-east-1.amazonaws.com  | HTTPS<br />HTTPS | 
| Asia Pacific (Hyderabad) | ap-south-2 |  s3-accesspoint.ap-south-2.amazonaws.com <br /> s3-accesspoint.dualstack.ap-south-2.amazonaws.com  | HTTPS<br />HTTPS | 
| Asia Pacific (Jakarta) | ap-southeast-3 |  s3-accesspoint.ap-southeast-3.amazonaws.com <br /> s3-accesspoint.dualstack.ap-southeast-3.amazonaws.com  | HTTPS<br />HTTPS | 
| Asia Pacific (Malaysia) | ap-southeast-5 |  s3-accesspoint.ap-southeast-5.amazonaws.com <br /> s3-accesspoint.dualstack.ap-southeast-5.amazonaws.com  | HTTPS<br />HTTPS | 
| Asia Pacific (Melbourne) | ap-southeast-4 |  s3-accesspoint.ap-southeast-4.amazonaws.com <br /> s3-accesspoint.dualstack.ap-southeast-4.amazonaws.com  | HTTPS<br />HTTPS | 
| Asia Pacific (Mumbai) | ap-south-1 |  s3-accesspoint.ap-south-1.amazonaws.com <br /> s3-accesspoint.dualstack.ap-south-1.amazonaws.com  | HTTPS<br />HTTPS | 
| Asia Pacific (New Zealand) | ap-southeast-6 |  s3-accesspoint.ap-southeast-6.amazonaws.com <br /> s3-accesspoint.dualstack.ap-southeast-6.amazonaws.com  | HTTPS<br />HTTPS | 
| Asia Pacific (Osaka) | ap-northeast-3 |  s3-accesspoint.ap-northeast-3.amazonaws.com <br /> s3-accesspoint.dualstack.ap-northeast-3.amazonaws.com  | HTTPS<br />HTTPS | 
| Asia Pacific (Seoul) | ap-northeast-2 |  s3-accesspoint.ap-northeast-2.amazonaws.com <br /> s3-accesspoint.dualstack.ap-northeast-2.amazonaws.com  | HTTPS<br />HTTPS | 
| Asia Pacific (Singapore) | ap-southeast-1 |  s3-accesspoint.ap-southeast-1.amazonaws.com <br /> s3-accesspoint.dualstack.ap-southeast-1.amazonaws.com  | HTTPS<br />HTTPS | 
| Asia Pacific (Sydney) | ap-southeast-2 |  s3-accesspoint.ap-southeast-2.amazonaws.com <br /> s3-accesspoint.dualstack.ap-southeast-2.amazonaws.com  | HTTPS<br />HTTPS | 
| Asia Pacific (Taipei) | ap-east-2 |  s3-accesspoint.ap-east-2.amazonaws.com <br /> s3-accesspoint.dualstack.ap-east-2.amazonaws.com  | HTTPS<br />HTTPS | 
| Asia Pacific (Thailand) | ap-southeast-7 |  s3-accesspoint.ap-southeast-7.amazonaws.com <br /> s3-accesspoint.dualstack.ap-southeast-7.amazonaws.com  | HTTPS<br />HTTPS | 
| Asia Pacific (Tokyo) | ap-northeast-1 |  s3-accesspoint.ap-northeast-1.amazonaws.com <br /> s3-accesspoint.dualstack.ap-northeast-1.amazonaws.com  | HTTPS<br />HTTPS | 
| Canada (Central) | ca-central-1 |  s3-accesspoint.ca-central-1.amazonaws.com <br /> s3-accesspoint-fips.dualstack.ca-central-1.amazonaws.com <br /> s3-accesspoint-fips.ca-central-1.amazonaws.com <br /> s3-accesspoint.dualstack.ca-central-1.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Canada West (Calgary) | ca-west-1 |  s3-accesspoint.ca-west-1.amazonaws.com <br /> s3-accesspoint-fips.dualstack.ca-west-1.amazonaws.com <br /> s3-accesspoint-fips.ca-west-1.amazonaws.com <br /> s3-accesspoint.dualstack.ca-west-1.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Europe (Frankfurt) | eu-central-1 |  s3-accesspoint.eu-central-1.amazonaws.com <br /> s3-accesspoint.dualstack.eu-central-1.amazonaws.com  | HTTPS<br />HTTPS | 
| Europe (Ireland) | eu-west-1 |  s3-accesspoint.eu-west-1.amazonaws.com <br /> s3-accesspoint.dualstack.eu-west-1.amazonaws.com  | HTTPS<br />HTTPS | 
| Europe (London) | eu-west-2 |  s3-accesspoint.eu-west-2.amazonaws.com <br /> s3-accesspoint.dualstack.eu-west-2.amazonaws.com  | HTTPS<br />HTTPS | 
| Europe (Milan) | eu-south-1 |  s3-accesspoint.eu-south-1.amazonaws.com <br /> s3-accesspoint.dualstack.eu-south-1.amazonaws.com  | HTTPS<br />HTTPS | 
| Europe (Paris) | eu-west-3 |  s3-accesspoint.eu-west-3.amazonaws.com <br /> s3-accesspoint.dualstack.eu-west-3.amazonaws.com  | HTTPS<br />HTTPS | 
| Europe (Spain) | eu-south-2 |  s3-accesspoint.eu-south-2.amazonaws.com <br /> s3-accesspoint.dualstack.eu-south-2.amazonaws.com  | HTTPS<br />HTTPS | 
| Europe (Stockholm) | eu-north-1 |  s3-accesspoint.eu-north-1.amazonaws.com <br /> s3-accesspoint.dualstack.eu-north-1.amazonaws.com  | HTTPS<br />HTTPS | 
| Europe (Zurich) | eu-central-2 |  s3-accesspoint.eu-central-2.amazonaws.com <br /> s3-accesspoint.dualstack.eu-central-2.amazonaws.com  | HTTPS<br />HTTPS | 
| Israel (Tel Aviv) | il-central-1 |  s3-accesspoint.il-central-1.amazonaws.com <br /> s3-accesspoint.dualstack.il-central-1.amazonaws.com  | HTTPS<br />HTTPS | 
| Mexico (Central) | mx-central-1 |  s3-accesspoint.mx-central-1.amazonaws.com <br /> s3-accesspoint.dualstack.mx-central-1.amazonaws.com  | HTTPS<br />HTTPS | 
| Middle East (Bahrain) | me-south-1 |  s3-accesspoint.me-south-1.amazonaws.com <br /> s3-accesspoint.dualstack.me-south-1.amazonaws.com  | HTTPS<br />HTTPS | 
| Middle East (UAE) | me-central-1 |  s3-accesspoint.me-central-1.amazonaws.com <br /> s3-accesspoint.dualstack.me-central-1.amazonaws.com  | HTTPS<br />HTTPS | 
| South America (São Paulo) | sa-east-1 |  s3-accesspoint.sa-east-1.amazonaws.com <br /> s3-accesspoint.dualstack.sa-east-1.amazonaws.com  | HTTPS<br />HTTPS | 
|  AWS GovCloud (US-East) | us-gov-east-1 |  s3-accesspoint.us-gov-east-1.amazonaws.com <br /> s3-accesspoint-fips.dualstack.us-gov-east-1.amazonaws.com <br /> s3-accesspoint-fips.us-gov-east-1.amazonaws.com <br /> s3-accesspoint.dualstack.us-gov-east-1.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
|  AWS GovCloud (US-West) | us-gov-west-1 |  s3-accesspoint.us-gov-west-1.amazonaws.com <br /> s3-accesspoint-fips.dualstack.us-gov-west-1.amazonaws.com <br /> s3-accesspoint-fips.us-gov-west-1.amazonaws.com <br /> s3-accesspoint.dualstack.us-gov-west-1.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 

#### Amazon S3 Control endpoints
<a name="auto-endpoints-control-s3"></a>

The `s3-control` endpoints are used with Amazon S3 account-level operations. To interact with these endpoints you must precede the endpoint name with the relevant AWS account ID in one of the following formats:

{{account-id}}.s3-control.{{AWS Region code}}.amazonaws.com

{{account-id}}.s3-control.dualstack.{{AWS Region code}}.amazonaws.com

{{account-id}}.s3-control-fips.dualstack.{{AWS Region code}}.amazonaws.com

{{account-id}}.s3-control-fips.{{AWS Region code}}.amazonaws.com


| Region Name | Region | Endpoint | Protocol | 
| --- | --- | --- | --- | 
| US East (Ohio) | us-east-2 |  s3-control.us-east-2.amazonaws.com <br /> s3-control.dualstack.us-east-2.amazonaws.com <br /> s3-control-fips.dualstack.us-east-2.amazonaws.com <br /> s3-control-fips.us-east-2.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| US East (N. Virginia) | us-east-1 |  s3-control.us-east-1.amazonaws.com <br /> s3-control-fips.us-east-1.amazonaws.com <br /> s3-control.dualstack.us-east-1.amazonaws.com <br /> s3-control-fips.dualstack.us-east-1.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| US West (N. California) | us-west-1 |  s3-control.us-west-1.amazonaws.com <br /> s3-control.dualstack.us-west-1.amazonaws.com <br /> s3-control-fips.dualstack.us-west-1.amazonaws.com <br /> s3-control-fips.us-west-1.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| US West (Oregon) | us-west-2 |  s3-control.us-west-2.amazonaws.com <br /> s3-control-fips.us-west-2.amazonaws.com <br /> s3-control.dualstack.us-west-2.amazonaws.com <br /> s3-control-fips.dualstack.us-west-2.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Africa (Cape Town) | af-south-1 |  s3-control.af-south-1.amazonaws.com <br /> s3-control.dualstack.af-south-1.amazonaws.com  | HTTPS<br />HTTPS | 
| Asia Pacific (Hong Kong) | ap-east-1 |  s3-control.ap-east-1.amazonaws.com <br /> s3-control.dualstack.ap-east-1.amazonaws.com  | HTTPS<br />HTTPS | 
| Asia Pacific (Hyderabad) | ap-south-2 |  s3-control.ap-south-2.amazonaws.com <br /> s3-control.dualstack.ap-south-2.amazonaws.com  | HTTPS<br />HTTPS | 
| Asia Pacific (Jakarta) | ap-southeast-3 |  s3-control.ap-southeast-3.amazonaws.com <br /> s3-control.dualstack.ap-southeast-3.amazonaws.com  | HTTPS<br />HTTPS | 
| Asia Pacific (Melbourne) | ap-southeast-4 |  s3-control.ap-southeast-4.amazonaws.com <br /> s3-control.dualstack.ap-southeast-4.amazonaws.com  | HTTPS<br />HTTPS | 
| Asia Pacific (Mumbai) | ap-south-1 |  s3-control.ap-south-1.amazonaws.com <br /> s3-control.dualstack.ap-south-1.amazonaws.com  | HTTPS<br />HTTPS | 
| Asia Pacific (Osaka) | ap-northeast-3 |  s3-control.ap-northeast-3.amazonaws.com <br /> s3-control.dualstack.ap-northeast-3.amazonaws.com  | HTTPS<br />HTTPS | 
| Asia Pacific (Seoul) | ap-northeast-2 |  s3-control.ap-northeast-2.amazonaws.com <br /> s3-control.dualstack.ap-northeast-2.amazonaws.com  | HTTPS<br />HTTPS | 
| Asia Pacific (Singapore) | ap-southeast-1 |  s3-control.ap-southeast-1.amazonaws.com <br /> s3-control.dualstack.ap-southeast-1.amazonaws.com  | HTTPS<br />HTTPS | 
| Asia Pacific (Sydney) | ap-southeast-2 |  s3-control.ap-southeast-2.amazonaws.com <br /> s3-control.dualstack.ap-southeast-2.amazonaws.com  | HTTPS<br />HTTPS | 
| Asia Pacific (Tokyo) | ap-northeast-1 |  s3-control.ap-northeast-1.amazonaws.com <br /> s3-control.dualstack.ap-northeast-1.amazonaws.com  | HTTPS<br />HTTPS | 
| Canada (Central) | ca-central-1 |  s3-control.ca-central-1.amazonaws.com <br /> s3-control.dualstack.ca-central-1.amazonaws.com <br /> s3-control-fips.ca-central-1.amazonaws.com <br /> s3-control-fips.dualstack.ca-central-1.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Canada West (Calgary) | ca-west-1 |  s3-control.ca-west-1.amazonaws.com <br /> s3-control-fips.ca-west-1.amazonaws.com <br /> s3-control.dualstack.ca-west-1.amazonaws.com <br /> s3-control-fips.dualstack.ca-west-1.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Europe (Frankfurt) | eu-central-1 |  s3-control.eu-central-1.amazonaws.com <br /> s3-control.dualstack.eu-central-1.amazonaws.com  | HTTPS<br />HTTPS | 
| Europe (Ireland) | eu-west-1 |  s3-control.eu-west-1.amazonaws.com <br /> s3-control.dualstack.eu-west-1.amazonaws.com  | HTTPS<br />HTTPS | 
| Europe (London) | eu-west-2 |  s3-control.eu-west-2.amazonaws.com <br /> s3-control.dualstack.eu-west-2.amazonaws.com  | HTTPS<br />HTTPS | 
| Europe (Milan) | eu-south-1 |  s3-control.eu-south-1.amazonaws.com <br /> s3-control.dualstack.eu-south-1.amazonaws.com  | HTTPS<br />HTTPS | 
| Europe (Paris) | eu-west-3 |  s3-control.eu-west-3.amazonaws.com <br /> s3-control.dualstack.eu-west-3.amazonaws.com  | HTTPS<br />HTTPS | 
| Europe (Spain) | eu-south-2 |  s3-control.eu-south-2.amazonaws.com <br /> s3-control.dualstack.eu-south-2.amazonaws.com  | HTTPS<br />HTTPS | 
| Europe (Stockholm) | eu-north-1 |  s3-control.eu-north-1.amazonaws.com <br /> s3-control.dualstack.eu-north-1.amazonaws.com  | HTTPS<br />HTTPS | 
| Europe (Zurich) | eu-central-2 |  s3-control.eu-central-2.amazonaws.com <br /> s3-control.dualstack.eu-central-2.amazonaws.com  | HTTPS<br />HTTPS | 
| Israel (Tel Aviv) | il-central-1 |  s3-control.il-central-1.amazonaws.com <br /> s3-control.dualstack.il-central-1.amazonaws.com  | HTTPS<br />HTTPS | 
| Middle East (Bahrain) | me-south-1 |  s3-control.me-south-1.amazonaws.com <br /> s3-control.dualstack.me-south-1.amazonaws.com  | HTTPS<br />HTTPS | 
| Middle East (UAE) | me-central-1 |  s3-control.me-central-1.amazonaws.com <br /> s3-control.dualstack.me-central-1.amazonaws.com  | HTTPS<br />HTTPS | 
| South America (São Paulo) | sa-east-1 |  s3-control.sa-east-1.amazonaws.com <br /> s3-control.dualstack.sa-east-1.amazonaws.com  | HTTPS<br />HTTPS | 
|  AWS GovCloud (US-East) | us-gov-east-1 |  s3-control.us-gov-east-1.amazonaws.com <br /> s3-control-fips.us-gov-east-1.amazonaws.com <br /> s3-control.dualstack.us-gov-east-1.amazonaws.com <br /> s3-control-fips.dualstack.us-gov-east-1.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
|  AWS GovCloud (US-West) | us-gov-west-1 |  s3-control.us-gov-west-1.amazonaws.com <br /> s3-control-fips.dualstack.us-gov-west-1.amazonaws.com <br /> s3-control.dualstack.us-gov-west-1.amazonaws.com <br /> s3-control-fips.us-gov-west-1.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 

**Note**  
Amazon S3 dual-stack endpoints support requests to S3 buckets over IPv6 and IPv4. For more information, see [Using Dual-Stack Endpoints](https://docs.aws.amazon.com/AmazonS3/latest/userguide/dual-stack-endpoints.html).

 When using the preceding endpoints, the following additional considerations apply:
+ Amazon S3 renamed the US Standard Region to the US East (N. Virginia) Region to be consistent with AWS Regional naming conventions. There is no change to the endpoint, and you do not need to make any changes to your application.
+ If you use a Region other than the US East (N. Virginia) endpoint to create a bucket, you must set the `LocationConstraint` bucket parameter to the same Region. Both the AWS SDK for Java and AWS SDK for .NET use an enumeration for setting location constraints (`Region` for Java, `S3Region` for .NET). For more information, see [`Create Bucket`](https://docs.aws.amazon.com/AmazonS3/latest/API/RESTBucketPUT.html) in the *Amazon Simple Storage Service API Reference*.

**Multivalue answer DNS routing**  
Amazon S3 uses Multivalue answer (MVA) DNS routing to return multiple answers in response to DNS queries for its endpoints. This behavior improves performance and availability by enabling applications to parallelize their requests across multiple Amazon S3 IP addresses.

To automatically benefit from MVA, you can use the newer versions of the AWS SDKs including the [SDK for Java 2.x](https://docs.aws.amazon.com/sdk-for-java/latest/developer-guide/home.html), [SDK for C\+\+](https://docs.aws.amazon.com/sdk-for-cpp/v1/developer-guide/welcome.html), and [AWS SDK for Python (Boto3)](https://docs.aws.amazon.com/personalize/latest/dg/getting-started-python.html). If you are using the [SDK for Java 2.x](https://docs.aws.amazon.com/sdk-for-java/latest/developer-guide/migration.html) with the [Common Runtime (CRT)](https://docs.aws.amazon.com/sdk-for-java/latest/developer-guide/http-configuration-crt.html) library enabled for asynchronous operations, your requests will automatically use MVA routing. 

 The [AWS CRT-based S3 client](https://docs.aws.amazon.com/sdk-for-java/latest/developer-guide/crt-based-s3-client.html) is an alternative Amazon S3 asynchronous client that allows you to transfer objects to and from S3 by automatically leveraging the S3 [multipart upload API](https://docs.aws.amazon.com/AmazonS3/latest/userguide/mpuoverview.html) and [byte-range fetches](https://docs.aws.amazon.com/whitepapers/latest/s3-optimizing-performance-best-practices/use-byte-range-fetches.html). The AWS CRT S3-based client improves reliability by automatically retrying individual failed parts of a multipart file transfer without restarting the transfer from the beginning. When used with MVA, these retries are made to alternative IP addresses, further improving the reliability of your connection to S3. 

 In cases where applications don't support MVA routing, they will use the first IP from the response. Amazon S3 MVA routing is supported in all AWS Regions, excluding AWS GovCloud (US). For more information, see [Multivalue answer routing](https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/routing-policy-multivalue.html).

### Amazon S3 website endpoints
<a name="s3_website_region_endpoints"></a>

When you configure your bucket as a website, the website is available by using the following Region-specific website endpoints. Note that the website endpoints are different than the REST API endpoints listed in the preceding table. For more information about hosting websites on Amazon S3, see [Hosting Websites on Amazon S3](https://docs.aws.amazon.com/AmazonS3/latest/userguide/WebsiteHosting.html) in the *Amazon Simple Storage Service User Guide*. You need the hosted zone IDs when using the Amazon Route 53 API to add an alias record to your hosted zone. 

**Note**  
Amazon S3 website endpoints do not support HTTPS or Amazon S3 Access Points. If you want to use HTTPS, you can use Amazon CloudFront to serve a static website hosted on Amazon S3. For more information, see [Configuring a static website using a custom domain registered with Route 53](https://docs.aws.amazon.com/AmazonS3/latest/userguide/website-hosting-custom-domain-walkthrough.html) and [Improving the performance of your website using CloudFront](https://docs.aws.amazon.com/AmazonS3/latest/userguide/website-hosting-cloudfront-walkthrough.html) in the *Amazon S3 User Guide*.

#### Amazon S3 website endpoints and HostedZone IDs
<a name="auto-endpoints-website-s3"></a>


| Region Name | Region | Endpoint | Protocol | Route 53 Hosted Zone ID | 
| --- | --- | --- | --- | --- | 
| US East (Ohio) | us-east-2 |  s3-website.us-east-2.amazonaws.com  | HTTP | Z2O1EMRO9K5GLX | 
| US East (N. Virginia) | us-east-1 |  s3-website-us-east-1.amazonaws.com  | HTTP | Z3AQBSTGFYJSTF | 
| US West (N. California) | us-west-1 |  s3-website-us-west-1.amazonaws.com  | HTTP | Z2F56UZL2M1ACD | 
| US West (Oregon) | us-west-2 |  s3-website-us-west-2.amazonaws.com  | HTTP | Z3BJ6K6RIION7M | 
| Africa (Cape Town) | af-south-1 |  s3-website.af-south-1.amazonaws.com  | HTTP | Z2OSFR5PIJ8TYW | 
| Asia Pacific (Hong Kong) | ap-east-1 |  s3-website.ap-east-1.amazonaws.com  | HTTP | ZNB98KWMFR0R6 | 
| Asia Pacific (Hyderabad) | ap-south-2 |  s3-website.ap-south-2.amazonaws.com  | HTTP | Z02976202B4EZMXIPMXF7 | 
| Asia Pacific (Jakarta) | ap-southeast-3 |  s3-website.ap-southeast-3.amazonaws.com  | HTTP | Z01846753K324LI26A3VV | 
| Asia Pacific (Malaysia) | ap-southeast-5 |  s3-website.ap-southeast-5.amazonaws.com  | HTTP | Z08660063OXLMA7F1FJHU | 
| Asia Pacific (Melbourne) | ap-southeast-4 |  s3-website.ap-southeast-4.amazonaws.com  | HTTP | Z0312387243XT5FE14WFO | 
| Asia Pacific (Mumbai) | ap-south-1 |  s3-website.ap-south-1.amazonaws.com  | HTTP | Z11RGJOFQNVJUP | 
| Asia Pacific (New Zealand) | ap-southeast-6 |  s3-website.ap-southeast-6.amazonaws.com  | HTTP | Z05686083R66JX5C163TC | 
| Asia Pacific (Osaka) | ap-northeast-3 |  s3-website.ap-northeast-3.amazonaws.com  | HTTP | Z2YQB5RD63NC85 | 
| Asia Pacific (Seoul) | ap-northeast-2 |  s3-website.ap-northeast-2.amazonaws.com  | HTTP | Z3W03O7B5YMIYP | 
| Asia Pacific (Singapore) | ap-southeast-1 |  s3-website-ap-southeast-1.amazonaws.com  | HTTP | Z3O0J2DXBE1FTB | 
| Asia Pacific (Sydney) | ap-southeast-2 |  s3-website-ap-southeast-2.amazonaws.com  | HTTP | Z1WCIGYICN2BYD | 
| Asia Pacific (Taipei) | ap-east-2 |  s3-website.ap-east-2.amazonaws.com  | HTTP | Z064739330DAH7WJVOO93 | 
| Asia Pacific (Thailand) | ap-southeast-7 |  s3-website.ap-southeast-7.amazonaws.com  | HTTP | Z0031014GXUMRZG6I14G | 
| Asia Pacific (Tokyo) | ap-northeast-1 |  s3-website-ap-northeast-1.amazonaws.com  | HTTP | Z2M4EHUR26P7ZW | 
| Canada (Central) | ca-central-1 |  s3-website.ca-central-1.amazonaws.com  | HTTP | Z1QDHH18159H29 | 
| Canada West (Calgary) | ca-west-1 |  s3-website.ca-west-1.amazonaws.com  | HTTP | Z03565811Z33SLEZTHOUL | 
| Europe (Frankfurt) | eu-central-1 |  s3-website.eu-central-1.amazonaws.com  | HTTP | Z21DNDUVLTQW6Q | 
| Europe (Ireland) | eu-west-1 |  s3-website-eu-west-1.amazonaws.com  | HTTP | Z1BKCTXD74EZPE | 
| Europe (London) | eu-west-2 |  s3-website.eu-west-2.amazonaws.com  | HTTP | Z3GKZC51ZF0DB4 | 
| Europe (Milan) | eu-south-1 |  s3-website.eu-south-1.amazonaws.com  | HTTP | Z2OPA49AB41N7K | 
| Europe (Paris) | eu-west-3 |  s3-website.eu-west-3.amazonaws.com  | HTTP | Z3R1K369G5AVDG | 
| Europe (Spain) | eu-south-2 |  s3-website.eu-south-2.amazonaws.com  | HTTP | Z0081959F7139GRJC19J | 
| Europe (Stockholm) | eu-north-1 |  s3-website.eu-north-1.amazonaws.com  | HTTP | Z3BAZG2TWCNX0D | 
| Europe (Zurich) | eu-central-2 |  s3-website.eu-central-2.amazonaws.com  | HTTP | Z030506016YDQGETNASS | 
| Israel (Tel Aviv) | il-central-1 |  s3-website.il-central-1.amazonaws.com  | HTTP | Z09640613K4A3MN55U7GU | 
| Mexico (Central) | mx-central-1 |  s3-website.mx-central-1.amazonaws.com  | HTTP | Z057606446ZNVQJJ8WOP | 
| Middle East (Bahrain) | me-south-1 |  s3-website.me-south-1.amazonaws.com  | HTTP | Z1MPMWCPA7YB62 | 
| Middle East (UAE) | me-central-1 |  s3-website.me-central-1.amazonaws.com  | HTTP | Z06143092I8HRXZRUZROF | 
| South America (São Paulo) | sa-east-1 |  s3-website-sa-east-1.amazonaws.com  | HTTP | Z7KQH4QJS55SO | 
|  AWS GovCloud (US-East) | us-gov-east-1 |  s3-website.us-gov-east-1.amazonaws.com  | HTTP | Z2NIFVYYW2VKV1 | 
|  AWS GovCloud (US-West) | us-gov-west-1 |  s3-website-us-gov-west-1.amazonaws.com  | HTTP | Z31GFT0UA1I2HV | 

## Service quotas
<a name="limits_s3"></a>

### Amazon S3
<a name="limits-s3-classic"></a>

**Note**  
The **Default** column shows "Each Account" for all quotas, but some quotas apply per bucket. See the **Description** column for the actual scope.


| Name | Default | Adjustable | Description | 
| --- | --- | --- | --- | 
| Access Points | Each Account: 10,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/s3/quotas/L-FAABEEBA)  | The number of Amazon S3 Access Points that you can create per region in an account | 
| Bucket policy | Each Account: 20 Kilobytes | No | The maximum size (in KB) of a bucket policy for an Amazon S3 bucket | 
| Bucket tags | Each Account: 50 | No | The maximum number of tags you can assign to an Amazon S3 bucket | 
| Directory buckets | Each Account: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/s3/quotas/L-775A314D)  | The number of Amazon S3 directory buckets that you can create in an account | 
| Event notifications | Each Account: 100 | No | The maximum number of event notifications per Amazon S3 bucket | 
| General purpose buckets | Each Account: 10,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/s3/quotas/L-DC2B2D3D)  | The number of Amazon S3 general purpose buckets that you can create in an account | 
| Lifecycle rules | Each Account: 1,000 | No | The maximum number of rules you can specify for an Amazon S3 lifecycle configuration | 
| Maximum part size | Each Account: 5 Gigabytes | No |  The maximum size (in GB) of an Amazon S3 object part in a Multipart upload using the API | 
| Minimum part size | Each Account: 5 Megabytes | No | The minimum size (in MB) of an Amazon S3 object part in a Multipart upload using the API. The last part uploaded can be less than the stated minimum | 
| Multi-Region Access Point Regions | Each Account: 20 | No | Maximum Regions per Multi-Region Access Point. | 
| Multi-Region Access Points | Each Account: 100 | No | Multi-Region Access Points per Account. | 
| Object size | Each Account: 48.828125 Terabytes | No | The maximum size (in TB) of an Amazon S3 object | 
| Object size (Console upload) | Each Account: 160 Gigabytes | No | The maximum size (in GB) of an Amazon S3 object that you can upload using the console | 
| Object tags | Each Account: 10 | No | The maximum number of tags you can assign to an Amazon S3 object | 
| Parts | Each Account: 10,000 | No | The maximum number of Amazon S3 object parts per Multipart upload | 
| Replication Destinations | Each Account: 28 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/s3/quotas/L-1A9B467F)  | The number of destination S3 buckets you can add for each source S3 bucket across all replication rules. | 
| Replication rules | Each Account: 1,000 | No | The maximum number of rules you can specify in an Amazon S3 Replication configuration | 
| Replication transfer rate | Each Account: 1 Gigabits per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/s3/quotas/L-349AD9CA)  | The maximum Replication Time Control transfer rate that you can replicate from the source region in this account. | 
| S3 Glacier: Number of random restore requests. | Each Account: 35 | No | The number of random restore requests from S3 Glacier storage class per PiB stored per day. | 
| S3 Glacier: Provisioned capacity units | Each Account: 2 | No | The maximum number of S3 Glacier storage class provisioned capacity units available to purchase per account. | 
| S3 Glacier: Retrieval request rate per second. | Each Account: 1,000 | No | The maximum number of retrieval requests per second allowed per account. | 

### Amazon S3 on Outposts
<a name="limits-s3-outposts"></a>


| Name | Default | Adjustable | Description | 
| --- | --- | --- | --- | 
| Access Points | Each Account: 10 | No | The maximum number of Amazon S3 on Outposts access points that you can create per S3 on Outposts bucket in the AWS account in the current Outpost. | 
| Buckets | Each Account: 100 | No | The maximum number of Amazon S3 on Outposts buckets that you can create per AWS account in the current Outpost. | 