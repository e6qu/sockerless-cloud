

# Amazon CloudWatch endpoints and quotas
<a name="cw_region"></a>

To connect programmatically to an AWS service, you use an endpoint. AWS services offer the following endpoint types in some or all of the AWS Regions that the service supports: IPv4 endpoints, dual-stack endpoints, and FIPS endpoints. Some services provide global endpoints. For more information, see [AWS service endpoints](rande.md).

Service quotas, also referred to as limits, are the maximum number of service resources or operations for your AWS account. For more information, see [AWS service quotas](aws_service_limits.md).

The following are the service endpoints and service quotas for this service.

## Service endpoints
<a name="cw_region"></a>


| Region Name | Region | Endpoint | Protocol | 
| --- | --- | --- | --- | 
| US East (Ohio) | us-east-2 |  monitoring.us-east-2.amazonaws.com <br /> monitoring-fips.us-east-2.amazonaws.com <br /> monitoring-fips.us-east-2.api.aws <br /> monitoring.us-east-2.api.aws  | HTTP and HTTPS<br />HTTPS<br />HTTPS<br />HTTP and HTTPS | 
| US East (N. Virginia) | us-east-1 |  monitoring.us-east-1.amazonaws.com <br /> monitoring-fips.us-east-1.amazonaws.com <br /> monitoring-fips.us-east-1.api.aws <br /> monitoring.us-east-1.api.aws  | HTTP and HTTPS<br />HTTPS<br />HTTPS<br />HTTP and HTTPS | 
| US West (N. California) | us-west-1 |  monitoring.us-west-1.amazonaws.com <br /> monitoring-fips.us-west-1.amazonaws.com <br /> monitoring-fips.us-west-1.api.aws <br /> monitoring.us-west-1.api.aws  | HTTP and HTTPS<br />HTTPS<br />HTTPS<br />HTTP and HTTPS | 
| US West (Oregon) | us-west-2 |  monitoring.us-west-2.amazonaws.com <br /> monitoring-fips.us-west-2.amazonaws.com <br /> monitoring-fips.us-west-2.api.aws <br /> monitoring.us-west-2.api.aws  | HTTP and HTTPS<br />HTTPS<br />HTTPS<br />HTTP and HTTPS | 
| Africa (Cape Town) | af-south-1 |  monitoring.af-south-1.amazonaws.com <br /> monitoring.af-south-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (Hong Kong) | ap-east-1 |  monitoring.ap-east-1.amazonaws.com <br /> monitoring.ap-east-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (Hyderabad) | ap-south-2 |  monitoring.ap-south-2.amazonaws.com <br /> monitoring.ap-south-2.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (Jakarta) | ap-southeast-3 |  monitoring.ap-southeast-3.amazonaws.com <br /> monitoring.ap-southeast-3.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (Malaysia) | ap-southeast-5 |  monitoring.ap-southeast-5.amazonaws.com <br /> monitoring.ap-southeast-5.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (Melbourne) | ap-southeast-4 |  monitoring.ap-southeast-4.amazonaws.com <br /> monitoring.ap-southeast-4.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (Mumbai) | ap-south-1 |  monitoring.ap-south-1.amazonaws.com <br /> monitoring.ap-south-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (New Zealand) | ap-southeast-6 |  monitoring.ap-southeast-6.amazonaws.com <br /> monitoring.ap-southeast-6.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (Osaka) | ap-northeast-3 |  monitoring.ap-northeast-3.amazonaws.com <br /> monitoring.ap-northeast-3.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (Seoul) | ap-northeast-2 |  monitoring.ap-northeast-2.amazonaws.com <br /> monitoring.ap-northeast-2.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (Singapore) | ap-southeast-1 |  monitoring.ap-southeast-1.amazonaws.com <br /> monitoring.ap-southeast-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (Sydney) | ap-southeast-2 |  monitoring.ap-southeast-2.amazonaws.com <br /> monitoring.ap-southeast-2.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (Taipei) | ap-east-2 |  monitoring.ap-east-2.amazonaws.com <br /> monitoring.ap-east-2.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (Thailand) | ap-southeast-7 |  monitoring.ap-southeast-7.amazonaws.com <br /> monitoring.ap-southeast-7.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (Tokyo) | ap-northeast-1 |  monitoring.ap-northeast-1.amazonaws.com <br /> monitoring.ap-northeast-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Canada (Central) | ca-central-1 |  monitoring.ca-central-1.amazonaws.com <br /> monitoring.ca-central-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Canada West (Calgary) | ca-west-1 |  monitoring.ca-west-1.amazonaws.com <br /> monitoring.ca-west-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Europe (Frankfurt) | eu-central-1 |  monitoring.eu-central-1.amazonaws.com <br /> monitoring.eu-central-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Europe (Ireland) | eu-west-1 |  monitoring.eu-west-1.amazonaws.com <br /> monitoring.eu-west-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Europe (London) | eu-west-2 |  monitoring.eu-west-2.amazonaws.com <br /> monitoring.eu-west-2.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Europe (Milan) | eu-south-1 |  monitoring.eu-south-1.amazonaws.com <br /> monitoring.eu-south-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Europe (Paris) | eu-west-3 |  monitoring.eu-west-3.amazonaws.com <br /> monitoring.eu-west-3.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Europe (Spain) | eu-south-2 |  monitoring.eu-south-2.amazonaws.com <br /> monitoring.eu-south-2.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Europe (Stockholm) | eu-north-1 |  monitoring.eu-north-1.amazonaws.com <br /> monitoring.eu-north-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Europe (Zurich) | eu-central-2 |  monitoring.eu-central-2.amazonaws.com <br /> monitoring.eu-central-2.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Israel (Tel Aviv) | il-central-1 |  monitoring.il-central-1.amazonaws.com <br /> monitoring.il-central-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Mexico (Central) | mx-central-1 |  monitoring.mx-central-1.amazonaws.com <br /> monitoring.mx-central-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Middle East (Bahrain) | me-south-1 |  monitoring.me-south-1.amazonaws.com <br /> monitoring.me-south-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Middle East (UAE) | me-central-1 |  monitoring.me-central-1.amazonaws.com <br /> monitoring.me-central-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| South America (São Paulo) | sa-east-1 |  monitoring.sa-east-1.amazonaws.com <br /> monitoring.sa-east-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
|  AWS GovCloud (US-East) | us-gov-east-1 |  monitoring.us-gov-east-1.amazonaws.com <br /> monitoring.us-gov-east-1.api.aws  | HTTP and HTTPS<br />HTTPS | 
|  AWS GovCloud (US-West) | us-gov-west-1 |  monitoring.us-gov-west-1.amazonaws.com <br /> monitoring.us-gov-west-1.api.aws  | HTTP and HTTPS<br />HTTPS | 

## Service quotas
<a name="limits_cloudwatch"></a>


| Name | Default | Adjustable | Description | 
| --- | --- | --- | --- | 
| Canary limit | Each supported Region: 500 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/monitoring/quotas/L-C1FE0F5C)  | The maximum number of canaries per account per region. | 
| Number of Alarm Mute Rules | Each supported Region: 2,000 | No | The maximum number of Alarm Mute Rules that you can have in this account in the current region. | 
| Number of Contributor Insights rules | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/monitoring/quotas/L-DBD11BCC)  | The maximum number of Contributor Insights rules you can have in this account. | 
| Number of Metrics Insights alarms | Each supported Region: 200 | No | The maximum number of Metrics Insights alarms that you can have in this account in the current region. | 
| Number of PromQL alarms | Each supported Region: 15,000 | No | The maximum number of PromQL alarms that you can have in this account in the current region. | 
| Rate of ANOMALY\_DETECTION\_BAND usage in GetMetricData | Each supported Region: 1,000 | No | The maximum number of times the ANOMALY\_DETECTION\_BAND function can be used in all GetMetricData requests, per second, in this account in the current region. | 
| Rate of DB\_PERF\_INSIGHTS usage in GetMetricData | Each supported Region: 4 | No | The maximum number of times the DB\_PERF\_INSIGHTS function can be used in all GetMetricData requests, per second, in this account in the current region. | 
| Rate of DeleteAlarmMuteRule requests | Each supported Region: 3 per second | No | The maximum number of DeleteAlarmMuteRule requests that you can make, per second, in this account in the current region. | 
| Rate of DeleteAlarms requests | Each supported Region: 3 per second | No | The maximum number of DeleteAlarms requests that you can make, per second, in this account in the current region. | 
| Rate of DeleteAnomalyDetector requests | Each supported Region: 5 per second | No | The maximum number of DeleteAnomalyDetector requests that you can make, per second, in this account in the current region. | 
| Rate of DeleteDashboards requests | Each supported Region: 10 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/monitoring/quotas/L-E1508405)  | The maximum number of DeleteDashboards requests that you can make, per second, in this account in the current region. | 
| Rate of DeleteInsightRules requests | Each supported Region: 5 per second | No | The maximum number of DeleteInsightRules requests you can make per second in this account. | 
| Rate of DeleteMetricStream requests | Each supported Region: 10 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/monitoring/quotas/L-0F4E28CA)  | The maximum number of DeleteMetricStream requests that you can make, per second, in this account in the current region. | 
| Rate of DescribeAlarmContributors requests | Each supported Region: 9 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/monitoring/quotas/L-7D8B1BC8)  | The maximum number of DescribeAlarmContributors requests that you can make, per second, in this account in the current region. | 
| Rate of DescribeAlarmHistory requests | Each supported Region: 20 per second | No | The maximum number of DescribeAlarmHistory requests that you can make, per second, in this account in the current region. | 
| Rate of DescribeAlarms requests | Each supported Region: 9 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/monitoring/quotas/L-21CB40A4)  | The maximum number of DescribeAlarms requests that you can make, per second, in this account in the current region. | 
| Rate of DescribeAlarmsForMetric requests | Each supported Region: 9 per second | No | The maximum number of DescribeAlarmsForMetric requests that you can make, per second, in this account in the current region. | 
| Rate of DescribeAnomalyDetectors requests | Each supported Region: 10 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/monitoring/quotas/L-6300B446)  | The maximum number of DescribeAnomalyDetectors requests that you can make, per second, in this account in the current region. | 
| Rate of DescribeInsightRules requests | Each supported Region: 20 per second | No | The maximum number of DescribeInsightRules requests you can make per second in this account. | 
| Rate of DisableAlarmActions requests | Each supported Region: 3 per second | No | The maximum number of DisableAlarmActions requests that you can make, per second, in this account in the current region. | 
| Rate of DisableInsightRules requests | Each supported Region: 1 per second | No | The maximum number of DisableInsightRules requests you can make per second in this account. | 
| Rate of EnableAlarmActions requests | Each supported Region: 3 per second | No | The maximum number of EnableAlarmActions requests that you can make, per second, in this account in the current region. | 
| Rate of EnableInsightRules requests | Each supported Region: 1 per second | No | The maximum number of EnableInsightRules requests you can make per second in this account. | 
| Rate of GetAlarmMuteRule requests | Each supported Region: 20 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/monitoring/quotas/L-8445A443)  | The maximum number of GetAlarmMuteRule requests that you can make, per second, in this account in the current region. | 
| Rate of GetDashboard requests | Each supported Region: 10 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/monitoring/quotas/L-E82C279D)  | The maximum number of GetDashboard requests that you can make, per second, in this account in the current region. | 
| Rate of GetInsightRuleReport requests | Each supported Region: 20 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/monitoring/quotas/L-1F0C4E0C)  | The maximum number of GetInsightRuleReport requests you can make, per second in this account. | 
| Rate of GetMetricData datapoints for metrics older than three hours | Each supported Region: 396,000 | No | The maximum number of GetMetricData datapoints that you can fetch, per second, for a request with a StartTime of more than three hours in this account in the current region. | 
| Rate of GetMetricData datapoints for the last three hours of metrics | Each supported Region: 180,000 | No | The maximum number of GetMetricData datapoints that you can fetch, per second, for a request with a StartTime of less than or equal to three hours in this account in the current region. | 
| Rate of GetMetricData datapoints using Metrics Insights | Each supported Region: 4,300,000 | No | The maximum number of GetMetricData datapoints that you can fetch using Metrics Insights, per second, for a request with a StartTime of less than or equal to three hours in this account in the current region. | 
| Rate of GetMetricData requests | Each supported Region: 500 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/monitoring/quotas/L-5E141212)  | The maximum number of GetMetricData requests that you can make, per second, in this account in the current region. | 
| Rate of GetMetricStatistics requests | Each supported Region: 400 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/monitoring/quotas/L-EE839489)  | The maximum number of GetMetricStatistics requests that you can make, per second, in this account in the current region. | 
| Rate of GetMetricStream requests | Each supported Region: 10 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/monitoring/quotas/L-59022E75)  | The maximum number of GetMetricStream requests that you can make, per second, in this account in the current region. | 
| Rate of GetMetricWidgetImage requests | Each supported Region: 20 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/monitoring/quotas/L-6FCAAA2E)  | The maximum number of GetMetricWidgetImage requests that you can make, per second, in this account in the current region. | 
| Rate of INSIGHT\_RULE\_METRIC usage in GetMetricData | Each supported Region: 20 | No | The maximum number of times the INSIGHT\_RULE\_METRIC function can be used in all GetMetricData requests, per second, in this account in the current region. | 
| Rate of LAMBDA usage in GetMetricData | Each supported Region: 5 | No | The maximum number of times the LAMBDA function can be used in all GetMetricData requests, per second, in this account in the current region. | 
| Rate of ListAlarmMuteRules requests | Each supported Region: 50 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/monitoring/quotas/L-B1A3FF67)  | The maximum number of ListAlarmMuteRules requests that you can make, per second, in this account in the current region. | 
| Rate of ListDashboards requests | Each supported Region: 10 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/monitoring/quotas/L-69C44FFD)  | The maximum number of ListDashboards requests that you can make, per second, in this account in the current region. | 
| Rate of ListMetricStreams requests | Each supported Region: 10 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/monitoring/quotas/L-A1710150)  | The maximum number of ListMetricStreams requests that you can make, per second, in this account in the current region. | 
| Rate of ListMetrics requests | Each supported Region: 25 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/monitoring/quotas/L-05D334F0)  | The maximum number of ListMetrics requests that you can make, per second, in this account in the current region. | 
| Rate of ListTagsForResource requests | Each supported Region: 10 per second | No | The maximum number of ListTagsForResource requests that you can make, per second, in this account in the current region. | 
| Rate of Metrics Insights usage in GetMetricData | Each supported Region: 10 | No | The maximum number of times Metrics Insights can be used in all GetMetricData requests, per second, in this account in the current region. | 
| Rate of PutAlarmMuteRule requests | Each supported Region: 3 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/monitoring/quotas/L-73547960)  | The maximum number of PutAlarmMuteRule requests that you can make, per second, in this account in the current region. | 
| Rate of PutAnomalyDetector requests | Each supported Region: 10 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/monitoring/quotas/L-8A387C66)  | The maximum number of PutAnomalyDetector requests that you can make, per second, in this account in the current region. | 
| Rate of PutCompositeAlarm requests | Each supported Region: 3 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/monitoring/quotas/L-515B0B71)  | The maximum number of PutCompositeAlarm requests that you can make, per second, in this account in the current region. | 
| Rate of PutDashboard requests | Each supported Region: 10 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/monitoring/quotas/L-6753900D)  | The maximum number of PutDashboard requests that you can make, per second, in this account in the current region. | 
| Rate of PutInsightRule requests | Each supported Region: 5 per second | No | The maximum number of PutInsightRule requests you can make, per second in this account. | 
| Rate of PutLogAlarm requests | Each supported Region: 3 per second | No | The maximum number of PutLogAlarm requests that you can make, per second, in this account in the current region. | 
| Rate of PutMetricAlarm requests | Each supported Region: 3 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/monitoring/quotas/L-0720E68F)  | The maximum number of PutMetricAlarm requests that you can make, per second, in this account in the current region. | 
| Rate of PutMetricData requests | Each supported Region: 500 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/monitoring/quotas/L-8BC498D4)  | The maximum number of PutMetricData requests that you can make, per second, in this account in the current region. | 
| Rate of PutMetricStream requests | Each supported Region: 10 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/monitoring/quotas/L-A6D89949)  | The maximum number of PutMetricStream requests that you can make, per second, in this account in the current region. | 
| Rate of SEARCH usage in GetMetricData | Each supported Region: 50 | No | The maximum number of times the SEARCH function can be used in all GetMetricData requests, per second, in this account in the current region. | 
| Rate of SERVICE\_QUOTA usage in GetMetricData | Each supported Region: 1,000 | No | The maximum number of times the SERVICE\_QUOTA function can be used in all GetMetricData requests, per second, in this account in the current region. | 
| Rate of SetAlarmState requests | Each supported Region: 3 per second | No | The maximum number of SetAlarmState requests that you can make, per second, in this account in the current region. | 
| Rate of StartMetricStreams requests | Each supported Region: 10 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/monitoring/quotas/L-787E531D)  | The maximum number of StartMetricStreams requests that you can make, per second, in this account in the current region. | 
| Rate of StopMetricStreams requests | Each supported Region: 10 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/monitoring/quotas/L-A64F5500)  | The maximum number of StopMetricStreams requests that you can make, per second, in this account in the current region. | 
| Rate of TagResource requests | Each supported Region: 20 per second | No | The maximum number of TagResource requests that you can make, per second, in this account in the current region. | 
| Rate of UntagResource requests | Each supported Region: 20 per second | No | The maximum number of UntagResource requests that you can make, per second, in this account in the current region. | 

For more information, see [CloudWatch Quotas](https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/cloudwatch_limits.html) in the *Amazon CloudWatch User Guide*.