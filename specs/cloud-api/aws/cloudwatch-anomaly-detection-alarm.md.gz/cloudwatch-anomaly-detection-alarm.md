

# Create a CloudWatch alarm based on anomaly detection
<a name="Create_Anomaly_Detection_Alarm"></a>

You can create an alarm based on CloudWatch anomaly detection, which analyzes past metric data and creates a model of expected values. The expected values take into account the typical hourly, daily, and weekly patterns in the metric.

You set a value for the anomaly detection threshold, and CloudWatch uses this threshold with the model to determine the "normal" range of values for the metric. A higher value for the threshold produces a thicker band of "normal" values.

You can choose whether the alarm is triggered when the metric value is above the band of expected values, below the band, or either above or below the band.

You also can create anomaly detection alarms on single metrics and the outputs of metric math expressions. You can use these expressions to create graphs that visualize anomaly detection bands.

In an account set up as a monitoring account for CloudWatch cross-account observability, you can create anomaly detectors on metrics in source accounts in addition to metrics in the monitoring account.

For more information, see [Using CloudWatch anomaly detection](CloudWatch_Anomaly_Detection.md).

**Note**  
If you're already using anomaly detection for visualization purposes on a metric in the Metrics console and you create an anomaly detection alarm on that same metric, then the threshold that you set for the alarm doesn't change the threshold that you already set for visualization. For more information, see [Creating a graph](graph_a_metric.md#create-metric-graph).

**To create an alarm that's based on anomaly detection**

1. Open the CloudWatch console at [https://console.aws.amazon.com/cloudwatch/](https://console.aws.amazon.com/cloudwatch/).

1.  In the navigation pane, choose **Alarms**, **All alarms**. 

1.  Choose **Create alarm**. 

1.  Choose **Select Metric**. 

1. Do one of the following:
   +  Choose the service namespace that contains your metric, and then continue choosing options as they appear to narrow down your options. When a list of metrics appears, select the check box that's next to your metric. 
   +  In the search box, enter the name of a metric, dimension, or resource ID. Select one of the results, and then continue choosing options as they appear until a list of metrics appears. Select the check box that's next to your metric. 

1.  Choose **Graphed metric**. 

   1.  (Optional) For *Statistic*, choose the dropdown, and then select one of the predefined statistics or percentiles. You can use the search box in the dropdown to specify a custom percentile, such as **p95.45**. 

   1.  (Optional) For *Period*, choose the dropdown, and then select one of the predefined evaluation periods. 
**Note**  
 When CloudWatch evaluates your alarm, it aggragates the period into a single datapoint. For an anomaly detection alarm, the evaluation period must be one minute or longer. 

1.  Choose **Next**. 

1.  Under ***Conditions***, specify the following: 

   1. Choose **Anomaly detection**.

       If the model for this metric and statistic already exists, CloudWatch displays a preview of the anomaly detection band in the graph at the top of the screen. After you create your alarm, it can take up to 15 minutes for the actual anomaly detection band to appear in the graph. Before that, the band that you see is an approximation of the anomaly detection band. 
**Tip**  
 To see the graph at the top of the screen in a longer time frame, choose **Edit** at the top-right of the screen. 

       If the model for this metric and statistic doesn't already exist, CloudWatch generates the anomaly detection band after you finish creating your alarm. For new models, it can take up to 3 hours for the actual anomaly detection band to appear in your graph. It can take up to two weeks for the new model to train, so the anomaly detection band shows more accurate expected values. 

   1. For **Whenever {{metric}} is**, specify when to trigger the alarm. For example, when the metric is greater than, lower than, or outside the band (in either direction).

   1. For **Anomaly detection threshold**, choose the number to use for the anomaly detection threshold. A higher number creates a thicker band of "normal" values that is more tolerant of metric changes. A lower number creates a thinner band that will go to `ALARM` state with smaller metric deviations. The number does not have to be a whole number.

   1. Choose **Additional configuration**. For **Datapoints to alarm**, specify how many evaluation periods (data points) must be in the `ALARM` state to trigger the alarm. If the two values here match, you create an alarm that goes to `ALARM` state if that many consecutive periods are breaching.

      To create an M out of N alarm, specify a number for the first value that is lower than the number for the second value. For more information, see [Alarm evaluation](alarm-evaluation.md).

   1. For **Missing data treatment**, choose how the alarm behaves when some data points are missing. For more information, see [Configuring how CloudWatch alarms treat missing data](alarms-and-missing-data.md).

   1. If the alarm uses a percentile as the monitored statistic, a **Percentiles with low samples** box appears. Use it to choose whether to evaluate or ignore cases with low sample rates. If you choose **Ignore (maintain alarm state)**, the current alarm state is always maintained when the sample size is too low. For more information, see [Percentile-based alarms and low data samples](percentiles-with-low-samples.md). 

1.  Choose **Next**. 

1. Under **Notification**, select an SNS topic to notify when the alarm is in `ALARM` state, `OK` state, or `INSUFFICIENT_DATA` state.

   To send multiple notifications for the same alarm state or for different alarm states, choose **Add notification**.

   Choose **Remove** if you don't want the alarm to send notifications.

1. You can set up the alarm to perform EC2 actions or invoke a Lambda function when it changes state, or to create a Systems Manager OpsItem or incident when it goes into ALARM state. To do this, choose the appropriate button and then choose the alarm state and action to perform.

   If you choose a Lambda function as an alarm action, you specify the function name or ARN, and you can optionally choose a specific version of the function.

   For more information about Systems Manager actions, see [ Configuring CloudWatch to create OpsItems from alarms](https://docs.aws.amazon.com/systems-manager/latest/userguide/OpsCenter-create-OpsItems-from-CloudWatch-Alarms.html) and [ Incident creation](https://docs.aws.amazon.com/incident-manager/latest/userguide/incident-creation.html).
**Note**  
To create an alarm that performs an AWS Systems Manager Incident Manager action, you must have certain permissions. For more information, see [ Identity-based policy examples for AWS Systems Manager Incident Manager](https://docs.aws.amazon.com/incident-manager/latest/userguide/security_iam_id-based-policy-examples.html).

1.  Choose **Next**. 

1.  Under ***Name and description***, enter a name and description for your alarm, and choose **Next**. The name must contain only UTF-8 characters, and can't contain ASCII control characters. The description can include markdown formatting, which is displayed only in the alarm **Details** tab in the CloudWatch console. The markdown can be useful to add links to runbooks or other internal resources. 
**Tip**  
 The alarm name must contain only UTF-8 characters, and can't contain ASCII control characters 

1.  Under ***Preview and create***, confirm that your alarm's information and conditions are correct, and choose **Create alarm**. 

## Creating an anomaly detection alarm using the AWS CLI
<a name="anomaly-detection-alarm-cli"></a>

You can also create an anomaly detection alarm with the AWS CLI. First create the anomaly detector, and then create an alarm that uses an `ANOMALY_DETECTION_BAND` metric math expression to define the expected range.

**To create an anomaly detection alarm**

1. Create the anomaly detector using the [put-anomaly-detector](https://docs.aws.amazon.com/cli/latest/reference/cloudwatch/put-anomaly-detector.html) command.

   ```
   aws cloudwatch put-anomaly-detector --single-metric-anomaly-detector '{"Namespace":"AWS/EC2","MetricName":"CPUUtilization","Dimensions":[{"Name":"InstanceId","Value":"{{instance-id}}"}],"Stat":"Average"}'
   ```

   If the command succeeds, it returns no output.

1. Create the alarm with a metric-math band using the [put-metric-alarm](https://docs.aws.amazon.com/cli/latest/reference/cloudwatch/put-metric-alarm.html) command. The `ANOMALY_DETECTION_BAND` expression defines the expected range.

   ```
   aws cloudwatch put-metric-alarm --alarm-name {{cpu-anomaly}} --comparison-operator LessThanLowerOrGreaterThanUpperThreshold --evaluation-periods 1 --threshold-metric-id ad1 --metrics '[{"Id":"m1","MetricStat":{"Metric":{"Namespace":"AWS/EC2","MetricName":"CPUUtilization","Dimensions":[{"Name":"InstanceId","Value":"{{instance-id}}"}]},"Period":300,"Stat":"Average"},"ReturnData":true},{"Id":"ad1","Expression":"ANOMALY_DETECTION_BAND(m1, 2)","ReturnData":true}]'
   ```

## Editing an anomaly detection model
<a name="Modify_Anomaly_Detection_Model"></a>

After you create an alarm, you can adjust the anomaly detection model. You can exclude certain time periods from being used in the model creation. It is critical that you exclude unusual events such as system outages, deployments, and holidays from the training data. You can also specify whether to adjust the model for Daylight Savings Time changes.

**To edit the anomaly detection model for an alarm**

1. Open the CloudWatch console at [https://console.aws.amazon.com/cloudwatch/](https://console.aws.amazon.com/cloudwatch/).

1. In the navigation pane, choose **Alarms**, **All alarms**.

1. Choose the name of the alarm. If necessary, use the search box to find the alarm.

1. Choose **View**, **In metrics**.

1. In the **Details** column, choose the **ANOMALY\_DETECTION\_BAND** keyword, and then choose **Edit anomaly detection model** in the popup.  
![The Graphed Metrics tab with the ANOMALY_DETECTION_BAND popup menu displayed.](https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/images/Anomaly_Detection_Edit.PNG)

1. To exclude a time period from being used to produce the model, choose the calendar icon by **End date**. Then, select or enter the days and times to exclude from training and choose **Apply**.

1. If the metric is sensitive to Daylight Savings Time changes, select the appropriate time zone in the **Metric timezone** box.

1. Choose **Update**.

## Deleting an anomaly detection model
<a name="Delete_Anomaly_Detection_Model"></a>

Using anomaly detection for an alarm accrues charges. As a best practice, if your alarm no longer needs an anomaly detection model, delete the alarm first and the model second. When anomaly detection alarms are evaluated, any missing anomaly detectors are created on your behalf. If you delete the model without deleting the alarm, the alarm automatically recreates the model.

**To delete an alarm**

1. Open the CloudWatch console at [https://console.aws.amazon.com/cloudwatch/](https://console.aws.amazon.com/cloudwatch/).

1. In the navigation pane, choose **Alarms**, **All Alarms**.

1. Choose the name of the alarm.

1. Choose **Actions**, **Delete**.

1. In the confirmation box, choose **Delete**.

**To delete an anomaly detection model that was used for an alarm**

1. Open the CloudWatch console at [https://console.aws.amazon.com/cloudwatch/](https://console.aws.amazon.com/cloudwatch/).

1.  In the navigation pane, choose **Metrics**, and then choose **Classic metrics**. 

1.  Choose **Browse**, and then select the metric that includes the anomaly detection model. You can search for your metric in the search box or select your metric by choosing through the options. 
   +  (Optional) If you're using the original interface, choose **All metrics**, and then choose the metric that includes the anomaly detection model. You can search for your metric in the search box or select your metric by choosing through the options. 

1.  Choose **Graphed metrics**. 

1. In the **Graphed metrics** tab, in the **Details** column, choose the **ANOMALY\_DETECTION\_BAND** keyword, and then choose **Delete anomaly detection model** in the popup.  
![The Graphed Metrics tab with the ANOMALY_DETECTION_BAND popup menu displayed.](https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/images/Anomaly_Detection_Edit.PNG)
   +  (Optional) If you're using the original interface, choose **Edit model**. You're directed to a new screen. On the new screen, choose **Delete model**, and then choose **Delete**. 

## Improving anomaly detection alarm accuracy with feedback
<a name="Improve_Anomaly_Detection_Alarm"></a>

After you create an anomaly detection alarm, you can provide feedback to help CloudWatch improve the accuracy of the anomaly detection model. CloudWatch uses your feedback to adjust how the model learns from your metric's behavior, which can result in more accurate anomaly detection bands over time.

You can provide feedback when you notice that:
+ The alarm triggered correctly, and you want to confirm that the detection was accurate.
+ The alarm triggered, but the metric behavior was actually normal (a false alarm).
+ The alarm did not trigger, but the metric behavior was anomalous (a missed detection).

**To submit feedback on an anomaly detection alarm**

1. Open the CloudWatch console at [https://console.aws.amazon.com/cloudwatch/](https://console.aws.amazon.com/cloudwatch/).

1. In the navigation pane, choose **Alarms**.

1. Choose the name of the anomaly detection alarm that you want to provide feedback for.

1. Choose the **Improve this alarm** button.

1. In the feedback dialog box, specify a **Start time** and **End time** for the time range that your feedback applies to. This should cover the period where you observed the alarm behavior you want to report.

1. For **Feedback type**, choose one of the following:
   + **Correct** – The alarm correctly detected an anomaly (or correctly did not trigger). This confirms that the model is performing well for this time range. No model adjustments are made.
   + **False alarm** – The alarm triggered, but the metric behavior was actually normal. CloudWatch adjusts the anomaly detection model to reduce false positives.
   + **Missed** – The alarm did not trigger, but the metric behavior was anomalous and should have been detected. CloudWatch adjusts the anomaly detection model to improve sensitivity.

1. For **Reason**, choose the reason that best describes why the alarm behavior was incorrect:
   + **Bands learning too fast** – The anomaly detection bands are adapting too quickly to recent changes in metric behavior, treating new patterns as normal too soon.
   + **Bands learning too slow** – The anomaly detection bands are not adapting quickly enough to legitimate changes in metric behavior.
   + **Bands too wide** – The expected range of normal values is too broad, causing the alarm to miss anomalies.
   + **Bands too narrow** – The expected range of normal values is too tight, causing the alarm to trigger on normal metric variations.
   + **Band level off** – The anomaly detection bands are not aligned with the expected baseline level of the metric.
   + **Planned deployment** – The alarm fired due to a planned deployment or change.
   + **Scaling event** – The alarm fired due to an expected scaling event (such as auto-scaling).
   + **Other** – The alarm behavior was incorrect for a reason not listed above.

1. Choose **Submit**.

CloudWatch processes your feedback and adjusts the anomaly detection model accordingly. For false alarm and missed feedback, CloudWatch automatically tunes the model's learning rate or band width based on the reason that you provide.

**Note**  
You can submit feedback multiple times for different time ranges. Each piece of feedback is processed independently and contributes to improving the model's accuracy over time.

**Note**  
When you submit feedback, the CloudWatch console calls the `SubmitAlarmFeedback` API on your behalf. This API is used by the CloudWatch console only and is not intended to be called directly.