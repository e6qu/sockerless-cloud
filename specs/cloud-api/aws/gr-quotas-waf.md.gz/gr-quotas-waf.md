

# AWS WAF endpoints and quotas
<a name="waf"></a>

To connect programmatically to an AWS service, you use an endpoint. AWS services offer the following endpoint types in some or all of the AWS Regions that the service supports: IPv4 endpoints, dual-stack endpoints, and FIPS endpoints. Some services provide global endpoints. For more information, see [AWS service endpoints](rande.md).

Service quotas, also referred to as limits, are the maximum number of service resources or operations for your AWS account. For more information, see [AWS service quotas](aws_service_limits.md).

The following are the service endpoints and service quotas for this service.

**Note**  
This page provides information related the latest version of AWS WAF, released in November 2019. The names of the entities that you use to access AWS WAF, like endpoints and namespaces, all have the versioning information added, like `V2` or `v2`, to distinguish from the prior version.

## Service endpoints
<a name="waf_region"></a>


| Region Name | Region | Endpoint | Protocol | 
| --- | --- | --- | --- | 
| US East (Ohio) | us-east-2 |  wafv2.us-east-2.amazonaws.com <br /> wafv2-fips.us-east-2.amazonaws.com  | HTTPS<br />HTTPS | 
| US East (N. Virginia) | us-east-1 |  wafv2.us-east-1.amazonaws.com <br /> wafv2-fips.us-east-1.amazonaws.com  | HTTPS<br />HTTPS | 
| US West (N. California) | us-west-1 |  wafv2.us-west-1.amazonaws.com <br /> wafv2-fips.us-west-1.amazonaws.com  | HTTPS<br />HTTPS | 
| US West (Oregon) | us-west-2 |  wafv2.us-west-2.amazonaws.com <br /> wafv2-fips.us-west-2.amazonaws.com  | HTTPS<br />HTTPS | 
| Africa (Cape Town) | af-south-1 |  wafv2.af-south-1.amazonaws.com <br /> wafv2-fips.af-south-1.amazonaws.com  | HTTPS<br />HTTPS | 
| Asia Pacific (Hong Kong) | ap-east-1 |  wafv2.ap-east-1.amazonaws.com <br /> wafv2-fips.ap-east-1.amazonaws.com  | HTTPS<br />HTTPS | 
| Asia Pacific (Hyderabad) | ap-south-2 |  wafv2.ap-south-2.amazonaws.com <br /> wafv2-fips.ap-south-2.amazonaws.com  | HTTPS<br />HTTPS | 
| Asia Pacific (Jakarta) | ap-southeast-3 |  wafv2.ap-southeast-3.amazonaws.com <br /> wafv2-fips.ap-southeast-3.amazonaws.com  | HTTPS<br />HTTPS | 
| Asia Pacific (Malaysia) | ap-southeast-5 |  wafv2.ap-southeast-5.amazonaws.com <br /> wafv2-fips.ap-southeast-5.amazonaws.com  | HTTPS<br />HTTPS | 
| Asia Pacific (Melbourne) | ap-southeast-4 |  wafv2.ap-southeast-4.amazonaws.com <br /> wafv2-fips.ap-southeast-4.amazonaws.com  | HTTPS<br />HTTPS | 
| Asia Pacific (Mumbai) | ap-south-1 |  wafv2.ap-south-1.amazonaws.com <br /> wafv2-fips.ap-south-1.amazonaws.com  | HTTPS<br />HTTPS | 
| Asia Pacific (New Zealand) | ap-southeast-6 |  wafv2.ap-southeast-6.amazonaws.com <br /> wafv2-fips.ap-southeast-6.amazonaws.com  | HTTPS<br />HTTPS | 
| Asia Pacific (Osaka) | ap-northeast-3 |  wafv2.ap-northeast-3.amazonaws.com <br /> wafv2-fips.ap-northeast-3.amazonaws.com  | HTTPS<br />HTTPS | 
| Asia Pacific (Seoul) | ap-northeast-2 |  wafv2.ap-northeast-2.amazonaws.com <br /> wafv2-fips.ap-northeast-2.amazonaws.com  | HTTPS<br />HTTPS | 
| Asia Pacific (Singapore) | ap-southeast-1 |  wafv2.ap-southeast-1.amazonaws.com <br /> wafv2-fips.ap-southeast-1.amazonaws.com  | HTTPS<br />HTTPS | 
| Asia Pacific (Sydney) | ap-southeast-2 |  wafv2.ap-southeast-2.amazonaws.com <br /> wafv2-fips.ap-southeast-2.amazonaws.com  | HTTPS<br />HTTPS | 
| Asia Pacific (Taipei) | ap-east-2 |  wafv2.ap-east-2.amazonaws.com <br /> wafv2-fips.ap-east-2.amazonaws.com  | HTTPS<br />HTTPS | 
| Asia Pacific (Thailand) | ap-southeast-7 |  wafv2.ap-southeast-7.amazonaws.com <br /> wafv2-fips.ap-southeast-7.amazonaws.com  | HTTPS<br />HTTPS | 
| Asia Pacific (Tokyo) | ap-northeast-1 |  wafv2.ap-northeast-1.amazonaws.com <br /> wafv2-fips.ap-northeast-1.amazonaws.com  | HTTPS<br />HTTPS | 
| Canada (Central) | ca-central-1 |  wafv2.ca-central-1.amazonaws.com <br /> wafv2-fips.ca-central-1.amazonaws.com  | HTTPS<br />HTTPS | 
| Canada West (Calgary) | ca-west-1 |  wafv2.ca-west-1.amazonaws.com <br /> wafv2-fips.ca-west-1.amazonaws.com  | HTTPS<br />HTTPS | 
| Europe (Frankfurt) | eu-central-1 |  wafv2.eu-central-1.amazonaws.com <br /> wafv2-fips.eu-central-1.amazonaws.com  | HTTPS<br />HTTPS | 
| Europe (Ireland) | eu-west-1 |  wafv2.eu-west-1.amazonaws.com <br /> wafv2-fips.eu-west-1.amazonaws.com  | HTTPS<br />HTTPS | 
| Europe (London) | eu-west-2 |  wafv2.eu-west-2.amazonaws.com <br /> wafv2-fips.eu-west-2.amazonaws.com  | HTTPS<br />HTTPS | 
| Europe (Milan) | eu-south-1 |  wafv2.eu-south-1.amazonaws.com <br /> wafv2-fips.eu-south-1.amazonaws.com  | HTTPS<br />HTTPS | 
| Europe (Paris) | eu-west-3 |  wafv2.eu-west-3.amazonaws.com <br /> wafv2-fips.eu-west-3.amazonaws.com  | HTTPS<br />HTTPS | 
| Europe (Spain) | eu-south-2 |  wafv2.eu-south-2.amazonaws.com <br /> wafv2-fips.eu-south-2.amazonaws.com  | HTTPS<br />HTTPS | 
| Europe (Stockholm) | eu-north-1 |  wafv2.eu-north-1.amazonaws.com <br /> wafv2-fips.eu-north-1.amazonaws.com  | HTTPS<br />HTTPS | 
| Europe (Zurich) | eu-central-2 |  wafv2.eu-central-2.amazonaws.com <br /> wafv2-fips.eu-central-2.amazonaws.com  | HTTPS<br />HTTPS | 
| Israel (Tel Aviv) | il-central-1 |  wafv2.il-central-1.amazonaws.com <br /> wafv2-fips.il-central-1.amazonaws.com  | HTTPS<br />HTTPS | 
| Mexico (Central) | mx-central-1 |  wafv2.mx-central-1.amazonaws.com <br /> wafv2-fips.mx-central-1.amazonaws.com  | HTTPS<br />HTTPS | 
| Middle East (Bahrain) | me-south-1 |  wafv2.me-south-1.amazonaws.com <br /> wafv2-fips.me-south-1.amazonaws.com  | HTTPS<br />HTTPS | 
| Middle East (UAE) | me-central-1 |  wafv2.me-central-1.amazonaws.com <br /> wafv2-fips.me-central-1.amazonaws.com  | HTTPS<br />HTTPS | 
| South America (São Paulo) | sa-east-1 |  wafv2.sa-east-1.amazonaws.com <br /> wafv2-fips.sa-east-1.amazonaws.com  | HTTPS<br />HTTPS | 
|  AWS GovCloud (US-East) | us-gov-east-1 |  wafv2.us-gov-east-1.amazonaws.com <br /> wafv2-fips.us-gov-east-1.amazonaws.com  | HTTPS<br />HTTPS | 
|  AWS GovCloud (US-West) | us-gov-west-1 |  wafv2.us-gov-west-1.amazonaws.com <br /> wafv2-fips.us-gov-west-1.amazonaws.com  | HTTPS<br />HTTPS | 

## Service quotas
<a name="limits_waf"></a>


| Name | Default | Adjustable | Description | 
| --- | --- | --- | --- | 
| Maximum IP sets per account in WAF for CloudFront | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/wafv2/quotas/L-F65D5473)  | The maximum number of IP sets you can create in your account for CloudFront. | 
| Maximum IP sets per account in WAF for regional | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/wafv2/quotas/L-D6DA96AE)  | The maximum number of IP sets you can create in your account for regional. | 
| Maximum combined size in kilobytes of all response body content for a single rule group or a single web ACL for CloudFront | Each supported Region: 50 | No | The maximum combined size in kilobytes of all response body content for a single rule group or a single web ACL for CloudFront. | 
| Maximum combined size in kilobytes of all response body content for a single rule group or a single web ACL for regional | Each supported Region: 50 | No | The maximum combined size in kilobytes of all response body content for a single rule group or a single web AC for regional. | 
| Maximum number of ALB associations per web ACL in WAF for regional | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/wafv2/quotas/L-C5E4D334)  | The maximum number of ALB associations per web ACL for regional. | 
| Maximum number of AWS Amplify associations per web ACL in WAF for CloudFront | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/wafv2/quotas/L-7ADC517D)  | The maximum number of AWS Amplify associations per web ACL for CloudFront. | 
| Maximum number of AWS App Runner service associations per web ACL in WAF for regional | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/wafv2/quotas/L-3D6A3ADF)  | The maximum number of AWS App Runner service associations per web ACL for regional. | 
| Maximum number of AWS AppSync GraphQL API associations per web ACL in WAF for regional | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/wafv2/quotas/L-5B2F9B11)  | The maximum number of AWS AppSync GraphQL API associations per web ACL for regional. | 
| Maximum number of AWS Verified Access instance associations per web ACL in WAF for regional | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/wafv2/quotas/L-08788A4E)  | The maximum number of AWS Verified Access instance associations per web ACL for regional. | 
| Maximum number of Amazon API Gateway REST API associations per web ACL in WAF for regional | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/wafv2/quotas/L-B32E8672)  | The maximum number of Amazon API Gateway REST API associations per web ACL for regional. | 
| Maximum number of Amazon Bedrock AgentCore Gateway associations per web ACL in WAF for regional | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/wafv2/quotas/L-2B217866)  | The maximum number of Amazon Bedrock AgentCore Gateway associations per web ACL for regional. | 
| Maximum number of Amazon Cognito user pool associations per web ACL in WAF for regional | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/wafv2/quotas/L-9FD4FE94)  | The maximum number of Amazon Cognito user pool associations per web ACL for regional. | 
| Maximum number of ELB Proxy associations per web ACL in WAF for regional | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/wafv2/quotas/L-0E0676C4)  | The maximum number of ELB Proxy associations per web ACL for regional. | 
| Maximum number of IP addresses in an IP set in WAF for CloudFront | Each supported Region: 10,000 | No | The maximum number of IP addresses allowed in an IP set for CloudFront. | 
| Maximum number of IP addresses in an IP set in WAF for regional | Each supported Region: 10,000 | No | The maximum number of IP addresses allowed in an IP set for regional. | 
| Maximum number of bytes in a string match (byte match) string in WAF for CloudFront | Each supported Region: 200 | No | The maximum number of bytes you can create in a string match (byte match) string for CloudFront. | 
| Maximum number of bytes in a string match (byte match) string in WAF for regional | Each supported Region: 200 | No | The maximum number of bytes you can create in a string match (byte match) string for regional. | 
| Maximum number of characters allowed in a regex pattern per account in WAF for Cloudfront | Each supported Region: 200 | No | The maximum number of characters allowed in a regex pattern in your account for CloudFront. | 
| Maximum number of characters allowed in a regex pattern per account in WAF for regional | Each supported Region: 200 | No | The maximum number of characters allowed in a regex pattern in your account for regional. | 
| Maximum number of custom headers for a single custom request definition for CloudFront | Each supported Region: 10 | No | The maximum number of custom headers for a single custom request definition for CloudFront. | 
| Maximum number of custom headers for a single custom request definition for regional | Each supported Region: 10 | No | The maximum number of custom headers for a single custom request definition for regional. | 
| Maximum number of custom headers for a single custom response definition for CloudFront | Each supported Region: 10 | No | The maximum number of custom headers for a single custom response definition for CloudFront. | 
| Maximum number of custom headers for a single custom response definition for regional | Each supported Region: 10 | No | The maximum number of custom headers for a single custom response definition for regional. | 
| Maximum number of custom request headers per web ACL or rule group for CloudFront | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/wafv2/quotas/L-3A878263)  | The maximum number of custom request headers per web ACL or rule group for CloudFront. | 
| Maximum number of custom request headers per web ACL or rule group for regional | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/wafv2/quotas/L-2D9CB303)  | The maximum number of custom request headers per web ACL or rule group for regional. | 
| Maximum number of custom response bodies per web ACL or rule group for CloudFront | Each supported Region: 50 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/wafv2/quotas/L-F7AF7D03)  | The maximum number of custom response bodies per web ACL or rule group for CloudFront. | 
| Maximum number of custom response bodies per web ACL or rule group for regional | Each supported Region: 50 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/wafv2/quotas/L-71C2E81B)  | The maximum number of custom response bodies per web ACL or rule group for regional. | 
| Maximum number of custom response headers per web ACL or rule group for CloudFront | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/wafv2/quotas/L-C4A384E0)  | The maximum number of custom response headers per web ACL or rule group for CloudFront. | 
| Maximum number of custom response headers per web ACL or rule group for regional | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/wafv2/quotas/L-E4E414A8)  | The maximum number of custom response headers per web ACL or rule group for regional. | 
| Maximum number of patterns in a regex pattern set per account in WAF for Cloudfront | Each supported Region: 10 | No | The maximum number of patterns in a regex pattern set you can create in your account for CloudFront. | 
| Maximum number of patterns in a regex pattern set per account in WAF for regional | Each supported Region: 10 | No | The maximum number of patterns in a regex pattern set you can create in your account for regional. | 
| Maximum number of rate-based statements per rule group in WAF for Cloudfront | Each supported Region: 4 | No | The maximum number of rate-based statements allowed in a rule group for CloudFront. | 
| Maximum number of rate-based statements per rule group in WAF for regional | Each supported Region: 4 | No | The maximum number of rate-based statements allowed in a rule group for regional. | 
| Maximum number of rate-based statements per web ACL in WAF for Cloudfront | Each supported Region: 10 | No | The maximum number of rate-based statements allowed in a web ACL for CloudFront. | 
| Maximum number of rate-based statements per web ACL in WAF for regional | Each supported Region: 10 | No | The maximum number of rate-based statements allowed in a web ACL for regional. | 
| Maximum number of referenced statements per rule group or web ACL in WAF for Cloudfront | Each supported Region: 50 | No | The maximum number of referenced statements allowed within a rule group or web ACL for CloudFront. | 
| Maximum number of referenced statements per rule group or web ACL in WAF for regional | Each supported Region: 50 | No | The maximum number of referenced statements allowed within a rule group or web ACL for regional. | 
| Maximum number of requests per second per web ACL for CloudFront | Each supported Region: 100,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/wafv2/quotas/L-FE21FEF6)  | The maximum number of requests per second per web ACL for CloudFront. | 
| Maximum number of requests per second per web ACL for regional | Each supported Region: 100,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/wafv2/quotas/L-A85235F6)  | The maximum number of requests per second per web ACL for regional. | 
| Maximum number of text transformations per rule statement for CloudFront | Each supported Region: 10 | No | The maximum number of text transformations per rule statement for CloudFront. | 
| Maximum number of text transformations per rule statement for regional | Each supported Region: 10 | No | The maximum number of text transformations per rule statement for regional. | 
| Maximum number of unique IP addresses that can be blocked per rate-based rule for CloudFront | Each supported Region: 10,000 | No | The maximum number of unique IP addresses that can be blocked per rate-based rule for CloudFront. | 
| Maximum number of unique IP addresses that can be blocked per rate-based rule for regional | Each supported Region: 10,000 | No | The maximum number of unique IP addresses that can be blocked per rate-based rule for regional. | 
| Maximum number of web ACL capacity units in a rule group in WAF for CloudFront | Each supported Region: 5,000 | No | The maximum number of web ACL capacity units allowed in a rule group for CloudFront. | 
| Maximum number of web ACL capacity units in a rule group in WAF for regional | Each supported Region: 5,000 | No | The maximum number of web ACL capacity units allowed in a rule group for regional. | 
| Maximum number of web ACL capacity units in a web ACL in WAF for CloudFront | Each supported Region: 5,000 | No | The maximum number of web ACL capacity units allowed in a web ACL for CloudFront. | 
| Maximum number of web ACL capacity units in a web ACL in WAF for regional | Each supported Region: 5,000 | No | The maximum number of web ACL capacity units allowed in a web ACL for regional. | 
| Maximum regex pattern sets per account in WAF for CloudFront | Each supported Region: 10 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/wafv2/quotas/L-8973BE90)  | The maximum number of regex pattern sets you can create in your account for CloudFront. | 
| Maximum regex pattern sets per account in WAF for regional | Each supported Region: 10 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/wafv2/quotas/L-BF0029B0)  | The maximum number of regex pattern sets you can create in your account for regional. | 
| Maximum rule groups per account in WAF for CloudFront | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/wafv2/quotas/L-9E2A3B2D)  | The maximum number of rule groups you can create in your account for CloudFront. | 
| Maximum rule groups per account in WAF for regional | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/wafv2/quotas/L-C5BCD850)  | The maximum number of rule groups you can create in your account for regional. | 
| Maximum size in kilobytes of a web request body that can be inspected for Application Load Balancer and AWS AppSync protections | Each supported Region: 8 | No | The maximum size in kilobytes of a web request body that can be inspected for Application Load Balancer and AWS AppSync protections. | 
| Maximum size in kilobytes of a web request body that can be inspected for CloudFront, API Gateway, Amazon Cognito, App Runner, and Verified Access protections | Each supported Region: 64 | No | The maximum size in kilobytes of a web request body that can be inspected for CloudFront, API Gateway, Amazon Cognito, App Runner, and Verified Access protections. | 
| Maximum size in kilobytes of the custom response body content for a single custom response definition for CloudFront | Each supported Region: 4 | No | The maximum size in kilobytes of the custom response body content for a single custom response definition for CloudFront. | 
| Maximum size in kilobytes of the custom response body content for a single custom response definition for regional | Each supported Region: 4 | No | The maximum size in kilobytes of the custom response body content for a single custom response definition for regional. | 
| Maximum web ACLs per account in WAF for CloudFront | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/wafv2/quotas/L-24189897)  | The maximum number of web ACLs you can create in your account for CloudFront. | 
| Maximum web ACLs per account in WAF for regional | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/wafv2/quotas/L-2EC3DE7B)  | The maximum number of web ACLs you can create in your account for regional. | 
| Minimum request rate that can be defined for a rate-based rule for CloudFront | Each supported Region: 10 | No | The minimum request rate that can be defined for a rate-based rule for CloudFront. | 
| Minimum request rate that can be defined for a rate-based rule for regional | Each supported Region: 10 | No | The minimum request rate that can be defined for a rate-based rule for regional. | 
| Number of token domains per web ACL for CloudFront | Each supported Region: 10 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/wafv2/quotas/L-85B5BC49)  | The number of token domains per web ACL for CloudFront. | 
| Number of token domains per web ACL for regional | Each supported Region: 10 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/wafv2/quotas/L-11D00F38)  | The number of token domains per web ACL for regional. | 

For more information, see [AWS WAF quotas](https://docs.aws.amazon.com/waf/latest/developerguide/limits.html) in the *AWS WAF Developer Guide*.