

# Amazon CloudWatch Logs endpoints and quotas
<a name="cwl_region"></a>

To connect programmatically to an AWS service, you use an endpoint. AWS services offer the following endpoint types in some or all of the AWS Regions that the service supports: IPv4 endpoints, dual-stack endpoints, and FIPS endpoints. Some services provide global endpoints. For more information, see [AWS service endpoints](rande.md).

Service quotas, also referred to as limits, are the maximum number of service resources or operations for your AWS account. For more information, see [AWS service quotas](aws_service_limits.md).

The following are the service endpoints and service quotas for this service.

**Note**  
CloudWatch Logs also offers VPC Endpoints which support all of these endpoint types. For more information, see [Using CloudWatch Logs with interface VPC endpoints](https://docs.aws.amazon.com/AmazonCloudWatch/latest/logs/cloudwatch-logs-and-interface-VPC.html) in the *Amazon CloudWatch Logs User Guide*. 

You can use the endpoints in the following tables to connect to APIs.

## Logs Service endpoints
<a name="cwl_region"></a>


| Region Name | Region | Endpoint | Protocol | 
| --- | --- | --- | --- | 
| US East (Ohio) | us-east-2 |  logs.us-east-2.amazonaws.com <br /> logs.us-east-2.api.aws <br /> logs-fips.us-east-2.amazonaws.com <br /> logs-fips.us-east-2.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| US East (N. Virginia) | us-east-1 |  logs.us-east-1.amazonaws.com <br /> logs-fips.us-east-1.amazonaws.com <br /> logs.us-east-1.api.aws <br /> logs-fips.us-east-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| US West (N. California) | us-west-1 |  logs.us-west-1.amazonaws.com <br /> logs.us-west-1.api.aws <br /> logs-fips.us-west-1.api.aws <br /> logs-fips.us-west-1.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| US West (Oregon) | us-west-2 |  logs.us-west-2.amazonaws.com <br /> logs-fips.us-west-2.amazonaws.com <br /> logs.us-west-2.api.aws <br /> logs-fips.us-west-2.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Africa (Cape Town) | af-south-1 |  logs.af-south-1.amazonaws.com <br /> logs.af-south-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Hong Kong) | ap-east-1 |  logs.ap-east-1.amazonaws.com <br /> logs.ap-east-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Hyderabad) | ap-south-2 |  logs.ap-south-2.amazonaws.com <br /> logs.ap-south-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Jakarta) | ap-southeast-3 |  logs.ap-southeast-3.amazonaws.com <br /> logs.ap-southeast-3.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Malaysia) | ap-southeast-5 |  logs.ap-southeast-5.amazonaws.com <br /> logs.ap-southeast-5.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Melbourne) | ap-southeast-4 |  logs.ap-southeast-4.amazonaws.com <br /> logs.ap-southeast-4.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Mumbai) | ap-south-1 |  logs.ap-south-1.amazonaws.com <br /> logs.ap-south-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (New Zealand) | ap-southeast-6 |  logs.ap-southeast-6.amazonaws.com <br /> logs.ap-southeast-6.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Osaka) | ap-northeast-3 |  logs.ap-northeast-3.amazonaws.com <br /> logs.ap-northeast-3.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Seoul) | ap-northeast-2 |  logs.ap-northeast-2.amazonaws.com <br /> logs.ap-northeast-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Singapore) | ap-southeast-1 |  logs.ap-southeast-1.amazonaws.com <br /> logs.ap-southeast-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Sydney) | ap-southeast-2 |  logs.ap-southeast-2.amazonaws.com <br /> logs.ap-southeast-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Taipei) | ap-east-2 |  logs.ap-east-2.amazonaws.com <br /> logs.ap-east-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Thailand) | ap-southeast-7 |  logs.ap-southeast-7.amazonaws.com <br /> logs.ap-southeast-7.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Tokyo) | ap-northeast-1 |  logs.ap-northeast-1.amazonaws.com <br /> logs.ap-northeast-1.api.aws  | HTTPS<br />HTTPS | 
| Canada (Central) | ca-central-1 |  logs.ca-central-1.amazonaws.com <br /> logs.ca-central-1.api.aws <br /> logs-fips.ca-central-1.amazonaws.com <br /> logs-fips.ca-central-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Canada West (Calgary) | ca-west-1 |  logs.ca-west-1.amazonaws.com <br /> logs.ca-west-1.api.aws <br /> logs-fips.ca-west-1.amazonaws.com <br /> logs-fips.ca-west-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Europe (Frankfurt) | eu-central-1 |  logs.eu-central-1.amazonaws.com <br /> logs.eu-central-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Ireland) | eu-west-1 |  logs.eu-west-1.amazonaws.com <br /> logs.eu-west-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (London) | eu-west-2 |  logs.eu-west-2.amazonaws.com <br /> logs.eu-west-2.api.aws  | HTTPS<br />HTTPS | 
| Europe (Milan) | eu-south-1 |  logs.eu-south-1.amazonaws.com <br /> logs.eu-south-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Paris) | eu-west-3 |  logs.eu-west-3.amazonaws.com <br /> logs.eu-west-3.api.aws  | HTTPS<br />HTTPS | 
| Europe (Spain) | eu-south-2 |  logs.eu-south-2.amazonaws.com <br /> logs.eu-south-2.api.aws  | HTTPS<br />HTTPS | 
| Europe (Stockholm) | eu-north-1 |  logs.eu-north-1.amazonaws.com <br /> logs.eu-north-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Zurich) | eu-central-2 |  logs.eu-central-2.amazonaws.com <br /> logs.eu-central-2.api.aws  | HTTPS<br />HTTPS | 
| Israel (Tel Aviv) | il-central-1 |  logs.il-central-1.amazonaws.com <br /> logs.il-central-1.api.aws  | HTTPS<br />HTTPS | 
| Mexico (Central) | mx-central-1 |  logs.mx-central-1.amazonaws.com <br /> logs.mx-central-1.api.aws  | HTTPS<br />HTTPS | 
| Middle East (Bahrain) | me-south-1 |  logs.me-south-1.amazonaws.com <br /> logs.me-south-1.api.aws  | HTTPS<br />HTTPS | 
| Middle East (UAE) | me-central-1 |  logs.me-central-1.amazonaws.com <br /> logs.me-central-1.api.aws  | HTTPS<br />HTTPS | 
| South America (São Paulo) | sa-east-1 |  logs.sa-east-1.amazonaws.com <br /> logs.sa-east-1.api.aws  | HTTPS<br />HTTPS | 
|  AWS GovCloud (US-East) | us-gov-east-1 |  logs.us-gov-east-1.amazonaws.com <br /> logs.us-gov-east-1.api.aws  | HTTPS<br />HTTPS | 
|  AWS GovCloud (US-West) | us-gov-west-1 |  logs.us-gov-west-1.amazonaws.com <br /> logs.us-gov-west-1.api.aws  | HTTPS<br />HTTPS | 

## Service quotas
<a name="limits_cloudwatch_events"></a>


| Name | Default | Adjustable | Description | 
| --- | --- | --- | --- | 
| Active export task | Each supported Region: 1 | No | The number of active (running or pending) export tasks per account | 
| AssociateKmsKey throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of associate-kms-key calls per second per account/per region | 
| AssociateSourceToS3TableIntegration throttle limit in transactions per second | Each supported Region: 5 | No | The maximum number of AssociateSourceToS3TableIntegration calls per second per account/per region | 
| AssociateSourceToS3TableIntegration throttle limit in transactions per second in a burst | Each supported Region: 10 | No | The maximum number of AssociateSourceToS3TableIntegration calls per second per account/per region in a burst | 
| Batch size | Each supported Region: 1 Megabytes | No | The maximum batch size in MB of a put-log-events request | 
| CancelExportTask throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of cancel-export-task calls per second per account/per region | 
| CancelImportTask throttle limit in transactions per second | Each supported Region: 1 | No | The maximum number of CancelImportTask calls per second per account/per region | 
| CancelImportTask throttle limit in transactions per second in a burst | Each supported Region: 1 | No | The maximum number of CancelImportTask calls per second per account/per region in a burst | 
| CreateExportTask throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of create-export-task calls per second per account/per region | 
| CreateImportTask throttle limit in transactions per second | Each supported Region: 1 | No | The maximum number of CreateImportTask calls per second per account/per region | 
| CreateImportTask throttle limit in transactions per second in a burst | Each supported Region: 1 | No | The maximum number of CreateImportTask calls per second per account/per region in a burst | 
| CreateLogGroup throttle limit in transactions per second | Each supported Region: 10 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/logs/quotas/L-D2832119)  | The maximum number of create-log-group calls per second per account/per region | 
| CreateLogStream throttle limit in transactions per second | Each supported Region: 50 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/logs/quotas/L-76507CEF)  | The maximum number of create-log-stream calls per second per account/per region | 
| Data archiving | Each supported Region: 5 Gigabytes | No | The maximum size in GB of free data archiving | 
| DeleteDataProtectionPolicy throttle limit in transactions per second | Each supported Region: 5 | No | The maximum number of delete-data-protection-policy calls per second per account/per region | 
| DeleteDestination throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of delete-destination calls per second per account/per region | 
| DeleteLogGroup throttle limit in transactions per second | Each supported Region: 10 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/logs/quotas/L-07A912D5)  | The maximum number of delete-log-group calls per second per account/per region | 
| DeleteLogStream throttle limit in transactions per second | Each supported Region: 15 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/logs/quotas/L-C029A21C)  | The maximum number of delete-log-stream calls per second per account/per region | 
| DeleteMetricFilter throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of delete-metric-filter calls per second per account/per region | 
| DeleteRetentionPolicy throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of delete-retention-policy calls per second per account/per region | 
| DeleteSubscriptionFilter throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of delete-subscription-filter calls per second per account/per region | 
| DeleteTransformer throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of delete-transformer calls per second per account/per region | 
| DescribeDestinations throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of describe-destinations calls per second per account/per region | 
| DescribeExportTasks throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of describe-export-tasks calls per second per account/per region | 
| DescribeImportTaskBatches throttle limit in transactions per second | Each supported Region: 10 | No | The maximum number of DescribeImportTaskBatches calls per second per account/per region | 
| DescribeImportTaskBatches throttle limit in transactions per second in a burst | Each supported Region: 10 | No | The maximum number of DescribeImportTaskBatches calls per second per account/per region in a burst | 
| DescribeImportTasks throttle limit in transactions per second | Each supported Region: 10 | No | The maximum number of DescribeImportTasks calls per second per account/per region | 
| DescribeImportTasks throttle limit in transactions per second in a burst | Each supported Region: 10 | No | The maximum number of DescribeImportTasks calls per second per account/per region in a burst | 
| DescribeLogGroups throttle limit in transactions per second | Each supported Region: 10 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/logs/quotas/L-4284EEDE)  | The maximum number of describe-log-groups calls per second per account/per region | 
| DescribeLogStreams throttle limit in transactions per second | Each supported Region: 25 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/logs/quotas/L-3F243AD0)  | The maximum number of describe-log-streams calls per second per account/per region | 
| DescribeMetricFilters throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of describe-metric-filters calls per second per account/per region | 
| DescribeSubscriptionFilters throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of describe-subscription-filters calls per second per account/per region | 
| DisassociateSourceFromS3TableIntegration throttle limit in transactions per second | Each supported Region: 5 | No | The maximum number of DisassociateSourceFromS3TableIntegration calls per second per account/per region | 
| DisassociateSourceFromS3TableIntegration throttle limit in transactions per second in a burst | Each supported Region: 10 | No | The maximum number of DisassociateSourceFromS3TableIntegration calls per second per account/per region in a burst | 
| Event size | Each supported Region: 1,024 Kilobytes | No | The maximum log event size in KB | 
| FilterLogEvents throttle limit in transactions per second | us-east-1: 25 per second<br />ap-northeast-3: 5 per second<br />ap-southeast-3: 5 per second<br />ca-west-1: 5 per second<br />eu-central-1: 5 per second<br />il-central-1: 5 per second<br />Each of the other supported Regions: 10 per second | No | The maximum number of filter-log-events calls per second per account/per region | 
| GetDataProtectionPolicy throttle limit in transactions per second | Each supported Region: 5 | No | The maximum number of get-data-protection-policy calls per second per account/per region | 
| GetLogEvents throttle limit in transactions per second | us-west-2: 10 per second<br />ap-northeast-3: 10 per second<br />ap-southeast-3: 10 per second<br />ca-west-1: 10 per second<br />eu-central-1: 10 per second<br />eu-west-1: 10 per second<br />eu-west-3: 30 per second<br />il-central-1: 10 per second<br />Each of the other supported Regions: 25 per second | No | The maximum number of get-log-events calls per second per account/per region | 
| GetQueryResults throttle limit in transactions per second | Each supported Region: 10 | No | The maximum number of get-query-results calls per second per account/per region | 
| GetTransformer throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of get-transformer calls per second per account/per region | 
| ListSourcesForS3TableIntegration throttle limit in transactions per second | Each supported Region: 5 | No | The maximum number of ListSourcesForS3TableIntegration calls per second per account/per region | 
| ListSourcesForS3TableIntegration throttle limit in transactions per second in a burst | Each supported Region: 10 | No | The maximum number of ListSourcesForS3TableIntegration calls per second per account/per region in a burst | 
| ListTagsForResource throttle limit in transactions per second | Each supported Region: 30 per second | No | The maximum number of list-tags-for-resource calls per second per account/per region | 
| ListTagsLogGroup throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of list-tags-log-group calls per second per account/per region | 
| Live Tail concurrent sessions limit | Each supported Region: 15 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/logs/quotas/L-D6990B80)  | The maximum number of concurrent active Live Tail sessions per account | 
| Log groups | Each supported Region: 1,000,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/logs/quotas/L-C7B9AAAB)  | The maximum number of log groups an account can have | 
| Log groups scanned per Live Tail session | Each supported Region: 10 | No | The maximum number of log groups that can be scanned per Live Tail session | 
| Metrics filters per log group | Each supported Region: 100 | No | The number of metric filters per log group | 
| PutBearerTokenAuthentication throttle limit in transactions per second | Each supported Region: 5 | No | The maximum number of put-bearer-token-authentication calls per second per account/per region | 
| PutBearerTokenAuthentication throttle limit in transactions per second in a burst | Each supported Region: 10 | No | The maximum number of put-bearer-token-authentication calls per second per account/per region in a burst | 
| PutDataProtectionPolicy throttle limit in transactions per second | Each supported Region: 5 | No | The maximum number of put-data-protection-policy calls per second per account/per region | 
| PutDestination throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of put-destination calls per second per account/per region | 
| PutDestinationPolicy throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of put-destination-policy calls per second per account/per region | 
| PutLogEvents throttle limit in transactions per second | Each supported Region: 5,000 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/logs/quotas/L-7E1FAE88)  | The maximum number of put-log-events calls per second per account/per region | 
| PutMetricFilter throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of put-metric-filter calls per second per account/per region | 
| PutRetentionPolicy throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of put-retention-policy calls per second per account/per region | 
| PutSubscriptionFilter throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of put-subscription-filter calls per second per account/per region | 
| PutTransformer throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of put-transformer calls per second per account/per region | 
| Resource policies | Each supported Region: 10 | No | The maximum number of resource policies per account/per region | 
| StartLiveTail throttle limit in transactions per second | Each supported Region: 5 | No | The maximum number of start-live-tail calls per second per account/per region. This limit applies independently to both console and API | 
| StartQuery throttle limit in transactions per second | Each supported Region: 10 | No | The maximum number of start-query calls per second per account/per region | 
| Subscription filters per log group | Each supported Region: 5 | No | The number of subscription filters per log group | 
| TagLogGroup throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of tag-log-group calls per second per account/per region | 
| TagResource throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of tag-resource calls per second per account/per region | 
| TestMetricFilter throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of test-metric-filter calls per second per account/per region | 
| TestTransformer throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of test-transformer calls per second per account/per region | 
| UntagLogGroup throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of untag-log-group calls per second per account/per region | 
| UntagResource throttle limit in transactions per second | Each supported Region: 5 per second | No | The maximum number of untag-resource calls per second per account/per region | 
| logs anomaly detectors | Each supported Region: 500 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/logs/quotas/L-B53B9649)  | The maximum number of active log anomaly detectors | 

For more information, see [CloudWatch Logs quotas](https://docs.aws.amazon.com/AmazonCloudWatch/latest/logs/cloudwatch_limits_cwl.html) in the *Amazon CloudWatch Logs User Guide*.