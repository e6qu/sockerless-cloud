

# Amazon ElastiCache endpoints and quotas
<a name="elasticache-service"></a>

To connect programmatically to an AWS service, you use an endpoint. AWS services offer the following endpoint types in some or all of the AWS Regions that the service supports: IPv4 endpoints, dual-stack endpoints, and FIPS endpoints. Some services provide global endpoints. For more information, see [AWS service endpoints](rande.md).

Service quotas, also referred to as limits, are the maximum number of service resources or operations for your AWS account. For more information, see [AWS service quotas](aws_service_limits.md).

The following are the service endpoints and service quotas for this service.

## Service endpoints
<a name="elasticache_region"></a>


| Region Name | Region | Endpoint | Protocol | 
| --- | --- | --- | --- | 
| US East (Ohio) | us-east-2 |  elasticache.us-east-2.amazonaws.com <br /> elasticache-fips.us-east-2.api.aws <br /> elasticache.us-east-2.api.aws <br /> elasticache-fips.us-east-2.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| US East (N. Virginia) | us-east-1 |  elasticache.us-east-1.amazonaws.com <br /> elasticache-fips.us-east-1.api.aws <br /> elasticache-fips.us-east-1.amazonaws.com <br /> elasticache.us-east-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| US West (N. California) | us-west-1 |  elasticache.us-west-1.amazonaws.com <br /> elasticache.us-west-1.api.aws <br /> elasticache-fips.us-west-1.amazonaws.com <br /> elasticache-fips.us-west-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| US West (Oregon) | us-west-2 |  elasticache.us-west-2.amazonaws.com <br /> elasticache-fips.us-west-2.api.aws <br /> elasticache-fips.us-west-2.amazonaws.com <br /> elasticache.us-west-2.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Africa (Cape Town) | af-south-1 |  elasticache.af-south-1.amazonaws.com <br /> elasticache.af-south-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Hong Kong) | ap-east-1 |  elasticache.ap-east-1.amazonaws.com <br /> elasticache.ap-east-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Hyderabad) | ap-south-2 |  elasticache.ap-south-2.amazonaws.com <br /> elasticache.ap-south-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Jakarta) | ap-southeast-3 |  elasticache.ap-southeast-3.amazonaws.com <br /> elasticache.ap-southeast-3.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Malaysia) | ap-southeast-5 |  elasticache.ap-southeast-5.amazonaws.com <br /> elasticache.ap-southeast-5.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Melbourne) | ap-southeast-4 |  elasticache.ap-southeast-4.amazonaws.com <br /> elasticache.ap-southeast-4.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Mumbai) | ap-south-1 |  elasticache.ap-south-1.amazonaws.com <br /> elasticache.ap-south-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (New Zealand) | ap-southeast-6 |  elasticache.ap-southeast-6.amazonaws.com <br /> elasticache.ap-southeast-6.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Osaka) | ap-northeast-3 |  elasticache.ap-northeast-3.amazonaws.com <br /> elasticache.ap-northeast-3.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Seoul) | ap-northeast-2 |  elasticache.ap-northeast-2.amazonaws.com <br /> elasticache.ap-northeast-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Singapore) | ap-southeast-1 |  elasticache.ap-southeast-1.amazonaws.com <br /> elasticache.ap-southeast-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Sydney) | ap-southeast-2 |  elasticache.ap-southeast-2.amazonaws.com <br /> elasticache.ap-southeast-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Taipei) | ap-east-2 |  elasticache.ap-east-2.amazonaws.com <br /> elasticache.ap-east-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Thailand) | ap-southeast-7 |  elasticache.ap-southeast-7.amazonaws.com <br /> elasticache.ap-southeast-7.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Tokyo) | ap-northeast-1 |  elasticache.ap-northeast-1.amazonaws.com <br /> elasticache.ap-northeast-1.api.aws  | HTTPS<br />HTTPS | 
| Canada (Central) | ca-central-1 |  elasticache.ca-central-1.amazonaws.com <br /> elasticache.ca-central-1.api.aws <br /> elasticache-fips.ca-central-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS | 
| Canada West (Calgary) | ca-west-1 |  elasticache.ca-west-1.amazonaws.com <br /> elasticache.ca-west-1.api.aws <br /> elasticache-fips.ca-west-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS | 
| Europe (Frankfurt) | eu-central-1 |  elasticache.eu-central-1.amazonaws.com <br /> elasticache.eu-central-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Ireland) | eu-west-1 |  elasticache.eu-west-1.amazonaws.com <br /> elasticache.eu-west-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (London) | eu-west-2 |  elasticache.eu-west-2.amazonaws.com <br /> elasticache.eu-west-2.api.aws  | HTTPS<br />HTTPS | 
| Europe (Milan) | eu-south-1 |  elasticache.eu-south-1.amazonaws.com <br /> elasticache.eu-south-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Paris) | eu-west-3 |  elasticache.eu-west-3.amazonaws.com <br /> elasticache.eu-west-3.api.aws  | HTTPS<br />HTTPS | 
| Europe (Spain) | eu-south-2 |  elasticache.eu-south-2.amazonaws.com <br /> elasticache.eu-south-2.api.aws  | HTTPS<br />HTTPS | 
| Europe (Stockholm) | eu-north-1 |  elasticache.eu-north-1.amazonaws.com <br /> elasticache.eu-north-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Zurich) | eu-central-2 |  elasticache.eu-central-2.amazonaws.com <br /> elasticache.eu-central-2.api.aws  | HTTPS<br />HTTPS | 
| Israel (Tel Aviv) | il-central-1 |  elasticache.il-central-1.amazonaws.com <br /> elasticache.il-central-1.api.aws  | HTTPS<br />HTTPS | 
| Mexico (Central) | mx-central-1 |  elasticache.mx-central-1.amazonaws.com <br /> elasticache.mx-central-1.api.aws  | HTTPS<br />HTTPS | 
| Middle East (Bahrain) | me-south-1 |  elasticache.me-south-1.amazonaws.com <br /> elasticache.me-south-1.api.aws  | HTTPS<br />HTTPS | 
| Middle East (UAE) | me-central-1 |  elasticache.me-central-1.amazonaws.com <br /> elasticache.me-central-1.api.aws  | HTTPS<br />HTTPS | 
| South America (São Paulo) | sa-east-1 |  elasticache.sa-east-1.amazonaws.com <br /> elasticache.sa-east-1.api.aws  | HTTPS<br />HTTPS | 
|  AWS GovCloud (US-East) | us-gov-east-1 |  elasticache.us-gov-east-1.amazonaws.com <br /> elasticache.us-gov-east-1.api.aws <br /> elasticache-fips.us-gov-east-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS | 
|  AWS GovCloud (US-West) | us-gov-west-1 |  elasticache.us-gov-west-1.amazonaws.com <br /> elasticache.us-gov-west-1.api.aws <br /> elasticache-fips.us-gov-west-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS | 

## Service quotas
<a name="limits_elasticache"></a>


| Name | Default | Adjustable | Description | 
| --- | --- | --- | --- | 
| Nodes per Region | Each supported Region: 300 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/elasticache/quotas/L-DFE45DF3)  | The maximum number of nodes across all clusters in a Region. This quota applies to both your reserved and non-reserved nodes within the given Region. You can have up to 300 reserved nodes and 300 non-reserved nodes in the same Region. | 
| Nodes per cluster (Memcached) | Each supported Region: 60 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/elasticache/quotas/L-8C334AD1)  | The maximum number of nodes in an individual Memcached cluster. | 
| Nodes per cluster (cluster mode enabled) | Each supported Region: 90 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/elasticache/quotas/L-AF354865)  | The maximum number of nodes in an individual Redis or Valkey cluster. | 
| Nodes per shard | Each supported Region: 6 | No | The maximum number of nodes in an individual shard (node group). One node is the read/write Primary. All other nodes are read-only Replicas. | 
| Parameter groups per Region | Each supported Region: 300 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/elasticache/quotas/L-3F15A733)  | The maximum number of parameters groups you can create in a Region. | 
| Serverless Caches per Region | Each supported Region: 40 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/elasticache/quotas/L-BBCDAECC)  | The maximum number of serverless caches in a Region. | 
| Serverless snapshots per day per cache | Each supported Region: 24 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/elasticache/quotas/L-75A7B5A4)  | The maximum number of snapshots that can be taken per day per serverless cache. | 
| Subnet groups per Region | Each supported Region: 300 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/elasticache/quotas/L-3E7F7726)  | The maximum number of subnet groups you can create in a Region. | 
| Subnets per subnet group | Each supported Region: 20 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/elasticache/quotas/L-A87EE522)  | The maximum number of subnets you can define for a subnet group. | 
| User Groups per Region | Each supported Region: 200 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/elasticache/quotas/L-AD484FC5)  | The maximum number of user groups you can create in a Region. | 
| Users per Region | Each supported Region: 2,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/elasticache/quotas/L-80E085C7)  | The maximum number of users you can create in a Region. | 
| Users per User Group | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/elasticache/quotas/L-943F0F1C)  | The maximum number of users you can define for a user group. | 