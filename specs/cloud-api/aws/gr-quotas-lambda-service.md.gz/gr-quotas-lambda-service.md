

# AWS Lambda endpoints and quotas
<a name="lambda-service"></a>

To connect programmatically to an AWS service, you use an endpoint. AWS services offer the following endpoint types in some or all of the AWS Regions that the service supports: IPv4 endpoints, dual-stack endpoints, and FIPS endpoints. Some services provide global endpoints. For more information, see [AWS service endpoints](rande.md).

Service quotas, also referred to as limits, are the maximum number of service resources or operations for your AWS account. For more information, see [AWS service quotas](aws_service_limits.md).

The following are the service endpoints and service quotas for this service.

## Service endpoints
<a name="lambda_region"></a>


| Region Name | Region | Endpoint | Protocol | 
| --- | --- | --- | --- | 
| US East (Ohio) | us-east-2 |  lambda.us-east-2.amazonaws.com <br /> lambda-fips.us-east-2.amazonaws.com <br /> lambda.us-east-2.api.aws  | HTTPS<br />HTTPS<br />HTTPS | 
| US East (N. Virginia) | us-east-1 |  lambda.us-east-1.amazonaws.com <br /> lambda-fips.us-east-1.amazonaws.com <br /> lambda.us-east-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS | 
| US West (N. California) | us-west-1 |  lambda.us-west-1.amazonaws.com <br /> lambda-fips.us-west-1.amazonaws.com <br /> lambda.us-west-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS | 
| US West (Oregon) | us-west-2 |  lambda.us-west-2.amazonaws.com <br /> lambda-fips.us-west-2.amazonaws.com <br /> lambda.us-west-2.api.aws  | HTTPS<br />HTTPS<br />HTTPS | 
| Africa (Cape Town) | af-south-1 |  lambda.af-south-1.amazonaws.com <br /> lambda.af-south-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Hong Kong) | ap-east-1 |  lambda.ap-east-1.amazonaws.com <br /> lambda.ap-east-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Hyderabad) | ap-south-2 |  lambda.ap-south-2.amazonaws.com <br /> lambda.ap-south-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Jakarta) | ap-southeast-3 |  lambda.ap-southeast-3.amazonaws.com <br /> lambda.ap-southeast-3.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Malaysia) | ap-southeast-5 |  lambda.ap-southeast-5.amazonaws.com <br /> lambda.ap-southeast-5.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Melbourne) | ap-southeast-4 |  lambda.ap-southeast-4.amazonaws.com <br /> lambda.ap-southeast-4.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Mumbai) | ap-south-1 |  lambda.ap-south-1.amazonaws.com <br /> lambda.ap-south-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (New Zealand) | ap-southeast-6 |  lambda.ap-southeast-6.amazonaws.com <br /> lambda.ap-southeast-6.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Osaka) | ap-northeast-3 |  lambda.ap-northeast-3.amazonaws.com <br /> lambda.ap-northeast-3.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Seoul) | ap-northeast-2 |  lambda.ap-northeast-2.amazonaws.com <br /> lambda.ap-northeast-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Singapore) | ap-southeast-1 |  lambda.ap-southeast-1.amazonaws.com <br /> lambda.ap-southeast-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Sydney) | ap-southeast-2 |  lambda.ap-southeast-2.amazonaws.com <br /> lambda.ap-southeast-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Taipei) | ap-east-2 |  lambda.ap-east-2.amazonaws.com <br /> lambda.ap-east-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Thailand) | ap-southeast-7 |  lambda.ap-southeast-7.amazonaws.com <br /> lambda.ap-southeast-7.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Tokyo) | ap-northeast-1 |  lambda.ap-northeast-1.amazonaws.com <br /> lambda.ap-northeast-1.api.aws  | HTTPS<br />HTTPS | 
| Canada (Central) | ca-central-1 |  lambda.ca-central-1.amazonaws.com <br /> lambda.ca-central-1.api.aws  | HTTPS<br />HTTPS | 
| Canada West (Calgary) | ca-west-1 |  lambda.ca-west-1.amazonaws.com <br /> lambda.ca-west-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Frankfurt) | eu-central-1 |  lambda.eu-central-1.amazonaws.com <br /> lambda.eu-central-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Ireland) | eu-west-1 |  lambda.eu-west-1.amazonaws.com <br /> lambda.eu-west-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (London) | eu-west-2 |  lambda.eu-west-2.amazonaws.com <br /> lambda.eu-west-2.api.aws  | HTTPS<br />HTTPS | 
| Europe (Milan) | eu-south-1 |  lambda.eu-south-1.amazonaws.com <br /> lambda.eu-south-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Paris) | eu-west-3 |  lambda.eu-west-3.amazonaws.com <br /> lambda.eu-west-3.api.aws  | HTTPS<br />HTTPS | 
| Europe (Spain) | eu-south-2 |  lambda.eu-south-2.amazonaws.com <br /> lambda.eu-south-2.api.aws  | HTTPS<br />HTTPS | 
| Europe (Stockholm) | eu-north-1 |  lambda.eu-north-1.amazonaws.com <br /> lambda.eu-north-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Zurich) | eu-central-2 |  lambda.eu-central-2.amazonaws.com <br /> lambda.eu-central-2.api.aws  | HTTPS<br />HTTPS | 
| Israel (Tel Aviv) | il-central-1 |  lambda.il-central-1.amazonaws.com <br /> lambda.il-central-1.api.aws  | HTTPS<br />HTTPS | 
| Mexico (Central) | mx-central-1 |  lambda.mx-central-1.amazonaws.com <br /> lambda.mx-central-1.api.aws  | HTTPS<br />HTTPS | 
| Middle East (Bahrain) | me-south-1 |  lambda.me-south-1.amazonaws.com <br /> lambda.me-south-1.api.aws  | HTTPS<br />HTTPS | 
| Middle East (UAE) | me-central-1 |  lambda.me-central-1.amazonaws.com <br /> lambda.me-central-1.api.aws  | HTTPS<br />HTTPS | 
| South America (São Paulo) | sa-east-1 |  lambda.sa-east-1.amazonaws.com <br /> lambda.sa-east-1.api.aws  | HTTPS<br />HTTPS | 
|  AWS GovCloud (US-East) | us-gov-east-1 |  lambda.us-gov-east-1.amazonaws.com <br /> lambda-fips.us-gov-east-1.amazonaws.com <br /> lambda.us-gov-east-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS | 
|  AWS GovCloud (US-West) | us-gov-west-1 |  lambda.us-gov-west-1.amazonaws.com <br /> lambda-fips.us-gov-west-1.amazonaws.com <br /> lambda.us-gov-west-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS | 

## Service quotas
<a name="limits_lambda"></a>

**Important**  
New AWS accounts have reduced concurrency and memory quotas. AWS raises these quotas automatically based on your usage. You can also [request a quota increase](https://docs.aws.amazon.com/servicequotas/latest/userguide/request-quota-increase.html).


| Name | Default | Adjustable | Description | 
| --- | --- | --- | --- | 
| Arm vCPUs for all Web Functions | Each supported Region: 2,000 | No | The Arm64 vCPU capacity for Lambda Web Function execution environments in this account in the current Region. | 
| Asynchronous invocation request throughput on Lambda Managed Instances | Each supported Region: 5 Megabytes/Second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/lambda/quotas/L-A723F9CC)  | The maximum invoke request throughput (MB/s) for asynchronous invocations on Lambda Managed Instances. Asynchronous invocations occur when Lambda functions are invoked by services such as Amazon S3 or Amazon SNS. | 
| Asynchronous payload | Each supported Region: 1,024 Kilobytes | No | The maximum size of an incoming asynchronous invocation request. | 
| Burst rate of CreateMicrovmAuthToken API requests | Each supported Region: 50 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/lambda/quotas/L-D65D9F16)  | The maximum number of CreateMicrovmAuthToken API requests that can be sent in one burst. | 
| Burst rate of CreateMicrovmShellAuthToken API requests | Each supported Region: 5 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/lambda/quotas/L-9A5E43A5)  | The maximum number of CreateMicrovmShellAuthToken API requests that can be sent in one burst. | 
| Burst rate of GetMicrovm API requests | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/lambda/quotas/L-C9C2110E)  | The maximum number of GetMicrovm API requests that can be sent in one burst. | 
| Burst rate of ResumeMicrovm API requests | Each supported Region: 5 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/lambda/quotas/L-25EEC0A4)  | The maximum number of ResumeMicrovm API requests that can be sent in one burst. | 
| Burst rate of RunMicrovm API requests | Each supported Region: 5 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/lambda/quotas/L-91B95582)  | The maximum number of RunMicrovm API requests that can be sent in one burst. | 
| Burst rate of SuspendMicrovm API requests | Each supported Region: 2 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/lambda/quotas/L-139F9A48)  | The maximum number of SuspendMicrovm API requests that can be sent in one burst. | 
| Burst rate of TerminateMicrovm API requests | Each supported Region: 10 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/lambda/quotas/L-2CCA0501)  | The maximum number of TerminateMicrovm API requests that can be sent in one burst. | 
| Capacity providers | Each supported Region: 1,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/lambda/quotas/L-F864D568)  | The maximum number of capacity providers that can be created in an account. | 
| Concurrency scaling rate | Each supported Region: 1,000 | No | The maximum immediate increase in function concurrency that can occur in response to an increase in traffic or execution duration. Every 10 seconds, each synchronously invoked Lambda function can scale by an additional 1,000 concurrent executions until the total concurrency across your functions in a Region reaches the account concurrency limit. | 
| Concurrent connections per 1 vCPU MicroVM | Each supported Region: 8 Count | No | Maximum number of concurrent connections per MicroVM with 1 vCPUs. | 
| Concurrent connections per 16 vCPU MicroVM | Each supported Region: 128 Count | No | Maximum number of concurrent connections per MicroVM with 16 vCPUs. | 
| Concurrent connections per 2 vCPU MicroVM | Each supported Region: 16 Count | No | Maximum number of concurrent connections per MicroVM with 2 vCPUs. | 
| Concurrent connections per 4 vCPU MicroVM | Each supported Region: 32 Count | No | Maximum number of concurrent connections per MicroVM with 4 vCPUs. | 
| Concurrent connections per 8 vCPU MicroVM | Each supported Region: 64 Count | No | Maximum number of concurrent connections per MicroVM with 8 vCPUs. | 
| Concurrent executions | Each supported Region: 1,000 Count |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/lambda/quotas/L-B99A9384)  | The maximum number of events that functions can process simultaneously in the current Region. | 
| Deployment package size (console editor) | Each supported Region: 3 Megabytes | No | The maximum size of a deployment package or layer archive when you upload it through the console editor. Upload larger files with Amazon S3. | 
| Deployment package size (direct upload) | Each supported Region: 50 Megabytes | No | The maximum size of a deployment package or layer archive when you upload it directly to Lambda. Upload larger files with Amazon S3. | 
| Deployment package size (unzipped) | Each supported Region: 250 Megabytes | No | The maximum size of the contents of a deployment package or layer archive when its unzipped. | 
| Durable execution storage written in megabytes | Each supported Region: 100 Megabytes | No | The maximum cumulative amount of data persisted per durable execution, including input and output payloads, checkpoints and error data, measured in megabytes. | 
| DynamoDB Event Source Mapping throughput on Lambda Managed Instances | Each supported Region: 10 Megabytes/Second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/lambda/quotas/L-7E8754C7)  | The maximum data throughput (MB/s) per DynamoDB event source mapping on Lambda Managed Instances. | 
| Elastic network interfaces per VPC | Each supported Region: 3,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/lambda/quotas/L-9FEE3D26)  | The maximum number of network interfaces that Lambda creates for a VPC with functions attached. Lambda creates a network interface for each combination of subnet and security group that functions connect to. | 
| Endpoints per Web Function | Each supported Region: 10 | No | The maximum number of endpoints allowed per Lambda Web Function. | 
| Environment variable size | Each supported Region: 4 Kilobytes | No | The maximum combined size of environment variables that are configured on a function. | 
| File descriptors | Each supported Region: 1,024 | No | The maximum number of file descriptors that a function can have open. | 
| Function and layer storage | Each supported Region: 300 Gigabytes |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/lambda/quotas/L-2ACBD22F)  | The amount of storage thats available for deployment packages and layer archives in the current Region. | 
| Function invocation rate to initiate durable executions | us-east-1: 6,000<br />us-west-2: 6,000<br />eu-west-1: 6,000<br />Each of the other supported Regions: 3,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/lambda/quotas/L-A0D6E196)  | The maximum number of new durable executions that you can initiate per second. | 
| Function layers | Each supported Region: 5 | No | The maximum number of layers that you can add to your function. | 
| Function resource-based policy | Each supported Region: 20 Kilobytes | No | The maximum combined size of resource-based policies that are configured on a function. | 
| Function timeout | Each supported Region: 900 | No | The maximum timeout that you can configure for a function. | 
| Function versions per capacity provider | Each supported Region: 100 | No | The maximum number of function versions per capacity provider. | 
| Kafka Event Source Mappings in default mode on Lambda Managed Instances | Each supported Region: 100 | No | The maximum number of Kafka event source mappings in default mode on Lambda Managed Instances. | 
| Kafka Stream Event Source Mapping throughput in non-provisioned mode | Each supported Region: 5 Megabytes/Second | No | The maximum data throughput (MB/s) per Kafka Stream event source mapping in non-provisioned mode. | 
| Kinesis Event Source Mapping throughput on Lambda Managed Instances | Each supported Region: 25 Megabytes/Second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/lambda/quotas/L-2EBBB6B4)  | The maximum data throughput (MB/s) per Kinesis event source mapping on Lambda Managed Instances. | 
| Max Execution Duration of a MicroVM (in Hours) | Each supported Region: 8 | No | The maximum execution duration of a MicroVM (in Hours). | 
| Max allocated ARM\_64 MicroVM memory | us-east-1: 2,048 Gigabytes<br />us-east-2: 2,048 Gigabytes<br />us-west-2: 2,048 Gigabytes<br />ap-northeast-1: 2,048 Gigabytes<br />ap-southeast-2: 2,048 Gigabytes<br />eu-central-1: 2,048 Gigabytes<br />eu-west-1: 2,048 Gigabytes<br />Each of the other supported Regions: 800 Gigabytes |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/lambda/quotas/L-CD1C0CC4)  | The maximum total configured baseline memory across all concurrently running ARM\_64 MicroVMs, per account, per region. Individual MicroVMs can burst up to 4x their configured baseline memory. | 
| Max allocated X86\_64 MicroVM memory | ap-south-1: 800 Gigabytes<br />ap-southeast-1: 800 Gigabytes<br />eu-north-1: 800 Gigabytes<br />Each of the other supported Regions: 2,048 Gigabytes |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/lambda/quotas/L-20EE1DBE)  | The maximum total configured baseline memory across all concurrently running X86\_64 MicroVMs, per account, per region. Individual MicroVMs can burst up to 4x their configured baseline memory. | 
| Maximum number of durable operations per durable execution | Each supported Region: 30,000 | No | The maximum number of durable operations (including customer-initiated operations and automatic retries) that trigger state persistence within a single durable execution. | 
| Maximum running durable executions | us-east-1: 10,000,000<br />us-west-2: 10,000,000<br />eu-west-1: 10,000,000<br />Each of the other supported Regions: 5,000,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/lambda/quotas/L-ABBF0CF3)  | The maximum number of durable executions that can be running simultaneously in the current region. | 
| Network bandwidth per execution environment | Each supported Region: 625 Megabits/Second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/lambda/quotas/L-14320ECE)  | The maximum sustained network bandwidth, in megabits per second, for a Lambda functions execution environment that is not attached to a VPC. | 
| Network connectors | Each supported Region: 1,000 | No | Number of Network Connectors per account | 
| Number of MicroVM images | Each supported Region: 100 Count |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/lambda/quotas/L-942E56BE)  | Number of MicroVM images per account per region | 
| Number of concurrent MicroVM image builds | us-east-1: 10 Count<br />us-east-2: 10 Count<br />us-west-2: 10 Count<br />ap-northeast-1: 10 Count<br />Each of the other supported Regions: 5 Count |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/lambda/quotas/L-72E0D058)  | Number of concurrent MicroVM image builds per account per region | 
| Processes and threads | Each supported Region: 1,024 | No | The maximum combined number of processes and threads that a function can have open. | 
| RPS per 16 vCPU MicroVm | Each supported Region: 160 Count | No | Maximum number of requests per second per MicroVM with 16 vCPUs / 32 GB. | 
| RPS per 4 vCPU MicroVm | Each supported Region: 40 Count | No | Maximum number of requests per second per MicroVM with 4 vCPUs / 8 GB. | 
| Rate of CheckpointDurableExecution API requests | us-east-1: 20,000<br />us-west-2: 20,000<br />eu-west-1: 20,000<br />Each of the other supported Regions: 10,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/lambda/quotas/L-DF87A8A6)  | The maximum number of CheckpointDurableExecution API requests per second. | 
| Rate of CreateMicrovmAuthToken API requests | Each supported Region: 50 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/lambda/quotas/L-7712260B)  | The maximum number of CreateMicrovmAuthToken API requests per second. | 
| Rate of CreateMicrovmShellAuthToken API requests | Each supported Region: 5 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/lambda/quotas/L-B78D2ECC)  | The maximum number of CreateMicrovmShellAuthToken API requests per second in this account in the current Region. | 
| Rate of GetDurableExecution API requests | us-east-1: 600<br />us-west-2: 600<br />eu-west-1: 600<br />Each of the other supported Regions: 300 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/lambda/quotas/L-9B52FC60)  | The maximum number of GetDurableExecution API requests per second. | 
| Rate of GetDurableExecutionHistory API requests | us-east-1: 300<br />us-west-2: 300<br />eu-west-1: 300<br />Each of the other supported Regions: 150 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/lambda/quotas/L-BA29C22B)  | The maximum number of GetDurableExecutionHistory API requests per second. | 
| Rate of GetDurableExecutionState API requests | us-east-1: 20,000<br />us-west-2: 20,000<br />eu-west-1: 20,000<br />Each of the other supported Regions: 10,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/lambda/quotas/L-50EA21A9)  | The maximum number of GetDurableExecutionState API requests per second. | 
| Rate of GetFunction API requests | Each supported Region: 100 | No | The maximum number of GetFunction API requests per second. | 
| Rate of GetMicrovm API requests | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/lambda/quotas/L-CE98C9E3)  | The maximum number of GetMicrovm API requests per second. | 
| Rate of GetPolicy API requests | Each supported Region: 15 | No | The maximum number of GetPolicy API requests per second. | 
| Rate of ListDurableExecutionsByFunction API requests | us-east-1: 300<br />us-west-2: 300<br />eu-west-1: 300<br />Each of the other supported Regions: 150 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/lambda/quotas/L-6A3611ED)  | The maximum number of ListDurableExecutionsByFunction API requests per second. | 
| Rate of ResumeMicrovm API requests | Each supported Region: 5 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/lambda/quotas/L-118C44B3)  | The maximum number of ResumeMicrovm API requests per second. | 
| Rate of RunMicrovm API requests | Each supported Region: 5 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/lambda/quotas/L-535CA9B6)  | The maximum number of RunMicrovm API requests per second | 
| Rate of SendDurableExecutionCallbackFailure API requests | us-east-1: 6,000<br />us-west-2: 6,000<br />eu-west-1: 6,000<br />Each of the other supported Regions: 3,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/lambda/quotas/L-88CBC2FA)  | The maximum number of SendDurableExecutionCallbackFailure API requests per second. | 
| Rate of SendDurableExecutionCallbackHeartbeat API requests | us-east-1: 6,000<br />us-west-2: 6,000<br />eu-west-1: 6,000<br />Each of the other supported Regions: 3,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/lambda/quotas/L-133D658A)  | The maximum number of SendDurableExecutionCallbackHeartbeat API requests per second. | 
| Rate of SendDurableExecutionCallbackSuccess API requests | us-east-1: 6,000<br />us-west-2: 6,000<br />eu-west-1: 6,000<br />Each of the other supported Regions: 3,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/lambda/quotas/L-B82A30EA)  | The maximum number of SendDurableExecutionCallbackSuccess API requests per second. | 
| Rate of StopDurableExecution API requests | us-east-1: 600<br />us-west-2: 600<br />eu-west-1: 600<br />Each of the other supported Regions: 300 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/lambda/quotas/L-4C4550DE)  | The maximum number of StopDurableExecution API requests per second. | 
| Rate of SuspendMicrovm API requests | Each supported Region: 2 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/lambda/quotas/L-90045317)  | The maximum number of SuspendMicrovm API requests per second. | 
| Rate of TerminateMicrovm API requests | Each supported Region: 10 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/lambda/quotas/L-74787B8A)  | The maximum number of TerminateMicrovm API requests per second. | 
| Rate of capacity provider read API requests | Each supported Region: 15 | No | The maximum combined rate (requests per second) for all capacity provider read APIs. | 
| Rate of capacity provider write API requests | Each supported Region: 1 | No | The maximum combined rate (requests per second) for all capacity provider write APIs. | 
| Rate of control plane API requests (excludes invocation, GetFunction, and GetPolicy requests) | Each supported Region: 15 | No | The maximum number of API requests per second (excluding invocation, GetFunction, and GetPolicy requests). | 
| Rate of requests per Web Function Endpoint | Each supported Region: 10,000 | No | The maximum number of requests per second allowed for a single Lambda Web Function endpoint. | 
| Rate of requests to Web Functions | Each supported Region: 100,000 | No | The maximum number of requests per second allowed across all your Lambda Web Function endpoints in this account in the current Region. | 
| Revisions per Web Function | Each supported Region: 50 | No | The maximum number of revisions retained per Lambda Web Function. When this limit is reached, the oldest revisions not referenced by any endpoint are automatically deleted. | 
| SQS Event Source Mapping throughput in default mode on Lambda Managed Instances | Each supported Region: 5 Megabytes/Second | No | The maximum data throughput (MB/s) per SQS event source mapping in default mode on Lambda Managed Instances. | 
| Synchronous payload | Each supported Region: 6 Megabytes | No | The maximum size of an incoming synchronous invocation request or outgoing response. | 
| Test events (console editor) | Each supported Region: 10 | No | The maximum amount of test events for a function through the console editor. | 
| Versions per MicroVM Image | Each supported Region: 50 Count |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/lambda/quotas/L-F8BECE9C)  | The maximum number of versions per MicroVM image per account per region. | 

For more information, see [Lambda quotas](https://docs.aws.amazon.com/lambda/latest/dg/limits.html) in the *AWS Lambda Developer Guide*.