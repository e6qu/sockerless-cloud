

# AWS Certificate Manager endpoints and quotas
<a name="acm"></a>

To connect programmatically to an AWS service, you use an endpoint. AWS services offer the following endpoint types in some or all of the AWS Regions that the service supports: IPv4 endpoints, dual-stack endpoints, and FIPS endpoints. Some services provide global endpoints. For more information, see [AWS service endpoints](rande.md).

Service quotas, also referred to as limits, are the maximum number of service resources or operations for your AWS account. For more information, see [AWS service quotas](aws_service_limits.md).

The following are the service endpoints and service quotas for this service.

## Service endpoints
<a name="acm_region"></a>


| Region Name | Region | Endpoint | Protocol | 
| --- | --- | --- | --- | 
| US East (Ohio) | us-east-2 |  acm.us-east-2.amazonaws.com <br /> acm-fips.us-east-2.api.aws <br /> acm.us-east-2.api.aws <br /> acm-fips.us-east-2.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| US East (N. Virginia) | us-east-1 |  acm.us-east-1.amazonaws.com <br /> acm-fips.us-east-1.api.aws <br /> acm-fips.us-east-1.amazonaws.com <br /> acm.us-east-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| US West (N. California) | us-west-1 |  acm.us-west-1.amazonaws.com <br /> acm.us-west-1.api.aws <br /> acm-fips.us-west-1.amazonaws.com <br /> acm-fips.us-west-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| US West (Oregon) | us-west-2 |  acm.us-west-2.amazonaws.com <br /> acm-fips.us-west-2.amazonaws.com <br /> acm.us-west-2.api.aws <br /> acm-fips.us-west-2.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Africa (Cape Town) | af-south-1 |  acm.af-south-1.amazonaws.com <br /> acm.af-south-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Hong Kong) | ap-east-1 |  acm.ap-east-1.amazonaws.com <br /> acm.ap-east-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Hyderabad) | ap-south-2 |  acm.ap-south-2.amazonaws.com <br /> acm.ap-south-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Jakarta) | ap-southeast-3 |  acm.ap-southeast-3.amazonaws.com <br /> acm.ap-southeast-3.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Malaysia) | ap-southeast-5 |  acm.ap-southeast-5.amazonaws.com <br /> acm.ap-southeast-5.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Melbourne) | ap-southeast-4 |  acm.ap-southeast-4.amazonaws.com <br /> acm.ap-southeast-4.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Mumbai) | ap-south-1 |  acm.ap-south-1.amazonaws.com <br /> acm.ap-south-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (New Zealand) | ap-southeast-6 |  acm.ap-southeast-6.amazonaws.com  | HTTPS | 
| Asia Pacific (Osaka) | ap-northeast-3 |  acm.ap-northeast-3.amazonaws.com <br /> acm.ap-northeast-3.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Seoul) | ap-northeast-2 |  acm.ap-northeast-2.amazonaws.com <br /> acm.ap-northeast-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Singapore) | ap-southeast-1 |  acm.ap-southeast-1.amazonaws.com <br /> acm.ap-southeast-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Sydney) | ap-southeast-2 |  acm.ap-southeast-2.amazonaws.com <br /> acm.ap-southeast-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Taipei) | ap-east-2 |  acm.ap-east-2.amazonaws.com  | HTTPS | 
| Asia Pacific (Thailand) | ap-southeast-7 |  acm.ap-southeast-7.amazonaws.com <br /> acm.ap-southeast-7.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Tokyo) | ap-northeast-1 |  acm.ap-northeast-1.amazonaws.com <br /> acm.ap-northeast-1.api.aws  | HTTPS<br />HTTPS | 
| Canada (Central) | ca-central-1 |  acm.ca-central-1.amazonaws.com <br /> acm.ca-central-1.api.aws <br /> acm-fips.ca-central-1.amazonaws.com <br /> acm-fips.ca-central-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Canada West (Calgary) | ca-west-1 |  acm.ca-west-1.amazonaws.com <br /> acm-fips.ca-west-1.api.aws <br /> acm.ca-west-1.api.aws <br /> acm-fips.ca-west-1.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Europe (Frankfurt) | eu-central-1 |  acm.eu-central-1.amazonaws.com <br /> acm.eu-central-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Ireland) | eu-west-1 |  acm.eu-west-1.amazonaws.com <br /> acm.eu-west-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (London) | eu-west-2 |  acm.eu-west-2.amazonaws.com <br /> acm.eu-west-2.api.aws  | HTTPS<br />HTTPS | 
| Europe (Milan) | eu-south-1 |  acm.eu-south-1.amazonaws.com <br /> acm.eu-south-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Paris) | eu-west-3 |  acm.eu-west-3.amazonaws.com <br /> acm.eu-west-3.api.aws  | HTTPS<br />HTTPS | 
| Europe (Spain) | eu-south-2 |  acm.eu-south-2.amazonaws.com <br /> acm.eu-south-2.api.aws  | HTTPS<br />HTTPS | 
| Europe (Stockholm) | eu-north-1 |  acm.eu-north-1.amazonaws.com <br /> acm.eu-north-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Zurich) | eu-central-2 |  acm.eu-central-2.amazonaws.com <br /> acm.eu-central-2.api.aws  | HTTPS<br />HTTPS | 
| Israel (Tel Aviv) | il-central-1 |  acm.il-central-1.amazonaws.com <br /> acm.il-central-1.api.aws  | HTTPS<br />HTTPS | 
| Mexico (Central) | mx-central-1 |  acm.mx-central-1.amazonaws.com <br /> acm.mx-central-1.api.aws  | HTTPS<br />HTTPS | 
| Middle East (Bahrain) | me-south-1 |  acm.me-south-1.amazonaws.com <br /> acm.me-south-1.api.aws  | HTTPS<br />HTTPS | 
| Middle East (UAE) | me-central-1 |  acm.me-central-1.amazonaws.com <br /> acm.me-central-1.api.aws  | HTTPS<br />HTTPS | 
| South America (São Paulo) | sa-east-1 |  acm.sa-east-1.amazonaws.com <br /> acm.sa-east-1.api.aws  | HTTPS<br />HTTPS | 
|  AWS GovCloud (US-East) | us-gov-east-1 |  acm.us-gov-east-1.amazonaws.com <br /> acm.us-gov-east-1.api.aws  | HTTPS<br />HTTPS | 
|  AWS GovCloud (US-West) | us-gov-west-1 |  acm.us-gov-west-1.amazonaws.com <br /> acm.us-gov-west-1.api.aws  | HTTPS<br />HTTPS | 

## Service quotas
<a name="limits_acm"></a>


| Name | Default | Adjustable | Description | 
| --- | --- | --- | --- | 
| ACM certificates | Each supported Region: 2,500 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/acm/quotas/L-F141DD1D)  | The maximum number of ACM Certificates you can have in this account in the current Region. Only certificates in the PENDING or ISSUED state count towards this limit. | 
| ACM certificates created in last 365 days | Each supported Region: 5,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/acm/quotas/L-DA1D8B98)  | The maximum number of ACM Certificates you can request per year. | 
| ACME domain validations per ACME endpoint | Each supported Region: 1,500 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/acm/quotas/L-69D109B1)  | The maximum number of ACME domain validations per ACME endpoint. | 
| ACME endpoints per account | Each supported Region: 50 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/acm/quotas/L-8E212782)  | The maximum number of ACME endpoints you can have in this account in the current Region. | 
| Domain names per ACM certificate | Each supported Region: 10 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/acm/quotas/L-FB94F0B0)  | The maximum number of domain names per ACM Certificate. The first domain name that you submit is included as the subject common name (CN) of the certificate. All names are included in the Subject Alternative Name extension. | 
| External account bindings per ACME endpoint | Each supported Region: 1,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/acm/quotas/L-E9B74925)  | The maximum number of external account bindings (EABs) per ACME endpoint. | 
| Identifiers per ACME order | Each supported Region: 100 | No | The maximum number of domain names (identifiers) per ACME order. | 
| Imported certificates | Each supported Region: 2,500 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/acm/quotas/L-D2CB7DE9)  | The maximum number of imported certificates you can have in this account in the current Region. | 
| Imported certificates in last 365 days | Each supported Region: 5,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/acm/quotas/L-3808DC70)  | The maximum number of certificates you can import per year in this account in the current Region. | 
| Rate of ChangeAccountKey requests (public CA) | Each supported Region: 50 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/acm/quotas/L-67CE8F15)  | The maximum number of ChangeAccountKey requests per second to an ACME endpoint (Public CA). | 
| Rate of CreateAcmeDomainValidation API requests | Each supported Region: 50 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/acm/quotas/L-74BB4A99)  | The maximum number of CreateAcmeDomainValidation API requests per second. | 
| Rate of CreateAcmeEndpoint API requests | Each supported Region: 50 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/acm/quotas/L-A7230D7D)  | The maximum number of CreateAcmeEndpoint API requests per second. | 
| Rate of CreateAcmeExternalAccountBinding API requests | Each supported Region: 50 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/acm/quotas/L-E8DE0414)  | The maximum number of CreateAcmeExternalAccountBinding API requests per second. | 
| Rate of DeleteAcmeDomainValidation API requests | Each supported Region: 50 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/acm/quotas/L-A1BB525F)  | The maximum number of DeleteAcmeDomainValidation API requests per second. | 
| Rate of DeleteAcmeEndpoint API requests | Each supported Region: 50 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/acm/quotas/L-62A479C6)  | The maximum number of DeleteAcmeEndpoint API requests per second. | 
| Rate of DeleteAcmeExternalAccountBinding API requests | Each supported Region: 50 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/acm/quotas/L-A25FF1B0)  | The maximum number of DeleteAcmeExternalAccountBinding API requests per second. | 
| Rate of DescribeAcmeAccount API requests | Each supported Region: 50 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/acm/quotas/L-12943EEB)  | The maximum number of DescribeAcmeAccount API requests per second. | 
| Rate of DescribeAcmeDomainValidation API requests | Each supported Region: 50 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/acm/quotas/L-A7EF109F)  | The maximum number of DescribeAcmeDomainValidation API requests per second. | 
| Rate of DescribeAcmeEndpoint API requests | Each supported Region: 50 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/acm/quotas/L-08DCE28B)  | The maximum number of DescribeAcmeEndpoint API requests per second. | 
| Rate of DescribeAcmeExternalAccountBinding API requests | Each supported Region: 50 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/acm/quotas/L-535A8003)  | The maximum number of DescribeAcmeExternalAccountBinding API requests per second. | 
| Rate of FinalizeOrder requests (Public CA) | Each supported Region: 50 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/acm/quotas/L-8F907C16)  | The maximum number of FinalizeOrder requests per second to an ACME endpoint (Public CA). | 
| Rate of GetAcmeExternalAccountBindingCredentials API requests | Each supported Region: 50 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/acm/quotas/L-2F0B3882)  | The maximum number of GetAcmeExternalAccountBindingCredentials API requests per second. | 
| Rate of GetCertificate requests (Public CA) | Each supported Region: 50 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/acm/quotas/L-C1B13B11)  | The maximum number of GetCertificate requests per second to an ACME endpoint (Public CA). | 
| Rate of GetDirectory requests (Public CA) | Each supported Region: 50 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/acm/quotas/L-25850AC5)  | The maximum number of GetDirectory requests per second to an ACME endpoint (Public CA). | 
| Rate of GetOrder requests (Public CA) | Each supported Region: 50 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/acm/quotas/L-E5BD64C4)  | The maximum number of GetOrder requests per second to an ACME endpoint (Public CA). | 
| Rate of ListAcmeAccounts API requests | Each supported Region: 50 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/acm/quotas/L-84FDD27E)  | The maximum number of ListAcmeAccounts API requests per second. | 
| Rate of ListAcmeDomainValidations API requests | Each supported Region: 50 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/acm/quotas/L-DD60D132)  | The maximum number of ListAcmeDomainValidations API requests per second. | 
| Rate of ListAcmeEndpoints API requests | Each supported Region: 50 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/acm/quotas/L-EF1F514F)  | The maximum number of ListAcmeEndpoints API requests per second. | 
| Rate of ListAcmeExternalAccountBindings API requests | Each supported Region: 50 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/acm/quotas/L-E9F88106)  | The maximum number of ListAcmeExternalAccountBindings API requests per second. | 
| Rate of ListOrders requests (Public CA) | Each supported Region: 50 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/acm/quotas/L-B54E258B)  | The maximum number of ListOrders requests per second to an ACME endpoint (Public CA). | 
| Rate of ManageAccount requests (Public CA) | Each supported Region: 50 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/acm/quotas/L-B8583BD1)  | The maximum number of ManageAccount requests per second to an ACME endpoint (Public CA). | 
| Rate of ManageAuthorization requests (Public CA) | Each supported Region: 50 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/acm/quotas/L-E6DBDBE9)  | The maximum number of ManageAuthorization requests per second to an ACME endpoint (Public CA). | 
| Rate of NewAccount requests (Public CA) | Each supported Region: 50 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/acm/quotas/L-8976373F)  | The maximum number of NewAccount requests per second to an ACME endpoint (Public CA). | 
| Rate of NewNonce requests (Public CA) | Each supported Region: 50 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/acm/quotas/L-24E5E876)  | The maximum number of NewNonce requests per second to an ACME endpoint (Public CA). | 
| Rate of NewOrder requests (Public CA) | Each supported Region: 50 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/acm/quotas/L-201D91CA)  | The maximum number of NewOrder requests per second to an ACME endpoint (Public CA). | 
| Rate of RestoreAcmeEndpoint API requests | Each supported Region: 50 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/acm/quotas/L-CF670426)  | The maximum number of RestoreAcmeEndpoint API requests per second. | 
| Rate of RevokeAcmeAccount API requests | Each supported Region: 50 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/acm/quotas/L-D0E9B342)  | The maximum number of RevokeAcmeAccount API requests per second. | 
| Rate of RevokeAcmeCertificate API requests | Each supported Region: 50 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/acm/quotas/L-183E8F71)  | The maximum number of RevokeAcmeCertificate API requests per second. | 
| Rate of RevokeAcmeExternalAccountBinding API requests | Each supported Region: 50 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/acm/quotas/L-C71B9553)  | The maximum number of RevokeAcmeExternalAccountBinding API requests per second. | 
| Rate of RevokeCertificate requests (Public CA) | Each supported Region: 50 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/acm/quotas/L-4C8B8B5F)  | The maximum number of RevokeCertificate requests per second to an ACME endpoint (Public CA). | 
| Rate of UpdateAcmeDomainValidation API requests | Each supported Region: 50 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/acm/quotas/L-B97889A6)  | The maximum number of UpdateAcmeDomainValidation API requests per second. | 
| Rate of UpdateAcmeEndpoint API requests | Each supported Region: 50 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/acm/quotas/L-8849A1A8)  | The maximum number of UpdateAcmeEndpoint API requests per second. | 

For more information, see [Quotas](https://docs.aws.amazon.com/acm/latest/userguide/acm-limits.html) in the *AWS Certificate Manager User Guide*.