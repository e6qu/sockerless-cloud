

# Amazon Data Firehose endpoints and quotas
<a name="fh"></a>

To connect programmatically to an AWS service, you use an endpoint. AWS services offer the following endpoint types in some or all of the AWS Regions that the service supports: IPv4 endpoints, dual-stack endpoints, and FIPS endpoints. Some services provide global endpoints. For more information, see [AWS service endpoints](rande.md).

Service quotas, also referred to as limits, are the maximum number of service resources or operations for your AWS account. For more information, see [AWS service quotas](aws_service_limits.md).

The following are the service endpoints and service quotas for this service.

## Service endpoints
<a name="fh_region"></a>


| Region Name | Region | Endpoint | Protocol | 
| --- | --- | --- | --- | 
| US East (Ohio) | us-east-2 |  firehose.us-east-2.amazonaws.com <br /> firehose-fips.us-east-2.api.aws <br /> firehose.us-east-2.api.aws <br /> firehose-fips.us-east-2.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| US East (N. Virginia) | us-east-1 |  firehose.us-east-1.amazonaws.com <br /> firehose-fips.us-east-1.amazonaws.com <br /> firehose.us-east-1.api.aws <br /> firehose-fips.us-east-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| US West (N. California) | us-west-1 |  firehose.us-west-1.amazonaws.com <br /> firehose.us-west-1.api.aws <br /> firehose-fips.us-west-1.amazonaws.com <br /> firehose-fips.us-west-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| US West (Oregon) | us-west-2 |  firehose.us-west-2.amazonaws.com <br /> firehose-fips.us-west-2.api.aws <br /> firehose.us-west-2.api.aws <br /> firehose-fips.us-west-2.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Africa (Cape Town) | af-south-1 |  firehose.af-south-1.amazonaws.com <br /> firehose.af-south-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Hong Kong) | ap-east-1 |  firehose.ap-east-1.amazonaws.com <br /> firehose.ap-east-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Hyderabad) | ap-south-2 |  firehose.ap-south-2.amazonaws.com <br /> firehose.ap-south-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Jakarta) | ap-southeast-3 |  firehose.ap-southeast-3.amazonaws.com <br /> firehose.ap-southeast-3.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Malaysia) | ap-southeast-5 |  firehose.ap-southeast-5.amazonaws.com <br /> firehose.ap-southeast-5.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Melbourne) | ap-southeast-4 |  firehose.ap-southeast-4.amazonaws.com <br /> firehose.ap-southeast-4.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Mumbai) | ap-south-1 |  firehose.ap-south-1.amazonaws.com <br /> firehose.ap-south-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (New Zealand) | ap-southeast-6 |  firehose.ap-southeast-6.amazonaws.com <br /> firehose.ap-southeast-6.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Osaka) | ap-northeast-3 |  firehose.ap-northeast-3.amazonaws.com <br /> firehose.ap-northeast-3.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Seoul) | ap-northeast-2 |  firehose.ap-northeast-2.amazonaws.com <br /> firehose.ap-northeast-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Singapore) | ap-southeast-1 |  firehose.ap-southeast-1.amazonaws.com <br /> firehose.ap-southeast-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Sydney) | ap-southeast-2 |  firehose.ap-southeast-2.amazonaws.com <br /> firehose.ap-southeast-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Taipei) | ap-east-2 |  firehose.ap-east-2.amazonaws.com <br /> firehose.ap-east-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Thailand) | ap-southeast-7 |  firehose.ap-southeast-7.amazonaws.com <br /> firehose.ap-southeast-7.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Tokyo) | ap-northeast-1 |  firehose.ap-northeast-1.amazonaws.com <br /> firehose.ap-northeast-1.api.aws  | HTTPS<br />HTTPS | 
| Canada (Central) | ca-central-1 |  firehose.ca-central-1.amazonaws.com <br /> firehose.ca-central-1.api.aws  | HTTPS<br />HTTPS | 
| Canada West (Calgary) | ca-west-1 |  firehose.ca-west-1.amazonaws.com <br /> firehose.ca-west-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Frankfurt) | eu-central-1 |  firehose.eu-central-1.amazonaws.com <br /> firehose.eu-central-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Ireland) | eu-west-1 |  firehose.eu-west-1.amazonaws.com <br /> firehose.eu-west-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (London) | eu-west-2 |  firehose.eu-west-2.amazonaws.com <br /> firehose.eu-west-2.api.aws  | HTTPS<br />HTTPS | 
| Europe (Milan) | eu-south-1 |  firehose.eu-south-1.amazonaws.com <br /> firehose.eu-south-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Paris) | eu-west-3 |  firehose.eu-west-3.amazonaws.com <br /> firehose.eu-west-3.api.aws  | HTTPS<br />HTTPS | 
| Europe (Spain) | eu-south-2 |  firehose.eu-south-2.amazonaws.com <br /> firehose.eu-south-2.api.aws  | HTTPS<br />HTTPS | 
| Europe (Stockholm) | eu-north-1 |  firehose.eu-north-1.amazonaws.com <br /> firehose.eu-north-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Zurich) | eu-central-2 |  firehose.eu-central-2.amazonaws.com <br /> firehose.eu-central-2.api.aws  | HTTPS<br />HTTPS | 
| Israel (Tel Aviv) | il-central-1 |  firehose.il-central-1.amazonaws.com <br /> firehose.il-central-1.api.aws  | HTTPS<br />HTTPS | 
| Mexico (Central) | mx-central-1 |  firehose.mx-central-1.amazonaws.com <br /> firehose.mx-central-1.api.aws  | HTTPS<br />HTTPS | 
| Middle East (Bahrain) | me-south-1 |  firehose.me-south-1.amazonaws.com <br /> firehose.me-south-1.api.aws  | HTTPS<br />HTTPS | 
| Middle East (UAE) | me-central-1 |  firehose.me-central-1.amazonaws.com <br /> firehose.me-central-1.api.aws  | HTTPS<br />HTTPS | 
| South America (São Paulo) | sa-east-1 |  firehose.sa-east-1.amazonaws.com <br /> firehose.sa-east-1.api.aws  | HTTPS<br />HTTPS | 
|  AWS GovCloud (US-East) | us-gov-east-1 |  firehose.us-gov-east-1.amazonaws.com <br /> firehose.us-gov-east-1.api.aws <br /> firehose-fips.us-gov-east-1.api.aws <br /> firehose-fips.us-gov-east-1.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
|  AWS GovCloud (US-West) | us-gov-west-1 |  firehose.us-gov-west-1.amazonaws.com <br /> firehose-fips.us-gov-west-1.api.aws <br /> firehose-fips.us-gov-west-1.amazonaws.com <br /> firehose.us-gov-west-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 

## Service quotas
<a name="limits-akf"></a>


| Name | Default | Adjustable | Description | 
| --- | --- | --- | --- | 
| Delivery streams | us-east-1: 5,000<br />us-east-2: 5,000<br />us-west-1: 2,000<br />us-west-2: 5,000<br />ap-northeast-1: 5,000<br />ap-northeast-2: 2,000<br />ap-northeast-3: 500<br />ap-south-1: 2,000<br />ap-southeast-1: 2,000<br />ap-southeast-2: 2,000<br />ca-central-1: 2,000<br />eu-central-1: 2,000<br />eu-north-1: 500<br />eu-south-1: 500<br />eu-west-1: 5,000<br />eu-west-2: 2,000<br />eu-west-3: 500<br />sa-east-1: 500<br />Each of the other supported Regions: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/firehose/quotas/L-14BB0BE7)  | The maximum number of delivery streams you can create in this account in the current Region. | 
| Dynamic Partitions | Each supported Region: 500 | No | The maximum number of dynamic partitions for a delivery stream in the current Region. | 
| Rate of CreateDeliveryStream requests | Each supported Region: 5 per second | No | The maximum number of CreateDeliveryStream requests you can make per second in this account in the current Region. | 
| Rate of DeleteDeliveryStream requests | Each supported Region: 5 per second | No | The maximum number of DeleteDeliveryStream requests you can make per second in this account in the current Region. | 
| Rate of DescribeDeliveryStream requests | Each supported Region: 5 | No | The maximum number of DescribeDeliveryStream requests you can make per second in this account in the current Region. | 
| Rate of ListDeliveryStream requests | Each supported Region: 5 per second | No | The maximum number of ListDeliveryStream requests you can make per second in this account in the current Region. | 
| Rate of ListTagsForDeliveryStream requests | Each supported Region: 5 per second | No | The maximum number of ListTagsForDeliveryStream requests you can make per second in this account in the current Region. | 
| Rate of Put requests | us-east-1: 2,000<br />us-west-2: 2,000<br />eu-west-1: 2,000<br />Each of the other supported Regions: 1,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/firehose/quotas/L-7681C790)  | The maximum number of combined PutRecord and PutRecordBatch requests per second for a delivery stream in the current Region. | 
| Rate of StartDeliveryStreamEncryption requests | Each supported Region: 5 per second | No | The maximum number of StartDeliveryStreamEncryption requests you can make per second in this account in the current Region. | 
| Rate of StopDeliveryStreamEncryption requests | Each supported Region: 5 per second | No | The maximum number of StopDeliveryStreamEncryption requests you can make per second in this account in the current Region. | 
| Rate of TagDeliveryStream requests | Each supported Region: 5 per second | No | The maximum number of TagDeliveryStream requests you can make per second in this account in the current Region. | 
| Rate of UntagDeliveryStream requests | Each supported Region: 5 per second | No | The maximum number of UntagDeliveryStream requests you can make per second in this account in the current Region. | 
| Rate of UpdateDestination requests | Each supported Region: 5 per second | No | The maximum number of UpdateDestination requests you can make per second in this account in the current Region. | 
| Rate of data | us-east-1: 5<br />us-west-2: 5<br />eu-west-1: 5<br />Each of the other supported Regions: 1 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/firehose/quotas/L-937C879B)  | The maximum capacity in mebibyte per second for a delivery stream in the current Region. | 
| Rate of records | us-east-1: 500,000<br />us-west-2: 500,000<br />eu-west-1: 500,000<br />Each of the other supported Regions: 100,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/firehose/quotas/L-17D4EADE)  | The maximum capacity in records per second for a delivery stream in the current Region. | 

For more information, see [Amazon Data Firehose Quotas](https://docs.aws.amazon.com/firehose/latest/dev/limits.html) in the *Amazon Data Firehose Developer Guide*.