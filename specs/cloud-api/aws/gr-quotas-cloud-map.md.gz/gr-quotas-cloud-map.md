

# AWS Cloud Map endpoints and quotas
<a name="cloud_map"></a>

To connect programmatically to an AWS service, you use an endpoint. AWS services offer the following endpoint types in some or all of the AWS Regions that the service supports: IPv4 endpoints, dual-stack endpoints, and FIPS endpoints. Some services provide global endpoints. For more information, see [AWS service endpoints](rande.md).

Service quotas, also referred to as limits, are the maximum number of service resources or operations for your AWS account. For more information, see [AWS service quotas](aws_service_limits.md).

The following are the service endpoints and service quotas for this service.

## Service endpoints
<a name="cloud_map_region"></a>


| Region Name | Region | Endpoint | Protocol | 
| --- | --- | --- | --- | 
| US East (Ohio) | us-east-2 |  servicediscovery.us-east-2.amazonaws.com <br /> servicediscovery.us-east-2.api.aws <br /> servicediscovery-fips.us-east-2.api.aws <br /> servicediscovery-fips.us-east-2.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| US East (N. Virginia) | us-east-1 |  servicediscovery.us-east-1.amazonaws.com <br /> servicediscovery-fips.us-east-1.amazonaws.com <br /> servicediscovery.us-east-1.api.aws <br /> servicediscovery-fips.us-east-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| US West (N. California) | us-west-1 |  servicediscovery.us-west-1.amazonaws.com <br /> servicediscovery.us-west-1.api.aws <br /> servicediscovery-fips.us-west-1.api.aws <br /> servicediscovery-fips.us-west-1.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| US West (Oregon) | us-west-2 |  servicediscovery.us-west-2.amazonaws.com <br /> servicediscovery-fips.us-west-2.amazonaws.com <br /> servicediscovery.us-west-2.api.aws <br /> servicediscovery-fips.us-west-2.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Africa (Cape Town) | af-south-1 |  servicediscovery.af-south-1.amazonaws.com <br /> servicediscovery.af-south-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Hong Kong) | ap-east-1 |  servicediscovery.ap-east-1.amazonaws.com <br /> servicediscovery.ap-east-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Hyderabad) | ap-south-2 |  servicediscovery.ap-south-2.amazonaws.com <br /> servicediscovery.ap-south-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Jakarta) | ap-southeast-3 |  servicediscovery.ap-southeast-3.amazonaws.com <br /> servicediscovery.ap-southeast-3.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Malaysia) | ap-southeast-5 |  servicediscovery.ap-southeast-5.amazonaws.com <br /> servicediscovery.ap-southeast-5.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Melbourne) | ap-southeast-4 |  servicediscovery.ap-southeast-4.amazonaws.com <br /> servicediscovery.ap-southeast-4.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Mumbai) | ap-south-1 |  servicediscovery.ap-south-1.amazonaws.com <br /> servicediscovery.ap-south-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (New Zealand) | ap-southeast-6 |  servicediscovery.ap-southeast-6.amazonaws.com <br /> servicediscovery.ap-southeast-6.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Osaka) | ap-northeast-3 |  servicediscovery.ap-northeast-3.amazonaws.com <br /> servicediscovery.ap-northeast-3.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Seoul) | ap-northeast-2 |  servicediscovery.ap-northeast-2.amazonaws.com <br /> servicediscovery.ap-northeast-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Singapore) | ap-southeast-1 |  servicediscovery.ap-southeast-1.amazonaws.com <br /> servicediscovery.ap-southeast-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Sydney) | ap-southeast-2 |  servicediscovery.ap-southeast-2.amazonaws.com <br /> servicediscovery.ap-southeast-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Taipei) | ap-east-2 |  servicediscovery.ap-east-2.amazonaws.com <br /> servicediscovery.ap-east-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Thailand) | ap-southeast-7 |  servicediscovery.ap-southeast-7.amazonaws.com <br /> servicediscovery.ap-southeast-7.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Tokyo) | ap-northeast-1 |  servicediscovery.ap-northeast-1.amazonaws.com <br /> servicediscovery.ap-northeast-1.api.aws  | HTTPS<br />HTTPS | 
| Canada (Central) | ca-central-1 |  servicediscovery.ca-central-1.amazonaws.com <br /> servicediscovery.ca-central-1.api.aws <br /> servicediscovery-fips.ca-central-1.amazonaws.com <br /> servicediscovery-fips.ca-central-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Canada West (Calgary) | ca-west-1 |  servicediscovery.ca-west-1.amazonaws.com <br /> servicediscovery-fips.ca-west-1.amazonaws.com <br /> servicediscovery.ca-west-1.api.aws <br /> servicediscovery-fips.ca-west-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Europe (Frankfurt) | eu-central-1 |  servicediscovery.eu-central-1.amazonaws.com <br /> servicediscovery.eu-central-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Ireland) | eu-west-1 |  servicediscovery.eu-west-1.amazonaws.com <br /> servicediscovery.eu-west-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (London) | eu-west-2 |  servicediscovery.eu-west-2.amazonaws.com <br /> servicediscovery.eu-west-2.api.aws  | HTTPS<br />HTTPS | 
| Europe (Milan) | eu-south-1 |  servicediscovery.eu-south-1.amazonaws.com <br /> servicediscovery.eu-south-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Paris) | eu-west-3 |  servicediscovery.eu-west-3.amazonaws.com <br /> servicediscovery.eu-west-3.api.aws  | HTTPS<br />HTTPS | 
| Europe (Spain) | eu-south-2 |  servicediscovery.eu-south-2.amazonaws.com <br /> servicediscovery.eu-south-2.api.aws  | HTTPS<br />HTTPS | 
| Europe (Stockholm) | eu-north-1 |  servicediscovery.eu-north-1.amazonaws.com <br /> servicediscovery.eu-north-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Zurich) | eu-central-2 |  servicediscovery.eu-central-2.amazonaws.com <br /> servicediscovery.eu-central-2.api.aws  | HTTPS<br />HTTPS | 
| Israel (Tel Aviv) | il-central-1 |  servicediscovery.il-central-1.amazonaws.com <br /> servicediscovery.il-central-1.api.aws  | HTTPS<br />HTTPS | 
| Mexico (Central) | mx-central-1 |  servicediscovery.mx-central-1.amazonaws.com <br /> servicediscovery.mx-central-1.api.aws  | HTTPS<br />HTTPS | 
| Middle East (Bahrain) | me-south-1 |  servicediscovery.me-south-1.amazonaws.com <br /> servicediscovery.me-south-1.api.aws  | HTTPS<br />HTTPS | 
| Middle East (UAE) | me-central-1 |  servicediscovery.me-central-1.amazonaws.com <br /> servicediscovery.me-central-1.api.aws  | HTTPS<br />HTTPS | 
| South America (São Paulo) | sa-east-1 |  servicediscovery.sa-east-1.amazonaws.com <br /> servicediscovery.sa-east-1.api.aws  | HTTPS<br />HTTPS | 
|  AWS GovCloud (US-East) | us-gov-east-1 |  servicediscovery.us-gov-east-1.amazonaws.com <br /> servicediscovery-fips.us-gov-east-1.amazonaws.com <br /> servicediscovery.us-gov-east-1.api.aws <br /> servicediscovery-fips.us-gov-east-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
|  AWS GovCloud (US-West) | us-gov-west-1 |  servicediscovery.us-gov-west-1.amazonaws.com <br /> servicediscovery-fips.us-gov-west-1.api.aws <br /> servicediscovery-fips.us-gov-west-1.amazonaws.com <br /> servicediscovery.us-gov-west-1.api.aws  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 

## Service quotas
<a name="limits_cloud_map"></a>


| Name | Default | Adjustable | Description | 
| --- | --- | --- | --- | 
| Custom attributes per instance | Each supported Region: 30 | No | The maximum number of custom attributes that you can specify when you register an instance. | 
| DiscoverInstances operation per account burst rate | Each supported Region: 2,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/AWSCloudMap/quotas/L-76CF203B)  | The maximum burst rate to call DiscoverInstances operation from a single account. | 
| DiscoverInstances operation per account steady rate | Each supported Region: 1,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/AWSCloudMap/quotas/L-514A639A)  | The maximum steady rate to call DiscoverInstances operation from a single account. | 
| DiscoverInstancesRevision operation per account rate | Each supported Region: 3,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/AWSCloudMap/quotas/L-0BA10AAE)  | The maximum rate to call DiscoverInstancesRevision operation from a single account. | 
| Instances per namespace | Each supported Region: 2,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/AWSCloudMap/quotas/L-D95E8A57)  | The maximum number of service instances that you can register using the same namespace. | 
| Instances per service | Each supported Region: 1,000 | No | The maximum number of instances that you can register in a Region using the same service. | 
| Namespaces per Region | Each supported Region: 50 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/AWSCloudMap/quotas/L-0FE3F50E)  | The maximum number of namespaces that you can create per Region. | 

For more information, see [AWS Cloud Map Quotas](https://docs.aws.amazon.com/cloud-map/latest/dg/cloud-map-limits.html) and [AWS Cloud Map DiscoverInstances API request throttling](https://docs.aws.amazon.com/cloud-map/latest/dg/cloud-map-limits.html#throttling) in the *AWS Cloud Map Developer Guide*.