

# Amazon Cognito endpoints and quotas
<a name="cognito"></a>

To connect programmatically to an AWS service, you use an endpoint. AWS services offer the following endpoint types in some or all of the AWS Regions that the service supports: IPv4 endpoints, dual-stack endpoints, and FIPS endpoints. Some services provide global endpoints. For more information, see [AWS service endpoints](rande.md).

Service quotas, also referred to as limits, are the maximum number of service resources or operations for your AWS account. For more information, see [AWS service quotas](aws_service_limits.md).

The following are the service endpoints and service quotas for this service.

## Service endpoints
<a name="cognito-region"></a>

### Amazon Cognito user pools
<a name="cognito-idp-region"></a>


| Region Name | Region | Endpoint | Protocol | 
| --- | --- | --- | --- | 
| US East (Ohio) | us-east-2 |  cognito-idp.us-east-2.amazonaws.com <br /> cognito-idp-fips.us-east-2.amazonaws.com  | HTTPS<br />HTTPS | 
| US East (N. Virginia) | us-east-1 |  cognito-idp.us-east-1.amazonaws.com <br /> cognito-idp-fips.us-east-1.amazonaws.com  | HTTPS<br />HTTPS | 
| US West (N. California) | us-west-1 |  cognito-idp.us-west-1.amazonaws.com <br /> cognito-idp-fips.us-west-1.amazonaws.com  | HTTPS<br />HTTPS | 
| US West (Oregon) | us-west-2 |  cognito-idp.us-west-2.amazonaws.com <br /> cognito-idp-fips.us-west-2.amazonaws.com  | HTTPS<br />HTTPS | 
| Africa (Cape Town) | af-south-1 |  cognito-idp.af-south-1.amazonaws.com  | HTTPS | 
| Asia Pacific (Hong Kong) | ap-east-1 |  cognito-idp.ap-east-1.amazonaws.com  | HTTPS | 
| Asia Pacific (Hyderabad) | ap-south-2 |  cognito-idp.ap-south-2.amazonaws.com  | HTTPS | 
| Asia Pacific (Jakarta) | ap-southeast-3 |  cognito-idp.ap-southeast-3.amazonaws.com  | HTTPS | 
| Asia Pacific (Malaysia) | ap-southeast-5 |  cognito-idp.ap-southeast-5.amazonaws.com  | HTTPS | 
| Asia Pacific (Melbourne) | ap-southeast-4 |  cognito-idp.ap-southeast-4.amazonaws.com  | HTTPS | 
| Asia Pacific (Mumbai) | ap-south-1 |  cognito-idp.ap-south-1.amazonaws.com  | HTTPS | 
| Asia Pacific (New Zealand) | ap-southeast-6 |  cognito-idp.ap-southeast-6.amazonaws.com  | HTTPS | 
| Asia Pacific (Osaka) | ap-northeast-3 |  cognito-idp.ap-northeast-3.amazonaws.com  | HTTPS | 
| Asia Pacific (Seoul) | ap-northeast-2 |  cognito-idp.ap-northeast-2.amazonaws.com  | HTTPS | 
| Asia Pacific (Singapore) | ap-southeast-1 |  cognito-idp.ap-southeast-1.amazonaws.com  | HTTPS | 
| Asia Pacific (Sydney) | ap-southeast-2 |  cognito-idp.ap-southeast-2.amazonaws.com  | HTTPS | 
| Asia Pacific (Taipei) | ap-east-2 |  cognito-idp.ap-east-2.amazonaws.com  | HTTPS | 
| Asia Pacific (Thailand) | ap-southeast-7 |  cognito-idp.ap-southeast-7.amazonaws.com  | HTTPS | 
| Asia Pacific (Tokyo) | ap-northeast-1 |  cognito-idp.ap-northeast-1.amazonaws.com  | HTTPS | 
| Canada (Central) | ca-central-1 |  cognito-idp.ca-central-1.amazonaws.com  | HTTPS | 
| Canada West (Calgary) | ca-west-1 |  cognito-idp.ca-west-1.amazonaws.com  | HTTPS | 
| Europe (Frankfurt) | eu-central-1 |  cognito-idp.eu-central-1.amazonaws.com  | HTTPS | 
| Europe (Ireland) | eu-west-1 |  cognito-idp.eu-west-1.amazonaws.com  | HTTPS | 
| Europe (London) | eu-west-2 |  cognito-idp.eu-west-2.amazonaws.com  | HTTPS | 
| Europe (Milan) | eu-south-1 |  cognito-idp.eu-south-1.amazonaws.com  | HTTPS | 
| Europe (Paris) | eu-west-3 |  cognito-idp.eu-west-3.amazonaws.com  | HTTPS | 
| Europe (Spain) | eu-south-2 |  cognito-idp.eu-south-2.amazonaws.com  | HTTPS | 
| Europe (Stockholm) | eu-north-1 |  cognito-idp.eu-north-1.amazonaws.com  | HTTPS | 
| Europe (Zurich) | eu-central-2 |  cognito-idp.eu-central-2.amazonaws.com  | HTTPS | 
| Israel (Tel Aviv) | il-central-1 |  cognito-idp.il-central-1.amazonaws.com  | HTTPS | 
| Mexico (Central) | mx-central-1 |  cognito-idp.mx-central-1.amazonaws.com  | HTTPS | 
| Middle East (Bahrain) | me-south-1 |  cognito-idp.me-south-1.amazonaws.com  | HTTPS | 
| Middle East (UAE) | me-central-1 |  cognito-idp.me-central-1.amazonaws.com  | HTTPS | 
| South America (São Paulo) | sa-east-1 |  cognito-idp.sa-east-1.amazonaws.com  | HTTPS | 
|  AWS GovCloud (US-East) | us-gov-east-1 |  cognito-idp.us-gov-east-1.amazonaws.com <br /> cognito-idp-fips.us-gov-east-1.amazonaws.com  | HTTPS<br />HTTPS | 
|  AWS GovCloud (US-West) | us-gov-west-1 |  cognito-idp.us-gov-west-1.amazonaws.com <br /> cognito-idp-fips.us-gov-west-1.amazonaws.com  | HTTPS<br />HTTPS | 

### Amazon Cognito identity pools
<a name="cognito-identity-region"></a>


| Region Name | Region | Endpoint | Protocol | 
| --- | --- | --- | --- | 
| US East (Ohio) | us-east-2 |  cognito-identity.us-east-2.amazonaws.com <br /> cognito-identity-fips.us-east-2.amazonaws.com  | HTTPS<br />HTTPS | 
| US East (N. Virginia) | us-east-1 |  cognito-identity.us-east-1.amazonaws.com <br /> cognito-identity-fips.us-east-1.amazonaws.com  | HTTPS<br />HTTPS | 
| US West (N. California) | us-west-1 |  cognito-identity.us-west-1.amazonaws.com <br /> cognito-identity-fips.us-west-1.amazonaws.com  | HTTPS<br />HTTPS | 
| US West (Oregon) | us-west-2 |  cognito-identity.us-west-2.amazonaws.com <br /> cognito-identity-fips.us-west-2.amazonaws.com  | HTTPS<br />HTTPS | 
| Africa (Cape Town) | af-south-1 |  cognito-identity.af-south-1.amazonaws.com  | HTTPS | 
| Asia Pacific (Hong Kong) | ap-east-1 |  cognito-identity.ap-east-1.amazonaws.com  | HTTPS | 
| Asia Pacific (Hyderabad) | ap-south-2 |  cognito-identity.ap-south-2.amazonaws.com  | HTTPS | 
| Asia Pacific (Jakarta) | ap-southeast-3 |  cognito-identity.ap-southeast-3.amazonaws.com  | HTTPS | 
| Asia Pacific (Malaysia) | ap-southeast-5 |  cognito-identity.ap-southeast-5.amazonaws.com  | HTTPS | 
| Asia Pacific (Melbourne) | ap-southeast-4 |  cognito-identity.ap-southeast-4.amazonaws.com  | HTTPS | 
| Asia Pacific (Mumbai) | ap-south-1 |  cognito-identity.ap-south-1.amazonaws.com  | HTTPS | 
| Asia Pacific (New Zealand) | ap-southeast-6 |  cognito-identity.ap-southeast-6.amazonaws.com  | HTTPS | 
| Asia Pacific (Osaka) | ap-northeast-3 |  cognito-identity.ap-northeast-3.amazonaws.com  | HTTPS | 
| Asia Pacific (Seoul) | ap-northeast-2 |  cognito-identity.ap-northeast-2.amazonaws.com  | HTTPS | 
| Asia Pacific (Singapore) | ap-southeast-1 |  cognito-identity.ap-southeast-1.amazonaws.com  | HTTPS | 
| Asia Pacific (Sydney) | ap-southeast-2 |  cognito-identity.ap-southeast-2.amazonaws.com  | HTTPS | 
| Asia Pacific (Taipei) | ap-east-2 |  cognito-identity.ap-east-2.amazonaws.com  | HTTPS | 
| Asia Pacific (Thailand) | ap-southeast-7 |  cognito-identity.ap-southeast-7.amazonaws.com  | HTTPS | 
| Asia Pacific (Tokyo) | ap-northeast-1 |  cognito-identity.ap-northeast-1.amazonaws.com  | HTTPS | 
| Canada (Central) | ca-central-1 |  cognito-identity.ca-central-1.amazonaws.com  | HTTPS | 
| Canada West (Calgary) | ca-west-1 |  cognito-identity.ca-west-1.amazonaws.com  | HTTPS | 
| Europe (Frankfurt) | eu-central-1 |  cognito-identity.eu-central-1.amazonaws.com  | HTTPS | 
| Europe (Ireland) | eu-west-1 |  cognito-identity.eu-west-1.amazonaws.com  | HTTPS | 
| Europe (London) | eu-west-2 |  cognito-identity.eu-west-2.amazonaws.com  | HTTPS | 
| Europe (Milan) | eu-south-1 |  cognito-identity.eu-south-1.amazonaws.com  | HTTPS | 
| Europe (Paris) | eu-west-3 |  cognito-identity.eu-west-3.amazonaws.com  | HTTPS | 
| Europe (Spain) | eu-south-2 |  cognito-identity.eu-south-2.amazonaws.com  | HTTPS | 
| Europe (Stockholm) | eu-north-1 |  cognito-identity.eu-north-1.amazonaws.com  | HTTPS | 
| Europe (Zurich) | eu-central-2 |  cognito-identity.eu-central-2.amazonaws.com  | HTTPS | 
| Israel (Tel Aviv) | il-central-1 |  cognito-identity.il-central-1.amazonaws.com  | HTTPS | 
| Mexico (Central) | mx-central-1 |  cognito-identity.mx-central-1.amazonaws.com  | HTTPS | 
| Middle East (Bahrain) | me-south-1 |  cognito-identity.me-south-1.amazonaws.com  | HTTPS | 
| Middle East (UAE) | me-central-1 |  cognito-identity.me-central-1.amazonaws.com  | HTTPS | 
| South America (São Paulo) | sa-east-1 |  cognito-identity.sa-east-1.amazonaws.com  | HTTPS | 
|  AWS GovCloud (US-East) | us-gov-east-1 |  cognito-identity.us-gov-east-1.amazonaws.com <br /> cognito-identity-fips.us-gov-east-1.amazonaws.com  | HTTPS<br />HTTPS | 
|  AWS GovCloud (US-West) | us-gov-west-1 |  cognito-identity.us-gov-west-1.amazonaws.com <br /> cognito-identity-fips.us-gov-west-1.amazonaws.com  | HTTPS<br />HTTPS | 

### Amazon Cognito Sync
<a name="cognito-sync-region"></a>


| Region Name | Region | Endpoint | Protocol | 
| --- | --- | --- | --- | 
| US East (Ohio) | us-east-2 |  cognito-sync.us-east-2.amazonaws.com  | HTTPS | 
| US East (N. Virginia) | us-east-1 |  cognito-sync.us-east-1.amazonaws.com  | HTTPS | 
| US West (Oregon) | us-west-2 |  cognito-sync.us-west-2.amazonaws.com  | HTTPS | 
| Asia Pacific (Mumbai) | ap-south-1 |  cognito-sync.ap-south-1.amazonaws.com  | HTTPS | 
| Asia Pacific (Seoul) | ap-northeast-2 |  cognito-sync.ap-northeast-2.amazonaws.com  | HTTPS | 
| Asia Pacific (Singapore) | ap-southeast-1 |  cognito-sync.ap-southeast-1.amazonaws.com  | HTTPS | 
| Asia Pacific (Sydney) | ap-southeast-2 |  cognito-sync.ap-southeast-2.amazonaws.com  | HTTPS | 
| Asia Pacific (Tokyo) | ap-northeast-1 |  cognito-sync.ap-northeast-1.amazonaws.com  | HTTPS | 
| Europe (Frankfurt) | eu-central-1 |  cognito-sync.eu-central-1.amazonaws.com  | HTTPS | 
| Europe (Ireland) | eu-west-1 |  cognito-sync.eu-west-1.amazonaws.com  | HTTPS | 
| Europe (London) | eu-west-2 |  cognito-sync.eu-west-2.amazonaws.com  | HTTPS | 

## Service quotas
<a name="cognito-quotas"></a>

### Amazon Cognito user pools
<a name="cognito-idp-quotas"></a>


| Name | Default | Adjustable | Description | 
| --- | --- | --- | --- | 
| Apps per user pool | Each supported Region: 1,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cognito-idp/quotas/L-5EAB0605)  | The maximum number of app clients per user pool. | 
| Custom domains per account | Each supported Region: 4 | No | The maximum number of custom domains that you can create in this account. | 
| Groups per user | Each supported Region: 100 | No | The maximum number of groups per user that any individual user can be added to. | 
| Groups per user pool | Each supported Region: 10,000 | No | The maximum number of groups per user pool. A group is a collection of users in a user pool. | 
| Identity providers per user pool | Each supported Region: 300 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cognito-idp/quotas/L-1B44D826)  | The maximum number of identity providers per user pool. | 
| Rate of ClientAuthentication requests per account | Each supported Region: 150 per second | No | The maximum combined call rate (requests per second) for all API operations in the ClientAuthentication category. All operations within a category share the same quota. For the list of included operations, see https://docs.aws.amazon.com/cognito/latest/developerguide/limits.html\#category\_operations. | 
| Rate of LimitManagement requests | Each supported Region: 1 per second | No | The maximum combined call rate (requests per second) for all API operations in the LimitManagement category. All operations within a category share the same quota. For the list of included operations, see https://docs.aws.amazon.com/cognito/latest/developerguide/limits.html\#category\_operations. | 
| Rate of UserAccountRecovery requests | Each supported Region: 30 per second | No | The maximum combined call rate (requests per second) for all API operations in the UserAccountRecovery category. All operations within a category share the same quota. For the list of included operations, see https://docs.aws.amazon.com/cognito/latest/developerguide/limits.html\#category\_operations. | 
| Rate of UserAuthentication requests | Each supported Region: 120 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cognito-idp/quotas/L-026ADBA3)  | The maximum combined call rate (requests per second) you can request for all API operations in the UserAuthentication category. Provision your rate limit within this quota from the Amazon Cognito console or APIs. For the list of included operations, see https://docs.aws.amazon.com/cognito/latest/developerguide/limits.html\#category\_operations. | 
| Rate of UserCreation requests | Each supported Region: 50 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cognito-idp/quotas/L-5987B8A0)  | The maximum combined call rate (requests per second) you can request for all API operations in the UserCreation category. Provision your rate limit within this quota from the Amazon Cognito console or APIs. For the list of included operations, see https://docs.aws.amazon.com/cognito/latest/developerguide/limits.html\#category\_operations. | 
| Rate of UserFederation requests | Each supported Region: 25 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cognito-idp/quotas/L-BB3E7CCF)  | The maximum combined call rate (requests per second) you can request for all API operations in the UserFederation category. Provision your rate limit within this quota from the Amazon Cognito console or APIs. For the list of included operations, see https://docs.aws.amazon.com/cognito/latest/developerguide/limits.html\#category\_operations. | 
| Rate of UserList requests | Each supported Region: 30 per second | No | The maximum combined call rate (requests per second) for all API operations in the UserList category. All operations within a category share the same quota. For the list of included operations, see https://docs.aws.amazon.com/cognito/latest/developerguide/limits.html\#category\_operations. | 
| Rate of UserPoolClientRead requests per account | Each supported Region: 15 per second | No | The maximum combined call rate (requests per second) for all API operations in the UserPoolClientRead category. All operations within a category share the same quota. For the list of included operations, see https://docs.aws.amazon.com/cognito/latest/developerguide/limits.html\#category\_operations. | 
| Rate of UserPoolClientRead requests per user pool | Each supported Region: 5 per second | No | The maximum call rate (requests per second) for an operation in the UserPoolClientRead category per user pool. Any operation within this category could be called at this rate per user pool. You can find the list of included operations at https://docs.aws.amazon.com/cognito/latest/developerguide/limits.html\#category\_operations. | 
| Rate of UserPoolClientUpdate requests per account | Each supported Region: 15 per second | No | The maximum combined call rate (requests per second) for all API operations in the UserPoolClientUpdate category. All operations within a category share the same quota. For the list of included operations, see https://docs.aws.amazon.com/cognito/latest/developerguide/limits.html\#category\_operations. | 
| Rate of UserPoolClientUpdate requests per user pool | Each supported Region: 5 per second | No | The maximum call rate (requests per second) for an operation in the UserPoolClientUpdate category per user pool. Any operation within this category could be called at this rate per user pool. You can find the list of included operations at https://docs.aws.amazon.com/cognito/latest/developerguide/limits.html\#category\_operations. | 
| Rate of UserPoolRead requests | Each supported Region: 15 per second | No | The maximum combined call rate (requests per second) for all API operations in the UserPoolRead category. All operations within a category share the same quota. For the list of included operations, see https://docs.aws.amazon.com/cognito/latest/developerguide/limits.html\#category\_operations. | 
| Rate of UserPoolResourceRead requests per account | Each supported Region: 20 per second | No | The maximum combined call rate (requests per second) for all API operations in the UserPoolResourceRead category. All operations within a category share the same quota. For the list of included operations, see https://docs.aws.amazon.com/cognito/latest/developerguide/limits.html\#category\_operations. | 
| Rate of UserPoolResourceRead requests per user pool | Each supported Region: 5 per second | No | The maximum call rate (requests per second) for an operation in the UserPoolResourceRead category per user pool. Any operation within this category could be called at this rate per user pool. You can find the list of included operations at https://docs.aws.amazon.com/cognito/latest/developerguide/limits.html\#category\_operations. | 
| Rate of UserPoolResourceUpdate requests per account | Each supported Region: 15 per second | No | The maximum combined call rate (requests per second) for all API operations in the UserPoolResourceUpdate category. All operations within a category share the same quota. For the list of included operations, see https://docs.aws.amazon.com/cognito/latest/developerguide/limits.html\#category\_operations. | 
| Rate of UserPoolResourceUpdate requests per user pool | Each supported Region: 5 per second | No | The maximum call rate (requests per second) for an operation in the UserPoolResourceUpdate category per user pool. Any operation within this category could be called at this rate per user pool. You can find the list of included operations at https://docs.aws.amazon.com/cognito/latest/developerguide/limits.html\#category\_operations. | 
| Rate of UserPoolUpdate requests | Each supported Region: 15 per second | No | The maximum combined call rate (requests per second) for all API operations in the UserPoolUpdate category. All operations within a category share the same quota. For the list of included operations, see https://docs.aws.amazon.com/cognito/latest/developerguide/limits.html\#category\_operations. | 
| Rate of UserRead requests | Each supported Region: 120 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cognito-idp/quotas/L-D6BD5178)  | The maximum combined call rate (requests per second) you can request for all API operations in the UserRead category. Provision your rate limit within this quota from the Amazon Cognito console or APIs. For the list of included operations, see https://docs.aws.amazon.com/cognito/latest/developerguide/limits.html\#category\_operations. | 
| Rate of UserResourceRead requests | Each supported Region: 50 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cognito-idp/quotas/L-55545DC8)  | The maximum combined call rate (requests per second) you can request for all API operations in the UserResourceRead category. Provision your rate limit within this quota from the Amazon Cognito console or APIs. For the list of included operations, see https://docs.aws.amazon.com/cognito/latest/developerguide/limits.html\#category\_operations. | 
| Rate of UserResourceUpdate requests | Each supported Region: 25 per second | No | The maximum combined call rate (requests per second) for all API operations in the UserResourceUpdate category. All operations within a category share the same quota. For the list of included operations, see https://docs.aws.amazon.com/cognito/latest/developerguide/limits.html\#category\_operations. | 
| Rate of UserToken requests | Each supported Region: 120 per second |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cognito-idp/quotas/L-F21F8BB4)  | The maximum combined call rate (requests per second) you can request for all API operations in the UserToken category. Provision your rate limit within this quota from the Amazon Cognito console or APIs. For the list of included operations, see https://docs.aws.amazon.com/cognito/latest/developerguide/limits.html\#category\_operations. | 
| Rate of UserUpdate requests | Each supported Region: 25 per second | No | The maximum combined call rate (requests per second) for all API operations in the UserUpdate category. All operations within a category share the same quota. For the list of included operations, see https://docs.aws.amazon.com/cognito/latest/developerguide/limits.html\#category\_operations. | 
| Resource servers per user pool | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cognito-idp/quotas/L-7CDAF993)  | The maximum number of resource servers per user pool. A resource server is a server for access-protected resources. | 
| Scopes per resource server | Each supported Region: 100 | No | The maximum number of scopes per resource server. A scope is a level of access (such as read or write access) that an app can request to a resource. | 
| User import jobs per user pool | Each supported Region: 1,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cognito-idp/quotas/L-681BB884)  | The maximum number of user import jobs per user pool. | 
| User pools per account | Each supported Region: 1,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cognito-idp/quotas/L-66E6DF30)  | The maximum number of user pools that you can create in this account per region. | 

For more information, see [Quotas in Amazon Cognito](https://docs.aws.amazon.com/cognito/latest/developerguide/limits.html) in the *Amazon Cognito Developer Guide*.

### Amazon Cognito identity pools
<a name="cognito-identity-quotas"></a>


| Name | Default | Adjustable | Description | 
| --- | --- | --- | --- | 
| Identity pool name size | Each supported Region: 128 Bytes | No | The maximum size of an identity pool name in bytes. | 
| Identity pools per account | Each supported Region: 1,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cognito-identity/quotas/L-8692CE1C)  | The maximum number of identity pools per account. | 
| List API call results | Each supported Region: 60 | No | The maximum number of results from a list or lookup API call. | 
| Login provider name size | Each supported Region: 2,048 Bytes | No | The maximum size of a login provider name in bytes. | 
| Rate of GetCredentialsForIdentity requests | Each supported Region: 200 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cognito-identity/quotas/L-5AE9F13D)  | The maximum number of GetCredentialsForIdentity requests that you can make per second. | 
| Rate of GetId requests | Each supported Region: 25 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cognito-identity/quotas/L-A38ADA84)  | The maximum number of GetId requests that you can make per second. | 
| Rate of GetOpenIdToken requests | Each supported Region: 200 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cognito-identity/quotas/L-E97D135E)  | The maximum number of GetOpenIdToken requests that you can make per second. | 
| Rate of GetOpenIdTokenForDeveloperIdentity requests | Each supported Region: 50 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cognito-identity/quotas/L-0BF99E8D)  | The maximum number of GetOpenIdTokenForDeveloperIdentity requests that you can make per second. | 
| Rate of ListIdentities requests | Each supported Region: 5 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cognito-identity/quotas/L-DBF99350)  | The maximum number of ListIdentities requests that you can make per second. | 
| Rate of ListTagsForResource requests | Each supported Region: 10 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cognito-identity/quotas/L-50C9AAB8)  | The maximum number of ListTagsForResource requests that you can make per second. | 
| Rate of TagResource requests | Each supported Region: 5 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cognito-identity/quotas/L-DAF3EAFF)  | The maximum number of TagResource requests that you can make per second. | 
| Rate of UntagResource requests | Each supported Region: 5 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cognito-identity/quotas/L-0D31D6D2)  | The maximum number of UntagResource requests that you can make per second. | 
| Role-based access control rules | Each supported Region: 25 | No | The maximum number of rules for role-based access control (RBAC) | 
| User pool providers per identity pool | Each supported Region: 50 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cognito-identity/quotas/L-14403AD5)  | The maximum number of Amazon Cognito user pool providers per identity pool. | 

For more information, see [Quotas in Amazon Cognito](https://docs.aws.amazon.com/cognito/latest/developerguide/limits.html) in the *Amazon Cognito Developer Guide*.

### Amazon Cognito Sync
<a name="cognito-sync-quotas"></a>


| Name | Default | Adjustable | Description | 
| --- | --- | --- | --- | 
| Bulk publish wait time | Each supported Region: 24 | No | The maximum wait time for a bulk publish after a successful request in hours. | 
| Dataset name size | Each supported Region: 128 Bytes | No | The maximum size of a dataset name in bytes. | 
| Dataset size | Each supported Region: 1 Megabytes |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cognito-sync/quotas/L-C5EE478A)  | The maximum size of a dataset in megabytes. | 
| Datasets per identity | Each supported Region: 20 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cognito-sync/quotas/L-2625A4A0)  | The maximum number of datasets per identity. | 
| Records per dataset | Each supported Region: 1,024 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cognito-sync/quotas/L-97A9518B)  | The maximum number of records per dataset. | 

For more information, see [Quotas in Amazon Cognito](https://docs.aws.amazon.com/cognito/latest/developerguide/limits.html) in the *Amazon Cognito Developer Guide*.