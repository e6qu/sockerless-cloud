

# AWS Amplify endpoints and quotas
<a name="amplify"></a>

To connect programmatically to an AWS service, you use an endpoint. AWS services offer the following endpoint types in some or all of the AWS Regions that the service supports: IPv4 endpoints, dual-stack endpoints, and FIPS endpoints. Some services provide global endpoints. For more information, see [AWS service endpoints](rande.md).

Service quotas, also referred to as limits, are the maximum number of service resources or operations for your AWS account. For more information, see [AWS service quotas](aws_service_limits.md).

The following are the service endpoints and service quotas for this service.

## Amplify endpoints
<a name="amplify_region"></a>


| Region Name | Region | Endpoint | Protocol | 
| --- | --- | --- | --- | 
| US East (Ohio) | us-east-2 |  amplify.us-east-2.amazonaws.com <br /> amplify.us-east-2.api.aws  | HTTPS<br />HTTPS | 
| US East (N. Virginia) | us-east-1 |  amplify.us-east-1.amazonaws.com <br /> amplify.us-east-1.api.aws  | HTTPS<br />HTTPS | 
| US West (N. California) | us-west-1 |  amplify.us-west-1.amazonaws.com <br /> amplify.us-west-1.api.aws  | HTTPS<br />HTTPS | 
| US West (Oregon) | us-west-2 |  amplify.us-west-2.amazonaws.com <br /> amplify.us-west-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Hong Kong) | ap-east-1 |  amplify.ap-east-1.amazonaws.com <br /> amplify.ap-east-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Mumbai) | ap-south-1 |  amplify.ap-south-1.amazonaws.com <br /> amplify.ap-south-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Osaka) | ap-northeast-3 |  amplify.ap-northeast-3.amazonaws.com <br /> amplify.ap-northeast-3.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Seoul) | ap-northeast-2 |  amplify.ap-northeast-2.amazonaws.com <br /> amplify.ap-northeast-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Singapore) | ap-southeast-1 |  amplify.ap-southeast-1.amazonaws.com <br /> amplify.ap-southeast-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Sydney) | ap-southeast-2 |  amplify.ap-southeast-2.amazonaws.com <br /> amplify.ap-southeast-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Tokyo) | ap-northeast-1 |  amplify.ap-northeast-1.amazonaws.com <br /> amplify.ap-northeast-1.api.aws  | HTTPS<br />HTTPS | 
| Canada (Central) | ca-central-1 |  amplify.ca-central-1.amazonaws.com <br /> amplify.ca-central-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Frankfurt) | eu-central-1 |  amplify.eu-central-1.amazonaws.com <br /> amplify.eu-central-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Ireland) | eu-west-1 |  amplify.eu-west-1.amazonaws.com <br /> amplify.eu-west-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (London) | eu-west-2 |  amplify.eu-west-2.amazonaws.com <br /> amplify.eu-west-2.api.aws  | HTTPS<br />HTTPS | 
| Europe (Milan) | eu-south-1 |  amplify.eu-south-1.amazonaws.com <br /> amplify.eu-south-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Paris) | eu-west-3 |  amplify.eu-west-3.amazonaws.com <br /> amplify.eu-west-3.api.aws  | HTTPS<br />HTTPS | 
| Europe (Stockholm) | eu-north-1 |  amplify.eu-north-1.amazonaws.com <br /> amplify.eu-north-1.api.aws  | HTTPS<br />HTTPS | 
| Middle East (Bahrain) | me-south-1 |  amplify.me-south-1.amazonaws.com <br /> amplify.me-south-1.api.aws  | HTTPS<br />HTTPS | 
| South America (São Paulo) | sa-east-1 |  amplify.sa-east-1.amazonaws.com <br /> amplify.sa-east-1.api.aws  | HTTPS<br />HTTPS | 

## Amplify Studio (backend) endpoints
<a name="amplifyadmin_region"></a>


| Region Name | Region | Endpoint | Protocol | 
| --- | --- | --- | --- | 
| US East (Ohio) | us-east-2 |  amplifybackend.us-east-2.amazonaws.com  | HTTPS | 
| US East (N. Virginia) | us-east-1 |  amplifybackend.us-east-1.amazonaws.com  | HTTPS | 
| US West (N. California) | us-west-1 |  amplifybackend.us-west-1.amazonaws.com  | HTTPS | 
| US West (Oregon) | us-west-2 |  amplifybackend.us-west-2.amazonaws.com  | HTTPS | 
| Asia Pacific (Mumbai) | ap-south-1 |  amplifybackend.ap-south-1.amazonaws.com  | HTTPS | 
| Asia Pacific (Osaka) | ap-northeast-3 |  amplifybackend.ap-northeast-3.amazonaws.com  | HTTPS | 
| Asia Pacific (Seoul) | ap-northeast-2 |  amplifybackend.ap-northeast-2.amazonaws.com  | HTTPS | 
| Asia Pacific (Singapore) | ap-southeast-1 |  amplifybackend.ap-southeast-1.amazonaws.com  | HTTPS | 
| Asia Pacific (Sydney) | ap-southeast-2 |  amplifybackend.ap-southeast-2.amazonaws.com  | HTTPS | 
| Asia Pacific (Tokyo) | ap-northeast-1 |  amplifybackend.ap-northeast-1.amazonaws.com  | HTTPS | 
| Canada (Central) | ca-central-1 |  amplifybackend.ca-central-1.amazonaws.com  | HTTPS | 
| Europe (Frankfurt) | eu-central-1 |  amplifybackend.eu-central-1.amazonaws.com  | HTTPS | 
| Europe (Ireland) | eu-west-1 |  amplifybackend.eu-west-1.amazonaws.com  | HTTPS | 
| Europe (London) | eu-west-2 |  amplifybackend.eu-west-2.amazonaws.com  | HTTPS | 
| Europe (Milan) | eu-south-1 |  amplifybackend.eu-south-1.amazonaws.com  | HTTPS | 
| Europe (Paris) | eu-west-3 |  amplifybackend.eu-west-3.amazonaws.com  | HTTPS | 
| Europe (Stockholm) | eu-north-1 |  amplifybackend.eu-north-1.amazonaws.com  | HTTPS | 
| Middle East (Bahrain) | me-south-1 |  amplifybackend.me-south-1.amazonaws.com  | HTTPS | 
| South America (São Paulo) | sa-east-1 |  amplifybackend.sa-east-1.amazonaws.com  | HTTPS | 

## Amplify Studio (UI Builder) endpoints
<a name="amplifyuibuilder_region"></a>


| Region Name | Region | Endpoint | Protocol | 
| --- | --- | --- | --- | 
| US East (Ohio) | us-east-2 |  amplifyuibuilder.us-east-2.amazonaws.com  | HTTPS | 
| US East (N. Virginia) | us-east-1 |  amplifyuibuilder.us-east-1.amazonaws.com  | HTTPS | 
| US West (N. California) | us-west-1 |  amplifyuibuilder.us-west-1.amazonaws.com  | HTTPS | 
| US West (Oregon) | us-west-2 |  amplifyuibuilder.us-west-2.amazonaws.com  | HTTPS | 
| Asia Pacific (Mumbai) | ap-south-1 |  amplifyuibuilder.ap-south-1.amazonaws.com  | HTTPS | 
| Asia Pacific (Osaka) | ap-northeast-3 |  amplifyuibuilder.ap-northeast-3.amazonaws.com  | HTTPS | 
| Asia Pacific (Seoul) | ap-northeast-2 |  amplifyuibuilder.ap-northeast-2.amazonaws.com  | HTTPS | 
| Asia Pacific (Singapore) | ap-southeast-1 |  amplifyuibuilder.ap-southeast-1.amazonaws.com  | HTTPS | 
| Asia Pacific (Sydney) | ap-southeast-2 |  amplifyuibuilder.ap-southeast-2.amazonaws.com  | HTTPS | 
| Asia Pacific (Tokyo) | ap-northeast-1 |  amplifyuibuilder.ap-northeast-1.amazonaws.com  | HTTPS | 
| Canada (Central) | ca-central-1 |  amplifyuibuilder.ca-central-1.amazonaws.com  | HTTPS | 
| Europe (Frankfurt) | eu-central-1 |  amplifyuibuilder.eu-central-1.amazonaws.com  | HTTPS | 
| Europe (Ireland) | eu-west-1 |  amplifyuibuilder.eu-west-1.amazonaws.com  | HTTPS | 
| Europe (London) | eu-west-2 |  amplifyuibuilder.eu-west-2.amazonaws.com  | HTTPS | 
| Europe (Milan) | eu-south-1 |  amplifyuibuilder.eu-south-1.amazonaws.com  | HTTPS | 
| Europe (Paris) | eu-west-3 |  amplifyuibuilder.eu-west-3.amazonaws.com  | HTTPS | 
| Europe (Stockholm) | eu-north-1 |  amplifyuibuilder.eu-north-1.amazonaws.com  | HTTPS | 
| Middle East (Bahrain) | me-south-1 |  amplifyuibuilder.me-south-1.amazonaws.com  | HTTPS | 
| South America (São Paulo) | sa-east-1 |  amplifyuibuilder.sa-east-1.amazonaws.com  | HTTPS | 

## Amplify Service quotas
<a name="service-quotas-amplify"></a>

**Important**  
New AWS accounts have reduced apps and concurrent jobs quotas. AWS raises these quotas automatically based on your usage. You can also [request a quota increase](https://docs.aws.amazon.com/servicequotas/latest/userguide/request-quota-increase.html).


| Name | Default | Adjustable | Description | 
| --- | --- | --- | --- | 
| Apps | Each supported Region: 25 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/amplify/quotas/L-1BED97F3)  | The maximum number of apps that you can create in AWS Amplify Console in this account in the current Region. | 
| Branches per app | Each supported Region: 50 | No | The maximum number of branches per app that you can create in this account in the current Region. | 
| Build artifact size | Each supported Region: 5 Gigabytes | No | The maximum size (in GB) of an app build artifact. A build artifact is deployed by AWS Amplify Console after a build. | 
| Cache artifact size | Each supported Region: 5 Gigabytes | No | The maximum size (in GB) of a cache artifact. | 
| Concurrent jobs | Each supported Region: 5 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/amplify/quotas/L-2A8ABB91)  | The maximum number of concurrent jobs that you can create in this account in the current Region. | 
| Domains per app | Each supported Region: 5 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/amplify/quotas/L-AD277529)  | The maximum number of domains per app that you can create in this account in the current Region. | 
| Environment cache artifact size | Each supported Region: 5 Gigabytes | No | The maximum size (in GB) of the environment cache artifact. | 
| Manual deploy ZIP file size | Each supported Region: 5 Gigabytes | No | The maximum size (in GB) of a manual deploy ZIP file. | 
| Maximum app creations per hour | Each supported Region: 25 | No | The maximum number of apps that you can create in AWS Amplify Console per hour in this account in the current Region. | 
| Request tokens per second | Each supported Region: 20,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/amplify/quotas/L-CE88B60E)  | The maximum number of request tokens per second for an app. Amplify Hosting allocates tokens to requests based on the amount of resources (processing time and data transfer) that they consume. | 
| Subdomains per domain | Each supported Region: 50 | No | The maximum number of subdomains per domain that you can create in this account in the current Region. | 
| Webhooks per app | Each supported Region: 50 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/amplify/quotas/L-4113FC04)  | The maximum number of webhooks per app that you can create in this account in the current Region. | 

## Amplify Studio (UI Builder) Service quotas
<a name="service-quotas-amplify-ui-builder"></a>


| Name | Default | Adjustable | Description | 
| --- | --- | --- | --- | 
| Component size | Each supported Region: 350 Kilobytes | No | The maximum size (in KB) of the component. | 
| Components per app | Each supported Region: 1,000 | No | The maximum number of components that you can create per Amplify app in the current Region. | 
| Form size | Each supported Region: 350 Kilobytes | No | The maximum size (in KB) of the form. | 
| Forms per app | Each supported Region: 1,000 | No | The maximum number of forms that you can create per Amplify app in the current Region. | 
| Theme size | Each supported Region: 350 Kilobytes | No | The maximum size (in KB) of the theme. | 
| Themes per app | Each supported Region: 1,000 | No | The maximum number of themes that you can create per Amplify app in the current Region. | 
| View size | Each supported Region: 350 Kilobytes | No | The maximum size (in KB) of the view. | 
| Views per app | Each supported Region: 1,000 | No | The maximum number of views that you can create per Amplify app in the current Region. | 