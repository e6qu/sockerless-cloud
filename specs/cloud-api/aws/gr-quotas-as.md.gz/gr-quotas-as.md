

# Amazon EC2 Auto Scaling endpoints and quotas
<a name="as"></a>

To connect programmatically to an AWS service, you use an endpoint. AWS services offer the following endpoint types in some or all of the AWS Regions that the service supports: IPv4 endpoints, dual-stack endpoints, and FIPS endpoints. Some services provide global endpoints. For more information, see [AWS service endpoints](rande.md).

Service quotas, also referred to as limits, are the maximum number of service resources or operations for your AWS account. For more information, see [AWS service quotas](aws_service_limits.md).

The following are the service endpoints and service quotas for this service.

## Service endpoints
<a name="as_region"></a>


| Region Name | Region | Endpoint | Protocol | 
| --- | --- | --- | --- | 
| US East (Ohio) | us-east-2 |  autoscaling.us-east-2.amazonaws.com <br /> autoscaling-fips.us-east-2.api.aws <br /> autoscaling-fips.us-east-2.amazonaws.com <br /> autoscaling.us-east-2.api.aws  | HTTP and HTTPS<br />HTTPS<br />HTTPS<br />HTTP and HTTPS | 
| US East (N. Virginia) | us-east-1 |  autoscaling.us-east-1.amazonaws.com <br /> autoscaling-fips.us-east-1.api.aws <br /> autoscaling-fips.us-east-1.amazonaws.com <br /> autoscaling.us-east-1.api.aws  | HTTP and HTTPS<br />HTTPS<br />HTTPS<br />HTTP and HTTPS | 
| US West (N. California) | us-west-1 |  autoscaling.us-west-1.amazonaws.com <br /> autoscaling-fips.us-west-1.api.aws <br /> autoscaling-fips.us-west-1.amazonaws.com <br /> autoscaling.us-west-1.api.aws  | HTTP and HTTPS<br />HTTPS<br />HTTPS<br />HTTP and HTTPS | 
| US West (Oregon) | us-west-2 |  autoscaling.us-west-2.amazonaws.com <br /> autoscaling-fips.us-west-2.api.aws <br /> autoscaling-fips.us-west-2.amazonaws.com <br /> autoscaling.us-west-2.api.aws  | HTTP and HTTPS<br />HTTPS<br />HTTPS<br />HTTP and HTTPS | 
| Africa (Cape Town) | af-south-1 |  autoscaling.af-south-1.amazonaws.com <br /> autoscaling.af-south-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (Hong Kong) | ap-east-1 |  autoscaling.ap-east-1.amazonaws.com <br /> autoscaling.ap-east-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (Hyderabad) | ap-south-2 |  autoscaling.ap-south-2.amazonaws.com <br /> autoscaling.ap-south-2.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (Jakarta) | ap-southeast-3 |  autoscaling.ap-southeast-3.amazonaws.com <br /> autoscaling.ap-southeast-3.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (Malaysia) | ap-southeast-5 |  autoscaling.ap-southeast-5.amazonaws.com <br /> autoscaling.ap-southeast-5.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (Melbourne) | ap-southeast-4 |  autoscaling.ap-southeast-4.amazonaws.com <br /> autoscaling.ap-southeast-4.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (Mumbai) | ap-south-1 |  autoscaling.ap-south-1.amazonaws.com <br /> autoscaling.ap-south-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (New Zealand) | ap-southeast-6 |  autoscaling.ap-southeast-6.amazonaws.com <br /> autoscaling.ap-southeast-6.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (Osaka) | ap-northeast-3 |  autoscaling.ap-northeast-3.amazonaws.com <br /> autoscaling.ap-northeast-3.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (Seoul) | ap-northeast-2 |  autoscaling.ap-northeast-2.amazonaws.com <br /> autoscaling.ap-northeast-2.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (Singapore) | ap-southeast-1 |  autoscaling.ap-southeast-1.amazonaws.com <br /> autoscaling.ap-southeast-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (Sydney) | ap-southeast-2 |  autoscaling.ap-southeast-2.amazonaws.com <br /> autoscaling.ap-southeast-2.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (Taipei) | ap-east-2 |  autoscaling.ap-east-2.amazonaws.com <br /> autoscaling.ap-east-2.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (Thailand) | ap-southeast-7 |  autoscaling.ap-southeast-7.amazonaws.com <br /> autoscaling.ap-southeast-7.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Asia Pacific (Tokyo) | ap-northeast-1 |  autoscaling.ap-northeast-1.amazonaws.com <br /> autoscaling.ap-northeast-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Canada (Central) | ca-central-1 |  autoscaling.ca-central-1.amazonaws.com <br /> autoscaling-fips.ca-central-1.api.aws <br /> autoscaling-fips.ca-central-1.amazonaws.com <br /> autoscaling.ca-central-1.api.aws  | HTTP and HTTPS<br />HTTPS<br />HTTPS<br />HTTP and HTTPS | 
| Canada West (Calgary) | ca-west-1 |  autoscaling.ca-west-1.amazonaws.com <br /> autoscaling-fips.ca-west-1.api.aws <br /> autoscaling-fips.ca-west-1.amazonaws.com <br /> autoscaling.ca-west-1.api.aws  | HTTP and HTTPS<br />HTTPS<br />HTTPS<br />HTTP and HTTPS | 
| Europe (Frankfurt) | eu-central-1 |  autoscaling.eu-central-1.amazonaws.com <br /> autoscaling.eu-central-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Europe (Ireland) | eu-west-1 |  autoscaling.eu-west-1.amazonaws.com <br /> autoscaling.eu-west-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Europe (London) | eu-west-2 |  autoscaling.eu-west-2.amazonaws.com <br /> autoscaling.eu-west-2.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Europe (Milan) | eu-south-1 |  autoscaling.eu-south-1.amazonaws.com <br /> autoscaling.eu-south-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Europe (Paris) | eu-west-3 |  autoscaling.eu-west-3.amazonaws.com <br /> autoscaling.eu-west-3.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Europe (Spain) | eu-south-2 |  autoscaling.eu-south-2.amazonaws.com <br /> autoscaling.eu-south-2.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Europe (Stockholm) | eu-north-1 |  autoscaling.eu-north-1.amazonaws.com <br /> autoscaling.eu-north-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Europe (Zurich) | eu-central-2 |  autoscaling.eu-central-2.amazonaws.com <br /> autoscaling.eu-central-2.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Israel (Tel Aviv) | il-central-1 |  autoscaling.il-central-1.amazonaws.com <br /> autoscaling.il-central-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Mexico (Central) | mx-central-1 |  autoscaling.mx-central-1.amazonaws.com <br /> autoscaling.mx-central-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Middle East (Bahrain) | me-south-1 |  autoscaling.me-south-1.amazonaws.com <br /> autoscaling.me-south-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| Middle East (UAE) | me-central-1 |  autoscaling.me-central-1.amazonaws.com <br /> autoscaling.me-central-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
| South America (São Paulo) | sa-east-1 |  autoscaling.sa-east-1.amazonaws.com <br /> autoscaling.sa-east-1.api.aws  | HTTP and HTTPS<br />HTTP and HTTPS | 
|  AWS GovCloud (US-East) | us-gov-east-1 |  autoscaling.us-gov-east-1.amazonaws.com <br /> autoscaling.us-gov-east-1.api.aws  | HTTP and HTTPS<br />HTTPS | 
|  AWS GovCloud (US-West) | us-gov-west-1 |  autoscaling.us-gov-west-1.amazonaws.com <br /> autoscaling.us-gov-west-1.api.aws  | HTTP and HTTPS<br />HTTPS | 

If you specify the general endpoint (autoscaling.amazonaws.com), Amazon EC2 Auto Scaling directs your request to the endpoint for `us-east-1`.

## Service quotas
<a name="limits_autoscaling"></a>


| Name | Default | Adjustable | Description | 
| --- | --- | --- | --- | 
| Auto Scaling groups per region | Each supported Region: 500 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/autoscaling/quotas/L-CDE20ADC)  | The maximum number of Auto Scaling groups allowed for your AWS account | 
| Classic Load Balancers per Auto Scaling group | Each supported Region: 50 | No | The maximum number of Classic Load Balancers per Auto Scaling group | 
| Launch configurations per region | Each supported Region: 200 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/autoscaling/quotas/L-6B80B8FA)  | The maximum number of launch configurations allowed for your AWS account | 
| Lifecycle hooks per Auto Scaling group | Each supported Region: 50 | No | The maximum number of lifecycle hooks per Auto Scaling group | 
| SNS topics per Auto Scaling group | Each supported Region: 10 | No | The maximum number of SNS topics per Auto Scaling group | 
| Scaling policies per Auto Scaling group | Each supported Region: 50 | No | The maximum number of scaling policies per Auto Scaling group | 
| Scheduled actions per Auto Scaling group | Each supported Region: 125 | No | The maximum number of scheduled actions per Auto Scaling group | 
| Step adjustments per step scaling policy | Each supported Region: 20 | No | The maximum number of step adjustments per step scaling policy | 
| Target groups per Auto Scaling group | Each supported Region: 50 | No | The maximum number of target groups per Auto Scaling group | 

For more information, see [Quotas for Amazon EC2 Auto Scaling](https://docs.aws.amazon.com/autoscaling/ec2/userguide/ec2-auto-scaling-quotas.html) in the *Amazon EC2 Auto Scaling User Guide*.