

# AWS Identity and Access Management endpoints and quotas
<a name="iam-service"></a>

To connect programmatically to an AWS service, you use an endpoint. AWS services offer the following endpoint types in some or all of the AWS Regions that the service supports: IPv4 endpoints, dual-stack endpoints, and FIPS endpoints. Some services provide global endpoints. For more information, see [AWS service endpoints](rande.md).

Service quotas, also referred to as limits, are the maximum number of service resources or operations for your AWS account. For more information, see [AWS service quotas](aws_service_limits.md).

The following are the service endpoints and service quotas for this service.

## Service endpoints
<a name="iam_region"></a>


| Region Name | Region | Endpoint | Protocol | 
| --- | --- | --- | --- | 
| US East (Ohio) | us-east-2 |  iam.amazonaws.com  | HTTPS | 
| US East (N. Virginia) | us-east-1 |  iam.amazonaws.com <br /> iam-fips.amazonaws.com  | HTTPS<br />HTTPS | 
| US West (N. California) | us-west-1 |  iam.amazonaws.com  | HTTPS | 
| US West (Oregon) | us-west-2 |  iam.amazonaws.com  | HTTPS | 
| Africa (Cape Town) | af-south-1 |  iam.amazonaws.com  | HTTPS | 
| Asia Pacific (Hong Kong) | ap-east-1 |  iam.amazonaws.com  | HTTPS | 
| Asia Pacific (Hyderabad) | ap-south-2 |  iam.amazonaws.com  | HTTPS | 
| Asia Pacific (Jakarta) | ap-southeast-3 |  iam.amazonaws.com  | HTTPS | 
| Asia Pacific (Malaysia) | ap-southeast-5 |  iam.amazonaws.com  | HTTPS | 
| Asia Pacific (Melbourne) | ap-southeast-4 |  iam.amazonaws.com  | HTTPS | 
| Asia Pacific (Mumbai) | ap-south-1 |  iam.amazonaws.com  | HTTPS | 
| Asia Pacific (New Zealand) | ap-southeast-6 |  iam.amazonaws.com  | HTTPS | 
| Asia Pacific (Osaka) | ap-northeast-3 |  iam.amazonaws.com  | HTTPS | 
| Asia Pacific (Seoul) | ap-northeast-2 |  iam.amazonaws.com  | HTTPS | 
| Asia Pacific (Singapore) | ap-southeast-1 |  iam.amazonaws.com  | HTTPS | 
| Asia Pacific (Sydney) | ap-southeast-2 |  iam.amazonaws.com  | HTTPS | 
| Asia Pacific (Taipei) | ap-east-2 |  iam.amazonaws.com  | HTTPS | 
| Asia Pacific (Thailand) | ap-southeast-7 |  iam.amazonaws.com  | HTTPS | 
| Asia Pacific (Tokyo) | ap-northeast-1 |  iam.amazonaws.com  | HTTPS | 
| Canada (Central) | ca-central-1 |  iam.amazonaws.com  | HTTPS | 
| Canada West (Calgary) | ca-west-1 |  iam.amazonaws.com  | HTTPS | 
| Europe (Frankfurt) | eu-central-1 |  iam.amazonaws.com  | HTTPS | 
| Europe (Ireland) | eu-west-1 |  iam.amazonaws.com  | HTTPS | 
| Europe (London) | eu-west-2 |  iam.amazonaws.com  | HTTPS | 
| Europe (Milan) | eu-south-1 |  iam.amazonaws.com  | HTTPS | 
| Europe (Paris) | eu-west-3 |  iam.amazonaws.com  | HTTPS | 
| Europe (Spain) | eu-south-2 |  iam.amazonaws.com  | HTTPS | 
| Europe (Stockholm) | eu-north-1 |  iam.amazonaws.com  | HTTPS | 
| Europe (Zurich) | eu-central-2 |  iam.amazonaws.com  | HTTPS | 
| Israel (Tel Aviv) | il-central-1 |  iam.amazonaws.com  | HTTPS | 
| Mexico (Central) | mx-central-1 |  iam.amazonaws.com  | HTTPS | 
| Middle East (Bahrain) | me-south-1 |  iam.amazonaws.com  | HTTPS | 
| Middle East (UAE) | me-central-1 |  iam.amazonaws.com  | HTTPS | 
| South America (São Paulo) | sa-east-1 |  iam.amazonaws.com  | HTTPS | 
|  AWS GovCloud (US-East) | us-gov-east-1 |  iam.us-gov.amazonaws.com  | HTTPS | 
|  AWS GovCloud (US-West) | us-gov-west-1 |  iam.us-gov.amazonaws.com  | HTTPS | 

## Service quotas
<a name="limits_iam"></a>


| Name | Default | Adjustable | Description | 
| --- | --- | --- | --- | 
| Access keys per user | Each supported Region: 2 | No | The maximum number of access keys that you can create for an IAM user. | 
| Customer managed policies per account | Each supported Region: 1,500 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/iam/quotas/L-E95E4862)  | The maximum number of customer managed policies that you can create in this account. | 
| Groups per account | Each supported Region: 300 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/iam/quotas/L-F4A5425F)  | The maximum number of IAM groups that you can create in this account. | 
| IAM groups per user | Each supported Region: 10 | No | The maximum number of IAM groups to which you can add an IAM user. | 
| Identity providers per IAM SAML provider object | Each supported Region: 10 | No | The maximum number of identity providers (IdPs) that you can add to an IAM SAML provider object. | 
| Instance profiles per account | Each supported Region: 1,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/iam/quotas/L-6E65F664)  | The maximum number of instance profiles that you can create in this account. | 
| Keys per SAML provider | Each supported Region: 10 | No | The maximum number of keys that you can assign to a SAML provider. | 
| MFA devices per user | Each supported Region: 8 | No | The maximum number of MFA devices that you can configure for an IAM user. | 
| Managed policies per group | Each supported Region: 10 | No | The maximum number of IAM managed policies that you can attach to an IAM group. | 
| Managed policies per role | Each supported Region: 20 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/iam/quotas/L-0DA4ABF3)  | The maximum number of IAM managed policies that you can attach to an IAM role. | 
| Managed policies per user | Each supported Region: 10 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/iam/quotas/L-4019AD8B)  | The maximum number of IAM managed policies that you can attach to an IAM user. | 
| Managed policy length | Each supported Region: 6,144 | No | The maximum number of characters in an IAM managed policy. | 
| OpenId connect providers per account | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/iam/quotas/L-858F3967)  | Maximum number of OpenID connectors allowed for an AWS account. | 
| Role trust policy length | Each supported Region: 2,048 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/iam/quotas/L-C07B4B0D)  | The maximum number of characters in an IAM role trust policy. | 
| Roles per account | Each supported Region: 1,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/iam/quotas/L-FE177D64)  | The maximum number of IAM roles that you can create in this account. | 
| SAML providers per account | Each supported Region: 100 | No | The maximum number of SAML providers that you can create in this account. | 
| SSH Public keys per user | Each supported Region: 5 | No | The maximum number of SSH public keys that you can assign to an IAM user. | 
| Server certificates per account | Each supported Region: 20 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/iam/quotas/L-BF35879D)  | The maximum number of server certificates that you can store in this account. | 
| Signing certificates per user | Each supported Region: 2 | No | The maximum number of signing certificates that you can upload for an IAM user. | 
| Tags per role | Each supported Region: 50 | No | The maximum number of tags that you can assign to an IAM role. | 
| Tags per user | Each supported Region: 50 | No | The maximum number of tags that you can assign to an IAM user. | 
| Users per account | Each supported Region: 5,000 | No | The maximum number of IAM users you can create for your AWS account. | 
| Versions per managed policy | Each supported Region: 5 | No | The maximum number of versions that you can save to an IAM managed policy in this account before you must overwrite an existing version. | 

For more information about IAM quotas, see [IAM and AWS STS quotas](https://docs.aws.amazon.com/IAM/latest/UserGuide/reference_iam-quotas.html) in the *IAM User Guide*.