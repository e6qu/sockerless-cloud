

# PutAnomalyDetector
<a name="API_PutAnomalyDetector"></a>

Creates an anomaly detection model for a CloudWatch metric. You can use the model to display a band of expected normal values when the metric is graphed.

If you have enabled unified cross-account observability, and this account is a monitoring account, the metric can be in the same account or a source account. You can specify the account ID in the object you specify in the `SingleMetricAnomalyDetector` parameter.

For more information, see [CloudWatch Anomaly Detection](https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/CloudWatch_Anomaly_Detection.html).

## Request Syntax
<a name="API_PutAnomalyDetector_RequestSyntax"></a>

```
{
   "Configuration": { 
      "AdaptationSpeed": "{{string}}",
      "ExcludedTimeRanges": [ 
         { 
            "EndTime": {{number}},
            "StartTime": {{number}}
         }
      ],
      "MetricTimezone": "{{string}}",
      "OutlierFilteringStrength": "{{string}}"
   },
   "Dimensions": [ 
      { 
         "Name": "{{string}}",
         "Value": "{{string}}"
      }
   ],
   "MetricCharacteristics": { 
      "PeriodicSpikes": {{boolean}}
   },
   "MetricMathAnomalyDetector": { 
      "MetricDataQueries": [ 
         { 
            "AccountId": "{{string}}",
            "Expression": "{{string}}",
            "Id": "{{string}}",
            "Label": "{{string}}",
            "MetricStat": { 
               "Metric": { 
                  "Dimensions": [ 
                     { 
                        "Name": "{{string}}",
                        "Value": "{{string}}"
                     }
                  ],
                  "MetricName": "{{string}}",
                  "Namespace": "{{string}}"
               },
               "Period": {{number}},
               "Stat": "{{string}}",
               "Unit": "{{string}}"
            },
            "Period": {{number}},
            "ReturnData": {{boolean}}
         }
      ]
   },
   "MetricName": "{{string}}",
   "Namespace": "{{string}}",
   "SingleMetricAnomalyDetector": { 
      "AccountId": "{{string}}",
      "Dimensions": [ 
         { 
            "Name": "{{string}}",
            "Value": "{{string}}"
         }
      ],
      "MetricName": "{{string}}",
      "Namespace": "{{string}}",
      "Stat": "{{string}}"
   },
   "Stat": "{{string}}"
}
```

## Request Parameters
<a name="API_PutAnomalyDetector_RequestParameters"></a>

For information about the parameters that are common to all actions, see [Common Parameters](CommonParameters.md).

The request accepts the following data in JSON format.

 ** [Configuration](#API_PutAnomalyDetector_RequestSyntax) **   <a name="ACW-PutAnomalyDetector-request-Configuration"></a>
The configuration specifies details about how the anomaly detection model is to be trained, including time ranges to exclude when training and updating the model. You can specify as many as 10 time ranges.  
The configuration can also include the time zone to use for the metric.  
Type: [AnomalyDetectorConfiguration](API_AnomalyDetectorConfiguration.md) object  
Required: No

 ** [Dimensions](#API_PutAnomalyDetector_RequestSyntax) **   <a name="ACW-PutAnomalyDetector-request-Dimensions"></a>
 *This parameter has been deprecated.*   
The metric dimensions to create the anomaly detection model for.  
Type: Array of [Dimension](API_Dimension.md) objects  
Array Members: Maximum number of 30 items.  
Required: No

 ** [MetricCharacteristics](#API_PutAnomalyDetector_RequestSyntax) **   <a name="ACW-PutAnomalyDetector-request-MetricCharacteristics"></a>
Use this object to include parameters to provide information about your metric to CloudWatch to help it build more accurate anomaly detection models. Currently, it includes the `PeriodicSpikes` parameter.  
Type: [MetricCharacteristics](API_MetricCharacteristics.md) object  
Required: No

 ** [MetricMathAnomalyDetector](#API_PutAnomalyDetector_RequestSyntax) **   <a name="ACW-PutAnomalyDetector-request-MetricMathAnomalyDetector"></a>
The metric math anomaly detector to be created.  
When using `MetricMathAnomalyDetector`, you cannot include the following parameters in the same operation:  
+  `Dimensions` 
+  `MetricName` 
+  `Namespace` 
+  `Stat` 
+ the `SingleMetricAnomalyDetector` parameters of `PutAnomalyDetectorInput` 
Instead, specify the metric math anomaly detector attributes as part of the property `MetricMathAnomalyDetector`.  
Type: [MetricMathAnomalyDetector](API_MetricMathAnomalyDetector.md) object  
Required: No

 ** [MetricName](#API_PutAnomalyDetector_RequestSyntax) **   <a name="ACW-PutAnomalyDetector-request-MetricName"></a>
 *This parameter has been deprecated.*   
The name of the metric to create the anomaly detection model for.  
Type: String  
Length Constraints: Minimum length of 1. Maximum length of 255.  
Required: No

 ** [Namespace](#API_PutAnomalyDetector_RequestSyntax) **   <a name="ACW-PutAnomalyDetector-request-Namespace"></a>
 *This parameter has been deprecated.*   
The namespace of the metric to create the anomaly detection model for.  
Type: String  
Length Constraints: Minimum length of 1. Maximum length of 255.  
Pattern: `[^:].*`   
Required: No

 ** [SingleMetricAnomalyDetector](#API_PutAnomalyDetector_RequestSyntax) **   <a name="ACW-PutAnomalyDetector-request-SingleMetricAnomalyDetector"></a>
A single metric anomaly detector to be created.  
When using `SingleMetricAnomalyDetector`, you cannot include the following parameters in the same operation:  
+  `Dimensions` 
+  `MetricName` 
+  `Namespace` 
+  `Stat` 
+ the `MetricMathAnomalyDetector` parameters of `PutAnomalyDetectorInput` 
Instead, specify the single metric anomaly detector attributes as part of the property `SingleMetricAnomalyDetector`.  
Type: [SingleMetricAnomalyDetector](API_SingleMetricAnomalyDetector.md) object  
Required: No

 ** [Stat](#API_PutAnomalyDetector_RequestSyntax) **   <a name="ACW-PutAnomalyDetector-request-Stat"></a>
 *This parameter has been deprecated.*   
The statistic to use for the metric and the anomaly detection model.  
Type: String  
Length Constraints: Maximum length of 50.  
Pattern: `(SampleCount|Average|Sum|Minimum|Maximum|IQM|(p|tc|tm|ts|wm)(\d{1,2}(\.\d{0,10})?|100)|[ou]\d+(\.\d*)?)(_E|_L|_H)?|(TM|TC|TS|WM)\(((((\d{1,2})(\.\d{0,10})?|100(\.0{0,10})?)%)?:((\d{1,2})(\.\d{0,10})?|100(\.0{0,10})?)%|((\d{1,2})(\.\d{0,10})?|100(\.0{0,10})?)%:(((\d{1,2})(\.\d{0,10})?|100(\.0{0,10})?)%)?)\)|(TM|TC|TS|WM|PR)\(((\d+(\.\d{0,10})?|(\d+(\.\d{0,10})?[Ee][+-]?\d+)):((\d+(\.\d{0,10})?|(\d+(\.\d{0,10})?[Ee][+-]?\d+)))?|((\d+(\.\d{0,10})?|(\d+(\.\d{0,10})?[Ee][+-]?\d+)))?:(\d+(\.\d{0,10})?|(\d+(\.\d{0,10})?[Ee][+-]?\d+)))\)`   
Required: No

## Response Syntax
<a name="API_PutAnomalyDetector_ResponseSyntax"></a>

```
{
   "AnomalyDetectorId": "string"
}
```

## Response Elements
<a name="API_PutAnomalyDetector_ResponseElements"></a>

If the action is successful, the service sends back an HTTP 200 response.

The following data is returned in JSON format by the service.

 ** [AnomalyDetectorId](#API_PutAnomalyDetector_ResponseSyntax) **   <a name="ACW-PutAnomalyDetector-response-AnomalyDetectorId"></a>
The unique identifier of the anomaly detector that you created or updated.  
Type: String  
Length Constraints: Minimum length of 1. Maximum length of 128.  
Pattern: `[A-Za-z0-9_./:%()+-]+` 

## Errors
<a name="API_PutAnomalyDetector_Errors"></a>

For information about the errors that are common to all actions, see [Common Error Types](CommonErrors.md).

 ** InternalServiceError **   
Request processing has failed due to some unknown error, exception, or failure.    
 ** Message **   

HTTP Status Code: 500

 ** InvalidParameterCombination **   
Parameters were used together that cannot be used together.    
 ** message **   

HTTP Status Code: 400

 ** InvalidParameterValue **   
The value of an input parameter is bad or out-of-range.    
 ** message **   

HTTP Status Code: 400

 ** LimitExceededException **   
The operation exceeded one or more limits.  
HTTP Status Code: 400

 ** MissingParameter **   
An input parameter that is required is missing.    
 ** message **   

HTTP Status Code: 400

## See Also
<a name="API_PutAnomalyDetector_SeeAlso"></a>

For more information about using this API in one of the language-specific AWS SDKs, see the following:
+  [AWS Command Line Interface V2](https://docs.aws.amazon.com/goto/cli2/monitoring-2010-08-01/PutAnomalyDetector) 
+  [AWS SDK for .NET V4](https://docs.aws.amazon.com/goto/DotNetSDKV4/monitoring-2010-08-01/PutAnomalyDetector) 
+  [AWS SDK for C\+\+](https://docs.aws.amazon.com/goto/SdkForCpp/monitoring-2010-08-01/PutAnomalyDetector) 
+  [AWS SDK for Go v2](https://docs.aws.amazon.com/goto/SdkForGoV2/monitoring-2010-08-01/PutAnomalyDetector) 
+  [AWS SDK for Java V2](https://docs.aws.amazon.com/goto/SdkForJavaV2/monitoring-2010-08-01/PutAnomalyDetector) 
+  [AWS SDK for JavaScript V3](https://docs.aws.amazon.com/goto/SdkForJavaScriptV3/monitoring-2010-08-01/PutAnomalyDetector) 
+  [AWS SDK for Kotlin](https://docs.aws.amazon.com/goto/SdkForKotlin/monitoring-2010-08-01/PutAnomalyDetector) 
+  [AWS SDK for PHP V3](https://docs.aws.amazon.com/goto/SdkForPHPV3/monitoring-2010-08-01/PutAnomalyDetector) 
+  [AWS SDK for Python (Boto3)](https://docs.aws.amazon.com/goto/boto3/monitoring-2010-08-01/PutAnomalyDetector) 
+  [AWS SDK for Ruby V3](https://docs.aws.amazon.com/goto/SdkForRubyV3/monitoring-2010-08-01/PutAnomalyDetector) 