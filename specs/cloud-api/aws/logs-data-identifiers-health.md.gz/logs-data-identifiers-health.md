

# Protected health information (PHI)
<a name="protect-sensitive-log-data-types-health"></a>

CloudWatch Logs data protection can find the following types of protected health information (PHI).

If you set a data protection policy, CloudWatch Logs scans for the data identifiers that you specify no matter what geolocation the log group is located in. The information in the **Countries and regions** column in this table designates whether two-letter country codes must be appended to the data identifier to detect the appropriate keywords for those countries and regions.


| Type of data | Data identifier ID | Keyword required | Countries and regions | 
| --- | --- | --- | --- | 
| Drug Enforcement Agency (DEA) registration number | `DrugEnforcementAgencyNumber` | `dea number`, `dea registration` | United States | 
| Health Insurance Card Number (EHIC) | `HealthInsuranceCardNumber` | `assicurazione sanitaria numero`, `carta assicurazione numero`, `carte d’assurance maladie`, `carte européenne d'assurance maladie`, `ceam`, `ehic`, `ehic#`, `finlandehicnumber#`, `gesundheitskarte`, `hälsokort`, `health card`, `health card number`, `health insurance card`, `health insurance number`, `insurance card number`, `krankenversicherungskarte`, `krankenversicherungsnummer`, `medical account number`, `numero conto medico`, `numéro d’assurance maladie`, `numéro de carte d’assurance`, `numéro de compte medical`, `número de cuenta médica`, `número de seguro de salud`, `número de tarjeta de seguro`, `sairaanhoitokortin`, `sairausvakuutuskortti`, `sairausvakuutusnumero`, `sjukförsäkring nummer`, `sjukförsäkringskort`, `suomi ehic-numero`, `tarjeta de salud`, `terveyskortti`, `tessera sanitaria assicurazione numero`, `versicherungsnummer` | European Union | 
| Health Insurance Claim Number (HICN) | `HealthInsuranceClaimNumber` | `health insurance claim number`, `hic no`, `hic no.`, `hic number`, `hic#`, `hicn`, `hicn#`, `hicno#` | United States | 
| Health insurance or medical identification number | `HealthInsuranceNumber` | `carte d'assuré social`, `carte vitale`, `insurance card`  | France | 
| Healthcare Common Procedure Coding System (HCPCS) code | `HealthcareProcedureCode` | `current procedural terminology`, `hcpcs`, `healthcare common procedure coding system`  | United States | 
| Medicare Beneficiary Number (MBN) | `MedicareBeneficiaryNumber` | `mbi`, `medicare beneficiary` | United States | 
| National Drug Code (NDC) | `NationalDrugCode` | `national drug code`, `ndc` | United States | 
| National Provider Identifier (NPI) | `NationalProviderId` | `hipaa`, `n.p.i.`, `national provider`, `npi` | United States | 
| National Health Service (NHS) number | `NhsNumber` | `national health service`, `NHS` | Great Britain | 
| Personal Health Number | `PersonalHealthNumber` | `canada healthcare number`, `msp number`, `care number`, `phn`, `soins de santé`  | Canada | 

## Data identifier ARNs for protected health information data types (PHI)
<a name="cwl-data-protection-phi-arns"></a>

The following lists the data identifier Amazon Resource Names (ARNs) that can be used in protected health information (PHI) data protection policies.


| PHI data identifier ARNs | 
| --- | 
| arn:aws:dataprotection::aws:data-identifier/DrugEnforcementAgencyNumber-US | 
| arn:aws:dataprotection::aws:data-identifier/HealthcareProcedureCode-US | 
| arn:aws:dataprotection::aws:data-identifier/HealthInsuranceCardNumber-EU | 
| arn:aws:dataprotection::aws:data-identifier/HealthInsuranceClaimNumber-US | 
| arn:aws:dataprotection::aws:data-identifier/HealthInsuranceNumber-FR | 
| arn:aws:dataprotection::aws:data-identifier/MedicareBeneficiaryNumber-US | 
| arn:aws:dataprotection::aws:data-identifier/NationalDrugCode-US | 
| arn:aws:dataprotection::aws:data-identifier/NationalInsuranceNumber-GB | 
| arn:aws:dataprotection::aws:data-identifier/NationalProviderId-US | 
| arn:aws:dataprotection::aws:data-identifier/NhsNumber-GB | 
| arn:aws:dataprotection::aws:data-identifier/PersonalHealthNumber-CA | 