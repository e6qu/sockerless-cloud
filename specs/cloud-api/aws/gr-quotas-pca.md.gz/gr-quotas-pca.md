

# AWS Private Certificate Authority endpoints and quotas
<a name="pca"></a>

To connect programmatically to an AWS service, you use an endpoint. AWS services offer the following endpoint types in some or all of the AWS Regions that the service supports: IPv4 endpoints, dual-stack endpoints, and FIPS endpoints. Some services provide global endpoints. For more information, see [AWS service endpoints](rande.md).

Service quotas, also referred to as limits, are the maximum number of service resources or operations for your AWS account. For more information, see [AWS service quotas](aws_service_limits.md).

The following are the service endpoints and service quotas for this service.

## AWS Private CA endpoints
<a name="pca_region"></a>


| Region Name | Region | Endpoint | Protocol | 
| --- | --- | --- | --- | 
| US East (Ohio) | us-east-2 |  acm-pca.us-east-2.amazonaws.com <br /> acm-pca-fips.us-east-2.amazonaws.com <br /> acm-pca-fips.us-east-2.api.aws <br /> acm-pca.us-east-2.api.aws  | https<br />HTTPS<br />HTTPS<br />HTTPS | 
| US East (N. Virginia) | us-east-1 |  acm-pca.us-east-1.amazonaws.com <br /> acm-pca-fips.us-east-1.amazonaws.com <br /> acm-pca-fips.us-east-1.api.aws <br /> acm-pca.us-east-1.api.aws  | https<br />HTTPS<br />HTTPS<br />HTTPS | 
| US West (N. California) | us-west-1 |  acm-pca.us-west-1.amazonaws.com <br /> acm-pca-fips.us-west-1.amazonaws.com <br /> acm-pca-fips.us-west-1.api.aws <br /> acm-pca.us-west-1.api.aws  | https<br />HTTPS<br />HTTPS<br />HTTPS | 
| US West (Oregon) | us-west-2 |  acm-pca.us-west-2.amazonaws.com <br /> acm-pca-fips.us-west-2.amazonaws.com <br /> acm-pca-fips.us-west-2.api.aws <br /> acm-pca.us-west-2.api.aws  | https<br />HTTPS<br />HTTPS<br />HTTPS | 
| Africa (Cape Town) | af-south-1 |  acm-pca.af-south-1.amazonaws.com <br /> acm-pca.af-south-1.api.aws  | https<br />HTTPS | 
| Asia Pacific (Hong Kong) | ap-east-1 |  acm-pca.ap-east-1.amazonaws.com <br /> acm-pca.ap-east-1.api.aws  | https<br />HTTPS | 
| Asia Pacific (Hyderabad) | ap-south-2 |  acm-pca.ap-south-2.amazonaws.com <br /> acm-pca.ap-south-2.api.aws  | https<br />HTTPS | 
| Asia Pacific (Jakarta) | ap-southeast-3 |  acm-pca.ap-southeast-3.amazonaws.com <br /> acm-pca.ap-southeast-3.api.aws  | https<br />HTTPS | 
| Asia Pacific (Malaysia) | ap-southeast-5 |  acm-pca.ap-southeast-5.amazonaws.com <br /> acm-pca.ap-southeast-5.api.aws  | https<br />HTTPS | 
| Asia Pacific (Melbourne) | ap-southeast-4 |  acm-pca.ap-southeast-4.amazonaws.com <br /> acm-pca.ap-southeast-4.api.aws  | https<br />HTTPS | 
| Asia Pacific (Mumbai) | ap-south-1 |  acm-pca.ap-south-1.amazonaws.com <br /> acm-pca.ap-south-1.api.aws  | https<br />HTTPS | 
| Asia Pacific (New Zealand) | ap-southeast-6 |  acm-pca.ap-southeast-6.amazonaws.com <br /> acm-pca.ap-southeast-6.api.aws  | https<br />HTTPS | 
| Asia Pacific (Osaka) | ap-northeast-3 |  acm-pca.ap-northeast-3.amazonaws.com <br /> acm-pca.ap-northeast-3.api.aws  | https<br />HTTPS | 
| Asia Pacific (Seoul) | ap-northeast-2 |  acm-pca.ap-northeast-2.amazonaws.com <br /> acm-pca.ap-northeast-2.api.aws  | https<br />HTTPS | 
| Asia Pacific (Singapore) | ap-southeast-1 |  acm-pca.ap-southeast-1.amazonaws.com <br /> acm-pca.ap-southeast-1.api.aws  | https<br />HTTPS | 
| Asia Pacific (Sydney) | ap-southeast-2 |  acm-pca.ap-southeast-2.amazonaws.com <br /> acm-pca.ap-southeast-2.api.aws  | https<br />HTTPS | 
| Asia Pacific (Taipei) | ap-east-2 |  acm-pca.ap-east-2.amazonaws.com <br /> acm-pca.ap-east-2.api.aws  | https<br />HTTPS | 
| Asia Pacific (Thailand) | ap-southeast-7 |  acm-pca.ap-southeast-7.amazonaws.com <br /> acm-pca.ap-southeast-7.api.aws  | https<br />HTTPS | 
| Asia Pacific (Tokyo) | ap-northeast-1 |  acm-pca.ap-northeast-1.amazonaws.com <br /> acm-pca.ap-northeast-1.api.aws  | https<br />HTTPS | 
| Canada (Central) | ca-central-1 |  acm-pca.ca-central-1.amazonaws.com <br /> acm-pca-fips.ca-central-1.amazonaws.com <br /> acm-pca-fips.ca-central-1.api.aws <br /> acm-pca.ca-central-1.api.aws  | https<br />HTTPS<br />HTTPS<br />HTTPS | 
| Canada West (Calgary) | ca-west-1 |  acm-pca.ca-west-1.amazonaws.com <br /> acm-pca-fips.ca-west-1.amazonaws.com <br /> acm-pca-fips.ca-west-1.api.aws <br /> acm-pca.ca-west-1.api.aws  | https<br />HTTPS<br />HTTPS<br />HTTPS | 
| Europe (Frankfurt) | eu-central-1 |  acm-pca.eu-central-1.amazonaws.com <br /> acm-pca.eu-central-1.api.aws  | https<br />HTTPS | 
| Europe (Ireland) | eu-west-1 |  acm-pca.eu-west-1.amazonaws.com <br /> acm-pca.eu-west-1.api.aws  | https<br />HTTPS | 
| Europe (London) | eu-west-2 |  acm-pca.eu-west-2.amazonaws.com <br /> acm-pca.eu-west-2.api.aws  | https<br />HTTPS | 
| Europe (Milan) | eu-south-1 |  acm-pca.eu-south-1.amazonaws.com <br /> acm-pca.eu-south-1.api.aws  | https<br />HTTPS | 
| Europe (Paris) | eu-west-3 |  acm-pca.eu-west-3.amazonaws.com <br /> acm-pca.eu-west-3.api.aws  | https<br />HTTPS | 
| Europe (Spain) | eu-south-2 |  acm-pca.eu-south-2.amazonaws.com <br /> acm-pca.eu-south-2.api.aws  | https<br />HTTPS | 
| Europe (Stockholm) | eu-north-1 |  acm-pca.eu-north-1.amazonaws.com <br /> acm-pca.eu-north-1.api.aws  | https<br />HTTPS | 
| Europe (Zurich) | eu-central-2 |  acm-pca.eu-central-2.amazonaws.com <br /> acm-pca.eu-central-2.api.aws  | https<br />HTTPS | 
| Israel (Tel Aviv) | il-central-1 |  acm-pca.il-central-1.amazonaws.com <br /> acm-pca.il-central-1.api.aws  | https<br />HTTPS | 
| Mexico (Central) | mx-central-1 |  acm-pca.mx-central-1.amazonaws.com <br /> acm-pca.mx-central-1.api.aws  | https<br />HTTPS | 
| Middle East (Bahrain) | me-south-1 |  acm-pca.me-south-1.amazonaws.com <br /> acm-pca.me-south-1.api.aws  | https<br />HTTPS | 
| Middle East (UAE) | me-central-1 |  acm-pca.me-central-1.amazonaws.com <br /> acm-pca.me-central-1.api.aws  | https<br />HTTPS | 
| South America (São Paulo) | sa-east-1 |  acm-pca.sa-east-1.amazonaws.com <br /> acm-pca.sa-east-1.api.aws  | https<br />HTTPS | 
|  AWS GovCloud (US-East) | us-gov-east-1 |  acm-pca.us-gov-east-1.amazonaws.com <br /> acm-pca.us-gov-east-1.api.aws  | https<br />HTTPS | 
|  AWS GovCloud (US-West) | us-gov-west-1 |  acm-pca.us-gov-west-1.amazonaws.com <br /> acm-pca.us-gov-west-1.api.aws  | https<br />HTTPS | 

## AWS Private CA Connector for Active Directory endpoints
<a name="pca-connector-ad_region"></a>


| Region Name | Region | Endpoint | Protocol | 
| --- | --- | --- | --- | 
| US East (Ohio) | us-east-2 |  pca-connector-ad.us-east-2.amazonaws.com <br /> pca-connector-ad.us-east-2.api.aws  | HTTPS<br />HTTPS | 
| US East (N. Virginia) | us-east-1 |  pca-connector-ad.us-east-1.amazonaws.com <br /> pca-connector-ad.us-east-1.api.aws  | HTTPS<br />HTTPS | 
| US West (N. California) | us-west-1 |  pca-connector-ad.us-west-1.amazonaws.com <br /> pca-connector-ad.us-west-1.api.aws  | HTTPS<br />HTTPS | 
| US West (Oregon) | us-west-2 |  pca-connector-ad.us-west-2.amazonaws.com <br /> pca-connector-ad.us-west-2.api.aws  | HTTPS<br />HTTPS | 
| Africa (Cape Town) | af-south-1 |  pca-connector-ad.af-south-1.amazonaws.com <br /> pca-connector-ad.af-south-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Hong Kong) | ap-east-1 |  pca-connector-ad.ap-east-1.amazonaws.com <br /> pca-connector-ad.ap-east-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Hyderabad) | ap-south-2 |  pca-connector-ad.ap-south-2.amazonaws.com <br /> pca-connector-ad.ap-south-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Jakarta) | ap-southeast-3 |  pca-connector-ad.ap-southeast-3.amazonaws.com <br /> pca-connector-ad.ap-southeast-3.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Malaysia) | ap-southeast-5 |  pca-connector-ad.ap-southeast-5.amazonaws.com <br /> pca-connector-ad.ap-southeast-5.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Melbourne) | ap-southeast-4 |  pca-connector-ad.ap-southeast-4.amazonaws.com <br /> pca-connector-ad.ap-southeast-4.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Mumbai) | ap-south-1 |  pca-connector-ad.ap-south-1.amazonaws.com <br /> pca-connector-ad.ap-south-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (New Zealand) | ap-southeast-6 |  pca-connector-ad.ap-southeast-6.amazonaws.com <br /> pca-connector-ad.ap-southeast-6.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Osaka) | ap-northeast-3 |  pca-connector-ad.ap-northeast-3.amazonaws.com <br /> pca-connector-ad.ap-northeast-3.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Seoul) | ap-northeast-2 |  pca-connector-ad.ap-northeast-2.amazonaws.com <br /> pca-connector-ad.ap-northeast-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Singapore) | ap-southeast-1 |  pca-connector-ad.ap-southeast-1.amazonaws.com <br /> pca-connector-ad.ap-southeast-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Sydney) | ap-southeast-2 |  pca-connector-ad.ap-southeast-2.amazonaws.com <br /> pca-connector-ad.ap-southeast-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Taipei) | ap-east-2 |  pca-connector-ad.ap-east-2.amazonaws.com <br /> pca-connector-ad.ap-east-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Thailand) | ap-southeast-7 |  pca-connector-ad.ap-southeast-7.amazonaws.com <br /> pca-connector-ad.ap-southeast-7.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Tokyo) | ap-northeast-1 |  pca-connector-ad.ap-northeast-1.amazonaws.com <br /> pca-connector-ad.ap-northeast-1.api.aws  | HTTPS<br />HTTPS | 
| Canada (Central) | ca-central-1 |  pca-connector-ad.ca-central-1.amazonaws.com <br /> pca-connector-ad.ca-central-1.api.aws  | HTTPS<br />HTTPS | 
| Canada West (Calgary) | ca-west-1 |  pca-connector-ad.ca-west-1.amazonaws.com <br /> pca-connector-ad.ca-west-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Frankfurt) | eu-central-1 |  pca-connector-ad.eu-central-1.amazonaws.com <br /> pca-connector-ad.eu-central-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Ireland) | eu-west-1 |  pca-connector-ad.eu-west-1.amazonaws.com <br /> pca-connector-ad.eu-west-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (London) | eu-west-2 |  pca-connector-ad.eu-west-2.amazonaws.com <br /> pca-connector-ad.eu-west-2.api.aws  | HTTPS<br />HTTPS | 
| Europe (Milan) | eu-south-1 |  pca-connector-ad.eu-south-1.amazonaws.com <br /> pca-connector-ad.eu-south-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Paris) | eu-west-3 |  pca-connector-ad.eu-west-3.amazonaws.com <br /> pca-connector-ad.eu-west-3.api.aws  | HTTPS<br />HTTPS | 
| Europe (Spain) | eu-south-2 |  pca-connector-ad.eu-south-2.amazonaws.com <br /> pca-connector-ad.eu-south-2.api.aws  | HTTPS<br />HTTPS | 
| Europe (Stockholm) | eu-north-1 |  pca-connector-ad.eu-north-1.amazonaws.com <br /> pca-connector-ad.eu-north-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Zurich) | eu-central-2 |  pca-connector-ad.eu-central-2.amazonaws.com <br /> pca-connector-ad.eu-central-2.api.aws  | HTTPS<br />HTTPS | 
| Israel (Tel Aviv) | il-central-1 |  pca-connector-ad.il-central-1.amazonaws.com <br /> pca-connector-ad.il-central-1.api.aws  | HTTPS<br />HTTPS | 
| Mexico (Central) | mx-central-1 |  pca-connector-ad.mx-central-1.amazonaws.com <br /> pca-connector-ad.mx-central-1.api.aws  | HTTPS<br />HTTPS | 
| Middle East (Bahrain) | me-south-1 |  pca-connector-ad.me-south-1.amazonaws.com <br /> pca-connector-ad.me-south-1.api.aws  | HTTPS<br />HTTPS | 
| Middle East (UAE) | me-central-1 |  pca-connector-ad.me-central-1.amazonaws.com <br /> pca-connector-ad.me-central-1.api.aws  | HTTPS<br />HTTPS | 
| South America (São Paulo) | sa-east-1 |  pca-connector-ad.sa-east-1.amazonaws.com <br /> pca-connector-ad.sa-east-1.api.aws  | HTTPS<br />HTTPS | 
|  AWS GovCloud (US-East) | us-gov-east-1 |  pca-connector-ad.us-gov-east-1.amazonaws.com <br /> pca-connector-ad.us-gov-east-1.api.aws  | HTTPS<br />HTTPS | 
|  AWS GovCloud (US-West) | us-gov-west-1 |  pca-connector-ad.us-gov-west-1.amazonaws.com <br /> pca-connector-ad.us-gov-west-1.api.aws  | HTTPS<br />HTTPS | 

## AWS Private CA Connector for SCEP endpoints
<a name="pca-connector-scep_region"></a>


| Region Name | Region | Endpoint | Protocol | 
| --- | --- | --- | --- | 
| US East (Ohio) | us-east-2 |  pca-connector-scep.us-east-2.amazonaws.com <br /> pca-connector-scep.us-east-2.api.aws  | HTTPS<br />HTTPS | 
| US East (N. Virginia) | us-east-1 |  pca-connector-scep.us-east-1.amazonaws.com <br /> pca-connector-scep.us-east-1.api.aws  | HTTPS<br />HTTPS | 
| US West (N. California) | us-west-1 |  pca-connector-scep.us-west-1.amazonaws.com <br /> pca-connector-scep.us-west-1.api.aws  | HTTPS<br />HTTPS | 
| US West (Oregon) | us-west-2 |  pca-connector-scep.us-west-2.amazonaws.com <br /> pca-connector-scep.us-west-2.api.aws  | HTTPS<br />HTTPS | 
| Africa (Cape Town) | af-south-1 |  pca-connector-scep.af-south-1.amazonaws.com <br /> pca-connector-scep.af-south-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Hong Kong) | ap-east-1 |  pca-connector-scep.ap-east-1.amazonaws.com <br /> pca-connector-scep.ap-east-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Hyderabad) | ap-south-2 |  pca-connector-scep.ap-south-2.amazonaws.com <br /> pca-connector-scep.ap-south-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Jakarta) | ap-southeast-3 |  pca-connector-scep.ap-southeast-3.amazonaws.com <br /> pca-connector-scep.ap-southeast-3.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Malaysia) | ap-southeast-5 |  pca-connector-scep.ap-southeast-5.amazonaws.com <br /> pca-connector-scep.ap-southeast-5.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Melbourne) | ap-southeast-4 |  pca-connector-scep.ap-southeast-4.amazonaws.com <br /> pca-connector-scep.ap-southeast-4.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Mumbai) | ap-south-1 |  pca-connector-scep.ap-south-1.amazonaws.com <br /> pca-connector-scep.ap-south-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (New Zealand) | ap-southeast-6 |  pca-connector-scep.ap-southeast-6.amazonaws.com <br /> pca-connector-scep.ap-southeast-6.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Osaka) | ap-northeast-3 |  pca-connector-scep.ap-northeast-3.amazonaws.com <br /> pca-connector-scep.ap-northeast-3.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Seoul) | ap-northeast-2 |  pca-connector-scep.ap-northeast-2.amazonaws.com <br /> pca-connector-scep.ap-northeast-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Singapore) | ap-southeast-1 |  pca-connector-scep.ap-southeast-1.amazonaws.com <br /> pca-connector-scep.ap-southeast-1.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Sydney) | ap-southeast-2 |  pca-connector-scep.ap-southeast-2.amazonaws.com <br /> pca-connector-scep.ap-southeast-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Taipei) | ap-east-2 |  pca-connector-scep.ap-east-2.amazonaws.com <br /> pca-connector-scep.ap-east-2.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Thailand) | ap-southeast-7 |  pca-connector-scep.ap-southeast-7.amazonaws.com <br /> pca-connector-scep.ap-southeast-7.api.aws  | HTTPS<br />HTTPS | 
| Asia Pacific (Tokyo) | ap-northeast-1 |  pca-connector-scep.ap-northeast-1.amazonaws.com <br /> pca-connector-scep.ap-northeast-1.api.aws  | HTTPS<br />HTTPS | 
| Canada (Central) | ca-central-1 |  pca-connector-scep.ca-central-1.amazonaws.com <br /> pca-connector-scep.ca-central-1.api.aws  | HTTPS<br />HTTPS | 
| Canada West (Calgary) | ca-west-1 |  pca-connector-scep.ca-west-1.amazonaws.com <br /> pca-connector-scep.ca-west-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Frankfurt) | eu-central-1 |  pca-connector-scep.eu-central-1.amazonaws.com <br /> pca-connector-scep.eu-central-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Ireland) | eu-west-1 |  pca-connector-scep.eu-west-1.amazonaws.com <br /> pca-connector-scep.eu-west-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (London) | eu-west-2 |  pca-connector-scep.eu-west-2.amazonaws.com <br /> pca-connector-scep.eu-west-2.api.aws  | HTTPS<br />HTTPS | 
| Europe (Milan) | eu-south-1 |  pca-connector-scep.eu-south-1.amazonaws.com <br /> pca-connector-scep.eu-south-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Paris) | eu-west-3 |  pca-connector-scep.eu-west-3.amazonaws.com <br /> pca-connector-scep.eu-west-3.api.aws  | HTTPS<br />HTTPS | 
| Europe (Spain) | eu-south-2 |  pca-connector-scep.eu-south-2.amazonaws.com <br /> pca-connector-scep.eu-south-2.api.aws  | HTTPS<br />HTTPS | 
| Europe (Stockholm) | eu-north-1 |  pca-connector-scep.eu-north-1.amazonaws.com <br /> pca-connector-scep.eu-north-1.api.aws  | HTTPS<br />HTTPS | 
| Europe (Zurich) | eu-central-2 |  pca-connector-scep.eu-central-2.amazonaws.com <br /> pca-connector-scep.eu-central-2.api.aws  | HTTPS<br />HTTPS | 
| Israel (Tel Aviv) | il-central-1 |  pca-connector-scep.il-central-1.amazonaws.com <br /> pca-connector-scep.il-central-1.api.aws  | HTTPS<br />HTTPS | 
| Mexico (Central) | mx-central-1 |  pca-connector-scep.mx-central-1.amazonaws.com <br /> pca-connector-scep.mx-central-1.api.aws  | HTTPS<br />HTTPS | 
| Middle East (Bahrain) | me-south-1 |  pca-connector-scep.me-south-1.amazonaws.com <br /> pca-connector-scep.me-south-1.api.aws  | HTTPS<br />HTTPS | 
| Middle East (UAE) | me-central-1 |  pca-connector-scep.me-central-1.amazonaws.com <br /> pca-connector-scep.me-central-1.api.aws  | HTTPS<br />HTTPS | 
| South America (São Paulo) | sa-east-1 |  pca-connector-scep.sa-east-1.amazonaws.com <br /> pca-connector-scep.sa-east-1.api.aws  | HTTPS<br />HTTPS | 

## AWS Private CA quotas
<a name="limits_pca"></a>


| Name | Default | Adjustable | Description | 
| --- | --- | --- | --- | 
| Number of private certificate authorities | Each supported Region: 200 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/acm-pca/quotas/L-799883CD)  | The maximum number of private certificate authorities (CAs) that can be created in an account in the current Region. | 
| Number of private certificates for each CA | Each supported Region: 100,000,000 | No | The maximum number of private certificates that a certificate authority (CA) can issue in an account in the current Region. This quota applies when no revocation is enabled or revocation is enabled using partitioned CRL and/or OCSP. When complete CRL is enabled, the "Number of private certificates for each CA using complete CRLs" limit is applied. | 
| Number of private certificates for each CA using complete CRLs | Each supported Region: 1,000,000 | No | The maximum number of private certificates that a certificate authority (CA) can issue in an account in the current Region. This quota applies to CAs using complete CRLs. | 
| Number of revoked private certificates for each CA with complete CRLs enabled | Each supported Region: 1,000,000 | No | The maximum number of revoked, unexpired private certificates in an account in the current Region. This quota applies only to certificates issued when the CA had complete CRLs enabled. | 
| Rate of CreateCertificateAuthority requests | Each supported Region: 1 | No | The maximum number of CreateCertificateAuthority requests that can be performed in an account in the current Region each second. | 
| Rate of CreateCertificateAuthorityAuditReport requests | Each supported Region: 1 | No | The maximum number of CreateCertificateAuthorityAuditReport requests that can be performed in an account in the current Region each second. | 
| Rate of CreatePermission requests | Each supported Region: 1 | No | The maximum number of CreatePermission requests that can be performed in an account in the current Region each second. | 
| Rate of DeleteCertificateAuthority requests | Each supported Region: 10 | No | The maximum number of DeleteCertificateAuthority requests that can be performed in an account in the current Region each second. | 
| Rate of DeletePermission requests | Each supported Region: 1 | No | The maximum number of DeletePermission requests that can be performed in an account in the current Region each second. | 
| Rate of DeletePolicy requests | Each supported Region: 5 | No | The maximum number of DeletePolicy requests that can be performed in an account in the current Region each second. | 
| Rate of DescribeCertificateAuthority requests | Each supported Region: 20 | No | The maximum number of DescribeCertificateAuthority requests that can be performed in an account in the current Region each second. | 
| Rate of DescribeCertificateAuthorityAuditReport requests | Each supported Region: 20 | No | The maximum number of DescribeCertificateAuthorityAuditReport requests that can be performed in an account in the current Region each second. | 
| Rate of GetCertificate requests | Each supported Region: 75 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/acm-pca/quotas/L-1725E639)  | The maximum number of GetCertificate requests that can be performed in an account in the current Region each second. | 
| Rate of GetCertificateAuthorityCertificate requests | Each supported Region: 20 | No | The maximum number of GetCertificateAuthorityCertificate requests that can be performed in an account in the current Region each second. | 
| Rate of GetCertificateAuthorityCsr requests | Each supported Region: 10 | No | The maximum number of GetCertificateAuthorityCsr requests that can be performed in an account in the current Region each second. | 
| Rate of GetPolicy requests | Each supported Region: 5 | No | The maximum number of GetPolicy requests that can be performed in an account in the current Region each second. | 
| Rate of ImportCertificateAuthorityCertificate requests | Each supported Region: 10 | No | The maximum number of ImportCertificateAuthorityCertificate requests that can be performed in an account in the current Region each second. | 
| Rate of IssueCertificate requests | Each supported Region: 25 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/acm-pca/quotas/L-CAFB4993)  | The maximum number of IssueCertificate requests that can be performed in an account in the current Region each second. | 
| Rate of ListCertificateAuthorities requests | Each supported Region: 20 | No | The maximum number of ListCertificateAuthorities requests that can be performed in an account in the current Region each second. | 
| Rate of ListPermissions requests | Each supported Region: 5 | No | The maximum number of ListPermissions requests that can be performed in an account in the current Region each second. | 
| Rate of ListTags requests | Each supported Region: 20 | No | The maximum number of ListTags requests that can be performed in an account in the current Region each second. | 
| Rate of PutPolicy requests | Each supported Region: 5 | No | The maximum number of PutPolicy requests that can be performed in an account in the current Region each second. | 
| Rate of RestoreCertificateAuthority requests | Each supported Region: 20 | No | The maximum number of RestoreCertificateAuthority requests that can be performed in an account in the current Region each second. | 
| Rate of RevokeCertificate requests | Each supported Region: 20 | No | The maximum number of RevokeCertificate requests that can be performed in an account in the current Region each second. | 
| Rate of TagCertificateAuthority requests | Each supported Region: 10 | No | The maximum number of TagCertificateAuthority requests that can be performed in an account in the current Region each second. | 
| Rate of UntagCertificateAuthority requests | Each supported Region: 10 | No | The maximum number of UntagCertificateAuthority requests that can be performed in an account in the current Region each second. | 
| Rate of UpdateCertificateAuthority requests | Each supported Region: 10 | No | The maximum number of UpdateCertificateAuthority requests that can be performed in an account in the current Region each second. | 

## AWS Private CA Connector for Active Directory quotas
<a name="limits_pca-connector-ad"></a>


| Name | Default | Adjustable | Description | 
| --- | --- | --- | --- | 
| Number of connectors | Each supported Region: 10 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/pca-connector-ad/quotas/L-351D0DCC)  | The maximum number of connectors that you can create in this account in the current region. | 
| Number of group access control entries per template | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/pca-connector-ad/quotas/L-B2C010E5)  | The maximum number of group access control entries per template that you can create in this account in the current Region. | 
| Number of templates per connector | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/pca-connector-ad/quotas/L-FB47817C)  | The maximum number of templates per connector that you can create in this account in the current Region. | 
| Rate of CreateConnector requests | Each supported Region: 2 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/pca-connector-ad/quotas/L-7966F778)  | The maximum number of CreateConnector requests that you can perform in this account in the current region per second. | 
| Rate of CreateDirectoryRegistration requests | Each supported Region: 10 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/pca-connector-ad/quotas/L-17569A85)  | The maximum number of CreateDirectoryRegistration requests that you can perform in this account in the current region per second. | 
| Rate of CreateServicePrincipalName requests | Each supported Region: 10 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/pca-connector-ad/quotas/L-6930FFF8)  | The maximum number of CreateServicePrincipalName requests that you can perform in this account in the current region per second. | 
| Rate of CreateTemplate requests | Each supported Region: 10 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/pca-connector-ad/quotas/L-70E167AD)  | The maximum number of CreateTemplate requests that you can perform in this account in the current region per second. | 
| Rate of CreateTemplateGroupAccessControlEntry requests | Each supported Region: 10 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/pca-connector-ad/quotas/L-21A25C3F)  | The maximum number of CreateTemplateGroupAccessControlEntry requests that you can perform in this account in the current region per second. | 
| Rate of DeleteConnector requests | Each supported Region: 2 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/pca-connector-ad/quotas/L-01AB3861)  | The maximum number of DeleteConnector requests that you can perform in this account in the current region per second. | 
| Rate of DeleteDirectoryRegistration requests | Each supported Region: 5 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/pca-connector-ad/quotas/L-568BB718)  | The maximum number of DeleteDirectoryRegistration requests that you can perform in this account in the current region per second. | 
| Rate of DeleteServicePrincipalName requests | Each supported Region: 5 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/pca-connector-ad/quotas/L-8228CBB5)  | The maximum number of DeleteServicePrincipalName requests that you can perform in this account in the current region per second. | 
| Rate of DeleteTemplate requests | Each supported Region: 5 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/pca-connector-ad/quotas/L-1F0B4E70)  | The maximum number of DeleteTemplate requests that you can perform in this account in the current region per second. | 
| Rate of DeleteTemplateGroupAccessControlEntry requests | Each supported Region: 5 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/pca-connector-ad/quotas/L-853BCABE)  | The maximum number of DeleteTemplateGroupAccessControlEntry requests that you can perform in this account in the current region per second. | 
| Rate of GetConnector requests | Each supported Region: 50 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/pca-connector-ad/quotas/L-F6A7C5A2)  | The maximum number of GetConnector requests that you can perform in this account in the current region per second. | 
| Rate of GetDirectoryRegistration requests | Each supported Region: 50 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/pca-connector-ad/quotas/L-5CC72EAF)  | The maximum number of GetDirectoryRegistration requests that you can perform in this account in the current region per second. | 
| Rate of GetPolicies requests | Each supported Region: 10 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/pca-connector-ad/quotas/L-0916B3E3)  | The maximum number of GetPolicies requests that you can perform in this account in the current region per second. | 
| Rate of GetServicePrincipalName requests | Each supported Region: 50 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/pca-connector-ad/quotas/L-F16E91B4)  | The maximum number of GetServicePrincipalName requests that you can perform in this account in the current region per second. | 
| Rate of GetTemplate requests | Each supported Region: 50 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/pca-connector-ad/quotas/L-046630BB)  | The maximum number of GetTemplate requests that you can perform in this account in the current region per second. | 
| Rate of GetTemplateGroupAccessControlEntry requests | Each supported Region: 50 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/pca-connector-ad/quotas/L-A40E38B0)  | The maximum number of GetTemplateGroupAccessControlEntry requests that you can perform in this account in the current region per second. | 
| Rate of ListConnectors requests | Each supported Region: 50 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/pca-connector-ad/quotas/L-49BEA97B)  | The maximum number of ListConnectors requests that you can perform in this account in the current region per second. | 
| Rate of ListDirectoryRegistrations requests | Each supported Region: 50 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/pca-connector-ad/quotas/L-71CF09F7)  | The maximum number of ListDirectoryRegistrations requests that you can perform in this account in the current region per second. | 
| Rate of ListServicePrincipalNames requests | Each supported Region: 50 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/pca-connector-ad/quotas/L-8B0AFBB5)  | The maximum number of ListServicePrincipalNames requests that you can perform in this account in the current region per second. | 
| Rate of ListTagsForResource requests | Each supported Region: 50 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/pca-connector-ad/quotas/L-EE597D84)  | The maximum number of ListTagsForResource requests that you can perform in this account in the current region per second. | 
| Rate of ListTemplateGroupAccessControlEntries requests | Each supported Region: 50 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/pca-connector-ad/quotas/L-5512056E)  | The maximum number of ListTemplateGroupAccessControlEntries requests that you can perform in this account in the current region per second. | 
| Rate of ListTemplates requests | Each supported Region: 50 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/pca-connector-ad/quotas/L-7362C0AD)  | The maximum number of ListTemplates requests that you can perform in this account in the current region per second. | 
| Rate of RequestSecurityToken requests | Each supported Region: 10 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/pca-connector-ad/quotas/L-27D56743)  | The maximum number of RequestSecurityToken requests that you can perform in this account in the current region per second. | 
| Rate of TagResource requests | Each supported Region: 50 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/pca-connector-ad/quotas/L-957664CC)  | The maximum number of TagResource requests that you can perform in this account in the current region per second. | 
| Rate of UntagResource requests | Each supported Region: 50 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/pca-connector-ad/quotas/L-64E52FB9)  | The maximum number of UntagResource requests that you can perform in this account in the current region per second. | 
| Rate of UpdateTemplate requests | Each supported Region: 10 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/pca-connector-ad/quotas/L-431F19A0)  | The maximum number of UpdateTemplate requests that you can perform in this account in the current region per second. | 
| Rate of UpdateTemplateGroupAccessControlEntry requests | Each supported Region: 10 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/pca-connector-ad/quotas/L-657D5FD0)  | The maximum number of UpdateTemplateGroupAccessControlEntry requests that you can perform in this account in the current region per second. | 

## AWS Private CA Connector for SCEP quotas
<a name="limits_pca-connector-scep"></a>


| Name | Default | Adjustable | Description | 
| --- | --- | --- | --- | 
| Number of challenges per connector | Each supported Region: 5 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/pca-connector-scep/quotas/L-D42FC980)  | The maximum number of challenges per connector that you can create in this account in the current Region. | 
| Number of connectors | Each supported Region: 20 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/pca-connector-scep/quotas/L-CB21FAEA)  | The maximum number of connectors that you can create in this account in the current Region. | 
| Rate of CreateChallenge requests | Each supported Region: 5 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/pca-connector-scep/quotas/L-F76F0010)  | The maximum number of CreateChallenge requests per second that you can perform in this account in the current Region. | 
| Rate of CreateConnector requests | Each supported Region: 5 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/pca-connector-scep/quotas/L-7ED03DC7)  | The maximum number of CreateConnector requests per second that you can perform in this account in the current Region. | 
| Rate of DeleteChallenge requests | Each supported Region: 5 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/pca-connector-scep/quotas/L-35687899)  | The maximum number of DeleteChallenge requests per second that you can perform in this account in the current Region. | 
| Rate of DeleteConnector requests | Each supported Region: 5 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/pca-connector-scep/quotas/L-A87A2654)  | The maximum number of DeleteConnector requests per second that you can perform in this account in the current Region. | 
| Rate of GetCACaps requests | Each supported Region: 20 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/pca-connector-scep/quotas/L-456B57EC)  | The maximum number of GetCACaps requests per second that your connector can perform in the current Region. | 
| Rate of GetCACert requests | Each supported Region: 20 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/pca-connector-scep/quotas/L-5967BA28)  | The maximum number of GetCACert requests per second that your connector can perform in the current Region. | 
| Rate of GetChallengeMetadata requests | Each supported Region: 50 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/pca-connector-scep/quotas/L-2F85730F)  | The maximum number of GetChallengeMetadata requests per second that you can perform in this account in the current Region. | 
| Rate of GetChallengePassword requests | Each supported Region: 50 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/pca-connector-scep/quotas/L-32FCF930)  | The maximum number of GetChallengePassword requests per second that you can perform in this account in the current Region. | 
| Rate of GetConnector requests | Each supported Region: 50 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/pca-connector-scep/quotas/L-2A99D11A)  | The maximum number of GetConnector requests per second that you can perform in this account in the current Region. | 
| Rate of ListChallengeMetadata requests | Each supported Region: 50 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/pca-connector-scep/quotas/L-8450A20F)  | The maximum number of ListChallengeMetadata requests per second that you can perform in this account in the current Region. | 
| Rate of ListConnectors requests | Each supported Region: 50 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/pca-connector-scep/quotas/L-98EB5A5D)  | The maximum number of ListConnectors requests per second that you can perform in this account in the current Region. | 
| Rate of ListTagsForResource requests | Each supported Region: 50 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/pca-connector-scep/quotas/L-43C22268)  | The maximum number of ListTagsForResource requests per second that you can perform in this account in the current Region. | 
| Rate of PKCSReq requests | Each supported Region: 10 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/pca-connector-scep/quotas/L-A0B79F1B)  | The maximum number of PKCSReq requests per second that your connector can perform in the current Region. | 
| Rate of TagResource requests | Each supported Region: 50 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/pca-connector-scep/quotas/L-F4B10249)  | The maximum number of TagResource requests per second that you can perform in this account in the current Region. | 
| Rate of UntagResource requests | Each supported Region: 50 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/pca-connector-scep/quotas/L-F422750F)  | The maximum number of UntagResource requests per second that you can perform in this account in the current Region. | 