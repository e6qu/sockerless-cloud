

# Amazon CloudFront endpoints and quotas
<a name="cf_region"></a>

To connect programmatically to an AWS service, you use an endpoint. AWS services offer the following endpoint types in some or all of the AWS Regions that the service supports: IPv4 endpoints, dual-stack endpoints, and FIPS endpoints. Some services provide global endpoints. For more information, see [AWS service endpoints](rande.md).

Service quotas, also referred to as limits, are the maximum number of service resources or operations for your AWS account. For more information, see [AWS service quotas](aws_service_limits.md).

The following are the service endpoints and service quotas for this service.

## Service endpoints
<a name="cloudfront_region"></a>

### Amazon CloudFront
<a name="cf_region_cfront"></a>



- **US East (N. Virginia) Region**
  - **Region:** us-east-1
  - **Endpoint:** cloudfront.amazonaws.com<br />cloudfront-fips.amazonaws.com / **Protocol:** HTTPS<br />HTTPS / **Amazon Route 53 Hosted Zone ID\*:** `Z2FDTNDATAQYW2`
  - **Endpoint:** cloudfront.global.api.aws / **Protocol:** HTTPS / **Amazon Route 53 Hosted Zone ID\*:** `Z04532621ON9XYH9VV43R`
  - **Endpoint:** cloudfront-fips.global.api.aws / **Protocol:** HTTPS / **Amazon Route 53 Hosted Zone ID\*:** `Z0169911SZ2QDT2H6OC8`



### Amazon CloudFront KeyValueStore
<a name="cf_region_cfront_kvs"></a>

CloudFront KeyValueStore is a global service. Specify your AWS account ID for the endpoint. 


| Endpoint | Protocol | Amazon Route 53 Hosted Zone ID\* | 
| --- | --- | --- | 
| {{AWS account}}.cloudfront-kvs.global.api.aws | HTTPS | The root host zone is the following. Each customer endpoint has its own hosted zone.<br />`Z024645223JLTKL21A7KJ` | 

## Service quotas
<a name="limits_cloudfront"></a>


| Name | Default | Adjustable | Description | 
| --- | --- | --- | --- | 
| Alternate domain names (CNAMEs) per distribution | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-AAD4943E)  | The maximum number of alternate domain names (CNAMEs) per distribution. | 
| Anycast static IP lists per AWS account | Each supported Region: 0 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-6A19EDFD)  | The maximum number of Anycast static IP lists per AWS account. | 
| Cache behaviors per distribution | Each supported Region: 75 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-F432D044)  | The maximum number of cache behaviors per distribution. | 
| Cache policies per AWS account | Each supported Region: 20 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-7D134442)  | The maximum number of cache policies per AWS account. | 
| CloudFront Functions: Maximum number of distributions associated with a single function | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-435C8433)  | The maximum number of CloudFront distributions associated with a single CloudFront function. | 
| Connection attempts per origin | Each supported Region: 3 | No | The number of connection attempts per origin (1-3). | 
| Connection timeout per origin | Each supported Region: 10 Seconds | No | The connection timeout per origin (1-10 seconds). | 
| Continuous deployment policies per AWS account | Each supported Region: 20 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-20E1C672)  | The maximum number of continuous deployment policies that you can have for an AWS account. | 
| Cookies per cache policy | Each supported Region: 10 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-BEBABC60)  | The maximum number of cookies per cache policy. | 
| Cookies per origin request policy | Each supported Region: 10 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-68CBA03E)  | The maximum number of cookies per origin request policy. | 
| Custom headers per response headers policy | Each supported Region: 10 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-8FE99263)  | The maximum number of custom headers per response headers policy. | 
| Custom headers: maximum length of a header name | Each supported Region: 256 | No | The maximum length of a header name in characters. | 
| Custom headers: maximum length of a header value | Each supported Region: 1,783 | No | The maximum length of a header value in characters. | 
| Custom headers: maximum length of all header values and names combined | Each supported Region: 10,240 | No | The maximum length of all header values and names combined. | 
| Custom headers: maximum number of custom headers that you can configure CloudFront to add to origin requests | Each supported Region: 30 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-BE7788E4)  | The maximum number of custom headers that you can configure CloudFront to add to origin requests. | 
| Data transfer rate per distribution | Each supported Region: 150 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-0F1E9017)  | The maximum data transfer rate (in Gbps) per distribution. | 
| Distributions associated with a single key group | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-C19110C4)  | The maximum number of distributions associated with a single key group. | 
| Distributions associated with the same VPC origin | Each supported Region: 50 | No | The maximum number of distributions that can be associated with a single VPC origin. | 
| Distributions associated with the same cache policy | Each supported Region: 100 | No | The maximum number of distributions associated with the same cache policy. | 
| Distributions associated with the same origin access control | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-7E654D79)  | The maximum number of distributions that you can associate with an origin access control. | 
| Distributions associated with the same origin request policy | Each supported Region: 100 | No | The maximum number of distributions associated with the same origin request policy. | 
| Distributions associated with the same response headers policy | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-F5EED448)  | The maximum number of distributions that you can associate with the same response headers policy. | 
| Distributions per AWS account that you can create triggers for | Each supported Region: 500 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-D0C8D03A)  | The maximum number of distributions per AWS account that you can create triggers for. | 
| File invalidation: maximum number of active wildcard invalidations allowed | Each supported Region: 15 | No | The maximum number of active wildcard invalidations allowed. | 
| File invalidation: maximum number of files allowed in active invalidation requests, excluding wildcard invalidations | Each supported Region: 3,000 | No | The maximum number of files allowed in active invalidation requests, excluding wildcard invalidations. | 
| Function memory size (Viewer request and response event) | Each supported Region: 128 Megabytes | No | The maximum function memory size (in MB). (Viewer request and response event) | 
| Function timeout (Origin request and response event) | Each supported Region: 30 Seconds | No | The maximum function timeout (in seconds). (Origin request and response event) | 
| Function timeout for a viewer request and response event | Each supported Region: 5 Seconds | No | The maximum function timeout (in seconds). (Viewer request and response event) | 
| Headers per cache policy | Each supported Region: 10 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-4C99C1B4)  | The maximum number of headers per cache policy. | 
| Headers per origin request policy | Each supported Region: 10 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-C646B44B)  | The maximum number of headers per origin request policy. | 
| Keep-alive timeout for a custom origin associated with distribution | Each supported Region: 300 Seconds |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-7429AF8A)  | How long (in seconds) CloudFront tries to maintain a connection to your distributions custom origin after it gets the last packet of a response. | 
| Key groups associated with a single distribution | Each supported Region: 4 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-E7E9ACEB)  | The maximum number of key groups associated with a single distribution. | 
| Key groups per AWS account | Each supported Region: 10 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-D64DA6E2)  | The maximum number of key groups per AWS account. | 
| Length of the content security policy value in a response headers policy | Each supported Region: 1,783 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-E9944CCE)  | The maximum length of the content security policy value in a response headers policy. | 
| Maximum CA bundle size per trust store | Each supported Region: 64 Kilobytes |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-59F2769C)  | The maximum size (in KB) of a CA bundle that can be uploaded to a trust store. | 
| Maximum certificate size in trust store CA bundle | Each supported Region: 16 Kilobytes |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-E55DEA80)  | The maximum size (in KB) of an individual certificate within a trust stores CA bundle. | 
| Maximum compressed size of a Lambda function and any included libraries. (Origin request and response event) | Each supported Region: 50 Megabytes | No | The maximum compressed size (in MB) of a Lambda function and any included libraries. (Origin request and response event) | 
| Maximum compressed size of a Lambda function and any included libraries. (Viewer request and response event) | Each supported Region: 50 Megabytes | No | The maximum compressed size (in MB) of a Lambda function and any included libraries. (Viewer request and response event) | 
| Maximum file size for HTTP GET, POST, and PUT requests  | Each supported Region: 50 Gigabytes | No | The maximum file size (in GB) for HTTP GET, POST, and PUT requests. | 
| Maximum length of a URL | Each supported Region: 8,192 Bytes | No | The maximum length of a URL (in bytes). | 
| Maximum length of a field to encrypt | Each supported Region: 16 Kilobytes | No | The maximum length (in KB) of a field to encrypt. | 
| Maximum length of a request body when field-level encryption is configured | Each supported Region: 1 Megabytes | No | The maximum length (in MB) of a request body when field-level encryption is configured. | 
| Maximum length of a request, including headers and query strings, but not including the body content | Each supported Region: 20,480 Bytes | No | The maximum length of a request (in bytes), including headers and query strings, but not including the body content. | 
| Maximum number of CloudFront distributions that can be associated with a field-level encryption configuration | Each supported Region: 20 | No | The maximum number of CloudFront distributions that can be associated with a field-level encryption configuration. | 
| Maximum number of aliases per distribution tenant | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-6CCE0F1E)  | The maximum number of aliases that you can have for a distribution tenant. | 
| Maximum number of associations per web ACL | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-F5C19F1B)  | The maximum number of resources that can be associated with a single web ACL. | 
| Maximum number of certificates per trust store | Each supported Region: 25 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-061D6ADD)  | The maximum number of certificates that you can have for a trust store. | 
| Maximum number of characters in a whitelisted query string | Each supported Region: 128 | No | The maximum number of characters in a whitelisted query string. | 
| Maximum number of characters total for all whitelisted query strings in the same parameter | Each supported Region: 512 | No | The maximum number of characters total for all whitelisted query strings in the same parameter. | 
| Maximum number of connection functions per AWS account | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-D0422299)  | The maximum number of connection functions that you can have for an AWS account. | 
| Maximum number of connection groups per AWS account | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-4024A45A)  | The maximum number of connection groups that you can have for an AWS account. | 
| Maximum number of connection groups per Anycast static IP list | Each supported Region: 5 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-8AB980CD)  | The maximum number of connection groups that can be associated with the same Anycast static IP list. | 
| Maximum number of distribution tenants per AWS account | Each supported Region: 1,000,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-D2BD2B16)  | The maximum number of distribution tenants that you can have for an AWS account. | 
| Maximum number of distributions associated with the same trust store | Each supported Region: 300 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-3FC44142)  | The maximum number of distributions that can be associated with a single trust store. | 
| Maximum number of field-level encryption configurations that can be associated with one AWS account | Each supported Region: 10 | No | The maximum number of field-level encryption configurations that can be associated with one AWS account. | 
| Maximum number of field-level encryption profiles that can be associated with one AWS account | Each supported Region: 10 | No | The maximum number of field-level encryption profiles that can be associated with one AWS account. | 
| Maximum number of fields in a request body when field-level encryption is configured | Each supported Region: 10 | No | The maximum number of fields in a request body when field-level encryption is configured. | 
| Maximum number of fields to encrypt that can be specified in one profile | Each supported Region: 10 | No | The maximum number of fields to encrypt that can be specified in one profile. | 
| Maximum number of multi-tenant distributions per AWS account | Each supported Region: 500 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-0AB8CD5F)  | The maximum number of multi-tenant distributions that you can have for an AWS account. | 
| Maximum number of parameters in a field in a multi-tenant distribution | Each supported Region: 2 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-4B3F61D0)  | The maximum number of parameters that you can have in a field in a multi-tenant distribution. | 
| Maximum number of parameters per distribution tenant | Each supported Region: 5 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-B41C610F)  | The maximum number of parameters that you can have for a distribution tenant. | 
| Maximum number of parameters per multi-tenant distribution | Each supported Region: 5 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-7EA57369)  | The maximum number of parameters that you can have for a multi-tenant distribution. | 
| Maximum number of public keys that can be added to one AWS account | Each supported Region: 10 | No | The maximum number of public keys that can be added to one AWS account. | 
| Maximum number of query argument profile mappings that can be included in a field-level encryption configuration | Each supported Region: 5 | No | The maximum number of query argument profile mappings that can be included in a field-level encryption configuration. | 
| Maximum number of trust stores per AWS account | Each supported Region: 20 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-F6F30A7D)  | The maximum number of trust stores that you can have for an AWS account. | 
| Origin access identities per account | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-08884E5C)  | The maximum number of origin access identities per account. | 
| Origin groups per distribution | Each supported Region: 10 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-1B2BD627)  | The maximum number of origin groups per distribution. | 
| Origin request policies per AWS account | Each supported Region: 20 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-C3659C43)  | The maximum number of origin request policies per AWS account. | 
| Origin response timeout (idle timeout) | Each supported Region: 10 | No | The maximum origin response timeout (idle timeout) in minutes. If CloudFront hasn’t detected any bytes sent from the origin to the client within the past 10 minutes, the connection is assumed to be idle and is closed. | 
| Origins per distribution | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-B4048FB4)  | The maximum number of origins per distribution. | 
| Public keys in a single key group | Each supported Region: 5 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-9EBD26CA)  | The maximum number of public keys in a single key group. | 
| Query strings per cache policy | Each supported Region: 10 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-50C9D326)  | The maximum number of query strings per cache policy. | 
| Query strings per origin request policy | Each supported Region: 10 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-E47A582D)  | The maximum number of query strings per origin request policy. | 
| Range of file sizes that CloudFront compresses | Each supported Region: 10,000,000 Bytes | No | The range of file sizes (in bytes) that CloudFront compresses (1,000 to 10,000,000). | 
| Removing headers from a response headers policy | Each supported Region: 10 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-584BB4D4)  | The maximum number of headers that you can remove in a response headers policy. | 
| Request body size for origin requests exposed to a Lambda@Edge function. | Each supported Region: 1 Megabytes | No | The maximum request body size (in MB) for origin requests exposed to a Lambda@Edge function. | 
| Request body size for origin requests when returning from a Lambda function (base64 encoding) | Each supported Region: 1.33 Megabytes | No | The maximum request body size (in KB) for origin requests when returning from a Lambda function. (base64 encoding) | 
| Request body size for origin requests when returning from a Lambda function (text encoding) | Each supported Region: 1 Megabytes | No | The maximum request body size (in KB) for origin requests when returning from a Lambda function. (text encoding) | 
| Request body size for viewer requests exposed to a Lambda@Edge function. | Each supported Region: 40 Kilobytes | No | The maximum request body size (in KB) for viewer requests exposed to a Lambda@Edge function. | 
| Request body size for viewer requests when returning from a Lambda function (base64 encoding) | Each supported Region: 53.2 Kilobytes | No | The maximum request body size (in KB) for viewer requests when returning from a Lambda function. (base64 encoding) | 
| Request body size for viewer requests when returning from a Lambda function (text encoding) | Each supported Region: 40 Kilobytes | No | The maximum request body size (in KB) for viewer requests when returning from a Lambda function. (text encoding) | 
| Requests per second per distribution | Each supported Region: 250,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-A2C80159)  | The maximum number of requests per second per distribution. | 
| Response headers policies | Each supported Region: 20 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-CF0D4FC5)  | The maximum number of response headers policies per AWS account. | 
| Response timeout per origin | Each supported Region: 120 Seconds |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-AECE9FA7)  | The response timeout per origin (1-120 seconds). | 
| SSL certificates per AWS account when serving HTTPS requests using dedicated IP addresses | Each supported Region: 2 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-DA9DCC93)  | The maximum number of SSL certificates per AWS account when serving HTTPS requests using dedicated IP addresses (no quota when serving HTTPS requests using SNI). | 
| SSL certificates that can be associated with a CloudFront web distribution | Each supported Region: 1 | No | The maximum number of SSL certificates that can be associated with a CloudFront web distribution. | 
| Size of a response that is generated by a Lambda function, including headers and body (Origin request and response event) | Each supported Region: 1 Megabytes | No | The maximum size (in MB) of a response that is generated by a Lambda function, including headers and body. (Origin request and response event) | 
| Size of a response that is generated by a Lambda function, including headers and body (Viewer request and response event) | Each supported Region: 40 Kilobytes | No | The maximum size (in KB) of a response that is generated by a Lambda function, including headers and body. (Viewer request and response event) | 
| Staging distributions per AWS account | Each supported Region: 20 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-5336F3E6)  | The maximum number of staging distributions that you can have for an AWS account. | 
| Tags that can be added to a distribution | Each supported Region: 50 | No | The maximum number of tags that can be added to a distribution. | 
| Total length of the URI including query string in a Lambda@Edge function | Each supported Region: 8,192 | No | The maximum total length in characters of the URI including the query string in a Lambda@Edge function. | 
| Total number of bytes in whitelisted cookie names (doesn’t apply if you configure CloudFront to forward all cookies to the origin) | Each supported Region: 512 Bytes | No | The total number of bytes in whitelisted cookie names (doesn’t apply if you configure CloudFront to forward all cookies to the origin). 512 minus the number of whitelisted cookies. | 
| Triggers per distribution | Each supported Region: 100 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-C57D59CB)  | The maximum number of triggers per distribution. | 
| VPC origins per AWS account | Each supported Region: 25 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-A53701DE)  | The maximum number of VPC origins per AWS account. | 
| Web distributions per AWS account | Each supported Region: 500 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-24B04930)  | The maximum number of web distributions per AWS account. | 
| Whitelisted cookies per cache behavior | Each supported Region: 10 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-9D26CF6B)  | The maximum number of whitelisted cookies per cache behavior. | 
| Whitelisted headers per cache behavior | Each supported Region: 10 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-1685304C)  | The maximum number of whitelisted headers per cache behavior. | 
| Whitelisted query strings per cache behavior | Each supported Region: 10 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/cloudfront/quotas/L-779C7A0B)  | The maximum number of whitelisted query strings per cache behavior. | 

For more information, see [Quotas](https://docs.aws.amazon.com/AmazonCloudFront/latest/DeveloperGuide/cloudfront-limits.html) in the *Amazon CloudFront Developer Guide*.