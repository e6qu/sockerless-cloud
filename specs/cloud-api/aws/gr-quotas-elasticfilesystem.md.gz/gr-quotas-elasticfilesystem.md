

# Amazon Elastic File System endpoints and quotas
<a name="elasticfilesystem"></a>

To connect programmatically to an AWS service, you use an endpoint. AWS services offer the following endpoint types in some or all of the AWS Regions that the service supports: IPv4 endpoints, dual-stack endpoints, and FIPS endpoints. Some services provide global endpoints. For more information, see [AWS service endpoints](rande.md).

Service quotas, also referred to as limits, are the maximum number of service resources or operations for your AWS account. For more information, see [AWS service quotas](aws_service_limits.md).

The following are the service endpoints and service quotas for this service.

## Service endpoints
<a name="elasticfilesystem-region"></a>


| Region Name | Region | Endpoint | Protocol | 
| --- | --- | --- | --- | 
| US East (Ohio) | us-east-2 |  elasticfilesystem.us-east-2.amazonaws.com <br /> efs.us-east-2.api.aws <br /> efs-fips.us-east-2.api.aws <br /> elasticfilesystem-fips.us-east-2.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| US East (N. Virginia) | us-east-1 |  elasticfilesystem.us-east-1.amazonaws.com <br /> efs.us-east-1.api.aws <br /> efs-fips.us-east-1.api.aws <br /> elasticfilesystem-fips.us-east-1.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| US West (N. California) | us-west-1 |  elasticfilesystem.us-west-1.amazonaws.com <br /> efs.us-west-1.api.aws <br /> efs-fips.us-west-1.api.aws <br /> elasticfilesystem-fips.us-west-1.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| US West (Oregon) | us-west-2 |  elasticfilesystem.us-west-2.amazonaws.com <br /> efs.us-west-2.api.aws <br /> efs-fips.us-west-2.api.aws <br /> elasticfilesystem-fips.us-west-2.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Africa (Cape Town) | af-south-1 |  elasticfilesystem.af-south-1.amazonaws.com <br /> efs.af-south-1.api.aws <br /> efs-fips.af-south-1.api.aws <br /> elasticfilesystem-fips.af-south-1.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Asia Pacific (Hong Kong) | ap-east-1 |  elasticfilesystem.ap-east-1.amazonaws.com <br /> efs.ap-east-1.api.aws <br /> efs-fips.ap-east-1.api.aws <br /> elasticfilesystem-fips.ap-east-1.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Asia Pacific (Hyderabad) | ap-south-2 |  elasticfilesystem.ap-south-2.amazonaws.com <br /> efs.ap-south-2.api.aws <br /> efs-fips.ap-south-2.api.aws <br /> elasticfilesystem-fips.ap-south-2.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Asia Pacific (Jakarta) | ap-southeast-3 |  elasticfilesystem.ap-southeast-3.amazonaws.com <br /> efs.ap-southeast-3.api.aws <br /> efs-fips.ap-southeast-3.api.aws <br /> elasticfilesystem-fips.ap-southeast-3.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Asia Pacific (Malaysia) | ap-southeast-5 |  elasticfilesystem.ap-southeast-5.amazonaws.com <br /> efs.ap-southeast-5.api.aws <br /> efs-fips.ap-southeast-5.api.aws <br /> elasticfilesystem-fips.ap-southeast-5.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Asia Pacific (Melbourne) | ap-southeast-4 |  elasticfilesystem.ap-southeast-4.amazonaws.com <br /> efs.ap-southeast-4.api.aws <br /> efs-fips.ap-southeast-4.api.aws <br /> elasticfilesystem-fips.ap-southeast-4.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Asia Pacific (Mumbai) | ap-south-1 |  elasticfilesystem.ap-south-1.amazonaws.com <br /> efs.ap-south-1.api.aws <br /> efs-fips.ap-south-1.api.aws <br /> elasticfilesystem-fips.ap-south-1.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Asia Pacific (New Zealand) | ap-southeast-6 |  elasticfilesystem.ap-southeast-6.amazonaws.com <br /> efs.ap-southeast-6.api.aws <br /> efs-fips.ap-southeast-6.api.aws <br /> elasticfilesystem-fips.ap-southeast-6.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Asia Pacific (Osaka) | ap-northeast-3 |  elasticfilesystem.ap-northeast-3.amazonaws.com <br /> efs.ap-northeast-3.api.aws <br /> efs-fips.ap-northeast-3.api.aws <br /> elasticfilesystem-fips.ap-northeast-3.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Asia Pacific (Seoul) | ap-northeast-2 |  elasticfilesystem.ap-northeast-2.amazonaws.com <br /> efs.ap-northeast-2.api.aws <br /> efs-fips.ap-northeast-2.api.aws <br /> elasticfilesystem-fips.ap-northeast-2.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Asia Pacific (Singapore) | ap-southeast-1 |  elasticfilesystem.ap-southeast-1.amazonaws.com <br /> efs.ap-southeast-1.api.aws <br /> efs-fips.ap-southeast-1.api.aws <br /> elasticfilesystem-fips.ap-southeast-1.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Asia Pacific (Sydney) | ap-southeast-2 |  elasticfilesystem.ap-southeast-2.amazonaws.com <br /> efs.ap-southeast-2.api.aws <br /> efs-fips.ap-southeast-2.api.aws <br /> elasticfilesystem-fips.ap-southeast-2.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Asia Pacific (Taipei) | ap-east-2 |  elasticfilesystem.ap-east-2.amazonaws.com <br /> elasticfilesystem-fips.ap-east-2.amazonaws.com  | HTTPS<br />HTTPS | 
| Asia Pacific (Thailand) | ap-southeast-7 |  elasticfilesystem.ap-southeast-7.amazonaws.com <br /> efs.ap-southeast-7.api.aws <br /> efs-fips.ap-southeast-7.api.aws <br /> elasticfilesystem-fips.ap-southeast-7.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Asia Pacific (Tokyo) | ap-northeast-1 |  elasticfilesystem.ap-northeast-1.amazonaws.com <br /> efs.ap-northeast-1.api.aws <br /> efs-fips.ap-northeast-1.api.aws <br /> elasticfilesystem-fips.ap-northeast-1.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Canada (Central) | ca-central-1 |  elasticfilesystem.ca-central-1.amazonaws.com <br /> efs.ca-central-1.api.aws <br /> efs-fips.ca-central-1.api.aws <br /> elasticfilesystem-fips.ca-central-1.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Canada West (Calgary) | ca-west-1 |  elasticfilesystem.ca-west-1.amazonaws.com <br /> efs.ca-west-1.api.aws <br /> efs-fips.ca-west-1.api.aws <br /> elasticfilesystem-fips.ca-west-1.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Europe (Frankfurt) | eu-central-1 |  elasticfilesystem.eu-central-1.amazonaws.com <br /> efs.eu-central-1.api.aws <br /> efs-fips.eu-central-1.api.aws <br /> elasticfilesystem-fips.eu-central-1.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Europe (Ireland) | eu-west-1 |  elasticfilesystem.eu-west-1.amazonaws.com <br /> efs.eu-west-1.api.aws <br /> efs-fips.eu-west-1.api.aws <br /> elasticfilesystem-fips.eu-west-1.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Europe (London) | eu-west-2 |  elasticfilesystem.eu-west-2.amazonaws.com <br /> efs.eu-west-2.api.aws <br /> efs-fips.eu-west-2.api.aws <br /> elasticfilesystem-fips.eu-west-2.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Europe (Milan) | eu-south-1 |  elasticfilesystem.eu-south-1.amazonaws.com <br /> efs.eu-south-1.api.aws <br /> efs-fips.eu-south-1.api.aws <br /> elasticfilesystem-fips.eu-south-1.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Europe (Paris) | eu-west-3 |  elasticfilesystem.eu-west-3.amazonaws.com <br /> efs.eu-west-3.api.aws <br /> efs-fips.eu-west-3.api.aws <br /> elasticfilesystem-fips.eu-west-3.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Europe (Spain) | eu-south-2 |  elasticfilesystem.eu-south-2.amazonaws.com <br /> efs.eu-south-2.api.aws <br /> efs-fips.eu-south-2.api.aws <br /> elasticfilesystem-fips.eu-south-2.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Europe (Stockholm) | eu-north-1 |  elasticfilesystem.eu-north-1.amazonaws.com <br /> efs.eu-north-1.api.aws <br /> efs-fips.eu-north-1.api.aws <br /> elasticfilesystem-fips.eu-north-1.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Europe (Zurich) | eu-central-2 |  elasticfilesystem.eu-central-2.amazonaws.com <br /> efs.eu-central-2.api.aws <br /> efs-fips.eu-central-2.api.aws <br /> elasticfilesystem-fips.eu-central-2.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Israel (Tel Aviv) | il-central-1 |  elasticfilesystem.il-central-1.amazonaws.com <br /> efs.il-central-1.api.aws <br /> efs-fips.il-central-1.api.aws <br /> elasticfilesystem-fips.il-central-1.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Mexico (Central) | mx-central-1 |  elasticfilesystem.mx-central-1.amazonaws.com <br /> efs.mx-central-1.api.aws <br /> efs-fips.mx-central-1.api.aws <br /> elasticfilesystem-fips.mx-central-1.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Middle East (Bahrain) | me-south-1 |  elasticfilesystem.me-south-1.amazonaws.com <br /> efs.me-south-1.api.aws <br /> efs-fips.me-south-1.api.aws <br /> elasticfilesystem-fips.me-south-1.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| Middle East (UAE) | me-central-1 |  elasticfilesystem.me-central-1.amazonaws.com <br /> efs.me-central-1.api.aws <br /> efs-fips.me-central-1.api.aws <br /> elasticfilesystem-fips.me-central-1.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
| South America (São Paulo) | sa-east-1 |  elasticfilesystem.sa-east-1.amazonaws.com <br /> efs.sa-east-1.api.aws <br /> efs-fips.sa-east-1.api.aws <br /> elasticfilesystem-fips.sa-east-1.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
|  AWS GovCloud (US-East) | us-gov-east-1 |  elasticfilesystem.us-gov-east-1.amazonaws.com <br /> efs.us-gov-east-1.api.aws <br /> efs-fips.us-gov-east-1.api.aws <br /> elasticfilesystem-fips.us-gov-east-1.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 
|  AWS GovCloud (US-West) | us-gov-west-1 |  elasticfilesystem.us-gov-west-1.amazonaws.com <br /> efs.us-gov-west-1.api.aws <br /> efs-fips.us-gov-west-1.api.aws <br /> elasticfilesystem-fips.us-gov-west-1.amazonaws.com  | HTTPS<br />HTTPS<br />HTTPS<br />HTTPS | 

## Service quotas
<a name="limits_elasticfilesystem"></a>


| Name | Default | Adjustable | Description | 
| --- | --- | --- | --- | 
| Access points per file system | Each supported Region: 10,000 | No | The maximum number of access points allowed per file system | 
| Active users per NFS client | Each supported Region: 65,536 | No | The maximum number of active users that can have files open at the same time for each NFS client | 
| Bursting throughput | us-east-1: 3,072 Megabytes per second<br />us-east-2: 3,072 Megabytes per second<br />us-west-2: 3,072 Megabytes per second<br />ap-southeast-2: 3,072 Megabytes per second<br />eu-west-1: 3,072 Megabytes per second<br />Each of the other supported Regions: 1,024 Megabytes per second | No | The maximum total bursting throughput for all connected clients on an EFS file system | 
| Directory depth | Each supported Region: 1,000 | No | The maximum number of levels, or depth, that you can have within a single directory | 
| EFS file locks | Each supported Region: 512 | No | The maximum number of locks per file across all instances connected and users accessing the file | 
| File hard links | Each supported Region: 177 | No | The maximum number of hard links that you can have for each file | 
| File size | Each supported Region: 52,673,613,135,872 Bytes | No | The maximum size of a single file on an EFS file system | 
| File system name length | Each supported Region: 255 Bytes | No | The maximum length of a file system name | 
| File system symbolic link (symlink) length | Each supported Region: 4,080 Bytes | No | The maximum length that a file system symbolic link, or symlink, can be | 
| File systems per account | Each supported Region: 1,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/elasticfilesystem/quotas/L-848C634D)  | The maximum number of file systems that a customer account can have in an AWS Region | 
| Locks across unique file/process pairs | Each supported Region: 65,536 | No | The maximum number of locks that can occur at the same time for each unique mount on an NFS client, across all unique file/process pairs | 
| Maximum read IOPS per file system with Elastic throughput | Each supported Region: 250,000 |  [Yes](https://console.aws.amazon.com/servicequotas/home/services/elasticfilesystem/quotas/L-B34D07B4)  | The maximum read IOPS file systems using Elastic throughput can achieve. | 
| Minimum wait time between Provisioned Throughput decreases | Each supported Region: 86,400 Seconds | No | The minimum amount of time that you have to wait after decreasing the amount of Provisioned Throughput before you can decrease it again | 
| Minimum wait time between Throughput mode changes | Each supported Region: 86,400 Seconds | No | The minimum amount of time that you have to wait after changing the Throughput mode before you can change it again | 
| Mount targets per Availability Zone | Each supported Region: 1 | No | The maximum number of EFS mount targets that you can have in an Availability Zone | 
| Mount targets per VPC | Each supported Region: 1,400 | No | The maximum number of EFS mount targets allowed for each VPC | 
| Open files per NFS client | Each supported Region: 65,536 | No | The maximum number of files that can be open at the same time for each NFS client | 
| Provisioned throughput | us-east-1: 3,414 Megabytes per second<br />us-east-2: 3,414 Megabytes per second<br />us-west-2: 3,414 Megabytes per second<br />eu-west-1: 3,414 Megabytes per second<br />Each of the other supported Regions: 1,024 Megabytes per second | No | The maximum total provisioned throughput for all connected clients on an EFS file system | 
| Rate of file system operations | Each supported Region: 250,000 | No | The maximum number of file system operations per second, for all connected clients, on an EFS file system that is configured in General Purpose mode. Data or metadata read operations consume one file operation, and data or metadata write operations consume five file operations. | 
| Security groups per mount target | Each supported Region: 5 | No | The maximum number of security groups that you can apply to a single EFS mount target | 
| Tags | Each supported Region: 50 | No | The maximum number of tags that you can apply to an EFS file system | 
| Throughput per NFS client | Each supported Region: 1,500 Megabytes per second | No | The maximum throughput that you can drive for each NFS client connected to an EFS file system | 
| VPCs per file system | Each supported Region: 1 | No | The maximum number of VPCs that you can apply to an EFS file system | 

For more information, see [Amazon EFS quotas](https://docs.aws.amazon.com/efs/latest/ug/limits.html) in the *Amazon Elastic File System User Guide*.