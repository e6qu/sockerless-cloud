

# Transform logs during ingestion
<a name="CloudWatch-Logs-Transformation"></a>

With logs transformation and enrichment, you can normalize all your logs in a consistent and context-rich format at the time of ingestion into CloudWatch Logs. You can add structure to your logs by using pre-configured templates for common AWS services such as AWS WAF and Amazon Route 53, or build custom transformers with native parsers such as [Grok](CloudWatch-Logs-Transformation-Configurable.md#CloudWatch-Logs-Transformation-Grok). You can also rename existing attributes and add additional metadata to your logs such as account ID, and Region.

Log transformation helps simplify and shorten your log queries across your applications, and helps simplify creating alerts on your logs. This feature provides transformation for common log types with out-of-the-box transformation templates for major AWS log sources like VPC Flow logs, Route 53, and Amazon RDS for PostgreSQL. You can use pre-configured transformation templates or create custom transformers to suit your needs.

Log transformation helps you manage logs emitted from various sources that vary widely in format and attribute names.

After you create a transformer, ingested log events are converted and stored in a standard format. You can leverage these transformed logs to accelerate your analytics experience with the following features:
+ [Field indexes](CloudWatchLogs-Field-Indexing.md)
+ [CloudWatch Logs Insights discovered fields](CWL_AnalyzeLogData-discoverable-fields.md)
+ Flexibility in alarming using [metric filters](MonitoringLogData.md)
+ Forwarding via [subscription filters](Subscriptions.md)
+ Creating metric data from log events with [ Contributor Insights](https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/ContributorInsights.html), where you can choose to have the Contributor Insights rule evaluate log events either before or after they are transformed.

Transformations happen only during log ingestion. You can't transform log events that have already been ingested. Transformations are not reversible. Both original and transformed logs are stored in CloudWatch Logs with the same retention policy. Log transformation and enrichment capability is included in the existing Standard log class ingestion price. Log storage costs will be based on log size after transformation, which might exceed the original log volume.

**Important**  
After log events have been transformed, you must use CloudWatch Logs Insights queries to view the transformed versions of the logs. The [ GetLogEvents](https://docs.aws.amazon.com/AmazonCloudWatchLogs/latest/APIReference/API_GetLogEvents.html) and [ FilterLogEvents](https://docs.aws.amazon.com/AmazonCloudWatchLogs/latest/APIReference/API_FilterLogEvents.html) actions return only the original versions of the log events, before they were transformed.

**Important**  
Despite a single log event in PutLogEvents allowing upto 1MB, logs transformation can only handle log event of size less than 512kb. Any log events greather than 512kb will fail in transformation and emit an error. Total size of PutLogEvents can still go over 512kb.

In addition to transforming into different formats, you can also enrich your logs with additional context, such as account ID, Region, and keyword. These are extracted from the log group name and from static keywords.

Log transformation helps you with logs emitted from various sources that vary widely in format and attribute names.

Log transformation and enrichment is supported only for log groups in the Standard log class.

You can create transformers for individual log groups, and you can also create account-level transformers that apply to all or many log groups in your account. If a log group has a log group-level transformer, that transformer overrides any account-level transformer that would otherwise apply to that log group. 

**Topics**
+ [Create and manage log transformers](CloudWatch-Logs-Transformation-Create.md)
+ [Configurable parser-type processors](CloudWatch-Logs-Transformation-Configurable.md)
+ [Built-in processors for AWS vended logs](CloudWatch-Logs-Transformation-BuiltIn.md)
+ [String mutate processors](CloudWatch-Logs-Transformation-StringMutate.md)
+ [JSON mutate processors](CloudWatch-Logs-Transformation-JSONMutate.md)
+ [Datatype converter processors](CloudWatch-Logs-Transformation-Datatype.md)
+ [Transformation metrics and errors](Transformation-Errors-Metrics.md)