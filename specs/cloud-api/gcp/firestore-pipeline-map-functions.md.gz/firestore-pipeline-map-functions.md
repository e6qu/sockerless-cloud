# Map Functions Reference

<div class="devsite-article-body clearfix devsite-no-page-title">

# Map Functions Reference

## **Map Functions**

|                                       |                                                         |
|---------------------------------------|---------------------------------------------------------|
| Name                                  | Description                                             |
| [`MAP`](#map)                         | Constructs a map value from a series of key-value pairs |
| [`MAP_GET`](#map_get)                 | Returns the value in a map given a specified key        |
| [`MAP_SET`](#map_set)                 | Returns a copy of a map with a series of updated keys   |
| [`MAP_REMOVE`](#map_remove)           | Returns a copy of a map with a series of keys removed   |
| [`MAP_MERGE`](#map_merge)             | Merges a series of maps together.                       |
| [`CURRENT_CONTEXT`](#current_context) | Returns the current context as a map.                   |
| [`MAP_KEYS`](#map_keys)               | Returns an array of all keys in a map.                  |
| [`MAP_VALUES`](#map_values)           | Returns an array of all values in a map.                |
| [`MAP_ENTRIES`](#map_entries)         | Returns an array of key-value pairs of a map.           |

### MAP

**Syntax:**

<div>

</div>

``` devsite-click-to-copy
map(key: STRING, value: ANY, ...) -> MAP
```

**Description:**

Constructs a map from a series of key-value pairs.

### MAP_GET

**Syntax:**

<div>

</div>

``` devsite-click-to-copy
map_get(map: ANY, key: STRING) -> ANY
```

**Description:**

Returns the value in a map given a specified key. Returns an `ABSENT` value if the `key` does not exist in the map, or if the `map` argument is not a `MAP`.

<div class="ds-selector-tabs" ds-scope="lang">

<div class="section">

##### Node.js

<div>

</div>

``` devsite-click-to-copy
const result = await db.pipeline()
  .collection("books")
  .select(
    field("awards").mapGet("pulitzer").as("hasPulitzerAward")
  )
  .execute();test.firestore.js
```

</div>

<div class="section">

### <span class="two-line-tab"><span tab-label="modular API"></span>Web</span>

<div>

</div>

``` devsite-click-to-copy
const result = await execute(db.pipeline()
  .collection("books")
  .select(
    field("awards").mapGet("pulitzer").as("hasPulitzerAward")
  )
);test.firestore.js
```

</div>

<div class="section">

##### Swift

<div>

</div>

``` devsite-click-to-copy
let result = try await db.pipeline()
  .collection("books")
  .select([
    Field("awards").mapGet("pulitzer").as("hasPulitzerAward")
  ])
  .execute()PipelineSnippets.swift
```

</div>

<div class="section">

##### <span class="two-line-tab">Kotlin <span class="firebase-platform-label">Android</span></span>

<div>

</div>

``` devsite-click-to-copy
val result = db.pipeline()
    .collection("books")
    .select(
        field("awards").mapGet("pulitzer").alias("hasPulitzerAward")
    )
    .execute()DocSnippets.kt
```

</div>

<div class="section">

##### <span class="two-line-tab">Java <span class="firebase-platform-label">Android</span></span>

<div>

</div>

``` devsite-click-to-copy
Task<Pipeline.Snapshot> result = db.pipeline()
    .collection("books")
    .select(
        field("awards").mapGet("pulitzer").alias("hasPulitzerAward")
    )
    .execute();DocSnippets.java
```

</div>

<div class="section">

##### Python

<div>

</div>

``` devsite-click-to-copy
from google.cloud.firestore_v1.pipeline_expressions import Field

result = (
    client.pipeline()
    .collection("books")
    .select(Field.of("awards").map_get("pulitzer").as_("hasPulitzerAward"))
    .execute()
)firestore_pipelines.py
```

</div>

<div class="section">

##### Java

<div>

</div>

``` devsite-click-to-copy
Pipeline.Snapshot result =
    firestore
        .pipeline()
        .collection("books")
        .select(mapGet(field("awards"), "pulitzer").as("hasPulitzerAward"))
        .execute()
        .get();PipelineSnippets.java
```

</div>

<div class="section">

##### Go

<div>

</div>

``` devsite-click-to-copy
snapshot := client.Pipeline().
 Collection("books").
 Select(firestore.Fields(
     firestore.MapGet(firestore.FieldOf("awards"), "pulitzer").As("hasPulitzerAward"),
 )).
 Execute(ctx)pipeline_snippets_object.go
```

</div>

</div>

### MAP_SET

**Syntax:**

<div>

</div>

``` devsite-click-to-copy
map_set(map: MAP, key: STRING, value: ANY, ...) -> MAP
```

**Description:**

Returns a copy of the `map` value with its contents updated by a series of key-value pairs.

If the given resolves to an absent value, the associated key is removed from the map.

If the `map` argument is not a `MAP`, returns an absent value.

### MAP_REMOVE

**Syntax:**

<div>

</div>

``` devsite-click-to-copy
map_remove(map: MAP, key: STRING...) -> MAP
```

**Description:**

Returns a copy of the `map` value with a series of keys removed.

### MAP_MERGE

**Syntax:**

<div>

</div>

``` devsite-click-to-copy
map_merge(maps: MAP...) -> MAP
```

Merges the contents of 2 or more maps. If multiple maps have conflicting values, the last value is used.

### CURRENT_CONTEXT

**Syntax:**

<div>

</div>

``` devsite-click-to-copy
current_context() -> MAP
```

Returns a map consisting of all available fields in the current point of execution.

### MAP_KEYS

**Syntax:**

<div>

</div>

``` devsite-click-to-copy
map_keys(map: MAP) -> ARRAY<STRING>
```

**Description:**

Returns an array containing all keys of the `map` value.

### MAP_VALUES

**Syntax:**

<div>

</div>

``` devsite-click-to-copy
map_values(map: MAP) -> ARRAY<ANY>
```

**Description:**

Returns an array containing all values of the `map` value.

### MAP_ENTRIES

**Syntax:**

<div>

</div>

``` devsite-click-to-copy
map_entries(map: MAP) -> ARRAY<MAP>
```

**Description:**

Returns an array containing all key-value pairs in the `map` value.

Each key-value pair will be in the form of a map with two entries, `k` and `v`.

**Examples:**

| `map`                          | `map_entries(map)`                                        |
|:-------------------------------|:----------------------------------------------------------|
| {}                             | \[\]                                                      |
| {"foo" : 2L}                   | \[{"k": "foo", "v" : 2L}\]                                |
| {"foo" : "bar", "bar" : "foo"} | \[{"k": "foo", "v" : "bar" }, {"k" : "bar", "v": "foo"}\] |

## What's next

- See the [Pipeline Queries overview](/firestore/docs/pipeline/overview)

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
