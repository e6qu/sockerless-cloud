# Generic Functions Reference

<div class="devsite-article-body clearfix devsite-no-page-title">

# Generic Functions Reference

## **Generic Functions**

|                                         |                                                                            |
|-----------------------------------------|----------------------------------------------------------------------------|
| Name                                    | Description                                                                |
| [`CURRENT_DOCUMENT`](#current_document) | Returns the document currently being processed in the pipeline.            |
| [`CONCAT`](#concat)                     | Concatenates two or more values of same type.                              |
| [`LENGTH`](#length)                     | Calculates the length of a `String`, `Bytes`, `Array`, `Vector`, or `Map`. |
| [`REVERSE`](#reverse)                   | Reverses a `String`, `Bytes`, or `Array`.                                  |

### CURRENT_DOCUMENT

**Syntax:**

<div>

</div>

``` devsite-click-to-copy
current_document() -> MAP
```

**Description:**

Evaluates to a map that holds all fields defined in the current scope. This is useful when merging or aggregating multiple documents together or when wanting to dynamically inspect the field names in the document.

For example, to get a list of documents grouped by a field:

<div>

<div class="section">

### Node.js

<div>

</div>

``` devsite-click-to-copy
const cities = await db.pipeline()
  .collection("/restaurants")
  .aggregate({
    groups: [ field("location.state").as("state") ],
    accumulators: [ arrayAgg(currentDocument().as("restaurants")) ]
   })
  .execute();
```

</div>

</div>

### CONCAT

**Syntax:**

<div>

</div>

``` devsite-click-to-copy
concat[T <: STRING | BYTES | ARRAY](values:T ...) -> T
```

**Description:**

Concatenates two or more values of same type.

**Examples:**

| values                  | `concat(values)` |
|:------------------------|:-----------------|
| "abc", "def"            | "abcdef"         |
| \[1, 2\], \[3, 4\]      | \[1, 2, 3, 4\]   |
| b"abc", b"def"          | b"abcdef"        |
| "abc", \[1,2,3\], "ghi" | error            |
| \[1,2,3\]               | error            |
| "abc", null             | null             |

<div class="ds-selector-tabs" ds-scope="lang">

<div class="section">

##### Node.js

<div>

</div>

``` devsite-click-to-copy
concat(constant("Author ID: "), field("authorId"));test.firestore.js
```

</div>

<div class="section">

### <span class="two-line-tab"><span tab-label="modular API"></span>Web</span>

<div>

</div>

``` devsite-click-to-copy
concat(constant("Author ID: "), field("authorId"));test.firestore.js
```

</div>

<div class="section">

##### Swift

<div>

</div>

``` devsite-click-to-copy
let displayString = Constant("Author ID: ").concat([Field("authorId")])PipelineSnippets.swift
```

</div>

<div class="section">

##### <span class="two-line-tab">Kotlin <span class="firebase-platform-label">Android</span></span>

<div>

</div>

``` devsite-click-to-copy
val displayString = constant("Author ID: ").concat(field("authorId"))
DocSnippets.kt
```

</div>

<div class="section">

##### <span class="two-line-tab">Java <span class="firebase-platform-label">Android</span></span>

<div>

</div>

``` devsite-click-to-copy
Expression displayString = constant("Author ID: ").concat(field("authorId"));DocSnippets.java
```

</div>

<div class="section">

##### Python

<div>

</div>

``` devsite-click-to-copy
Constant.of("Author ID: ").concat(Field.of("authorId"))firestore_pipelines.py
```

</div>

</div>

### LENGTH

**Syntax:**

<div>

</div>

``` devsite-click-to-copy
length[T <: STRING | BYTES | ARRAY | VECTOR | MAP](value: T) -> INT64
```

**Description:**

Calculates the length of a `String`, `Bytes`, `Array`, `Vector`, or `Map` value.

**Examples:**

| value          | `length(value)` |
|:---------------|:----------------|
| "hello"        | 5               |
| \[1, 2, 3, 4\] | 4               |
| b"abcde"       | 5               |
| null           | null            |
| 1              | error           |

### REVERSE

**Syntax:**

<div>

</div>

``` devsite-click-to-copy
reverse[T <: STRING | BYTES | ARRAY](value: T) -> T
```

**Description:**

Reverses a `String`, `Bytes`, or `Array` value.

**Examples:**

| value       | `reverse(value)` |
|:------------|:-----------------|
| "hello"     | "olleh"          |
| \[1, 2, 3\] | \[3, 2, 1\]      |
| b"abc"      | b"cba"           |
| 23          | error            |
| null        | null             |

## What's next

- See the [Pipeline Queries overview](/firestore/docs/pipeline/overview)

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
