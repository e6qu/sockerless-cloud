# Cloud DNS roles and permissions

<div class="devsite-article-body clearfix">

This page lists the IAM roles and permissions for Cloud DNS. To search through all roles and permissions, see the [role and permission index](/iam/docs/roles-permissions).

## Cloud DNS roles

<div results-count-container="">

</div>

<table class="fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="50%">Role</th>
<th>Permissions</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td class="role-description"><h4 id="dns.admin" class="role-title add-link" data-text="DNS Administrator " tabindex="-1">DNS Administrator</h4>
<p>(<code translate="no" dir="ltr">roles/dns.admin</code>)</p>
<span class="role-description custom"> </span>
<p>Provides read-write access to all Cloud DNS resources.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Managed zone</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">compute.networks.get</code></p>
<p><code translate="no" dir="ltr">compute.networks.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">dns.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">dns.changes.create</code></li>
<li><code translate="no" dir="ltr">dns.changes.get</code></li>
<li><code translate="no" dir="ltr">dns.changes.list</code></li>
<li><code translate="no" dir="ltr">dns.dnsKeys.get</code></li>
<li><code translate="no" dir="ltr">dns.dnsKeys.list</code></li>
<li><code translate="no" dir="ltr">dns.gkeClusters.bindDNSResponsePolicy</code></li>
<li><code translate="no" dir="ltr">dns.gkeClusters.bindPrivateDNSZone</code></li>
<li><code translate="no" dir="ltr">dns.managedZoneOperations.get</code></li>
<li><code translate="no" dir="ltr">dns.managedZoneOperations.list</code></li>
<li><code translate="no" dir="ltr">dns.managedZones.create</code></li>
<li><code translate="no" dir="ltr">dns.managedZones.delete</code></li>
<li><code translate="no" dir="ltr">dns.managedZones.get</code></li>
<li><code translate="no" dir="ltr">dns.managedZones.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">dns.managedZones.list</code></li>
<li><code translate="no" dir="ltr">dns.managedZones.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">dns.managedZones.update</code></li>
<li><code translate="no" dir="ltr">dns.networks.bindDNSResponsePolicy</code></li>
<li><code translate="no" dir="ltr">dns.networks.bindPrivateDNSPolicy</code></li>
<li><code translate="no" dir="ltr">dns.networks.bindPrivateDNSZone</code></li>
<li><code translate="no" dir="ltr">dns.networks.targetWithPeeringZone</code></li>
<li><code translate="no" dir="ltr">dns.networks.useHealthSignals</code></li>
<li><code translate="no" dir="ltr">dns.policies.create</code></li>
<li><code translate="no" dir="ltr">dns.policies.createTagBinding</code></li>
<li><code translate="no" dir="ltr">dns.policies.delete</code></li>
<li><code translate="no" dir="ltr">dns.policies.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">dns.policies.get</code></li>
<li><code translate="no" dir="ltr">dns.policies.list</code></li>
<li><code translate="no" dir="ltr">dns.policies.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">dns.policies.listTagBindings</code></li>
<li><code translate="no" dir="ltr">dns.policies.update</code></li>
<li><code translate="no" dir="ltr">dns.projects.get</code></li>
<li><code translate="no" dir="ltr">dns.resourceRecordSets.create</code></li>
<li><code translate="no" dir="ltr">dns.resourceRecordSets.delete</code></li>
<li><code translate="no" dir="ltr">dns.resourceRecordSets.get</code></li>
<li><code translate="no" dir="ltr">dns.resourceRecordSets.list</code></li>
<li><code translate="no" dir="ltr">dns.resourceRecordSets.update</code></li>
<li><code translate="no" dir="ltr">dns.responsePolicies.create</code></li>
<li><code translate="no" dir="ltr">dns.responsePolicies.delete</code></li>
<li><code translate="no" dir="ltr">dns.responsePolicies.get</code></li>
<li><code translate="no" dir="ltr">dns.responsePolicies.list</code></li>
<li><code translate="no" dir="ltr">dns.responsePolicies.update</code></li>
<li><code translate="no" dir="ltr">dns.responsePolicyRules.create</code></li>
<li><code translate="no" dir="ltr">dns.responsePolicyRules.delete</code></li>
<li><code translate="no" dir="ltr">dns.responsePolicyRules.get</code></li>
<li><code translate="no" dir="ltr">dns.responsePolicyRules.list</code></li>
<li><code translate="no" dir="ltr">dns.responsePolicyRules.update</code></li>
</ul>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="dns.editor" class="role-title add-link" data-text="DNS Editor " tabindex="-1">DNS Editor</h4>
<p>(<code translate="no" dir="ltr">roles/dns.editor</code>)</p>
<span class="role-description"> </span>
<p>Editor role for DNS resources.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">compute.networks.get</code></p>
<p><code translate="no" dir="ltr">compute.networks.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">dns.changes.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">dns.changes.create</code></li>
<li><code translate="no" dir="ltr">dns.changes.get</code></li>
<li><code translate="no" dir="ltr">dns.changes.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">dns.dnsKeys.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">dns.dnsKeys.get</code></li>
<li><code translate="no" dir="ltr">dns.dnsKeys.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">dns.gkeClusters.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">dns.gkeClusters.bindDNSResponsePolicy</code></li>
<li><code translate="no" dir="ltr">dns.gkeClusters.bindPrivateDNSZone</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">dns.managedZoneOperations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">dns.managedZoneOperations.get</code></li>
<li><code translate="no" dir="ltr">dns.managedZoneOperations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">dns.managedZones.create</code></p>
<p><code translate="no" dir="ltr">dns.managedZones.delete</code></p>
<p><code translate="no" dir="ltr">dns.managedZones.get</code></p>
<p><code translate="no" dir="ltr">dns.managedZones.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dns.managedZones.list</code></p>
<p><code translate="no" dir="ltr">dns.managedZones.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">dns.networks.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">dns.networks.bindDNSResponsePolicy</code></li>
<li><code translate="no" dir="ltr">dns.networks.bindPrivateDNSPolicy</code></li>
<li><code translate="no" dir="ltr">dns.networks.bindPrivateDNSZone</code></li>
<li><code translate="no" dir="ltr">dns.networks.targetWithPeeringZone</code></li>
<li><code translate="no" dir="ltr">dns.networks.useHealthSignals</code></li>
</ul>
<p><code translate="no" dir="ltr">dns.policies.create</code></p>
<p><code translate="no" dir="ltr">dns.policies.delete</code></p>
<p><code translate="no" dir="ltr">dns.policies.get</code></p>
<p><code translate="no" dir="ltr">dns.policies.list</code></p>
<p><code translate="no" dir="ltr">dns.policies.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">dns.policies.listTagBindings</code></p>
<p><code translate="no" dir="ltr">dns.policies.update</code></p>
<p><code translate="no" dir="ltr">dns.projects.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">dns.resourceRecordSets.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">dns.resourceRecordSets.create</code></li>
<li><code translate="no" dir="ltr">dns.resourceRecordSets.delete</code></li>
<li><code translate="no" dir="ltr">dns.resourceRecordSets.get</code></li>
<li><code translate="no" dir="ltr">dns.resourceRecordSets.list</code></li>
<li><code translate="no" dir="ltr">dns.resourceRecordSets.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">dns.responsePolicies.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">dns.responsePolicies.create</code></li>
<li><code translate="no" dir="ltr">dns.responsePolicies.delete</code></li>
<li><code translate="no" dir="ltr">dns.responsePolicies.get</code></li>
<li><code translate="no" dir="ltr">dns.responsePolicies.list</code></li>
<li><code translate="no" dir="ltr">dns.responsePolicies.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">dns.responsePolicyRules.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">dns.responsePolicyRules.create</code></li>
<li><code translate="no" dir="ltr">dns.responsePolicyRules.delete</code></li>
<li><code translate="no" dir="ltr">dns.responsePolicyRules.get</code></li>
<li><code translate="no" dir="ltr">dns.responsePolicyRules.list</code></li>
<li><code translate="no" dir="ltr">dns.responsePolicyRules.update</code></li>
</ul>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="dns.viewer" class="role-title add-link" data-text="DNS Viewer " tabindex="-1">DNS Viewer</h4>
<p>(<code translate="no" dir="ltr">roles/dns.viewer</code>)</p>
<span class="role-description"> </span>
<p>Viewer role for DNS resources.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">compute.networks.get</code></p>
<p><code translate="no" dir="ltr">dns.changes.get</code></p>
<p><code translate="no" dir="ltr">dns.changes.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">dns.dnsKeys.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">dns.dnsKeys.get</code></li>
<li><code translate="no" dir="ltr">dns.dnsKeys.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">dns.managedZoneOperations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">dns.managedZoneOperations.get</code></li>
<li><code translate="no" dir="ltr">dns.managedZoneOperations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">dns.managedZones.get</code></p>
<p><code translate="no" dir="ltr">dns.managedZones.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dns.managedZones.list</code></p>
<p><code translate="no" dir="ltr">dns.policies.get</code></p>
<p><code translate="no" dir="ltr">dns.policies.list</code></p>
<p><code translate="no" dir="ltr">dns.policies.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">dns.policies.listTagBindings</code></p>
<p><code translate="no" dir="ltr">dns.projects.get</code></p>
<p><code translate="no" dir="ltr">dns.resourceRecordSets.get</code></p>
<p><code translate="no" dir="ltr">dns.resourceRecordSets.list</code></p>
<p><code translate="no" dir="ltr">dns.responsePolicies.get</code></p>
<p><code translate="no" dir="ltr">dns.responsePolicies.list</code></p>
<p><code translate="no" dir="ltr">dns.responsePolicyRules.get</code></p>
<p><code translate="no" dir="ltr">dns.responsePolicyRules.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="dns.peer" class="role-title add-link" data-text="DNS Peer " tabindex="-1">DNS Peer</h4>
<p>(<code translate="no" dir="ltr">roles/dns.peer</code>)</p>
<span class="role-description"> </span>
<p>Access to target networks with DNS peering zones</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">dns.networks.targetWithPeeringZone</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="dns.reader" class="role-title add-link" data-text="DNS Reader " tabindex="-1">DNS Reader</h4>
<p>(<code translate="no" dir="ltr">roles/dns.reader</code>)</p>
<span class="role-description custom"> </span>
<p>Provides read-only access to all Cloud DNS resources.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Managed zone</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">compute.networks.get</code></p>
<p><code translate="no" dir="ltr">dns.changes.get</code></p>
<p><code translate="no" dir="ltr">dns.changes.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">dns.dnsKeys.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">dns.dnsKeys.get</code></li>
<li><code translate="no" dir="ltr">dns.dnsKeys.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">dns.managedZoneOperations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">dns.managedZoneOperations.get</code></li>
<li><code translate="no" dir="ltr">dns.managedZoneOperations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">dns.managedZones.get</code></p>
<p><code translate="no" dir="ltr">dns.managedZones.list</code></p>
<p><code translate="no" dir="ltr">dns.policies.get</code></p>
<p><code translate="no" dir="ltr">dns.policies.list</code></p>
<p><code translate="no" dir="ltr">dns.policies.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">dns.policies.listTagBindings</code></p>
<p><code translate="no" dir="ltr">dns.projects.get</code></p>
<p><code translate="no" dir="ltr">dns.resourceRecordSets.get</code></p>
<p><code translate="no" dir="ltr">dns.resourceRecordSets.list</code></p>
<p><code translate="no" dir="ltr">dns.responsePolicies.get</code></p>
<p><code translate="no" dir="ltr">dns.responsePolicies.list</code></p>
<p><code translate="no" dir="ltr">dns.responsePolicyRules.get</code></p>
<p><code translate="no" dir="ltr">dns.responsePolicyRules.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
</tbody>
</table>

### Service agent roles

Service agent roles should only be granted to [service agents](/iam/docs/service-agents).

<div results-count-container="">

</div>

<table class="fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="50%">Role</th>
<th>Permissions</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td class="role-description"><h4 id="dns.serviceAgent" class="role-title add-link" data-text="Cloud DNS Service Agent " tabindex="-1">Cloud DNS Service Agent</h4>
<p>(<code translate="no" dir="ltr">roles/dns.serviceAgent</code>)</p>
<span class="role-description"> </span>
<p>Gives Cloud DNS Service Agent access to Cloud Platform resources.</p>
<strong>Warning:</strong> Do not grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.</td>
<td class="role-permissions"><p><code translate="no" dir="ltr">compute.addresses.create</code></p>
<p><code translate="no" dir="ltr">compute.addresses.createInternal</code></p>
<p><code translate="no" dir="ltr">compute.addresses.delete</code></p>
<p><code translate="no" dir="ltr">compute.addresses.deleteInternal</code></p>
<p><code translate="no" dir="ltr">compute.addresses.get</code></p>
<p><code translate="no" dir="ltr">compute.addresses.list</code></p>
<p><code translate="no" dir="ltr">compute.addresses.use</code></p>
<p><code translate="no" dir="ltr">compute.addresses.useInternal</code></p>
<p><code translate="no" dir="ltr">compute.globalNetworkEndpointGroups.attachNetworkEndpoints</code></p>
<p><code translate="no" dir="ltr">compute.globalNetworkEndpointGroups.create</code></p>
<p><code translate="no" dir="ltr">compute.globalNetworkEndpointGroups.delete</code></p>
<p><code translate="no" dir="ltr">compute.globalNetworkEndpointGroups.detachNetworkEndpoints</code></p>
<p><code translate="no" dir="ltr">compute.globalNetworkEndpointGroups.get</code></p>
<p><code translate="no" dir="ltr">compute.globalOperations.get</code></p>
<p><code translate="no" dir="ltr">compute.healthChecks.get</code></p>
<p><code translate="no" dir="ltr">compute.networks.get</code></p>
<p><code translate="no" dir="ltr">compute.networks.use</code></p>
<p><code translate="no" dir="ltr">compute.subnetworks.get</code></p>
<p><code translate="no" dir="ltr">compute.subnetworks.list</code></p>
<p><code translate="no" dir="ltr">compute.subnetworks.use</code></p></td>
</tr>
</tbody>
</table>

## Cloud DNS permissions

<div results-count-container="">

</div>

<table class="permissions-table fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="45%">Permission</th>
<th>Included in roles</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td><h4 id="dns.changes.create" class="permission-name add-link" data-text="dns.changes.create" tabindex="-1"><code translate="no" dir="ltr">dns.changes.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.admin">DNS Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.editor">DNS Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.serviceAgent">Cluster Director Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.serviceAgent">Cloud Managed Identities Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.serviceAgent">Managed Kafka Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/metastore#metastore.serviceAgent">Dataproc Metastore Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/metastore.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusterservicediscovery#multiclusterservicediscovery.serviceAgent">Multi-Cluster Service Discovery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusterservicediscovery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/networkconnectivity#networkconnectivity.serviceAgent">Network Connectivity Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/networkconnectivity.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/oci#oci.serviceAgent">Oracle Database@Google Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/oci.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/servicenetworking#servicenetworking.serviceAgent">Service Networking Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/servicenetworking.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.serviceAgent">VMware Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="dns.changes.get" class="permission-name add-link" data-text="dns.changes.get" tabindex="-1"><code translate="no" dir="ltr">dns.changes.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.admin">DNS Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.editor">DNS Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.viewer">DNS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.reader">DNS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.serviceAgent">Cluster Director Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.serviceAgent">Cloud Managed Identities Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/metastore#metastore.serviceAgent">Dataproc Metastore Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/metastore.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusterservicediscovery#multiclusterservicediscovery.serviceAgent">Multi-Cluster Service Discovery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusterservicediscovery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/oci#oci.serviceAgent">Oracle Database@Google Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/oci.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/servicenetworking#servicenetworking.serviceAgent">Service Networking Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/servicenetworking.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.serviceAgent">VMware Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="dns.changes.list" class="permission-name add-link" data-text="dns.changes.list" tabindex="-1"><code translate="no" dir="ltr">dns.changes.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.admin">DNS Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.editor">DNS Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.viewer">DNS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.reader">DNS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.serviceAgent">Cluster Director Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.serviceAgent">Cloud Managed Identities Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusterservicediscovery#multiclusterservicediscovery.serviceAgent">Multi-Cluster Service Discovery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusterservicediscovery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/oci#oci.serviceAgent">Oracle Database@Google Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/oci.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/servicenetworking#servicenetworking.serviceAgent">Service Networking Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/servicenetworking.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.serviceAgent">VMware Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="dns.dnsKeys.get" class="permission-name add-link" data-text="dns.dnsKeys.get" tabindex="-1"><code translate="no" dir="ltr">dns.dnsKeys.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.admin">DNS Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.editor">DNS Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.viewer">DNS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.reader">DNS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.serviceAgent">Cloud Managed Identities Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusterservicediscovery#multiclusterservicediscovery.serviceAgent">Multi-Cluster Service Discovery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusterservicediscovery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/oci#oci.serviceAgent">Oracle Database@Google Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/oci.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/servicenetworking#servicenetworking.serviceAgent">Service Networking Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/servicenetworking.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.serviceAgent">VMware Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="dns.dnsKeys.list" class="permission-name add-link" data-text="dns.dnsKeys.list" tabindex="-1"><code translate="no" dir="ltr">dns.dnsKeys.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.admin">DNS Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.editor">DNS Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.viewer">DNS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.reader">DNS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.serviceAgent">Cloud Managed Identities Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusterservicediscovery#multiclusterservicediscovery.serviceAgent">Multi-Cluster Service Discovery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusterservicediscovery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/oci#oci.serviceAgent">Oracle Database@Google Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/oci.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/servicenetworking#servicenetworking.serviceAgent">Service Networking Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/servicenetworking.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.serviceAgent">VMware Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="dns.gkeClusters.bindDNSResponsePolicy" class="permission-name add-link" data-text="dns.gkeClusters.bindDNSResponsePolicy" tabindex="-1"><code translate="no" dir="ltr">dns.gkeClusters.bindDNSResponsePolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.admin">DNS Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.editor">DNS Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusterservicediscovery#multiclusterservicediscovery.serviceAgent">Multi-Cluster Service Discovery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusterservicediscovery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/servicenetworking#servicenetworking.serviceAgent">Service Networking Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/servicenetworking.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.serviceAgent">VMware Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="dns.gkeClusters.bindPrivateDNSZone" class="permission-name add-link" data-text="dns.gkeClusters.bindPrivateDNSZone" tabindex="-1"><code translate="no" dir="ltr">dns.gkeClusters.bindPrivateDNSZone</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.admin">DNS Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.editor">DNS Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusterservicediscovery#multiclusterservicediscovery.serviceAgent">Multi-Cluster Service Discovery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusterservicediscovery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/servicenetworking#servicenetworking.serviceAgent">Service Networking Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/servicenetworking.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.serviceAgent">VMware Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="dns.managedZoneOperations.get" class="permission-name add-link" data-text="dns.managedZoneOperations.get" tabindex="-1"><code translate="no" dir="ltr">dns.managedZoneOperations.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.admin">DNS Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.editor">DNS Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.viewer">DNS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.reader">DNS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.serviceAgent">Cloud Managed Identities Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusterservicediscovery#multiclusterservicediscovery.serviceAgent">Multi-Cluster Service Discovery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusterservicediscovery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/networkconnectivity#networkconnectivity.serviceAgent">Network Connectivity Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/networkconnectivity.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/oci#oci.serviceAgent">Oracle Database@Google Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/oci.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/servicenetworking#servicenetworking.serviceAgent">Service Networking Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/servicenetworking.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.serviceAgent">VMware Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="dns.managedZoneOperations.list" class="permission-name add-link" data-text="dns.managedZoneOperations.list" tabindex="-1"><code translate="no" dir="ltr">dns.managedZoneOperations.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.admin">DNS Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.editor">DNS Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.viewer">DNS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.reader">DNS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.serviceAgent">Cloud Managed Identities Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusterservicediscovery#multiclusterservicediscovery.serviceAgent">Multi-Cluster Service Discovery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusterservicediscovery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/networkconnectivity#networkconnectivity.serviceAgent">Network Connectivity Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/networkconnectivity.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/oci#oci.serviceAgent">Oracle Database@Google Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/oci.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/servicenetworking#servicenetworking.serviceAgent">Service Networking Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/servicenetworking.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.serviceAgent">VMware Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="dns.managedZones.create" class="permission-name add-link" data-text="dns.managedZones.create" tabindex="-1"><code translate="no" dir="ltr">dns.managedZones.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.admin">DNS Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.editor">DNS Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.serviceAgent">Cluster Director Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.serviceAgent">Cloud Managed Identities Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.serviceAgent">Managed Kafka Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/metastore#metastore.serviceAgent">Dataproc Metastore Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/metastore.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusterservicediscovery#multiclusterservicediscovery.serviceAgent">Multi-Cluster Service Discovery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusterservicediscovery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/networkconnectivity#networkconnectivity.serviceAgent">Network Connectivity Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/networkconnectivity.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/oci#oci.serviceAgent">Oracle Database@Google Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/oci.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/servicenetworking#servicenetworking.serviceAgent">Service Networking Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/servicenetworking.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.serviceAgent">VMware Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="dns.managedZones.delete" class="permission-name add-link" data-text="dns.managedZones.delete" tabindex="-1"><code translate="no" dir="ltr">dns.managedZones.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.admin">DNS Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.editor">DNS Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.serviceAgent">Cluster Director Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.serviceAgent">Cloud Managed Identities Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.serviceAgent">Managed Kafka Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/metastore#metastore.serviceAgent">Dataproc Metastore Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/metastore.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusterservicediscovery#multiclusterservicediscovery.serviceAgent">Multi-Cluster Service Discovery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusterservicediscovery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/networkconnectivity#networkconnectivity.serviceAgent">Network Connectivity Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/networkconnectivity.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/oci#oci.serviceAgent">Oracle Database@Google Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/oci.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/servicenetworking#servicenetworking.serviceAgent">Service Networking Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/servicenetworking.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.serviceAgent">VMware Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="dns.managedZones.get" class="permission-name add-link" data-text="dns.managedZones.get" tabindex="-1"><code translate="no" dir="ltr">dns.managedZones.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.admin">DNS Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.editor">DNS Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.viewer">DNS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.sharedVpcAgent">Composer Shared VPC Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.sharedVpcAgent</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.reader">DNS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.serviceAgent">Cluster Director Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.sharedVpcServiceAgent">Cluster Director Shared VPC Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.sharedVpcServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.serviceAgent">Cloud Managed Identities Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/metastore#metastore.serviceAgent">Dataproc Metastore Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/metastore.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusterservicediscovery#multiclusterservicediscovery.serviceAgent">Multi-Cluster Service Discovery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusterservicediscovery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/networkconnectivity#networkconnectivity.serviceAgent">Network Connectivity Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/networkconnectivity.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/oci#oci.serviceAgent">Oracle Database@Google Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/oci.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/servicenetworking#servicenetworking.serviceAgent">Service Networking Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/servicenetworking.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.serviceAgent">VMware Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="dns.managedZones.getIamPolicy" class="permission-name add-link" data-text="dns.managedZones.getIamPolicy" tabindex="-1"><code translate="no" dir="ltr">dns.managedZones.getIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.admin">DNS Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.editor">DNS Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.viewer">DNS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusterservicediscovery#multiclusterservicediscovery.serviceAgent">Multi-Cluster Service Discovery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusterservicediscovery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/oci#oci.serviceAgent">Oracle Database@Google Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/oci.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/servicenetworking#servicenetworking.serviceAgent">Service Networking Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/servicenetworking.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.serviceAgent">VMware Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="dns.managedZones.list" class="permission-name add-link" data-text="dns.managedZones.list" tabindex="-1"><code translate="no" dir="ltr">dns.managedZones.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.admin">DNS Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.editor">DNS Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.viewer">DNS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.admin">Workload Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.sharedVpcAgent">Composer Shared VPC Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.sharedVpcAgent</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.reader">DNS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.deploymentAdmin">Workload Manager Deployment Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.deploymentAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.serviceAgent">Audit Manager Auditing Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.serviceAgent">Cloud Security Compliance Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.serviceAgent">Cluster Director Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.sharedVpcServiceAgent">Cluster Director Shared VPC Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.sharedVpcServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.serviceAgent">Cloud Managed Identities Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.serviceAgent">Managed Kafka Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/metastore#metastore.serviceAgent">Dataproc Metastore Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/metastore.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusterservicediscovery#multiclusterservicediscovery.serviceAgent">Multi-Cluster Service Discovery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusterservicediscovery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/networkconnectivity#networkconnectivity.serviceAgent">Network Connectivity Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/networkconnectivity.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/oci#oci.serviceAgent">Oracle Database@Google Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/oci.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.attackSurfaceManagementScannerServiceAgent">Attack Surface Management Scanner Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.attackSurfaceManagementScannerServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/servicenetworking#servicenetworking.serviceAgent">Service Networking Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/servicenetworking.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.serviceAgent">VMware Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="dns.managedZones.setIamPolicy" class="permission-name add-link" data-text="dns.managedZones.setIamPolicy" tabindex="-1"><code translate="no" dir="ltr">dns.managedZones.setIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.admin">DNS Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="dns.managedZones.update" class="permission-name add-link" data-text="dns.managedZones.update" tabindex="-1"><code translate="no" dir="ltr">dns.managedZones.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.admin">DNS Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.editor">DNS Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.serviceAgent">Cluster Director Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.serviceAgent">Cloud Managed Identities Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusterservicediscovery#multiclusterservicediscovery.serviceAgent">Multi-Cluster Service Discovery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusterservicediscovery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/networkconnectivity#networkconnectivity.serviceAgent">Network Connectivity Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/networkconnectivity.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/oci#oci.serviceAgent">Oracle Database@Google Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/oci.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/servicenetworking#servicenetworking.serviceAgent">Service Networking Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/servicenetworking.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.serviceAgent">VMware Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="dns.networks.bindDNSResponsePolicy" class="permission-name add-link" data-text="dns.networks.bindDNSResponsePolicy" tabindex="-1"><code translate="no" dir="ltr">dns.networks.bindDNSResponsePolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.admin">DNS Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.editor">DNS Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/container#container.hostServiceAgentUser">Kubernetes Engine Host Service Agent User</a> (<code class="role-name" translate="no" dir="ltr">roles/container.hostServiceAgentUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusterservicediscovery#multiclusterservicediscovery.serviceAgent">Multi-Cluster Service Discovery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusterservicediscovery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/oci#oci.serviceAgent">Oracle Database@Google Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/oci.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/servicenetworking#servicenetworking.serviceAgent">Service Networking Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/servicenetworking.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.serviceAgent">VMware Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="dns.networks.bindPrivateDNSPolicy" class="permission-name add-link" data-text="dns.networks.bindPrivateDNSPolicy" tabindex="-1"><code translate="no" dir="ltr">dns.networks.bindPrivateDNSPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.admin">DNS Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.editor">DNS Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/container#container.hostServiceAgentUser">Kubernetes Engine Host Service Agent User</a> (<code class="role-name" translate="no" dir="ltr">roles/container.hostServiceAgentUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.serviceAgent">Cloud Managed Identities Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusterservicediscovery#multiclusterservicediscovery.serviceAgent">Multi-Cluster Service Discovery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusterservicediscovery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/oci#oci.serviceAgent">Oracle Database@Google Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/oci.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/servicenetworking#servicenetworking.serviceAgent">Service Networking Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/servicenetworking.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.serviceAgent">VMware Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="dns.networks.bindPrivateDNSZone" class="permission-name add-link" data-text="dns.networks.bindPrivateDNSZone" tabindex="-1"><code translate="no" dir="ltr">dns.networks.bindPrivateDNSZone</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.admin">DNS Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.editor">DNS Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/container#container.hostServiceAgentUser">Kubernetes Engine Host Service Agent User</a> (<code class="role-name" translate="no" dir="ltr">roles/container.hostServiceAgentUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.serviceAgent">Cluster Director Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.sharedVpcServiceAgent">Cluster Director Shared VPC Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.sharedVpcServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.serviceAgent">Cloud Managed Identities Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.serviceAgent">Managed Kafka Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/metastore#metastore.serviceAgent">Dataproc Metastore Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/metastore.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusterservicediscovery#multiclusterservicediscovery.serviceAgent">Multi-Cluster Service Discovery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusterservicediscovery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/networkconnectivity#networkconnectivity.serviceAgent">Network Connectivity Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/networkconnectivity.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/oci#oci.serviceAgent">Oracle Database@Google Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/oci.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/servicenetworking#servicenetworking.serviceAgent">Service Networking Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/servicenetworking.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.serviceAgent">VMware Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/workstations#workstations.serviceAgent">Workstations Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/workstations.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="dns.networks.targetWithPeeringZone" class="permission-name add-link" data-text="dns.networks.targetWithPeeringZone" tabindex="-1"><code translate="no" dir="ltr">dns.networks.targetWithPeeringZone</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.admin">DNS Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.editor">DNS Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.sharedVpcAgent">Composer Shared VPC Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.sharedVpcAgent</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.peer">DNS Peer</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.peer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/agentgateway#agentgateway.serviceAgent">Agent Gateway Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/agentgateway.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/eventarc#eventarc.serviceAgent">Eventarc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/eventarc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.serviceAgent">Cluster Director Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.sharedVpcServiceAgent">Cluster Director Shared VPC Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.sharedVpcServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/managedflink#managedflink.serviceAgent">Managed Flink Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/managedflink.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.serviceAgent">Managed Kafka Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/metastore#metastore.serviceAgent">Dataproc Metastore Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/metastore.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusterservicediscovery#multiclusterservicediscovery.serviceAgent">Multi-Cluster Service Discovery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusterservicediscovery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/oci#oci.serviceAgent">Oracle Database@Google Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/oci.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/servicenetworking#servicenetworking.serviceAgent">Service Networking Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/servicenetworking.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.serviceAgent">VMware Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/workstations#workstations.serviceAgent">Workstations Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/workstations.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="dns.networks.useHealthSignals" class="permission-name add-link" data-text="dns.networks.useHealthSignals" tabindex="-1"><code translate="no" dir="ltr">dns.networks.useHealthSignals</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.admin">DNS Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.editor">DNS Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusterservicediscovery#multiclusterservicediscovery.serviceAgent">Multi-Cluster Service Discovery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusterservicediscovery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/oci#oci.serviceAgent">Oracle Database@Google Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/oci.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/servicenetworking#servicenetworking.serviceAgent">Service Networking Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/servicenetworking.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.serviceAgent">VMware Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="dns.policies.create" class="permission-name add-link" data-text="dns.policies.create" tabindex="-1"><code translate="no" dir="ltr">dns.policies.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.admin">DNS Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.editor">DNS Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.serviceAgent">Cloud Managed Identities Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusterservicediscovery#multiclusterservicediscovery.serviceAgent">Multi-Cluster Service Discovery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusterservicediscovery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/oci#oci.serviceAgent">Oracle Database@Google Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/oci.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/servicenetworking#servicenetworking.serviceAgent">Service Networking Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/servicenetworking.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.serviceAgent">VMware Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="dns.policies.createTagBinding" class="permission-name add-link" data-text="dns.policies.createTagBinding" tabindex="-1"><code translate="no" dir="ltr">dns.policies.createTagBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.admin">DNS Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="dns.policies.delete" class="permission-name add-link" data-text="dns.policies.delete" tabindex="-1"><code translate="no" dir="ltr">dns.policies.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.admin">DNS Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.editor">DNS Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.serviceAgent">Cloud Managed Identities Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusterservicediscovery#multiclusterservicediscovery.serviceAgent">Multi-Cluster Service Discovery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusterservicediscovery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/oci#oci.serviceAgent">Oracle Database@Google Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/oci.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/servicenetworking#servicenetworking.serviceAgent">Service Networking Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/servicenetworking.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.serviceAgent">VMware Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="dns.policies.deleteTagBinding" class="permission-name add-link" data-text="dns.policies.deleteTagBinding" tabindex="-1"><code translate="no" dir="ltr">dns.policies.deleteTagBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.admin">DNS Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="dns.policies.get" class="permission-name add-link" data-text="dns.policies.get" tabindex="-1"><code translate="no" dir="ltr">dns.policies.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.admin">DNS Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.editor">DNS Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.viewer">DNS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.reader">DNS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.serviceAgent">Cloud Managed Identities Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusterservicediscovery#multiclusterservicediscovery.serviceAgent">Multi-Cluster Service Discovery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusterservicediscovery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/oci#oci.serviceAgent">Oracle Database@Google Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/oci.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/servicenetworking#servicenetworking.serviceAgent">Service Networking Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/servicenetworking.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.serviceAgent">VMware Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="dns.policies.list" class="permission-name add-link" data-text="dns.policies.list" tabindex="-1"><code translate="no" dir="ltr">dns.policies.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.admin">DNS Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.editor">DNS Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.viewer">DNS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.reader">DNS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.serviceAgent">Cloud Managed Identities Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusterservicediscovery#multiclusterservicediscovery.serviceAgent">Multi-Cluster Service Discovery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusterservicediscovery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/oci#oci.serviceAgent">Oracle Database@Google Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/oci.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/servicenetworking#servicenetworking.serviceAgent">Service Networking Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/servicenetworking.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.serviceAgent">VMware Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="dns.policies.listEffectiveTags" class="permission-name add-link" data-text="dns.policies.listEffectiveTags" tabindex="-1"><code translate="no" dir="ltr">dns.policies.listEffectiveTags</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.admin">DNS Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.editor">DNS Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.viewer">DNS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagViewer">Tag Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.reader">DNS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusterservicediscovery#multiclusterservicediscovery.serviceAgent">Multi-Cluster Service Discovery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusterservicediscovery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/oci#oci.serviceAgent">Oracle Database@Google Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/oci.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/servicenetworking#servicenetworking.serviceAgent">Service Networking Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/servicenetworking.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.serviceAgent">VMware Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="dns.policies.listTagBindings" class="permission-name add-link" data-text="dns.policies.listTagBindings" tabindex="-1"><code translate="no" dir="ltr">dns.policies.listTagBindings</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.admin">DNS Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.editor">DNS Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.viewer">DNS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagViewer">Tag Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.reader">DNS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusterservicediscovery#multiclusterservicediscovery.serviceAgent">Multi-Cluster Service Discovery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusterservicediscovery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/oci#oci.serviceAgent">Oracle Database@Google Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/oci.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/servicenetworking#servicenetworking.serviceAgent">Service Networking Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/servicenetworking.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.serviceAgent">VMware Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="dns.policies.update" class="permission-name add-link" data-text="dns.policies.update" tabindex="-1"><code translate="no" dir="ltr">dns.policies.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.admin">DNS Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.editor">DNS Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.serviceAgent">Cloud Managed Identities Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusterservicediscovery#multiclusterservicediscovery.serviceAgent">Multi-Cluster Service Discovery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusterservicediscovery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/oci#oci.serviceAgent">Oracle Database@Google Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/oci.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/servicenetworking#servicenetworking.serviceAgent">Service Networking Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/servicenetworking.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.serviceAgent">VMware Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="dns.projects.get" class="permission-name add-link" data-text="dns.projects.get" tabindex="-1"><code translate="no" dir="ltr">dns.projects.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.admin">DNS Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.editor">DNS Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.viewer">DNS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.reader">DNS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.serviceAgent">Cloud Managed Identities Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusterservicediscovery#multiclusterservicediscovery.serviceAgent">Multi-Cluster Service Discovery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusterservicediscovery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/oci#oci.serviceAgent">Oracle Database@Google Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/oci.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/servicenetworking#servicenetworking.serviceAgent">Service Networking Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/servicenetworking.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.serviceAgent">VMware Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="dns.resourceRecordSets.create" class="permission-name add-link" data-text="dns.resourceRecordSets.create" tabindex="-1"><code translate="no" dir="ltr">dns.resourceRecordSets.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.admin">DNS Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.editor">DNS Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.serviceAgent">Cluster Director Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.serviceAgent">Cloud Managed Identities Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.serviceAgent">Managed Kafka Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/metastore#metastore.serviceAgent">Dataproc Metastore Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/metastore.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusterservicediscovery#multiclusterservicediscovery.serviceAgent">Multi-Cluster Service Discovery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusterservicediscovery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/networkconnectivity#networkconnectivity.serviceAgent">Network Connectivity Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/networkconnectivity.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/oci#oci.serviceAgent">Oracle Database@Google Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/oci.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/servicenetworking#servicenetworking.serviceAgent">Service Networking Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/servicenetworking.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.serviceAgent">VMware Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="dns.resourceRecordSets.delete" class="permission-name add-link" data-text="dns.resourceRecordSets.delete" tabindex="-1"><code translate="no" dir="ltr">dns.resourceRecordSets.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.admin">DNS Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.editor">DNS Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.serviceAgent">Cluster Director Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.serviceAgent">Cloud Managed Identities Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.serviceAgent">Managed Kafka Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/metastore#metastore.serviceAgent">Dataproc Metastore Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/metastore.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusterservicediscovery#multiclusterservicediscovery.serviceAgent">Multi-Cluster Service Discovery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusterservicediscovery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/networkconnectivity#networkconnectivity.serviceAgent">Network Connectivity Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/networkconnectivity.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/oci#oci.serviceAgent">Oracle Database@Google Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/oci.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/servicenetworking#servicenetworking.serviceAgent">Service Networking Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/servicenetworking.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.serviceAgent">VMware Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="dns.resourceRecordSets.get" class="permission-name add-link" data-text="dns.resourceRecordSets.get" tabindex="-1"><code translate="no" dir="ltr">dns.resourceRecordSets.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.admin">DNS Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.editor">DNS Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.viewer">DNS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.reader">DNS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.serviceAgent">Cluster Director Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.serviceAgent">Cloud Managed Identities Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/metastore#metastore.serviceAgent">Dataproc Metastore Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/metastore.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusterservicediscovery#multiclusterservicediscovery.serviceAgent">Multi-Cluster Service Discovery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusterservicediscovery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/networkconnectivity#networkconnectivity.serviceAgent">Network Connectivity Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/networkconnectivity.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/oci#oci.serviceAgent">Oracle Database@Google Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/oci.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/servicenetworking#servicenetworking.serviceAgent">Service Networking Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/servicenetworking.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.serviceAgent">VMware Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="dns.resourceRecordSets.list" class="permission-name add-link" data-text="dns.resourceRecordSets.list" tabindex="-1"><code translate="no" dir="ltr">dns.resourceRecordSets.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.admin">DNS Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.editor">DNS Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.viewer">DNS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.reader">DNS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.serviceAgent">Cluster Director Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.serviceAgent">Cloud Managed Identities Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.serviceAgent">Managed Kafka Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/metastore#metastore.serviceAgent">Dataproc Metastore Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/metastore.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusterservicediscovery#multiclusterservicediscovery.serviceAgent">Multi-Cluster Service Discovery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusterservicediscovery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/networkconnectivity#networkconnectivity.serviceAgent">Network Connectivity Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/networkconnectivity.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/oci#oci.serviceAgent">Oracle Database@Google Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/oci.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.attackSurfaceManagementScannerServiceAgent">Attack Surface Management Scanner Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.attackSurfaceManagementScannerServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/servicenetworking#servicenetworking.serviceAgent">Service Networking Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/servicenetworking.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.serviceAgent">VMware Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="dns.resourceRecordSets.update" class="permission-name add-link" data-text="dns.resourceRecordSets.update" tabindex="-1"><code translate="no" dir="ltr">dns.resourceRecordSets.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.admin">DNS Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.editor">DNS Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.serviceAgent">Cluster Director Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.serviceAgent">Cloud Managed Identities Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.serviceAgent">Managed Kafka Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/metastore#metastore.serviceAgent">Dataproc Metastore Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/metastore.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusterservicediscovery#multiclusterservicediscovery.serviceAgent">Multi-Cluster Service Discovery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusterservicediscovery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/networkconnectivity#networkconnectivity.serviceAgent">Network Connectivity Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/networkconnectivity.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/oci#oci.serviceAgent">Oracle Database@Google Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/oci.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/servicenetworking#servicenetworking.serviceAgent">Service Networking Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/servicenetworking.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.serviceAgent">VMware Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="dns.responsePolicies.create" class="permission-name add-link" data-text="dns.responsePolicies.create" tabindex="-1"><code translate="no" dir="ltr">dns.responsePolicies.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.admin">DNS Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.editor">DNS Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/container#container.hostServiceAgentUser">Kubernetes Engine Host Service Agent User</a> (<code class="role-name" translate="no" dir="ltr">roles/container.hostServiceAgentUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.serviceAgent">Cloud Managed Identities Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusterservicediscovery#multiclusterservicediscovery.serviceAgent">Multi-Cluster Service Discovery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusterservicediscovery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/oci#oci.serviceAgent">Oracle Database@Google Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/oci.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/servicenetworking#servicenetworking.serviceAgent">Service Networking Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/servicenetworking.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.serviceAgent">VMware Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="dns.responsePolicies.delete" class="permission-name add-link" data-text="dns.responsePolicies.delete" tabindex="-1"><code translate="no" dir="ltr">dns.responsePolicies.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.admin">DNS Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.editor">DNS Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/container#container.hostServiceAgentUser">Kubernetes Engine Host Service Agent User</a> (<code class="role-name" translate="no" dir="ltr">roles/container.hostServiceAgentUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.serviceAgent">Cloud Managed Identities Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusterservicediscovery#multiclusterservicediscovery.serviceAgent">Multi-Cluster Service Discovery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusterservicediscovery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/oci#oci.serviceAgent">Oracle Database@Google Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/oci.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/servicenetworking#servicenetworking.serviceAgent">Service Networking Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/servicenetworking.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.serviceAgent">VMware Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="dns.responsePolicies.get" class="permission-name add-link" data-text="dns.responsePolicies.get" tabindex="-1"><code translate="no" dir="ltr">dns.responsePolicies.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.admin">DNS Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.editor">DNS Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.viewer">DNS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/container#container.hostServiceAgentUser">Kubernetes Engine Host Service Agent User</a> (<code class="role-name" translate="no" dir="ltr">roles/container.hostServiceAgentUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.reader">DNS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.serviceAgent">Cloud Managed Identities Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusterservicediscovery#multiclusterservicediscovery.serviceAgent">Multi-Cluster Service Discovery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusterservicediscovery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/oci#oci.serviceAgent">Oracle Database@Google Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/oci.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/servicenetworking#servicenetworking.serviceAgent">Service Networking Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/servicenetworking.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.serviceAgent">VMware Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="dns.responsePolicies.list" class="permission-name add-link" data-text="dns.responsePolicies.list" tabindex="-1"><code translate="no" dir="ltr">dns.responsePolicies.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.admin">DNS Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.editor">DNS Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.viewer">DNS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/container#container.hostServiceAgentUser">Kubernetes Engine Host Service Agent User</a> (<code class="role-name" translate="no" dir="ltr">roles/container.hostServiceAgentUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.reader">DNS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.serviceAgent">Cloud Managed Identities Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusterservicediscovery#multiclusterservicediscovery.serviceAgent">Multi-Cluster Service Discovery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusterservicediscovery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/oci#oci.serviceAgent">Oracle Database@Google Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/oci.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/servicenetworking#servicenetworking.serviceAgent">Service Networking Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/servicenetworking.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.serviceAgent">VMware Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="dns.responsePolicies.update" class="permission-name add-link" data-text="dns.responsePolicies.update" tabindex="-1"><code translate="no" dir="ltr">dns.responsePolicies.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.admin">DNS Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.editor">DNS Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/container#container.hostServiceAgentUser">Kubernetes Engine Host Service Agent User</a> (<code class="role-name" translate="no" dir="ltr">roles/container.hostServiceAgentUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.serviceAgent">Cloud Managed Identities Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusterservicediscovery#multiclusterservicediscovery.serviceAgent">Multi-Cluster Service Discovery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusterservicediscovery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/oci#oci.serviceAgent">Oracle Database@Google Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/oci.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/servicenetworking#servicenetworking.serviceAgent">Service Networking Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/servicenetworking.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.serviceAgent">VMware Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="dns.responsePolicyRules.create" class="permission-name add-link" data-text="dns.responsePolicyRules.create" tabindex="-1"><code translate="no" dir="ltr">dns.responsePolicyRules.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.admin">DNS Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.editor">DNS Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/container#container.hostServiceAgentUser">Kubernetes Engine Host Service Agent User</a> (<code class="role-name" translate="no" dir="ltr">roles/container.hostServiceAgentUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.serviceAgent">Cloud Managed Identities Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusterservicediscovery#multiclusterservicediscovery.serviceAgent">Multi-Cluster Service Discovery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusterservicediscovery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/oci#oci.serviceAgent">Oracle Database@Google Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/oci.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/servicenetworking#servicenetworking.serviceAgent">Service Networking Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/servicenetworking.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.serviceAgent">VMware Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="dns.responsePolicyRules.delete" class="permission-name add-link" data-text="dns.responsePolicyRules.delete" tabindex="-1"><code translate="no" dir="ltr">dns.responsePolicyRules.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.admin">DNS Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.editor">DNS Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/container#container.hostServiceAgentUser">Kubernetes Engine Host Service Agent User</a> (<code class="role-name" translate="no" dir="ltr">roles/container.hostServiceAgentUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.serviceAgent">Cloud Managed Identities Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusterservicediscovery#multiclusterservicediscovery.serviceAgent">Multi-Cluster Service Discovery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusterservicediscovery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/oci#oci.serviceAgent">Oracle Database@Google Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/oci.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/servicenetworking#servicenetworking.serviceAgent">Service Networking Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/servicenetworking.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.serviceAgent">VMware Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="dns.responsePolicyRules.get" class="permission-name add-link" data-text="dns.responsePolicyRules.get" tabindex="-1"><code translate="no" dir="ltr">dns.responsePolicyRules.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.admin">DNS Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.editor">DNS Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.viewer">DNS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/container#container.hostServiceAgentUser">Kubernetes Engine Host Service Agent User</a> (<code class="role-name" translate="no" dir="ltr">roles/container.hostServiceAgentUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.reader">DNS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.serviceAgent">Cloud Managed Identities Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusterservicediscovery#multiclusterservicediscovery.serviceAgent">Multi-Cluster Service Discovery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusterservicediscovery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/oci#oci.serviceAgent">Oracle Database@Google Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/oci.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/servicenetworking#servicenetworking.serviceAgent">Service Networking Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/servicenetworking.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.serviceAgent">VMware Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="dns.responsePolicyRules.list" class="permission-name add-link" data-text="dns.responsePolicyRules.list" tabindex="-1"><code translate="no" dir="ltr">dns.responsePolicyRules.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.admin">DNS Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.editor">DNS Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.viewer">DNS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/container#container.hostServiceAgentUser">Kubernetes Engine Host Service Agent User</a> (<code class="role-name" translate="no" dir="ltr">roles/container.hostServiceAgentUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.reader">DNS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.serviceAgent">Cloud Managed Identities Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusterservicediscovery#multiclusterservicediscovery.serviceAgent">Multi-Cluster Service Discovery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusterservicediscovery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/oci#oci.serviceAgent">Oracle Database@Google Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/oci.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/servicenetworking#servicenetworking.serviceAgent">Service Networking Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/servicenetworking.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.serviceAgent">VMware Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="dns.responsePolicyRules.update" class="permission-name add-link" data-text="dns.responsePolicyRules.update" tabindex="-1"><code translate="no" dir="ltr">dns.responsePolicyRules.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.admin">DNS Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.editor">DNS Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/container#container.hostServiceAgentUser">Kubernetes Engine Host Service Agent User</a> (<code class="role-name" translate="no" dir="ltr">roles/container.hostServiceAgentUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.serviceAgent">Cloud Managed Identities Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusterservicediscovery#multiclusterservicediscovery.serviceAgent">Multi-Cluster Service Discovery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusterservicediscovery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/oci#oci.serviceAgent">Oracle Database@Google Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/oci.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/servicenetworking#servicenetworking.serviceAgent">Service Networking Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/servicenetworking.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.serviceAgent">VMware Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.serviceAgent</code>)</li>
</ul></td>
</tr>
</tbody>
</table>

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
