# Cloud Run functions roles and permissions

<div class="devsite-article-body clearfix">

This page lists the IAM roles and permissions for Cloud Run functions. To search through all roles and permissions, see the [role and permission index](/iam/docs/roles-permissions).

## Cloud Run functions roles

<div results-count-container="">

</div>

<table class="fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="50%">Role</th>
<th>Permissions</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td class="role-description"><h4 id="cloudfunctions.admin" class="role-title add-link" data-text="Cloud Functions Admin " tabindex="-1">Cloud Functions Admin</h4>
<p>(<code translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<span class="role-description custom"> </span>
<p>Full access to functions, operations and locations.</p>
<p>This role applies to functions created using the Cloud Functions API. For functions created using Cloud Run, refer to the <a href="/iam/docs/roles-permissions/run">Cloud Run roles and permissions</a> page.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">artifactregistry.attachments.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.attachments.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.dockerimages.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.dockerimages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.dockerimages.list</code></li>
</ul>
<p><code translate="no" dir="ltr">artifactregistry.files.download</code></p>
<p><code translate="no" dir="ltr">artifactregistry.files.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.files.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.locations.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.locations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.mavenartifacts.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.mavenartifacts.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.mavenartifacts.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.npmpackages.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.npmpackages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.npmpackages.list</code></li>
</ul>
<p><code translate="no" dir="ltr">artifactregistry.packages.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.packages.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.projectconfigs.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.projectsettings.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.pythonpackages.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.pythonpackages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.pythonpackages.list</code></li>
</ul>
<p><code translate="no" dir="ltr">artifactregistry.repositories.downloadArtifacts</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.exportArtifacts</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.listTagBindings</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.readViaVirtualRepository</code></p>
<p><code translate="no" dir="ltr">artifactregistry.rules.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.rules.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.tags.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.tags.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.versions.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.versions.list</code></p>
<p><code translate="no" dir="ltr">cloudasset.assets.searchAllResources</code></p>
<p><code translate="no" dir="ltr">cloudbuild.builds.get</code></p>
<p><code translate="no" dir="ltr">cloudbuild.builds.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudbuild.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudbuild.locations.get</code></li>
<li><code translate="no" dir="ltr">cloudbuild.locations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudbuild.operations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudbuild.operations.get</code></li>
<li><code translate="no" dir="ltr">cloudbuild.operations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudfunctions.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudfunctions.functions.call</code></li>
<li><code translate="no" dir="ltr">cloudfunctions.functions.create</code></li>
<li><code translate="no" dir="ltr">cloudfunctions.functions.delete</code></li>
<li><code translate="no" dir="ltr">cloudfunctions.functions.generationUpgrade</code></li>
<li><code translate="no" dir="ltr">cloudfunctions.functions.get</code></li>
<li><code translate="no" dir="ltr">cloudfunctions.functions.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">cloudfunctions.functions.invoke</code></li>
<li><code translate="no" dir="ltr">cloudfunctions.functions.list</code></li>
<li><code translate="no" dir="ltr">cloudfunctions.functions.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">cloudfunctions.functions.sourceCodeGet</code></li>
<li><code translate="no" dir="ltr">cloudfunctions.functions.sourceCodeSet</code></li>
<li><code translate="no" dir="ltr">cloudfunctions.functions.update</code></li>
<li><code translate="no" dir="ltr">cloudfunctions.locations.list</code></li>
<li><code translate="no" dir="ltr">cloudfunctions.operations.get</code></li>
<li><code translate="no" dir="ltr">cloudfunctions.operations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">eventarc.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">eventarc.channelConnections.create</code></li>
<li><code translate="no" dir="ltr">eventarc.channelConnections.createTagBinding</code></li>
<li><code translate="no" dir="ltr">eventarc.channelConnections.delete</code></li>
<li><code translate="no" dir="ltr">eventarc.channelConnections.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">eventarc.channelConnections.get</code></li>
<li><code translate="no" dir="ltr">eventarc.channelConnections.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">eventarc.channelConnections.list</code></li>
<li><code translate="no" dir="ltr">eventarc.channelConnections.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">eventarc.channelConnections.listTagBindings</code></li>
<li><code translate="no" dir="ltr">eventarc.channelConnections.publish</code></li>
<li><code translate="no" dir="ltr">eventarc.channelConnections.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">eventarc.channels.attach</code></li>
<li><code translate="no" dir="ltr">eventarc.channels.create</code></li>
<li><code translate="no" dir="ltr">eventarc.channels.createTagBinding</code></li>
<li><code translate="no" dir="ltr">eventarc.channels.delete</code></li>
<li><code translate="no" dir="ltr">eventarc.channels.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">eventarc.channels.get</code></li>
<li><code translate="no" dir="ltr">eventarc.channels.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">eventarc.channels.list</code></li>
<li><code translate="no" dir="ltr">eventarc.channels.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">eventarc.channels.listTagBindings</code></li>
<li><code translate="no" dir="ltr">eventarc.channels.publish</code></li>
<li><code translate="no" dir="ltr">eventarc.channels.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">eventarc.channels.undelete</code></li>
<li><code translate="no" dir="ltr">eventarc.channels.update</code></li>
<li><code translate="no" dir="ltr">eventarc.enrollments.create</code></li>
<li><code translate="no" dir="ltr">eventarc.enrollments.delete</code></li>
<li><code translate="no" dir="ltr">eventarc.enrollments.get</code></li>
<li><code translate="no" dir="ltr">eventarc.enrollments.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">eventarc.enrollments.list</code></li>
<li><code translate="no" dir="ltr">eventarc.enrollments.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">eventarc.enrollments.update</code></li>
<li><code translate="no" dir="ltr">eventarc.events.receiveAuditLogWritten</code></li>
<li><code translate="no" dir="ltr">eventarc.events.receiveEvent</code></li>
<li><code translate="no" dir="ltr">eventarc.googleApiSources.create</code></li>
<li><code translate="no" dir="ltr">eventarc.googleApiSources.delete</code></li>
<li><code translate="no" dir="ltr">eventarc.googleApiSources.get</code></li>
<li><code translate="no" dir="ltr">eventarc.googleApiSources.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">eventarc.googleApiSources.list</code></li>
<li><code translate="no" dir="ltr">eventarc.googleApiSources.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">eventarc.googleApiSources.update</code></li>
<li><code translate="no" dir="ltr">eventarc.googleChannelConfigs.get</code></li>
<li><code translate="no" dir="ltr">eventarc.googleChannelConfigs.update</code></li>
<li><code translate="no" dir="ltr">eventarc.kafkaSources.create</code></li>
<li><code translate="no" dir="ltr">eventarc.kafkaSources.delete</code></li>
<li><code translate="no" dir="ltr">eventarc.kafkaSources.get</code></li>
<li><code translate="no" dir="ltr">eventarc.kafkaSources.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">eventarc.kafkaSources.list</code></li>
<li><code translate="no" dir="ltr">eventarc.kafkaSources.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">eventarc.locations.get</code></li>
<li><code translate="no" dir="ltr">eventarc.locations.list</code></li>
<li><code translate="no" dir="ltr">eventarc.messageBuses.create</code></li>
<li><code translate="no" dir="ltr">eventarc.messageBuses.delete</code></li>
<li><code translate="no" dir="ltr">eventarc.messageBuses.get</code></li>
<li><code translate="no" dir="ltr">eventarc.messageBuses.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">eventarc.messageBuses.list</code></li>
<li><code translate="no" dir="ltr">eventarc.messageBuses.publish</code></li>
<li><code translate="no" dir="ltr">eventarc.messageBuses.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">eventarc.messageBuses.update</code></li>
<li><code translate="no" dir="ltr">eventarc.messageBuses.use</code></li>
<li><code translate="no" dir="ltr">eventarc.multiProjectSources.collectGoogleApiEvents</code></li>
<li><code translate="no" dir="ltr">eventarc.operations.cancel</code></li>
<li><code translate="no" dir="ltr">eventarc.operations.delete</code></li>
<li><code translate="no" dir="ltr">eventarc.operations.get</code></li>
<li><code translate="no" dir="ltr">eventarc.operations.list</code></li>
<li><code translate="no" dir="ltr">eventarc.pipelines.create</code></li>
<li><code translate="no" dir="ltr">eventarc.pipelines.delete</code></li>
<li><code translate="no" dir="ltr">eventarc.pipelines.get</code></li>
<li><code translate="no" dir="ltr">eventarc.pipelines.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">eventarc.pipelines.list</code></li>
<li><code translate="no" dir="ltr">eventarc.pipelines.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">eventarc.pipelines.update</code></li>
<li><code translate="no" dir="ltr">eventarc.providers.get</code></li>
<li><code translate="no" dir="ltr">eventarc.providers.list</code></li>
<li><code translate="no" dir="ltr">eventarc.triggers.create</code></li>
<li><code translate="no" dir="ltr">eventarc.triggers.createTagBinding</code></li>
<li><code translate="no" dir="ltr">eventarc.triggers.delete</code></li>
<li><code translate="no" dir="ltr">eventarc.triggers.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">eventarc.triggers.get</code></li>
<li><code translate="no" dir="ltr">eventarc.triggers.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">eventarc.triggers.list</code></li>
<li><code translate="no" dir="ltr">eventarc.triggers.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">eventarc.triggers.listTagBindings</code></li>
<li><code translate="no" dir="ltr">eventarc.triggers.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">eventarc.triggers.undelete</code></li>
<li><code translate="no" dir="ltr">eventarc.triggers.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.cloudFunctionsPerformanceInsights.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.cloudFunctionsPerformanceInsights.get</code></li>
<li><code translate="no" dir="ltr">recommender.cloudFunctionsPerformanceInsights.list</code></li>
<li><code translate="no" dir="ltr">recommender.cloudFunctionsPerformanceInsights.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.cloudFunctionsPerformanceRecommendations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.cloudFunctionsPerformanceRecommendations.get</code></li>
<li><code translate="no" dir="ltr">recommender.cloudFunctionsPerformanceRecommendations.list</code></li>
<li><code translate="no" dir="ltr">recommender.cloudFunctionsPerformanceRecommendations.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.locations.get</code></li>
<li><code translate="no" dir="ltr">recommender.locations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServiceCostInsights.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServiceCostInsights.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceCostInsights.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceCostInsights.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServiceCostRecommendations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServiceCostRecommendations.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceCostRecommendations.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceCostRecommendations.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServiceIdentityInsights.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServiceIdentityInsights.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceIdentityInsights.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceIdentityInsights.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServiceIdentityRecommendations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServiceIdentityRecommendations.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceIdentityRecommendations.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceIdentityRecommendations.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServicePerformanceInsights.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServicePerformanceInsights.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServicePerformanceInsights.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServicePerformanceInsights.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServicePerformanceRecommendations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServicePerformanceRecommendations.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServicePerformanceRecommendations.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServicePerformanceRecommendations.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServiceSecurityInsights.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServiceSecurityInsights.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceSecurityInsights.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceSecurityInsights.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServiceSecurityRecommendations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServiceSecurityRecommendations.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceSecurityRecommendations.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceSecurityRecommendations.update</code></li>
</ul>
<p><code translate="no" dir="ltr">remotebuildexecution.blobs.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">run.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">run.configurations.get</code></li>
<li><code translate="no" dir="ltr">run.configurations.list</code></li>
<li><code translate="no" dir="ltr">run.executions.cancel</code></li>
<li><code translate="no" dir="ltr">run.executions.delete</code></li>
<li><code translate="no" dir="ltr">run.executions.get</code></li>
<li><code translate="no" dir="ltr">run.executions.list</code></li>
<li><code translate="no" dir="ltr">run.instances.create</code></li>
<li><code translate="no" dir="ltr">run.instances.delete</code></li>
<li><code translate="no" dir="ltr">run.instances.get</code></li>
<li><code translate="no" dir="ltr">run.instances.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">run.instances.invoke</code></li>
<li><code translate="no" dir="ltr">run.instances.list</code></li>
<li><code translate="no" dir="ltr">run.instances.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">run.instances.sshRead</code></li>
<li><code translate="no" dir="ltr">run.instances.sshRoot</code></li>
<li><code translate="no" dir="ltr">run.instances.start</code></li>
<li><code translate="no" dir="ltr">run.instances.stop</code></li>
<li><code translate="no" dir="ltr">run.instances.update</code></li>
<li><code translate="no" dir="ltr">run.jobs.create</code></li>
<li><code translate="no" dir="ltr">run.jobs.createTagBinding</code></li>
<li><code translate="no" dir="ltr">run.jobs.delete</code></li>
<li><code translate="no" dir="ltr">run.jobs.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">run.jobs.get</code></li>
<li><code translate="no" dir="ltr">run.jobs.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">run.jobs.list</code></li>
<li><code translate="no" dir="ltr">run.jobs.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">run.jobs.listTagBindings</code></li>
<li><code translate="no" dir="ltr">run.jobs.run</code></li>
<li><code translate="no" dir="ltr">run.jobs.runWithOverrides</code></li>
<li><code translate="no" dir="ltr">run.jobs.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">run.jobs.sshRead</code></li>
<li><code translate="no" dir="ltr">run.jobs.sshRoot</code></li>
<li><code translate="no" dir="ltr">run.jobs.update</code></li>
<li><code translate="no" dir="ltr">run.locations.list</code></li>
<li><code translate="no" dir="ltr">run.locations.uploadSource</code></li>
<li><code translate="no" dir="ltr">run.operations.delete</code></li>
<li><code translate="no" dir="ltr">run.operations.get</code></li>
<li><code translate="no" dir="ltr">run.operations.list</code></li>
<li><code translate="no" dir="ltr">run.prompts.get</code></li>
<li><code translate="no" dir="ltr">run.revisions.delete</code></li>
<li><code translate="no" dir="ltr">run.revisions.get</code></li>
<li><code translate="no" dir="ltr">run.revisions.list</code></li>
<li><code translate="no" dir="ltr">run.routes.get</code></li>
<li><code translate="no" dir="ltr">run.routes.invoke</code></li>
<li><code translate="no" dir="ltr">run.routes.list</code></li>
<li><code translate="no" dir="ltr">run.services.create</code></li>
<li><code translate="no" dir="ltr">run.services.createTagBinding</code></li>
<li><code translate="no" dir="ltr">run.services.delete</code></li>
<li><code translate="no" dir="ltr">run.services.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">run.services.get</code></li>
<li><code translate="no" dir="ltr">run.services.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">run.services.list</code></li>
<li><code translate="no" dir="ltr">run.services.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">run.services.listTagBindings</code></li>
<li><code translate="no" dir="ltr">run.services.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">run.services.sshRead</code></li>
<li><code translate="no" dir="ltr">run.services.sshRoot</code></li>
<li><code translate="no" dir="ltr">run.services.update</code></li>
<li><code translate="no" dir="ltr">run.tasks.get</code></li>
<li><code translate="no" dir="ltr">run.tasks.list</code></li>
<li><code translate="no" dir="ltr">run.workerpools.create</code></li>
<li><code translate="no" dir="ltr">run.workerpools.delete</code></li>
<li><code translate="no" dir="ltr">run.workerpools.get</code></li>
<li><code translate="no" dir="ltr">run.workerpools.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">run.workerpools.list</code></li>
<li><code translate="no" dir="ltr">run.workerpools.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">run.workerpools.sshRead</code></li>
<li><code translate="no" dir="ltr">run.workerpools.sshRoot</code></li>
<li><code translate="no" dir="ltr">run.workerpools.update</code></li>
</ul>
<p><code translate="no" dir="ltr">serviceusage.consumerpolicy.analyze</code></p>
<p><code translate="no" dir="ltr">serviceusage.consumerpolicy.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.effectivepolicy.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">serviceusage.groups.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">serviceusage.groups.list</code></li>
<li><code translate="no" dir="ltr">serviceusage.groups.listExpandedMembers</code></li>
<li><code translate="no" dir="ltr">serviceusage.groups.listMembers</code></li>
</ul>
<p><code translate="no" dir="ltr">serviceusage.quotas.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.list</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.listApis</code></p>
<p><code translate="no" dir="ltr">serviceusage.values.test</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="cloudfunctions.editor" class="role-title add-link" data-text="Cloud Functions Editor " tabindex="-1">Cloud Functions Editor</h4>
<p>(<code translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<span class="role-description custom"> </span>
<p>Editor role for Cloud Functions</p>
<p>This role applies to functions created using the Cloud Functions API. For functions created using Cloud Run, refer to the <a href="/iam/docs/roles-permissions/run">Cloud Run roles and permissions</a> page.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">artifactregistry.attachments.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.attachments.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.dockerimages.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.dockerimages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.dockerimages.list</code></li>
</ul>
<p><code translate="no" dir="ltr">artifactregistry.files.download</code></p>
<p><code translate="no" dir="ltr">artifactregistry.files.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.files.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.locations.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.locations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.mavenartifacts.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.mavenartifacts.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.mavenartifacts.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.npmpackages.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.npmpackages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.npmpackages.list</code></li>
</ul>
<p><code translate="no" dir="ltr">artifactregistry.packages.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.packages.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.projectconfigs.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.projectsettings.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.pythonpackages.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.pythonpackages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.pythonpackages.list</code></li>
</ul>
<p><code translate="no" dir="ltr">artifactregistry.repositories.downloadArtifacts</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.exportArtifacts</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.listTagBindings</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.readViaVirtualRepository</code></p>
<p><code translate="no" dir="ltr">artifactregistry.rules.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.rules.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.tags.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.tags.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.versions.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.versions.list</code></p>
<p><code translate="no" dir="ltr">cloudasset.assets.searchAllResources</code></p>
<p><code translate="no" dir="ltr">cloudbuild.builds.get</code></p>
<p><code translate="no" dir="ltr">cloudbuild.builds.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudbuild.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudbuild.locations.get</code></li>
<li><code translate="no" dir="ltr">cloudbuild.locations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudbuild.operations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudbuild.operations.get</code></li>
<li><code translate="no" dir="ltr">cloudbuild.operations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">cloudfunctions.functions.call</code></p>
<p><code translate="no" dir="ltr">cloudfunctions.functions.create</code></p>
<p><code translate="no" dir="ltr">cloudfunctions.functions.delete</code></p>
<p><code translate="no" dir="ltr">cloudfunctions.functions.generationUpgrade</code></p>
<p><code translate="no" dir="ltr">cloudfunctions.functions.get</code></p>
<p><code translate="no" dir="ltr">cloudfunctions.functions.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudfunctions.functions.invoke</code></p>
<p><code translate="no" dir="ltr">cloudfunctions.functions.list</code></p>
<p><code translate="no" dir="ltr">cloudfunctions.functions.sourceCodeGet</code></p>
<p><code translate="no" dir="ltr">cloudfunctions.functions.sourceCodeSet</code></p>
<p><code translate="no" dir="ltr">cloudfunctions.functions.update</code></p>
<p><code translate="no" dir="ltr">cloudfunctions.locations.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudfunctions.operations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudfunctions.operations.get</code></li>
<li><code translate="no" dir="ltr">cloudfunctions.operations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">eventarc.channelConnections.create</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.delete</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.get</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.list</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.listTagBindings</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.publish</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.attach</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.create</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.delete</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.get</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.list</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.listTagBindings</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.publish</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.undelete</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.update</code></p>
<p><code translate="no" dir="ltr">eventarc.enrollments.create</code></p>
<p><code translate="no" dir="ltr">eventarc.enrollments.delete</code></p>
<p><code translate="no" dir="ltr">eventarc.enrollments.get</code></p>
<p><code translate="no" dir="ltr">eventarc.enrollments.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.enrollments.list</code></p>
<p><code translate="no" dir="ltr">eventarc.enrollments.update</code></p>
<p><code translate="no" dir="ltr">eventarc.googleApiSources.create</code></p>
<p><code translate="no" dir="ltr">eventarc.googleApiSources.delete</code></p>
<p><code translate="no" dir="ltr">eventarc.googleApiSources.get</code></p>
<p><code translate="no" dir="ltr">eventarc.googleApiSources.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.googleApiSources.list</code></p>
<p><code translate="no" dir="ltr">eventarc.googleApiSources.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">eventarc.googleChannelConfigs.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">eventarc.googleChannelConfigs.get</code></li>
<li><code translate="no" dir="ltr">eventarc.googleChannelConfigs.update</code></li>
</ul>
<p><code translate="no" dir="ltr">eventarc.kafkaSources.create</code></p>
<p><code translate="no" dir="ltr">eventarc.kafkaSources.delete</code></p>
<p><code translate="no" dir="ltr">eventarc.kafkaSources.get</code></p>
<p><code translate="no" dir="ltr">eventarc.kafkaSources.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.kafkaSources.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">eventarc.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">eventarc.locations.get</code></li>
<li><code translate="no" dir="ltr">eventarc.locations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">eventarc.messageBuses.get</code></p>
<p><code translate="no" dir="ltr">eventarc.messageBuses.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.messageBuses.list</code></p>
<p><code translate="no" dir="ltr">eventarc.messageBuses.use</code></p>
<p><code translate="no" dir="ltr">eventarc.multiProjectSources.collectGoogleApiEvents</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">eventarc.operations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">eventarc.operations.cancel</code></li>
<li><code translate="no" dir="ltr">eventarc.operations.delete</code></li>
<li><code translate="no" dir="ltr">eventarc.operations.get</code></li>
<li><code translate="no" dir="ltr">eventarc.operations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">eventarc.pipelines.create</code></p>
<p><code translate="no" dir="ltr">eventarc.pipelines.delete</code></p>
<p><code translate="no" dir="ltr">eventarc.pipelines.get</code></p>
<p><code translate="no" dir="ltr">eventarc.pipelines.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.pipelines.list</code></p>
<p><code translate="no" dir="ltr">eventarc.pipelines.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">eventarc.providers.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">eventarc.providers.get</code></li>
<li><code translate="no" dir="ltr">eventarc.providers.list</code></li>
</ul>
<p><code translate="no" dir="ltr">eventarc.triggers.create</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.delete</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.get</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.list</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.listTagBindings</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.undelete</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.cloudFunctionsPerformanceInsights.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.cloudFunctionsPerformanceInsights.get</code></li>
<li><code translate="no" dir="ltr">recommender.cloudFunctionsPerformanceInsights.list</code></li>
<li><code translate="no" dir="ltr">recommender.cloudFunctionsPerformanceInsights.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.cloudFunctionsPerformanceRecommendations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.cloudFunctionsPerformanceRecommendations.get</code></li>
<li><code translate="no" dir="ltr">recommender.cloudFunctionsPerformanceRecommendations.list</code></li>
<li><code translate="no" dir="ltr">recommender.cloudFunctionsPerformanceRecommendations.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.locations.get</code></li>
<li><code translate="no" dir="ltr">recommender.locations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServiceCostInsights.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServiceCostInsights.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceCostInsights.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceCostInsights.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServiceCostRecommendations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServiceCostRecommendations.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceCostRecommendations.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceCostRecommendations.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServiceIdentityInsights.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServiceIdentityInsights.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceIdentityInsights.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceIdentityInsights.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServiceIdentityRecommendations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServiceIdentityRecommendations.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceIdentityRecommendations.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceIdentityRecommendations.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServicePerformanceInsights.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServicePerformanceInsights.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServicePerformanceInsights.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServicePerformanceInsights.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServicePerformanceRecommendations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServicePerformanceRecommendations.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServicePerformanceRecommendations.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServicePerformanceRecommendations.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServiceSecurityInsights.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServiceSecurityInsights.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceSecurityInsights.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceSecurityInsights.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServiceSecurityRecommendations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServiceSecurityRecommendations.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceSecurityRecommendations.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceSecurityRecommendations.update</code></li>
</ul>
<p><code translate="no" dir="ltr">remotebuildexecution.blobs.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">run.configurations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">run.configurations.get</code></li>
<li><code translate="no" dir="ltr">run.configurations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">run.executions.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">run.executions.cancel</code></li>
<li><code translate="no" dir="ltr">run.executions.delete</code></li>
<li><code translate="no" dir="ltr">run.executions.get</code></li>
<li><code translate="no" dir="ltr">run.executions.list</code></li>
</ul>
<p><code translate="no" dir="ltr">run.instances.create</code></p>
<p><code translate="no" dir="ltr">run.instances.delete</code></p>
<p><code translate="no" dir="ltr">run.instances.get</code></p>
<p><code translate="no" dir="ltr">run.instances.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">run.instances.invoke</code></p>
<p><code translate="no" dir="ltr">run.instances.list</code></p>
<p><code translate="no" dir="ltr">run.instances.sshRead</code></p>
<p><code translate="no" dir="ltr">run.instances.sshRoot</code></p>
<p><code translate="no" dir="ltr">run.instances.start</code></p>
<p><code translate="no" dir="ltr">run.instances.stop</code></p>
<p><code translate="no" dir="ltr">run.instances.update</code></p>
<p><code translate="no" dir="ltr">run.jobs.create</code></p>
<p><code translate="no" dir="ltr">run.jobs.delete</code></p>
<p><code translate="no" dir="ltr">run.jobs.get</code></p>
<p><code translate="no" dir="ltr">run.jobs.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">run.jobs.list</code></p>
<p><code translate="no" dir="ltr">run.jobs.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">run.jobs.listTagBindings</code></p>
<p><code translate="no" dir="ltr">run.jobs.run</code></p>
<p><code translate="no" dir="ltr">run.jobs.runWithOverrides</code></p>
<p><code translate="no" dir="ltr">run.jobs.sshRead</code></p>
<p><code translate="no" dir="ltr">run.jobs.sshRoot</code></p>
<p><code translate="no" dir="ltr">run.jobs.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">run.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">run.locations.list</code></li>
<li><code translate="no" dir="ltr">run.locations.uploadSource</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">run.operations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">run.operations.delete</code></li>
<li><code translate="no" dir="ltr">run.operations.get</code></li>
<li><code translate="no" dir="ltr">run.operations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">run.prompts.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">run.revisions.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">run.revisions.delete</code></li>
<li><code translate="no" dir="ltr">run.revisions.get</code></li>
<li><code translate="no" dir="ltr">run.revisions.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">run.routes.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">run.routes.get</code></li>
<li><code translate="no" dir="ltr">run.routes.invoke</code></li>
<li><code translate="no" dir="ltr">run.routes.list</code></li>
</ul>
<p><code translate="no" dir="ltr">run.services.create</code></p>
<p><code translate="no" dir="ltr">run.services.delete</code></p>
<p><code translate="no" dir="ltr">run.services.get</code></p>
<p><code translate="no" dir="ltr">run.services.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">run.services.list</code></p>
<p><code translate="no" dir="ltr">run.services.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">run.services.listTagBindings</code></p>
<p><code translate="no" dir="ltr">run.services.sshRead</code></p>
<p><code translate="no" dir="ltr">run.services.sshRoot</code></p>
<p><code translate="no" dir="ltr">run.services.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">run.tasks.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">run.tasks.get</code></li>
<li><code translate="no" dir="ltr">run.tasks.list</code></li>
</ul>
<p><code translate="no" dir="ltr">run.workerpools.create</code></p>
<p><code translate="no" dir="ltr">run.workerpools.delete</code></p>
<p><code translate="no" dir="ltr">run.workerpools.get</code></p>
<p><code translate="no" dir="ltr">run.workerpools.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">run.workerpools.list</code></p>
<p><code translate="no" dir="ltr">run.workerpools.sshRead</code></p>
<p><code translate="no" dir="ltr">run.workerpools.sshRoot</code></p>
<p><code translate="no" dir="ltr">run.workerpools.update</code></p>
<p><code translate="no" dir="ltr">serviceusage.consumerpolicy.analyze</code></p>
<p><code translate="no" dir="ltr">serviceusage.consumerpolicy.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.effectivepolicy.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">serviceusage.groups.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">serviceusage.groups.list</code></li>
<li><code translate="no" dir="ltr">serviceusage.groups.listExpandedMembers</code></li>
<li><code translate="no" dir="ltr">serviceusage.groups.listMembers</code></li>
</ul>
<p><code translate="no" dir="ltr">serviceusage.quotas.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.list</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.listApis</code></p>
<p><code translate="no" dir="ltr">serviceusage.values.test</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="cloudfunctions.invoker" class="role-title add-link" data-text="Cloud Functions Invoker " tabindex="-1">Cloud Functions Invoker</h4>
<p>(<code translate="no" dir="ltr">roles/cloudfunctions.invoker</code>)</p>
<span class="role-description custom"> </span>
<p>Ability to invoke 1st gen HTTP functions with restricted access. 2nd gen functions need the Cloud Run Invoker role instead.</p>
<p>This role applies to functions created using the Cloud Functions API. For functions created using Cloud Run, refer to the <a href="/iam/docs/roles-permissions/run">Cloud Run roles and permissions</a> page.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudfunctions.functions.invoke</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="cloudfunctions.viewer" class="role-title add-link" data-text="Cloud Functions Viewer " tabindex="-1">Cloud Functions Viewer</h4>
<p>(<code translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<span class="role-description custom"> </span>
<p>Read-only access to functions and locations.</p>
<p>This role applies to functions created using the Cloud Functions API. For functions created using Cloud Run, refer to the <a href="/iam/docs/roles-permissions/run">Cloud Run roles and permissions</a> page.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudasset.assets.searchAllResources</code></p>
<p><code translate="no" dir="ltr">cloudbuild.builds.get</code></p>
<p><code translate="no" dir="ltr">cloudbuild.builds.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudbuild.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudbuild.locations.get</code></li>
<li><code translate="no" dir="ltr">cloudbuild.locations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudbuild.operations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudbuild.operations.get</code></li>
<li><code translate="no" dir="ltr">cloudbuild.operations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">cloudfunctions.functions.get</code></p>
<p><code translate="no" dir="ltr">cloudfunctions.functions.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudfunctions.functions.list</code></p>
<p><code translate="no" dir="ltr">cloudfunctions.locations.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudfunctions.operations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudfunctions.operations.get</code></li>
<li><code translate="no" dir="ltr">cloudfunctions.operations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">eventarc.channelConnections.get</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.list</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.listTagBindings</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.get</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.list</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.listTagBindings</code></p>
<p><code translate="no" dir="ltr">eventarc.enrollments.get</code></p>
<p><code translate="no" dir="ltr">eventarc.enrollments.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.enrollments.list</code></p>
<p><code translate="no" dir="ltr">eventarc.googleApiSources.get</code></p>
<p><code translate="no" dir="ltr">eventarc.googleApiSources.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.googleApiSources.list</code></p>
<p><code translate="no" dir="ltr">eventarc.googleChannelConfigs.get</code></p>
<p><code translate="no" dir="ltr">eventarc.kafkaSources.get</code></p>
<p><code translate="no" dir="ltr">eventarc.kafkaSources.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.kafkaSources.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">eventarc.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">eventarc.locations.get</code></li>
<li><code translate="no" dir="ltr">eventarc.locations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">eventarc.messageBuses.get</code></p>
<p><code translate="no" dir="ltr">eventarc.messageBuses.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.messageBuses.list</code></p>
<p><code translate="no" dir="ltr">eventarc.messageBuses.use</code></p>
<p><code translate="no" dir="ltr">eventarc.multiProjectSources.collectGoogleApiEvents</code></p>
<p><code translate="no" dir="ltr">eventarc.operations.get</code></p>
<p><code translate="no" dir="ltr">eventarc.operations.list</code></p>
<p><code translate="no" dir="ltr">eventarc.pipelines.get</code></p>
<p><code translate="no" dir="ltr">eventarc.pipelines.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.pipelines.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">eventarc.providers.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">eventarc.providers.get</code></li>
<li><code translate="no" dir="ltr">eventarc.providers.list</code></li>
</ul>
<p><code translate="no" dir="ltr">eventarc.triggers.get</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.list</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.listTagBindings</code></p>
<p><code translate="no" dir="ltr">recommender.cloudFunctionsPerformanceInsights.get</code></p>
<p><code translate="no" dir="ltr">recommender.cloudFunctionsPerformanceInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudFunctionsPerformanceRecommendations.get</code></p>
<p><code translate="no" dir="ltr">recommender.cloudFunctionsPerformanceRecommendations.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.locations.get</code></li>
<li><code translate="no" dir="ltr">recommender.locations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">recommender.runServiceCostInsights.get</code></p>
<p><code translate="no" dir="ltr">recommender.runServiceCostInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.runServiceCostRecommendations.get</code></p>
<p><code translate="no" dir="ltr">recommender.runServiceCostRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.runServiceIdentityInsights.get</code></p>
<p><code translate="no" dir="ltr">recommender.runServiceIdentityInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.runServiceIdentityRecommendations.get</code></p>
<p><code translate="no" dir="ltr">recommender.runServiceIdentityRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.runServicePerformanceInsights.get</code></p>
<p><code translate="no" dir="ltr">recommender.runServicePerformanceInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.runServicePerformanceRecommendations.get</code></p>
<p><code translate="no" dir="ltr">recommender.runServicePerformanceRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.runServiceSecurityInsights.get</code></p>
<p><code translate="no" dir="ltr">recommender.runServiceSecurityInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.runServiceSecurityRecommendations.get</code></p>
<p><code translate="no" dir="ltr">recommender.runServiceSecurityRecommendations.list</code></p>
<p><code translate="no" dir="ltr">remotebuildexecution.blobs.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">run.configurations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">run.configurations.get</code></li>
<li><code translate="no" dir="ltr">run.configurations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">run.executions.get</code></p>
<p><code translate="no" dir="ltr">run.executions.list</code></p>
<p><code translate="no" dir="ltr">run.instances.get</code></p>
<p><code translate="no" dir="ltr">run.instances.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">run.instances.list</code></p>
<p><code translate="no" dir="ltr">run.jobs.get</code></p>
<p><code translate="no" dir="ltr">run.jobs.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">run.jobs.list</code></p>
<p><code translate="no" dir="ltr">run.jobs.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">run.jobs.listTagBindings</code></p>
<p><code translate="no" dir="ltr">run.locations.list</code></p>
<p><code translate="no" dir="ltr">run.operations.get</code></p>
<p><code translate="no" dir="ltr">run.operations.list</code></p>
<p><code translate="no" dir="ltr">run.prompts.get</code></p>
<p><code translate="no" dir="ltr">run.revisions.get</code></p>
<p><code translate="no" dir="ltr">run.revisions.list</code></p>
<p><code translate="no" dir="ltr">run.routes.get</code></p>
<p><code translate="no" dir="ltr">run.routes.list</code></p>
<p><code translate="no" dir="ltr">run.services.get</code></p>
<p><code translate="no" dir="ltr">run.services.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">run.services.list</code></p>
<p><code translate="no" dir="ltr">run.services.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">run.services.listTagBindings</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">run.tasks.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">run.tasks.get</code></li>
<li><code translate="no" dir="ltr">run.tasks.list</code></li>
</ul>
<p><code translate="no" dir="ltr">run.workerpools.get</code></p>
<p><code translate="no" dir="ltr">run.workerpools.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">run.workerpools.list</code></p>
<p><code translate="no" dir="ltr">serviceusage.consumerpolicy.analyze</code></p>
<p><code translate="no" dir="ltr">serviceusage.consumerpolicy.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.effectivepolicy.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">serviceusage.groups.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">serviceusage.groups.list</code></li>
<li><code translate="no" dir="ltr">serviceusage.groups.listExpandedMembers</code></li>
<li><code translate="no" dir="ltr">serviceusage.groups.listMembers</code></li>
</ul>
<p><code translate="no" dir="ltr">serviceusage.quotas.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.list</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.listApis</code></p>
<p><code translate="no" dir="ltr">serviceusage.values.test</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="cloudfunctions.developer" class="role-title add-link" data-text="Cloud Functions Developer " tabindex="-1">Cloud Functions Developer</h4>
<p>(<code translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<span class="role-description custom"> </span>
<p>Read and write access to all functions-related resources.</p>
<p>This role applies to functions created using the Cloud Functions API. For functions created using Cloud Run, refer to the <a href="/iam/docs/roles-permissions/run">Cloud Run roles and permissions</a> page.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">artifactregistry.attachments.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.attachments.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.dockerimages.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.dockerimages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.dockerimages.list</code></li>
</ul>
<p><code translate="no" dir="ltr">artifactregistry.files.download</code></p>
<p><code translate="no" dir="ltr">artifactregistry.files.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.files.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.locations.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.locations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.mavenartifacts.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.mavenartifacts.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.mavenartifacts.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.npmpackages.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.npmpackages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.npmpackages.list</code></li>
</ul>
<p><code translate="no" dir="ltr">artifactregistry.packages.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.packages.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.projectconfigs.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.projectsettings.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.pythonpackages.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.pythonpackages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.pythonpackages.list</code></li>
</ul>
<p><code translate="no" dir="ltr">artifactregistry.repositories.downloadArtifacts</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.exportArtifacts</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.listTagBindings</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.readViaVirtualRepository</code></p>
<p><code translate="no" dir="ltr">artifactregistry.rules.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.rules.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.tags.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.tags.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.versions.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.versions.list</code></p>
<p><code translate="no" dir="ltr">cloudasset.assets.searchAllResources</code></p>
<p><code translate="no" dir="ltr">cloudbuild.builds.get</code></p>
<p><code translate="no" dir="ltr">cloudbuild.builds.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudbuild.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudbuild.locations.get</code></li>
<li><code translate="no" dir="ltr">cloudbuild.locations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudbuild.operations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudbuild.operations.get</code></li>
<li><code translate="no" dir="ltr">cloudbuild.operations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">cloudfunctions.functions.call</code></p>
<p><code translate="no" dir="ltr">cloudfunctions.functions.create</code></p>
<p><code translate="no" dir="ltr">cloudfunctions.functions.delete</code></p>
<p><code translate="no" dir="ltr">cloudfunctions.functions.generationUpgrade</code></p>
<p><code translate="no" dir="ltr">cloudfunctions.functions.get</code></p>
<p><code translate="no" dir="ltr">cloudfunctions.functions.invoke</code></p>
<p><code translate="no" dir="ltr">cloudfunctions.functions.list</code></p>
<p><code translate="no" dir="ltr">cloudfunctions.functions.sourceCodeGet</code></p>
<p><code translate="no" dir="ltr">cloudfunctions.functions.sourceCodeSet</code></p>
<p><code translate="no" dir="ltr">cloudfunctions.functions.update</code></p>
<p><code translate="no" dir="ltr">cloudfunctions.locations.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudfunctions.operations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudfunctions.operations.get</code></li>
<li><code translate="no" dir="ltr">cloudfunctions.operations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">eventarc.channelConnections.create</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.createTagBinding</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.delete</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.get</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.list</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.listTagBindings</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.publish</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.attach</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.create</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.createTagBinding</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.delete</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.get</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.list</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.listTagBindings</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.publish</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.undelete</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.update</code></p>
<p><code translate="no" dir="ltr">eventarc.enrollments.create</code></p>
<p><code translate="no" dir="ltr">eventarc.enrollments.delete</code></p>
<p><code translate="no" dir="ltr">eventarc.enrollments.get</code></p>
<p><code translate="no" dir="ltr">eventarc.enrollments.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.enrollments.list</code></p>
<p><code translate="no" dir="ltr">eventarc.enrollments.update</code></p>
<p><code translate="no" dir="ltr">eventarc.googleApiSources.create</code></p>
<p><code translate="no" dir="ltr">eventarc.googleApiSources.delete</code></p>
<p><code translate="no" dir="ltr">eventarc.googleApiSources.get</code></p>
<p><code translate="no" dir="ltr">eventarc.googleApiSources.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.googleApiSources.list</code></p>
<p><code translate="no" dir="ltr">eventarc.googleApiSources.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">eventarc.googleChannelConfigs.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">eventarc.googleChannelConfigs.get</code></li>
<li><code translate="no" dir="ltr">eventarc.googleChannelConfigs.update</code></li>
</ul>
<p><code translate="no" dir="ltr">eventarc.kafkaSources.create</code></p>
<p><code translate="no" dir="ltr">eventarc.kafkaSources.delete</code></p>
<p><code translate="no" dir="ltr">eventarc.kafkaSources.get</code></p>
<p><code translate="no" dir="ltr">eventarc.kafkaSources.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.kafkaSources.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">eventarc.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">eventarc.locations.get</code></li>
<li><code translate="no" dir="ltr">eventarc.locations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">eventarc.operations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">eventarc.operations.cancel</code></li>
<li><code translate="no" dir="ltr">eventarc.operations.delete</code></li>
<li><code translate="no" dir="ltr">eventarc.operations.get</code></li>
<li><code translate="no" dir="ltr">eventarc.operations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">eventarc.pipelines.create</code></p>
<p><code translate="no" dir="ltr">eventarc.pipelines.delete</code></p>
<p><code translate="no" dir="ltr">eventarc.pipelines.get</code></p>
<p><code translate="no" dir="ltr">eventarc.pipelines.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.pipelines.list</code></p>
<p><code translate="no" dir="ltr">eventarc.pipelines.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">eventarc.providers.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">eventarc.providers.get</code></li>
<li><code translate="no" dir="ltr">eventarc.providers.list</code></li>
</ul>
<p><code translate="no" dir="ltr">eventarc.triggers.create</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.createTagBinding</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.delete</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.get</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.list</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.listTagBindings</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.undelete</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.cloudFunctionsPerformanceInsights.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.cloudFunctionsPerformanceInsights.get</code></li>
<li><code translate="no" dir="ltr">recommender.cloudFunctionsPerformanceInsights.list</code></li>
<li><code translate="no" dir="ltr">recommender.cloudFunctionsPerformanceInsights.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.cloudFunctionsPerformanceRecommendations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.cloudFunctionsPerformanceRecommendations.get</code></li>
<li><code translate="no" dir="ltr">recommender.cloudFunctionsPerformanceRecommendations.list</code></li>
<li><code translate="no" dir="ltr">recommender.cloudFunctionsPerformanceRecommendations.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.locations.get</code></li>
<li><code translate="no" dir="ltr">recommender.locations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServiceCostInsights.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServiceCostInsights.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceCostInsights.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceCostInsights.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServiceCostRecommendations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServiceCostRecommendations.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceCostRecommendations.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceCostRecommendations.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServiceIdentityInsights.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServiceIdentityInsights.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceIdentityInsights.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceIdentityInsights.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServiceIdentityRecommendations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServiceIdentityRecommendations.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceIdentityRecommendations.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceIdentityRecommendations.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServicePerformanceInsights.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServicePerformanceInsights.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServicePerformanceInsights.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServicePerformanceInsights.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServicePerformanceRecommendations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServicePerformanceRecommendations.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServicePerformanceRecommendations.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServicePerformanceRecommendations.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServiceSecurityInsights.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServiceSecurityInsights.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceSecurityInsights.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceSecurityInsights.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServiceSecurityRecommendations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServiceSecurityRecommendations.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceSecurityRecommendations.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceSecurityRecommendations.update</code></li>
</ul>
<p><code translate="no" dir="ltr">remotebuildexecution.blobs.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">run.configurations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">run.configurations.get</code></li>
<li><code translate="no" dir="ltr">run.configurations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">run.executions.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">run.executions.cancel</code></li>
<li><code translate="no" dir="ltr">run.executions.delete</code></li>
<li><code translate="no" dir="ltr">run.executions.get</code></li>
<li><code translate="no" dir="ltr">run.executions.list</code></li>
</ul>
<p><code translate="no" dir="ltr">run.instances.create</code></p>
<p><code translate="no" dir="ltr">run.instances.delete</code></p>
<p><code translate="no" dir="ltr">run.instances.get</code></p>
<p><code translate="no" dir="ltr">run.instances.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">run.instances.invoke</code></p>
<p><code translate="no" dir="ltr">run.instances.list</code></p>
<p><code translate="no" dir="ltr">run.instances.sshRead</code></p>
<p><code translate="no" dir="ltr">run.instances.sshRoot</code></p>
<p><code translate="no" dir="ltr">run.instances.start</code></p>
<p><code translate="no" dir="ltr">run.instances.stop</code></p>
<p><code translate="no" dir="ltr">run.instances.update</code></p>
<p><code translate="no" dir="ltr">run.jobs.create</code></p>
<p><code translate="no" dir="ltr">run.jobs.delete</code></p>
<p><code translate="no" dir="ltr">run.jobs.get</code></p>
<p><code translate="no" dir="ltr">run.jobs.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">run.jobs.list</code></p>
<p><code translate="no" dir="ltr">run.jobs.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">run.jobs.listTagBindings</code></p>
<p><code translate="no" dir="ltr">run.jobs.run</code></p>
<p><code translate="no" dir="ltr">run.jobs.runWithOverrides</code></p>
<p><code translate="no" dir="ltr">run.jobs.sshRead</code></p>
<p><code translate="no" dir="ltr">run.jobs.sshRoot</code></p>
<p><code translate="no" dir="ltr">run.jobs.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">run.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">run.locations.list</code></li>
<li><code translate="no" dir="ltr">run.locations.uploadSource</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">run.operations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">run.operations.delete</code></li>
<li><code translate="no" dir="ltr">run.operations.get</code></li>
<li><code translate="no" dir="ltr">run.operations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">run.prompts.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">run.revisions.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">run.revisions.delete</code></li>
<li><code translate="no" dir="ltr">run.revisions.get</code></li>
<li><code translate="no" dir="ltr">run.revisions.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">run.routes.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">run.routes.get</code></li>
<li><code translate="no" dir="ltr">run.routes.invoke</code></li>
<li><code translate="no" dir="ltr">run.routes.list</code></li>
</ul>
<p><code translate="no" dir="ltr">run.services.create</code></p>
<p><code translate="no" dir="ltr">run.services.delete</code></p>
<p><code translate="no" dir="ltr">run.services.get</code></p>
<p><code translate="no" dir="ltr">run.services.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">run.services.list</code></p>
<p><code translate="no" dir="ltr">run.services.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">run.services.listTagBindings</code></p>
<p><code translate="no" dir="ltr">run.services.sshRead</code></p>
<p><code translate="no" dir="ltr">run.services.sshRoot</code></p>
<p><code translate="no" dir="ltr">run.services.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">run.tasks.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">run.tasks.get</code></li>
<li><code translate="no" dir="ltr">run.tasks.list</code></li>
</ul>
<p><code translate="no" dir="ltr">run.workerpools.create</code></p>
<p><code translate="no" dir="ltr">run.workerpools.delete</code></p>
<p><code translate="no" dir="ltr">run.workerpools.get</code></p>
<p><code translate="no" dir="ltr">run.workerpools.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">run.workerpools.list</code></p>
<p><code translate="no" dir="ltr">run.workerpools.sshRead</code></p>
<p><code translate="no" dir="ltr">run.workerpools.sshRoot</code></p>
<p><code translate="no" dir="ltr">run.workerpools.update</code></p>
<p><code translate="no" dir="ltr">serviceusage.consumerpolicy.analyze</code></p>
<p><code translate="no" dir="ltr">serviceusage.consumerpolicy.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.effectivepolicy.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">serviceusage.groups.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">serviceusage.groups.list</code></li>
<li><code translate="no" dir="ltr">serviceusage.groups.listExpandedMembers</code></li>
<li><code translate="no" dir="ltr">serviceusage.groups.listMembers</code></li>
</ul>
<p><code translate="no" dir="ltr">serviceusage.quotas.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.list</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.listApis</code></p>
<p><code translate="no" dir="ltr">serviceusage.values.test</code></p></td>
</tr>
</tbody>
</table>

### Service agent roles

Service agent roles should only be granted to [service agents](/iam/docs/service-agents).

<div results-count-container="">

</div>

<table class="fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="50%">Role</th>
<th>Permissions</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td class="role-description"><h4 id="cloudfunctions.serviceAgent" class="role-title add-link" data-text="(Deprecated) Cloud Functions Service Agent " tabindex="-1">(Deprecated) Cloud Functions Service Agent</h4>
<p>(<code translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</p>
<span class="role-description custom"> </span>
<p>Gives Cloud Functions service account access to managed resources.</p>
<p>This role applies to functions created using the Cloud Functions API. For functions created using Cloud Run, refer to the <a href="/iam/docs/roles-permissions/run">Cloud Run roles and permissions</a> page.</p>
<strong>Warning:</strong> Do not grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.</td>
<td class="role-permissions"><p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.aptartifacts.create</code></li>
<li><code translate="no" dir="ltr">artifactregistry.attachments.create</code></li>
<li><code translate="no" dir="ltr">artifactregistry.attachments.delete</code></li>
<li><code translate="no" dir="ltr">artifactregistry.attachments.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.attachments.list</code></li>
<li><code translate="no" dir="ltr">artifactregistry.dockerimages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.dockerimages.list</code></li>
<li><code translate="no" dir="ltr">artifactregistry.files.delete</code></li>
<li><code translate="no" dir="ltr">artifactregistry.files.download</code></li>
<li><code translate="no" dir="ltr">artifactregistry.files.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.files.list</code></li>
<li><code translate="no" dir="ltr">artifactregistry.files.update</code></li>
<li><code translate="no" dir="ltr">artifactregistry.files.upload</code></li>
<li><code translate="no" dir="ltr">artifactregistry.kfpartifacts.create</code></li>
<li><code translate="no" dir="ltr">artifactregistry.locations.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.locations.list</code></li>
<li><code translate="no" dir="ltr">artifactregistry.mavenartifacts.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.mavenartifacts.list</code></li>
<li><code translate="no" dir="ltr">artifactregistry.npmpackages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.npmpackages.list</code></li>
<li><code translate="no" dir="ltr">artifactregistry.packages.delete</code></li>
<li><code translate="no" dir="ltr">artifactregistry.packages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.packages.list</code></li>
<li><code translate="no" dir="ltr">artifactregistry.packages.update</code></li>
<li><code translate="no" dir="ltr">artifactregistry.projectconfigs.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.projectconfigs.update</code></li>
<li><code translate="no" dir="ltr">artifactregistry.projectsettings.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.projectsettings.update</code></li>
<li><code translate="no" dir="ltr">artifactregistry.pythonpackages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.pythonpackages.list</code></li>
<li><code translate="no" dir="ltr">artifactregistry.repositories.create</code></li>
<li><code translate="no" dir="ltr">artifactregistry.repositories.createOnPush</code></li>
<li><code translate="no" dir="ltr">artifactregistry.repositories.createTagBinding</code></li>
<li><code translate="no" dir="ltr">artifactregistry.repositories.delete</code></li>
<li><code translate="no" dir="ltr">artifactregistry.repositories.deleteArtifacts</code></li>
<li><code translate="no" dir="ltr">artifactregistry.repositories.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">artifactregistry.repositories.downloadArtifacts</code></li>
<li><code translate="no" dir="ltr">artifactregistry.repositories.exportArtifacts</code></li>
<li><code translate="no" dir="ltr">artifactregistry.repositories.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.repositories.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">artifactregistry.repositories.list</code></li>
<li><code translate="no" dir="ltr">artifactregistry.repositories.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">artifactregistry.repositories.listTagBindings</code></li>
<li><code translate="no" dir="ltr">artifactregistry.repositories.readViaVirtualRepository</code></li>
<li><code translate="no" dir="ltr">artifactregistry.repositories.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">artifactregistry.repositories.update</code></li>
<li><code translate="no" dir="ltr">artifactregistry.repositories.uploadArtifacts</code></li>
<li><code translate="no" dir="ltr">artifactregistry.rules.create</code></li>
<li><code translate="no" dir="ltr">artifactregistry.rules.delete</code></li>
<li><code translate="no" dir="ltr">artifactregistry.rules.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.rules.list</code></li>
<li><code translate="no" dir="ltr">artifactregistry.rules.update</code></li>
<li><code translate="no" dir="ltr">artifactregistry.tags.create</code></li>
<li><code translate="no" dir="ltr">artifactregistry.tags.delete</code></li>
<li><code translate="no" dir="ltr">artifactregistry.tags.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.tags.list</code></li>
<li><code translate="no" dir="ltr">artifactregistry.tags.update</code></li>
<li><code translate="no" dir="ltr">artifactregistry.versions.delete</code></li>
<li><code translate="no" dir="ltr">artifactregistry.versions.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.versions.list</code></li>
<li><code translate="no" dir="ltr">artifactregistry.versions.update</code></li>
<li><code translate="no" dir="ltr">artifactregistry.yumartifacts.create</code></li>
</ul>
<p><code translate="no" dir="ltr">clientauthconfig.clients.list</code></p>
<p><code translate="no" dir="ltr">cloudbuild.builds.create</code></p>
<p><code translate="no" dir="ltr">cloudbuild.builds.get</code></p>
<p><code translate="no" dir="ltr">cloudbuild.builds.list</code></p>
<p><code translate="no" dir="ltr">cloudbuild.builds.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudbuild.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudbuild.locations.get</code></li>
<li><code translate="no" dir="ltr">cloudbuild.locations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudbuild.operations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudbuild.operations.get</code></li>
<li><code translate="no" dir="ltr">cloudbuild.operations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">cloudbuild.workerpools.use</code></p>
<p><code translate="no" dir="ltr">cloudfunctions.functions.get</code></p>
<p><code translate="no" dir="ltr">cloudfunctions.functions.invoke</code></p>
<p><code translate="no" dir="ltr">cloudfunctions.functions.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudfunctions.operations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudfunctions.operations.get</code></li>
<li><code translate="no" dir="ltr">cloudfunctions.operations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">compute.globalOperations.get</code></p>
<p><code translate="no" dir="ltr">compute.networks.access</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.create</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.delete</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.get</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.list</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.listTagBindings</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.publish</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.attach</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.create</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.delete</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.get</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.list</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.listTagBindings</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.publish</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.undelete</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.update</code></p>
<p><code translate="no" dir="ltr">eventarc.enrollments.create</code></p>
<p><code translate="no" dir="ltr">eventarc.enrollments.delete</code></p>
<p><code translate="no" dir="ltr">eventarc.enrollments.get</code></p>
<p><code translate="no" dir="ltr">eventarc.enrollments.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.enrollments.list</code></p>
<p><code translate="no" dir="ltr">eventarc.enrollments.update</code></p>
<p><code translate="no" dir="ltr">eventarc.googleApiSources.create</code></p>
<p><code translate="no" dir="ltr">eventarc.googleApiSources.delete</code></p>
<p><code translate="no" dir="ltr">eventarc.googleApiSources.get</code></p>
<p><code translate="no" dir="ltr">eventarc.googleApiSources.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.googleApiSources.list</code></p>
<p><code translate="no" dir="ltr">eventarc.googleApiSources.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">eventarc.googleChannelConfigs.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">eventarc.googleChannelConfigs.get</code></li>
<li><code translate="no" dir="ltr">eventarc.googleChannelConfigs.update</code></li>
</ul>
<p><code translate="no" dir="ltr">eventarc.kafkaSources.create</code></p>
<p><code translate="no" dir="ltr">eventarc.kafkaSources.delete</code></p>
<p><code translate="no" dir="ltr">eventarc.kafkaSources.get</code></p>
<p><code translate="no" dir="ltr">eventarc.kafkaSources.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.kafkaSources.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">eventarc.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">eventarc.locations.get</code></li>
<li><code translate="no" dir="ltr">eventarc.locations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">eventarc.operations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">eventarc.operations.cancel</code></li>
<li><code translate="no" dir="ltr">eventarc.operations.delete</code></li>
<li><code translate="no" dir="ltr">eventarc.operations.get</code></li>
<li><code translate="no" dir="ltr">eventarc.operations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">eventarc.pipelines.create</code></p>
<p><code translate="no" dir="ltr">eventarc.pipelines.delete</code></p>
<p><code translate="no" dir="ltr">eventarc.pipelines.get</code></p>
<p><code translate="no" dir="ltr">eventarc.pipelines.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.pipelines.list</code></p>
<p><code translate="no" dir="ltr">eventarc.pipelines.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">eventarc.providers.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">eventarc.providers.get</code></li>
<li><code translate="no" dir="ltr">eventarc.providers.list</code></li>
</ul>
<p><code translate="no" dir="ltr">eventarc.triggers.create</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.delete</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.get</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.list</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.listTagBindings</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.undelete</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.update</code></p>
<p><code translate="no" dir="ltr">firebasedatabase.instances.get</code></p>
<p><code translate="no" dir="ltr">firebasedatabase.instances.update</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.actAs</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.getAccessToken</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.getOpenIdToken</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.signBlob</code></p>
<p><code translate="no" dir="ltr">pubsub.subscriptions.consume</code></p>
<p><code translate="no" dir="ltr">pubsub.subscriptions.create</code></p>
<p><code translate="no" dir="ltr">pubsub.subscriptions.delete</code></p>
<p><code translate="no" dir="ltr">pubsub.subscriptions.get</code></p>
<p><code translate="no" dir="ltr">pubsub.subscriptions.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">pubsub.subscriptions.list</code></p>
<p><code translate="no" dir="ltr">pubsub.subscriptions.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">pubsub.subscriptions.listTagBindings</code></p>
<p><code translate="no" dir="ltr">pubsub.subscriptions.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">pubsub.subscriptions.update</code></p>
<p><code translate="no" dir="ltr">pubsub.topics.attachSubscription</code></p>
<p><code translate="no" dir="ltr">pubsub.topics.create</code></p>
<p><code translate="no" dir="ltr">pubsub.topics.get</code></p>
<p><code translate="no" dir="ltr">pubsub.topics.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.locations.get</code></li>
<li><code translate="no" dir="ltr">recommender.locations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServiceCostInsights.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServiceCostInsights.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceCostInsights.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceCostInsights.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServiceCostRecommendations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServiceCostRecommendations.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceCostRecommendations.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceCostRecommendations.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServiceIdentityInsights.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServiceIdentityInsights.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceIdentityInsights.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceIdentityInsights.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServiceIdentityRecommendations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServiceIdentityRecommendations.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceIdentityRecommendations.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceIdentityRecommendations.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServicePerformanceInsights.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServicePerformanceInsights.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServicePerformanceInsights.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServicePerformanceInsights.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServicePerformanceRecommendations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServicePerformanceRecommendations.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServicePerformanceRecommendations.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServicePerformanceRecommendations.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServiceSecurityInsights.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServiceSecurityInsights.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceSecurityInsights.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceSecurityInsights.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServiceSecurityRecommendations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServiceSecurityRecommendations.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceSecurityRecommendations.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceSecurityRecommendations.update</code></li>
</ul>
<p><code translate="no" dir="ltr">remotebuildexecution.blobs.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">run.configurations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">run.configurations.get</code></li>
<li><code translate="no" dir="ltr">run.configurations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">run.executions.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">run.executions.cancel</code></li>
<li><code translate="no" dir="ltr">run.executions.delete</code></li>
<li><code translate="no" dir="ltr">run.executions.get</code></li>
<li><code translate="no" dir="ltr">run.executions.list</code></li>
</ul>
<p><code translate="no" dir="ltr">run.instances.create</code></p>
<p><code translate="no" dir="ltr">run.instances.delete</code></p>
<p><code translate="no" dir="ltr">run.instances.get</code></p>
<p><code translate="no" dir="ltr">run.instances.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">run.instances.invoke</code></p>
<p><code translate="no" dir="ltr">run.instances.list</code></p>
<p><code translate="no" dir="ltr">run.instances.sshRead</code></p>
<p><code translate="no" dir="ltr">run.instances.sshRoot</code></p>
<p><code translate="no" dir="ltr">run.instances.start</code></p>
<p><code translate="no" dir="ltr">run.instances.stop</code></p>
<p><code translate="no" dir="ltr">run.instances.update</code></p>
<p><code translate="no" dir="ltr">run.jobs.create</code></p>
<p><code translate="no" dir="ltr">run.jobs.delete</code></p>
<p><code translate="no" dir="ltr">run.jobs.get</code></p>
<p><code translate="no" dir="ltr">run.jobs.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">run.jobs.list</code></p>
<p><code translate="no" dir="ltr">run.jobs.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">run.jobs.listTagBindings</code></p>
<p><code translate="no" dir="ltr">run.jobs.run</code></p>
<p><code translate="no" dir="ltr">run.jobs.runWithOverrides</code></p>
<p><code translate="no" dir="ltr">run.jobs.sshRead</code></p>
<p><code translate="no" dir="ltr">run.jobs.sshRoot</code></p>
<p><code translate="no" dir="ltr">run.jobs.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">run.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">run.locations.list</code></li>
<li><code translate="no" dir="ltr">run.locations.uploadSource</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">run.operations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">run.operations.delete</code></li>
<li><code translate="no" dir="ltr">run.operations.get</code></li>
<li><code translate="no" dir="ltr">run.operations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">run.prompts.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">run.revisions.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">run.revisions.delete</code></li>
<li><code translate="no" dir="ltr">run.revisions.get</code></li>
<li><code translate="no" dir="ltr">run.revisions.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">run.routes.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">run.routes.get</code></li>
<li><code translate="no" dir="ltr">run.routes.invoke</code></li>
<li><code translate="no" dir="ltr">run.routes.list</code></li>
</ul>
<p><code translate="no" dir="ltr">run.services.create</code></p>
<p><code translate="no" dir="ltr">run.services.delete</code></p>
<p><code translate="no" dir="ltr">run.services.get</code></p>
<p><code translate="no" dir="ltr">run.services.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">run.services.list</code></p>
<p><code translate="no" dir="ltr">run.services.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">run.services.listTagBindings</code></p>
<p><code translate="no" dir="ltr">run.services.sshRead</code></p>
<p><code translate="no" dir="ltr">run.services.sshRoot</code></p>
<p><code translate="no" dir="ltr">run.services.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">run.tasks.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">run.tasks.get</code></li>
<li><code translate="no" dir="ltr">run.tasks.list</code></li>
</ul>
<p><code translate="no" dir="ltr">run.workerpools.create</code></p>
<p><code translate="no" dir="ltr">run.workerpools.delete</code></p>
<p><code translate="no" dir="ltr">run.workerpools.get</code></p>
<p><code translate="no" dir="ltr">run.workerpools.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">run.workerpools.list</code></p>
<p><code translate="no" dir="ltr">run.workerpools.sshRead</code></p>
<p><code translate="no" dir="ltr">run.workerpools.sshRoot</code></p>
<p><code translate="no" dir="ltr">run.workerpools.update</code></p>
<p><code translate="no" dir="ltr">serviceusage.catalogs.listMembers</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">serviceusage.consumerpolicy.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">serviceusage.consumerpolicy.analyze</code></li>
<li><code translate="no" dir="ltr">serviceusage.consumerpolicy.get</code></li>
<li><code translate="no" dir="ltr">serviceusage.consumerpolicy.update</code></li>
</ul>
<p><code translate="no" dir="ltr">serviceusage.effectivepolicy.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">serviceusage.groups.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">serviceusage.groups.list</code></li>
<li><code translate="no" dir="ltr">serviceusage.groups.listExpandedMembers</code></li>
<li><code translate="no" dir="ltr">serviceusage.groups.listMembers</code></li>
</ul>
<p><code translate="no" dir="ltr">serviceusage.quotas.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.disable</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.enable</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.listApis</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.listDependentServices</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.use</code></p>
<p><code translate="no" dir="ltr">serviceusage.values.test</code></p>
<p><code translate="no" dir="ltr">source.repos.get</code></p>
<p><code translate="no" dir="ltr">source.repos.list</code></p>
<p><code translate="no" dir="ltr">storage.buckets.create</code></p>
<p><code translate="no" dir="ltr">storage.buckets.delete</code></p>
<p><code translate="no" dir="ltr">storage.buckets.get</code></p>
<p><code translate="no" dir="ltr">storage.buckets.update</code></p>
<p><code translate="no" dir="ltr">storage.objects.create</code></p>
<p><code translate="no" dir="ltr">storage.objects.delete</code></p>
<p><code translate="no" dir="ltr">storage.objects.get</code></p>
<p><code translate="no" dir="ltr">storage.objects.list</code></p>
<p><code translate="no" dir="ltr">vpcaccess.connectors.get</code></p></td>
</tr>
</tbody>
</table>

## Cloud Run functions permissions

<div results-count-container="">

</div>

<table class="permissions-table fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="45%">Permission</th>
<th>Included in roles</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td><h4 id="cloudfunctions.functions.call" class="permission-name add-link" data-text="cloudfunctions.functions.call" tabindex="-1"><code translate="no" dir="ltr">cloudfunctions.functions.call</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="cloudfunctions.functions.create" class="permission-name add-link" data-text="cloudfunctions.functions.create" tabindex="-1"><code translate="no" dir="ltr">cloudfunctions.functions.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="cloudfunctions.functions.delete" class="permission-name add-link" data-text="cloudfunctions.functions.delete" tabindex="-1"><code translate="no" dir="ltr">cloudfunctions.functions.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="cloudfunctions.functions.generationUpgrade" class="permission-name add-link" data-text="cloudfunctions.functions.generationUpgrade" tabindex="-1"><code translate="no" dir="ltr">cloudfunctions.functions.generationUpgrade</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="cloudfunctions.functions.get" class="permission-name add-link" data-text="cloudfunctions.functions.get" tabindex="-1"><code translate="no" dir="ltr">cloudfunctions.functions.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.serverlessImageRegistryScanner">Wiz Serverless &amp; Container Image Registry Scanner</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.serverlessImageRegistryScanner</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/monitoring#monitoring.notificationServiceAgent">Monitoring Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/monitoring.notificationServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visionai#visionai.serviceAgent">Cloud Vision AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visionai.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="cloudfunctions.functions.getIamPolicy" class="permission-name add-link" data-text="cloudfunctions.functions.getIamPolicy" tabindex="-1"><code translate="no" dir="ltr">cloudfunctions.functions.getIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasemods#firebasemods.serviceAgent">Firebase Extensions API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasemods.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="cloudfunctions.functions.invoke" class="permission-name add-link" data-text="cloudfunctions.functions.invoke" tabindex="-1"><code translate="no" dir="ltr">cloudfunctions.functions.invoke</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.invoker">Cloud Functions Invoker</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.invoker</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/ces#ces.serviceAgent">Customer Engagement Suite Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ces.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/contentwarehouse#contentwarehouse.serviceAgent">Content Warehouse Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/contentwarehouse.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dialogflow#dialogflow.serviceAgent">Dialogflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dialogflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/identitytoolkit#identitytoolkit.serviceAgent">Identity Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/identitytoolkit.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/integrations#integrations.serviceAgent">Application Integration Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visionai#visionai.serviceAgent">Cloud Vision AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visionai.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="cloudfunctions.functions.list" class="permission-name add-link" data-text="cloudfunctions.functions.list" tabindex="-1"><code translate="no" dir="ltr">cloudfunctions.functions.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visionai#visionai.serviceAgent">Cloud Vision AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visionai.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="cloudfunctions.functions.setIamPolicy" class="permission-name add-link" data-text="cloudfunctions.functions.setIamPolicy" tabindex="-1"><code translate="no" dir="ltr">cloudfunctions.functions.setIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/firebasemods#firebasemods.serviceAgent">Firebase Extensions API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasemods.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="cloudfunctions.functions.sourceCodeGet" class="permission-name add-link" data-text="cloudfunctions.functions.sourceCodeGet" tabindex="-1"><code translate="no" dir="ltr">cloudfunctions.functions.sourceCodeGet</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.serverlessImageRegistryScanner">Wiz Serverless &amp; Container Image Registry Scanner</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.serverlessImageRegistryScanner</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="cloudfunctions.functions.sourceCodeSet" class="permission-name add-link" data-text="cloudfunctions.functions.sourceCodeSet" tabindex="-1"><code translate="no" dir="ltr">cloudfunctions.functions.sourceCodeSet</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="cloudfunctions.functions.update" class="permission-name add-link" data-text="cloudfunctions.functions.update" tabindex="-1"><code translate="no" dir="ltr">cloudfunctions.functions.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="cloudfunctions.locations.list" class="permission-name add-link" data-text="cloudfunctions.locations.list" tabindex="-1"><code translate="no" dir="ltr">cloudfunctions.locations.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="cloudfunctions.operations.get" class="permission-name add-link" data-text="cloudfunctions.operations.get" tabindex="-1"><code translate="no" dir="ltr">cloudfunctions.operations.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="cloudfunctions.operations.list" class="permission-name add-link" data-text="cloudfunctions.operations.list" tabindex="-1"><code translate="no" dir="ltr">cloudfunctions.operations.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
</ul></td>
</tr>
</tbody>
</table>

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
