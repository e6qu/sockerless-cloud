# Where (Transformation Stage)

<div class="devsite-article-body clearfix devsite-no-page-title">

# Where (Transformation Stage)

## Description

Filters the documents from the previous stage, returning only the documents where the condition evaluates to `true`.

## Examples

<div class="ds-selector-tabs" ds-scope="lang">

<div class="section">

### <span class="two-line-tab"><span tab-label="modular API"></span>Web</span>

<div>

</div>

``` devsite-click-to-copy
let results;

results = await execute(db.pipeline().collection("books")
  .where(field("rating").equal(5))
  .where(field("published").lessThan(1900))
);

results = await execute(db.pipeline().collection("books")
  .where(and(field("rating").equal(5), field("published").lessThan(1900)))
);test.firestore.js
```

</div>

<div class="section">

##### Swift

<div>

</div>

``` devsite-click-to-copy
var results: Pipeline.Snapshot

results = try await db.pipeline().collection("books")
  .where(Field("rating").equal(5))
  .where(Field("published").lessThan(1900))
  .execute()

results = try await db.pipeline().collection("books")
  .where(Field("rating").equal(5) && Field("published").lessThan(1900))
  .execute()PipelineSnippets.swift
```

</div>

<div class="section">

##### <span class="two-line-tab">Kotlin <span class="firebase-platform-label">Android</span></span>

<div>

</div>

``` devsite-click-to-copy
var results: Task<Pipeline.Snapshot>

results = db.pipeline().collection("books")
    .where(field("rating").equal(5))
    .where(field("published").lessThan(1900))
    .execute()

results = db.pipeline().collection("books")
    .where(Expression.and(field("rating").equal(5),
      field("published").lessThan(1900)))
    .execute()DocSnippets.kt
```

</div>

<div class="section">

##### <span class="two-line-tab">Java <span class="firebase-platform-label">Android</span></span>

<div>

</div>

``` devsite-click-to-copy
Task<Pipeline.Snapshot> results;

results = db.pipeline().collection("books")
    .where(field("rating").equal(5))
    .where(field("published").lessThan(1900))
    .execute();

results = db.pipeline().collection("books")
    .where(Expression.and(
        field("rating").equal(5),
        field("published").lessThan(1900)
    ))
    .execute();DocSnippets.java
```

</div>

<div class="section">

##### Python

<div>

</div>

``` devsite-click-to-copy
from google.cloud.firestore_v1.pipeline_expressions import And, Field

results = (
    client.pipeline()
    .collection("books")
    .where(Field.of("rating").equal(5))
    .where(Field.of("published").less_than(1900))
    .execute()
)

results = (
    client.pipeline()
    .collection("books")
    .where(And(Field.of("rating").equal(5), Field.of("published").less_than(1900)))
    .execute()
)firestore_pipelines.py
```

</div>

<div class="section">

##### Java

<div>

</div>

``` devsite-click-to-copy
Pipeline.Snapshot results1 =
    firestore
        .pipeline()
        .collection("books")
        .where(field("rating").equal(5))
        .where(field("published").lessThan(1900))
        .execute()
        .get();

Pipeline.Snapshot results2 =
    firestore
        .pipeline()
        .collection("books")
        .where(and(field("rating").equal(5), field("published").lessThan(1900)))
        .execute()
        .get();PipelineSnippets.java
```

</div>

<div class="section">

##### Go

<div>

</div>

``` devsite-click-to-copy
results1, err := client.Pipeline().
 Collection("books").
 Where(firestore.FieldOf("rating").Equal(5)).
 Where(firestore.FieldOf("published").LessThan(1900)).
 Execute(ctx).Results().GetAll()
if err != nil {
 fmt.Fprintf(w, "GetAll failed: %v", err)
 return err
}

results2, err := client.Pipeline().
 Collection("books").
 Where(firestore.And(
     firestore.FieldOf("rating").Equal(5),
     firestore.FieldOf("published").LessThan(1900),
 )).
 Execute(ctx).Results().GetAll()
if err != nil {
 fmt.Fprintf(w, "GetAll failed: %v", err)
 return err
}pipeline_snippets_general.go
```

</div>

</div>

## Behavior

### Chained versus Nested Filters

Multiple `where(...)` stages can be chained together, which is logically equivalent to combining the filter conditions within a single `where(...)` stage using an `and(...)` expression. Both approaches produce the same execution plan and have no impact on query execution or performance.

For example, chaining multiple `where(...)` stages:

<div>

<div class="section">

### Node.js

<div>

</div>

``` devsite-click-to-copy
const cities = await db.pipeline()
  .collection("/cities")
  .where(field("location.country").equals("USA"))
  .where(field("population").greaterThan(500000))
  .execute();
```

</div>

</div>

is equivalent to using a single `where(...)` stage with a compound `and(...)`:

<div>

<div class="section">

### Node.js

<div>

</div>

``` devsite-click-to-copy
const cities = await db.pipeline()
  .collection("/cities")
  .where(
    field("location.country").equals("USA")
      .and(field("population").greaterThan(500000)))
  .execute();
```

</div>

</div>

However, filtering based on a logical `or(...)` of conditions cannot be split across multiple stages and must be done in a single `where(...)` stage:

<div>

<div class="section">

### Node.js

<div>

</div>

``` devsite-click-to-copy
const cities = await db.pipeline()
  .collection("/cities")
  .where(
    field("location.state").equals("NY")
      .or(field("location.state").equals("CA")))
  .execute();
```

</div>

</div>

### Complex Expressions

The filter condition can contain complex filter conditions containing deeply nested expressions and logical operators. For example:

<div>

<div class="section">

### Node.js

<div>

</div>

``` devsite-click-to-copy
const cities = await db.pipeline()
  .collection("/cities")
  .where(
    field("name").like("San%")
    .or(
      field("location.state").charLength().greaterThan(7)
      .and(field("location.country").equals("USA"))))
```

</div>

</div>

filters `/cities` based on a regular expression, or if the city is in the `USA` with a long enough state name. Any expression can be given as the condition, but will only match those which evaluate to `true`.

### Stage Ordering

The order of stages is important as it can change the query evaluation order. For example the query:

<div>

<div class="section">

### Node.js

<div>

</div>

``` devsite-click-to-copy
const cities = await db.pipeline()
  .collection("/cities")
  .limit(10)
  .where(field("location.country").equals("USA"))
  .execute();
```

</div>

</div>

will only filter on `location.country` for a (potentially random) set of 10 documents as the prior [`limit(...)`](/firestore/native/docs/pipeline/stages/transformation/limit) stage is restricting the documents that are ever provided to the `where(...)` stage. Given this, the rule of thumb is to put the `where(...)` stages as early in the query as possible.

**`HAVING`-Like Functionality:**

The `where(...)` stage can come after any stage that changes the schema of the documents, like [`select(...)`](/firestore/native/docs/pipeline/stages/transformation/select) or [`aggregate(...)`](/firestore/native/docs/pipeline/stages/transformation/aggregate) and will refer to the fields produced from those stages. Importantly for [`aggregate(...)`](/firestore/native/docs/pipeline/stages/transformation/aggregate), a following `where(...)` clause that refers to the accumulated fields acts like a `HAVING` clause in a typical SQL system. For example:

<div>

<div class="section">

### Node.js

<div>

</div>

``` devsite-click-to-copy
const cities = await db.pipeline()
  .collection("/cities")
  .aggregate({
    accumulators: [field("population").sum().as("total_population")],
    groups: ["location.state"]
  })
  .where(field("total_population").greaterThan(10000000))
```

</div>

</div>

allows returning the states which have cities over a total population size.

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
