# Mathematical functions

<div class="devsite-article-body clearfix">

GoogleSQL for BigQuery supports mathematical functions. All mathematical functions have the following behaviors:

- They return `NULL` if any of the input parameters is `NULL`.
- They return `NaN` if any of the arguments is `NaN`.

## Categories

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th>Category</th>
<th>Functions</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td>Trigonometric</td>
<td><a href="#acos"><code translate="no" dir="ltr">ACOS</code></a>   <a href="#acosh"><code translate="no" dir="ltr">ACOSH</code></a>   <a href="#asin"><code translate="no" dir="ltr">ASIN</code></a>   <a href="#asinh"><code translate="no" dir="ltr">ASINH</code></a>   <a href="#atan"><code translate="no" dir="ltr">ATAN</code></a>   <a href="#atan2"><code translate="no" dir="ltr">ATAN2</code></a>   <a href="#atanh"><code translate="no" dir="ltr">ATANH</code></a>   <a href="#cos"><code translate="no" dir="ltr">COS</code></a>   <a href="#cosh"><code translate="no" dir="ltr">COSH</code></a>   <a href="#cot"><code translate="no" dir="ltr">COT</code></a>   <a href="#coth"><code translate="no" dir="ltr">COTH</code></a>   <a href="#csc"><code translate="no" dir="ltr">CSC</code></a>   <a href="#csch"><code translate="no" dir="ltr">CSCH</code></a>   <a href="#sec"><code translate="no" dir="ltr">SEC</code></a>   <a href="#sech"><code translate="no" dir="ltr">SECH</code></a>   <a href="#sin"><code translate="no" dir="ltr">SIN</code></a>   <a href="#sinh"><code translate="no" dir="ltr">SINH</code></a>   <a href="#tan"><code translate="no" dir="ltr">TAN</code></a>   <a href="#tanh"><code translate="no" dir="ltr">TANH</code></a>  </td>
</tr>
<tr class="even">
<td>Exponential and<br />
logarithmic</td>
<td><a href="#exp"><code translate="no" dir="ltr">EXP</code></a>   <a href="#ln"><code translate="no" dir="ltr">LN</code></a>   <a href="#log"><code translate="no" dir="ltr">LOG</code></a>   <a href="#log10"><code translate="no" dir="ltr">LOG10</code></a>  </td>
</tr>
<tr class="odd">
<td>Rounding and<br />
truncation</td>
<td><a href="#ceil"><code translate="no" dir="ltr">CEIL</code></a>   <a href="#ceiling"><code translate="no" dir="ltr">CEILING</code></a>   <a href="#floor"><code translate="no" dir="ltr">FLOOR</code></a>   <a href="#round"><code translate="no" dir="ltr">ROUND</code></a>   <a href="#trunc"><code translate="no" dir="ltr">TRUNC</code></a>  </td>
</tr>
<tr class="even">
<td>Power and<br />
root</td>
<td><a href="#cbrt"><code translate="no" dir="ltr">CBRT</code></a>   <a href="#pow"><code translate="no" dir="ltr">POW</code></a>   <a href="#power"><code translate="no" dir="ltr">POWER</code></a>   <a href="#sqrt"><code translate="no" dir="ltr">SQRT</code></a>  </td>
</tr>
<tr class="odd">
<td>Sign</td>
<td><a href="#abs"><code translate="no" dir="ltr">ABS</code></a>   <a href="#sign"><code translate="no" dir="ltr">SIGN</code></a>  </td>
</tr>
<tr class="even">
<td>Distance</td>
<td><a href="#cosine_distance"><code translate="no" dir="ltr">COSINE_DISTANCE</code></a>   <a href="#euclidean_distance"><code translate="no" dir="ltr">EUCLIDEAN_DISTANCE</code></a>  </td>
</tr>
<tr class="odd">
<td>Comparison</td>
<td><a href="#greatest"><code translate="no" dir="ltr">GREATEST</code></a>   <a href="#least"><code translate="no" dir="ltr">LEAST</code></a>  </td>
</tr>
<tr class="even">
<td>Random number generator</td>
<td><a href="#rand"><code translate="no" dir="ltr">RAND</code></a>  </td>
</tr>
<tr class="odd">
<td>Arithmetic and error handling</td>
<td><a href="#div"><code translate="no" dir="ltr">DIV</code></a>   <a href="#ieee_divide"><code translate="no" dir="ltr">IEEE_DIVIDE</code></a>   <a href="#is_inf"><code translate="no" dir="ltr">IS_INF</code></a>   <a href="#is_nan"><code translate="no" dir="ltr">IS_NAN</code></a>   <a href="#mod"><code translate="no" dir="ltr">MOD</code></a>   <a href="#safe_add"><code translate="no" dir="ltr">SAFE_ADD</code></a>   <a href="#safe_divide"><code translate="no" dir="ltr">SAFE_DIVIDE</code></a>   <a href="#safe_multiply"><code translate="no" dir="ltr">SAFE_MULTIPLY</code></a>   <a href="#safe_negate"><code translate="no" dir="ltr">SAFE_NEGATE</code></a>   <a href="#safe_subtract"><code translate="no" dir="ltr">SAFE_SUBTRACT</code></a>  </td>
</tr>
<tr class="even">
<td>Bucket</td>
<td><a href="#range_bucket"><code translate="no" dir="ltr">RANGE_BUCKET</code></a>  </td>
</tr>
</tbody>
</table>

## Function list

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th>Name</th>
<th>Summary</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td><a href="/bigquery/docs/reference/standard-sql/mathematical_functions#abs"><code translate="no" dir="ltr">ABS</code></a></td>
<td>Computes the absolute value of <code translate="no" dir="ltr">X</code>.</td>
</tr>
<tr class="even">
<td><a href="/bigquery/docs/reference/standard-sql/mathematical_functions#acos"><code translate="no" dir="ltr">ACOS</code></a></td>
<td>Computes the inverse cosine of <code translate="no" dir="ltr">X</code>.</td>
</tr>
<tr class="odd">
<td><a href="/bigquery/docs/reference/standard-sql/mathematical_functions#acosh"><code translate="no" dir="ltr">ACOSH</code></a></td>
<td>Computes the inverse hyperbolic cosine of <code translate="no" dir="ltr">X</code>.</td>
</tr>
<tr class="even">
<td><a href="/bigquery/docs/reference/standard-sql/mathematical_functions#asin"><code translate="no" dir="ltr">ASIN</code></a></td>
<td>Computes the inverse sine of <code translate="no" dir="ltr">X</code>.</td>
</tr>
<tr class="odd">
<td><a href="/bigquery/docs/reference/standard-sql/mathematical_functions#asinh"><code translate="no" dir="ltr">ASINH</code></a></td>
<td>Computes the inverse hyperbolic sine of <code translate="no" dir="ltr">X</code>.</td>
</tr>
<tr class="even">
<td><a href="/bigquery/docs/reference/standard-sql/mathematical_functions#atan"><code translate="no" dir="ltr">ATAN</code></a></td>
<td>Computes the inverse tangent of <code translate="no" dir="ltr">X</code>.</td>
</tr>
<tr class="odd">
<td><a href="/bigquery/docs/reference/standard-sql/mathematical_functions#atan2"><code translate="no" dir="ltr">ATAN2</code></a></td>
<td>Computes the inverse tangent of <code translate="no" dir="ltr">X/Y</code>, using the signs of <code translate="no" dir="ltr">X</code> and <code translate="no" dir="ltr">Y</code> to determine the quadrant.</td>
</tr>
<tr class="even">
<td><a href="/bigquery/docs/reference/standard-sql/mathematical_functions#atanh"><code translate="no" dir="ltr">ATANH</code></a></td>
<td>Computes the inverse hyperbolic tangent of <code translate="no" dir="ltr">X</code>.</td>
</tr>
<tr class="odd">
<td><a href="/bigquery/docs/reference/standard-sql/aggregate_functions#avg"><code translate="no" dir="ltr">AVG</code></a></td>
<td>Gets the average of non-<code translate="no" dir="ltr">NULL</code> values.<br />
For more information, see <a href="/bigquery/docs/reference/standard-sql/aggregate_functions">Aggregate functions</a>.</td>
</tr>
<tr class="even">
<td><a href="/bigquery/docs/reference/standard-sql/aggregate-dp-functions#dp_avg"><code translate="no" dir="ltr">AVG</code> (Differential Privacy)</a></td>
<td><code translate="no" dir="ltr">DIFFERENTIAL_PRIVACY</code>-supported <code translate="no" dir="ltr">AVG</code>.<br />
<br />
Gets the differentially-private average of non-<code translate="no" dir="ltr">NULL</code>, non-<code translate="no" dir="ltr">NaN</code> values in a query with a <code translate="no" dir="ltr">DIFFERENTIAL_PRIVACY</code> clause.<br />
<br />
For more information, see <a href="/bigquery/docs/reference/standard-sql/aggregate-dp-functions">Differential privacy functions</a>.</td>
</tr>
<tr class="odd">
<td><a href="/bigquery/docs/reference/standard-sql/mathematical_functions#cbrt"><code translate="no" dir="ltr">CBRT</code></a></td>
<td>Computes the cube root of <code translate="no" dir="ltr">X</code>.</td>
</tr>
<tr class="even">
<td><a href="/bigquery/docs/reference/standard-sql/mathematical_functions#ceil"><code translate="no" dir="ltr">CEIL</code></a></td>
<td>Gets the smallest integral value that isn't less than <code translate="no" dir="ltr">X</code>.</td>
</tr>
<tr class="odd">
<td><a href="/bigquery/docs/reference/standard-sql/mathematical_functions#ceiling"><code translate="no" dir="ltr">CEILING</code></a></td>
<td>Synonym of <code translate="no" dir="ltr">CEIL</code>.</td>
</tr>
<tr class="even">
<td><a href="/bigquery/docs/reference/standard-sql/mathematical_functions#cos"><code translate="no" dir="ltr">COS</code></a></td>
<td>Computes the cosine of <code translate="no" dir="ltr">X</code>.</td>
</tr>
<tr class="odd">
<td><a href="/bigquery/docs/reference/standard-sql/mathematical_functions#cosh"><code translate="no" dir="ltr">COSH</code></a></td>
<td>Computes the hyperbolic cosine of <code translate="no" dir="ltr">X</code>.</td>
</tr>
<tr class="even">
<td><a href="/bigquery/docs/reference/standard-sql/mathematical_functions#cosine_distance"><code translate="no" dir="ltr">COSINE_DISTANCE</code></a></td>
<td>Computes the cosine distance between two vectors.</td>
</tr>
<tr class="odd">
<td><a href="/bigquery/docs/reference/standard-sql/mathematical_functions#cot"><code translate="no" dir="ltr">COT</code></a></td>
<td>Computes the cotangent of <code translate="no" dir="ltr">X</code>.</td>
</tr>
<tr class="even">
<td><a href="/bigquery/docs/reference/standard-sql/mathematical_functions#coth"><code translate="no" dir="ltr">COTH</code></a></td>
<td>Computes the hyperbolic cotangent of <code translate="no" dir="ltr">X</code>.</td>
</tr>
<tr class="odd">
<td><a href="/bigquery/docs/reference/standard-sql/mathematical_functions#csc"><code translate="no" dir="ltr">CSC</code></a></td>
<td>Computes the cosecant of <code translate="no" dir="ltr">X</code>.</td>
</tr>
<tr class="even">
<td><a href="/bigquery/docs/reference/standard-sql/mathematical_functions#csch"><code translate="no" dir="ltr">CSCH</code></a></td>
<td>Computes the hyperbolic cosecant of <code translate="no" dir="ltr">X</code>.</td>
</tr>
<tr class="odd">
<td><a href="/bigquery/docs/reference/standard-sql/mathematical_functions#div"><code translate="no" dir="ltr">DIV</code></a></td>
<td>Divides integer <code translate="no" dir="ltr">X</code> by integer <code translate="no" dir="ltr">Y</code>.</td>
</tr>
<tr class="even">
<td><a href="/bigquery/docs/reference/standard-sql/mathematical_functions#exp"><code translate="no" dir="ltr">EXP</code></a></td>
<td>Computes <code translate="no" dir="ltr">e</code> to the power of <code translate="no" dir="ltr">X</code>.</td>
</tr>
<tr class="odd">
<td><a href="/bigquery/docs/reference/standard-sql/mathematical_functions#euclidean_distance"><code translate="no" dir="ltr">EUCLIDEAN_DISTANCE</code></a></td>
<td>Computes the Euclidean distance between two vectors.</td>
</tr>
<tr class="even">
<td><a href="/bigquery/docs/reference/standard-sql/mathematical_functions#floor"><code translate="no" dir="ltr">FLOOR</code></a></td>
<td>Gets the largest integral value that isn't greater than <code translate="no" dir="ltr">X</code>.</td>
</tr>
<tr class="odd">
<td><a href="/bigquery/docs/reference/standard-sql/mathematical_functions#greatest"><code translate="no" dir="ltr">GREATEST</code></a></td>
<td>Gets the greatest value among <code translate="no" dir="ltr">X1,...,XN</code>.</td>
</tr>
<tr class="even">
<td><a href="/bigquery/docs/reference/standard-sql/mathematical_functions#ieee_divide"><code translate="no" dir="ltr">IEEE_DIVIDE</code></a></td>
<td>Divides <code translate="no" dir="ltr">X</code> by <code translate="no" dir="ltr">Y</code>, but doesn't generate errors for division by zero or overflow.</td>
</tr>
<tr class="odd">
<td><a href="/bigquery/docs/reference/standard-sql/mathematical_functions#is_inf"><code translate="no" dir="ltr">IS_INF</code></a></td>
<td>Checks if <code translate="no" dir="ltr">X</code> is positive or negative infinity.</td>
</tr>
<tr class="even">
<td><a href="/bigquery/docs/reference/standard-sql/mathematical_functions#is_nan"><code translate="no" dir="ltr">IS_NAN</code></a></td>
<td>Checks if <code translate="no" dir="ltr">X</code> is a <code translate="no" dir="ltr">NaN</code> value.</td>
</tr>
<tr class="odd">
<td><a href="/bigquery/docs/reference/standard-sql/mathematical_functions#least"><code translate="no" dir="ltr">LEAST</code></a></td>
<td>Gets the least value among <code translate="no" dir="ltr">X1,...,XN</code>.</td>
</tr>
<tr class="even">
<td><a href="/bigquery/docs/reference/standard-sql/mathematical_functions#ln"><code translate="no" dir="ltr">LN</code></a></td>
<td>Computes the natural logarithm of <code translate="no" dir="ltr">X</code>.</td>
</tr>
<tr class="odd">
<td><a href="/bigquery/docs/reference/standard-sql/mathematical_functions#log"><code translate="no" dir="ltr">LOG</code></a></td>
<td>Computes the natural logarithm of <code translate="no" dir="ltr">X</code> or the logarithm of <code translate="no" dir="ltr">X</code> to base <code translate="no" dir="ltr">Y</code>.</td>
</tr>
<tr class="even">
<td><a href="/bigquery/docs/reference/standard-sql/mathematical_functions#log10"><code translate="no" dir="ltr">LOG10</code></a></td>
<td>Computes the natural logarithm of <code translate="no" dir="ltr">X</code> to base 10.</td>
</tr>
<tr class="odd">
<td><a href="/bigquery/docs/reference/standard-sql/aggregate_functions#max"><code translate="no" dir="ltr">MAX</code></a></td>
<td>Gets the maximum non-<code translate="no" dir="ltr">NULL</code> value.<br />
For more information, see <a href="/bigquery/docs/reference/standard-sql/aggregate_functions">Aggregate functions</a>.</td>
</tr>
<tr class="even">
<td><a href="/bigquery/docs/reference/standard-sql/aggregate_functions#max_by"><code translate="no" dir="ltr">MAX_BY</code></a></td>
<td>Synonym for <code translate="no" dir="ltr">ANY_VALUE(x HAVING MAX y)</code>.<br />
For more information, see <a href="/bigquery/docs/reference/standard-sql/aggregate_functions">Aggregate functions</a>.</td>
</tr>
<tr class="odd">
<td><a href="/bigquery/docs/reference/standard-sql/aggregate_functions#min_by"><code translate="no" dir="ltr">MIN_BY</code></a></td>
<td>Synonym for <code translate="no" dir="ltr">ANY_VALUE(x HAVING MIN y)</code>.<br />
For more information, see <a href="/bigquery/docs/reference/standard-sql/aggregate_functions">Aggregate functions</a>.</td>
</tr>
<tr class="even">
<td><a href="/bigquery/docs/reference/standard-sql/mathematical_functions#mod"><code translate="no" dir="ltr">MOD</code></a></td>
<td>Gets the remainder of the division of <code translate="no" dir="ltr">X</code> by <code translate="no" dir="ltr">Y</code>.</td>
</tr>
<tr class="odd">
<td><a href="/bigquery/docs/reference/standard-sql/mathematical_functions#pow"><code translate="no" dir="ltr">POW</code></a></td>
<td>Produces the value of <code translate="no" dir="ltr">X</code> raised to the power of <code translate="no" dir="ltr">Y</code>.</td>
</tr>
<tr class="even">
<td><a href="/bigquery/docs/reference/standard-sql/mathematical_functions#power"><code translate="no" dir="ltr">POWER</code></a></td>
<td>Synonym of <code translate="no" dir="ltr">POW</code>.</td>
</tr>
<tr class="odd">
<td><a href="/bigquery/docs/reference/standard-sql/mathematical_functions#rand"><code translate="no" dir="ltr">RAND</code></a></td>
<td>Generates a pseudo-random value of type <code translate="no" dir="ltr">FLOAT64</code> in the range of <code translate="no" dir="ltr">[0, 1)</code>.</td>
</tr>
<tr class="even">
<td><a href="/bigquery/docs/reference/standard-sql/mathematical_functions#range_bucket"><code translate="no" dir="ltr">RANGE_BUCKET</code></a></td>
<td>Scans through a sorted array and returns the 0-based position of a point's upper bound.</td>
</tr>
<tr class="odd">
<td><a href="/bigquery/docs/reference/standard-sql/mathematical_functions#round"><code translate="no" dir="ltr">ROUND</code></a></td>
<td>Rounds <code translate="no" dir="ltr">X</code> to the nearest integer or rounds <code translate="no" dir="ltr">X</code> to <code translate="no" dir="ltr">N</code> decimal places after the decimal point.</td>
</tr>
<tr class="even">
<td><a href="/bigquery/docs/reference/standard-sql/mathematical_functions#safe_add"><code translate="no" dir="ltr">SAFE_ADD</code></a></td>
<td>Equivalent to the addition operator (<code translate="no" dir="ltr">X + Y</code>), but returns <code translate="no" dir="ltr">NULL</code> if overflow occurs.</td>
</tr>
<tr class="odd">
<td><a href="/bigquery/docs/reference/standard-sql/mathematical_functions#safe_divide"><code translate="no" dir="ltr">SAFE_DIVIDE</code></a></td>
<td>Equivalent to the division operator (<code translate="no" dir="ltr">X / Y</code>), but returns <code translate="no" dir="ltr">NULL</code> if an error occurs.</td>
</tr>
<tr class="even">
<td><a href="/bigquery/docs/reference/standard-sql/mathematical_functions#safe_multiply"><code translate="no" dir="ltr">SAFE_MULTIPLY</code></a></td>
<td>Equivalent to the multiplication operator (<code translate="no" dir="ltr">X * Y</code>), but returns <code translate="no" dir="ltr">NULL</code> if overflow occurs.</td>
</tr>
<tr class="odd">
<td><a href="/bigquery/docs/reference/standard-sql/mathematical_functions#safe_negate"><code translate="no" dir="ltr">SAFE_NEGATE</code></a></td>
<td>Equivalent to the unary minus operator (<code translate="no" dir="ltr">-X</code>), but returns <code translate="no" dir="ltr">NULL</code> if overflow occurs.</td>
</tr>
<tr class="even">
<td><a href="/bigquery/docs/reference/standard-sql/mathematical_functions#safe_subtract"><code translate="no" dir="ltr">SAFE_SUBTRACT</code></a></td>
<td>Equivalent to the subtraction operator (<code translate="no" dir="ltr">X - Y</code>), but returns <code translate="no" dir="ltr">NULL</code> if overflow occurs.</td>
</tr>
<tr class="odd">
<td><a href="/bigquery/docs/reference/standard-sql/mathematical_functions#sec"><code translate="no" dir="ltr">SEC</code></a></td>
<td>Computes the secant of <code translate="no" dir="ltr">X</code>.</td>
</tr>
<tr class="even">
<td><a href="/bigquery/docs/reference/standard-sql/mathematical_functions#sech"><code translate="no" dir="ltr">SECH</code></a></td>
<td>Computes the hyperbolic secant of <code translate="no" dir="ltr">X</code>.</td>
</tr>
<tr class="odd">
<td><a href="/bigquery/docs/reference/standard-sql/mathematical_functions#sign"><code translate="no" dir="ltr">SIGN</code></a></td>
<td>Produces -1 , 0, or +1 for negative, zero, and positive arguments respectively.</td>
</tr>
<tr class="even">
<td><a href="/bigquery/docs/reference/standard-sql/mathematical_functions#sin"><code translate="no" dir="ltr">SIN</code></a></td>
<td>Computes the sine of <code translate="no" dir="ltr">X</code>.</td>
</tr>
<tr class="odd">
<td><a href="/bigquery/docs/reference/standard-sql/mathematical_functions#sinh"><code translate="no" dir="ltr">SINH</code></a></td>
<td>Computes the hyperbolic sine of <code translate="no" dir="ltr">X</code>.</td>
</tr>
<tr class="even">
<td><a href="/bigquery/docs/reference/standard-sql/mathematical_functions#sqrt"><code translate="no" dir="ltr">SQRT</code></a></td>
<td>Computes the square root of <code translate="no" dir="ltr">X</code>.</td>
</tr>
<tr class="odd">
<td><a href="/bigquery/docs/reference/standard-sql/aggregate_functions#sum"><code translate="no" dir="ltr">SUM</code></a></td>
<td>Gets the sum of non-<code translate="no" dir="ltr">NULL</code> values.<br />
For more information, see <a href="/bigquery/docs/reference/standard-sql/aggregate_functions">Aggregate functions</a>.</td>
</tr>
<tr class="even">
<td><a href="/bigquery/docs/reference/standard-sql/aggregate-dp-functions#dp_sum"><code translate="no" dir="ltr">SUM</code> (Differential Privacy)</a></td>
<td><code translate="no" dir="ltr">DIFFERENTIAL_PRIVACY</code>-supported <code translate="no" dir="ltr">SUM</code>.<br />
<br />
Gets the differentially-private sum of non-<code translate="no" dir="ltr">NULL</code>, non-<code translate="no" dir="ltr">NaN</code> values in a query with a <code translate="no" dir="ltr">DIFFERENTIAL_PRIVACY</code> clause.<br />
<br />
For more information, see <a href="/bigquery/docs/reference/standard-sql/aggregate-dp-functions">Differential privacy functions</a>.</td>
</tr>
<tr class="odd">
<td><a href="/bigquery/docs/reference/standard-sql/mathematical_functions#tan"><code translate="no" dir="ltr">TAN</code></a></td>
<td>Computes the tangent of <code translate="no" dir="ltr">X</code>.</td>
</tr>
<tr class="even">
<td><a href="/bigquery/docs/reference/standard-sql/mathematical_functions#tanh"><code translate="no" dir="ltr">TANH</code></a></td>
<td>Computes the hyperbolic tangent of <code translate="no" dir="ltr">X</code>.</td>
</tr>
<tr class="odd">
<td><a href="/bigquery/docs/reference/standard-sql/mathematical_functions#trunc"><code translate="no" dir="ltr">TRUNC</code></a></td>
<td>Rounds a number like <code translate="no" dir="ltr">ROUND(X)</code> or <code translate="no" dir="ltr">ROUND(X, N)</code>, but always rounds towards zero and never overflows.</td>
</tr>
</tbody>
</table>

## `ABS`

<div>

</div>

``` devsite-click-to-copy
ABS(X)
```

**Description**

Computes absolute value. Returns an error if the argument is an integer and the output value can't be represented as the same type; this happens only for the largest negative input value, which has no positive representation.

| X      | ABS(X) |
|--------|--------|
| 25     | 25     |
| -25    | 25     |
| `+inf` | `+inf` |
| `-inf` | `+inf` |

**Return Data Type**

| INPUT  | `INT64` | `NUMERIC` | `BIGNUMERIC` | `FLOAT64` |
|--------|---------|-----------|--------------|-----------|
| OUTPUT | `INT64` | `NUMERIC` | `BIGNUMERIC` | `FLOAT64` |

## `ACOS`

<div>

</div>

``` devsite-click-to-copy
ACOS(X)
```

**Description**

Computes the principal value of the inverse cosine of X. The return value is in the range \[0,π\]. Generates an error if X is a value outside of the range \[-1, 1\].

| X       | ACOS(X) |
|---------|---------|
| `+inf`  | `NaN`   |
| `-inf`  | `NaN`   |
| `NaN`   | `NaN`   |
| X \< -1 | Error   |
| X \> 1  | Error   |

## `ACOSH`

<div>

</div>

``` devsite-click-to-copy
ACOSH(X)
```

**Description**

Computes the inverse hyperbolic cosine of X. Generates an error if X is a value less than 1.

| X      | ACOSH(X) |
|--------|----------|
| `+inf` | `+inf`   |
| `-inf` | `NaN`    |
| `NaN`  | `NaN`    |
| X \< 1 | Error    |

## `ASIN`

<div>

</div>

``` devsite-click-to-copy
ASIN(X)
```

**Description**

Computes the principal value of the inverse sine of X. The return value is in the range \[-π/2,π/2\]. Generates an error if X is outside of the range \[-1, 1\].

| X       | ASIN(X) |
|---------|---------|
| `+inf`  | `NaN`   |
| `-inf`  | `NaN`   |
| `NaN`   | `NaN`   |
| X \< -1 | Error   |
| X \> 1  | Error   |

## `ASINH`

<div>

</div>

``` devsite-click-to-copy
ASINH(X)
```

**Description**

Computes the inverse hyperbolic sine of X. Doesn't fail.

| X      | ASINH(X) |
|--------|----------|
| `+inf` | `+inf`   |
| `-inf` | `-inf`   |
| `NaN`  | `NaN`    |

## `ATAN`

<div>

</div>

``` devsite-click-to-copy
ATAN(X)
```

**Description**

Computes the principal value of the inverse tangent of X. The return value is in the range \[-π/2,π/2\]. Doesn't fail.

| X      | ATAN(X) |
|--------|---------|
| `+inf` | π/2     |
| `-inf` | -π/2    |
| `NaN`  | `NaN`   |

## `ATAN2`

<div>

</div>

``` devsite-click-to-copy
ATAN2(X, Y)
```

**Description**

Calculates the principal value of the inverse tangent of X/Y using the signs of the two arguments to determine the quadrant. The return value is in the range \[-π,π\].

| X                     | Y            | ATAN2(X, Y) |
|-----------------------|--------------|-------------|
| `NaN`                 | Any value    | `NaN`       |
| Any value             | `NaN`        | `NaN`       |
| 0.0                   | 0.0          | 0.0         |
| Positive Finite value | `-inf`       | π           |
| Negative Finite value | `-inf`       | -π          |
| Finite value          | `+inf`       | 0.0         |
| `+inf`                | Finite value | π/2         |
| `-inf`                | Finite value | -π/2        |
| `+inf`                | `-inf`       | ¾π          |
| `-inf`                | `-inf`       | -¾π         |
| `+inf`                | `+inf`       | π/4         |
| `-inf`                | `+inf`       | -π/4        |

## `ATANH`

<div>

</div>

``` devsite-click-to-copy
ATANH(X)
```

**Description**

Computes the inverse hyperbolic tangent of X. Generates an error if X is outside of the range (-1, 1).

| X       | ATANH(X) |
|---------|----------|
| `+inf`  | `NaN`    |
| `-inf`  | `NaN`    |
| `NaN`   | `NaN`    |
| X \< -1 | Error    |
| X \> 1  | Error    |

## `CBRT`

<div>

</div>

``` devsite-click-to-copy
CBRT(X)
```

**Description**

Computes the cube root of `X`. `X` can be any data type that [coerces to `FLOAT64`](/bigquery/docs/reference/standard-sql/conversion_rules). Supports the `SAFE.` prefix.

| X      | CBRT(X) |
|--------|---------|
| `+inf` | `inf`   |
| `-inf` | `-inf`  |
| `NaN`  | `NaN`   |
| `0`    | `0`     |
| `NULL` | `NULL`  |

**Return Data Type**

`FLOAT64`

**Example**

<div>

</div>

``` devsite-click-to-copy
SELECT CBRT(27) AS cube_root;

/*--------------------+
 | cube_root          |
 +--------------------+
 | 3.0000000000000004 |
 +--------------------*/
```

## `CEIL`

<div>

</div>

``` devsite-click-to-copy
CEIL(X)
```

**Description**

Returns the smallest integral value that isn't less than X.

| X      | CEIL(X) |
|--------|---------|
| 2.0    | 2.0     |
| 2.3    | 3.0     |
| 2.8    | 3.0     |
| 2.5    | 3.0     |
| -2.3   | -2.0    |
| -2.8   | -2.0    |
| -2.5   | -2.0    |
| 0      | 0       |
| `+inf` | `+inf`  |
| `-inf` | `-inf`  |
| `NaN`  | `NaN`   |

**Return Data Type**

| INPUT  | `INT64`   | `NUMERIC` | `BIGNUMERIC` | `FLOAT64` |
|--------|-----------|-----------|--------------|-----------|
| OUTPUT | `FLOAT64` | `NUMERIC` | `BIGNUMERIC` | `FLOAT64` |

## `CEILING`

<div>

</div>

``` devsite-click-to-copy
CEILING(X)
```

**Description**

Synonym of CEIL(X)

## `COS`

<div>

</div>

``` devsite-click-to-copy
COS(X)
```

**Description**

Computes the cosine of X where X is specified in radians. Never fails.

| X      | COS(X) |
|--------|--------|
| `+inf` | `NaN`  |
| `-inf` | `NaN`  |
| `NaN`  | `NaN`  |

## `COSH`

<div>

</div>

``` devsite-click-to-copy
COSH(X)
```

**Description**

Computes the hyperbolic cosine of X where X is specified in radians. Generates an error if overflow occurs.

| X      | COSH(X) |
|--------|---------|
| `+inf` | `+inf`  |
| `-inf` | `+inf`  |
| `NaN`  | `NaN`   |

## `COSINE_DISTANCE`

<div>

</div>

``` devsite-click-to-copy
COSINE_DISTANCE(vector1, vector2)
```

**Description**

Computes the [cosine distance](https://en.wikipedia.org/wiki/Cosine_similarity#Cosine_distance) between two vectors.

**Definitions**

- `vector1`: A vector that's represented by an `ARRAY<T>` value or a sparse vector that is represented by an `ARRAY<STRUCT<dimension,magnitude>>` value.
- `vector2`: A vector that's represented by an `ARRAY<T>` value or a sparse vector that is represented by an `ARRAY<STRUCT<dimension,magnitude>>` value.

**Details**

- `ARRAY<T>` can be used to represent a vector. Each zero-based index in this array represents a dimension. The value for each element in this array represents a magnitude.

  `T` can represent the following and must be the same for both vectors:

  - `FLOAT64`

  In the following example vector, there are four dimensions. The magnitude is `10.0` for dimension `0`, `55.0` for dimension `1`, `40.0` for dimension `2`, and `34.0` for dimension `3`:

  <div>

  </div>

  ``` devsite-click-to-copy
  [10.0, 55.0, 40.0, 34.0]
  ```

- `ARRAY<STRUCT<dimension,magnitude>>` can be used to represent a sparse vector. With a sparse vector, you only need to include dimension-magnitude pairs for non-zero magnitudes. If a magnitude isn't present in the sparse vector, the magnitude is implicitly understood to be zero.

  For example, if you have a vector with 10,000 dimensions, but only 10 dimensions have non-zero magnitudes, then the vector is a sparse vector. As a result, it's more efficient to describe a sparse vector by only mentioning its non-zero magnitudes.

  In `ARRAY<STRUCT<dimension,magnitude>>`, `STRUCT<dimension,magnitude>` represents a dimension-magnitude pair for each non-zero magnitude in a sparse vector. These parts need to be included for each dimension-magnitude pair:

  - `dimension`: A `STRING` or `INT64` value that represents a dimension in a vector.

  - `magnitude`: A `FLOAT64` value that represents a non-zero magnitude for a specific dimension in a vector.

  You don't need to include empty dimension-magnitude pairs in a sparse vector. For example, the following sparse vector and non-sparse vector are equivalent:

  <div>

  </div>

  ``` devsite-click-to-copy
  -- sparse vector ARRAY<STRUCT<INT64, FLOAT64>>
  [(1, 10.0), (2, 30.0), (5, 40.0)]
  ```

  <div>

  </div>

  ``` devsite-click-to-copy
  -- vector ARRAY<FLOAT64>
  [0.0, 10.0, 30.0, 0.0, 0.0, 40.0]
  ```

  In a sparse vector, dimension-magnitude pairs don't need to be in any particular order. The following sparse vectors are equivalent:

  <div>

  </div>

  ``` devsite-click-to-copy
  [('a', 10.0), ('b', 30.0), ('d', 40.0)]
  ```

  <div>

  </div>

  ``` devsite-click-to-copy
  [('d', 40.0), ('a', 10.0), ('b', 30.0)]
  ```

- Both non-sparse vectors in this function must share the same dimensions, and if they don't, an error is produced.

- A vector can't be a zero vector. A vector is a zero vector if it has no dimensions or all dimensions have a magnitude of `0`, such as `[]` or `[0.0, 0.0]`. If a zero vector is encountered, an error is produced.

- An error is produced if a magnitude in a vector is `NULL`.

- If a vector is `NULL`, `NULL` is returned.

**Return type**

`FLOAT64`

**Examples**

In the following example, non-sparsevectors are used to compute the cosine distance:

<div>

</div>

``` devsite-click-to-copy
SELECT COSINE_DISTANCE([1.0, 2.0], [3.0, 4.0]) AS results;

/*----------+
 | results  |
 +----------+
 | 0.016130 |
 +----------*/
```

In the following example, sparse vectors are used to compute the cosine distance:

<div>

</div>

``` devsite-click-to-copy
SELECT COSINE_DISTANCE(
 [(1, 1.0), (2, 2.0)],
 [(2, 4.0), (1, 3.0)]) AS results;

 /*----------+
  | results  |
  +----------+
  | 0.016130 |
  +----------*/
```

The ordering of numeric values in a vector doesn't impact the results produced by this function. For example these queries produce the same results even though the numeric values in each vector is in a different order:

<div>

</div>

``` devsite-click-to-copy
SELECT COSINE_DISTANCE([1.0, 2.0], [3.0, 4.0]) AS results;
```

<div>

</div>

``` devsite-click-to-copy
SELECT COSINE_DISTANCE([2.0, 1.0], [4.0, 3.0]) AS results;
```

<div>

</div>

``` devsite-click-to-copy
SELECT COSINE_DISTANCE([(1, 1.0), (2, 2.0)], [(1, 3.0), (2, 4.0)]) AS results;
```

<div>

</div>

``` devsite-click-to-copy
 /*----------+
  | results  |
  +----------+
  | 0.016130 |
  +----------*/
```

In the following example, the function can't compute cosine distance against the first vector, which is a zero vector:

<div>

</div>

``` devsite-click-to-copy
-- ERROR
SELECT COSINE_DISTANCE([0.0, 0.0], [3.0, 4.0]) AS results;
```

<div>

</div>

``` devsite-click-to-copy
-- ERROR
SELECT COSINE_DISTANCE([(1, 0.0), (2, 0.0)], [(1, 3.0), (2, 4.0)]) AS results;
```

Both non-sparse vectors must have the same dimensions. If not, an error is produced. In the following example, the first vector has two dimensions and the second vector has three:

<div>

</div>

``` devsite-click-to-copy
-- ERROR
SELECT COSINE_DISTANCE([9.0, 7.0], [8.0, 4.0, 5.0]) AS results;
```

If you use sparse vectors and you repeat a dimension, an error is produced:

<div>

</div>

``` devsite-click-to-copy
-- ERROR
SELECT COSINE_DISTANCE(
  [(1, 9.0), (2, 7.0), (2, 8.0)], [(1, 8.0), (2, 4.0), (3, 5.0)]) AS results;
```

## `COT`

<div>

</div>

``` devsite-click-to-copy
COT(X)
```

**Description**

Computes the cotangent for the angle of `X`, where `X` is specified in radians. `X` can be any data type that [coerces to `FLOAT64`](/bigquery/docs/reference/standard-sql/conversion_rules). Supports the `SAFE.` prefix.

| X      | COT(X)  |
|--------|---------|
| `+inf` | `NaN`   |
| `-inf` | `NaN`   |
| `NaN`  | `NaN`   |
| `0`    | `Error` |
| `NULL` | `NULL`  |

**Return Data Type**

`FLOAT64`

**Example**

<div>

</div>

``` devsite-click-to-copy
SELECT COT(1) AS a, SAFE.COT(0) AS b;

/*---------------------+------+
 | a                   | b    |
 +---------------------+------+
 | 0.64209261593433065 | NULL |
 +---------------------+------*/
```

## `COTH`

<div>

</div>

``` devsite-click-to-copy
COTH(X)
```

**Description**

Computes the hyperbolic cotangent for the angle of `X`, where `X` is specified in radians. `X` can be any data type that [coerces to `FLOAT64`](/bigquery/docs/reference/standard-sql/conversion_rules). Supports the `SAFE.` prefix.

| X      | COTH(X) |
|--------|---------|
| `+inf` | `1`     |
| `-inf` | `-1`    |
| `NaN`  | `NaN`   |
| `0`    | `Error` |
| `NULL` | `NULL`  |

**Return Data Type**

`FLOAT64`

**Example**

<div>

</div>

``` devsite-click-to-copy
SELECT COTH(1) AS a, SAFE.COTH(0) AS b;

/*----------------+------+
 | a              | b    |
 +----------------+------+
 | 1.313035285499 | NULL |
 +----------------+------*/
```

## `CSC`

<div>

</div>

``` devsite-click-to-copy
CSC(X)
```

**Description**

Computes the cosecant of the input angle, which is in radians. `X` can be any data type that [coerces to `FLOAT64`](/bigquery/docs/reference/standard-sql/conversion_rules). Supports the `SAFE.` prefix.

| X      | CSC(X)  |
|--------|---------|
| `+inf` | `NaN`   |
| `-inf` | `NaN`   |
| `NaN`  | `NaN`   |
| `0`    | `Error` |
| `NULL` | `NULL`  |

**Return Data Type**

`FLOAT64`

**Example**

<div>

</div>

``` devsite-click-to-copy
SELECT CSC(100) AS a, CSC(-1) AS b, SAFE.CSC(0) AS c;

/*----------------+-----------------+------+
 | a              | b               | c    |
 +----------------+-----------------+------+
 | -1.97485753142 | -1.188395105778 | NULL |
 +----------------+-----------------+------*/
```

## `CSCH`

<div>

</div>

``` devsite-click-to-copy
CSCH(X)
```

**Description**

Computes the hyperbolic cosecant of the input angle, which is in radians. `X` can be any data type that [coerces to `FLOAT64`](/bigquery/docs/reference/standard-sql/conversion_rules). Supports the `SAFE.` prefix.

| X      | CSCH(X) |
|--------|---------|
| `+inf` | `0`     |
| `-inf` | `0`     |
| `NaN`  | `NaN`   |
| `0`    | `Error` |
| `NULL` | `NULL`  |

**Return Data Type**

`FLOAT64`

**Example**

<div>

</div>

``` devsite-click-to-copy
SELECT CSCH(0.5) AS a, CSCH(-2) AS b, SAFE.CSCH(0) AS c;

/*----------------+----------------+------+
 | a              | b              | c    |
 +----------------+----------------+------+
 | 1.919034751334 | -0.27572056477 | NULL |
 +----------------+----------------+------*/
```

## `DIV`

<div>

</div>

``` devsite-click-to-copy
DIV(X, Y)
```

**Description**

Returns the result of integer division of X by Y. Division by zero returns an error. Division by -1 may overflow.

| X   | Y   | DIV(X, Y) |
|-----|-----|-----------|
| 20  | 4   | 5         |
| 12  | -7  | -1        |
| 20  | 3   | 6         |
| 0   | 20  | 0         |
| 20  | 0   | Error     |

**Return Data Type**

The return data type is determined by the argument types with the following table.

INPUT

</div>

`INT64`

`NUMERIC`

`BIGNUMERIC`

`INT64`

`INT64`

`NUMERIC`

`BIGNUMERIC`

`NUMERIC`

`NUMERIC`

`NUMERIC`

`BIGNUMERIC`

`BIGNUMERIC`

`BIGNUMERIC`

`BIGNUMERIC`

`BIGNUMERIC`

## `EXP`

<div>

</div>

``` devsite-click-to-copy
EXP(X)
```

**Description**

Computes *e* to the power of X, also called the natural exponential function. If the result underflows, this function returns a zero. Generates an error if the result overflows.

| X      | EXP(X) |
|--------|--------|
| 0.0    | 1.0    |
| `+inf` | `+inf` |
| `-inf` | 0.0    |

**Return Data Type**

| INPUT  | `INT64`   | `NUMERIC` | `BIGNUMERIC` | `FLOAT64` |
|--------|-----------|-----------|--------------|-----------|
| OUTPUT | `FLOAT64` | `NUMERIC` | `BIGNUMERIC` | `FLOAT64` |

## `EUCLIDEAN_DISTANCE`

<div>

</div>

``` devsite-click-to-copy
EUCLIDEAN_DISTANCE(vector1, vector2)
```

**Description**

Computes the [Euclidean distance](https://en.wikipedia.org/wiki/Euclidean_distance) between two vectors.

**Definitions**

- `vector1`: A vector that's represented by an `ARRAY<T>` value or a sparse vector that is represented by an `ARRAY<STRUCT<dimension,magnitude>>` value.
- `vector2`: A vector that's represented by an `ARRAY<T>` value or a sparse vector that is represented by an `ARRAY<STRUCT<dimension,magnitude>>` value.

**Details**

- `ARRAY<T>` can be used to represent a vector. Each zero-based index in this array represents a dimension. The value for each element in this array represents a magnitude.

  `T` can represent the following and must be the same for both vectors:

  - `FLOAT64`

  In the following example vector, there are four dimensions. The magnitude is `10.0` for dimension `0`, `55.0` for dimension `1`, `40.0` for dimension `2`, and `34.0` for dimension `3`:

  <div>

  </div>

  ``` devsite-click-to-copy
  [10.0, 55.0, 40.0, 34.0]
  ```

- `ARRAY<STRUCT<dimension,magnitude>>` can be used to represent a sparse vector. With a sparse vector, you only need to include dimension-magnitude pairs for non-zero magnitudes. If a magnitude isn't present in the sparse vector, the magnitude is implicitly understood to be zero.

  For example, if you have a vector with 10,000 dimensions, but only 10 dimensions have non-zero magnitudes, then the vector is a sparse vector. As a result, it's more efficient to describe a sparse vector by only mentioning its non-zero magnitudes.

  In `ARRAY<STRUCT<dimension,magnitude>>`, `STRUCT<dimension,magnitude>` represents a dimension-magnitude pair for each non-zero magnitude in a sparse vector. These parts need to be included for each dimension-magnitude pair:

  - `dimension`: A `STRING` or `INT64` value that represents a dimension in a vector.

  - `magnitude`: A `FLOAT64` value that represents a non-zero magnitude for a specific dimension in a vector.

  You don't need to include empty dimension-magnitude pairs in a sparse vector. For example, the following sparse vector and non-sparse vector are equivalent:

  <div>

  </div>

  ``` devsite-click-to-copy
  -- sparse vector ARRAY<STRUCT<INT64, FLOAT64>>
  [(1, 10.0), (2, 30.0), (5, 40.0)]
  ```

  <div>

  </div>

  ``` devsite-click-to-copy
  -- vector ARRAY<FLOAT64>
  [0.0, 10.0, 30.0, 0.0, 0.0, 40.0]
  ```

  In a sparse vector, dimension-magnitude pairs don't need to be in any particular order. The following sparse vectors are equivalent:

  <div>

  </div>

  ``` devsite-click-to-copy
  [('a', 10.0), ('b', 30.0), ('d', 40.0)]
  ```

  <div>

  </div>

  ``` devsite-click-to-copy
  [('d', 40.0), ('a', 10.0), ('b', 30.0)]
  ```

- Both non-sparse vectors in this function must share the same dimensions, and if they don't, an error is produced.

- A vector can be a zero vector. A vector is a zero vector if it has no dimensions or all dimensions have a magnitude of `0`, such as `[]` or `[0.0, 0.0]`.

- An error is produced if a magnitude in a vector is `NULL`.

- If a vector is `NULL`, `NULL` is returned.

**Return type**

`FLOAT64`

**Examples**

In the following example, non-sparse vectors are used to compute the Euclidean distance:

<div>

</div>

``` devsite-click-to-copy
SELECT EUCLIDEAN_DISTANCE([1.0, 2.0], [3.0, 4.0]) AS results;

/*----------+
 | results  |
 +----------+
 | 2.828    |
 +----------*/
```

In the following example, sparse vectors are used to compute the Euclidean distance:

<div>

</div>

``` devsite-click-to-copy
SELECT EUCLIDEAN_DISTANCE(
 [(1, 1.0), (2, 2.0)],
 [(2, 4.0), (1, 3.0)]) AS results;

 /*----------+
  | results  |
  +----------+
  | 2.828    |
  +----------*/
```

The ordering of magnitudes in a vector doesn't impact the results produced by this function. For example these queries produce the same results even though the magnitudes in each vector is in a different order:

<div>

</div>

``` devsite-click-to-copy
SELECT EUCLIDEAN_DISTANCE([1.0, 2.0], [3.0, 4.0]);
```

<div>

</div>

``` devsite-click-to-copy
SELECT EUCLIDEAN_DISTANCE([2.0, 1.0], [4.0, 3.0]);
```

<div>

</div>

``` devsite-click-to-copy
SELECT EUCLIDEAN_DISTANCE([(1, 1.0), (2, 2.0)], [(1, 3.0), (2, 4.0)]) AS results;
```

<div>

</div>

``` devsite-click-to-copy
 /*----------+
  | results  |
  +----------+
  | 2.828    |
  +----------*/
```

Both non-sparse vectors must have the same dimensions. If not, an error is produced. In the following example, the first vector has two dimensions and the second vector has three:

<div>

</div>

``` devsite-click-to-copy
-- ERROR
SELECT EUCLIDEAN_DISTANCE([9.0, 7.0], [8.0, 4.0, 5.0]) AS results;
```

If you use sparse vectors and you repeat a dimension, an error is produced:

<div>

</div>

``` devsite-click-to-copy
-- ERROR
SELECT EUCLIDEAN_DISTANCE(
  [(1, 9.0), (2, 7.0), (2, 8.0)], [(1, 8.0), (2, 4.0), (3, 5.0)]) AS results;
```

## `FLOOR`

<div>

</div>

``` devsite-click-to-copy
FLOOR(X)
```

**Description**

Returns the largest integral value that isn't greater than X.

| X      | FLOOR(X) |
|--------|----------|
| 2.0    | 2.0      |
| 2.3    | 2.0      |
| 2.8    | 2.0      |
| 2.5    | 2.0      |
| -2.3   | -3.0     |
| -2.8   | -3.0     |
| -2.5   | -3.0     |
| 0      | 0        |
| `+inf` | `+inf`   |
| `-inf` | `-inf`   |
| `NaN`  | `NaN`    |

**Return Data Type**

| INPUT  | `INT64`   | `NUMERIC` | `BIGNUMERIC` | `FLOAT64` |
|--------|-----------|-----------|--------------|-----------|
| OUTPUT | `FLOAT64` | `NUMERIC` | `BIGNUMERIC` | `FLOAT64` |

## `GREATEST`

<div>

</div>

``` devsite-click-to-copy
GREATEST(X1,...,XN)
```

**Description**

Returns the greatest value among `X1,...,XN`. If any argument is `NULL`, returns `NULL`. Otherwise, in the case of floating-point arguments, if any argument is `NaN`, returns `NaN`. In all other cases, returns the value among `X1,...,XN` that has the greatest value according to the ordering used by the `ORDER BY` clause. The arguments `X1, ..., XN` must be coercible to a common supertype, and the supertype must support ordering.

| X1,...,XN | GREATEST(X1,...,XN) |
|-----------|---------------------|
| 3,5,1     | 5                   |

This function supports specifying [collation](/bigquery/docs/reference/standard-sql/collation-concepts).

**Return Data Types**

Data type of the input values.

## `IEEE_DIVIDE`

<div>

</div>

``` devsite-click-to-copy
IEEE_DIVIDE(X, Y)
```

**Description**

Divides X by Y; this function never fails. Returns `FLOAT64`. Unlike the division operator (/), this function doesn't generate errors for division by zero or overflow.

| X      | Y      | IEEE_DIVIDE(X, Y)  |
|--------|--------|--------------------|
| 20.0   | 4.0    | 5.0                |
| 20.0   | 6.0    | 3.3333333333333335 |
| 0.0    | 25.0   | 0.0                |
| 25.0   | 0.0    | `+inf`             |
| -25.0  | 0.0    | `-inf`             |
| 25.0   | -0.0   | `-inf`             |
| 0.0    | 0.0    | `NaN`              |
| 0.0    | `NaN`  | `NaN`              |
| `NaN`  | 0.0    | `NaN`              |
| `+inf` | `+inf` | `NaN`              |
| `-inf` | `-inf` | `NaN`              |

## `IS_INF`

<div>

</div>

``` devsite-click-to-copy
IS_INF(X)
```

**Description**

Returns `TRUE` if the value is positive or negative infinity.

| X      | IS_INF(X) |
|--------|-----------|
| `+inf` | `TRUE`    |
| `-inf` | `TRUE`    |
| 25     | `FALSE`   |

## `IS_NAN`

<div>

</div>

``` devsite-click-to-copy
IS_NAN(X)
```

**Description**

Returns `TRUE` if the value is a `NaN` value.

| X     | IS_NAN(X) |
|-------|-----------|
| `NaN` | `TRUE`    |
| 25    | `FALSE`   |

## `LEAST`

<div>

</div>

``` devsite-click-to-copy
LEAST(X1,...,XN)
```

**Description**

Returns the least value among `X1,...,XN`. If any argument is `NULL`, returns `NULL`. Otherwise, in the case of floating-point arguments, if any argument is `NaN`, returns `NaN`. In all other cases, returns the value among `X1,...,XN` that has the least value according to the ordering used by the `ORDER BY` clause. The arguments `X1, ..., XN` must be coercible to a common supertype, and the supertype must support ordering.

| X1,...,XN | LEAST(X1,...,XN) |
|-----------|------------------|
| 3,5,1     | 1                |

This function supports specifying [collation](/bigquery/docs/reference/standard-sql/collation-concepts).

**Return Data Types**

Data type of the input values.

## `LN`

<div>

</div>

``` devsite-click-to-copy
LN(X)
```

**Description**

Computes the natural logarithm of X. Generates an error if X is less than or equal to zero.

| X        | LN(X)  |
|----------|--------|
| 1.0      | 0.0    |
| `+inf`   | `+inf` |
| `X <= 0` | Error  |

**Return Data Type**

| INPUT  | `INT64`   | `NUMERIC` | `BIGNUMERIC` | `FLOAT64` |
|--------|-----------|-----------|--------------|-----------|
| OUTPUT | `FLOAT64` | `NUMERIC` | `BIGNUMERIC` | `FLOAT64` |

## `LOG`

<div>

</div>

``` devsite-click-to-copy
LOG(X [, Y])
```

**Description**

If only X is present, `LOG` is a synonym of `LN`. If Y is also present, `LOG` computes the logarithm of X to base Y.

| X         | Y               | LOG(X, Y) |
|-----------|-----------------|-----------|
| 100.0     | 10.0            | 2.0       |
| `-inf`    | Any value       | `NaN`     |
| Any value | `+inf`          | `NaN`     |
| `+inf`    | 0.0 \< Y \< 1.0 | `-inf`    |
| `+inf`    | Y \> 1.0        | `+inf`    |
| X \<= 0   | Any value       | Error     |
| Any value | Y \<= 0         | Error     |
| Any value | 1.0             | Error     |

**Return Data Type**

| INPUT        | `INT64`      | `NUMERIC`    | `BIGNUMERIC` | `FLOAT64` |
|--------------|--------------|--------------|--------------|-----------|
| `INT64`      | `FLOAT64`    | `NUMERIC`    | `BIGNUMERIC` | `FLOAT64` |
| `NUMERIC`    | `NUMERIC`    | `NUMERIC`    | `BIGNUMERIC` | `FLOAT64` |
| `BIGNUMERIC` | `BIGNUMERIC` | `BIGNUMERIC` | `BIGNUMERIC` | `FLOAT64` |
| `FLOAT64`    | `FLOAT64`    | `FLOAT64`    | `FLOAT64`    | `FLOAT64` |

## `LOG10`

<div>

</div>

``` devsite-click-to-copy
LOG10(X)
```

**Description**

Similar to `LOG`, but computes logarithm to base 10.

| X       | LOG10(X) |
|---------|----------|
| 100.0   | 2.0      |
| `-inf`  | `NaN`    |
| `+inf`  | `+inf`   |
| X \<= 0 | Error    |

**Return Data Type**

| INPUT  | `INT64`   | `NUMERIC` | `BIGNUMERIC` | `FLOAT64` |
|--------|-----------|-----------|--------------|-----------|
| OUTPUT | `FLOAT64` | `NUMERIC` | `BIGNUMERIC` | `FLOAT64` |

## `MOD`

<div>

</div>

``` devsite-click-to-copy
MOD(X, Y)
```

**Description**

Modulo function: returns the remainder of the division of X by Y. Returned value has the same sign as X. An error is generated if Y is 0.

| X   | Y   | MOD(X, Y) |
|-----|-----|-----------|
| 25  | 12  | 1         |
| 25  | 0   | Error     |

**Return Data Type**

The return data type is determined by the argument types with the following table.

INPUT

`INT64`

`NUMERIC`

`BIGNUMERIC`

`INT64`

`INT64`

`NUMERIC`

`BIGNUMERIC`

`NUMERIC`

`NUMERIC`

`NUMERIC`

`BIGNUMERIC`

`BIGNUMERIC`

`BIGNUMERIC`

`BIGNUMERIC`

`BIGNUMERIC`

## `POW`

<div>

</div>

``` devsite-click-to-copy
POW(X, Y)
```

**Description**

Returns the value of X raised to the power of Y. If the result underflows and isn't representable, then the function returns a value of zero.

| X                         | Y                         | POW(X, Y)                                       |
|---------------------------|---------------------------|-------------------------------------------------|
| 2.0                       | 3.0                       | 8.0                                             |
| 1.0                       | Any value including `NaN` | 1.0                                             |
| Any value including `NaN` | 0                         | 1.0                                             |
| -1.0                      | `+inf`                    | 1.0                                             |
| -1.0                      | `-inf`                    | 1.0                                             |
| ABS(X) \< 1               | `-inf`                    | `+inf`                                          |
| ABS(X) \> 1               | `-inf`                    | 0.0                                             |
| ABS(X) \< 1               | `+inf`                    | 0.0                                             |
| ABS(X) \> 1               | `+inf`                    | `+inf`                                          |
| `-inf`                    | Y \< 0                    | 0.0                                             |
| `-inf`                    | Y \> 0                    | `-inf` if Y is an odd integer, `+inf` otherwise |
| `+inf`                    | Y \< 0                    | 0                                               |
| `+inf`                    | Y \> 0                    | `+inf`                                          |
| Finite value \< 0         | Non-integer               | Error                                           |
| 0                         | Finite value \< 0         | Error                                           |

**Return Data Type**

The return data type is determined by the argument types with the following table.

| INPUT        | `INT64`      | `NUMERIC`    | `BIGNUMERIC` | `FLOAT64` |
|--------------|--------------|--------------|--------------|-----------|
| `INT64`      | `FLOAT64`    | `NUMERIC`    | `BIGNUMERIC` | `FLOAT64` |
| `NUMERIC`    | `NUMERIC`    | `NUMERIC`    | `BIGNUMERIC` | `FLOAT64` |
| `BIGNUMERIC` | `BIGNUMERIC` | `BIGNUMERIC` | `BIGNUMERIC` | `FLOAT64` |
| `FLOAT64`    | `FLOAT64`    | `FLOAT64`    | `FLOAT64`    | `FLOAT64` |

## `POWER`

<div>

</div>

``` devsite-click-to-copy
POWER(X, Y)
```

**Description**

Synonym of [`POW(X, Y)`](#pow).

## `RAND`

<div>

</div>

``` devsite-click-to-copy
RAND()
```

**Description**

Generates a pseudo-random value of type `FLOAT64` in the range of \[0, 1), inclusive of 0 and exclusive of 1.

## `RANGE_BUCKET`

<div>

</div>

``` devsite-click-to-copy
RANGE_BUCKET(point, boundaries_array)
```

**Description**

`RANGE_BUCKET` scans through a sorted array and returns the 0-based position of the point's upper bound. This can be useful if you need to group your data to build partitions, histograms, business-defined rules, and more.

`RANGE_BUCKET` follows these rules:

- If the point exists in the array, returns the index of the next larger value.

  <div>

  </div>

  ``` devsite-click-to-copy
  RANGE_BUCKET(20, [0, 10, 20, 30, 40]) -- 3 is return value
  RANGE_BUCKET(20, [0, 10, 20, 20, 40, 40]) -- 4 is return value
  ```

- If the point doesn't exist in the array, but it falls between two values, returns the index of the larger value.

  <div>

  </div>

  ``` devsite-click-to-copy
  RANGE_BUCKET(25, [0, 10, 20, 30, 40]) -- 3 is return value
  ```

- If the point is smaller than the first value in the array, returns 0.

  <div>

  </div>

  ``` devsite-click-to-copy
  RANGE_BUCKET(-10, [5, 10, 20, 30, 40]) -- 0 is return value
  ```

- If the point is greater than or equal to the last value in the array, returns the length of the array.

  <div>

  </div>

  ``` devsite-click-to-copy
  RANGE_BUCKET(80, [0, 10, 20, 30, 40]) -- 5 is return value
  ```

- If the array is empty, returns 0.

  <div>

  </div>

  ``` devsite-click-to-copy
  RANGE_BUCKET(80, []) -- 0 is return value
  ```

- If the point is `NULL` or `NaN`, returns `NULL`.

  <div>

  </div>

  ``` devsite-click-to-copy
  RANGE_BUCKET(NULL, [0, 10, 20, 30, 40]) -- NULL is return value
  ```

- The data type for the point and array must be compatible.

  <div>

  </div>

  ``` devsite-click-to-copy
  RANGE_BUCKET('a', ['a', 'b', 'c', 'd']) -- 1 is return value
  RANGE_BUCKET(1.2, [1, 1.2, 1.4, 1.6]) -- 2 is return value
  RANGE_BUCKET(1.2, [1, 2, 4, 6]) -- execution failure
  ```

Execution failure occurs when:

- The array has a `NaN` or `NULL` value in it.

  <div>

  </div>

  ``` devsite-click-to-copy
  RANGE_BUCKET(80, [NULL, 10, 20, 30, 40]) -- execution failure
  ```

- The array isn't sorted in ascending order.

  <div>

  </div>

  ``` devsite-click-to-copy
  RANGE_BUCKET(30, [10, 30, 20, 40, 50]) -- execution failure
  ```

**Parameters**

- `point`: A generic value.
- `boundaries_array`: A generic array of values.

**Note:** The data type for `point` and the element type of `boundaries_array` must be equivalent. The data type must be [comparable](/bigquery/docs/reference/standard-sql/data-types#data_type_properties).

**Return Value**

`INT64`

**Examples**

In a table called `students`, check to see how many records would exist in each `age_group` bucket, based on a student's age:

- age_group 0 (age \< 10)
- age_group 1 (age \>= 10, age \< 20)
- age_group 2 (age \>= 20, age \< 30)
- age_group 3 (age \>= 30)

<div>

</div>

``` devsite-click-to-copy
WITH students AS
(
  SELECT 9 AS age UNION ALL
  SELECT 20 AS age UNION ALL
  SELECT 25 AS age UNION ALL
  SELECT 31 AS age UNION ALL
  SELECT 32 AS age UNION ALL
  SELECT 33 AS age
)
SELECT RANGE_BUCKET(age, [10, 20, 30]) AS age_group, COUNT(*) AS count
FROM students
GROUP BY 1

/*--------------+-------+
 | age_group    | count |
 +--------------+-------+
 | 0            | 1     |
 | 2            | 2     |
 | 3            | 3     |
 +--------------+-------*/
```

## `ROUND`

<div>

</div>

``` devsite-click-to-copy
ROUND(X [, N [, rounding_mode]])
```

**Description**

If only X is present, rounds X to the nearest integer. If N is present, rounds X to N decimal places after the decimal point. If N is negative, rounds off digits to the left of the decimal point. Rounds halfway cases away from zero. Generates an error if overflow occurs.

If X is a `NUMERIC` or `BIGNUMERIC` type, then you can explicitly set `rounding_mode` to one of the following:

- [`"ROUND_HALF_AWAY_FROM_ZERO"`](https://en.wikipedia.org/wiki/Rounding#Rounding_half_away_from_zero): (Default) Rounds halfway cases away from zero.
- [`"ROUND_HALF_EVEN"`](https://en.wikipedia.org/wiki/Rounding#Rounding_half_to_even): Rounds halfway cases towards the nearest even digit.

If you set the `rounding_mode` and X isn't a `NUMERIC` or `BIGNUMERIC` type, then the function generates an error.

| Expression                                              | Return Value |
|---------------------------------------------------------|--------------|
| `ROUND(2.0)`                                            | 2.0          |
| `ROUND(2.3)`                                            | 2.0          |
| `ROUND(2.8)`                                            | 3.0          |
| `ROUND(2.5)`                                            | 3.0          |
| `ROUND(-2.3)`                                           | -2.0         |
| `ROUND(-2.8)`                                           | -3.0         |
| `ROUND(-2.5)`                                           | -3.0         |
| `ROUND(0)`                                              | 0            |
| `ROUND(+inf)`                                           | `+inf`       |
| `ROUND(-inf)`                                           | `-inf`       |
| `ROUND(NaN)`                                            | `NaN`        |
| `ROUND(123.7, -1)`                                      | 120.0        |
| `ROUND(1.235, 2)`                                       | 1.24         |
| `ROUND(NUMERIC "2.25", 1, "ROUND_HALF_EVEN")`           | 2.2          |
| `ROUND(NUMERIC "2.35", 1, "ROUND_HALF_EVEN")`           | 2.4          |
| `ROUND(NUMERIC "2.251", 1, "ROUND_HALF_EVEN")`          | 2.3          |
| `ROUND(NUMERIC "-2.5", 0, "ROUND_HALF_EVEN")`           | -2           |
| `ROUND(NUMERIC "2.5", 0, "ROUND_HALF_AWAY_FROM_ZERO")`  | 3            |
| `ROUND(NUMERIC "-2.5", 0, "ROUND_HALF_AWAY_FROM_ZERO")` | -3           |

**Return Data Type**

| INPUT  | `INT64`   | `NUMERIC` | `BIGNUMERIC` | `FLOAT64` |
|--------|-----------|-----------|--------------|-----------|
| OUTPUT | `FLOAT64` | `NUMERIC` | `BIGNUMERIC` | `FLOAT64` |

## `SAFE_ADD`

<div>

</div>

``` devsite-click-to-copy
SAFE_ADD(X, Y)
```

**Description**

Equivalent to the addition operator (`+`), but returns `NULL` if overflow occurs.

| X   | Y   | SAFE_ADD(X, Y) |
|-----|-----|----------------|
| 5   | 4   | 9              |

**Return Data Type**

| INPUT        | `INT64`      | `NUMERIC`    | `BIGNUMERIC` | `FLOAT64` |
|--------------|--------------|--------------|--------------|-----------|
| `INT64`      | `INT64`      | `NUMERIC`    | `BIGNUMERIC` | `FLOAT64` |
| `NUMERIC`    | `NUMERIC`    | `NUMERIC`    | `BIGNUMERIC` | `FLOAT64` |
| `BIGNUMERIC` | `BIGNUMERIC` | `BIGNUMERIC` | `BIGNUMERIC` | `FLOAT64` |
| `FLOAT64`    | `FLOAT64`    | `FLOAT64`    | `FLOAT64`    | `FLOAT64` |

## `SAFE_DIVIDE`

<div>

</div>

``` devsite-click-to-copy
SAFE_DIVIDE(X, Y)
```

**Description**

Equivalent to the division operator (`X / Y`), but returns `NULL` if an error occurs, such as a division by zero error.

| X   | Y   | SAFE_DIVIDE(X, Y) |
|-----|-----|-------------------|
| 20  | 4   | 5                 |
| 0   | 20  | `0`               |
| 20  | 0   | `NULL`            |

**Return Data Type**

| INPUT        | `INT64`      | `NUMERIC`    | `BIGNUMERIC` | `FLOAT64` |
|--------------|--------------|--------------|--------------|-----------|
| `INT64`      | `FLOAT64`    | `NUMERIC`    | `BIGNUMERIC` | `FLOAT64` |
| `NUMERIC`    | `NUMERIC`    | `NUMERIC`    | `BIGNUMERIC` | `FLOAT64` |
| `BIGNUMERIC` | `BIGNUMERIC` | `BIGNUMERIC` | `BIGNUMERIC` | `FLOAT64` |
| `FLOAT64`    | `FLOAT64`    | `FLOAT64`    | `FLOAT64`    | `FLOAT64` |

## `SAFE_MULTIPLY`

<div>

</div>

``` devsite-click-to-copy
SAFE_MULTIPLY(X, Y)
```

**Description**

Equivalent to the multiplication operator (`*`), but returns `NULL` if overflow occurs.

| X   | Y   | SAFE_MULTIPLY(X, Y) |
|-----|-----|---------------------|
| 20  | 4   | 80                  |

**Return Data Type**

| INPUT        | `INT64`      | `NUMERIC`    | `BIGNUMERIC` | `FLOAT64` |
|--------------|--------------|--------------|--------------|-----------|
| `INT64`      | `INT64`      | `NUMERIC`    | `BIGNUMERIC` | `FLOAT64` |
| `NUMERIC`    | `NUMERIC`    | `NUMERIC`    | `BIGNUMERIC` | `FLOAT64` |
| `BIGNUMERIC` | `BIGNUMERIC` | `BIGNUMERIC` | `BIGNUMERIC` | `FLOAT64` |
| `FLOAT64`    | `FLOAT64`    | `FLOAT64`    | `FLOAT64`    | `FLOAT64` |

## `SAFE_NEGATE`

<div>

</div>

``` devsite-click-to-copy
SAFE_NEGATE(X)
```

**Description**

Equivalent to the unary minus operator (`-`), but returns `NULL` if overflow occurs.

| X   | SAFE_NEGATE(X) |
|-----|----------------|
| +1  | -1             |
| -1  | +1             |
| 0   | 0              |

**Return Data Type**

| INPUT  | `INT64` | `NUMERIC` | `BIGNUMERIC` | `FLOAT64` |
|--------|---------|-----------|--------------|-----------|
| OUTPUT | `INT64` | `NUMERIC` | `BIGNUMERIC` | `FLOAT64` |

## `SAFE_SUBTRACT`

<div>

</div>

``` devsite-click-to-copy
SAFE_SUBTRACT(X, Y)
```

**Description**

Returns the result of Y subtracted from X. Equivalent to the subtraction operator (`-`), but returns `NULL` if overflow occurs.

| X   | Y   | SAFE_SUBTRACT(X, Y) |
|-----|-----|---------------------|
| 5   | 4   | 1                   |

**Return Data Type**

| INPUT        | `INT64`      | `NUMERIC`    | `BIGNUMERIC` | `FLOAT64` |
|--------------|--------------|--------------|--------------|-----------|
| `INT64`      | `INT64`      | `NUMERIC`    | `BIGNUMERIC` | `FLOAT64` |
| `NUMERIC`    | `NUMERIC`    | `NUMERIC`    | `BIGNUMERIC` | `FLOAT64` |
| `BIGNUMERIC` | `BIGNUMERIC` | `BIGNUMERIC` | `BIGNUMERIC` | `FLOAT64` |
| `FLOAT64`    | `FLOAT64`    | `FLOAT64`    | `FLOAT64`    | `FLOAT64` |

## `SEC`

<div>

</div>

``` devsite-click-to-copy
SEC(X)
```

**Description**

Computes the secant for the angle of `X`, where `X` is specified in radians. `X` can be any data type that [coerces to `FLOAT64`](/bigquery/docs/reference/standard-sql/conversion_rules).

| X      | SEC(X) |
|--------|--------|
| `+inf` | `NaN`  |
| `-inf` | `NaN`  |
| `NaN`  | `NaN`  |
| `NULL` | `NULL` |

**Return Data Type**

`FLOAT64`

**Example**

<div>

</div>

``` devsite-click-to-copy
SELECT SEC(100) AS a, SEC(-1) AS b;

/*----------------+---------------+
 | a              | b             |
 +----------------+---------------+
 | 1.159663822905 | 1.85081571768 |
 +----------------+---------------*/
```

## `SECH`

<div>

</div>

``` devsite-click-to-copy
SECH(X)
```

**Description**

Computes the hyperbolic secant for the angle of `X`, where `X` is specified in radians. `X` can be any data type that [coerces to `FLOAT64`](/bigquery/docs/reference/standard-sql/conversion_rules). Never produces an error.

| X      | SECH(X) |
|--------|---------|
| `+inf` | `0`     |
| `-inf` | `0`     |
| `NaN`  | `NaN`   |
| `NULL` | `NULL`  |

**Return Data Type**

`FLOAT64`

**Example**

<div>

</div>

``` devsite-click-to-copy
SELECT SECH(0.5) AS a, SECH(-2) AS b, SECH(100) AS c;

/*----------------+----------------+---------------------+
 | a              | b              | c                   |
 +----------------+----------------+---------------------+
 | 0.88681888397  | 0.265802228834 | 7.4401519520417E-44 |
 +----------------+----------------+---------------------*/
```

## `SIGN`

<div>

</div>

``` devsite-click-to-copy
SIGN(X)
```

**Description**

Returns `-1`, `0`, or `+1` for negative, zero and positive arguments respectively. For floating point arguments, this function doesn't distinguish between positive and negative zero.

| X   | SIGN(X) |
|-----|---------|
| 25  | +1      |
| 0   | 0       |
| -25 | -1      |
| NaN | NaN     |

**Return Data Type**

| INPUT  | `INT64` | `NUMERIC` | `BIGNUMERIC` | `FLOAT64` |
|--------|---------|-----------|--------------|-----------|
| OUTPUT | `INT64` | `NUMERIC` | `BIGNUMERIC` | `FLOAT64` |

## `SIN`

<div>

</div>

``` devsite-click-to-copy
SIN(X)
```

**Description**

Computes the sine of X where X is specified in radians. Never fails.

| X      | SIN(X) |
|--------|--------|
| `+inf` | `NaN`  |
| `-inf` | `NaN`  |
| `NaN`  | `NaN`  |

## `SINH`

<div>

</div>

``` devsite-click-to-copy
SINH(X)
```

**Description**

Computes the hyperbolic sine of X where X is specified in radians. Generates an error if overflow occurs.

| X      | SINH(X) |
|--------|---------|
| `+inf` | `+inf`  |
| `-inf` | `-inf`  |
| `NaN`  | `NaN`   |

## `SQRT`

<div>

</div>

``` devsite-click-to-copy
SQRT(X)
```

**Description**

Computes the square root of X. Generates an error if X is less than 0.

| X       | SQRT(X) |
|---------|---------|
| `25.0`  | `5.0`   |
| `+inf`  | `+inf`  |
| `X < 0` | Error   |

**Return Data Type**

| INPUT  | `INT64`   | `NUMERIC` | `BIGNUMERIC` | `FLOAT64` |
|--------|-----------|-----------|--------------|-----------|
| OUTPUT | `FLOAT64` | `NUMERIC` | `BIGNUMERIC` | `FLOAT64` |

## `TAN`

<div>

</div>

``` devsite-click-to-copy
TAN(X)
```

**Description**

Computes the tangent of X where X is specified in radians. Generates an error if overflow occurs.

| X      | TAN(X) |
|--------|--------|
| `+inf` | `NaN`  |
| `-inf` | `NaN`  |
| `NaN`  | `NaN`  |

## `TANH`

<div>

</div>

``` devsite-click-to-copy
TANH(X)
```

**Description**

Computes the hyperbolic tangent of X where X is specified in radians. Doesn't fail.

| X      | TANH(X) |
|--------|---------|
| `+inf` | 1.0     |
| `-inf` | -1.0    |
| `NaN`  | `NaN`   |

## `TRUNC`

<div>

</div>

``` devsite-click-to-copy
TRUNC(X [, N])
```

**Description**

If only X is present, `TRUNC` rounds X to the nearest integer whose absolute value isn't greater than the absolute value of X. If N is also present, `TRUNC` behaves like `ROUND(X, N)`, but always rounds towards zero and never overflows.

| X      | TRUNC(X) |
|--------|----------|
| 2.0    | 2.0      |
| 2.3    | 2.0      |
| 2.8    | 2.0      |
| 2.5    | 2.0      |
| -2.3   | -2.0     |
| -2.8   | -2.0     |
| -2.5   | -2.0     |
| 0      | 0        |
| `+inf` | `+inf`   |
| `-inf` | `-inf`   |
| `NaN`  | `NaN`    |

**Return Data Type**

| INPUT  | `INT64`   | `NUMERIC` | `BIGNUMERIC` | `FLOAT64` |
|--------|-----------|-----------|--------------|-----------|
| OUTPUT | `FLOAT64` | `NUMERIC` | `BIGNUMERIC` | `FLOAT64` |

Send feedback

<div class="devsite-floating-action-buttons">

</div>
