# Cloud Build roles and permissions

<div class="devsite-article-body clearfix">

This page lists the IAM roles and permissions for Cloud Build. To search through all roles and permissions, see the [role and permission index](/iam/docs/roles-permissions).

## Cloud Build roles

<div results-count-container="">

</div>

<table class="fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="50%">Role</th>
<th>Permissions</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td class="role-description"><h4 id="cloudbuild.admin" class="role-title add-link" data-text="Cloud Build Admin " tabindex="-1">Cloud Build Admin</h4>
<p>(<code translate="no" dir="ltr">roles/cloudbuild.admin</code>)</p>
<span class="role-description"> </span>
<p>Admin role for Cloud Build</p></td>
<td class="role-permissions"><p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudbuild.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudbuild.builds.approve</code></li>
<li><code translate="no" dir="ltr">cloudbuild.builds.create</code></li>
<li><code translate="no" dir="ltr">cloudbuild.builds.get</code></li>
<li><code translate="no" dir="ltr">cloudbuild.builds.list</code></li>
<li><code translate="no" dir="ltr">cloudbuild.builds.update</code></li>
<li><code translate="no" dir="ltr">cloudbuild.connections.create</code></li>
<li><code translate="no" dir="ltr">cloudbuild.connections.delete</code></li>
<li><code translate="no" dir="ltr">cloudbuild.connections.fetchLinkableRepositories</code></li>
<li><code translate="no" dir="ltr">cloudbuild.connections.get</code></li>
<li><code translate="no" dir="ltr">cloudbuild.connections.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">cloudbuild.connections.list</code></li>
<li><code translate="no" dir="ltr">cloudbuild.connections.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">cloudbuild.connections.update</code></li>
<li><code translate="no" dir="ltr">cloudbuild.integrations.create</code></li>
<li><code translate="no" dir="ltr">cloudbuild.integrations.delete</code></li>
<li><code translate="no" dir="ltr">cloudbuild.integrations.get</code></li>
<li><code translate="no" dir="ltr">cloudbuild.integrations.list</code></li>
<li><code translate="no" dir="ltr">cloudbuild.integrations.update</code></li>
<li><code translate="no" dir="ltr">cloudbuild.locations.get</code></li>
<li><code translate="no" dir="ltr">cloudbuild.locations.list</code></li>
<li><code translate="no" dir="ltr">cloudbuild.operations.get</code></li>
<li><code translate="no" dir="ltr">cloudbuild.operations.list</code></li>
<li><code translate="no" dir="ltr">cloudbuild.repositories.accessReadToken</code></li>
<li><code translate="no" dir="ltr">cloudbuild.repositories.accessReadWriteToken</code></li>
<li><code translate="no" dir="ltr">cloudbuild.repositories.create</code></li>
<li><code translate="no" dir="ltr">cloudbuild.repositories.delete</code></li>
<li><code translate="no" dir="ltr">cloudbuild.repositories.fetchGitRefs</code></li>
<li><code translate="no" dir="ltr">cloudbuild.repositories.get</code></li>
<li><code translate="no" dir="ltr">cloudbuild.repositories.list</code></li>
<li><code translate="no" dir="ltr">cloudbuild.workerpools.create</code></li>
<li><code translate="no" dir="ltr">cloudbuild.workerpools.delete</code></li>
<li><code translate="no" dir="ltr">cloudbuild.workerpools.get</code></li>
<li><code translate="no" dir="ltr">cloudbuild.workerpools.list</code></li>
<li><code translate="no" dir="ltr">cloudbuild.workerpools.update</code></li>
<li><code translate="no" dir="ltr">cloudbuild.workerpools.use</code></li>
</ul>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="cloudbuild.builds.builder" class="role-title add-link" data-text="Cloud Build Service Account " tabindex="-1">Cloud Build Service Account</h4>
<p>(<code translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<span class="role-description custom"> </span>
<p>Provides access to perform builds.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">artifactregistry.aptartifacts.create</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.attachments.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.attachments.create</code></li>
<li><code translate="no" dir="ltr">artifactregistry.attachments.delete</code></li>
<li><code translate="no" dir="ltr">artifactregistry.attachments.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.attachments.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.dockerimages.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.dockerimages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.dockerimages.list</code></li>
</ul>
<p><code translate="no" dir="ltr">artifactregistry.files.download</code></p>
<p><code translate="no" dir="ltr">artifactregistry.files.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.files.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.files.update</code></p>
<p><code translate="no" dir="ltr">artifactregistry.files.upload</code></p>
<p><code translate="no" dir="ltr">artifactregistry.kfpartifacts.create</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.locations.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.locations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.mavenartifacts.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.mavenartifacts.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.mavenartifacts.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.npmpackages.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.npmpackages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.npmpackages.list</code></li>
</ul>
<p><code translate="no" dir="ltr">artifactregistry.packages.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.packages.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.packages.update</code></p>
<p><code translate="no" dir="ltr">artifactregistry.projectconfigs.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.projectsettings.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.pythonpackages.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.pythonpackages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.pythonpackages.list</code></li>
</ul>
<p><code translate="no" dir="ltr">artifactregistry.repositories.createOnPush</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.deleteArtifacts</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.downloadArtifacts</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.exportArtifacts</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.listTagBindings</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.readViaVirtualRepository</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.uploadArtifacts</code></p>
<p><code translate="no" dir="ltr">artifactregistry.rules.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.rules.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.tags.create</code></p>
<p><code translate="no" dir="ltr">artifactregistry.tags.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.tags.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.tags.update</code></p>
<p><code translate="no" dir="ltr">artifactregistry.versions.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.versions.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.yumartifacts.create</code></p>
<p><code translate="no" dir="ltr">cloudbuild.builds.create</code></p>
<p><code translate="no" dir="ltr">cloudbuild.builds.get</code></p>
<p><code translate="no" dir="ltr">cloudbuild.builds.list</code></p>
<p><code translate="no" dir="ltr">cloudbuild.builds.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudbuild.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudbuild.locations.get</code></li>
<li><code translate="no" dir="ltr">cloudbuild.locations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudbuild.operations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudbuild.operations.get</code></li>
<li><code translate="no" dir="ltr">cloudbuild.operations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">cloudbuild.workerpools.use</code></p>
<p><code translate="no" dir="ltr">compute.images.create</code></p>
<p><code translate="no" dir="ltr">containeranalysis.occurrences.create</code></p>
<p><code translate="no" dir="ltr">containeranalysis.occurrences.delete</code></p>
<p><code translate="no" dir="ltr">containeranalysis.occurrences.get</code></p>
<p><code translate="no" dir="ltr">containeranalysis.occurrences.list</code></p>
<p><code translate="no" dir="ltr">containeranalysis.occurrences.update</code></p>
<p><code translate="no" dir="ltr">logging.logEntries.create</code></p>
<p><code translate="no" dir="ltr">logging.logEntries.list</code></p>
<p><code translate="no" dir="ltr">logging.views.access</code></p>
<p><code translate="no" dir="ltr">pubsub.topics.create</code></p>
<p><code translate="no" dir="ltr">pubsub.topics.publish</code></p>
<p><code translate="no" dir="ltr">remotebuildexecution.blobs.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><code translate="no" dir="ltr">source.repos.get</code></p>
<p><code translate="no" dir="ltr">source.repos.list</code></p>
<p><code translate="no" dir="ltr">storage.buckets.create</code></p>
<p><code translate="no" dir="ltr">storage.buckets.get</code></p>
<p><code translate="no" dir="ltr">storage.buckets.list</code></p>
<p><code translate="no" dir="ltr">storage.objects.create</code></p>
<p><code translate="no" dir="ltr">storage.objects.delete</code></p>
<p><code translate="no" dir="ltr">storage.objects.get</code></p>
<p><code translate="no" dir="ltr">storage.objects.list</code></p>
<p><code translate="no" dir="ltr">storage.objects.update</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="cloudbuild.editor" class="role-title add-link" data-text="Cloud Build Editor " tabindex="-1">Cloud Build Editor</h4>
<p>(<code translate="no" dir="ltr">roles/cloudbuild.editor</code>)</p>
<span class="role-description"> </span>
<p>Editor role for Cloud Build</p></td>
<td class="role-permissions"><p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudbuild.builds.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudbuild.builds.approve</code></li>
<li><code translate="no" dir="ltr">cloudbuild.builds.create</code></li>
<li><code translate="no" dir="ltr">cloudbuild.builds.get</code></li>
<li><code translate="no" dir="ltr">cloudbuild.builds.list</code></li>
<li><code translate="no" dir="ltr">cloudbuild.builds.update</code></li>
</ul>
<p><code translate="no" dir="ltr">cloudbuild.connections.create</code></p>
<p><code translate="no" dir="ltr">cloudbuild.connections.delete</code></p>
<p><code translate="no" dir="ltr">cloudbuild.connections.fetchLinkableRepositories</code></p>
<p><code translate="no" dir="ltr">cloudbuild.connections.get</code></p>
<p><code translate="no" dir="ltr">cloudbuild.connections.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudbuild.connections.list</code></p>
<p><code translate="no" dir="ltr">cloudbuild.connections.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudbuild.integrations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudbuild.integrations.create</code></li>
<li><code translate="no" dir="ltr">cloudbuild.integrations.delete</code></li>
<li><code translate="no" dir="ltr">cloudbuild.integrations.get</code></li>
<li><code translate="no" dir="ltr">cloudbuild.integrations.list</code></li>
<li><code translate="no" dir="ltr">cloudbuild.integrations.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudbuild.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudbuild.locations.get</code></li>
<li><code translate="no" dir="ltr">cloudbuild.locations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudbuild.operations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudbuild.operations.get</code></li>
<li><code translate="no" dir="ltr">cloudbuild.operations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">cloudbuild.repositories.create</code></p>
<p><code translate="no" dir="ltr">cloudbuild.repositories.delete</code></p>
<p><code translate="no" dir="ltr">cloudbuild.repositories.fetchGitRefs</code></p>
<p><code translate="no" dir="ltr">cloudbuild.repositories.get</code></p>
<p><code translate="no" dir="ltr">cloudbuild.repositories.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudbuild.workerpools.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudbuild.workerpools.create</code></li>
<li><code translate="no" dir="ltr">cloudbuild.workerpools.delete</code></li>
<li><code translate="no" dir="ltr">cloudbuild.workerpools.get</code></li>
<li><code translate="no" dir="ltr">cloudbuild.workerpools.list</code></li>
<li><code translate="no" dir="ltr">cloudbuild.workerpools.update</code></li>
<li><code translate="no" dir="ltr">cloudbuild.workerpools.use</code></li>
</ul>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="cloudbuild.viewer" class="role-title add-link" data-text="Cloud Build Viewer " tabindex="-1">Cloud Build Viewer</h4>
<p>(<code translate="no" dir="ltr">roles/cloudbuild.viewer</code>)</p>
<span class="role-description"> </span>
<p>Viewer role for Cloud Build</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudbuild.builds.get</code></p>
<p><code translate="no" dir="ltr">cloudbuild.builds.list</code></p>
<p><code translate="no" dir="ltr">cloudbuild.connections.fetchLinkableRepositories</code></p>
<p><code translate="no" dir="ltr">cloudbuild.connections.get</code></p>
<p><code translate="no" dir="ltr">cloudbuild.connections.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudbuild.connections.list</code></p>
<p><code translate="no" dir="ltr">cloudbuild.integrations.get</code></p>
<p><code translate="no" dir="ltr">cloudbuild.integrations.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudbuild.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudbuild.locations.get</code></li>
<li><code translate="no" dir="ltr">cloudbuild.locations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudbuild.operations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudbuild.operations.get</code></li>
<li><code translate="no" dir="ltr">cloudbuild.operations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">cloudbuild.repositories.fetchGitRefs</code></p>
<p><code translate="no" dir="ltr">cloudbuild.repositories.get</code></p>
<p><code translate="no" dir="ltr">cloudbuild.repositories.list</code></p>
<p><code translate="no" dir="ltr">cloudbuild.workerpools.get</code></p>
<p><code translate="no" dir="ltr">cloudbuild.workerpools.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="cloudbuild.builds.approver" class="role-title add-link" data-text="Cloud Build Approver " tabindex="-1">Cloud Build Approver</h4>
<p>(<code translate="no" dir="ltr">roles/cloudbuild.builds.approver</code>)</p>
<span class="role-description"> </span>
<p>Can approve or reject pending builds.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudbuild.builds.approve</code></p>
<p><code translate="no" dir="ltr">cloudbuild.builds.get</code></p>
<p><code translate="no" dir="ltr">cloudbuild.builds.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudbuild.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudbuild.locations.get</code></li>
<li><code translate="no" dir="ltr">cloudbuild.locations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudbuild.operations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudbuild.operations.get</code></li>
<li><code translate="no" dir="ltr">cloudbuild.operations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">remotebuildexecution.blobs.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="cloudbuild.builds.editor" class="role-title add-link" data-text="Cloud Build Editor " tabindex="-1">Cloud Build Editor</h4>
<p>(<code translate="no" dir="ltr">roles/cloudbuild.builds.editor</code>)</p>
<span class="role-description custom"> </span>
<p>Provides access to create and cancel builds.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Project</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudbuild.builds.create</code></p>
<p><code translate="no" dir="ltr">cloudbuild.builds.get</code></p>
<p><code translate="no" dir="ltr">cloudbuild.builds.list</code></p>
<p><code translate="no" dir="ltr">cloudbuild.builds.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudbuild.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudbuild.locations.get</code></li>
<li><code translate="no" dir="ltr">cloudbuild.locations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudbuild.operations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudbuild.operations.get</code></li>
<li><code translate="no" dir="ltr">cloudbuild.operations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">remotebuildexecution.blobs.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="cloudbuild.builds.viewer" class="role-title add-link" data-text="Cloud Build Viewer " tabindex="-1">Cloud Build Viewer</h4>
<p>(<code translate="no" dir="ltr">roles/cloudbuild.builds.viewer</code>)</p>
<span class="role-description custom"> </span>
<p>Provides access to view builds.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Project</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudbuild.builds.get</code></p>
<p><code translate="no" dir="ltr">cloudbuild.builds.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudbuild.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudbuild.locations.get</code></li>
<li><code translate="no" dir="ltr">cloudbuild.locations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudbuild.operations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudbuild.operations.get</code></li>
<li><code translate="no" dir="ltr">cloudbuild.operations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">remotebuildexecution.blobs.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="cloudbuild.connectionAdmin" class="role-title add-link" data-text="Cloud Build Connection Admin " tabindex="-1">Cloud Build Connection Admin</h4>
<p>(<code translate="no" dir="ltr">roles/cloudbuild.connectionAdmin</code>)</p>
<span class="role-description"> </span>
<p>Can manage connections and repositories.</p></td>
<td class="role-permissions"><p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudbuild.connections.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudbuild.connections.create</code></li>
<li><code translate="no" dir="ltr">cloudbuild.connections.delete</code></li>
<li><code translate="no" dir="ltr">cloudbuild.connections.fetchLinkableRepositories</code></li>
<li><code translate="no" dir="ltr">cloudbuild.connections.get</code></li>
<li><code translate="no" dir="ltr">cloudbuild.connections.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">cloudbuild.connections.list</code></li>
<li><code translate="no" dir="ltr">cloudbuild.connections.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">cloudbuild.connections.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudbuild.operations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudbuild.operations.get</code></li>
<li><code translate="no" dir="ltr">cloudbuild.operations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">cloudbuild.repositories.create</code></p>
<p><code translate="no" dir="ltr">cloudbuild.repositories.delete</code></p>
<p><code translate="no" dir="ltr">cloudbuild.repositories.fetchGitRefs</code></p>
<p><code translate="no" dir="ltr">cloudbuild.repositories.get</code></p>
<p><code translate="no" dir="ltr">cloudbuild.repositories.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="cloudbuild.connectionViewer" class="role-title add-link" data-text="Cloud Build Connection Viewer " tabindex="-1">Cloud Build Connection Viewer</h4>
<p>(<code translate="no" dir="ltr">roles/cloudbuild.connectionViewer</code>)</p>
<span class="role-description"> </span>
<p>Can view and list connections and repositories.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudbuild.connections.fetchLinkableRepositories</code></p>
<p><code translate="no" dir="ltr">cloudbuild.connections.get</code></p>
<p><code translate="no" dir="ltr">cloudbuild.connections.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudbuild.connections.list</code></p>
<p><code translate="no" dir="ltr">cloudbuild.repositories.fetchGitRefs</code></p>
<p><code translate="no" dir="ltr">cloudbuild.repositories.get</code></p>
<p><code translate="no" dir="ltr">cloudbuild.repositories.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="cloudbuild.integrationsEditor" class="role-title add-link" data-text="Cloud Build Integrations Editor " tabindex="-1">Cloud Build Integrations Editor</h4>
<p>(<code translate="no" dir="ltr">roles/cloudbuild.integrationsEditor</code>)</p>
<span class="role-description"> </span>
<p>Can update Integrations</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudbuild.integrations.get</code></p>
<p><code translate="no" dir="ltr">cloudbuild.integrations.list</code></p>
<p><code translate="no" dir="ltr">cloudbuild.integrations.update</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="cloudbuild.integrationsOwner" class="role-title add-link" data-text="Cloud Build Integrations Owner " tabindex="-1">Cloud Build Integrations Owner</h4>
<p>(<code translate="no" dir="ltr">roles/cloudbuild.integrationsOwner</code>)</p>
<span class="role-description"> </span>
<p>Can create/delete Integrations</p></td>
<td class="role-permissions"><p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudbuild.integrations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudbuild.integrations.create</code></li>
<li><code translate="no" dir="ltr">cloudbuild.integrations.delete</code></li>
<li><code translate="no" dir="ltr">cloudbuild.integrations.get</code></li>
<li><code translate="no" dir="ltr">cloudbuild.integrations.list</code></li>
<li><code translate="no" dir="ltr">cloudbuild.integrations.update</code></li>
</ul>
<p><code translate="no" dir="ltr">compute.firewalls.create</code></p>
<p><code translate="no" dir="ltr">compute.firewalls.get</code></p>
<p><code translate="no" dir="ltr">compute.firewalls.list</code></p>
<p><code translate="no" dir="ltr">compute.networks.get</code></p>
<p><code translate="no" dir="ltr">compute.networks.updatePolicy</code></p>
<p><code translate="no" dir="ltr">compute.regions.get</code></p>
<p><code translate="no" dir="ltr">compute.subnetworks.get</code></p>
<p><code translate="no" dir="ltr">compute.subnetworks.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="cloudbuild.integrationsViewer" class="role-title add-link" data-text="Cloud Build Integrations Viewer " tabindex="-1">Cloud Build Integrations Viewer</h4>
<p>(<code translate="no" dir="ltr">roles/cloudbuild.integrationsViewer</code>)</p>
<span class="role-description"> </span>
<p>Can view Integrations</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudbuild.integrations.get</code></p>
<p><code translate="no" dir="ltr">cloudbuild.integrations.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="cloudbuild.readTokenAccessor" class="role-title add-link" data-text="Cloud Build Read Only Token Accessor " tabindex="-1">Cloud Build Read Only Token Accessor</h4>
<p>(<code translate="no" dir="ltr">roles/cloudbuild.readTokenAccessor</code>)</p>
<span class="role-description"> </span>
<p>Can view the connection and access its read-only token.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudbuild.connections.get</code></p>
<p><code translate="no" dir="ltr">cloudbuild.repositories.accessReadToken</code></p>
<p><code translate="no" dir="ltr">cloudbuild.repositories.get</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="cloudbuild.tokenAccessor" class="role-title add-link" data-text="Cloud Build Token Accessor " tabindex="-1">Cloud Build Token Accessor</h4>
<p>(<code translate="no" dir="ltr">roles/cloudbuild.tokenAccessor</code>)</p>
<span class="role-description"> </span>
<p>Can view the connection and access its read/write and read-only tokens.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudbuild.connections.get</code></p>
<p><code translate="no" dir="ltr">cloudbuild.repositories.accessReadToken</code></p>
<p><code translate="no" dir="ltr">cloudbuild.repositories.accessReadWriteToken</code></p>
<p><code translate="no" dir="ltr">cloudbuild.repositories.get</code></p>
<p><code translate="no" dir="ltr">cloudbuild.repositories.list</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="cloudbuild.workerPoolEditor" class="role-title add-link" data-text="Cloud Build WorkerPool Editor " tabindex="-1">Cloud Build WorkerPool Editor</h4>
<p>(<code translate="no" dir="ltr">roles/cloudbuild.workerPoolEditor</code>)</p>
<span class="role-description"> </span>
<p>Can update and view WorkerPools</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudbuild.workerpools.get</code></p>
<p><code translate="no" dir="ltr">cloudbuild.workerpools.list</code></p>
<p><code translate="no" dir="ltr">cloudbuild.workerpools.update</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="cloudbuild.workerPoolOwner" class="role-title add-link" data-text="Cloud Build WorkerPool Owner " tabindex="-1">Cloud Build WorkerPool Owner</h4>
<p>(<code translate="no" dir="ltr">roles/cloudbuild.workerPoolOwner</code>)</p>
<span class="role-description"> </span>
<p>Can create, delete, update, and view WorkerPools</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudbuild.workerpools.create</code></p>
<p><code translate="no" dir="ltr">cloudbuild.workerpools.delete</code></p>
<p><code translate="no" dir="ltr">cloudbuild.workerpools.get</code></p>
<p><code translate="no" dir="ltr">cloudbuild.workerpools.list</code></p>
<p><code translate="no" dir="ltr">cloudbuild.workerpools.update</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="cloudbuild.workerPoolUser" class="role-title add-link" data-text="Cloud Build WorkerPool User " tabindex="-1">Cloud Build WorkerPool User</h4>
<p>(<code translate="no" dir="ltr">roles/cloudbuild.workerPoolUser</code>)</p>
<span class="role-description"> </span>
<p>Can run builds in the WorkerPool</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudbuild.workerpools.use</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="cloudbuild.workerPoolViewer" class="role-title add-link" data-text="Cloud Build WorkerPool Viewer " tabindex="-1">Cloud Build WorkerPool Viewer</h4>
<p>(<code translate="no" dir="ltr">roles/cloudbuild.workerPoolViewer</code>)</p>
<span class="role-description"> </span>
<p>Can view WorkerPools</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudbuild.workerpools.get</code></p>
<p><code translate="no" dir="ltr">cloudbuild.workerpools.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
</tbody>
</table>

### Service agent roles

Service agent roles should only be granted to [service agents](/iam/docs/service-agents).

<div results-count-container="">

</div>

<table class="fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="50%">Role</th>
<th>Permissions</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td class="role-description"><h4 id="cloudbuild.loggingServiceAgent" class="role-title add-link" data-text="Cloud Build Logging Service Agent " tabindex="-1">Cloud Build Logging Service Agent</h4>
<p>(<code translate="no" dir="ltr">roles/cloudbuild.loggingServiceAgent</code>)</p>
<span class="role-description"> </span>
<p>Gives the Cloud Build logging-specific service account access to write logs.</p>
<strong>Warning:</strong> Do not grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.</td>
<td class="role-permissions"><p><code translate="no" dir="ltr">logging.buckets.write</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="cloudbuild.serviceAgent" class="role-title add-link" data-text="Cloud Build Service Agent " tabindex="-1">Cloud Build Service Agent</h4>
<p>(<code translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</p>
<span class="role-description"> </span>
<p>Gives Cloud Build service account access to managed resources.</p>
<strong>Warning:</strong> Do not grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.</td>
<td class="role-permissions"><p><code translate="no" dir="ltr">artifactregistry.aptartifacts.create</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.attachments.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.attachments.create</code></li>
<li><code translate="no" dir="ltr">artifactregistry.attachments.delete</code></li>
<li><code translate="no" dir="ltr">artifactregistry.attachments.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.attachments.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.dockerimages.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.dockerimages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.dockerimages.list</code></li>
</ul>
<p><code translate="no" dir="ltr">artifactregistry.files.download</code></p>
<p><code translate="no" dir="ltr">artifactregistry.files.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.files.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.files.update</code></p>
<p><code translate="no" dir="ltr">artifactregistry.files.upload</code></p>
<p><code translate="no" dir="ltr">artifactregistry.kfpartifacts.create</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.locations.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.locations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.mavenartifacts.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.mavenartifacts.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.mavenartifacts.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.npmpackages.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.npmpackages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.npmpackages.list</code></li>
</ul>
<p><code translate="no" dir="ltr">artifactregistry.packages.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.packages.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.packages.update</code></p>
<p><code translate="no" dir="ltr">artifactregistry.projectconfigs.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.projectsettings.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.pythonpackages.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.pythonpackages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.pythonpackages.list</code></li>
</ul>
<p><code translate="no" dir="ltr">artifactregistry.repositories.createOnPush</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.deleteArtifacts</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.downloadArtifacts</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.exportArtifacts</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.listTagBindings</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.readViaVirtualRepository</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.uploadArtifacts</code></p>
<p><code translate="no" dir="ltr">artifactregistry.rules.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.rules.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.tags.create</code></p>
<p><code translate="no" dir="ltr">artifactregistry.tags.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.tags.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.tags.update</code></p>
<p><code translate="no" dir="ltr">artifactregistry.versions.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.versions.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.yumartifacts.create</code></p>
<p><code translate="no" dir="ltr">binaryauthorization.attestors.create</code></p>
<p><code translate="no" dir="ltr">binaryauthorization.attestors.delete</code></p>
<p><code translate="no" dir="ltr">binaryauthorization.attestors.get</code></p>
<p><code translate="no" dir="ltr">binaryauthorization.attestors.list</code></p>
<p><code translate="no" dir="ltr">binaryauthorization.attestors.update</code></p>
<p><code translate="no" dir="ltr">binaryauthorization.attestors.verifyImageAttested</code></p>
<p><code translate="no" dir="ltr">cloudbuild.builds.create</code></p>
<p><code translate="no" dir="ltr">cloudbuild.builds.get</code></p>
<p><code translate="no" dir="ltr">cloudbuild.builds.list</code></p>
<p><code translate="no" dir="ltr">cloudbuild.builds.update</code></p>
<p><code translate="no" dir="ltr">cloudbuild.connections.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudbuild.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudbuild.locations.get</code></li>
<li><code translate="no" dir="ltr">cloudbuild.locations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudbuild.operations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudbuild.operations.get</code></li>
<li><code translate="no" dir="ltr">cloudbuild.operations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">cloudbuild.repositories.accessReadToken</code></p>
<p><code translate="no" dir="ltr">cloudbuild.repositories.accessReadWriteToken</code></p>
<p><code translate="no" dir="ltr">cloudbuild.repositories.get</code></p>
<p><code translate="no" dir="ltr">cloudbuild.repositories.list</code></p>
<p><code translate="no" dir="ltr">cloudbuild.workerpools.use</code></p>
<p><code translate="no" dir="ltr">compute.firewalls.get</code></p>
<p><code translate="no" dir="ltr">compute.firewalls.list</code></p>
<p><code translate="no" dir="ltr">compute.images.create</code></p>
<p><code translate="no" dir="ltr">compute.networkAttachments.get</code></p>
<p><code translate="no" dir="ltr">compute.networkAttachments.update</code></p>
<p><code translate="no" dir="ltr">compute.networks.get</code></p>
<p><code translate="no" dir="ltr">compute.regionOperations.get</code></p>
<p><code translate="no" dir="ltr">compute.subnetworks.get</code></p>
<p><code translate="no" dir="ltr">containeranalysis.notes.attachOccurrence</code></p>
<p><code translate="no" dir="ltr">containeranalysis.notes.create</code></p>
<p><code translate="no" dir="ltr">containeranalysis.notes.delete</code></p>
<p><code translate="no" dir="ltr">containeranalysis.notes.get</code></p>
<p><code translate="no" dir="ltr">containeranalysis.notes.list</code></p>
<p><code translate="no" dir="ltr">containeranalysis.notes.update</code></p>
<p><code translate="no" dir="ltr">containeranalysis.occurrences.create</code></p>
<p><code translate="no" dir="ltr">containeranalysis.occurrences.delete</code></p>
<p><code translate="no" dir="ltr">containeranalysis.occurrences.get</code></p>
<p><code translate="no" dir="ltr">containeranalysis.occurrences.list</code></p>
<p><code translate="no" dir="ltr">containeranalysis.occurrences.update</code></p>
<p><code translate="no" dir="ltr">developerconnect.connections.get</code></p>
<p><code translate="no" dir="ltr">developerconnect.gitRepositoryLinks.fetchReadToken</code></p>
<p><code translate="no" dir="ltr">developerconnect.gitRepositoryLinks.fetchReadWriteToken</code></p>
<p><code translate="no" dir="ltr">developerconnect.gitRepositoryLinks.get</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.get</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.getAccessToken</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.getOpenIdToken</code></p>
<p><code translate="no" dir="ltr">logging.buckets.create</code></p>
<p><code translate="no" dir="ltr">logging.buckets.get</code></p>
<p><code translate="no" dir="ltr">logging.buckets.list</code></p>
<p><code translate="no" dir="ltr">logging.logEntries.create</code></p>
<p><code translate="no" dir="ltr">logging.logEntries.list</code></p>
<p><code translate="no" dir="ltr">logging.views.access</code></p>
<p><code translate="no" dir="ltr">pubsub.subscriptions.create</code></p>
<p><code translate="no" dir="ltr">pubsub.subscriptions.delete</code></p>
<p><code translate="no" dir="ltr">pubsub.subscriptions.get</code></p>
<p><code translate="no" dir="ltr">pubsub.subscriptions.update</code></p>
<p><code translate="no" dir="ltr">pubsub.topics.attachSubscription</code></p>
<p><code translate="no" dir="ltr">pubsub.topics.create</code></p>
<p><code translate="no" dir="ltr">pubsub.topics.get</code></p>
<p><code translate="no" dir="ltr">pubsub.topics.publish</code></p>
<p><code translate="no" dir="ltr">remotebuildexecution.blobs.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><code translate="no" dir="ltr">servicedirectory.endpoints.get</code></p>
<p><code translate="no" dir="ltr">servicedirectory.endpoints.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">servicedirectory.endpoints.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">servicedirectory.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">servicedirectory.locations.get</code></li>
<li><code translate="no" dir="ltr">servicedirectory.locations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">servicedirectory.namespaces.get</code></p>
<p><code translate="no" dir="ltr">servicedirectory.namespaces.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">servicedirectory.namespaces.list</code></p>
<p><code translate="no" dir="ltr">servicedirectory.networks.access</code></p>
<p><code translate="no" dir="ltr">servicedirectory.services.get</code></p>
<p><code translate="no" dir="ltr">servicedirectory.services.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">servicedirectory.services.list</code></p>
<p><code translate="no" dir="ltr">servicedirectory.services.resolve</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.use</code></p>
<p><code translate="no" dir="ltr">source.repos.get</code></p>
<p><code translate="no" dir="ltr">source.repos.list</code></p>
<p><code translate="no" dir="ltr">storage.buckets.create</code></p>
<p><code translate="no" dir="ltr">storage.buckets.get</code></p>
<p><code translate="no" dir="ltr">storage.buckets.list</code></p>
<p><code translate="no" dir="ltr">storage.objects.create</code></p>
<p><code translate="no" dir="ltr">storage.objects.delete</code></p>
<p><code translate="no" dir="ltr">storage.objects.get</code></p>
<p><code translate="no" dir="ltr">storage.objects.list</code></p>
<p><code translate="no" dir="ltr">storage.objects.update</code></p></td>
</tr>
</tbody>
</table>

## Cloud Build permissions

<div results-count-container="">

</div>

<table class="permissions-table fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="45%">Permission</th>
<th>Included in roles</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td><h4 id="cloudbuild.builds.approve" class="permission-name add-link" data-text="cloudbuild.builds.approve" tabindex="-1"><code translate="no" dir="ltr">cloudbuild.builds.approve</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.admin">Cloud Build Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.editor">Cloud Build Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.approver">Cloud Build Approver</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.approver</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="cloudbuild.builds.create" class="permission-name add-link" data-text="cloudbuild.builds.create" tabindex="-1"><code translate="no" dir="ltr">cloudbuild.builds.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.admin">Cloud Build Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.editor">Cloud Build Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.admin">Dataflow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.editor">Cloud Build Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.developer">Dataflow Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/appengineflex#appengineflex.serviceAgent">App Engine flexible environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengineflex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudconfig#cloudconfig.serviceAgent">Infrastructure Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudconfig.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/clouddeploy#clouddeploy.serviceAgent">Cloud Deploy Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploy.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/configdelivery#configdelivery.serviceAgent">Config Delivery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/configdelivery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/designcenter#designcenter.serviceAgent">DesignCenter Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.serviceAgent">Firebase App Hosting Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/runapps#runapps.serviceAgent">Serverless Integrations Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/runapps.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="cloudbuild.builds.get" class="permission-name add-link" data-text="cloudbuild.builds.get" tabindex="-1"><code translate="no" dir="ltr">cloudbuild.builds.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.admin">Cloud Build Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.editor">Cloud Build Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.viewer">Cloud Build Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.admin">Dataflow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.admin">Application Design Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.admin">Gemini Cloud Assist Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.editor">Gemini Cloud Assist Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.user">Gemini Cloud Assist User</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.approver">Cloud Build Approver</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.approver</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.editor">Cloud Build Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.viewer">Cloud Build Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.developer">Dataflow Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.applicationAdmin">Application Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.applicationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.applicationEditor">Application Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.applicationEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/appengineflex#appengineflex.serviceAgent">App Engine flexible environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengineflex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudconfig#cloudconfig.serviceAgent">Infrastructure Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudconfig.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/clouddeploy#clouddeploy.serviceAgent">Cloud Deploy Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploy.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/configdelivery#configdelivery.serviceAgent">Config Delivery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/configdelivery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/designcenter#designcenter.serviceAgent">DesignCenter Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.serviceAgent">Firebase App Hosting Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/runapps#runapps.serviceAgent">Serverless Integrations Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/runapps.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="cloudbuild.builds.list" class="permission-name add-link" data-text="cloudbuild.builds.list" tabindex="-1"><code translate="no" dir="ltr">cloudbuild.builds.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.admin">Cloud Build Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.editor">Cloud Build Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.viewer">Cloud Build Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.admin">Dataflow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.admin">Application Design Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.admin">Gemini Cloud Assist Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.editor">Gemini Cloud Assist Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.user">Gemini Cloud Assist User</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.approver">Cloud Build Approver</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.approver</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.editor">Cloud Build Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.viewer">Cloud Build Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.developer">Dataflow Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.applicationAdmin">Application Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.applicationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.applicationEditor">Application Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.applicationEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudconfig#cloudconfig.serviceAgent">Infrastructure Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudconfig.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/clouddeploy#clouddeploy.serviceAgent">Cloud Deploy Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploy.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/configdelivery#configdelivery.serviceAgent">Config Delivery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/configdelivery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/designcenter#designcenter.serviceAgent">DesignCenter Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="cloudbuild.builds.update" class="permission-name add-link" data-text="cloudbuild.builds.update" tabindex="-1"><code translate="no" dir="ltr">cloudbuild.builds.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.admin">Cloud Build Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.editor">Cloud Build Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.admin">Dataflow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.editor">Cloud Build Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.developer">Dataflow Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudconfig#cloudconfig.serviceAgent">Infrastructure Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudconfig.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/clouddeploy#clouddeploy.serviceAgent">Cloud Deploy Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploy.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/configdelivery#configdelivery.serviceAgent">Config Delivery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/configdelivery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.serviceAgent">Firebase App Hosting Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="cloudbuild.connections.create" class="permission-name add-link" data-text="cloudbuild.connections.create" tabindex="-1"><code translate="no" dir="ltr">cloudbuild.connections.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.admin">Cloud Build Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.editor">Cloud Build Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.connectionAdmin">Cloud Build Connection Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.connectionAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="cloudbuild.connections.delete" class="permission-name add-link" data-text="cloudbuild.connections.delete" tabindex="-1"><code translate="no" dir="ltr">cloudbuild.connections.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.admin">Cloud Build Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.editor">Cloud Build Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.connectionAdmin">Cloud Build Connection Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.connectionAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="cloudbuild.connections.fetchLinkableRepositories" class="permission-name add-link" data-text="cloudbuild.connections.fetchLinkableRepositories" tabindex="-1"><code translate="no" dir="ltr">cloudbuild.connections.fetchLinkableRepositories</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.admin">Cloud Build Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.editor">Cloud Build Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.viewer">Cloud Build Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.connectionAdmin">Cloud Build Connection Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.connectionAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.connectionViewer">Cloud Build Connection Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.connectionViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="cloudbuild.connections.get" class="permission-name add-link" data-text="cloudbuild.connections.get" tabindex="-1"><code translate="no" dir="ltr">cloudbuild.connections.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.admin">Cloud Build Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.editor">Cloud Build Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.viewer">Cloud Build Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.connectionAdmin">Cloud Build Connection Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.connectionAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.connectionViewer">Cloud Build Connection Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.connectionViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.readTokenAccessor">Cloud Build Read Only Token Accessor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.readTokenAccessor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.tokenAccessor">Cloud Build Token Accessor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.tokenAccessor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudaicompanion#cloudaicompanion.serviceAgent">Gemini for Google Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudaicompanion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.serviceAgent">Firebase App Hosting Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="cloudbuild.connections.getIamPolicy" class="permission-name add-link" data-text="cloudbuild.connections.getIamPolicy" tabindex="-1"><code translate="no" dir="ltr">cloudbuild.connections.getIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.admin">Cloud Build Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.editor">Cloud Build Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.viewer">Cloud Build Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.connectionAdmin">Cloud Build Connection Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.connectionAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.connectionViewer">Cloud Build Connection Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.connectionViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="cloudbuild.connections.list" class="permission-name add-link" data-text="cloudbuild.connections.list" tabindex="-1"><code translate="no" dir="ltr">cloudbuild.connections.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.admin">Cloud Build Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.editor">Cloud Build Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.viewer">Cloud Build Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.connectionAdmin">Cloud Build Connection Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.connectionAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.connectionViewer">Cloud Build Connection Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.connectionViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/config#config.agent">Cloud Infrastructure Manager Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/config.agent</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.serviceAgent">Cluster Director Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="cloudbuild.connections.setIamPolicy" class="permission-name add-link" data-text="cloudbuild.connections.setIamPolicy" tabindex="-1"><code translate="no" dir="ltr">cloudbuild.connections.setIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.admin">Cloud Build Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.connectionAdmin">Cloud Build Connection Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.connectionAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="cloudbuild.connections.update" class="permission-name add-link" data-text="cloudbuild.connections.update" tabindex="-1"><code translate="no" dir="ltr">cloudbuild.connections.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.admin">Cloud Build Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.editor">Cloud Build Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.connectionAdmin">Cloud Build Connection Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.connectionAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="cloudbuild.integrations.create" class="permission-name add-link" data-text="cloudbuild.integrations.create" tabindex="-1"><code translate="no" dir="ltr">cloudbuild.integrations.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.admin">Cloud Build Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.editor">Cloud Build Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.integrationsOwner">Cloud Build Integrations Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.integrationsOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="cloudbuild.integrations.delete" class="permission-name add-link" data-text="cloudbuild.integrations.delete" tabindex="-1"><code translate="no" dir="ltr">cloudbuild.integrations.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.admin">Cloud Build Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.editor">Cloud Build Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.integrationsOwner">Cloud Build Integrations Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.integrationsOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="cloudbuild.integrations.get" class="permission-name add-link" data-text="cloudbuild.integrations.get" tabindex="-1"><code translate="no" dir="ltr">cloudbuild.integrations.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.admin">Cloud Build Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.editor">Cloud Build Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.viewer">Cloud Build Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.integrationsEditor">Cloud Build Integrations Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.integrationsEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.integrationsOwner">Cloud Build Integrations Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.integrationsOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.integrationsViewer">Cloud Build Integrations Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.integrationsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="cloudbuild.integrations.list" class="permission-name add-link" data-text="cloudbuild.integrations.list" tabindex="-1"><code translate="no" dir="ltr">cloudbuild.integrations.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.admin">Cloud Build Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.editor">Cloud Build Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.viewer">Cloud Build Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.integrationsEditor">Cloud Build Integrations Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.integrationsEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.integrationsOwner">Cloud Build Integrations Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.integrationsOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.integrationsViewer">Cloud Build Integrations Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.integrationsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="cloudbuild.integrations.update" class="permission-name add-link" data-text="cloudbuild.integrations.update" tabindex="-1"><code translate="no" dir="ltr">cloudbuild.integrations.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.admin">Cloud Build Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.editor">Cloud Build Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.integrationsEditor">Cloud Build Integrations Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.integrationsEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.integrationsOwner">Cloud Build Integrations Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.integrationsOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="cloudbuild.locations.get" class="permission-name add-link" data-text="cloudbuild.locations.get" tabindex="-1"><code translate="no" dir="ltr">cloudbuild.locations.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.admin">Cloud Build Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.editor">Cloud Build Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.viewer">Cloud Build Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.admin">Dataflow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.approver">Cloud Build Approver</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.approver</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.editor">Cloud Build Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.viewer">Cloud Build Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.developer">Dataflow Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="cloudbuild.locations.list" class="permission-name add-link" data-text="cloudbuild.locations.list" tabindex="-1"><code translate="no" dir="ltr">cloudbuild.locations.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.admin">Cloud Build Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.editor">Cloud Build Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.viewer">Cloud Build Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.admin">Dataflow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.approver">Cloud Build Approver</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.approver</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.editor">Cloud Build Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.viewer">Cloud Build Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.developer">Dataflow Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="cloudbuild.operations.get" class="permission-name add-link" data-text="cloudbuild.operations.get" tabindex="-1"><code translate="no" dir="ltr">cloudbuild.operations.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.admin">Cloud Build Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.editor">Cloud Build Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.viewer">Cloud Build Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.admin">Dataflow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.approver">Cloud Build Approver</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.approver</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.editor">Cloud Build Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.viewer">Cloud Build Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.connectionAdmin">Cloud Build Connection Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.connectionAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.developer">Dataflow Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.serviceAgent">Firebase App Hosting Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="cloudbuild.operations.list" class="permission-name add-link" data-text="cloudbuild.operations.list" tabindex="-1"><code translate="no" dir="ltr">cloudbuild.operations.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.admin">Cloud Build Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.editor">Cloud Build Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.viewer">Cloud Build Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.admin">Dataflow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.approver">Cloud Build Approver</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.approver</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.editor">Cloud Build Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.viewer">Cloud Build Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.connectionAdmin">Cloud Build Connection Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.connectionAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.developer">Dataflow Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="cloudbuild.repositories.accessReadToken" class="permission-name add-link" data-text="cloudbuild.repositories.accessReadToken" tabindex="-1"><code translate="no" dir="ltr">cloudbuild.repositories.accessReadToken</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.admin">Cloud Build Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.readTokenAccessor">Cloud Build Read Only Token Accessor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.readTokenAccessor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.tokenAccessor">Cloud Build Token Accessor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.tokenAccessor</code>)</p>
<p><a href="/iam/docs/roles-permissions/config#config.agent">Cloud Infrastructure Manager Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/config.agent</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudaicompanion#cloudaicompanion.serviceAgent">Gemini for Google Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudaicompanion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.serviceAgent">Firebase App Hosting Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.serviceAgent">Cluster Director Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="cloudbuild.repositories.accessReadWriteToken" class="permission-name add-link" data-text="cloudbuild.repositories.accessReadWriteToken" tabindex="-1"><code translate="no" dir="ltr">cloudbuild.repositories.accessReadWriteToken</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.admin">Cloud Build Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.tokenAccessor">Cloud Build Token Accessor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.tokenAccessor</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.serviceAgent">Firebase App Hosting Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="cloudbuild.repositories.create" class="permission-name add-link" data-text="cloudbuild.repositories.create" tabindex="-1"><code translate="no" dir="ltr">cloudbuild.repositories.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.admin">Cloud Build Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.editor">Cloud Build Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.connectionAdmin">Cloud Build Connection Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.connectionAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="cloudbuild.repositories.delete" class="permission-name add-link" data-text="cloudbuild.repositories.delete" tabindex="-1"><code translate="no" dir="ltr">cloudbuild.repositories.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.admin">Cloud Build Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.editor">Cloud Build Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.connectionAdmin">Cloud Build Connection Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.connectionAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="cloudbuild.repositories.fetchGitRefs" class="permission-name add-link" data-text="cloudbuild.repositories.fetchGitRefs" tabindex="-1"><code translate="no" dir="ltr">cloudbuild.repositories.fetchGitRefs</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.admin">Cloud Build Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.editor">Cloud Build Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.viewer">Cloud Build Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.connectionAdmin">Cloud Build Connection Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.connectionAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.connectionViewer">Cloud Build Connection Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.connectionViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudaicompanion#cloudaicompanion.serviceAgent">Gemini for Google Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudaicompanion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="cloudbuild.repositories.get" class="permission-name add-link" data-text="cloudbuild.repositories.get" tabindex="-1"><code translate="no" dir="ltr">cloudbuild.repositories.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.admin">Cloud Build Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.editor">Cloud Build Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.viewer">Cloud Build Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.connectionAdmin">Cloud Build Connection Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.connectionAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.connectionViewer">Cloud Build Connection Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.connectionViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.readTokenAccessor">Cloud Build Read Only Token Accessor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.readTokenAccessor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.tokenAccessor">Cloud Build Token Accessor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.tokenAccessor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudaicompanion#cloudaicompanion.serviceAgent">Gemini for Google Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudaicompanion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/configdelivery#configdelivery.serviceAgent">Config Delivery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/configdelivery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.serviceAgent">Firebase App Hosting Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="cloudbuild.repositories.list" class="permission-name add-link" data-text="cloudbuild.repositories.list" tabindex="-1"><code translate="no" dir="ltr">cloudbuild.repositories.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.admin">Cloud Build Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.editor">Cloud Build Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.viewer">Cloud Build Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.connectionAdmin">Cloud Build Connection Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.connectionAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.connectionViewer">Cloud Build Connection Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.connectionViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.tokenAccessor">Cloud Build Token Accessor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.tokenAccessor</code>)</p>
<p><a href="/iam/docs/roles-permissions/config#config.agent">Cloud Infrastructure Manager Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/config.agent</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudaicompanion#cloudaicompanion.serviceAgent">Gemini for Google Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudaicompanion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.serviceAgent">Cluster Director Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="cloudbuild.workerpools.create" class="permission-name add-link" data-text="cloudbuild.workerpools.create" tabindex="-1"><code translate="no" dir="ltr">cloudbuild.workerpools.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.admin">Cloud Build Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.editor">Cloud Build Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.workerPoolOwner">Cloud Build WorkerPool Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.workerPoolOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="cloudbuild.workerpools.delete" class="permission-name add-link" data-text="cloudbuild.workerpools.delete" tabindex="-1"><code translate="no" dir="ltr">cloudbuild.workerpools.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.admin">Cloud Build Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.editor">Cloud Build Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.workerPoolOwner">Cloud Build WorkerPool Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.workerPoolOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="cloudbuild.workerpools.get" class="permission-name add-link" data-text="cloudbuild.workerpools.get" tabindex="-1"><code translate="no" dir="ltr">cloudbuild.workerpools.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.admin">Cloud Build Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.editor">Cloud Build Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.viewer">Cloud Build Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.workerPoolEditor">Cloud Build WorkerPool Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.workerPoolEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.workerPoolOwner">Cloud Build WorkerPool Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.workerPoolOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.workerPoolViewer">Cloud Build WorkerPool Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.workerPoolViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="cloudbuild.workerpools.list" class="permission-name add-link" data-text="cloudbuild.workerpools.list" tabindex="-1"><code translate="no" dir="ltr">cloudbuild.workerpools.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.admin">Cloud Build Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.editor">Cloud Build Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.viewer">Cloud Build Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.workerPoolEditor">Cloud Build WorkerPool Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.workerPoolEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.workerPoolOwner">Cloud Build WorkerPool Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.workerPoolOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.workerPoolViewer">Cloud Build WorkerPool Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.workerPoolViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="cloudbuild.workerpools.update" class="permission-name add-link" data-text="cloudbuild.workerpools.update" tabindex="-1"><code translate="no" dir="ltr">cloudbuild.workerpools.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.admin">Cloud Build Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.editor">Cloud Build Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.workerPoolEditor">Cloud Build WorkerPool Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.workerPoolEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.workerPoolOwner">Cloud Build WorkerPool Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.workerPoolOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="cloudbuild.workerpools.use" class="permission-name add-link" data-text="cloudbuild.workerpools.use" tabindex="-1"><code translate="no" dir="ltr">cloudbuild.workerpools.use</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.admin">Cloud Build Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.editor">Cloud Build Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.workerPoolUser">Cloud Build WorkerPool User</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.workerPoolUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudconfig#cloudconfig.serviceAgent">Infrastructure Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudconfig.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/clouddeploy#clouddeploy.serviceAgent">Cloud Deploy Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploy.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
</ul></td>
</tr>
</tbody>
</table>

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
