# Offset (Transformation Stage)

<div class="devsite-article-body clearfix devsite-no-page-title">

# Offset (Transformation Stage)

## Description

Skips the first `N` input documents.

## Examples

<div class="ds-selector-tabs" ds-scope="lang">

<div class="section">

##### Node.js

<div>

</div>

``` devsite-click-to-copy
const results = await db.pipeline()
  .collection("cities")
  .offset(10)
  .execute();test.firestore.js
```

</div>

<div class="section">

### <span class="two-line-tab"><span tab-label="modular API"></span>Web</span>

<div>

</div>

``` devsite-click-to-copy
const results = await execute(db.pipeline()
  .collection("cities")
  .offset(10));test.firestore.js
```

</div>

<div class="section">

##### Swift

<div>

</div>

``` devsite-click-to-copy
let results = try await db.pipeline()
  .collection("cities")
  .offset(10)
  .execute()PipelineSnippets.swift
```

</div>

<div class="section">

##### <span class="two-line-tab">Kotlin <span class="firebase-platform-label">Android</span></span>

<div>

</div>

``` devsite-click-to-copy
val results = db.pipeline()
    .collection("cities")
    .offset(10)
    .execute()DocSnippets.kt
```

</div>

<div class="section">

##### <span class="two-line-tab">Java <span class="firebase-platform-label">Android</span></span>

<div>

</div>

``` devsite-click-to-copy
Task<Pipeline.Snapshot> results = db.pipeline()
        .collection("cities")
        .offset(10)
        .execute();DocSnippets.java
```

</div>

<div class="section">

##### Python

<div>

</div>

``` devsite-click-to-copy
results = client.pipeline().collection("cities").offset(10).execute()firestore_pipelines.py
```

</div>

<div class="section">

##### Java

<div>

</div>

``` devsite-click-to-copy
Pipeline.Snapshot results =
    firestore.pipeline().collection("cities").offset(10).execute().get();PipelineSnippets.java
```

</div>

<div class="section">

##### Go

<div>

</div>

``` devsite-click-to-copy
snapshot := client.Pipeline().Collection("cities").Offset(10).Execute(ctx)pipeline_snippets_general.go
```

</div>

</div>

## Behavior

The `offset(...)` stage will skip the first `N` input documents. Unless a [`sort(...)`](/firestore/native/docs/pipeline/stages/transformation/sort) stage is used before the offset, the order in which documents are returned is unstable and repeated executions might produce different results.

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
