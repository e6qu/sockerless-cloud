# Secret Manager roles and permissions

<div class="devsite-article-body clearfix">

This page lists the IAM roles and permissions for Secret Manager. To search through all roles and permissions, see the [role and permission index](/iam/docs/roles-permissions).

## Secret Manager roles

<div results-count-container="">

</div>

<table class="fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="50%">Role</th>
<th>Permissions</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td class="role-description"><h4 id="secretmanager.admin" class="role-title add-link" data-text="Secret Manager Admin " tabindex="-1">Secret Manager Admin</h4>
<p>(<code translate="no" dir="ltr">roles/secretmanager.admin</code>)</p>
<span class="role-description"> </span>
<p>Full access to administer Secret Manager resources.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Secret</li>
</ul></td>
<td class="role-permissions"><p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudkms.keyHandles.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudkms.keyHandles.create</code></li>
<li><code translate="no" dir="ltr">cloudkms.keyHandles.get</code></li>
<li><code translate="no" dir="ltr">cloudkms.keyHandles.list</code></li>
</ul>
<p><code translate="no" dir="ltr">cloudkms.operations.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.projects.showEffectiveAutokeyConfig</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">secretmanager.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">secretmanager.locations.get</code></li>
<li><code translate="no" dir="ltr">secretmanager.locations.list</code></li>
<li><code translate="no" dir="ltr">secretmanager.secrets.create</code></li>
<li><code translate="no" dir="ltr">secretmanager.secrets.createTagBinding</code></li>
<li><code translate="no" dir="ltr">secretmanager.secrets.delete</code></li>
<li><code translate="no" dir="ltr">secretmanager.secrets.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">secretmanager.secrets.enableManagedRotation</code></li>
<li><code translate="no" dir="ltr">secretmanager.secrets.get</code></li>
<li><code translate="no" dir="ltr">secretmanager.secrets.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">secretmanager.secrets.list</code></li>
<li><code translate="no" dir="ltr">secretmanager.secrets.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">secretmanager.secrets.listTagBindings</code></li>
<li><code translate="no" dir="ltr">secretmanager.secrets.rotate</code></li>
<li><code translate="no" dir="ltr">secretmanager.secrets.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">secretmanager.secrets.update</code></li>
<li><code translate="no" dir="ltr">secretmanager.versions.access</code></li>
<li><code translate="no" dir="ltr">secretmanager.versions.add</code></li>
<li><code translate="no" dir="ltr">secretmanager.versions.destroy</code></li>
<li><code translate="no" dir="ltr">secretmanager.versions.disable</code></li>
<li><code translate="no" dir="ltr">secretmanager.versions.enable</code></li>
<li><code translate="no" dir="ltr">secretmanager.versions.get</code></li>
<li><code translate="no" dir="ltr">secretmanager.versions.list</code></li>
</ul></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="secretmanager.editor" class="role-title add-link" data-text="Secret Manager Editor " tabindex="-1">Secret Manager Editor</h4>
<p>(<code translate="no" dir="ltr">roles/secretmanager.editor</code>)</p>
<span class="role-description"> </span>
<p>Editor role for Secret Manager</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">secretmanager.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">secretmanager.locations.get</code></li>
<li><code translate="no" dir="ltr">secretmanager.locations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">secretmanager.secrets.create</code></p>
<p><code translate="no" dir="ltr">secretmanager.secrets.delete</code></p>
<p><code translate="no" dir="ltr">secretmanager.secrets.enableManagedRotation</code></p>
<p><code translate="no" dir="ltr">secretmanager.secrets.get</code></p>
<p><code translate="no" dir="ltr">secretmanager.secrets.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">secretmanager.secrets.list</code></p>
<p><code translate="no" dir="ltr">secretmanager.secrets.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">secretmanager.secrets.listTagBindings</code></p>
<p><code translate="no" dir="ltr">secretmanager.secrets.rotate</code></p>
<p><code translate="no" dir="ltr">secretmanager.secrets.update</code></p>
<p><code translate="no" dir="ltr">secretmanager.versions.add</code></p>
<p><code translate="no" dir="ltr">secretmanager.versions.destroy</code></p>
<p><code translate="no" dir="ltr">secretmanager.versions.disable</code></p>
<p><code translate="no" dir="ltr">secretmanager.versions.enable</code></p>
<p><code translate="no" dir="ltr">secretmanager.versions.get</code></p>
<p><code translate="no" dir="ltr">secretmanager.versions.list</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="secretmanager.secretAccessor" class="role-title add-link" data-text="Secret Manager Secret Accessor " tabindex="-1">Secret Manager Secret Accessor</h4>
<p>(<code translate="no" dir="ltr">roles/secretmanager.secretAccessor</code>)</p>
<span class="role-description"> </span>
<p>Allows accessing the payload of secrets.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Secret</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><code translate="no" dir="ltr">secretmanager.versions.access</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="secretmanager.viewer" class="role-title add-link" data-text="Secret Manager Viewer " tabindex="-1">Secret Manager Viewer</h4>
<p>(<code translate="no" dir="ltr">roles/secretmanager.viewer</code>)</p>
<span class="role-description"> </span>
<p>Allows viewing metadata of all Secret Manager resources</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Secret</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">secretmanager.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">secretmanager.locations.get</code></li>
<li><code translate="no" dir="ltr">secretmanager.locations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">secretmanager.secrets.get</code></p>
<p><code translate="no" dir="ltr">secretmanager.secrets.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">secretmanager.secrets.list</code></p>
<p><code translate="no" dir="ltr">secretmanager.secrets.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">secretmanager.secrets.listTagBindings</code></p>
<p><code translate="no" dir="ltr">secretmanager.versions.get</code></p>
<p><code translate="no" dir="ltr">secretmanager.versions.list</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="secretmanager.secretVersionAdder" class="role-title add-link" data-text="Secret Manager Secret Version Adder " tabindex="-1">Secret Manager Secret Version Adder</h4>
<p>(<code translate="no" dir="ltr">roles/secretmanager.secretVersionAdder</code>)</p>
<span class="role-description"> </span>
<p>Allows adding versions to existing secrets.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Secret</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><code translate="no" dir="ltr">secretmanager.secrets.rotate</code></p>
<p><code translate="no" dir="ltr">secretmanager.versions.add</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="secretmanager.secretVersionManager" class="role-title add-link" data-text="Secret Manager Secret Version Manager " tabindex="-1">Secret Manager Secret Version Manager</h4>
<p>(<code translate="no" dir="ltr">roles/secretmanager.secretVersionManager</code>)</p>
<span class="role-description"> </span>
<p>Allows creating and managing versions of existing secrets.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Secret</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><code translate="no" dir="ltr">secretmanager.secrets.rotate</code></p>
<p><code translate="no" dir="ltr">secretmanager.versions.add</code></p>
<p><code translate="no" dir="ltr">secretmanager.versions.destroy</code></p>
<p><code translate="no" dir="ltr">secretmanager.versions.disable</code></p>
<p><code translate="no" dir="ltr">secretmanager.versions.enable</code></p>
<p><code translate="no" dir="ltr">secretmanager.versions.get</code></p>
<p><code translate="no" dir="ltr">secretmanager.versions.list</code></p></td>
</tr>
</tbody>
</table>

## Secret Manager permissions

<div results-count-container="">

</div>

<table class="permissions-table fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="45%">Permission</th>
<th>Included in roles</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td><h4 id="secretmanager.locations.get" class="permission-name add-link" data-text="secretmanager.locations.get" tabindex="-1"><code translate="no" dir="ltr">secretmanager.locations.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.admin">Secret Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.editor">Secret Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.viewer">Secret Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="secretmanager.locations.list" class="permission-name add-link" data-text="secretmanager.locations.list" tabindex="-1"><code translate="no" dir="ltr">secretmanager.locations.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.admin">Secret Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.editor">Secret Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.viewer">Secret Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="secretmanager.secrets.create" class="permission-name add-link" data-text="secretmanager.secrets.create" tabindex="-1"><code translate="no" dir="ltr">secretmanager.secrets.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.admin">Secret Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.editor">Secret Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.editor</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="secretmanager.secrets.createTagBinding" class="permission-name add-link" data-text="secretmanager.secrets.createTagBinding" tabindex="-1"><code translate="no" dir="ltr">secretmanager.secrets.createTagBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.admin">Secret Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="secretmanager.secrets.delete" class="permission-name add-link" data-text="secretmanager.secrets.delete" tabindex="-1"><code translate="no" dir="ltr">secretmanager.secrets.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.admin">Secret Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.editor">Secret Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.editor</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="secretmanager.secrets.deleteTagBinding" class="permission-name add-link" data-text="secretmanager.secrets.deleteTagBinding" tabindex="-1"><code translate="no" dir="ltr">secretmanager.secrets.deleteTagBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.admin">Secret Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="secretmanager.secrets.enableManagedRotation" class="permission-name add-link" data-text="secretmanager.secrets.enableManagedRotation" tabindex="-1"><code translate="no" dir="ltr">secretmanager.secrets.enableManagedRotation</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.admin">Secret Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.editor">Secret Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.editor</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="secretmanager.secrets.get" class="permission-name add-link" data-text="secretmanager.secrets.get" tabindex="-1"><code translate="no" dir="ltr">secretmanager.secrets.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.admin">Secret Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.editor">Secret Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.viewer">Secret Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="secretmanager.secrets.getIamPolicy" class="permission-name add-link" data-text="secretmanager.secrets.getIamPolicy" tabindex="-1"><code translate="no" dir="ltr">secretmanager.secrets.getIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/connectors#connectors.admin">Connector Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/connectors.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.admin">Secret Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.editor">Secret Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.viewer">Secret Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="secretmanager.secrets.list" class="permission-name add-link" data-text="secretmanager.secrets.list" tabindex="-1"><code translate="no" dir="ltr">secretmanager.secrets.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.admin">Secret Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.editor">Secret Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.viewer">Secret Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.serviceAgent">Audit Manager Auditing Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="secretmanager.secrets.listEffectiveTags" class="permission-name add-link" data-text="secretmanager.secrets.listEffectiveTags" tabindex="-1"><code translate="no" dir="ltr">secretmanager.secrets.listEffectiveTags</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagViewer">Tag Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.admin">Secret Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.editor">Secret Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.viewer">Secret Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="secretmanager.secrets.listTagBindings" class="permission-name add-link" data-text="secretmanager.secrets.listTagBindings" tabindex="-1"><code translate="no" dir="ltr">secretmanager.secrets.listTagBindings</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagViewer">Tag Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.admin">Secret Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.editor">Secret Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.viewer">Secret Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="secretmanager.secrets.rotate" class="permission-name add-link" data-text="secretmanager.secrets.rotate" tabindex="-1"><code translate="no" dir="ltr">secretmanager.secrets.rotate</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.admin">Secret Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.editor">Secret Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.secretVersionAdder">Secret Manager Secret Version Adder</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.secretVersionAdder</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.secretVersionManager">Secret Manager Secret Version Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.secretVersionManager</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="secretmanager.secrets.setIamPolicy" class="permission-name add-link" data-text="secretmanager.secrets.setIamPolicy" tabindex="-1"><code translate="no" dir="ltr">secretmanager.secrets.setIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.admin">Secret Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.admin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="secretmanager.secrets.update" class="permission-name add-link" data-text="secretmanager.secrets.update" tabindex="-1"><code translate="no" dir="ltr">secretmanager.secrets.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.admin">Secret Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.editor">Secret Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.editor</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="secretmanager.versions.access" class="permission-name add-link" data-text="secretmanager.versions.access" tabindex="-1"><code translate="no" dir="ltr">secretmanager.versions.access</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.admin">Secret Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.secretAccessor">Secret Manager Secret Accessor</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.secretAccessor</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="secretmanager.versions.add" class="permission-name add-link" data-text="secretmanager.versions.add" tabindex="-1"><code translate="no" dir="ltr">secretmanager.versions.add</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.admin">Secret Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.editor">Secret Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.secretVersionAdder">Secret Manager Secret Version Adder</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.secretVersionAdder</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.secretVersionManager">Secret Manager Secret Version Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.secretVersionManager</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="secretmanager.versions.destroy" class="permission-name add-link" data-text="secretmanager.versions.destroy" tabindex="-1"><code translate="no" dir="ltr">secretmanager.versions.destroy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.admin">Secret Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.editor">Secret Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.secretVersionManager">Secret Manager Secret Version Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.secretVersionManager</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="secretmanager.versions.disable" class="permission-name add-link" data-text="secretmanager.versions.disable" tabindex="-1"><code translate="no" dir="ltr">secretmanager.versions.disable</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.admin">Secret Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.editor">Secret Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.secretVersionManager">Secret Manager Secret Version Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.secretVersionManager</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="secretmanager.versions.enable" class="permission-name add-link" data-text="secretmanager.versions.enable" tabindex="-1"><code translate="no" dir="ltr">secretmanager.versions.enable</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.admin">Secret Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.editor">Secret Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.secretVersionManager">Secret Manager Secret Version Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.secretVersionManager</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="secretmanager.versions.get" class="permission-name add-link" data-text="secretmanager.versions.get" tabindex="-1"><code translate="no" dir="ltr">secretmanager.versions.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.admin">Secret Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.editor">Secret Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.viewer">Secret Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.secretVersionManager">Secret Manager Secret Version Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.secretVersionManager</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="secretmanager.versions.list" class="permission-name add-link" data-text="secretmanager.versions.list" tabindex="-1"><code translate="no" dir="ltr">secretmanager.versions.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.admin">Secret Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.editor">Secret Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.viewer">Secret Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.secretVersionManager">Secret Manager Secret Version Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.secretVersionManager</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p></td>
</tr>
</tbody>
</table>

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
