# Shrink instance storage capacity

<div class="devsite-article-body clearfix">

<div class="nocontent" style="font-size:medium; margin-bottom:40px; border-top:1px solid black;">

<div style="float:right">

<a href="/sql/docs/mysql/shrink-instance-storage-capacity" data-track-type="sqlSwitcher" data-track-name="mysqlLink" title="View this page for the MySQL database engine">MySQL</a> <span style="color:light-gray">  \|  </span><span style="font-weight:bold">PostgreSQL</span> <span style="color:light-gray">  \|  </span><a href="/sql/docs/sqlserver/shrink-instance-storage-capacity" data-track-type="sqlSwitcher" data-track-name="sqlServerLink" title="View this page for the SQL Server database engine">SQL Server</a>

</div>

</div>

This page shows you how to manage the storage capacity of a Cloud SQL instance using storage shrink capabilities.

## Before you begin

1.  Review the [feature's limitations](/sql/docs/postgres/about-storage-shrink#limitations).

2.  If you're using [gcloud CLI](/sdk/gcloud), make sure you are using the latest version of Google Cloud SDK and gcloud CLI.

    - [Install the latest gcloud CLI version](/sdk/docs/install#linux) (gcloud CLI version 563.0.0 or later).
    - To get the current gcloud CLI version, run `gcloud --version`.
    - To update the gcloud CLI version, run `gcloud components update`.

3.  Get the following IAM permissions:

    - `cloudsql.instances.getDiskShrinkConfig`
    - `cloudsql.instances.performDiskShrink`

    These permissions are available in either of the following roles. When assigning your role, we recommend applying the principle of least privilege:

    - Cloud SQL Admin (`roles/cloudsql.admin`)
    - Cloud SQL Editor (`roles/cloudsql.editor`)

    For more information, see the following resources:

    - [Cloud SQL roles](/sql/docs/postgres/iam-roles)
    - [Understanding roles](/iam/docs/understanding-roles)
    - [Granting IAM permissions](/iam/docs/granting-changing-revoking-access)

## Prepare the instance

Complete the following requirements before you begin.

These steps are the same for primary instances and read replicas.

If updating a read replica, make sure to shrink the capacity of the primary instance first, then shrink the size of the replica.

1.  [Get the project ID](/resource-manager/docs/creating-managing-projects#identifying_projects) of the project containing the instance you want to manage.

2.  [Check the current state of the instance](/sql/docs/postgres/instance-info#info) to make sure it is running. One way to check is to use the [`describe`](/sdk/gcloud/reference/sql/instances/describe) command:

    <div>

    </div>

    ``` devsite-click-to-copy
      gcloud sql instances describe
    ```

    Returns the following status:

    <div>

    </div>

    ``` devsite-click-to-copy
      RUNNABLE
    ```

    If not, [start the instance](/sql/docs/postgres/start-stop-restart-instance#start).

3.  [Create a backup](/sql/docs/postgres/backup-recovery/backing-up#on-demand) of the current instance. This lets you [restore the instance](/sql/docs/postgres/backup-recovery/restoring#restorebackups) later if you run into issues during configuration.

4.  If you are running a PostgreSQL instance, set the [`max_wal_size`](https://www.postgresql.org/docs/current/runtime-config-wal.html#GUC-MAX-WAL-SIZE) flag value to less than 5128 MB. If the `max_wal_size` value is too large, the instance might be slow to start and the operation might fail.

5.  Disable all extensions or features that enable outbound connections (or require outbound data transfer). For example, an outbound connection might be established using one of these extensions or features, and should be disabled before performing a storage shrink operation:

    - `dblink` extension
    - `PL/proxy` extension
    - `pglogical` extension
    - Foreign data wrappers (such as `postgres_fdw`, `oracle_fdw`, and `tds_fdw`)
    - [Logical replication](https://www.postgresql.org/docs/current/logical-replication.html) in PostgreSQL 10 and later

## Shrink the storage capacity of an instance

The following steps are the same for primary instances and read replicas.

1.  Check the target minimum storage capacity of the instance and the estimated operation time. This information can help you plan your storage shrink operation.

    **Note:** You can't check the target minimum storage capacity for read replicas. Read replica storage capacity typically matches its associated primary instance.

    <div>

    <div class="section">

    ### gcloud

    Run the [`gcloud sql instances get-storage-shrink-config`](/sdk/gcloud/reference/sql/instances) command:

    <div>

    </div>

    ``` devsite-click-to-copy
    gcloud sql instances get-storage-shrink-config INSTANCE_NAME
    ```

    Replace the following:

    - `INSTANCE_NAME`: the name of the primary instance.

    The response includes a value for `minimalTargetSizeGb`. You can use this value to determine the value you want to use for the `--storage-size` parameter when you run a storage shrink operation.

    The response also returns a message with an estimated operation time, similar to the following:

    <div>

    </div>

    ``` devsite-click-to-copy
    ...
    "The estimated operation time is 20 minutes".
    ```

    </div>

    <div class="section">

    ### REST v1

    Use the [GET](/sql/docs/postgres/admin-api/rest/v1/instances/get) method to view the instance's target minimum storage capacity.

    Before using any of the request data, make the following replacements:

    - `PROJECT_ID`: the name of the project where the primary instance resides.
    - `INSTANCE_ID`: the instance ID of the primary instance.

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    GET https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/instances/INSTANCE_ID/getDiskShrinkConfig
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X GET \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         "https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/instances/INSTANCE_ID/getDiskShrinkConfig"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method GET `
        -Headers $headers `
        -Uri "https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/instances/INSTANCE_ID/getDiskShrinkConfig" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a JSON response similar to the following:

    <div class="section expandable">

    #### Response

    <div>

    </div>

    ``` readonly
    {
      "kind": "sql#instance",
      "min_target_size_gb": "1234"
      "message": "The size of your instance's storage impacts IOPS, and therefore shrinking your storage
        may have a negative impact on IOPS. Before shrinking your storage, please refer to our
        documentation on Cloud SQL limits to understand what impact shrinking your storage might have:
        https://docs.cloud.google.com/sql/docs/quotas#fixed-limits. Additionally, we recommend leaving an
        appropriate buffer for operational purposes, like reindexing, etc. We recommend a buffer of at
        least 100 GB or 20% more than current usage, whichever is larger. For more details, please refer
        to: https://docs.cloud.google.com/sql/docs/shared-responsibility. The estimated operation time is
        20 minutes."
    }
    ```

    </div>

    The response includes a value for `min_target_size_gb`. You can use this value to determine the value you want to use for the `--storage-size` parameter when you run a storage shrink operation.

    The response also returns a message with an estimated operation time, similar to the following:

    <div>

    </div>

    ``` devsite-click-to-copy
    ...
    "The estimated operation time is 20 minutes".
    ```

    </div>

    <div class="section">

    ### REST v1beta4

    Use the [GET](/sql/docs/postgres/admin-api/rest/v1beta4/instances/get) method to view the instance's target minimum storage capacity.

    Before using any of the request data, make the following replacements:

    - `PROJECT_ID`: the name of the project where the primary instance resides.
    - `INSTANCE_ID`: the instance ID of the primary instance.

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    GET https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/instances/INSTANCE_ID/getDiskShrinkConfig
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X GET \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         "https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/instances/INSTANCE_ID/getDiskShrinkConfig"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method GET `
        -Headers $headers `
        -Uri "https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/instances/INSTANCE_ID/getDiskShrinkConfig" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a JSON response similar to the following:

    <div class="section expandable">

    #### Response

    <div>

    </div>

    ``` readonly
    {
      "kind": "sql#instance",
      "min_target_size_gb": "1234"
      "message": "The size of your instance's storage impacts IOPS, and therefore shrinking your storage
        may have a negative impact on IOPS. Before shrinking your storage, please refer to our
        documentation on Cloud SQL limits to understand what impact shrinking your storage might have:
        https://docs.cloud.google.com/sql/docs/quotas#fixed-limits. Additionally, we recommend leaving an
        appropriate buffer for operational purposes, like reindexing, etc. We recommend a buffer of at
        least 100 GB or 20% more than current usage, whichever is larger. For more details, please refer
        to: https://docs.cloud.google.com/sql/docs/shared-responsibility. The estimated operation time is
        20 minutes."
    }
    ```

    </div>

    The response includes a value for `min_target_size_gb`. You can use this value to determine the value you want to use for the `--storage-size` parameter when you run a storage shrink operation.

    The response also returns a message with an estimated operation time, similar to the following:

    <div>

    </div>

    ``` devsite-click-to-copy
    ...
    "The estimated operation time is 20 minutes".
    ```

    </div>

    </div>

2.  Shrink storage capacity of the instance.

    **Note:** The `--storage-size` parameter is only supported for primary or standalone instances. To shrink storage on a replica instance, omit the `--storage-size` parameter in the command.

    <div>

    <div class="section">

    ### gcloud

    Run the following command to shrink storage on the instance:

    <div>

    </div>

    ``` devsite-click-to-copy
    gcloud sql instances perform-storage-shrink INSTANCE_NAME \
      --storage-size=TARGET_STORAGE_SIZE
    ```

    Replace the following:

    - `INSTANCE_NAME`: the name of the instance.
    - `TARGET_STORAGE_SIZE`: the target storage capacity in GB. For example, 100 GB.

    </div>

    <div class="section">

    ### REST v1

    Before using any of the request data, make the following replacements:

    - `PROJECT_ID`: the ID of the project where the instance resides.
    - `INSTANCE_ID`: the ID of the instance.
    - `TARGET_STORAGE_SIZE`: the target storage size in GB.

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    POST https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/instances/INSTANCE_ID/performDiskShrink
    ```

    </div>

    Request JSON body:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    {
      "targetSizeGb": TARGET_STORAGE_SIZE
    }
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Save the request body in a file named `request.json`, and execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X POST \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         -H "Content-Type: application/json; charset=utf-8" \
         -d @request.json \
         "https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/instances/INSTANCE_ID/performDiskShrink"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Save the request body in a file named `request.json`, and execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method POST `
        -Headers $headers `
        -ContentType: "application/json; charset=utf-8" `
        -InFile request.json `
        -Uri "https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/instances/INSTANCE_ID/performDiskShrink" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a JSON response similar to the following:

    <div class="section expandable">

    #### Response

    <div>

    </div>

    ``` readonly

    {
      "kind": "sql#operation",
      "targetLink": "https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/instances/INSTANCE_ID",
      "status": "PENDING",
      "user": "user@example.com",
      "insertTime": "2019-09-25T22:19:33.735Z",
      "operationType": "UPDATE",
      "name": "operation-id",
      "targetId": "INSTANCE_ID",
      "selfLink": "https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/operations/operation-id",
      "targetProject": "PROJECT_ID"
    }
    ```

    </div>

    </div>

    <div class="section">

    ### REST v1beta4

    Before using any of the request data, make the following replacements:

    - `PROJECT_ID`: the ID of the project where the instance resides.
    - `INSTANCE_ID`: the ID of the instance.
    - `TARGET_STORAGE_SIZE`: the target storage size of the instance.

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    POST https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/instances/INSTANCE_ID/performDiskShrink
    ```

    </div>

    Request JSON body:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    {
      "targetSizeGb": TARGET_STORAGE_SIZE
    }
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Save the request body in a file named `request.json`, and execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X POST \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         -H "Content-Type: application/json; charset=utf-8" \
         -d @request.json \
         "https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/instances/INSTANCE_ID/performDiskShrink"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Save the request body in a file named `request.json`, and execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method POST `
        -Headers $headers `
        -ContentType: "application/json; charset=utf-8" `
        -InFile request.json `
        -Uri "https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/instances/INSTANCE_ID/performDiskShrink" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a JSON response similar to the following:

    <div class="section expandable">

    #### Response

    <div>

    </div>

    ``` readonly

    {
      "kind": "sql#operation",
      "targetLink": "https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/instances/INSTANCE_ID",
      "status": "PENDING",
      "user": "user@example.com",
      "insertTime": "2019-09-25T22:19:33.735Z",
      "operationType": "UPDATE",
      "name": "operation-id",
      "targetId": "INSTANCE_ID",
      "selfLink": "https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/operations/operation-id",
      "targetProject": "PROJECT_ID"
    }
    ```

    </div>

    </div>

    </div>

3.  To check the status of the storage shrink operation, see [Check the status of an operation](#check-status).

## Cancel storage shrink operation

**Note:** Cancel operations are only supported on primary or standalone instances.

1.  Get the storage shrink operation ID.

    You can retrieve the operation ID by running the following [list](/sdk/gcloud/reference/sql/operations/list) command:

    <div>

    </div>

    ``` devsite-click-to-copy
    gcloud sql operations list
    ```

2.  Send a cancellation request.

    <div>

    <div class="section">

    ### gcloud

    Run the following command to cancel the request:

    <div>

    </div>

    ``` devsite-click-to-copy
    gcloud sql operations cancel OPERATION_ID
    ```

    Replace the following:

    `OPERATION_ID`: the ID of the storage shrink operation you want to cancel.

    </div>

    <div class="section">

    ### REST v1

    Before using any of the request data, make the following replacements:

    - `PROJECT_ID`: the ID of the project where the instance resides.
    - `OPERATION_ID`: the ID of the storage shrink operation you want to cancel.

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    POST https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/operations/OPERATION_ID/cancel
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X POST \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         -H "Content-Type: application/json; charset=utf-8" \
         -d "" \
         "https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/operations/OPERATION_ID/cancel"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method POST `
        -Headers $headers `
        -Uri "https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/operations/OPERATION_ID/cancel" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a successful status code (2xx) and an empty response.

    </div>

    <div class="section">

    ### REST v1beta4

    Before using any of the request data, make the following replacements:

    - `PROJECT_ID`: the ID of the project where the instance resides.
    - `OPERATION_ID`: the ID of the storage shrink operation you want to cancel.

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    POST https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/operations/OPERATION_ID/cancel
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X POST \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         -H "Content-Type: application/json; charset=utf-8" \
         -d "" \
         "https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/operations/OPERATION_ID/cancel"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method POST `
        -Headers $headers `
        -Uri "https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/operations/OPERATION_ID/cancel" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a successful status code (2xx) and an empty response.

    </div>

    </div>

## Check the status of a cancellation request or other operation

To check the status of a request, run the following commands:

<div>

<div class="section">

### gcloud

1.  Get the operation ID for the cancellation request:

    <div>

    </div>

    ``` devsite-click-to-copy
    gcloud sql operations list
    ```

2.  Check the status of the operation:

    <div>

    </div>

    ``` devsite-click-to-copy
    gcloud sql operations describe OPERATION_ID
    ```

    Replace the following:

    `OPERATION_ID`: the ID of the operation you want to check.

</div>

<div class="section">

### REST v1

Before using any of the request data, make the following replacements:

- `PROJECT_ID`: the name of the project where the instance resides.
- `OPERATION_ID`: the ID of the storage shrink operation.

HTTP method and URL:

<div class="section">

<div>

</div>

``` devsite-click-to-copy
GET https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/operations/OPERATION_ID
```

</div>

To send your request, expand one of these options:

<div class="section expandable">

#### curl (Linux, macOS, or Cloud Shell)

**Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).

Execute the following command:

<div class="section">

<div>

</div>

``` devsite-click-to-copy
curl -X GET \
     -H "Authorization: Bearer $(gcloud auth print-access-token)" \
     "https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/operations/OPERATION_ID"
```

</div>

</div>

<div class="section expandable">

#### PowerShell (Windows)

**Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).

Execute the following command:

<div class="section">

<div>

</div>

``` devsite-click-to-copy
$cred = gcloud auth print-access-token
$headers = @{ "Authorization" = "Bearer $cred" }

Invoke-WebRequest `
    -Method GET `
    -Headers $headers `
    -Uri "https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/operations/OPERATION_ID" | Select-Object -Expand Content
```

</div>

</div>

You should receive a JSON response similar to the following:

<div class="section expandable">

#### Response

<div>

</div>

``` readonly
{
  "kind": "sql#operation",
  "targetLink": "https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/instances/INSTANCE_ID",
  "status": "RUNNING",
  "user": "user@example.com",
  "insertTime": "2023-12-18T22:43:09.849Z",
  "startTime": "2023-12-18T22:43:10.373Z",
  "operationType": "UPDATE",
  "name": "OPERATION_ID",
  "targetId": "example_instance",
  "selfLink": "https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/operations/OPERATION_ID",
  "targetProject": "PROJECT_ID"
}
```

</div>

</div>

<div class="section">

### REST v1beta4

Before using any of the request data, make the following replacements:

- `PROJECT_ID`: the name of the project where the instance resides.
- `OPERATION_ID`: the ID of the storage shrink operation.

HTTP method and URL:

<div class="section">

<div>

</div>

``` devsite-click-to-copy
GET https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/operations/OPERATION_ID
```

</div>

To send your request, expand one of these options:

<div class="section expandable">

#### curl (Linux, macOS, or Cloud Shell)

**Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).

Execute the following command:

<div class="section">

<div>

</div>

``` devsite-click-to-copy
curl -X GET \
     -H "Authorization: Bearer $(gcloud auth print-access-token)" \
     "https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/operations/OPERATION_ID"
```

</div>

</div>

<div class="section expandable">

#### PowerShell (Windows)

**Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).

Execute the following command:

<div class="section">

<div>

</div>

``` devsite-click-to-copy
$cred = gcloud auth print-access-token
$headers = @{ "Authorization" = "Bearer $cred" }

Invoke-WebRequest `
    -Method GET `
    -Headers $headers `
    -Uri "https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/operations/OPERATION_ID" | Select-Object -Expand Content
```

</div>

</div>

You should receive a JSON response similar to the following:

<div class="section expandable">

#### Response

<div>

</div>

``` readonly
{
  "kind": "sql#operation",
  "targetLink": "https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/instances/INSTANCE_ID",
  "status": "RUNNING",
  "user": "user@example.com",
  "insertTime": "2023-12-18T22:43:09.849Z",
  "startTime": "2023-12-18T22:43:10.373Z",
  "operationType": "UPDATE",
  "name": "OPERATION_ID",
  "targetId": "example_instance",
  "selfLink": "https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/operations/OPERATION_ID",
  "targetProject": "PROJECT_ID"
}
```

</div>

</div>

</div>

## Troubleshooting

For information regarding troubleshooting, see [Issues updating storage capacity](/sql/docs/postgres/issues-updating-storage-capacity).

## What's next

- [About storage shrink](/sql/docs/postgres/about-storage-shrink)
- [Cloud SQL error messages](/sql/docs/postgres/error-messages)
- [Cloud SQL storage options](/sql/docs/postgres/storage-options-overview)

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
