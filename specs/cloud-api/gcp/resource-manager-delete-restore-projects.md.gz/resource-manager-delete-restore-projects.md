# Delete and restore projects

<div class="devsite-article-body clearfix">

You can shut down Google Cloud projects when you no longer need them, and restore deleted projects within a 30-day recovery period. Before you shut down a project, review the deletion timeline and understand when Google Cloud permanently deletes project resources so that you can prevent unexpected data loss.

## Shut down (delete) a project

Shutting down a project stops all billing and resource usage. This action immediately moves the project into a 30-day recovery period, after which the project and all associated data are permanently deleted. Only projects with a lifecycle state of `ACTIVE` can be shut down.

**Deletion process and timeline**

When you initiate a shutdown, the following events occur:

1.  Immediate shutdown: The project is immediately marked for deletion and becomes unusable.

2.  Notification: Google Cloud sends a notification email to the user who initiated the deletion and to any contacts listed in the Technical category of [Essential Contacts](/resource-manager/docs/managing-notification-contacts).

    **Note:** Deletion proceeds even if notification emails can't be delivered. If no Technical contact is specified, fallback contacts aren't notified.

3.  Billing disconnection: Any associated Cloud Billing account is disconnected. This association isn't automatically reinstated if the project is later restored.

4.  30-day recovery window: The project remains in a `DELETE_REQUESTED` state for 30 days. During this period, project owners can restore the project.

5.  Permanent deletion: After 30 days, the project and all its resources are permanently deleted and can't be recovered.

**Track deletion progress**

After you initiate a shutdown, you can use the `gcloud projects describe` command to track the progress of the 30-day deletion period:

<div>

</div>

``` devsite-click-to-copy
gcloud projects describe PROJECT_ID
```

The output displays the `lifecycleState` and other project details, as shown in the following example:

<div>

</div>

``` devsite-click-to-copy
createTime: '2025-06-14T10:00:00.000Z'
lifecycleState: DELETE_REQUESTED
name: Test Project
parent:
  id: '123456789012'
  type: folder
projectId: Test Project
projectNumber: '987654321098'
```

**Critical considerations**

Before shutting down a project, review the following risks:

- Resource recovery: While most resources are recoverable within the 30-day window, some services—such as [Cloud Storage](/storage/docs/projects#project-deletions) and Pub/Sub—might delete resources much sooner. These might not be fully recoverable even if the project is restored.

- Restoration delays: If you restore a project, some services may take up to 36 hours to fully resume operations.

- Project IDs: Project IDs are unique and permanent. Once a project is fully deleted, its ID can't be reused. If you want to preserve a custom project ID for future use, delete the resources within the project instead of shutting down the project itself.

- Project quota: Until a project is permanently deleted (after the 30-day window), it continues to count toward your project quota.

- Billing charges: Projects may continue to incur charges until the current billing cycle ends. To avoid unexpected charges, [disable billing](/billing/docs/how-to/modify-project#disable_billing_for_a_project) manually before initiating a shutdown.

- **Active Committed Use Discounts (CUDs)**: If you have active CUDs in a project, deleting the project can lead to unexpected billing issues or cancellation of the discounts. To prevent accidental deletion of projects with active CUDs, we recommend applying [project liens](/resource-manager/docs/project-liens).

**Safeguards**

To prevent accidental deletion of business-critical projects, you can enable [change risk recommendations](/recommender/docs/change-risk-recommendations). These recommendations provide warnings when you attempt to delete projects that Google Cloud has identified as important based on recent activity.

To learn more about data retention and safe deletion, see [How Google retains data we collect](https://policies.google.com/technologies/retention).

You can shut down projects using the Google Cloud console, Google Cloud CLI, or the API.

<div>

<div class="section">

### Console

1.  In the Google Cloud console, go to the IAM & Admin **Settings** page.

    <a href="https://console.cloud.google.com/iam-admin/settings?walkthrough_id=resource-manager--shutdown-project&amp;start_index=1#step_index=1" class="button button-primary" target="console" data-track-name="consoleLink" data-track-type="task" data-track-metadata-position="body" data-track-metadata-id="resource-manager--shutdown-project&amp;start_index=1" data-track-metadata-event-detail="iam-admin/settings">Go to IAM &amp; Admin Settings</a>

    The remaining steps appear in the Google Cloud console.

2.  On the **IAM & Admin Settings** page, select the project you want to delete, and then click **Shut down**.

    **Shut down** only appears for users who have the `resourcemanager.projects.delete` permission in the current project.

3.  Click **Shut down**.

4.  Enter the project ID, and then click **Shut down anyway**.

Alternatively, you can delete a project from the **Manage resources** page:

1.  In the Google Cloud console, go to the **Manage resources** page.

    <a href="https://console.cloud.google.com/iam-admin/projects" class="button button-primary">Go to Manage resources</a>

2.  Select the project you want to delete.

3.  Click **Delete**.

4.  Enter the project ID and click **Shut down**.

</div>

<div class="section">

### gcloud

1.  In the Google Cloud console, activate Cloud Shell.

    <a href="https://console.cloud.google.com/?cloudshell=true" class="button button-primary" target="console" data-track-type="commonIncludes" data-track-name="consoleLink" data-track-metadata-end-goal="launchCloudShell">Activate Cloud Shell</a>

    At the bottom of the Google Cloud console, a [Cloud Shell](/shell/docs/how-cloud-shell-works) session starts and displays a command-line prompt. Cloud Shell is a shell environment with the Google Cloud CLI already installed and with values already set for your current project. It can take a few seconds for the session to initialize.

2.  To delete a project, use the [`gcloud projects delete`](/sdk/gcloud/reference/projects/delete) command:

    <div>

    </div>

    ``` devsite-click-to-copy
    gcloud projects delete PROJECT_ID
    ```

    Where `PROJECT_ID` is the ID of the project you want to delete.

</div>

<div class="section">

### REST

The following code snippet deletes the specified project:

Request:

<div>

</div>

``` devsite-click-to-copy
DELETE https://cloudresourcemanager.googleapis.com/v3/projects/my-project-123
```

</div>

</div>

### Troubleshoot project deletion

If you encounter issues while attempting to shut down or restore a project, it's typically due to permission constraints or specific resource "liens." For information, see [Troubleshoot project deletion](/resource-manager/docs/troubleshooting-project-deletion).

## Restore a project

Project owners can restore a deleted project within the 30-day recovery period that begins when the project is shut down.

Restoring a project returns it to its state prior to shutdown, with the following exceptions:

- Billing is disabled on the project when the [project is shut down](#shutting_down_projects). It isn't automatically re-enabled upon restoration. You must [manually link the project to a Cloud Billing account](/billing/docs/how-to/modify-project#enable_billing_for_an_existing_project). You might need to wait a few hours before you can successfully link a recently restored project to a billing account.

- You can recover most resources if you restore a project within the 30-day period. Some services such as Cloud Storage or Pub/Sub might delete data sooner than 30 days. For example, [Cloud Storage resources that are protected by soft delete](/storage/docs/soft-delete) might be deleted after **7 days**, depending on the soft delete retention duration, but buckets that have soft delete disabled might be deleted immediately and might not be recoverable. The success rate of resource recovery is linked to the dependencies of those resources.

- It can take up to 36 hours for all services within a restored project to become fully functional. In particular, **OAuth clients** may take **1 to 3 days** to be fully operational after a project is restored. If your resources aren't restored after this period, reach out to [Google support](https://console.cloud.google.com/support).

- Some services might need to be restarted manually. For more information, see [Restarting Google Cloud Services](/billing/docs/how-to/restart-services).

To restore a project, you must have the `resourcemanager.projects.undelete` permission on the project. To view projects pending deletion in the console, you also need the following permissions:

- `resourcemanager.projects.list`
- `resourcemanager.folders.list` (if the project is in a folder)
- `resourcemanager.projects.get`

To restore a project, use one of the following methods:

<div>

<div class="section">

### Console

1.  In the Google Cloud console, go to the **Manage resources** page.

    <a href="https://console.cloud.google.com/iam-admin/projects" class="button button-primary">Go to Manage resources</a>

2.  In the **Project picker** at the top of the page, select your organization resource.

3.  Below the list of organization resources, folders, and projects, click **Resources pending deletion**.

4.  Select the checkbox for the project you want to restore, and then click **Restore**. In the dialog that appears, confirm that you want to restore the project.

</div>

<div class="section">

### gcloud

1.  In the Google Cloud console, activate Cloud Shell.

    <a href="https://console.cloud.google.com/?cloudshell=true" class="button button-primary" target="console" data-track-type="commonIncludes" data-track-name="consoleLink" data-track-metadata-end-goal="launchCloudShell">Activate Cloud Shell</a>

    At the bottom of the Google Cloud console, a [Cloud Shell](/shell/docs/how-cloud-shell-works) session starts and displays a command-line prompt. Cloud Shell is a shell environment with the Google Cloud CLI already installed and with values already set for your current project. It can take a few seconds for the session to initialize.

2.  To restore a project, use the [`gcloud projects undelete`](/sdk/gcloud/reference/projects/undelete) command:

    <div>

    </div>

    ``` devsite-click-to-copy
    gcloud projects undelete PROJECT_ID
    ```

    `PROJECT_ID` is the project ID or project number of the project you want to restore.

</div>

<div class="section">

### REST

The following code snippet restores the specified project:

Request:

<div>

</div>

``` devsite-click-to-copy
POST https://cloudresourcemanager.googleapis.com/v3/projects/my-project-123:undelete
```

</div>

</div>

## What's next

- Learn how to [move a project within your resource hierarchy](/resource-manager/docs/moving-projects-folders).
- Learn how to [migrate a project from one organization resource to another](/resource-manager/docs/project-migration).

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
