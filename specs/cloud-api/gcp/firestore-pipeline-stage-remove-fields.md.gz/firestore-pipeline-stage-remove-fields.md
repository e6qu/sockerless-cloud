# Remove Fields (Transformation Stage)

<div class="devsite-article-body clearfix devsite-no-page-title">

# Remove Fields (Transformation Stage)

## Description

Remove fields from the documents produced by the previous stage.

The generated documents will contain all fields from the previous stage except for the fields specified to be removed.

## Examples

<div class="ds-selector-tabs" ds-scope="lang">

<div class="section">

##### Node.js

<div>

</div>

``` devsite-click-to-copy
const results = await db.pipeline()
  .collection("cities")
  .removeFields("population", "location.state")
  .execute();test.firestore.js
```

</div>

<div class="section">

### <span class="two-line-tab"><span tab-label="modular API"></span>Web</span>

<div>

</div>

``` devsite-click-to-copy
const results = await execute(db.pipeline()
  .collection("cities")
  .removeFields("population", "location.state"));test.firestore.js
```

</div>

<div class="section">

##### Swift

<div>

</div>

``` devsite-click-to-copy
let results = try await db.pipeline()
  .collection("cities")
  .removeFields(["population", "location.state"])
  .execute()PipelineSnippets.swift
```

</div>

<div class="section">

##### <span class="two-line-tab">Kotlin <span class="firebase-platform-label">Android</span></span>

<div>

</div>

``` devsite-click-to-copy
val results = db.pipeline()
    .collection("cities")
    .removeFields("population", "location.state")
    .execute()DocSnippets.kt
```

</div>

<div class="section">

##### <span class="two-line-tab">Java <span class="firebase-platform-label">Android</span></span>

<div>

</div>

``` devsite-click-to-copy
Task<Pipeline.Snapshot> results = db.pipeline()
        .collection("cities")
        .removeFields("population", "location.state")
        .execute();DocSnippets.java
```

</div>

<div class="section">

##### Python

<div>

</div>

``` devsite-click-to-copy
results = (
    client.pipeline()
    .collection("cities")
    .remove_fields("population", "location.state")
    .execute()
)firestore_pipelines.py
```

</div>

<div class="section">

##### Java

<div>

</div>

``` devsite-click-to-copy
Pipeline.Snapshot results =
    firestore
        .pipeline()
        .collection("cities")
        .removeFields("population", "location.state")
        .execute()
        .get();PipelineSnippets.java
```

</div>

<div class="section">

##### Go

<div>

</div>

``` devsite-click-to-copy
snapshot := client.Pipeline().Collection("cities").
 RemoveFields(firestore.Fields("population", "location.state")).
 Execute(ctx)pipeline_snippets_general.go
```

</div>

</div>

## Behavior

### Remove Nested Fields

The `remove_fields(...)` stage respects nested field syntax, and will remove keys from a map.

For example, to remove the nested state field from the dataset:

<div>

<div class="section">

### Node.js

<div>

</div>

``` devsite-click-to-copy
await db.collection("cities").doc("SF").set({name: "San Francisco", location: {country: "USA", state: "California"}});
await db.collection("cities").doc("TO").set({name: "Toronto", location: {country: "Canada", province: "Ontario"}});
```

</div>

</div>

The following pipeline can be used:

<div>

<div class="section">

### Node.js

<div>

</div>

``` devsite-click-to-copy
const results = await db.pipeline()
  .collection("/cities")
  .removeFields("location.state")
  .execute();
```

</div>

</div>

Which produces the following documents:

<div>

</div>

``` devsite-click-to-copy
{ name: "San Francisco", location: { country: "USA" } }
{ name: "Toronto", location: { country: "Canada", province: "Ontario" } }
```

Removal of elements within an array is unsupported.

### Remove on Non-Existent Fields

If a nested or top-level field given to `remove_fields(...)` does not exist in a document, the stage won't edit the document for that field. Other existing fields will still be removed.

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
