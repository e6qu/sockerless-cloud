# Retry jobs

<div class="devsite-article-body clearfix">

By default, if a Cloud Scheduler job doesn't receive an acknowledgement from its handler, the job is considered to have failed, and will retry according to the exponential backoff you have configured. You can determine this retry behavior in the following ways when creating or updating a Cloud Scheduler job:

- [Using the Google Cloud console](https://console.cloud.google.com/cloudscheduler)

- [Using the Google Cloud CLI](/sdk/gcloud/reference/scheduler/jobs)

- [Making a direct API request](/scheduler/docs/reference/rest/v1/projects.locations.jobs#retryconfig) and configuring the `RetryConfig`settings of a `Job` resource

## Retry settings

The following tables describe the retry settings that you can configure.

### Maximum retry attempts

The number of attempts that the system will make to run a job using the exponential backoff procedure described by `maxDoublings`.

**Note:** Setting `retryCount` to 0 doesn't prevent failed jobs from running according to schedule after the failure.

<table class="responsive">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<tbody>
<tr class="odd">
<td>Description</td>
<td><p>If <code translate="no" dir="ltr">retryCount</code> is set to a non-zero number, Cloud Scheduler will retry the failed job, using exponential backoff, for <code translate="no" dir="ltr">retryCount</code> times until the job succeeds or the number of retries is exhausted. Note that the next scheduled execution time might be skipped if the retries continue through that time.</p>
<p>If <code translate="no" dir="ltr">retryCount</code> is 0 (and if <code translate="no" dir="ltr">maxRetryDuration</code> is also 0), a job attempt <em>won't be retried if it fails</em>. Instead, Cloud Scheduler will wait for the next scheduled execution time.</p>
<p>Values greater than 5 and negative values are not allowed.</p></td>
</tr>
<tr class="even">
<td>Default</td>
<td>Default is 0.</td>
</tr>
<tr class="odd">
<td>Console label</td>
<td><strong>Max retry attempts</strong></td>
</tr>
<tr class="even">
<td>CLI flag</td>
<td><code translate="no" dir="ltr">--max-retry-attempts</code></td>
</tr>
<tr class="odd">
<td>API field</td>
<td><code translate="no" dir="ltr">retryCount</code></td>
</tr>
</tbody>
</table>

### Maximum retry duration

The time limit for retrying a failed job, measured from the time when an execution was first attempted. If specified with `retryCount`, the job will be retried until *both limits are reached*.

<table class="responsive">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<tbody>
<tr class="odd">
<td>Description</td>
<td><p>A duration in seconds with up to nine fractional digits, ending with "s"—for example, "3.5s".</p>
<p>A duration of 0 means that the retry duration is unlimited. However, if <code translate="no" dir="ltr">retryCount</code> is also 0, a job attempt <em>won't be retried if it fails</em>.</p></td>
</tr>
<tr class="even">
<td>Default</td>
<td>Default is 0 seconds.</td>
</tr>
<tr class="odd">
<td>Console label</td>
<td><strong>Max retry duration</strong></td>
</tr>
<tr class="even">
<td>CLI flag</td>
<td><code translate="no" dir="ltr">--max-retry-duration</code></td>
</tr>
<tr class="odd">
<td>API field</td>
<td><code translate="no" dir="ltr">maxRetryDuration</code></td>
</tr>
</tbody>
</table>

### Minimum backoff duration

The minimum amount of time to wait before retrying a job after it fails.

|               |                                                                                               |
|---------------|-----------------------------------------------------------------------------------------------|
| Description   | A duration in seconds with up to nine fractional digits, ending with "s"—for example, "3.5s". |
| Default       | Default is 5 seconds.                                                                         |
| Console label | **Min backoff duration**                                                                      |
| CLI flag      | `--min-backoff`                                                                               |
| API field     | `minBackoffDuration`                                                                          |

### Maximum backoff duration

The maximum amount of time to wait before retrying a job after it fails.

|               |                                                                                               |
|---------------|-----------------------------------------------------------------------------------------------|
| Description   | A duration in seconds with up to nine fractional digits, ending with "s"—for example, "3.5s". |
| Default       | Default is 3600 seconds (1 hour).                                                             |
| Console label | **Max backoff duration**                                                                      |
| CLI flag      | `--max-backoff`                                                                               |
| API field     | `maxBackoffDuration`                                                                          |

### Maximum doublings

Maximum number of times that the interval between failed job retries will be doubled before the increase becomes constant.

<table class="responsive">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<tbody>
<tr class="odd">
<td>Description</td>
<td>The time between retries will double <code translate="no" dir="ltr">maxDoublings</code> times.
<p>A job's retry interval starts at <code translate="no" dir="ltr">minBackoffDuration</code>, then doubles <code translate="no" dir="ltr">maxDoublings</code> times, then increases linearly, and finally retries at intervals of <code translate="no" dir="ltr">maxBackoffDuration</code> up to <code translate="no" dir="ltr">retryCount</code> times. For example:</p>
<p>If <code translate="no" dir="ltr">minBackoffDuration</code> is 10s, <code translate="no" dir="ltr">maxBackoffDuration</code> is 300s, and <code translate="no" dir="ltr">maxDoublings</code> is 3:</p>
<ol>
<li>The job will first be retried in 10s.</li>
<li>The retry interval will double three times.</li>
<li>The retry interval will then increase linearly by 2^3 * 10s.</li>
<li>If applicable, the job will retry at intervals of <code translate="no" dir="ltr">maxBackoffDuration</code> until the job has been attempted <code translate="no" dir="ltr">retryCount</code> times (to a maximum of 5 times).</li>
</ol>
<p>Thus, the requests will retry at 10s, 20s, 40s, 80s, 160s.</p>
<p>If <code translate="no" dir="ltr">minBackoffDuration</code> is 10s, <code translate="no" dir="ltr">maxBackoffDuration</code> is 120s, and <code translate="no" dir="ltr">maxDoublings</code> is 2:</p>
<ol>
<li>The job will first be retried in 10s.</li>
<li>The retry interval will double two times.</li>
<li>The retry interval will then increase linearly by 2^2 * 10s.</li>
<li>If applicable, the job will retry at intervals of <code translate="no" dir="ltr">maxBackoffDuration</code> until the job has been attempted <code translate="no" dir="ltr">retryCount</code> times (to a maximum of 5 times).</li>
</ol>
<p>Thus, the requests will retry at 10s, 20s, 40s, 80s, 120s.</p></td>
</tr>
<tr class="even">
<td>Default</td>
<td>Default is 5.</td>
</tr>
<tr class="odd">
<td>Console label</td>
<td><strong>Max doublings</strong></td>
</tr>
<tr class="even">
<td>CLI flag</td>
<td><code translate="no" dir="ltr">--max-doublings</code></td>
</tr>
<tr class="odd">
<td>API field</td>
<td><code translate="no" dir="ltr">maxDoublings</code></td>
</tr>
</tbody>
</table>

## Retry examples

The following examples demonstrate the retry behavior when a Cloud Scheduler job doesn't complete successfully.

If both `retryCount` and `maxRetryDuration` are not set  
Both settings default to 0 and the job doesn't retry at all.

Note that Cloud Scheduler will try to run the job at the next scheduled execution time.

If both `retryCount` and `maxRetryDuration` are set  
The job will retry at least `retryCount` number of times until reaching `maxRetryDuration`.

Note that the job could retry more times than the `retryCount`.

If `retryCount` is set and `maxRetryDuration` is not set  
The `maxRetryDuration` setting defaults to 0 and the job will retry exactly `retryCount` number of times.

If `retryCount` is not set and `maxRetryDuration` is set  
The job will retry any number of times (up to a maximum of 5 times) or until reaching `maxRetryDuration`.

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
