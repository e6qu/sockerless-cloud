# Enable and disable high availability

<div class="devsite-article-body clearfix">

<div class="nocontent" style="font-size:medium; margin-bottom:40px; border-top:1px solid black;">

<div style="float:right">

<a href="/sql/docs/mysql/configure-ha" data-track-type="sqlSwitcher" data-track-name="mysqlLink" title="View this page for the MySQL database engine">MySQL</a> <span style="color:light-gray">  \|  </span><span style="font-weight:bold">PostgreSQL</span> <span style="color:light-gray">  \|  </span><a href="/sql/docs/sqlserver/configure-ha" data-track-type="sqlSwitcher" data-track-name="sqlServerLink" title="View this page for the SQL Server database engine">SQL Server</a>

</div>

</div>

This page describes how to configure an instance for high availability.

You can configure an instance for high availability when you create the instance, or you can enable high availability on an existing instance.

For more information about high availability, see [Overview of the high availability configuration](/sql/docs/postgres/high-availability).

## Create a new instance configured for high availability

When you create an instance and configure it for high availability, Cloud SQL creates it as a regional instance.

To create an instance configured for high availability:

<div id="create-ha-instance" class="ds-selector-tabs" ds-scope="code-sample">

<div class="section">

### Console

1.  In the Google Cloud console, go to the **Cloud SQL Instances** page.

    <a href="https://console.cloud.google.com/sql" class="button button-primary" target="console">Go to Cloud SQL Instances</a>

2.  Select **Create instance**.

3.  Select the database engine.

4.  In the **Choose region and zonal availability** section, select **Multiple zones (Highly available)**.

5.  Expand **Specify zones**.

6.  Select the primary and secondary zones. The following conditions apply when the secondary zone is used during instance creation or edit:
    - The zones default to `Any` for the primary zone and `Any (different from primary)` for the secondary zone.

7.  Click **Save**.

    You are returned to the instance page for the primary instance while the instance is updated.

</div>

<div class="section">

### gcloud

1.  Create the regional instance:

    <div>

    </div>

    ``` devsite-click-to-copy
    gcloud sql instances create REGIONAL_INSTANCE_NAME \
    --availability-type=REGIONAL \
    --database-version=DATABASE_VERSION \
    --cpu=NUMBER_CPUS \
    --memory=MEMORY_SIZE
    ```

    For a complete list of available parameters, see the [gcloud sql instances create](/sdk/gcloud/reference/sql/instances/create) reference page.

2.  Configure the root user:

    <div>

    </div>

    ``` devsite-click-to-copy
    gcloud sql users set-password root no-host \
    --instance=REGIONAL_INSTANCE_NAME \
    --password=PASSWORD
    ```

</div>

<div class="section">

### Terraform

To create an instance with high availability, use a <a href="https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/sql_database_instance" class="external">Terraform resource</a>.

<div class="github-docwidget-gitinclude-code">

<div>

</div>

``` lang-terraform
resource "google_sql_database_instance" "postgres_instance_ha" {
  name             = "postgres-instance-ha"
  region           = "us-central1"
  database_version = "POSTGRES_14"
  settings {
    tier              = "db-custom-2-7680"
    availability_type = "REGIONAL"
    backup_configuration {
      enabled                        = true
      point_in_time_recovery_enabled = true
      start_time                     = "20:55"
    }
  }
  # set `deletion_protection` to true, will ensure that one cannot accidentally delete this instance by
  # use of Terraform whereas `deletion_protection_enabled` flag protects this instance at the GCP level.
  deletion_protection = false
}
```

</div>

#### Apply the changes

To apply your Terraform configuration in a Google Cloud project, complete the steps in the following sections.

## Prepare Cloud Shell

1.  Launch [Cloud Shell](https://shell.cloud.google.com/).

2.  Set the default Google Cloud project where you want to apply your Terraform configurations.

    You only need to run this command once per project, and you can run it in any directory.

    <div>

    </div>

    ``` devsite-click-to-copy
    export GOOGLE_CLOUD_PROJECT=PROJECT_ID
    ```

    Environment variables are overridden if you set explicit values in the Terraform configuration file.

## Prepare the directory

Each Terraform configuration file must have its own directory (also called a *root module*).

1.  In [Cloud Shell](https://shell.cloud.google.com/), create a directory and a new file within that directory. The filename must have the `.tf` extension—for example `main.tf`. In this tutorial, the file is referred to as `main.tf`.

    <div>

    </div>

    ``` devsite-click-to-copy
    mkdir DIRECTORY && cd DIRECTORY && touch main.tf
    ```

2.  If you are following a tutorial, you can copy the sample code in each section or step.

    Copy the sample code into the newly created `main.tf`.

    Optionally, copy the code from GitHub. This is recommended when the Terraform snippet is part of an end-to-end solution.

3.  Review and modify the sample parameters to apply to your environment.

4.  Save your changes.

5.  Initialize Terraform. You only need to do this once per directory.

    <div>

    </div>

    ``` devsite-click-to-copy
    terraform init
    ```

    Optionally, to use the latest Google provider version, include the `-upgrade` option:

    <div>

    </div>

    ``` devsite-click-to-copy
    terraform init -upgrade
    ```

## Apply the changes

1.  Review the configuration and verify that the resources that Terraform is going to create or update match your expectations:

    <div>

    </div>

    ``` devsite-click-to-copy
    terraform plan
    ```

    Make corrections to the configuration as necessary.

2.  Apply the Terraform configuration by running the following command and entering `yes` at the prompt:

    <div>

    </div>

    ``` devsite-click-to-copy
    terraform apply
    ```

    Wait until Terraform displays the "Apply complete!" message.

3.  [Open your Google Cloud project](https://console.cloud.google.com/) to view the results. In the Google Cloud console, navigate to your resources in the UI to make sure that Terraform has created or updated them.

**Note:** Terraform samples typically assume that the required APIs are enabled in your Google Cloud project.

#### Delete the changes

To delete your changes, do the following:

1.  To disable deletion protection, in your Terraform configuration file set the `deletion_protection` argument to `false`.

    <div>

    </div>

    ``` devsite-click-to-copy
    deletion_protection =  "false"
    ```

2.  Apply the updated Terraform configuration by running the following command and entering `yes` at the prompt:

    <div>

    </div>

    ``` devsite-click-to-copy
    terraform apply
    ```

<!-- -->

3.  Remove resources previously applied with your Terraform configuration by running the following command and entering `yes` at the prompt:

    <div>

    </div>

    ``` devsite-click-to-copy
    terraform destroy
    ```

</div>

<div class="section">

### REST v1

For the complete list of parameters for the request, see the [instances:insert](/sql/docs/postgres/admin-api/rest/v1/instances/insert) page.

Create the regional instance.

1.  Before using any of the request data, make the following replacements:

    - `project-id`: The project ID
    - `instance-name`: The instance name
    - `database-version`: The database version enum string
    - `region` The GCP region
    - `machine-type` The machine type

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    POST https://sqladmin.googleapis.com/v1/projects/project-id/instances
    ```

    </div>

    Request JSON body:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    {
      "name": "instance-name",
      "region": "region",
      "databaseVersion": "database-version",
       "settings": {
         "tier": "machine-type",
         "backupConfiguration": {
             "enabled": true,
             "pointInTimeRecoveryEnabled": true
          },
          "availabilityType": "REGIONAL"
       }
    }
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Save the request body in a file named `request.json`, and execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X POST \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         -H "Content-Type: application/json; charset=utf-8" \
         -d @request.json \
         "https://sqladmin.googleapis.com/v1/projects/project-id/instances"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Save the request body in a file named `request.json`, and execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method POST `
        -Headers $headers `
        -ContentType: "application/json; charset=utf-8" `
        -InFile request.json `
        -Uri "https://sqladmin.googleapis.com/v1/projects/project-id/instances" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a JSON response similar to the following:

    <div class="section expandable">

    #### Response

    <div>

    </div>

    ``` readonly
    {
      "kind": "sql#operation",
      "targetLink": "https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-name",
      "status": "PENDING",
      "user": "user@example.com",
      "insertTime": "2020-01-21T22:43:37.981Z",
      "operationType": "CREATE",
      "name": "operation-id",
      "targetId": "instance-name",
      "selfLink": "https://sqladmin.googleapis.com/v1/projects/project-id/operations/operation-id",
      "targetProject": "project-id"
    }
    ```

    </div>

2.  When the instance finishes initializing, update the root password on the instance:

    Before using any of the request data, make the following replacements:

    - `project-id`: The project ID
    - `instance-id`: The instance ID
    - `password`: The new root user password

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    PATCH https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-id/users?host=%25&name=postgres'
    ```

    </div>

    Request JSON body:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    {
       "name": "postgres",
       "host": "nohost",
       "password": "password"}
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Save the request body in a file named `request.json`, and execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X PATCH \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         -H "Content-Type: application/json; charset=utf-8" \
         -d @request.json \
         "https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-id/users?host=%25&name=postgres'"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Save the request body in a file named `request.json`, and execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method PATCH `
        -Headers $headers `
        -ContentType: "application/json; charset=utf-8" `
        -InFile request.json `
        -Uri "https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-id/users?host=%25&name=postgres'" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a successful status code (2xx) and an empty response.

</div>

<div class="section">

### REST v1beta4

For the complete list of parameters for the request, see the [instances:insert](/sql/docs/postgres/admin-api/rest/v1beta4/instances/insert) page.

Create the regional instance.

1.  Before using any of the request data, make the following replacements:

    - `project-id`: The project ID
    - `instance-name`: The instance name
    - `database-version`: The database version enum string
    - `region` The GCP region
    - `machine-type` The machine type

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    POST https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances
    ```

    </div>

    Request JSON body:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    {
      "name": "instance-name",
      "region": "region",
      "databaseVersion": "database-version",
       "settings": {
         "tier": "machine-type",
         "backupConfiguration": {
             "enabled": true,
             "pointInTimeRecoveryEnabled": true
          },
          "availabilityType": "REGIONAL"
       }
    }
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Save the request body in a file named `request.json`, and execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X POST \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         -H "Content-Type: application/json; charset=utf-8" \
         -d @request.json \
         "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Save the request body in a file named `request.json`, and execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method POST `
        -Headers $headers `
        -ContentType: "application/json; charset=utf-8" `
        -InFile request.json `
        -Uri "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a JSON response similar to the following:

    <div class="section expandable">

    #### Response

    <div>

    </div>

    ``` readonly
    {
      "kind": "sql#operation",
      "targetLink": "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-name",
      "status": "PENDING",
      "user": "user@example.com",
      "insertTime": "2020-01-21T22:43:37.981Z",
      "operationType": "CREATE",
      "name": "operation-id",
      "targetId": "instance-name",
      "selfLink": "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/operations/operation-id",
      "targetProject": "project-id"
    }
    ```

    </div>

2.  When the instance finishes initializing, update the root password on the instance:

    Before using any of the request data, make the following replacements:

    - `project-id`: The project ID
    - `instance-id`: The instance ID
    - `password`: The new root user password

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    PATCH https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id/users?host=%25&name=postgres'
    ```

    </div>

    Request JSON body:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    {
       "name": "postgres",
       "host": "nohost",
       "password": "password"}
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Save the request body in a file named `request.json`, and execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X PATCH \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         -H "Content-Type: application/json; charset=utf-8" \
         -d @request.json \
         "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id/users?host=%25&name=postgres'"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Save the request body in a file named `request.json`, and execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method PATCH `
        -Headers $headers `
        -ContentType: "application/json; charset=utf-8" `
        -InFile request.json `
        -Uri "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id/users?host=%25&name=postgres'" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a successful status code (2xx) and an empty response.

</div>

</div>

For more details about creating an instance, see [Creating Instances](/sql/docs/postgres/create-instance).

## Configure an existing instance for high availability

You can configure a Cloud SQL instance for high availability by using the Google Cloud console, [](/sdk/gcloud)[gcloud CLI](/sdk/gcloud), or the API.

**Note:** After you start the high availability configuration for an instance, you can't stop it. Reconfiguring the instance restarts it. It typically takes only a few minutes for Cloud SQL to reconfigure the instance and restart it. However, if the instance has a large disk or load, then it might take up to an hour.

<div id="configure-ha-instance" class="ds-selector-tabs" ds-scope="code-sample">

<div class="section">

### Console

**Important:** You can't use the Google Cloud console to configure instances that have [Private Service Connect](/sql/docs/postgres/about-private-service-connect) enabled for high availability. To configure these instances, use [gcloud CLI](/sdk/gcloud) or the API.

To configure an instance for high availability:

1.  In the Google Cloud console, go to the **Cloud SQL Instances** page.

    <a href="https://console.cloud.google.com/sql" class="button button-primary" target="console">Go to Cloud SQL Instances</a>

2.  To open the **Overview** page of an instance, click the instance name.

3.  Click **Edit**.

4.  In the **Auto backups and high availability** configuration option section, select **High availability (regional)**. It's also recommended that you enable **Automate backups**.

5.  Click **Save**.

</div>

<div class="section">

### gcloud

To configure an instance to be a regional, high availability instance, use the [`gcloud sql instances patch`](/sdk/gcloud/reference/sql/instances/patch) command:

<div>

</div>

``` devsite-click-to-copy
gcloud sql instances patch INSTANCE_NAME \
--availability-type REGIONAL
```

Replace `INSTANCE_NAME` with the name of the Cloud SQL instance that you're configuring for high availability.

</div>

<div class="section">

### REST v1

To configure an instance to be a regional, high availability instance:

1.  Check the instance to see if automatic backups and point-in-time recovery are enabled. These are required for high availability instances.

    Before using any of the request data, make the following replacements:

    - `PROJECT_ID`: the ID or [project number](/resource-manager/docs/creating-managing-projects#identifying_projects) of the Google Cloud project that contains the instance
    - `INSTANCE_NAME`: the name of the instance that you're configuring for high availability

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    GET https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/instances/INSTANCE_NAME
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X GET \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         "https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/instances/INSTANCE_NAME"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method GET `
        -Headers $headers `
        -Uri "https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/instances/INSTANCE_NAME" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a JSON response similar to the following:

    <div class="section">

    <div>

    </div>

    ``` readonly
    {
      "kind": "sql#instance",
      "state": "RUNNABLE",
      "databaseVersion": "POSTGRES_13"
    }
    ```

    </div>

    The output contains a section similar to the following:

    <div>

    </div>

    ```
      "backupConfiguration": {
        "kind": "sql#backupConfiguration",
        "startTime": "12:00",
        "enabled": true,
        "pointInTimeRecoveryEnabled": true
        }
      
    ```

2.  If either `enabled` or `pointInTimeRecoveryEnabled` are `false`, then use the [`instances:patch`](/sql/docs/postgres/admin-api/rest/v1/instances/patch) method to enable them both. To enable backups, set `enabled` to `true` and `startTime` to a value which is the start of the backup window. To enable binary logging, set `pointInTimeRecoveryEnabled` to `true`.

    Before using any of the request data, make the following replacements:

    - `PROJECT_ID`: the ID or [project number](/resource-manager/docs/creating-managing-projects#identifying_projects) of the Google Cloud project that contains the instance
    - `INSTANCE_NAME`: the name of the primary or read replica instance that you're configuring for high availability
    - `START_TIME`: the time (in hours and minutes)

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    PATCH https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/instances/INSTANCE_NAME
    ```

    </div>

    Request JSON body:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    {
      "settings":
      {
        "backupConfiguration":
        {
          "startTime": "START_TIME",
          "enabled": true,
          "pointInTimeRecoveryEnabled": true
        }
      }
    }
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Save the request body in a file named `request.json`, and execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X PATCH \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         -H "Content-Type: application/json; charset=utf-8" \
         -d @request.json \
         "https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/instances/INSTANCE_NAME"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Save the request body in a file named `request.json`, and execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method PATCH `
        -Headers $headers `
        -ContentType: "application/json; charset=utf-8" `
        -InFile request.json `
        -Uri "https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/instances/INSTANCE_NAME" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a JSON response similar to the following:

    <div class="section expandable">

    #### Response

    <div>

    </div>

    ``` readonly
    {
      "kind": "sql#operation",
      "targetLink": "https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/instances/INSTANCE_NAME",
      "status": "PENDING",
      "user": "user@example.com",
      "insertTime": "2020-01-21T22:43:37.981Z",
      "operationType": "UPDATE",
      "name": "OPERATION_ID",
      "targetId": "INSTANCE_NAME",
      "selfLink": "https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/operations/OPERATION_ID",
      "targetProject": "PROJECT_ID"
    }
    ```

    </div>

3.  Configure the instance to be a regional, high availability instance:

    Before using any of the request data, make the following replacements:

    - `PROJECT_ID`: the ID or [project number](/resource-manager/docs/creating-managing-projects#identifying_projects) of the Google Cloud project that contains the instance
    - `INSTANCE_NAME`: the name of the instance that you're configuring for high availability

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    PATCH https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/instances/INSTANCE_NAME
    ```

    </div>

    Request JSON body:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    {
      "settings": {"availabilityType": "REGIONAL" }
    }
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Save the request body in a file named `request.json`, and execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X PATCH \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         -H "Content-Type: application/json; charset=utf-8" \
         -d @request.json \
         "https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/instances/INSTANCE_NAME"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Save the request body in a file named `request.json`, and execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method PATCH `
        -Headers $headers `
        -ContentType: "application/json; charset=utf-8" `
        -InFile request.json `
        -Uri "https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/instances/INSTANCE_NAME" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a successful status code (2xx) and an empty response.

</div>

<div class="section">

### REST v1beta4

To configure an instance to be a regional, high availability instance:

1.  Check the instance to see if automatic backups and point-in-time recovery are enabled. These are required for high availability instances.

    Before using any of the request data, make the following replacements:

    - `PROJECT_ID`: the ID or [project number](/resource-manager/docs/creating-managing-projects#identifying_projects) of the Google Cloud project that contains the instance
    - `INSTANCE_NAME`: the name of the instance that you're configuring for high availability

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    GET https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/instances/INSTANCE_NAME
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X GET \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         "https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/instances/INSTANCE_NAME"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method GET `
        -Headers $headers `
        -Uri "https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/instances/INSTANCE_NAME" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a JSON response similar to the following:

    <div class="section">

    <div>

    </div>

    ``` readonly
    {
      "kind": "sql#instance",
      "state": "RUNNABLE",
      "databaseVersion": "POSTGRES_13",
    }
    ```

    </div>

    The output contains a section similar to the following:

    <div>

    </div>

    ```
      "backupConfiguration": {
        "kind": "sql#backupConfiguration",
        "startTime": "12:00",
        "enabled": true,
        "pointInTimeRecoveryEnabled": true
        }
      
    ```

2.  If either `enabled` or `pointInTimeRecoveryEnabled` are `false`, then use the [`instances:patch`](/sql/docs/postgres/admin-api/rest/v1beta4/instances/patch) method to enable them both. To enable backups, set `enabled` to `true` and `startTime` to a value which is the start of the backup window. To enable binary logging, set `pointInTimeRecoveryEnabled` to `true`.

    Before using any of the request data, make the following replacements:

    - `PROJECT_ID`: the ID or [project number](/resource-manager/docs/creating-managing-projects#identifying_projects) of the Google Cloud project that contains the instance
    - `INSTANCE_NAME`: the name of the primary or read replica instance that you're configuring for high availability
    - `START_TIME`: the time (in hours and minutes)

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    PATCH https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/instances/INSTANCE_NAME
    ```

    </div>

    Request JSON body:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    {
      "settings":
      {
        "backupConfiguration":
        {
          "startTime": "START_TIME",
          "enabled": true,
          "pointInTimeRecoveryEnabled": true
        }
      }
    }
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Save the request body in a file named `request.json`, and execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X PATCH \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         -H "Content-Type: application/json; charset=utf-8" \
         -d @request.json \
         "https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/instances/INSTANCE_NAME"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Save the request body in a file named `request.json`, and execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method PATCH `
        -Headers $headers `
        -ContentType: "application/json; charset=utf-8" `
        -InFile request.json `
        -Uri "https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/instances/INSTANCE_NAME" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a JSON response similar to the following:

    <div class="section expandable">

    #### Response

    <div>

    </div>

    ``` readonly
    {
      "kind": "sql#operation",
      "targetLink": "https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/instances/INSTANCE_NAME",
      "status": "PENDING",
      "user": "user@example.com",
      "insertTime": "2020-01-21T22:43:37.981Z",
      "operationType": "UPDATE",
      "name": "OPERATION_ID",
      "targetId": "INSTANCE_NAME",
      "selfLink": "https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/operations/OPERATION_ID",
      "targetProject": "PROJECT_ID"
    }
    ```

    </div>

3.  Configure the instance to be a regional, high availability instance:

    Before using any of the request data, make the following replacements:

    - `PROJECT_ID`: the ID or [project number](/resource-manager/docs/creating-managing-projects#identifying_projects) of the Google Cloud project that contains the instance
    - `INSTANCE_NAME`: the name of the instance that you're configuring for high availability

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    PATCH https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/instances/INSTANCE_NAME
    ```

    </div>

    Request JSON body:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    {
      "settings": {"availabilityType": "REGIONAL" }
    }
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Save the request body in a file named `request.json`, and execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X PATCH \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         -H "Content-Type: application/json; charset=utf-8" \
         -d @request.json \
         "https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/instances/INSTANCE_NAME"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Save the request body in a file named `request.json`, and execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method PATCH `
        -Headers $headers `
        -ContentType: "application/json; charset=utf-8" `
        -InFile request.json `
        -Uri "https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/instances/INSTANCE_NAME" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a successful status code (2xx) and an empty response.

</div>

</div>

## Initiate failover

Testing failover is optional, but is recommended so that you can see how your application responds in the event of a failover.

This feature helps you test your application's response to an automatic failover. Make sure that your instance has completed any previous failover (so it's responding to connection requests) before you trigger another failover. Also, before you initiate failover for your instance, [configure the instance for high availability](/sql/docs/postgres/configure-ha#ha-existing).

To learn more about failovers, see the [Failover overview](/sql/docs/postgres/high-availability#failover-overview).

<div id="initiate-failover" class="ds-selector-tabs" ds-scope="code-sample">

<div class="section">

### Console

1.  In the Google Cloud console, go to the **Cloud SQL Instances** page.

    <a href="https://console.cloud.google.com/sql" class="button button-primary" target="console">Go to Cloud SQL Instances</a>

2.  To open the **Overview** page of an instance, click the instance name.

3.  Click **Failover**.

4.  In the **Manually trigger a failover** dialog box, enter the ID of your instance in the text field, and then click **Trigger Failover**.

</div>

<div class="section">

### gcloud

Initiate the failover:

<div>

</div>

``` devsite-click-to-copy
gcloud sql instances failover PRIMARY_INSTANCE_NAME
```

</div>

<div class="section">

### REST v1

1.  Describe the primary instance to get the value of the `settingsVersion` field.

    Before using any of the request data, make the following replacements:

    - `PROJECT_ID`: the ID or [project number](/resource-manager/docs/creating-managing-projects#identifying_projects) of the Google Cloud project that contains the instance
    - `INSTANCE_NAME`: the name of the instance that you're configuring for high availability

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    GET https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/instances/INSTANCE_NAME
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X GET \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         "https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/instances/INSTANCE_NAME"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method GET `
        -Headers $headers `
        -Uri "https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/instances/INSTANCE_NAME" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a JSON response similar to the following:

    <div class="section">

    <div>

    </div>

    ``` readonly
    {
      "kind": "sql#instance",
      "state": "RUNNABLE",
      "databaseVersion": "POSTGRES_13"
    }
    ```

    </div>

2.  Initiate the failover:

    Before using any of the request data, make the following replacements:

    - `project-id`: The project ID
    - `instance-name`: The instance name
    - `settings-version`: The settingsVersion from instanceInfo

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    POST https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-name/failover
    ```

    </div>

    Request JSON body:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    {
      "failoverContext":
         {
            "settingsVersion":"settings-version"
         }
    }
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Save the request body in a file named `request.json`, and execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X POST \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         -H "Content-Type: application/json; charset=utf-8" \
         -d @request.json \
         "https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-name/failover"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Save the request body in a file named `request.json`, and execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method POST `
        -Headers $headers `
        -ContentType: "application/json; charset=utf-8" `
        -InFile request.json `
        -Uri "https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-name/failover" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a JSON response similar to the following:

    <div class="section expandable">

    #### Response

    <div>

    </div>

    ``` readonly
    {
      "kind": "sql#operation",
      "targetLink": "https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-name",
      "status": "PENDING",
      "user": "user@example.com",
      "insertTime": "2020-01-21T22:43:37.981Z",
      "operationType": "CREATE",
      "name": "operation-id",
      "targetId": "instance-name",
      "selfLink": "https://sqladmin.googleapis.com/v1/projects/project-id/operations/operation-id",
      "targetProject": "project-id"
    }
    ```

    </div>

</div>

<div class="section">

### REST v1beta4

1.  Describe the primary instance to get the value of the `settingsVersion` field.

    Before using any of the request data, make the following replacements:

    - `PROJECT_ID`: the ID or [project number](/resource-manager/docs/creating-managing-projects#identifying_projects) of the Google Cloud project that contains the instance
    - `INSTANCE_NAME`: the name of the instance that you're configuring for high availability

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    GET https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/instances/INSTANCE_NAME
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X GET \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         "https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/instances/INSTANCE_NAME"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method GET `
        -Headers $headers `
        -Uri "https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/instances/INSTANCE_NAME" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a JSON response similar to the following:

    <div class="section">

    <div>

    </div>

    ``` readonly
    {
      "kind": "sql#instance",
      "state": "RUNNABLE",
      "databaseVersion": "POSTGRES_13"
    }
    ```

    </div>

2.  Initiate the failover:

    Before using any of the request data, make the following replacements:

    - `project-id`: The project ID
    - `instance-name`: The instance name
    - `settings-version`: The settingsVersion from instanceInfo

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    POST https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-name/failover
    ```

    </div>

    Request JSON body:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    {
      "failoverContext":
         {
            "settingsVersion":"settings-version"
         }
    }
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Save the request body in a file named `request.json`, and execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X POST \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         -H "Content-Type: application/json; charset=utf-8" \
         -d @request.json \
         "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-name/failover"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Save the request body in a file named `request.json`, and execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method POST `
        -Headers $headers `
        -ContentType: "application/json; charset=utf-8" `
        -InFile request.json `
        -Uri "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-name/failover" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a JSON response similar to the following:

    <div class="section expandable">

    #### Response

    <div>

    </div>

    ``` readonly
    {
      "kind": "sql#operation",
      "targetLink": "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-name",
      "status": "PENDING",
      "user": "user@example.com",
      "insertTime": "2020-01-21T22:43:37.981Z",
      "operationType": "CREATE",
      "name": "operation-id",
      "targetId": "instance-name",
      "selfLink": "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/operations/operation-id",
      "targetProject": "project-id"
    }
    ```

    </div>

</div>

</div>

The instance fails over and it isn't available to serve data for a few minutes.

## Verify an instance's high availability configuration

To verify an instance has high availability and to view the zones in which it is running:

<div id="verify-ha-on-instance" class="ds-selector-tabs" ds-scope="code-sample">

<div class="section">

### Console

1.  In the Google Cloud console, go to the **Cloud SQL Instances** page.

    <a href="https://console.cloud.google.com/sql" class="button button-primary" target="console">Go to Cloud SQL Instances</a>

2.  To open the **Overview** page of an instance, click the instance name.

3.  Confirm the following high availability settings are displayed in the **Configuration** section:

4.  - **Highly available (regional)**
    - **Located in** shows the current primary zone of the instance.

</div>

<div class="section">

### gcloud

<div>

</div>

``` devsite-click-to-copy
gcloud sql instances describe INSTANCE_NAME
```

The output indicates `availabilityType` is `REGIONAL`. The `gceZone` and `secondaryGceZone` fields show the current primary and secondary zones of the instance.

</div>

<div class="section">

### REST v1

Before using any of the request data, make the following replacements:

- `PROJECT_ID`: the ID or [project number](/resource-manager/docs/creating-managing-projects#identifying_projects) of the Google Cloud project that contains the instance
- `INSTANCE_NAME`: the name of the instance that you're configuring for high availability

HTTP method and URL:

<div class="section">

<div>

</div>

``` devsite-click-to-copy
GET https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/instances/INSTANCE_NAME
```

</div>

To send your request, expand one of these options:

<div class="section expandable">

#### curl (Linux, macOS, or Cloud Shell)

**Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).

Execute the following command:

<div class="section">

<div>

</div>

``` devsite-click-to-copy
curl -X GET \
     -H "Authorization: Bearer $(gcloud auth print-access-token)" \
     "https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/instances/INSTANCE_NAME"
```

</div>

</div>

<div class="section expandable">

#### PowerShell (Windows)

**Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).

Execute the following command:

<div class="section">

<div>

</div>

``` devsite-click-to-copy
$cred = gcloud auth print-access-token
$headers = @{ "Authorization" = "Bearer $cred" }

Invoke-WebRequest `
    -Method GET `
    -Headers $headers `
    -Uri "https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/instances/INSTANCE_NAME" | Select-Object -Expand Content
```

</div>

</div>

You should receive a JSON response similar to the following:

<div class="section">

<div>

</div>

``` readonly
{
  "kind": "sql#instance",
  "state": "RUNNABLE",
  "databaseVersion": "POSTGRES_13"
}
```

</div>

The output indicates `availabilityType` is `REGIONAL`. The `gceZone` and `secondaryGceZone` fields show the current primary and secondary zones of the instance.

</div>

<div class="section">

### REST v1beta4

Before using any of the request data, make the following replacements:

- `PROJECT_ID`: the ID or [project number](/resource-manager/docs/creating-managing-projects#identifying_projects) of the Google Cloud project that contains the instance
- `INSTANCE_NAME`: the name of the instance that you're configuring for high availability

HTTP method and URL:

<div class="section">

<div>

</div>

``` devsite-click-to-copy
GET https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/instances/INSTANCE_NAME
```

</div>

To send your request, expand one of these options:

<div class="section expandable">

#### curl (Linux, macOS, or Cloud Shell)

**Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).

Execute the following command:

<div class="section">

<div>

</div>

``` devsite-click-to-copy
curl -X GET \
     -H "Authorization: Bearer $(gcloud auth print-access-token)" \
     "https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/instances/INSTANCE_NAME"
```

</div>

</div>

<div class="section expandable">

#### PowerShell (Windows)

**Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).

Execute the following command:

<div class="section">

<div>

</div>

``` devsite-click-to-copy
$cred = gcloud auth print-access-token
$headers = @{ "Authorization" = "Bearer $cred" }

Invoke-WebRequest `
    -Method GET `
    -Headers $headers `
    -Uri "https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/instances/INSTANCE_NAME" | Select-Object -Expand Content
```

</div>

</div>

You should receive a JSON response similar to the following:

<div class="section">

<div>

</div>

``` readonly
{
  "kind": "sql#instance",
  "state": "RUNNABLE",
  "databaseVersion": "POSTGRES_13",
}
```

</div>

The output indicates `availabilityType` is `REGIONAL`. The `gceZone` and `secondaryGceZone` fields show the current primary and secondary zones of the instance.

</div>

</div>

## Change the zones of a high availability instance

Changing one or both zones of an existing high availability instance causes a few minutes of downtime while the instance is reconfigured. To see the current primary and secondary zones that the high availability instance is running in, see [Verify an instance's high availability configuration](/sql/docs/postgres/configure-ha#verify-ha).

**Note:** Once you start the zone change operation on an instance, you cannot stop it. This operation restarts the instance. It typically takes only a few minutes for the configuration and restart to complete. But if the instance has a large disk or load, it might take up to an hour.

To change the zones of a high availability instance:

<div id="change-zones" class="ds-selector-tabs" ds-scope="code-sample">

<div class="section">

### Console

1.  In the Google Cloud console, go to the **Cloud SQL Instances** page.

    <a href="https://console.cloud.google.com/sql" class="button button-primary" target="console">Go to Cloud SQL Instances</a>

2.  To open the **Overview** page of an instance, click the instance name.

3.  Click **Edit**.

4.  In the **Choose region and zonal availability** section, expand **Specify zones** and select new zones. The zones default to `Any` for the primary zone and `Any (different from primary)` for the secondary zone. The following restrictions apply:
    - You can specify the primary zone only, or both the primary and secondary zones.
    - If both the primary and secondary zones are specified, they must be different zones.

5.  Click **Save**.

    You are returned to the instance page for the primary instance while the instance is updated.

</div>

<div class="section">

### gcloud

Change the zone in which the instance is running:

<div>

</div>

``` devsite-click-to-copy
gcloud sql instances patch INSTANCE_NAME \
  --zone=PRIMARY_ZONE --secondary-zone=SECONDARY_ZONE
```

The `--secondary-zone` parameter is optional. If you omit it, Cloud SQL will select an available zone that is different from the primary zone.

The following restrictions apply:

- The zones must be valid zones belonging to the same region as the Cloud SQL instance.
- If the secondary zone is specified, it must be different from the primary zone.

</div>

<div class="section">

### REST v1

1.  Change the zones of the regional instance:

    Before using any of the request data, make the following replacements:

    - `PROJECT_ID`: The project ID
    - `INSTANCE_NAME`: The instance name
    - `PRIMARY_ZONE`: The primary zone
    - `SECONDARY_ZONE`: The secondary zone

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    PATCH https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/instances/INSTANCE_NAME
    ```

    </div>

    Request JSON body:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    {
    "settings": {"locationPreference": {"zone": "PRIMARY_ZONE", "secondaryZone": "SECONDARY_ZONE"}}
    }
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Save the request body in a file named `request.json`, and execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X PATCH \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         -H "Content-Type: application/json; charset=utf-8" \
         -d @request.json \
         "https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/instances/INSTANCE_NAME"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Save the request body in a file named `request.json`, and execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method PATCH `
        -Headers $headers `
        -ContentType: "application/json; charset=utf-8" `
        -InFile request.json `
        -Uri "https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/instances/INSTANCE_NAME" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a successful status code (2xx) and an empty response.

    The `secondaryZone` parameter is optional. If you omit it, Cloud SQL will select an available zone that is different from the primary zone.

    The following restrictions apply:

    - The zones must be valid zones.
    - Any zones that you choose must belong to the same region as the Cloud SQL instance.

</div>

<div class="section">

### REST v1beta4

1.  Change the zones of the regional instance:

    Before using any of the request data, make the following replacements:

    - `PROJECT_ID`: The project ID
    - `INSTANCE_NAME`: The instance name
    - `PRIMARY_ZONE`: The primary zone
    - `SECONDARY_ZONE`: The secondary zone

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    PATCH https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/instances/INSTANCE_NAME
    ```

    </div>

    Request JSON body:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    {
    "settings": {"locationPreference": {"zone": "PRIMARY_ZONE", "secondaryZone": "SECONDARY_ZONE"}}
    }
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Save the request body in a file named `request.json`, and execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X PATCH \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         -H "Content-Type: application/json; charset=utf-8" \
         -d @request.json \
         "https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/instances/INSTANCE_NAME"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Save the request body in a file named `request.json`, and execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method PATCH `
        -Headers $headers `
        -ContentType: "application/json; charset=utf-8" `
        -InFile request.json `
        -Uri "https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/instances/INSTANCE_NAME" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a successful status code (2xx) and an empty response.

    The `secondaryZone` parameter is optional. If you omit it, Cloud SQL will select an available zone that is different from the primary zone.

    The following restrictions apply:

    - The zones must be valid zones.
    - Any zones that you choose must belong to the same region as the Cloud SQL instance.

</div>

</div>

## Deactivate high availability for an instance

You can deactivate high availability for a Cloud SQL instance by using the Google Cloud console, [](/sdk/gcloud)[gcloud CLI](/sdk/gcloud), or the API.

**Note:** Before you perform this procedure, make sure that no operations are running on the instance.

If you deactivate high availability for an instance, then in the event of a zonal outage, you need to recover the instance manually. For more information, see [Recovery options for standalone instances](/sql/docs/postgres/high-availability#recovery-options).

<div id="deactivate-ha-on-instance" class="ds-selector-tabs" ds-scope="code-sample">

<div class="section">

### Console

**Important:** You can't use the Google Cloud console to deactivate high availability for instances that have [Private Service Connect](/sql/docs/postgres/about-private-service-connect) enabled. To deactivate these instances, use [gcloud CLI](/sdk/gcloud) or the API.

To deactivate high availability for an instance:

1.  In the Google Cloud console, go to the **Cloud SQL Instances** page.

    <a href="https://console.cloud.google.com/sql" class="button button-primary" target="console">Go to Cloud SQL Instances</a>

2.  To open the **Overview** page of an instance, click the instance name.

3.  Click **Edit**.

4.  Open **Auto backups**.

5.  In the **Availability** section, click **Single zone**.

6.  Click **Save**. This edit requires you to restart the instance.

7.  When the dialog appears, click **Save and restart**.

</div>

<div class="section">

### gcloud

To deactivate high availability for an instance, use the [`gcloud sql instances patch`](/sdk/gcloud/reference/sql/instances/patch) command:

<div>

</div>

``` devsite-click-to-copy
gcloud sql instances patch INSTANCE_NAME \
--availability-type ZONAL
```

Replace `INSTANCE_NAME` with the name of the Cloud SQL instance for which you're deactivating high availability.

</div>

<div class="section">

### REST v1

To change the availability type of the instance to `ZONAL`, use the [`instances:patch`](/sql/docs/postgres/admin-api/rest/v1/instances/patch) method. This method deactivates high availability for the instance.

Before using any of the request data, make the following replacements:

- `PROJECT_ID`: the ID or [project number](/resource-manager/docs/creating-managing-projects#identifying_projects) of the Google Cloud project that contains the instance
- `INSTANCE_NAME`: the name of the instance for which you're deactivating high availability

HTTP method and URL:

<div class="section">

<div>

</div>

``` devsite-click-to-copy
PATCH https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/instances/INSTANCE_NAME
```

</div>

Request JSON body:

<div class="section">

<div>

</div>

``` devsite-click-to-copy
{
  "settings": {"availabilityType": "ZONAL" }
}
```

</div>

To send your request, expand one of these options:

<div class="section expandable">

#### curl (Linux, macOS, or Cloud Shell)

**Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).

Save the request body in a file named `request.json`, and execute the following command:

<div class="section">

<div>

</div>

``` devsite-click-to-copy
curl -X PATCH \
     -H "Authorization: Bearer $(gcloud auth print-access-token)" \
     -H "Content-Type: application/json; charset=utf-8" \
     -d @request.json \
     "https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/instances/INSTANCE_NAME"
```

</div>

</div>

<div class="section expandable">

#### PowerShell (Windows)

**Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).

Save the request body in a file named `request.json`, and execute the following command:

<div class="section">

<div>

</div>

``` devsite-click-to-copy
$cred = gcloud auth print-access-token
$headers = @{ "Authorization" = "Bearer $cred" }

Invoke-WebRequest `
    -Method PATCH `
    -Headers $headers `
    -ContentType: "application/json; charset=utf-8" `
    -InFile request.json `
    -Uri "https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/instances/INSTANCE_NAME" | Select-Object -Expand Content
```

</div>

</div>

You should receive a successful status code (2xx) and an empty response.

</div>

<div class="section">

### REST v1beta4

To change the availability type of the instance to `ZONAL`, use the [`instances:patch`](/sql/docs/postgres/admin-api/rest/v1/instances/patch) method. This method deactivates high availability for the instance.

Before using any of the request data, make the following replacements:

- `PROJECT_ID`: the ID or [project number](/resource-manager/docs/creating-managing-projects#identifying_projects) of the Google Cloud project that contains the instance
- `INSTANCE_NAME`: the name of the instance for which you're deactivating high availability

HTTP method and URL:

<div class="section">

<div>

</div>

``` devsite-click-to-copy
PATCH https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/instances/INSTANCE_NAME
```

</div>

Request JSON body:

<div class="section">

<div>

</div>

``` devsite-click-to-copy
{
  "settings": {"availabilityType": "ZONAL" }
}
```

</div>

To send your request, expand one of these options:

<div class="section expandable">

#### curl (Linux, macOS, or Cloud Shell)

**Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).

Save the request body in a file named `request.json`, and execute the following command:

<div class="section">

<div>

</div>

``` devsite-click-to-copy
curl -X PATCH \
     -H "Authorization: Bearer $(gcloud auth print-access-token)" \
     -H "Content-Type: application/json; charset=utf-8" \
     -d @request.json \
     "https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/instances/INSTANCE_NAME"
```

</div>

</div>

<div class="section expandable">

#### PowerShell (Windows)

**Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).

Save the request body in a file named `request.json`, and execute the following command:

<div class="section">

<div>

</div>

``` devsite-click-to-copy
$cred = gcloud auth print-access-token
$headers = @{ "Authorization" = "Bearer $cred" }

Invoke-WebRequest `
    -Method PATCH `
    -Headers $headers `
    -ContentType: "application/json; charset=utf-8" `
    -InFile request.json `
    -Uri "https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/instances/INSTANCE_NAME" | Select-Object -Expand Content
```

</div>

</div>

You should receive a successful status code (2xx) and an empty response.

</div>

</div>

## Troubleshoot

Issue

</div>

Troubleshooting

You can't find the metrics for a manual failover.

Only automatic failovers go into the metrics.

Cloud SQL instance resources (CPU and RAM) are near 100% usage, causing the high availability instance to go down.

The instance machine size is too small for the load.

[Edit the instance](/sql/docs/postgres/edit-instance#editing_an_instance) to upgrade to a larger machine size to get more CPUs and memory.

## What's next

- Learn more about [how the high availability configuration works](/sql/docs/postgres/high-availability).
- Test how your application responds to lost connections by [restarting your instance](/sql/docs/postgres/start-stop-restart-instance).
- Learn more about [managing your database connections](/sql/faq#connections).
- Learn more about [Google Cloud Observability](/monitoring/docs).
- [Create read replicas](/sql/docs/postgres/replication) for your instance.

Send feedback

<div class="devsite-floating-action-buttons">

</div>
