# Cloud Scheduler roles and permissions

<div class="devsite-article-body clearfix">

This page lists the IAM roles and permissions for Cloud Scheduler. To search through all roles and permissions, see the [role and permission index](/iam/docs/roles-permissions).

## Cloud Scheduler roles

<div results-count-container="">

</div>

<table class="fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="50%">Role</th>
<th>Permissions</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td class="role-description"><h4 id="cloudscheduler.admin" class="role-title add-link" data-text="Cloud Scheduler Admin " tabindex="-1">Cloud Scheduler Admin</h4>
<p>(<code translate="no" dir="ltr">roles/cloudscheduler.admin</code>)</p>
<span class="role-description custom"> </span>
<p>Full access to jobs and executions.</p>
<p>Note that a Cloud Scheduler Admin (or any custom role with the permission cloudscheduler.jobs.create) can create jobs that publish to any Pub/Sub topics within the project.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Project</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">appengine.applications.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudscheduler.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudscheduler.jobs.create</code></li>
<li><code translate="no" dir="ltr">cloudscheduler.jobs.delete</code></li>
<li><code translate="no" dir="ltr">cloudscheduler.jobs.enable</code></li>
<li><code translate="no" dir="ltr">cloudscheduler.jobs.fullView</code></li>
<li><code translate="no" dir="ltr">cloudscheduler.jobs.get</code></li>
<li><code translate="no" dir="ltr">cloudscheduler.jobs.list</code></li>
<li><code translate="no" dir="ltr">cloudscheduler.jobs.pause</code></li>
<li><code translate="no" dir="ltr">cloudscheduler.jobs.run</code></li>
<li><code translate="no" dir="ltr">cloudscheduler.jobs.update</code></li>
<li><code translate="no" dir="ltr">cloudscheduler.locations.get</code></li>
<li><code translate="no" dir="ltr">cloudscheduler.locations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><code translate="no" dir="ltr">serviceusage.catalogs.listMembers</code></p>
<p><code translate="no" dir="ltr">serviceusage.consumerpolicy.analyze</code></p>
<p><code translate="no" dir="ltr">serviceusage.consumerpolicy.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.effectivepolicy.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">serviceusage.groups.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">serviceusage.groups.list</code></li>
<li><code translate="no" dir="ltr">serviceusage.groups.listExpandedMembers</code></li>
<li><code translate="no" dir="ltr">serviceusage.groups.listMembers</code></li>
</ul>
<p><code translate="no" dir="ltr">serviceusage.services.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.list</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.listApis</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.listDependentServices</code></p>
<p><code translate="no" dir="ltr">serviceusage.values.test</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="cloudscheduler.viewer" class="role-title add-link" data-text="Cloud Scheduler Viewer " tabindex="-1">Cloud Scheduler Viewer</h4>
<p>(<code translate="no" dir="ltr">roles/cloudscheduler.viewer</code>)</p>
<span class="role-description"> </span>
<p>Get and list access to jobs, executions, and locations.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Project</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">appengine.applications.get</code></p>
<p><code translate="no" dir="ltr">cloudscheduler.jobs.fullView</code></p>
<p><code translate="no" dir="ltr">cloudscheduler.jobs.get</code></p>
<p><code translate="no" dir="ltr">cloudscheduler.jobs.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudscheduler.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudscheduler.locations.get</code></li>
<li><code translate="no" dir="ltr">cloudscheduler.locations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><code translate="no" dir="ltr">serviceusage.catalogs.listMembers</code></p>
<p><code translate="no" dir="ltr">serviceusage.consumerpolicy.analyze</code></p>
<p><code translate="no" dir="ltr">serviceusage.consumerpolicy.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.effectivepolicy.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">serviceusage.groups.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">serviceusage.groups.list</code></li>
<li><code translate="no" dir="ltr">serviceusage.groups.listExpandedMembers</code></li>
<li><code translate="no" dir="ltr">serviceusage.groups.listMembers</code></li>
</ul>
<p><code translate="no" dir="ltr">serviceusage.services.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.list</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.listApis</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.listDependentServices</code></p>
<p><code translate="no" dir="ltr">serviceusage.values.test</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="cloudscheduler.jobRunner" class="role-title add-link" data-text="Cloud Scheduler Job Runner " tabindex="-1">Cloud Scheduler Job Runner</h4>
<p>(<code translate="no" dir="ltr">roles/cloudscheduler.jobRunner</code>)</p>
<span class="role-description"> </span>
<p>Access to run jobs.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Project</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">appengine.applications.get</code></p>
<p><code translate="no" dir="ltr">cloudscheduler.jobs.fullView</code></p>
<p><code translate="no" dir="ltr">cloudscheduler.jobs.run</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><code translate="no" dir="ltr">serviceusage.catalogs.listMembers</code></p>
<p><code translate="no" dir="ltr">serviceusage.consumerpolicy.analyze</code></p>
<p><code translate="no" dir="ltr">serviceusage.consumerpolicy.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.effectivepolicy.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">serviceusage.groups.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">serviceusage.groups.list</code></li>
<li><code translate="no" dir="ltr">serviceusage.groups.listExpandedMembers</code></li>
<li><code translate="no" dir="ltr">serviceusage.groups.listMembers</code></li>
</ul>
<p><code translate="no" dir="ltr">serviceusage.services.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.list</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.listApis</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.listDependentServices</code></p>
<p><code translate="no" dir="ltr">serviceusage.values.test</code></p></td>
</tr>
</tbody>
</table>

### Service agent roles

Service agent roles should only be granted to [service agents](/iam/docs/service-agents).

<div results-count-container="">

</div>

<table class="fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="50%">Role</th>
<th>Permissions</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td class="role-description"><h4 id="cloudscheduler.serviceAgent" class="role-title add-link" data-text="Cloud Scheduler Service Agent " tabindex="-1">Cloud Scheduler Service Agent</h4>
<p>(<code translate="no" dir="ltr">roles/cloudscheduler.serviceAgent</code>)</p>
<span class="role-description"> </span>
<p>Grants Cloud Scheduler Service Account access to manage resources.</p>
<strong>Warning:</strong> Do not grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.</td>
<td class="role-permissions"><p><code translate="no" dir="ltr">iam.serviceAccounts.getAccessToken</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.getOpenIdToken</code></p>
<p><code translate="no" dir="ltr">logging.logEntries.create</code></p>
<p><code translate="no" dir="ltr">logging.logEntries.route</code></p>
<p><code translate="no" dir="ltr">pubsub.topics.publish</code></p></td>
</tr>
</tbody>
</table>

## Cloud Scheduler permissions

<div results-count-container="">

</div>

<table class="permissions-table fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="45%">Permission</th>
<th>Included in roles</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td><h4 id="cloudscheduler.jobs.create" class="permission-name add-link" data-text="cloudscheduler.jobs.create" tabindex="-1"><code translate="no" dir="ltr">cloudscheduler.jobs.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.admin">Cloud Scheduler Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.admin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/integrations#integrations.serviceAgent">Application Integration Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/kuberun#kuberun.eventsControlPlaneServiceAgent">KubeRun Events Control Plane Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/kuberun.eventsControlPlaneServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="cloudscheduler.jobs.delete" class="permission-name add-link" data-text="cloudscheduler.jobs.delete" tabindex="-1"><code translate="no" dir="ltr">cloudscheduler.jobs.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.admin">Cloud Scheduler Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.admin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/integrations#integrations.serviceAgent">Application Integration Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/kuberun#kuberun.eventsControlPlaneServiceAgent">KubeRun Events Control Plane Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/kuberun.eventsControlPlaneServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="cloudscheduler.jobs.enable" class="permission-name add-link" data-text="cloudscheduler.jobs.enable" tabindex="-1"><code translate="no" dir="ltr">cloudscheduler.jobs.enable</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.admin">Cloud Scheduler Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.admin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/integrations#integrations.serviceAgent">Application Integration Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="cloudscheduler.jobs.fullView" class="permission-name add-link" data-text="cloudscheduler.jobs.fullView" tabindex="-1"><code translate="no" dir="ltr">cloudscheduler.jobs.fullView</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.admin">Cloud Scheduler Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.viewer">Cloud Scheduler Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.jobRunner">Cloud Scheduler Job Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.jobRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/integrations#integrations.serviceAgent">Application Integration Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="cloudscheduler.jobs.get" class="permission-name add-link" data-text="cloudscheduler.jobs.get" tabindex="-1"><code translate="no" dir="ltr">cloudscheduler.jobs.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.admin">Cloud Scheduler Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.viewer">Cloud Scheduler Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/integrations#integrations.serviceAgent">Application Integration Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/kuberun#kuberun.eventsControlPlaneServiceAgent">KubeRun Events Control Plane Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/kuberun.eventsControlPlaneServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="cloudscheduler.jobs.list" class="permission-name add-link" data-text="cloudscheduler.jobs.list" tabindex="-1"><code translate="no" dir="ltr">cloudscheduler.jobs.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.admin">Cloud Scheduler Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.viewer">Cloud Scheduler Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="cloudscheduler.jobs.pause" class="permission-name add-link" data-text="cloudscheduler.jobs.pause" tabindex="-1"><code translate="no" dir="ltr">cloudscheduler.jobs.pause</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.admin">Cloud Scheduler Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.admin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/integrations#integrations.serviceAgent">Application Integration Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="cloudscheduler.jobs.run" class="permission-name add-link" data-text="cloudscheduler.jobs.run" tabindex="-1"><code translate="no" dir="ltr">cloudscheduler.jobs.run</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.admin">Cloud Scheduler Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.jobRunner">Cloud Scheduler Job Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.jobRunner</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/integrations#integrations.serviceAgent">Application Integration Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="cloudscheduler.jobs.update" class="permission-name add-link" data-text="cloudscheduler.jobs.update" tabindex="-1"><code translate="no" dir="ltr">cloudscheduler.jobs.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.admin">Cloud Scheduler Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.admin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/integrations#integrations.serviceAgent">Application Integration Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="cloudscheduler.locations.get" class="permission-name add-link" data-text="cloudscheduler.locations.get" tabindex="-1"><code translate="no" dir="ltr">cloudscheduler.locations.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.admin">Cloud Scheduler Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.viewer">Cloud Scheduler Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/integrations#integrations.serviceAgent">Application Integration Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="cloudscheduler.locations.list" class="permission-name add-link" data-text="cloudscheduler.locations.list" tabindex="-1"><code translate="no" dir="ltr">cloudscheduler.locations.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.admin">Cloud Scheduler Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.viewer">Cloud Scheduler Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/integrations#integrations.serviceAgent">Application Integration Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.serviceAgent</code>)</li>
</ul></td>
</tr>
</tbody>
</table>

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
