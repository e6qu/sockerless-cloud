# Manage SSL/TLS certificates

<div class="devsite-article-body clearfix">

<div class="nocontent" style="font-size:medium; margin-bottom:40px; border-top:1px solid black;">

<div style="float:right">

<a href="/sql/docs/mysql/manage-ssl-instance" data-track-type="sqlSwitcher" data-track-name="mysqlLink" title="View this page for the MySQL database engine">MySQL</a> <span style="color:light-gray">  \|  </span><span style="font-weight:bold">PostgreSQL</span> <span style="color:light-gray">  \|  </span><a href="/sql/docs/sqlserver/manage-ssl-instance" data-track-type="sqlSwitcher" data-track-name="sqlServerLink" title="View this page for the SQL Server database engine">SQL Server</a>

</div>

</div>

This page describes how to manage your client and server certificate authority (CA) certificates.

## Manage client certificates

Use the following procedures to manage client certificates in Cloud SQL.

### Retrieve a client certificate

You can retrieve the public key portion of a client certificate. You cannot retrieve the private key, however. If you have lost your private key, you must create a new certificate.

<div id="get-ssl-details" class="ds-selector-tabs" ds-scope="code-sample">

<div class="section">

### Console

1.  In the Google Cloud console, go to the **Cloud SQL Instances** page.

    <a href="https://console.cloud.google.com/sql" class="button button-primary" target="console">Go to Cloud SQL Instances</a>

2.  To open the **Overview** page of an instance, click the instance name.

3.  Select **Connections** from the SQL navigation menu.

4.  Select the **Security** tab.

5.  In **Manage client certificates**, click a certificate name.

6.  The **SSL Client Certificate** page opens and shows the client certificate (`client-cert.pem`) with a link to download the certificate.

</div>

<div class="section">

### gcloud

Retrieve the client certificate public key with the [`ssl client-certs describe`](/sdk/gcloud/reference/sql/ssl/client-certs/describe) command:

<div>

</div>

``` devsite-click-to-copy
gcloud sql ssl client-certs describe CERT_NAME \
--instance=INSTANCE_NAME \
--format="value(cert)" > client-cert.pem
```

</div>

<div class="section">

### REST v1

1.  List the certificates on the instance to get the fingerprint of the certificate you want to retrieve:

    Before using any of the request data, make the following replacements:

    - `project-id`: The project ID
    - `instance-id`: The instance ID

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    GET https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-id/sslCerts
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X GET \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         "https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-id/sslCerts"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method GET `
        -Headers $headers `
        -Uri "https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-id/sslCerts" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a JSON response similar to the following:

    <div class="section expandable">

    #### Response

    <div>

    </div>

    ``` readonly
    {
      "kind": "sql#sslCertsList",
      "items": [
        {
          "kind": "sql#sslCert",
          "certSerialNumber": "cert-serial-number",
          "cert": "cert-value",
          "commonName": "ca-server-name",
          "sha1Fingerprint": "sha1Fingerprint"
          "instance": "instance-id",
          "selfLink": "https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-id/sslCerts/sha1FingerPrint",
          "createTime": "2020-02-13T00:10:20.595Z",
          "expirationTime": "2030-02-10T00:11:20.595Z"
        }
      ]
    }
    ```

    </div>

    Record the `sha1Fingerprint` field for the certificate you want to retrieve. Don't include the quotation marks.

2.  Retrieve the certificate:

    Before using any of the request data, make the following replacements:

    - `project-id`: The project ID
    - `instance-id`: The instance ID
    - `sha1FingerPrint`: The cert's sha1FingerPrint

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    GET https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-id/sslCerts/sha1FingerPrint
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X GET \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         "https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-id/sslCerts/sha1FingerPrint"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method GET `
        -Headers $headers `
        -Uri "https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-id/sslCerts/sha1FingerPrint" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a JSON response similar to the following:

    <div class="section expandable">

    #### Response

    <div>

    </div>

    ``` readonly
    {
      "kind": "sql#sslCert",
      "certSerialNumber": "cert-serial-number",
      "cert": "cert-value",
      "commonName": "ca-server-name",
      "sha1Fingerprint": "sha1Fingerprint"
      "instance": "instance-id",
      "selfLink": "https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-id/sslCerts/sha1FingerPrint",
      "createTime": "2020-02-13T00:10:20.595Z",
      "expirationTime": "2030-02-10T00:11:20.595Z"
    }
    ```

    </div>

3.  Copy all of the certificate data contained by the quotation marks to a file, for example `client-cert.pem`. Don't copy the quotation marks themselves.

</div>

<div class="section">

### REST v1beta4

1.  List the certificates on the instance to get the fingerprint of the certificate you want to retrieve:

    Before using any of the request data, make the following replacements:

    - `project-id`: The project ID
    - `instance-id`: The instance ID

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    GET https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id/sslCerts
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X GET \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id/sslCerts"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method GET `
        -Headers $headers `
        -Uri "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id/sslCerts" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a JSON response similar to the following:

    <div class="section expandable">

    #### Response

    <div>

    </div>

    ``` readonly
    {
      "kind": "sql#sslCertsList",
      "items": [
        {
          "kind": "sql#sslCert",
          "certSerialNumber": "cert-serial-number",
          "cert": "cert-value",
          "commonName": "ca-server-name",
          "sha1Fingerprint": "sha1Fingerprint"
          "instance": "instance-id",
          "selfLink": "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id/sslCerts/sha1FingerPrint",
          "createTime": "2020-02-13T00:10:20.595Z",
          "expirationTime": "2030-02-10T00:11:20.595Z"
        }
      ]
    }
    ```

    </div>

    Record the `sha1Fingerprint` field for the certificate you want to retrieve. Don't include the quotation marks.

2.  Retrieve the certificate:

    Before using any of the request data, make the following replacements:

    - `project-id`: The project ID
    - `instance-id`: The instance ID
    - `sha1FingerPrint`: The cert's sha1FingerPrint

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    GET https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id/sslCerts/sha1FingerPrint
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X GET \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id/sslCerts/sha1FingerPrint"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method GET `
        -Headers $headers `
        -Uri "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id/sslCerts/sha1FingerPrint" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a JSON response similar to the following:

    <div class="section expandable">

    #### Response

    <div>

    </div>

    ``` readonly
    {
      "kind": "sql#sslCert",
      "certSerialNumber": "cert-serial-number",
      "cert": "cert-value",
      "commonName": "ca-server-name",
      "sha1Fingerprint": "sha1Fingerprint"
      "instance": "instance-id",
      "selfLink": "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id/sslCerts/sha1FingerPrint",
      "createTime": "2020-02-13T00:10:20.595Z",
      "expirationTime": "2030-02-10T00:11:20.595Z"
    }
    ```

    </div>

3.  Copy all of the certificate data contained by the quotation marks to a file, for example `client-cert.pem`. Don't copy the quotation marks themselves.

</div>

</div>

### Delete a client certificate

When you delete a client certificate, the database server is updated and doesn't need to be restarted.

<div id="delete-client-cert" class="ds-selector-tabs" ds-scope="code-sample">

<div class="section">

### Console

1.  In the Google Cloud console, go to the **Cloud SQL Instances** page.

    <a href="https://console.cloud.google.com/sql" class="button button-primary" target="console">Go to Cloud SQL Instances</a>

2.  To open the **Overview** page of an instance, click the instance name.

3.  Select **Connections** from the SQL navigation menu.

4.  Select the **Security** tab.

5.  In **Manage client certificates**, find the certificate you want to delete and click <img src="/static/sql/images/delete-icon.png" style="margin-bottom:-4px" alt="Delete." />.

6.  In the **Delete client certificate** pane, click **Ok**.

</div>

<div class="section">

### gcloud

Delete the client certificate using the [ssl client-certs delete](/sdk/gcloud/reference/sql/ssl/client-certs/delete) command:

<div>

</div>

``` devsite-click-to-copy
gcloud sql ssl client-certs delete CERT_NAME \
--instance=INSTANCE_NAME
```

</div>

<div class="section">

### REST v1

1.  List the certificates on the instance to get the fingerprint of the certificate you want to delete:

    Before using any of the request data, make the following replacements:

    - `project-id`: The project ID
    - `instance-id`: The instance ID

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    GET https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-id/sslCerts
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X GET \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         "https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-id/sslCerts"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method GET `
        -Headers $headers `
        -Uri "https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-id/sslCerts" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a JSON response similar to the following:

    <div class="section expandable">

    #### Response

    <div>

    </div>

    ``` readonly
    {
      "kind": "sql#sslCertsList",
      "items": [
        {
          "kind": "sql#sslCert",
          "certSerialNumber": "cert-serial-number",
          "cert": "cert-value",
          "commonName": "ca-server-name",
          "sha1Fingerprint": "sha1Fingerprint"
          "instance": "instance-id",
          "selfLink": "https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-id/sslCerts/sha1FingerPrint",
          "createTime": "2020-02-13T00:10:20.595Z",
          "expirationTime": "2030-02-10T00:11:20.595Z"
        }
      ]
    }
    ```

    </div>

    Record the `sha1Fingerprint` field for the certificate you want to delete. Don't include the quotation marks.

2.  Delete the certificate:

    Before using any of the request data, make the following replacements:

    - `project-id`: The project ID
    - `instance-id`: The instance ID
    - `sha1FingerPrint`: The cert's sha1FingerPrint

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    DELETE https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-id/sslCerts/sha1FingerPrint
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X DELETE \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         "https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-id/sslCerts/sha1FingerPrint"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method DELETE `
        -Headers $headers `
        -Uri "https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-id/sslCerts/sha1FingerPrint" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a JSON response similar to the following:

    <div class="section expandable">

    #### Response

    <div>

    </div>

    ``` readonly
    {
      "kind": "sql#operation",
      "targetLink": "https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-id",
      "status": "PENDING",
      "user": "user@example.com",
      "insertTime": "2020-01-20T21:30:35.667Z",
      "operationType": "UPDATE",
      "name": "operation-id",
      "targetId": "instance-id",
      "selfLink": "https://sqladmin.googleapis.com/v1/projects/project-id/operations/operation-id",
      "targetProject": "project-id"
    }
    ```

    </div>

</div>

<div class="section">

### REST v1beta4

1.  List the certificates on the instance to get the fingerprint of the certificate you want to delete:

    Before using any of the request data, make the following replacements:

    - `project-id`: The project ID
    - `instance-id`: The instance ID

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    GET https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id/sslCerts
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X GET \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id/sslCerts"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method GET `
        -Headers $headers `
        -Uri "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id/sslCerts" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a JSON response similar to the following:

    <div class="section expandable">

    #### Response

    <div>

    </div>

    ``` readonly
    {
      "kind": "sql#sslCertsList",
      "items": [
        {
          "kind": "sql#sslCert",
          "certSerialNumber": "cert-serial-number",
          "cert": "cert-value",
          "commonName": "ca-server-name",
          "sha1Fingerprint": "sha1Fingerprint"
          "instance": "instance-id",
          "selfLink": "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id/sslCerts/sha1FingerPrint",
          "createTime": "2020-02-13T00:10:20.595Z",
          "expirationTime": "2030-02-10T00:11:20.595Z"
        }
      ]
    }
    ```

    </div>

    Record the `sha1Fingerprint` field for the certificate you want to delete. Don't include the quotation marks.

2.  Delete the certificate:

    Before using any of the request data, make the following replacements:

    - `project-id`: The project ID
    - `instance-id`: The instance ID
    - `sha1FingerPrint`: The cert's sha1FingerPrint

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    DELETE https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id/sslCerts/sha1FingerPrint
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X DELETE \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id/sslCerts/sha1FingerPrint"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method DELETE `
        -Headers $headers `
        -Uri "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id/sslCerts/sha1FingerPrint" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a JSON response similar to the following:

    <div class="section expandable">

    #### Response

    <div>

    </div>

    ``` readonly
    {
      "kind": "sql#operation",
      "targetLink": "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id",
      "status": "PENDING",
      "user": "user@example.com",
      "insertTime": "2020-01-20T21:30:35.667Z",
      "operationType": "UPDATE",
      "name": "operation-id",
      "targetId": "instance-id",
      "selfLink": "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/operations/operation-id",
      "targetProject": "project-id"
    }
    ```

    </div>

</div>

</div>

## Manage server CA certificates (per-instance CA)

This section describes how to manage server CA certificates that are created internally by Cloud SQL. This is the default server CA mode in Cloud SQL. In this certificate authority hierarchy, Cloud SQL creates a server CA for each instance.

### Rotate server CA certificates

If you've received a notice about your certificates expiring, or you want to initiate a rotation, then take the following steps to complete the rotation. Before you start the rotation, you must have a new server CA on the instance. If a new server CA has already been created, then you can skip the first step in the following procedure.

1.  Create a new server CA.
2.  Download the new server CA certificate information.
3.  Update your clients to use the new server CA certificate information.
4.  Complete the rotation, which moves the active certificate into the "previous" slot and updates the newly added certificate to be the active certificate.

After rotating the SSL certificate, your App Engine and Cloud SQL Auth Proxy connections will automatically receive a new certificate when they connect.

<div id="rotate-server-certs" class="ds-selector-tabs" ds-scope="code-sample">

<div class="section">

### Console

Download the new server CA certificate, encoded as a PEM file, to your local environment:

1.  In the Google Cloud console, go to the **Cloud SQL Instances** page.

    <a href="https://console.cloud.google.com/sql" class="button button-primary" target="console">Go to Cloud SQL Instances</a>

2.  To open the **Overview** page of an instance, click the instance name.

3.  Select **Connections** from the SQL navigation menu.

4.  Select the **Security** tab.

5.  Click to expand **Manage certificates**.

6.  Select **Rotate CA certificate**.

    If there are no eligible certificates, then the rotate option is unavailable. You must create a new [server CA certificate](/sql/docs/postgres/configure-ssl-instance#server-cert-list-view).

7.  Click **Download Certificates**.

Update all of your PostgreSQL clients to use the new information by copying the downloaded file to your client host machines, replacing the existing `server-ca.pem` file.

After you have updated your clients, complete the rotation:

1.  Return to the **Security** tab.
2.  Click to expand **Manage certificates**.
3.  Select **Rotate CA certificate**.
4.  Confirm that your clients are connecting properly.

</div>

<div class="section">

### gcloud

1.  Create a server CA certificate:

    <div>

    </div>

    ``` devsite-click-to-copy
    gcloud sql ssl server-ca-certs create \
    --instance=INSTANCE
    ```

2.  Download the certificate information to a local PEM file:

    <div>

    </div>

    ``` devsite-click-to-copy
    gcloud sql ssl server-ca-certs list \
    --format="value(cert)" \
    --instance=INSTANCE_NAME > \
    FILE_PATH/FILE_NAME.pem
    ```

3.  Update all of your clients to use the new information by copying the downloaded file to your client host machines, replacing the existing server-ca.pem files.

4.  After you have updated your clients, complete the rotation:

    <div>

    </div>

    ``` devsite-click-to-copy
    gcloud sql ssl server-ca-certs rotate \
    --instance=INSTANCE_NAME
          
    ```

5.  Confirm that your clients are connecting properly.

</div>

<div class="section">

### REST v1

1.  Download your server CA certificates:

    Before using any of the request data, make the following replacements:

    - `project-id`: The project ID
    - `instance-id`: The instance ID

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    GET https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-id/listServerCas
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X GET \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         "https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-id/listServerCas"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method GET `
        -Headers $headers `
        -Uri "https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-id/listServerCas" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a JSON response similar to the following:

    <div class="section expandable">

    #### Response

    <div>

    </div>

    ``` readonly
    {
      "certs": [
        {
          "kind": "sql#sslCert",
          "certSerialNumber": "cert-serial-number",
          "cert": "cert-value",
          "commonName": "ca-server-name",
          "sha1Fingerprint": "sha1Fingerprint",
          "instance": "instance-id",
          "createTime": "2020-02-10T17:18:54.935Z",
          "expirationTime": "2030-02-07T17:19:54.935Z"
        },
        {
          "kind": "sql#sslCert",
           certSerialNumber": "cert-serial-number",
          "cert": "cert-value",
          "commonName": "ca-server-name",
          "sha1Fingerprint": "sha1Fingerprint",
          "instance": "instance-id",
          "createTime": "2019-11-14T22:43:56.458Z",
          "expirationTime": "2029-11-11T22:44:56.458Z"
        }
      ],
      "activeVersion": "active-version",
      "kind": "sql#instancesListServerCas"
    }
    ```

    </div>

2.  Complete the rotation:

    Before using any of the request data, make the following replacements:

    - `project-id`: The project ID
    - `instance-id`: The instance ID

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    POST https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-id/rotateServerCa
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X POST \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         -H "Content-Type: application/json; charset=utf-8" \
         -d "" \
         "https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-id/rotateServerCa"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method POST `
        -Headers $headers `
        -Uri "https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-id/rotateServerCa" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a JSON response similar to the following:

    <div class="section expandable">

    #### Response

    <div>

    </div>

    ``` readonly
    {
      "kind": "sql#operation",
      "targetLink": "https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-id",
      "status": "PENDING",
      "user": "user@example.com",
      "insertTime": "2020-01-20T21:30:35.667Z",
      "operationType": "UPDATE",
      "name": "operation-id",
      "targetId": "instance-id",
      "selfLink": "https://sqladmin.googleapis.com/v1/projects/project-id/operations/operation-id",
      "targetProject": "project-id"
    }
    ```

    </div>

</div>

<div class="section">

### REST v1beta4

1.  Download your server CA certificates:

    Before using any of the request data, make the following replacements:

    - `project-id`: The project ID
    - `instance-id`: The instance ID

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    GET https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id/listServerCas
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X GET \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id/listServerCas"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method GET `
        -Headers $headers `
        -Uri "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id/listServerCas" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a JSON response similar to the following:

    <div class="section expandable">

    #### Response

    <div>

    </div>

    ``` readonly
    {
      "certs": [
        {
          "kind": "sql#sslCert",
          "certSerialNumber": "cert-serial-number",
          "cert": "cert-value",
          "commonName": "ca-server-name",
          "sha1Fingerprint": "sha1Fingerprint",
          "instance": "instance-id",
          "createTime": "2020-02-10T17:18:54.935Z",
          "expirationTime": "2030-02-07T17:19:54.935Z"
        },
        {
          "kind": "sql#sslCert",
           certSerialNumber": "cert-serial-number",
          "cert": "cert-value",
          "commonName": "ca-server-name",
          "sha1Fingerprint": "sha1Fingerprint",
          "instance": "instance-id",
          "createTime": "2019-11-14T22:43:56.458Z",
          "expirationTime": "2029-11-11T22:44:56.458Z"
        }
      ],
      "activeVersion": "active-version",
      "kind": "sql#instancesListServerCas"
    }
    ```

    </div>

2.  Complete the rotation:

    Before using any of the request data, make the following replacements:

    - `project-id`: The project ID
    - `instance-id`: The instance ID

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    POST https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id/rotateServerCa
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X POST \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         -H "Content-Type: application/json; charset=utf-8" \
         -d "" \
         "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id/rotateServerCa"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method POST `
        -Headers $headers `
        -Uri "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id/rotateServerCa" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a JSON response similar to the following:

    <div class="section expandable">

    #### Response

    <div>

    </div>

    ``` readonly
    {
      "kind": "sql#operation",
      "targetLink": "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id",
      "status": "PENDING",
      "user": "user@example.com",
      "insertTime": "2020-01-20T21:30:35.667Z",
      "operationType": "UPDATE",
      "name": "operation-id",
      "targetId": "instance-id",
      "selfLink": "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/operations/operation-id",
      "targetProject": "project-id"
    }
    ```

    </div>

</div>

</div>

If you receive an error when you try to rotate a certificate that says `No upcoming/previous Server CA Certificate exists`, then verify that you're running the command on an instance that uses the per-instance CA hierarchy. You can view which CA hierarchy is configured for a Cloud SQL instance by using the `gcloud sql instances describe` command. For more information, see [View instance information](/sql/docs/postgres/instance-info).

### Roll back a certificate rotation operation

After you complete a certificate rotation, your clients must all use the new certificate to connect to your Cloud SQL instance. If the clients aren't updated properly to use the new certificate information, then they can't connect using SSL/TLS to your instance. If this happens, then you can roll back to the previous certificate configuration.

A rollback operation moves the active certificate into the "upcoming" slot (replacing any "upcoming" certificate). The "previous" certificate becomes the active certificate, returning your certificate configuration to the state it was in before you completed the rotation.

**Note:** Certificate rollback is available only until the old certificate expires.

To roll back to the previous certificate configuration:

<div id="rollback-server-certs" class="ds-selector-tabs" ds-scope="code-sample">

<div class="section">

### Console

1.  In the Google Cloud console, go to the **Cloud SQL Instances** page.

    <a href="https://console.cloud.google.com/sql" class="button button-primary" target="console">Go to Cloud SQL Instances</a>

2.  To open the **Overview** page of an instance, click the instance name.

3.  Select **Connections** from the SQL navigation menu.

4.  Select the **Security** tab.

5.  Click to expand **Manage certificates**.

6.  Select **Rollback CA certificate**.

    If there are no eligible certificates, then the rollback option is unavailable. Otherwise, the rollback action completes after a few seconds.

</div>

<div class="section">

### gcloud

<div>

</div>

``` devsite-click-to-copy
gcloud sql ssl server-ca-certs rollback \
--instance=INSTANCE_NAME
   
```

</div>

<div class="section">

### REST v1

1.  Download your server CA certificates:

    Before using any of the request data, make the following replacements:

    - `project-id`: The project ID
    - `instance-id`: The instance ID

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    GET https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-id/listServerCas
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X GET \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         "https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-id/listServerCas"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method GET `
        -Headers $headers `
        -Uri "https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-id/listServerCas" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a JSON response similar to the following:

    <div class="section expandable">

    #### Response

    <div>

    </div>

    ``` readonly
    {
      "certs": [
        {
          "kind": "sql#sslCert",
          "certSerialNumber": "cert-serial-number",
          "cert": "cert-value",
          "commonName": "ca-server-name",
          "sha1Fingerprint": "sha1Fingerprint",
          "instance": "instance-id",
          "createTime": "2020-02-10T17:18:54.935Z",
          "expirationTime": "2030-02-07T17:19:54.935Z"
        },
        {
          "kind": "sql#sslCert",
           certSerialNumber": "cert-serial-number",
          "cert": "cert-value",
          "commonName": "ca-server-name",
          "sha1Fingerprint": "sha1Fingerprint",
          "instance": "instance-id",
          "createTime": "2019-11-14T22:43:56.458Z",
          "expirationTime": "2029-11-11T22:44:56.458Z"
        }
      ],
      "activeVersion": "active-version",
      "kind": "sql#instancesListServerCas"
    }
    ```

    </div>

2.  Copy the `sha1Fingerprint` field for the version you want to roll back to.

    Look for the version with a createTime value immediately earlier than the version with the sha1Fingerprint value shown as `activeVersion`.

3.  Roll back the rotation:

    Before using any of the request data, make the following replacements:

    - `project-id`: The project ID
    - `instance-id`: The instance ID

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    POST https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-id/rotateServerCa
    ```

    </div>

    Request JSON body:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    {
      "rotateServerCaContext": {"nextVersion": "sha1Fingerprint"}
    }
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Save the request body in a file named `request.json`, and execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X POST \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         -H "Content-Type: application/json; charset=utf-8" \
         -d @request.json \
         "https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-id/rotateServerCa"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Save the request body in a file named `request.json`, and execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method POST `
        -Headers $headers `
        -ContentType: "application/json; charset=utf-8" `
        -InFile request.json `
        -Uri "https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-id/rotateServerCa" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a JSON response similar to the following:

    <div class="section expandable">

    #### Response

    <div>

    </div>

    ``` readonly
    {
      "kind": "sql#operation",
      "targetLink": "https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-id",
      "status": "PENDING",
      "user": "user@example.com",
      "insertTime": "2020-01-20T21:30:35.667Z",
      "operationType": "UPDATE",
      "name": "operation-id",
      "targetId": "instance-id",
      "selfLink": "https://sqladmin.googleapis.com/v1/projects/project-id/operations/operation-id",
      "targetProject": "project-id"
    }
    ```

    </div>

</div>

<div class="section">

### REST v1beta4

1.  Download your server CA certificates:

    Before using any of the request data, make the following replacements:

    - `project-id`: The project ID
    - `instance-id`: The instance ID

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    GET https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id/listServerCas
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X GET \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id/listServerCas"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method GET `
        -Headers $headers `
        -Uri "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id/listServerCas" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a JSON response similar to the following:

    <div class="section expandable">

    #### Response

    <div>

    </div>

    ``` readonly
    {
      "certs": [
        {
          "kind": "sql#sslCert",
          "certSerialNumber": "cert-serial-number",
          "cert": "cert-value",
          "commonName": "ca-server-name",
          "sha1Fingerprint": "sha1Fingerprint",
          "instance": "instance-id",
          "createTime": "2020-02-10T17:18:54.935Z",
          "expirationTime": "2030-02-07T17:19:54.935Z"
        },
        {
          "kind": "sql#sslCert",
           certSerialNumber": "cert-serial-number",
          "cert": "cert-value",
          "commonName": "ca-server-name",
          "sha1Fingerprint": "sha1Fingerprint",
          "instance": "instance-id",
          "createTime": "2019-11-14T22:43:56.458Z",
          "expirationTime": "2029-11-11T22:44:56.458Z"
        }
      ],
      "activeVersion": "active-version",
      "kind": "sql#instancesListServerCas"
    }
    ```

    </div>

2.  Copy the `sha1Fingerprint` field for the version you want to roll back to.

    Look for the version with a createTime value immediately earlier than the version with the sha1Fingerprint value shown as `activeVersion`.

3.  Roll back the rotation:

    Before using any of the request data, make the following replacements:

    - `project-id`: The project ID
    - `instance-id`: The instance ID

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    POST https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id/rotateServerCa
    ```

    </div>

    Request JSON body:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    {
      "rotateServerCaContext": {"nextVersion": "sha1Fingerprint"}
    }
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Save the request body in a file named `request.json`, and execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X POST \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         -H "Content-Type: application/json; charset=utf-8" \
         -d @request.json \
         "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id/rotateServerCa"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Save the request body in a file named `request.json`, and execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method POST `
        -Headers $headers `
        -ContentType: "application/json; charset=utf-8" `
        -InFile request.json `
        -Uri "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id/rotateServerCa" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a JSON response similar to the following:

    <div class="section expandable">

    #### Response

    <div>

    </div>

    ``` readonly
    {
      "kind": "sql#operation",
      "targetLink": "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id",
      "status": "PENDING",
      "user": "user@example.com",
      "insertTime": "2020-01-20T21:30:35.667Z",
      "operationType": "UPDATE",
      "name": "operation-id",
      "targetId": "instance-id",
      "selfLink": "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/operations/operation-id",
      "targetProject": "project-id"
    }
    ```

    </div>

</div>

</div>

If you receive an error when you try to roll back a certificate CA rotation that says `No upcoming/previous Server CA Certificate exists`, then verify that you're running the command on an instance that uses the per-instance CA hierarchy. You can view which CA hierarchy is configured for a Cloud SQL instance by using the `gcloud sql instances describe` command. For more information, see [View instance information](/sql/docs/postgres/instance-info).

### Initiate a rotation

You don't need to wait for the email from Cloud SQL to start a rotation. You can start one at any time. When you start a rotation, a new certificate is created and placed into the "upcoming" slot. If a certificate is already present in the "upcoming" slot at the time of your request, then that certificate is deleted. There can be only one upcoming certificate.

To initiate a rotation:

<div id="initiate-rotation" class="ds-selector-tabs" ds-scope="code-sample">

<div class="section">

### Console

1.  In the Google Cloud console, go to the **Cloud SQL Instances** page.

    <a href="https://console.cloud.google.com/sql" class="button button-primary" target="console">Go to Cloud SQL Instances</a>

2.  To open the **Overview** page of an instance, click the instance name.

3.  Select **Connections** from the SQL navigation menu.

4.  Select the **Security** tab.

5.  Click to expand **Manage certificates**.

6.  Click **Create new CA certificate**.

7.  Select **Rotate CA certificate**.

    If there are no eligible certificates, then the rotate option is unavailable.

8.  Complete the rotation as described in [Rotate server CA certificates](#rotate).

</div>

<div class="section">

### gcloud

1.  Initiate the rotation:

    <div>

    </div>

    ``` devsite-click-to-copy
    gcloud sql ssl server-ca-certs create \
    --instance=INSTANCE_NAME
         
    ```

2.  Complete the rotation as described in [Rotate server CA certificates](#rotate).

</div>

<div class="section">

### REST v1

1.  Before using any of the request data, make the following replacements:

    - `project-id`: The project ID
    - `instance-id`: The instance ID

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    POST https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-id/rotateServerCa
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X POST \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         -H "Content-Type: application/json; charset=utf-8" \
         -d "" \
         "https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-id/rotateServerCa"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method POST `
        -Headers $headers `
        -Uri "https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-id/rotateServerCa" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a JSON response similar to the following:

    <div class="section expandable">

    #### Response

    <div>

    </div>

    ``` readonly
    {
      "kind": "sql#operation",
      "targetLink": "https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-id",
      "status": "PENDING",
      "user": "user@example.com",
      "insertTime": "2020-01-20T21:30:35.667Z",
      "operationType": "UPDATE",
      "name": "operation-id",
      "targetId": "instance-id",
      "selfLink": "https://sqladmin.googleapis.com/v1/projects/project-id/operations/operation-id",
      "targetProject": "project-id"
    }
    ```

    </div>

2.  Complete the rotation as described in [Rotate server CA certificates](#rotate).

</div>

<div class="section">

### REST v1beta4

1.  Before using any of the request data, make the following replacements:

    - `project-id`: The project ID
    - `instance-id`: The instance ID

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    POST https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id/rotateServerCa
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X POST \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         -H "Content-Type: application/json; charset=utf-8" \
         -d "" \
         "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id/rotateServerCa"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method POST `
        -Headers $headers `
        -Uri "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id/rotateServerCa" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a JSON response similar to the following:

    <div class="section expandable">

    #### Response

    <div>

    </div>

    ``` readonly
    {
      "kind": "sql#operation",
      "targetLink": "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id",
      "status": "PENDING",
      "user": "user@example.com",
      "insertTime": "2020-01-20T21:30:35.667Z",
      "operationType": "UPDATE",
      "name": "operation-id",
      "targetId": "instance-id",
      "selfLink": "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/operations/operation-id",
      "targetProject": "project-id"
    }
    ```

    </div>

2.  Complete the rotation as described in [Rotate server CA certificates](#rotate).

</div>

</div>

### Get information about a server CA certificate

You can get information about your server CA certificate, such as when it expires or what level of encryption it provides.

<div id="get-server-details" class="ds-selector-tabs" ds-scope="code-sample">

<div class="section">

### Console

1.  In the Google Cloud console, go to the **Cloud SQL Instances** page.

    <a href="https://console.cloud.google.com/sql" class="button button-primary" target="console">Go to Cloud SQL Instances</a>

2.  To open the **Overview** page of an instance, click the instance name.

3.  Select **Connections** from the SQL navigation menu.

4.  Select the **Security** tab.

    In **Manage server CA certificates**, you can see the expiration date of your server CA certificate in the table.

    To see the certificate type, use the `gcloud sql ssl server-ca-certs list --instance=``INSTANCE_NAME` command.

</div>

<div class="section">

### gcloud

<div>

</div>

``` devsite-click-to-copy
gcloud sql ssl server-ca-certs list \
--instance=INSTANCE_NAME
```

</div>

<div class="section">

### REST v1

When you describe your instance, you can see details about the server CA certificate:

Before using any of the request data, make the following replacements:

- `project-id`: The project ID
- `instance-id`: The instance ID

HTTP method and URL:

<div class="section">

<div>

</div>

``` devsite-click-to-copy
GET https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-id?fields=serverCaCert
```

</div>

To send your request, expand one of these options:

<div class="section expandable">

#### curl (Linux, macOS, or Cloud Shell)

**Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).

Execute the following command:

<div class="section">

<div>

</div>

``` devsite-click-to-copy
curl -X GET \
     -H "Authorization: Bearer $(gcloud auth print-access-token)" \
     "https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-id?fields=serverCaCert"
```

</div>

</div>

<div class="section expandable">

#### PowerShell (Windows)

**Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).

Execute the following command:

<div class="section">

<div>

</div>

``` devsite-click-to-copy
$cred = gcloud auth print-access-token
$headers = @{ "Authorization" = "Bearer $cred" }

Invoke-WebRequest `
    -Method GET `
    -Headers $headers `
    -Uri "https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-id?fields=serverCaCert" | Select-Object -Expand Content
```

</div>

</div>

You should receive a JSON response similar to the following:

<div class="section expandable">

#### Response

<div>

</div>

``` readonly
{
  "serverCaCert":
  {
    "kind": "sql#sslCert",
    "certSerialNumber": "cert-serial-number",
    "cert": "cert-value-",
    "commonName": "ca-server-name",
    "sha1Fingerprint": "sha1Fingerprint",
    "instance": "instance-id",
    "createTime": "2020-02-10T17:18:54.935Z",
    "expirationTime": "2030-02-07T17:19:54.935Z"
  }
}
```

</div>

</div>

<div class="section">

### REST v1beta4

When you describe your instance, you can see details about the server CA certificate:

Before using any of the request data, make the following replacements:

- `project-id`: The project ID
- `instance-id`: The instance ID

HTTP method and URL:

<div class="section">

<div>

</div>

``` devsite-click-to-copy
GET https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id?fields=serverCaCert
```

</div>

To send your request, expand one of these options:

<div class="section expandable">

#### curl (Linux, macOS, or Cloud Shell)

**Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).

Execute the following command:

<div class="section">

<div>

</div>

``` devsite-click-to-copy
curl -X GET \
     -H "Authorization: Bearer $(gcloud auth print-access-token)" \
     "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id?fields=serverCaCert"
```

</div>

</div>

<div class="section expandable">

#### PowerShell (Windows)

**Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).

Execute the following command:

<div class="section">

<div>

</div>

``` devsite-click-to-copy
$cred = gcloud auth print-access-token
$headers = @{ "Authorization" = "Bearer $cred" }

Invoke-WebRequest `
    -Method GET `
    -Headers $headers `
    -Uri "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id?fields=serverCaCert" | Select-Object -Expand Content
```

</div>

</div>

You should receive a JSON response similar to the following:

<div class="section expandable">

#### Response

<div>

</div>

``` readonly
{
  "serverCaCert":
  {
    "kind": "sql#sslCert",
    "certSerialNumber": "cert-serial-number",
    "cert": "cert-value-",
    "commonName": "ca-server-name",
    "sha1Fingerprint": "sha1Fingerprint",
    "instance": "instance-id",
    "createTime": "2020-02-10T17:18:54.935Z",
    "expirationTime": "2030-02-07T17:19:54.935Z"
  }
}
```

</div>

</div>

</div>

### View the content of CA certificates

You can use `openssl storeutl` to view the content of CA certificates.

When you run the [sql ssl server-ca-certs list](/sdk/gcloud/reference/sql/ssl/server-ca-certs/list) command, you might get multiple CA certificates from previous rotation-related operations.

<div id="examine-ca-certs" class="ds-selector-tabs" ds-scope="code-sample">

<div class="section">

### gcloud

1.  Run the following command:

    <div>

    </div>

    ``` devsite-click-to-copy
    gcloud sql ssl server-ca-certs list \
      --instance=INSTANCE_NAME \
      --format='value(cert)' > temp_cert.pem
    ```

    Replace `INSTANCE_NAME` with the name of the instance.

2.  Use `openssl` to examine the contents of the CA certificates.

</div>

</div>

### View the content of a server certificate

You can use `openssl s_client` to view the content of server certificates.

<div id="examine-server-certs" class="ds-selector-tabs" ds-scope="code-sample">

<div class="section">

### gcloud

To view the server certificate content, run the following command:

<div>

</div>

``` devsite-click-to-copy
openssl s_client -starttls postgres -connect INSTANCE_IP_ADDRESS:5432
```

Replace `INSTANCE_IP_ADDRESS` with the IP address of the instance.

</div>

</div>

### External server SSL expiry notification

- If the external server's server CA certificate is expiring, then [rotate the SSL certificates](#rotate), including the server CA certificate on the on-premises instance. This step depends on how the on-premises instance is managed. Steps can vary if, for example, you're using an RDS server CA certificate, Cloud SQL server CA certificate, or database-generic server CA certificate.
- If the client certificate is expiring, then you need to generate a new certificate and key. This applies to both Google Cloud-managed SSL certificates and self-signed certificates.
- Update the Cloud SQL source representation instance with the new SSL certificates.

## Manage server certificates (shared CA)

This section describes how to manage server certificates on instances that use shared CAs or customer-managed CAs.

You can opt in to using shared CAs as the server CA mode for your instance by specifying `GOOGLE_MANAGED_CAS_CA` for the `serverCaMode` setting (Cloud SQL Admin API) or the `--server-ca-mode` flag ([gcloud CLI](/sdk/gcloud)) when you [create](/sql/docs/postgres/create-instance) or [edit](/sql/docs/postgres/edit-instance) your instance.

To use customer-managed CA as the server CA mode for your instance, you must specify `CUSTOMER_MANAGED_CAS_CA` for the `serverCaMode` setting (Cloud SQL Admin API) or the `--server-ca-mode` flag ([gcloud CLI](/sdk/gcloud)) when you [create](/sql/docs/postgres/create-instance) or [edit](/sql/docs/postgres/edit-instance) your instance, and you must have a valid CA pool and CA. For more information, see [Use customer-managed CA](/sql/docs/postgres/customer-managed-ca).

### Enable or disable automatic server certificate rotation

We recommend that you enable automatic server certificate rotation. With this feature enabled, Cloud SQL automatically rotates your server certificate during your regularly scheduled [maintenance update](/sql/docs/postgres/maintenance) or when you [perform self-service maintenance](/sql/docs/postgres/self-service-maintenance) up to 180 days before the certificate expires. Automatic certificate rotation helps you avoid connection interruptions caused by expired certificates and eliminates the need to rotate the certificates manually.

**Note:** Your server certificate won't be rotated automatically if maintenance updates are skipped or during the maintenance event, Cloud SQL detects that the certificate has more than 180 days left until its expiration date.

You can enable automatic server certificate rotation when you [create your instance](/sql/docs/postgres/create-instance) or when you edit your existing instance.

The following procedure describes how to edit an existing instance to enable or disable automatic server certificate rotation.

<div id="update-server-certs-cas-automatic" class="ds-selector-tabs" ds-scope="code-sample">

<div class="section">

### Console

1.  In the Google Cloud console, go to the **Cloud SQL Instances** page.

    <a href="https://console.cloud.google.com/sql" class="button button-primary" target="console">Go to Cloud SQL Instances</a>

2.  To open the **Overview** page of an instance, click the instance name.

3.  Click **Edit**.

4.  In the **Customize your instance** section, expand **Show configuration options**.

5.  Click **Security** to expand the security configuration section.

6.  Do one of the following:
    - To enable automatic server certificate rotation, select the **Rotate server certificates automatically** checkbox.
    - To disable automatic server certificate rotation, clear the **Rotate server certificates automatically** checkbox.

7.  Click **Save**.

</div>

<div class="section">

### gcloud

To edit server certificate rotation mode for an instance, use the [`gcloud sql instances patch`](/sdk/gcloud/reference/sql/instances/patch) command:

<div>

</div>

``` devsite-click-to-copy
gcloud sql instances patch INSTANCE_NAME \
  --project=PROJECT_ID \
  --server-certificate-rotation-mode=SERVER_CERTIFICATE_ROTATION_MODE
```

Make the following replacements:

- `INSTANCE_NAME`: the name of the Cloud SQL instance that has a server certificate that you're modifying
- `PROJECT_ID`: the ID or [project number](/resource-manager/docs/creating-managing-projects#identifying_projects) of the Google Cloud project that contains the instance
- `SERVER_CERTIFICATE_ROTATION_MODE`: specify either `NO_AUTOMATIC_ROTATION` or `AUTOMATIC_ROTATION_DURING_MAINTENANCE`.

</div>

<div class="section">

### REST v1

Before using any of the request data, make the following replacements:

- `PROJECT_ID`: the ID or [project number](/resource-manager/docs/creating-managing-projects#identifying_projects) of your Google Cloud project. This project contains a Cloud SQL instance that has a server certificate that you're managing.

- `INSTANCE_NAME`: the name of the instance.

- `SERVER_CERTIFICATE_ROTATION_MODE`: specify either `NO_AUTOMATIC_ROTATION` or `AUTOMATIC_ROTATION_DURING_MAINTENANCE`.

HTTP method and URL:

<div class="section">

<div>

</div>

``` devsite-click-to-copy
PATCH https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/instances/INSTANCE_NAME
```

</div>

Request JSON body:

<div class="section">

<div>

</div>

``` devsite-click-to-copy
{
  "kind": "sql#instance",
  "name": "INSTANCE_NAME",
  "project": "PROJECT_ID",
  "settings": {
    "ipConfiguration": {
      "serverCertificateRotationMode": "SERVER_CERTIFICATE_ROTATION_MODE"
    },
    "kind": "sql#settings"
  }
}
```

</div>

To send your request, expand one of these options:

<div class="section expandable">

#### curl (Linux, macOS, or Cloud Shell)

**Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).

Save the request body in a file named `request.json`, and execute the following command:

<div class="section">

<div>

</div>

``` devsite-click-to-copy
curl -X PATCH \
     -H "Authorization: Bearer $(gcloud auth print-access-token)" \
     -H "Content-Type: application/json; charset=utf-8" \
     -d @request.json \
     "https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/instances/INSTANCE_NAME"
```

</div>

</div>

<div class="section expandable">

#### PowerShell (Windows)

**Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).

Save the request body in a file named `request.json`, and execute the following command:

<div class="section">

<div>

</div>

``` devsite-click-to-copy
$cred = gcloud auth print-access-token
$headers = @{ "Authorization" = "Bearer $cred" }

Invoke-WebRequest `
    -Method PATCH `
    -Headers $headers `
    -ContentType: "application/json; charset=utf-8" `
    -InFile request.json `
    -Uri "https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/instances/INSTANCE_NAME" | Select-Object -Expand Content
```

</div>

</div>

You should receive a JSON response similar to the following:

<div class="section">

<div>

</div>

``` readonly
{
  "kind": "sql#operation",
  "targetLink": "https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/instances/INSTANCE_NAME",
  "status": "PENDING",
  "user": "user@example.com",
  "insertTime": "2026-01-16T02:32:12.281Z",
  "operationType": "UPDATE",
  "name": "OPERATION_ID",
  "targetId": "INSTANCE_NAME",
  "selfLink": "https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/operations/OPERATION_ID",
  "targetProject": "PROJECT_ID"
}
```

</div>

To see how the [underlying REST API request](/sql/docs/postgres/admin-api/rest/v1beta4/instances/patch) is constructed for this task, see the [APIs Explorer on the instances:patch page](/sql/docs/postgres/admin-api/rest/v1beta4/instances/patch).

</div>

<div class="section">

### REST v1beta4

Before using any of the request data, make the following replacements:

- `PROJECT_ID`: the ID or [project number](/resource-manager/docs/creating-managing-projects#identifying_projects) of your Google Cloud project. This project contains a Cloud SQL instance that has a server certificate that you're managing.

- `INSTANCE_NAME`: the name of the instance.

- `SERVER_CERTIFICATE_ROTATION_MODE`: specify either `NO_AUTOMATIC_ROTATION` or `AUTOMATIC_ROTATION_DURING_MAINTENANCE`.

HTTP method and URL:

<div class="section">

<div>

</div>

``` devsite-click-to-copy
PATCH https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/instances/INSTANCE_NAME
```

</div>

Request JSON body:

<div class="section">

<div>

</div>

``` devsite-click-to-copy
{
  "kind": "sql#instance",
  "name": "INSTANCE_NAME",
  "project": "PROJECT_ID",
  "settings": {
    "ipConfiguration": {
      "serverCertificateRotationMode": "SERVER_CERTIFICATE_ROTATION_MODE"
    },
    "kind": "sql#settings"
  }
}
```

</div>

To send your request, expand one of these options:

<div class="section expandable">

#### curl (Linux, macOS, or Cloud Shell)

**Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).

Save the request body in a file named `request.json`, and execute the following command:

<div class="section">

<div>

</div>

``` devsite-click-to-copy
curl -X PATCH \
     -H "Authorization: Bearer $(gcloud auth print-access-token)" \
     -H "Content-Type: application/json; charset=utf-8" \
     -d @request.json \
     "https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/instances/INSTANCE_NAME"
```

</div>

</div>

<div class="section expandable">

#### PowerShell (Windows)

**Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).

Save the request body in a file named `request.json`, and execute the following command:

<div class="section">

<div>

</div>

``` devsite-click-to-copy
$cred = gcloud auth print-access-token
$headers = @{ "Authorization" = "Bearer $cred" }

Invoke-WebRequest `
    -Method PATCH `
    -Headers $headers `
    -ContentType: "application/json; charset=utf-8" `
    -InFile request.json `
    -Uri "https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/instances/INSTANCE_NAME" | Select-Object -Expand Content
```

</div>

</div>

You should receive a JSON response similar to the following:

<div class="section">

<div>

</div>

``` readonly
{
  "kind": "sql#operation",
  "targetLink": "https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/instances/INSTANCE_NAME",
  "status": "PENDING",
  "user": "user@example.com",
  "insertTime": "2026-01-16T02:32:12.281Z",
  "operationType": "UPDATE",
  "name": "OPERATION_ID",
  "targetId": "INSTANCE_NAME",
  "selfLink": "https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/operations/OPERATION_ID",
  "targetProject": "PROJECT_ID"
}
```

</div>

To see how the [underlying REST API request](/sql/docs/postgres/admin-api/rest/v1beta4/instances/patch) is constructed for this task, see the [APIs Explorer on the instances:patch page](/sql/docs/postgres/admin-api/rest/v1beta4/instances/patch).

</div>

</div>

### Manually rotate server certificates

If you've received a notice about your server certificates expiring or you want to initiate a rotation, but you don't have automatic server certificate rotation enabled, then take the following steps to complete the rotation. Before you start the rotation, there must be a new server certificate created for the upcoming rotation. If there is already a new server certificate created for the upcoming rotation, then you can skip the first step in the following procedure.

To rotate the server certificate on your instance, perform the following steps:

1.  If you need a new server certificate, then [create one](/sql/docs/postgres/create-instance#create-server-certificate-cas).

2.  If your clients already trust the root CA, then this step is optional. However, if you need to update your clients with server CA information, then do the following:

    1.  Download the latest server CA information.
    2.  Update your clients to use the latest server CA information.

3.  Complete the rotation by moving the active certificate to the previous slot, and updating the new certificate to be the active certificate.

<div id="rotate-server-certs-cas" class="ds-selector-tabs" ds-scope="code-sample">

<div class="section">

### Console

Download the server CA certificate information, encoded as a PEM file, to your local environment:

1.  In the Google Cloud console, go to the **Cloud SQL Instances** page.

    <a href="https://console.cloud.google.com/sql" class="button button-primary" target="console">Go to Cloud SQL Instances</a>

2.  To open the **Overview** page of an instance, click the instance name.

3.  Select **Connections** from the SQL navigation menu.

4.  Select the **Security** tab.

5.  Click to expand **Manage certificates**.

6.  Confirm that the **Rotate server certificate** option appears as an available option; however, don't select it yet.

    If there are no eligible certificates, then the rotate option is unavailable. You must create a new [server certificate](/sql/docs/postgres/configure-ssl-instance#server-cert-list-view).

7.  Click **Download certificates**.

Update all of your PostgreSQL clients to use the new information by copying the downloaded file to your client host machines, replacing the existing `server-ca.pem` file.

After you have updated your clients, complete the rotation:

1.  Return to the **Security** tab.

2.  Click to expand **Manage certificates**.

3.  Select **Rotate certificate**.

4.  In the **Confirm certificate rotation** dialog, click **Rotate**.

5.  Confirm that your clients are connecting properly.

    If any clients are not connecting using the newly rotated certificate, then you can select **Rollback certificate** to [rollback](#rollback) to the previous configuration.

</div>

<div class="section">

### gcloud

1.  To create a server certificate, use the following command:

    <div>

    </div>

    ``` devsite-click-to-copy
    gcloud sql ssl server-certs create \
    --instance=INSTANCE
    ```

2.  Make sure that you're using the [latest CA bundle](#download-root-regional-ca-bundles). If you aren't using the latest CA bundle, then run the following command to download the latest server CA information for the instance to a local PEM file:

    <div>

    </div>

    ``` devsite-click-to-copy
    gcloud sql ssl server-certs list \
    --format="value(ca_cert.cert)" \
    --instance=INSTANCE_NAME > \
    FILE_PATH/server-ca.pem
    ```

    Or download the CA bundles from the [root and regional CA certificate bundle table](#download-root-regional-ca-bundles) on this page.

    Then update all of your clients to use new server CA information by copying the downloaded file to your client host machines, replacing the existing `server-ca.pem` files.

3.  After you update all your clients (if client updates are required), complete the rotation:

    <div>

    </div>

    ``` devsite-click-to-copy
    gcloud sql ssl server-certs rotate \
    --instance=INSTANCE_NAME
          
    ```

4.  Confirm that your clients are connecting properly.

    If any clients aren't connecting using the newly rotated server certificate, then [roll back](#rollback-certificate-rotation-cas) to the previous configuration.

</div>

<div class="section">

### REST v1

1.  Create a server certificate.

    Before using any of the request data, make the following replacements:

    - `PROJECT_ID`: the project ID
    - `INSTANCE_ID`: the instance ID

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    POST https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/instances/INSTANCE_ID/addServerCertificate
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X POST \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         -H "Content-Type: application/json; charset=utf-8" \
         -d "" \
         "https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/instances/INSTANCE_ID/addServerCertificate"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method POST `
        -Headers $headers `
        -Uri "https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/instances/INSTANCE_ID/addServerCertificate" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a JSON response similar to the following:

    <div class="section expandable">

    #### Response

    <div>

    </div>

    ``` readonly
    {
      "kind": "sql#operation",
      "targetLink": "https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/instances/INSTANCE_ID",
      "status": "PENDING",
      "user": "user@example.com",
      "insertTime": "2024-01-20T21:30:35.667Z",
      "operationType": "UPDATE",
      "name": "OPERATION_ID",
      "targetId": "INSTANCE_ID",
      "selfLink": "https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/operations/OPERATION_ID",
      "targetProject": "PROJECT_ID"
    }
    ```

    </div>

2.  If you need to download server CA certificate information, then you can use the following command.

    Before using any of the request data, make the following replacements:

    - `PROJECT_ID`: the project ID
    - `INSTANCE_ID`: the instance ID

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    GET https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/instances/INSTANCE_ID/listServerCertificates
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X GET \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         "https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/instances/INSTANCE_ID/listServerCertificates"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method GET `
        -Headers $headers `
        -Uri "https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/instances/INSTANCE_ID/listServerCertificates" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a JSON response similar to the following:

    <div class="section expandable">

    #### Response

    <div>

    </div>

    ``` readonly
    {
      "caCerts": [
        {
          "kind": "sql#sslCert",
          "certSerialNumber": "CERT_SERIAL_NUMBER_CA_CERT_ONE",
          "cert": "CERT_VALUE",
          "commonName": "CA_SERVER_NAME",
          "sha1Fingerprint": "sha1Fingerprint_CA_CERT_ONE",
          "instance": "INSTANCE_NAME",
          "createTime": "2024-07-10T17:18:54.935Z",
          "expirationTime": "2034-07-10T17:19:54.935Z"
        },
        {
          "kind": "sql#sslCert",
          "certSerialNumber": "CERT_SERIAL_NUMBER_CA_CERT_TWO",
          "cert": "CERT_VALUE",
          "commonName": "CA_SERVER_NAME",
          "sha1Fingerprint": "sha1Fingerprint_CA_CERT_TWO",
          "instance": "INSTANCE_NAME",
          "createTime": "2024-07-14T22:43:56.458Z",
          "expirationTime": "2034-11-11T22:44:56.458Z"
        }
      ],
      "serverCerts": [
      {
        "kind": "sql#sslCert",
        "certSerialNumber": "CERT_SERIAL_NUMBER_SERVER_CERT_ONE",
        "cert": "CERT_VALUE"
        "commonName": "SUBJECT_VALUE",
        "sha1Fingerprint": "sha1Fingerprint_SERVER_CERT_ONE",
        "instance": "INSTANCE_NAME",
        "createTime": "2024-09-16T18:11:39Z",
        "expirationTime": "2025-09-16T18:11:38Z"
      },
      {
        "kind": "sql#sslCert",
        "certSerialNumber": "CERT_SERIAL_NUMBER_SERVER_CERT_TWO",
        "cert": "CERT_VALUE"
        "commonName": "SUBJECT_VALUE",
        "sha1Fingerprint": "sha1Fingerprint_SERVER_CERT_TWO",
        "instance": "INSTANCE_NAME",
        "createTime": "2024-09-10T20:56:06Z",
        "expirationTime": "2025-09-10T20:56:05Z"
      }
    ],
      "activeVersion": "sha1Fingerprint_SERVER_CERT_TWO",
      "kind": "sql#instancesListServerCertificates"
    }
    ```

    </div>

3.  Complete the rotation.

    Before using any of the request data, make the following replacements:

    - `PROJECT_ID`: The project ID
    - `INSTANCE_ID`: The instance ID

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    POST https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/instances/INSTANCE_ID/rotateServerCertificate
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X POST \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         -H "Content-Type: application/json; charset=utf-8" \
         -d "" \
         "https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/instances/INSTANCE_ID/rotateServerCertificate"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method POST `
        -Headers $headers `
        -Uri "https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/instances/INSTANCE_ID/rotateServerCertificate" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a JSON response similar to the following:

    <div class="section expandable">

    #### Response

    <div>

    </div>

    ``` readonly
    {
      "kind": "sql#operation",
      "targetLink": "https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/instances/INSTANCE_ID",
      "status": "PENDING",
      "user": "user@example.com",
      "insertTime": "2024-09-20T21:30:35.667Z",
      "operationType": "UPDATE",
      "name": "operation-id",
      "targetId": "INSTANCE_ID",
      "selfLink": "https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/operations/operation-id",
      "targetProject": "PROJECT_ID"
    }
    ```

    </div>

</div>

<div class="section">

### REST v1beta4

1.  Create a server certificate.

    Before using any of the request data, make the following replacements:

    - `PROJECT_ID`: the project ID
    - `INSTANCE_ID`: the instance ID

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    POST https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/instances/INSTANCE_ID/addServerCertificate
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X POST \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         -H "Content-Type: application/json; charset=utf-8" \
         -d "" \
         "https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/instances/INSTANCE_ID/addServerCertificate"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method POST `
        -Headers $headers `
        -Uri "https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/instances/INSTANCE_ID/addServerCertificate" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a JSON response similar to the following:

    <div class="section expandable">

    #### Response

    <div>

    </div>

    ``` readonly
    {
      "kind": "sql#operation",
      "targetLink": "https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/instances/INSTANCE_ID",
      "status": "PENDING",
      "user": "user@example.com",
      "insertTime": "2024-01-20T21:30:35.667Z",
      "operationType": "UPDATE",
      "name": "OPERATION_ID",
      "targetId": "INSTANCE_ID",
      "selfLink": "https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/operations/OPERATION_ID",
      "targetProject": "PROJECT_ID"
    }
    ```

    </div>

2.  If you need to download server CA certificate information, then you can use the following command.

    Before using any of the request data, make the following replacements:

    - `PROJECT_ID`: the project ID
    - `INSTANCE_ID`: the instance ID

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    GET https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/instances/INSTANCE_ID/listServerCertificates
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X GET \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         "https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/instances/INSTANCE_ID/listServerCertificates"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method GET `
        -Headers $headers `
        -Uri "https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/instances/INSTANCE_ID/listServerCertificates" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a JSON response similar to the following:

    <div class="section expandable">

    #### Response

    <div>

    </div>

    ``` readonly
    {
      "caCerts": [
        {
          "kind": "sql#sslCert",
          "certSerialNumber": "CERT_SERIAL_NUMBER_CA_CERT_ONE",
          "cert": "CERT_VALUE",
          "commonName": "CA_SERVER_NAME",
          "sha1Fingerprint": "sha1Fingerprint_CA_CERT_ONE",
          "instance": "INSTANCE_NAME",
          "createTime": "2024-07-10T17:18:54.935Z",
          "expirationTime": "2034-07-10T17:19:54.935Z"
        },
        {
          "kind": "sql#sslCert",
          "certSerialNumber": "CERT_SERIAL_NUMBER_CA_CERT_TWO",
          "cert": "CERT_VALUE",
          "commonName": "CA_SERVER_NAME",
          "sha1Fingerprint": "sha1Fingerprint_CA_CERT_TWO",
          "instance": "INSTANCE_NAME",
          "createTime": "2024-07-14T22:43:56.458Z",
          "expirationTime": "2034-11-11T22:44:56.458Z"
        }
      ],
      "serverCerts": [
      {
        "kind": "sql#sslCert",
        "certSerialNumber": "CERT_SERIAL_NUMBER_SERVER_CERT_ONE",
        "cert": "CERT_VALUE"
        "commonName": "SUBJECT_VALUE",
        "sha1Fingerprint": "sha1Fingerprint_SERVER_CERT_ONE",
        "instance": "INSTANCE_NAME",
        "createTime": "2024-09-16T18:11:39Z",
        "expirationTime": "2025-09-16T18:11:38Z"
      },
      {
        "kind": "sql#sslCert",
        "certSerialNumber": "CERT_SERIAL_NUMBER_SERVER_CERT_TWO",
        "cert": "CERT_VALUE"
        "commonName": "SUBJECT_VALUE",
        "sha1Fingerprint": "sha1Fingerprint_SERVER_CERT_TWO",
        "instance": "INSTANCE_NAME",
        "createTime": "2024-09-10T20:56:06Z",
        "expirationTime": "2025-09-10T20:56:05Z"
      }
    ],
      "activeVersion": "sha1Fingerprint_SERVER_CERT_TWO",
      "kind": "sql#instancesListServerCertificates"
    }
    ```

    </div>

3.  Complete the rotation.

    Before using any of the request data, make the following replacements:

    - `PROJECT_ID`: the project ID
    - `INSTANCE_ID`: the instance ID

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    POST https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/instances/INSTANCE_ID/rotateServerCertificate
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X POST \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         -H "Content-Type: application/json; charset=utf-8" \
         -d "" \
         "https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/instances/INSTANCE_ID/rotateServerCertificate"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method POST `
        -Headers $headers `
        -Uri "https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/instances/INSTANCE_ID/rotateServerCertificate" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a JSON response similar to the following:

    <div class="section expandable">

    #### Response

    <div>

    </div>

    ``` readonly
    {
      "kind": "sql#operation",
      "targetLink": "https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/instances/INSTANCE_ID",
      "status": "PENDING",
      "user": "user@example.com",
      "insertTime": "2024-09-20T21:30:35.667Z",
      "operationType": "UPDATE",
      "name": "OPERATION_ID",
      "targetId": "INSTANCE_ID",
      "selfLink": "https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/operations/OPERATION_ID",
      "targetProject": "PROJECT_ID"
    }
    ```

    </div>

</div>

</div>

### Roll back a certificate rotation

After you complete a server certificate rotation, all your clients must use the new certificate to connect to your Cloud SQL instance. If the clients aren't updated properly to use the new certificate information, then they can't connect using SSL/TLS to your instance. If this happens, then you can roll back to the previous certificate configuration.

A rollback operation moves the active certificate into the "upcoming" slot, which replaces any "upcoming" certificate. The "previous" certificate becomes the active certificate and returns your certificate configuration to its previous state before you completed the rotation.

<div id="rollback-server-certs-cas" class="ds-selector-tabs" ds-scope="code-sample">

<div class="section">

### Console

1.  In the Google Cloud console, go to the **Cloud SQL Instances** page.

    <a href="https://console.cloud.google.com/sql" class="button button-primary" target="console">Go to Cloud SQL Instances</a>

2.  To open the **Overview** page of an instance, click the instance name.

3.  Select **Connections** from the SQL navigation menu.

4.  Select the **Security** tab.

5.  Click to expand **Manage certificates**.

6.  Select **Rollback server certificate**.

    If there are no eligible certificates, then the rollback option is unavailable.

7.  In the **Confirm certificate rollback** dialog, select **Rollback**.

    The rollback might take a few seconds to complete.

</div>

<div class="section">

### gcloud

<div>

</div>

``` devsite-click-to-copy
gcloud sql ssl server-certs rollback \
--instance=INSTANCE_NAME
   
```

</div>

<div class="section">

### REST v1

1.  List your server certificates.

    Before using any of the request data, make the following replacements:

    - `PROJECT_ID`: the project ID
    - `INSTANCE_ID`: the instance ID

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    GET https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/instances/INSTANCE_ID/listServerCertificates
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X GET \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         "https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/instances/INSTANCE_ID/listServerCertificates"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method GET `
        -Headers $headers `
        -Uri "https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/instances/INSTANCE_ID/listServerCertificates" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a JSON response similar to the following:

    <div class="section expandable">

    #### Response

    <div>

    </div>

    ``` readonly
    {
      "caCerts": [
        {
          "kind": "sql#sslCert",
          "certSerialNumber": "CERT_SERIAL_NUMBER_CA_CERT_ONE",
          "cert": "CERT_VALUE",
          "commonName": "CA_SERVER_NAME",
          "sha1Fingerprint": "sha1Fingerprint_CA_CERT_ONE",
          "instance": "INSTANCE_NAME",
          "createTime": "2024-07-10T17:18:54.935Z",
          "expirationTime": "2034-07-10T17:19:54.935Z"
        },
        {
          "kind": "sql#sslCert",
          "certSerialNumber": "CERT_SERIAL_NUMBER_CA_CERT_TWO",
          "cert": "CERT_VALUE",
          "commonName": "CA_SERVER_NAME",
          "sha1Fingerprint": "sha1Fingerprint_CA_CERT_TWO",
          "instance": "INSTANCE_NAME",
          "createTime": "2024-07-14T22:43:56.458Z",
          "expirationTime": "2034-11-11T22:44:56.458Z"
        }
      ],
      "serverCerts": [
      {
        "kind": "sql#sslCert",
        "certSerialNumber": "CERT_SERIAL_NUMBER_SERVER_CERT_ONE",
        "cert": "CERT_VALUE"
        "commonName": "SUBJECT_VALUE",
        "sha1Fingerprint": "sha1Fingerprint_SERVER_CERT_ONE",
        "instance": "INSTANCE_NAME",
        "createTime": "2024-09-16T18:11:39Z",
        "expirationTime": "2025-09-16T18:11:38Z"
      },
      {
        "kind": "sql#sslCert",
        "certSerialNumber": "CERT_SERIAL_NUMBER_SERVER_CERT_TWO",
        "cert": "CERT_VALUE"
        "commonName": "SUBJECT_VALUE",
        "sha1Fingerprint": "sha1Fingerprint_SERVER_CERT_TWO",
        "instance": "INSTANCE_NAME",
        "createTime": "2024-09-10T20:56:06Z",
        "expirationTime": "2025-09-10T20:56:05Z"
      }
    ],
      "activeVersion": "sha1Fingerprint_SERVER_CERT_TWO",
      "kind": "sql#instancesListServerCertificates"
    }
    ```

    </div>

2.  Copy the `sha1Fingerprint` field for the version you want to roll back to.

    Look for the version with a `createTime` value immediately earlier than the version with the `sha1Fingerprint` value shown as `activeVersion`.

3.  Roll back the rotation.

    Before using any of the request data, make the following replacements:

    - `PROJECT_ID`: the project ID
    - `INSTANCE_ID`: the instance ID

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    POST https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/instances/INSTANCE_ID/rotateServerCertificate
    ```

    </div>

    Request JSON body:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    {
      "rotateServerCertificateContext": {"nextVersion": "sha1Fingerprint"}
    }
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Save the request body in a file named `request.json`, and execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X POST \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         -H "Content-Type: application/json; charset=utf-8" \
         -d @request.json \
         "https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/instances/INSTANCE_ID/rotateServerCertificate"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Save the request body in a file named `request.json`, and execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method POST `
        -Headers $headers `
        -ContentType: "application/json; charset=utf-8" `
        -InFile request.json `
        -Uri "https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/instances/INSTANCE_ID/rotateServerCertificate" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a JSON response similar to the following:

    <div class="section expandable">

    #### Response

    <div>

    </div>

    ``` readonly
    {
      "kind": "sql#operation",
      "targetLink": "https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/instances/INSTANCE_ID",
      "status": "PENDING",
      "user": "user@example.com",
      "insertTime": "2020-01-20T21:30:35.667Z",
      "operationType": "UPDATE",
      "name": "OPERATION_ID",
      "targetId": "INSTANCE_ID",
      "selfLink": "https://sqladmin.googleapis.com/v1/projects/PROJECT_ID/operations/OPERATION_ID",
      "targetProject": "PROJECT_ID"
    }
    ```

    </div>

</div>

<div class="section">

### REST v1beta4

1.  List your server certificates.

    Before using any of the request data, make the following replacements:

    - `PROJECT_ID`: the project ID
    - `INSTANCE_ID`: the instance ID

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    GET https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/instances/INSTANCE_ID/listServerCertificates
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X GET \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         "https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/instances/INSTANCE_ID/listServerCertificates"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method GET `
        -Headers $headers `
        -Uri "https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/instances/INSTANCE_ID/listServerCertificates" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a JSON response similar to the following:

    <div class="section expandable">

    #### Response

    <div>

    </div>

    ``` readonly
    {
      "caCerts": [
        {
          "kind": "sql#sslCert",
          "certSerialNumber": "CERT_SERIAL_NUMBER_CA_CERT_ONE",
          "cert": "CERT_VALUE",
          "commonName": "CA_SERVER_NAME",
          "sha1Fingerprint": "sha1Fingerprint_CA_CERT_ONE",
          "instance": "INSTANCE_NAME",
          "createTime": "2024-07-10T17:18:54.935Z",
          "expirationTime": "2034-07-10T17:19:54.935Z"
        },
        {
          "kind": "sql#sslCert",
          "certSerialNumber": "CERT_SERIAL_NUMBER_CA_CERT_TWO",
          "cert": "CERT_VALUE",
          "commonName": "CA_SERVER_NAME",
          "sha1Fingerprint": "sha1Fingerprint_CA_CERT_TWO",
          "instance": "INSTANCE_NAME",
          "createTime": "2024-07-14T22:43:56.458Z",
          "expirationTime": "2034-11-11T22:44:56.458Z"
        }
      ],
      "serverCerts": [
      {
        "kind": "sql#sslCert",
        "certSerialNumber": "CERT_SERIAL_NUMBER_SERVER_CERT_ONE",
        "cert": "CERT_VALUE"
        "commonName": "SUBJECT_VALUE",
        "sha1Fingerprint": "sha1Fingerprint_SERVER_CERT_ONE",
        "instance": "INSTANCE_NAME",
        "createTime": "2024-09-16T18:11:39Z",
        "expirationTime": "2025-09-16T18:11:38Z"
      },
      {
        "kind": "sql#sslCert",
        "certSerialNumber": "CERT_SERIAL_NUMBER_SERVER_CERT_TWO",
        "cert": "CERT_VALUE"
        "commonName": "SUBJECT_VALUE",
        "sha1Fingerprint": "sha1Fingerprint_SERVER_CERT_TWO",
        "instance": "INSTANCE_NAME",
        "createTime": "2024-09-10T20:56:06Z",
        "expirationTime": "2025-09-10T20:56:05Z"
      }
    ],
      "activeVersion": "sha1Fingerprint_SERVER_CERT_TWO",
      "kind": "sql#instancesListServerCertificates"
    }
    ```

    </div>

2.  Copy the `sha1Fingerprint` field for the version you want to roll back to.

    Look for the version with a `createTime` value immediately earlier than the version with the `sha1Fingerprint` value shown as `activeVersion`.

3.  Roll back the rotation.

    Before using any of the request data, make the following replacements:

    - `PROJECT_ID`: the project ID
    - `INSTANCE_ID`: the instance ID

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    POST https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/instances/INSTANCE_ID/rotateServerCertificate
    ```

    </div>

    Request JSON body:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    {
      "rotateServerCertificateContext": {"nextVersion": "sha1Fingerprint"}
    }
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Save the request body in a file named `request.json`, and execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X POST \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         -H "Content-Type: application/json; charset=utf-8" \
         -d @request.json \
         "https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/instances/INSTANCE_ID/rotateServerCertificate"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Save the request body in a file named `request.json`, and execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method POST `
        -Headers $headers `
        -ContentType: "application/json; charset=utf-8" `
        -InFile request.json `
        -Uri "https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/instances/INSTANCE_ID/rotateServerCertificate" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a JSON response similar to the following:

    <div class="section expandable">

    #### Response

    <div>

    </div>

    ``` readonly
    {
      "kind": "sql#operation",
      "targetLink": "https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/instances/INSTANCE_ID",
      "status": "PENDING",
      "user": "user@example.com",
      "insertTime": "2020-01-20T21:30:35.667Z",
      "operationType": "UPDATE",
      "name": "OPERATION_ID",
      "targetId": "INSTANCE_ID",
      "selfLink": "https://sqladmin.googleapis.com/sql/v1beta4/projects/PROJECT_ID/operations/OPERATION_ID",
      "targetProject": "PROJECT_ID"
    }
    ```

    </div>

</div>

</div>

### View the content of CA certificates

You can use the `openssl storeutl` utility to view the content of CA certificates.

When you run the [sql ssl server-certs list](/sdk/gcloud/reference/sql/ssl/server-certs/list) command, you always get multiple CA certificates due to the trust chain. You might also get multiple CA certificates from previous rotation-related operations.

<div id="examine-ca-certs" class="ds-selector-tabs" ds-scope="code-sample">

<div class="section">

### gcloud

1.  Run the following command:

    <div>

    </div>

    ``` devsite-click-to-copy
    gcloud sql ssl server-certs list \
      --instance=INSTANCE_NAME \
      --format='value(ca_cert.cert)' > temp_cert.pem
    ```

    Replace `INSTANCE_NAME` with the name of the instance.

2.  Use `openssl` to examine the contents of the CA certificates.

</div>

</div>

### View the content of a server certificate

You can use `openssl` utilities and the [sql ssl server-certs list](/sdk/gcloud/reference/sql/ssl/server-certs/list) command to view the content of a server certificate.

When you run the [gcloud CLI](/sdk/gcloud) command, you always get multiple CA certificates due to the trust chain. You also might get multiple CA certificates from previous rotation-related operations.

<div id="examine-server-certs-cas" class="ds-selector-tabs" ds-scope="code-sample">

<div class="section">

### gcloud

**Using `openssl s_client` only**:

<div>

</div>

``` devsite-click-to-copy
openssl s_client -starttls postgres -connect INSTANCE_IP_ADDRESS:5432
```

Replace `INSTANCE_IP_ADDRESS` with the IP address of the instance.

**Using the [`gcloud CLI`](/sdk/gcloud) and `openssl storeutl`**:

1.  Run the following command:

    <div>

    </div>

    ``` devsite-click-to-copy
    gcloud sql ssl server-certs list \
      --instance=INSTANCE_NAME \
      --format='value(ssl_cert.cert)' > temp_cert.pem
    ```

    Replace `INSTANCE_NAME` with the name of the instance.

2.  Use `openssl` to examine the contents of the server certificates.

</div>

</div>

### Download root and regional CA certificate bundles for a shared CA

If you're using a Google-managed shared CA configuration, then you can download the root and regional CA certificate bundles from the following table.

These certificate bundles don't apply to instances that use the per-instance or customer-managed CA options.

|                   | Region name               | Location          | Certificate bundle                                                                                                                                                              |
|-------------------|---------------------------|-------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| **Global**        |                           |                   |                                                                                                                                                                                 |
|                   | CA for all regions        | All locations     | <a href="https://storage.googleapis.com/cloudsql-ca-bundles/global.pem" class="download"><code translate="no" dir="ltr">global.pem</code></a>                                   |
| **Asia**          |                           |                   |                                                                                                                                                                                 |
|                   | `asia-east1`              | Taiwan            | <a href="https://storage.googleapis.com/cloudsql-ca-bundles/asia-east1.pem" class="download"><code translate="no" dir="ltr">asia-east1.pem</code></a>                           |
|                   | `asia-east2`              | Hong Kong         | <a href="https://storage.googleapis.com/cloudsql-ca-bundles/asia-east2.pem" class="download"><code translate="no" dir="ltr">asia-east2.pem</code></a>                           |
|                   | `asia-northeast1`         | Tokyo             | <a href="https://storage.googleapis.com/cloudsql-ca-bundles/asia-northeast1.pem" class="download"><code translate="no" dir="ltr">asia-northeast1.pem</code></a>                 |
|                   | `asia-northeast2`         | Osaka             | <a href="https://storage.googleapis.com/cloudsql-ca-bundles/asia-northeast2.pem" class="download"><code translate="no" dir="ltr">asia-northeast2.pem</code></a>                 |
|                   | `asia-northeast3`         | Seoul             | <a href="https://storage.googleapis.com/cloudsql-ca-bundles/asia-northeast3.pem" class="download"><code translate="no" dir="ltr">asia-northeast3.pem</code></a>                 |
|                   | `asia-south1`             | Mumbai            | <a href="https://storage.googleapis.com/cloudsql-ca-bundles/asia-south1.pem" class="download"><code translate="no" dir="ltr">asia-south1.pem</code></a>                         |
|                   | `asia-south2`             | Delhi             | <a href="https://storage.googleapis.com/cloudsql-ca-bundles/asia-south2.pem" class="download"><code translate="no" dir="ltr">asia-south2.pem</code></a>                         |
|                   | `asia-southeast1`         | Singapore         | <a href="https://storage.googleapis.com/cloudsql-ca-bundles/asia-southeast1.pem" class="download"><code translate="no" dir="ltr">asia-southeast1.pem</code></a>                 |
|                   | `asia-southeast2`         | Jakarta           | <a href="https://storage.googleapis.com/cloudsql-ca-bundles/asia-southeast2.pem" class="download"><code translate="no" dir="ltr">asia-southeast2.pem</code></a>                 |
|                   | `asia-southeast3`         | Bangkok           | <a href="https://storage.googleapis.com/cloudsql-ca-bundles/asia-southeast3.pem" class="download"><code translate="no" dir="ltr">asia-southeast3.pem</code></a>                 |
| **Africa**        |                           |                   |                                                                                                                                                                                 |
|                   | `africa-south1`           | Johannesburg      | <a href="https://storage.googleapis.com/cloudsql-ca-bundles/africa-south1.pem" class="download"><code translate="no" dir="ltr">africa-south1.pem</code></a>                     |
| **Australia**     |                           |                   |                                                                                                                                                                                 |
|                   | `australia-southeast1`    | Sydney            | <a href="https://storage.googleapis.com/cloudsql-ca-bundles/australia-southeast1.pem" class="download"><code translate="no" dir="ltr">australia-southeast1.pem</code></a>       |
|                   | `australia-southeast2`    | Melbourne         | <a href="https://storage.googleapis.com/cloudsql-ca-bundles/australia-southeast2.pem" class="download"><code translate="no" dir="ltr">australia-southeast2.pem</code></a>       |
| **Europe**        |                           |                   |                                                                                                                                                                                 |
|                   | `europe-central2`         | Warsaw            | <a href="https://storage.googleapis.com/cloudsql-ca-bundles/europe-central2.pem" class="download"><code translate="no" dir="ltr">europe-central2.pem</code></a>                 |
|                   | `europe-north1`           | Finland           | <a href="https://storage.googleapis.com/cloudsql-ca-bundles/europe-north1.pem" class="download"><code translate="no" dir="ltr">europe-north1.pem</code></a>                     |
|                   | `europe-north2`           | Stockholm         | <a href="https://storage.googleapis.com/cloudsql-ca-bundles/europe-north2.pem" class="download"><code translate="no" dir="ltr">europe-north2.pem</code></a>                     |
|                   | `europe-southwest1`       | Madrid            | <a href="https://storage.googleapis.com/cloudsql-ca-bundles/europe-southwest1.pem" class="download"><code translate="no" dir="ltr">europe-southwest1.pem</code></a>             |
|                   | `europe-west1`            | Belgium           | <a href="https://storage.googleapis.com/cloudsql-ca-bundles/europe-west1.pem" class="download"><code translate="no" dir="ltr">europe-west1.pem</code></a>                       |
|                   | `europe-west2`            | London            | <a href="https://storage.googleapis.com/cloudsql-ca-bundles/europe-west2.pem" class="download"><code translate="no" dir="ltr">europe-west2.pem</code></a>                       |
|                   | `europe-west3`            | Frankfurt         | <a href="https://storage.googleapis.com/cloudsql-ca-bundles/europe-west3.pem" class="download"><code translate="no" dir="ltr">europe-west3.pem</code></a>                       |
|                   | `europe-west4`            | Netherlands       | <a href="https://storage.googleapis.com/cloudsql-ca-bundles/europe-west4.pem" class="download"><code translate="no" dir="ltr">europe-west4.pem</code></a>                       |
|                   | `europe-west6`            | Zürich            | <a href="https://storage.googleapis.com/cloudsql-ca-bundles/europe-west6.pem" class="download"><code translate="no" dir="ltr">europe-west6.pem</code></a>                       |
|                   | `europe-west8`            | Milan             | <a href="https://storage.googleapis.com/cloudsql-ca-bundles/europe-west8.pem" class="download"><code translate="no" dir="ltr">europe-west8.pem</code></a>                       |
|                   | `europe-west9`            | Paris             | <a href="https://storage.googleapis.com/cloudsql-ca-bundles/europe-west9.pem" class="download"><code translate="no" dir="ltr">europe-west9.pem</code></a>                       |
|                   | `europe-west10`           | Berlin            | <a href="https://storage.googleapis.com/cloudsql-ca-bundles/europe-west10.pem" class="download"><code translate="no" dir="ltr">europe-west10.pem</code></a>                     |
|                   | `europe-west12`           | Turin             | <a href="https://storage.googleapis.com/cloudsql-ca-bundles/europe-west12.pem" class="download"><code translate="no" dir="ltr">europe-west12.pem</code></a>                     |
| **Middle East**   |                           |                   |                                                                                                                                                                                 |
|                   | `me-central1`             | Doha              | <a href="https://storage.googleapis.com/cloudsql-ca-bundles/me-central1.pem" class="download"><code translate="no" dir="ltr">me-central1.pem</code></a>                         |
|                   | `me-central2`             | Dammam            | <a href="https://storage.googleapis.com/cloudsql-ca-bundles/me-central2.pem" class="download"><code translate="no" dir="ltr">me-central2.pem</code></a>                         |
|                   | `me-west1`                | Tel Aviv          | <a href="https://storage.googleapis.com/cloudsql-ca-bundles/me-west1.pem" class="download"><code translate="no" dir="ltr">me-west1.pem</code></a>                               |
| **North America** |                           |                   |                                                                                                                                                                                 |
|                   | `northamerica-northeast1` | Montréal          | <a href="https://storage.googleapis.com/cloudsql-ca-bundles/northamerica-northeast1.pem" class="download"><code translate="no" dir="ltr">northamerica-northeast1.pem</code></a> |
|                   | `northamerica-northeast2` | Toronto           | <a href="https://storage.googleapis.com/cloudsql-ca-bundles/northamerica-northeast2.pem" class="download"><code translate="no" dir="ltr">northamerica-northeast2.pem</code></a> |
|                   | `northamerica-south1`     | Mexico            | <a href="https://storage.googleapis.com/cloudsql-ca-bundles/northamerica-south1.pem" class="download"><code translate="no" dir="ltr">northamerica-south1.pem</code></a>         |
|                   | `us-central1`             | Iowa              | <a href="https://storage.googleapis.com/cloudsql-ca-bundles/us-central1.pem" class="download"><code translate="no" dir="ltr">us-central1.pem</code></a>                         |
|                   | `us-east1`                | South Carolina    | <a href="https://storage.googleapis.com/cloudsql-ca-bundles/us-east1.pem" class="download"><code translate="no" dir="ltr">us-east1.pem</code></a>                               |
|                   | `us-east4`                | Northern Virginia | <a href="https://storage.googleapis.com/cloudsql-ca-bundles/us-east4.pem" class="download"><code translate="no" dir="ltr">us-east4.pem</code></a>                               |
|                   | `us-east5`                | Columbus          | <a href="https://storage.googleapis.com/cloudsql-ca-bundles/us-east5.pem" class="download"><code translate="no" dir="ltr">us-east5.pem</code></a>                               |
|                   | `us-south1`               | Dallas            | <a href="https://storage.googleapis.com/cloudsql-ca-bundles/us-south1.pem" class="download"><code translate="no" dir="ltr">us-south1.pem</code></a>                             |
|                   | `us-west1`                | Oregon            | <a href="https://storage.googleapis.com/cloudsql-ca-bundles/us-west1.pem" class="download"><code translate="no" dir="ltr">us-west1.pem</code></a>                               |
|                   | `us-west2`                | Los Angeles       | <a href="https://storage.googleapis.com/cloudsql-ca-bundles/us-west2.pem" class="download"><code translate="no" dir="ltr">us-west2.pem</code></a>                               |
|                   | `us-west3`                | Salt Lake City    | <a href="https://storage.googleapis.com/cloudsql-ca-bundles/us-west3.pem" class="download"><code translate="no" dir="ltr">us-west3.pem</code></a>                               |
|                   | `us-west4`                | Las Vegas         | <a href="https://storage.googleapis.com/cloudsql-ca-bundles/us-west4.pem" class="download"><code translate="no" dir="ltr">us-west4.pem</code></a>                               |
| **South America** |                           |                   |                                                                                                                                                                                 |
|                   | `southamerica-east1`      | São Paulo         | <a href="https://storage.googleapis.com/cloudsql-ca-bundles/southamerica-east1.pem" class="download"><code translate="no" dir="ltr">southamerica-east1.pem</code></a>           |
|                   | `southamerica-west1`      | Santiago          | <a href="https://storage.googleapis.com/cloudsql-ca-bundles/southamerica-west1.pem" class="download"><code translate="no" dir="ltr">southamerica-west1.pem</code></a>           |

## Reset the SSL/TLS configuration

You can completely reset your SSL/TLS configuration.

**Caution:** Performing this action removes the ability to connect to your instance using SSL/TLS until you create new client certificates to replace any that were previously in use.

<div id="refresh-server-cert" class="ds-selector-tabs" ds-scope="code-sample">

<div class="section">

### Console

1.  In the Google Cloud console, go to the **Cloud SQL Instances** page.

    <a href="https://console.cloud.google.com/sql" class="button button-primary" target="console">Go to Cloud SQL Instances</a>

2.  To open the **Overview** page of an instance, click the instance name.

3.  Select **Connections** from the SQL navigation menu.

4.  Go to the **Reset SSL configuration** section.

5.  Click **Reset SSL Configuration**.

</div>

<div class="section">

### gcloud

1.  Refresh the certificate:

    <div>

    </div>

    ``` devsite-click-to-copy
    gcloud sql instances reset-ssl-config INSTANCE_NAME
    ```

2.  [Create new client certificates](/sql/docs/postgres/configure-ssl-instance#new-client).

</div>

<div class="section">

### REST v1beta4

1.  Refresh the certificate:

    Before using any of the request data, make the following replacements:

    - `project-id`: The project ID
    - `instance-id`: The instance ID

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    POST https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id/resetSslConfig
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X POST \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         -H "Content-Type: application/json; charset=utf-8" \
         -d "" \
         "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id/resetSslConfig"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method POST `
        -Headers $headers `
        -Uri "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id/resetSslConfig" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a JSON response similar to the following:

    <div class="section expandable">

    #### Response

    <div>

    </div>

    ``` readonly
    {
      "kind": "sql#operation",
      "targetLink": "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id",
      "status": "PENDING",
      "user": "user@example.com",
      "insertTime": "2020-01-20T21:30:35.667Z",
      "operationType": "UPDATE",
      "name": "operation-id",
      "targetId": "instance-id",
      "selfLink": "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/operations/operation-id",
      "targetProject": "project-id"
    }
    ```

    </div>

2.  [Create new client certificates](/sql/docs/postgres/configure-ssl-instance#new-client).

</div>

</div>

## What's next

- Learn more about [SSL/TLS in Cloud SQL](/sql/docs/postgres/authorize-ssl).
- [Configure SSL/TLS](/sql/docs/postgres/configure-ssl-instance) on your Cloud SQL instance.
- [Connect using SSL/TLS](/sql/docs/postgres/connect-admin-ip#connect-ssl) to your Cloud SQL instance.
- Learn more about <a href="https://www.postgresql.org/docs/current/static/libpq-ssl.html" target="_blank">how PostgreSQL uses SSL/TLS</a>.
- View all the [Google Cloud services available in locations worldwide](https://cloud.google.com/about/locations).

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
