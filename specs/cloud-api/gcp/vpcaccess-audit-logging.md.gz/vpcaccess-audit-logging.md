# Serverless VPC Access audit logging

<div class="devsite-article-body clearfix devsite-no-page-title">

# Serverless VPC Access audit logging

**Preview**

This product or feature is subject to the "Pre-GA Offerings Terms" in the General Service Terms section of the <a href="/terms/service-terms#1" data-track-type="commonIncludes">Service Specific Terms</a>. Pre-GA products and features are available "as is" and might have limited support. For more information, see the <a href="https://cloud.google.com/products/#product-launch-stages" data-track-type="commonIncludes">launch stage descriptions</a>.

Cloud Audit Logs for Serverless VPC Access let you track administrative and data-access operations on your resources to help you monitor access and configuration changes. You can query these logs in the Logs Explorer and check which Serverless VPC Access API methods generate Cloud Audit Logs.

For more information about Cloud Audit Logs, see the following documents:

- [Types of audit logs](/logging/docs/audit#types)
- [Audit log entry structure](/logging/docs/audit#audit_log_entry_structure)
- [Storing and routing audit logs](/logging/docs/audit#storing_and_routing_audit_logs)
- [Cloud Logging pricing summary](/stackdriver/pricing#logs-pricing-summary)
- [Enable Data Access audit logs](/logging/docs/audit/configure-data-access)

## Service name

To view the Serverless VPC Access audit logs, do the following:

1.  In the Google Cloud console, go to the Logs Explorer page:

    <a href="https://console.cloud.google.com/logs/query" class="button button-primary" target="console" data-track-name="consoleLink" data-track-type="reference" data-track-metadata-position="body">Go to Logs Explorer</a>

2.  Copy and paste the following query into the **Query** field of the Logs Explorer, and then click **Run query**.

    <div>

    </div>

    ``` devsite-click-to-copy
        protoPayload.serviceName="vpcaccess.googleapis.com"
      
    ```

## Methods by permission type

Each IAM permission has a `type` property, whose value is an enum that can be one of four values: `ADMIN_READ`, `ADMIN_WRITE`, `DATA_READ`, or `DATA_WRITE`. When you call a method, Serverless VPC Access generates an audit log whose category is dependent on the `type` property of the permission required to perform the method. Methods that require an IAM permission with the `type` property value of `DATA_READ`, `DATA_WRITE`, or `ADMIN_READ` generate [Data Access](/logging/docs/audit#data-access) audit logs. Methods that require an IAM permission with the `type` property value of `ADMIN_WRITE` generate [Admin Activity](/logging/docs/audit#admin-activity) audit logs.

API methods in the following list that are marked with (LRO) are long-running operations (LROs). These methods usually generate two audit log entries: one when the operation starts and another when it ends. For more information see [Audit logs for long-running operations](/logging/docs/audit/understanding-audit-logs#lro).

<table class="fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="15%">Permission type</th>
<th>Methods</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td><code translate="no" dir="ltr">ADMIN_READ</code></td>
<td><code translate="no" dir="ltr">google.cloud.vpcaccess.v1.VpcAccessService.GetConnector</code><br />
<code translate="no" dir="ltr">google.cloud.vpcaccess.v1.VpcAccessService.ListConnectors</code><br />
<code translate="no" dir="ltr">google.cloud.vpcaccess.v1beta1.VpcAccessService.GetConnector</code><br />
<code translate="no" dir="ltr">google.cloud.vpcaccess.v1beta1.VpcAccessService.ListConnectors</code><br />
<code translate="no" dir="ltr">google.longrunning.Operations.GetOperation</code><br />
<code translate="no" dir="ltr">google.longrunning.Operations.ListOperations</code></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">ADMIN_WRITE</code></td>
<td><code translate="no" dir="ltr">google.cloud.vpcaccess.v1.VpcAccessService.CreateConnector</code> (LRO)<br />
<code translate="no" dir="ltr">google.cloud.vpcaccess.v1.VpcAccessService.DeleteConnector</code> (LRO)<br />
<code translate="no" dir="ltr">google.cloud.vpcaccess.v1.VpcAccessService.UpdateConnector</code> (LRO)<br />
<code translate="no" dir="ltr">google.cloud.vpcaccess.v1beta1.VpcAccessService.CreateConnector</code> (LRO)<br />
<code translate="no" dir="ltr">google.cloud.vpcaccess.v1beta1.VpcAccessService.DeleteConnector</code> (LRO)<br />
<code translate="no" dir="ltr">google.cloud.vpcaccess.v1beta1.VpcAccessService.UpdateConnector</code> (LRO)</td>
</tr>
</tbody>
</table>

## API interface audit logs

For information about how and which permissions are evaluated for each method, see the Identity and Access Management documentation for Serverless VPC Access.

### `google.cloud.vpcaccess.v1.VpcAccessService`

The following audit logs are associated with methods belonging to `google.cloud.vpcaccess.v1.VpcAccessService`.

#### `CreateConnector`

- **Method**: `google.cloud.vpcaccess.v1.VpcAccessService.CreateConnector`  
- **Audit log type**: [Admin activity](/logging/docs/audit#admin-activity)  
- **Permissions**:
  - `vpcaccess.connectors.create - ADMIN_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="google.cloud.vpcaccess.v1.VpcAccessService.CreateConnector" `  

#### `DeleteConnector`

- **Method**: `google.cloud.vpcaccess.v1.VpcAccessService.DeleteConnector`  
- **Audit log type**: [Admin activity](/logging/docs/audit#admin-activity)  
- **Permissions**:
  - `vpcaccess.connectors.delete - ADMIN_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="google.cloud.vpcaccess.v1.VpcAccessService.DeleteConnector" `  

#### `GetConnector`

- **Method**: `google.cloud.vpcaccess.v1.VpcAccessService.GetConnector`  
- **Audit log type**: [Data access](/logging/docs/audit#data-access)  
- **Permissions**:
  - `vpcaccess.connectors.get - ADMIN_READ`
- **Method is a long-running or streaming operation**: No.  
- **Filter for this method**: ` protoPayload.methodName="google.cloud.vpcaccess.v1.VpcAccessService.GetConnector" `  

#### `ListConnectors`

- **Method**: `google.cloud.vpcaccess.v1.VpcAccessService.ListConnectors`  
- **Audit log type**: [Data access](/logging/docs/audit#data-access)  
- **Permissions**:
  - `vpcaccess.connectors.list - ADMIN_READ`
- **Method is a long-running or streaming operation**: No.  
- **Filter for this method**: ` protoPayload.methodName="google.cloud.vpcaccess.v1.VpcAccessService.ListConnectors" `  

#### `UpdateConnector`

- **Method**: `google.cloud.vpcaccess.v1.VpcAccessService.UpdateConnector`  
- **Audit log type**: [Admin activity](/logging/docs/audit#admin-activity)  
- **Permissions**:
  - `vpcaccess.connectors.update - ADMIN_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="google.cloud.vpcaccess.v1.VpcAccessService.UpdateConnector" `  

### `google.cloud.vpcaccess.v1beta1.VpcAccessService`

The following audit logs are associated with methods belonging to `google.cloud.vpcaccess.v1beta1.VpcAccessService`.

#### `CreateConnector`

- **Method**: `google.cloud.vpcaccess.v1beta1.VpcAccessService.CreateConnector`  
- **Audit log type**: [Admin activity](/logging/docs/audit#admin-activity)  
- **Permissions**:
  - `vpcaccess.connectors.create - ADMIN_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="google.cloud.vpcaccess.v1beta1.VpcAccessService.CreateConnector" `  

#### `DeleteConnector`

- **Method**: `google.cloud.vpcaccess.v1beta1.VpcAccessService.DeleteConnector`  
- **Audit log type**: [Admin activity](/logging/docs/audit#admin-activity)  
- **Permissions**:
  - `vpcaccess.connectors.delete - ADMIN_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="google.cloud.vpcaccess.v1beta1.VpcAccessService.DeleteConnector" `  

#### `GetConnector`

- **Method**: `google.cloud.vpcaccess.v1beta1.VpcAccessService.GetConnector`  
- **Audit log type**: [Data access](/logging/docs/audit#data-access)  
- **Permissions**:
  - `vpcaccess.connectors.get - ADMIN_READ`
- **Method is a long-running or streaming operation**: No.  
- **Filter for this method**: ` protoPayload.methodName="google.cloud.vpcaccess.v1beta1.VpcAccessService.GetConnector" `  

#### `ListConnectors`

- **Method**: `google.cloud.vpcaccess.v1beta1.VpcAccessService.ListConnectors`  
- **Audit log type**: [Data access](/logging/docs/audit#data-access)  
- **Permissions**:
  - `vpcaccess.connectors.list - ADMIN_READ`
- **Method is a long-running or streaming operation**: No.  
- **Filter for this method**: ` protoPayload.methodName="google.cloud.vpcaccess.v1beta1.VpcAccessService.ListConnectors" `  

#### `UpdateConnector`

- **Method**: `google.cloud.vpcaccess.v1beta1.VpcAccessService.UpdateConnector`  
- **Audit log type**: [Admin activity](/logging/docs/audit#admin-activity)  
- **Permissions**:
  - `vpcaccess.connectors.update - ADMIN_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="google.cloud.vpcaccess.v1beta1.VpcAccessService.UpdateConnector" `  

### `google.longrunning.Operations`

The following audit logs are associated with methods belonging to `google.longrunning.Operations`.

#### `GetOperation`

- **Method**: `google.longrunning.Operations.GetOperation`  
- **Audit log type**: [Data access](/logging/docs/audit#data-access)  
- **Permissions**:
  - `vpcaccess.operations.get - ADMIN_READ`
- **Method is a long-running or streaming operation**: No.  
- **Filter for this method**: ` protoPayload.methodName="google.longrunning.Operations.GetOperation" `  

#### `ListOperations`

- **Method**: `google.longrunning.Operations.ListOperations`  
- **Audit log type**: [Data access](/logging/docs/audit#data-access)  
- **Permissions**:
  - `vpcaccess.operations.list - ADMIN_READ`
- **Method is a long-running or streaming operation**: No.  
- **Filter for this method**: ` protoPayload.methodName="google.longrunning.Operations.ListOperations" `  

## Methods that don't produce audit logs

A method might not produce audit logs for one or more of the following reasons:

- It is a high volume method involving significant log generation and storage costs.
- It has low auditing value.
- Another audit or platform log already provides method coverage.

The following methods don't produce audit logs:

- `google.cloud.vpcaccess.v1alpha1.VpcAccessService.HeartbeatConnector`

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
