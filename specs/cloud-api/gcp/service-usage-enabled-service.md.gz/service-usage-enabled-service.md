# Enabled services

<div class="devsite-article-body clearfix devsite-no-page-title">

# Enabled services

To use most Google Cloud APIs and services, you must first enable them in a Google Cloud project. Enabling APIs and services in a Google Cloud project results in the following changes:

- Associates them with the project.
- Adds monitoring pages in the Google Cloud console.
- Enables billing for the APIs and services if billing is enabled for the project.
- In some cases, [Identity and Access Management (IAM)](/iam) roles only become visible when you enable the associated service.

## Calling a service

The typical high-level requirements for using Google Cloud APIs and services are the following:

1.  You should have a Google Cloud project. For details on creating a Google Cloud project, see [Create projects](/resource-manager/docs/creating-managing-projects).

2.  You should enable the API or service for the project. To learn how to enable APIs and services, see [Enable and disable services](/service-usage/docs/enable-disable).

3.  You should have authentication credentials for the service you enabled. To learn how to authenticate to a [Google Cloud API](/apis), see [Authentication for Google Cloud APIs and services](/docs/authentication).

The credentials you use to call Google Cloud APIs and services are associated with the project you use to create them.

## IAM role visibility

Some IAM roles are only visible if the associated service is enabled in a Google Cloud project. For example, the `roles/compute.admin` role is only visible after the `compute.googleapis.com` API is enabled in a project. To learn how to list the available roles to grant in a project, see [Viewing the grantable roles on resources](/iam/docs/viewing-grantable-roles).

## Services enabled by default

When you create a Google Cloud project using the Google Cloud console or Google Cloud CLI, the following APIs and services are enabled by default:

**Note:** You can disable any of the following services, just like any other service you enable.

| Service name                                                                              | API endpoint                                                                                         |
|-------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------|
| [App Topology API](/app-topology)                                                         | `apptopology.googleapis.com`                                                                         |
| [BigQuery sharing (formerly Analytics Hub)](/bigquery/docs/analytics-hub-introduction)    | [`analyticshub.googleapis.com`](/bigquery/docs/reference/analytics-hub/rest)                         |
| [BigQuery API](/bigquery)                                                                 | [`bigquery.googleapis.com`](/bigquery/docs/reference/rest)                                           |
| [BigQuery Connection API](/bigquery/docs/connections-api-intro)                           | [`bigqueryconnection.googleapis.com`](/bigquery/docs/reference/bigqueryconnection/rest)              |
| BigQuery Data Policy API                                                                  | [`bigquerydatapolicy.googleapis.com`](/bigquery/docs/reference/bigquerydatapolicy/rest)              |
| [BigQuery Data Transfer Service](/bigquery/docs/dts-introduction)                         | [`bigquerydatatransfer.googleapis.com`](/bigquery/docs/reference/datatransfer/rest)                  |
| [BigQuery Migration API](/bigquery/docs/migration-intro)                                  | [`bigquerymigration.googleapis.com`](/bigquery/docs/reference/migration/rest)                        |
| BigQuery Reservation API                                                                  | [`bigqueryreservation.googleapis.com`](/bigquery/docs/reference/reservations/rest)                   |
| [BigQuery Storage API](/bigquery/docs/storage_overview)                                   | [`bigquerystorage.googleapis.com`](/bigquery/docs/reference/storage/rpc)                             |
| [Cloud Dataform API](/dataform)                                                           | [`dataform.googleapis.com`](/dataform/reference/rest)                                                |
| [Cloud Dataplex API](/dataplex)                                                           | [`dataplex.googleapis.com`](/dataplex/docs/reference/rest)                                           |
| [Cloud Datastore API](/datastore)                                                         | [`datastore.googleapis.com`](/datastore/docs/reference/data/rest)                                    |
| [Cloud Logging API](/logging)                                                             | [`logging.googleapis.com`](/logging/docs/reference/api-overview)                                     |
| [Cloud Monitoring API](/monitoring)                                                       | [`monitoring.googleapis.com`](/monitoring/api/v3)                                                    |
| [Cloud SQL](/sql)                                                                         | `sql-component.googleapis.com`                                                                       |
| [Cloud Storage](/storage)                                                                 | `storage-component.googleapis.com`                                                                   |
| [Cloud Storage API](/storage)                                                             | [`storage.googleapis.com`](/storage/docs/json_api/v1)                                                |
| [Cloud Trace API](/trace)                                                                 | [`cloudtrace.googleapis.com`](/trace/docs/reference/v1/rest)                                         |
| [Google Cloud APIs](/apis/docs/overview)                                                  | `cloudapis.googleapis.com`                                                                           |
| [Google Cloud Storage JSON API](/storage)                                                 | `storage-api.googleapis.com`                                                                         |
| [Service Management API](/service-infrastructure/docs/service-management/getting-started) | [`servicemanagement.googleapis.com`](/service-infrastructure/docs/service-management/reference/rest) |
| [Service Usage API](/service-usage)                                                       | [`serviceusage.googleapis.com`](/service-usage/docs/reference/rest)                                  |
| Telemetry API                                                                             | [`telemetry.googleapis.com`](/stackdriver/docs/reference/telemetry/overview)                         |

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
