# Predefined metadata keys

<div class="devsite-article-body clearfix">

<div id="tags" class="nocontent">

<span class="devsite-label" data-title="" track-type="docChip" track-name="Linux"> Linux </span> <span class="devsite-label" data-title="" track-type="docChip" track-name="Windows"> Windows </span>

</div>

Predefined metadata keys and their values provide instance and project information. You can use these keys to control various instance behaviors.

When you create a new compute instance, Compute Engine automatically creates these keys for your instance on the metadata server. Compute Engine also automatically populates values for some predefined keys, such as the instance ID or project ID. For other keys, you set values to enable or disable features. For example, to activate OS login for an instance, set the `enable-oslogin` key to `TRUE`.

You can update the values of these predefined keys; key values are case-sensitive. However, you cannot modify the keys themselves. When you understand the metadata keys that are in your `instance/` and `project/` metadata directories, you can optimize instance performance, troubleshoot configurations, and maintain a reliable compute environment.

For information about how VM metadata for Compute Engine is defined, categorized, and arranged, see [About VM metadata](/compute/docs/metadata/overview).

## Predefined project metadata keys

Predefined metadata keys for project metadata are stored under the following directory:

- `http://metadata.google.internal/computeMetadata/v1/project/`

The following table provides a list of metadata keys and directories that Compute Engine automatically creates in the `project/` metadata directory:

<table data-cellspacing="0" data-cellpadding="0">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="20%">Metadata entry</th>
<th>Description</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td><code translate="no" dir="ltr">attributes/</code></td>
<td><p>A directory of custom metadata values passed to the VMs in your project during startup or shutdown. These custom values can either be Google Cloud attributes or user-created metadata values.</p>
<p>For a list of project-level Google Cloud attributes that you can set, see <a href="#project-attributes-metadata">Project attributes</a>.</p>
<p>For more information about setting custom metadata, see <a href="/compute/docs/metadata/setting-custom-metadata">Set custom metadata</a>.</p></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">numeric-project-id</code></td>
<td>The <a href="/resource-manager/docs/creating-managing-projects#identifying_projects">numeric project ID (project number)</a> of the instance, which is not the same as the project name that is visible in the <a href="https://console.cloud.google.com/" target="console" data-track-type="inline link" referrerpolicy="no-referrer-when-downgrade">Google Cloud console</a>. This value is different from the <code translate="no" dir="ltr">project-id</code> metadata entry value.</td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">project-id</code></td>
<td>The <a href="/resource-manager/docs/creating-managing-projects#identifying_projects">project ID</a>.</td>
</tr>
</tbody>
</table>

### Predefined project attribute metadata keys

Predefined metadata keys for project attributes are stored under the following directory:

- `http://metadata.google.internal/computeMetadata/v1/project/attributes/`

The following table provides a list of metadata keys that, if set for your project, Compute Engine creates in the `project/attributes/` metadata directory, along with its associated effect:

<table data-cellspacing="0" data-cellpadding="0">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="25%">Metadata entry</th>
<th>Description</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td><code translate="no" dir="ltr">disable-legacy-endpoints</code></td>
<td><p>Disables legacy metadata server endpoints for all VMs in your project.</p>
<p>Legacy endpoints are deprecated, always set <code translate="no" dir="ltr">disable-legacy-endpoints=TRUE</code>.</p></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">enable-guest-attributes</code></td>
<td><p>Sets guest attributes for the project.</p>
<p>Guest attributes are custom VM instance metadata values that you can use to publish infrequent status notifications, low volume data, or low frequency data. These values are useful for indicating when startup scripts have finished or for providing other infrequent status notifications to other applications.</p>
<strong>Note:</strong> Any user or process on your VM instance can read and write to the namespaces and keys in <code translate="no" dir="ltr">guest-attributes</code> metadata.
<p>For more information about guest attributes, see <a href="/compute/docs/metadata/manage-guest-attributes">Set and query guest attributes</a>.</p></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">enable-os-inventory</code></td>
<td><p>Enables or disables OS inventory for the project.</p>
<p>Collects and stores OS information. This includes information such as hostname, kernel version, architecture, and installed packages.</p>
<p>For more information about OS inventory, see <a href="/compute/docs/instances/view-os-details">View operating system details</a>.</p></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">enable-osconfig</code></td>
<td><p>Enables or disables VM Manager for the project.</p>
<p>Setting <code translate="no" dir="ltr">enable-osconfig</code> to <code translate="no" dir="ltr">TRUE</code> enables Patch, OS policies, and OS inventory management.</p>
<p>For more information about enabling VM Manager, see <a href="/compute/vm-manager/docs/setup#enable-metadata">Set the metadata values</a>.</p></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">osconfig-poll-interval</code></td>
<td><p>Configures the OS inventory scan interval, in minutes, for the project.</p>
<p>By default, the OS Config agent runs an inventory scan on each VM every 10 minutes.</p>
<p>For more information about configuring the scan interval, see <a href="/compute/vm-manager/docs/os-inventory/view-os-details#configure-scan-interval">Configure the OS inventory scan interval</a>.</p></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">enable-oslogin</code></td>
<td><p>Enables or disables SSH key management on your project.</p>
<p>For more information about OS Login, see <a href="/compute/docs/instances/managing-instance-access">Set up OS Login</a>.</p></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">enable-windows-ssh</code></td>
<td><p><strong>Preview</strong></p>
<p>This product or feature is subject to the "Pre-GA Offerings Terms" in the General Service Terms section of the <a href="/terms/service-terms#1" data-track-type="commonIncludes">Service Specific Terms</a>. Pre-GA products and features are available "as is" and might have limited support. For more information, see the <a href="https://cloud.google.com/products/#product-launch-stages" data-track-type="commonIncludes">launch stage descriptions</a>.</p>
<p>Enables or disables SSH for Windows VMs.</p>
<p>For more information, see <a href="/compute/docs/connect/windows-ssh">Connect to Windows VMs using SSH</a>.</p></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">google-compute-default-data-protection</code></td>
<td><p>If set, stores the default option that is used to back up new instances created in the project.</p>
<p>For more information, see <a href="/compute/docs/disks/default-backup">Configure the default backup setting for the console</a>.</p></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">google-compute-default-region</code></td>
<td>If set, stores the default region that is used by the project.
<p>For more information about setting default regions, see <a href="/compute/docs/gcloud-compute#default-region-zone">Default region and zone</a>.</p></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">google-compute-default-zone</code></td>
<td>If set, stores the default zone that is used by the project.
<p>For more information about setting default zones, see <a href="/compute/docs/gcloud-compute#default-region-zone">Default region and zone</a>.</p></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">ssh-keys</code></td>
<td><p>If you are <a href="/compute/docs/instances/adding-removing-ssh-keys">managing SSH keys using metadata</a>, this attribute lets you configure public SSH keys that can connect to VMs in this project. If there are multiple SSH keys, each key is separated by a newline character (<code translate="no" dir="ltr">\n</code>). The value of the <code translate="no" dir="ltr">ssh-keys</code> attribute is a string.</p>
<p><strong>Example:</strong> <code translate="no" dir="ltr">"user1:ssh-rsa mypublickey user1@host.com\nuser2:ssh-rsa mypublickey user2@host.com"</code></p>
<p>SSH keys managed by <a href="/compute/docs/instances/managing-instance-access">OS Login</a> aren't visible in metadata.</p></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">sshKeys</code></td>
<td><strong>Deprecated:</strong> Use <code translate="no" dir="ltr">ssh-keys</code>.</td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">vmdnssetting</code></td>
<td><p>Enable zonal DNS and global DNS for the VMs in your project.</p>
<p>For more information about using zonal DNS names for your VMs, see <a href="/compute/docs/networking/zonal-dns">Use Zonal DNS for your internal DNS type</a>.</p></td>
</tr>
</tbody>
</table>

## Predefined instance metadata keys

Predefined metadata keys for instance metadata are stored under the following directory:

- `http://metadata.google.internal/computeMetadata/v1/instance/`

The following table provides a list of metadata keys and directories that Compute Engine automatically creates in the `instance/` metadata directory:

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="20%">Metadata entry</th>
<th>Description</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td><code translate="no" dir="ltr">attributes/</code></td>
<td><p>A directory of custom metadata values passed to the VM during startup or shutdown. These custom values can either be Google Cloud attributes or user-created metadata values.</p>
<p>For a list of instance-level Google Cloud attributes that you can set, see <a href="#instance-attributes-metadata">Instance attributes</a></p>
<p>For more information about setting custom metadata, see <a href="/compute/docs/metadata/setting-custom-metadata">Set custom metadata</a>.</p></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">cpu-platform</code></td>
<td><p>CPU platform of the VM.</p>
<p>For information about CPU platforms, see <a href="/compute/docs/cpu-platforms">CPU platforms</a>.</p></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">description</code></td>
<td>The free-text description of an instance that is assigned using the <code translate="no" dir="ltr">--description</code> flag by using the Google Cloud CLI or the API.</td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">disks/</code></td>
<td><p>A directory of disks that are attached to the VM. For each disk, the following information is available:</p>
<ul>
<li><code translate="no" dir="ltr">device-name</code></li>
<li><code translate="no" dir="ltr">index</code></li>
<li><code translate="no" dir="ltr">interface</code></li>
<li><code translate="no" dir="ltr">mode</code></li>
<li><code translate="no" dir="ltr">type</code></li>
</ul>
<p>For more information about disks, see <a href="/compute/docs/disks">Storage options</a>.</p></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">gce-workload-certificates/</code> (<strong>Deprecated</strong>)</td>
<td><p>Stores the following endpoints for the managed workload identities feature used by applications running in the VM.</p>
<ul>
<li><code translate="no" dir="ltr">config-status</code>: Contains any errors in the configuration values provided through the VM metadata.</li>
<li><code translate="no" dir="ltr">workload-identities</code>: Contains the identities managed by the Compute Engine control plane. This endpoint contains the X.509 certificate and the private key for the VM's trust domain.</li>
<li><code translate="no" dir="ltr">trust-anchors</code>: Contains a set of trusted certificates for peer X.509 certificate chain validation.</li>
</ul>
<p>For more information, see <a href="/compute/docs/access/authenticate-workloads-over-mtls">Authenticate workloads to other workloads over mTLS</a>.</p></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">guest-attributes/</code></td>
<td><p>Sets guest attributes for the VM. These custom values can either be Google Cloud attributes or user-created metadata values.</p>
<p>For a list of instance-level Google Cloud attributes that you can set, see <a href="#instance-guest-attributes-metadata">Instance guest attributes</a></p>
<strong>Note:</strong> Any user or process on your VM instance can read and write to the namespaces and keys in <code translate="no" dir="ltr">guest-attributes</code> metadata.
<p>For more information about guest attributes, see <a href="/compute/docs/metadata/manage-guest-attributes">Set and query guest attributes</a>.</p></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">hostname</code></td>
<td>The hostname of the VM.</td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">id</code></td>
<td>The ID of the VM. This is a unique, numerical ID generated by Compute Engine for your project and the zone of the VM. You can use this ID to identify your VM, especially if you haven't assigned a custom name to the VM.</td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">image</code></td>
<td>The operating system image used by the VM. This value has the following format: <code translate="no" dir="ltr">projects/</code><var translate="no">IMAGE_PROJECT</var><code translate="no" dir="ltr">/global/images/</code><var translate="no">IMAGE_NAME</var>.</td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">legacy-endpoint-access/</code></td>
<td>Stores the list of legacy endpoints. Values are <code translate="no" dir="ltr">0.1</code> and <code translate="no" dir="ltr">v1beta1</code>.</td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">licenses/</code></td>
<td>A list of license code IDs that are used to attach the licenses to images, snapshots, and disks.</td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">machine-type</code></td>
<td>The machine type for this VM. This value has the following format: <code translate="no" dir="ltr">projects/</code><var translate="no">PROJECT_NUM</var><code translate="no" dir="ltr">/machineTypes/</code><var translate="no">MACHINE_TYPE</var></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">maintenance-event</code></td>
<td>Indicates whether a maintenance event is affecting this VM. For more information, see <a href="/compute/docs/instances/setting-instance-scheduling-options#live_migrate">Live migrate</a>.</td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">name</code></td>
<td>The name of the VM.</td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">network-interfaces/</code></td>
<td><p>A directory of network interfaces. For each network interface the following information is available:</p>
<ul>
<li><code translate="no" dir="ltr">access-configs/</code>: Directory containing access configurations for this interface. Only <code translate="no" dir="ltr">0/</code> is supported, which contains details for a one-to-one NAT access config. Under <code translate="no" dir="ltr">access-configs/0/</code>:
<ul>
<li><code translate="no" dir="ltr">external-ip</code>: The external IP address of this interface.</li>
<li><code translate="no" dir="ltr">type</code>: The type of access configuration. <code translate="no" dir="ltr">ONE_TO_ONE_NAT</code> is the only value provided at this time.</li>
</ul></li>
<li><code translate="no" dir="ltr">dns-servers</code>: A list of DNS name servers for this interface.</li>
<li><code translate="no" dir="ltr">forwarded-ips/</code>: Directory containing IPs forwarded to this instance by using load balancing or protocol forwarding. Each entry is an IP address.</li>
<li><code translate="no" dir="ltr">forwarded-ipv6s/</code>: Directory containing IPv6 CIDR ranges forwarded to this instance by using load balancing or protocol forwarding. Each entry is an IPv6 CIDR range.</li>
<li><code translate="no" dir="ltr">gateway</code>: The gateway address for this network interface.</li>
<li><code translate="no" dir="ltr">gateway-ipv6</code>: The IPv6 gateway address for this network interface.</li>
<li><code translate="no" dir="ltr">ip</code>: The assigned internal IP address for this network interface.</li>
<li><code translate="no" dir="ltr">ip-aliases/</code>: Directory containing IP alias ranges assigned to this network interface. Each entry is an IP alias range.</li>
<li><code translate="no" dir="ltr">ipv6</code>: A list of IPv6 CIDR ranges assigned to the network interface.</li>
<li><code translate="no" dir="ltr">ipv6s</code>: A list of IPv6 addresses or prefixes assigned to the network interface.</li>
<li><code translate="no" dir="ltr">mac</code>: The MAC address for this network interface.</li>
<li><code translate="no" dir="ltr">mtu</code>: The MTU for this network interface.</li>
<li><code translate="no" dir="ltr">network</code>: The network for this interface, in <code translate="no" dir="ltr">projects/</code><var translate="no">PROJECT_ID</var><code translate="no" dir="ltr">/networks/</code><var translate="no">NETWORK_NAME</var> format.</li>
<li><code translate="no" dir="ltr">subnetmask</code>: The subnet mask for this network interface.</li>
<li><code translate="no" dir="ltr">target-instance-ips</code>: The list of internal IP addresses of forwarding rules that are targeting this instance.</li>
</ul>
<p>For more information about network interfaces, see <a href="/vpc/docs/multiple-interfaces-concepts">Multiple network interfaces overview</a>.</p></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">partner-attributes/</code> (<strong>Deprecated</strong>)</td>
<td><p>A directory containing namespaces within which metadata entries are stored. The namespaces are created by Google Cloud services, which use partner-attributes to store their configurations. When there are no services using the partner-attributes, the directory is empty.</p>
<p>For example, <a href="/compute/docs/access/authenticate-workloads-over-mtls#configure_identities">managed workload identities</a> use partner-attributes for its configurations.</p></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">preempted</code></td>
<td><p>A boolean value that indicates whether a VM is about to be preempted.</p></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">scheduling/</code></td>
<td><p>Sets the scheduling options for the VM.</p>
<p>Scheduling metadata values include the following:</p>
<ul>
<li><code translate="no" dir="ltr">on-host-maintenance</code>: indicates whether the VM terminates or live migrates during host maintenance.</li>
<li><code translate="no" dir="ltr">automatic-restart</code>: If this value is <code translate="no" dir="ltr">TRUE</code>, the VM automatically restarts after a maintenance event or crash.</li>
<li><code translate="no" dir="ltr">preemptible</code>: If this value is <code translate="no" dir="ltr">TRUE</code>, the VM is preemptible. This value is set when you create a VM, and it can't be changed.</li>
</ul>
<p>For more information about scheduling options, see <a href="/compute/docs/instances/setting-instance-scheduling-options">Set instance availability policies</a>.</p></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">service-accounts/</code></td>
<td><p>A directory of service accounts associated with the VM. For each service account, the following information is available:</p>
<ul>
<li><code translate="no" dir="ltr">aliases</code></li>
<li><code translate="no" dir="ltr">email</code>: The email address for the service account.</li>
<li><p><code translate="no" dir="ltr">identity</code>: A JSON Web Token that is unique to the VM. You must include the <code translate="no" dir="ltr">audience</code> parameter in your request for this VM metadata value. For example, <code translate="no" dir="ltr">?audience=http://www.example.com</code>.</p>
<p>For information about how to request and verify instance identity tokens, see <a href="/compute/docs/instances/verifying-instance-identity">Verify VM identity</a>.</p></li>
<li><code translate="no" dir="ltr">scopes</code>: The access scopes assigned to the service account.</li>
<li><p><code translate="no" dir="ltr">token</code>: The <code translate="no" dir="ltr">OAuth2</code> access token that can be used to authenticate applications.</p>
<p>For information about access tokens, see <a href="/compute/docs/access/create-enable-service-accounts-for-instances#applications">Authenticating applications directly with access tokens</a>.</p></li>
</ul>
<p>For more information about how Compute Engine uses service accounts, see <a href="/compute/docs/access/service-accounts">Service accounts</a>.</p></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">tags</code></td>
<td><p>Lists any network tags associated with the VM.</p>
<p>For more information about network tags, see <a href="/vpc/docs/add-remove-network-tags">Add network tags</a>.</p></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">virtual-clock/drift-token</code></td>
<td><p>The accumulated drift of the VM clock. Initialized to zero during instance creation and increased by the accumulated clock skew as the VM <a href="/compute/docs/instances/live-migration-process">live migrates</a>.</p></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">zone</code></td>
<td>The zone where this VM is located. This value has the following format: <code translate="no" dir="ltr">projects/</code><var translate="no">PROJECT_NUM</var><code translate="no" dir="ltr">/zones/</code><var translate="no">ZONE</var></td>
</tr>
</tbody>
</table>

### Predefined instance attribute metadata keys

Predefined metadata keys for instance attributes are stored under the following directory:

- `http://metadata.google.internal/computeMetadata/v1/instance/attributes/`

The following table provides a list of metadata keys that, if set for your instance, Compute Engine creates in the `instance/attributes/` metadata directory, along with its associated effect:

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="20%">Metadata entry</th>
<th>Description</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td><code translate="no" dir="ltr">physical_host_topology</code></td>
<td><p>A hash string that represents the physical location of a VM within a zone.</p>
<p>For more information about this attribute, see <a href="/compute/docs/instances/view-instance-topology">Verify the physical location of a VM</a>.</p></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">enable-osconfig</code></td>
<td><p>Enables or disables VM Manager for the VM.</p>
<p>Setting <code translate="no" dir="ltr">enable-osconfig</code> to <code translate="no" dir="ltr">TRUE</code> enables Patch, OS policies, and OS inventory management.</p>
<p>For more information about enabling VM Manager, see <a href="/compute/vm-manager/docs/setup#enable-metadata">Set the metadata values</a>.</p></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">osconfig-poll-interval</code></td>
<td><p>Configures the OS inventory scan interval, in minutes, for the VM.</p>
<p>By default, the OS Config agent runs an inventory scan on each VM every 10 minutes.</p>
<p>For more information about configuring the scan interval, see <a href="/compute/vm-manager/docs/os-inventory/view-os-details#configure-scan-interval">Configure the OS inventory scan interval</a>.</p></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">enable-oslogin</code></td>
<td><p>Enables or disables SSH key management on your VM.</p>
<p>For more information about OS Login, see <a href="/compute/docs/instances/managing-instance-access">Set up OS Login</a>.</p></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">enable-windows-ssh</code> (<a href="https://cloud.google.com/products/#product-launch-stages">Preview</a>)</td>
<td><p>Enables or disables SSH for Windows VMs.</p>
<p>For more information, see <a href="/compute/docs/connect/windows-ssh">Connect to Windows VMs using SSH</a>.</p></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">enable-workload-certificate</code> (<strong>Deprecated</strong>)</td>
<td><p>Enables or disables managed workload identities on a VM.</p>
<p>For more information, see <a href="/compute/docs/access/authenticate-workloads-over-mtls#enable-workload-id-vms">Enable managed workload identities for individual VMs</a>.</p></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">vmdnssetting</code></td>
<td><p>Enable zonal DNS and global DNS for the VM.</p>
<p>For more information about using zonal DNS names for your VMs DNS, see <a href="/compute/docs/networking/zonal-dns">Use Zonal DNS for your internal DNS type</a>.</p></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">ssh-keys</code></td>
<td><p>If you are <a href="/compute/docs/instances/adding-removing-ssh-keys">managing SSH keys using metadata</a>, this attribute lets you configure public SSH keys that can connect to VMs in this project. If there are multiple SSH keys, each key is separated by a newline character (<code translate="no" dir="ltr">\n</code>). The value of the <code translate="no" dir="ltr">ssh-keys</code> attribute is a string.</p>
<p><strong>Example:</strong> <code translate="no" dir="ltr">"user1:ssh-rsa mypublickey user1@host.com\nuser2:ssh-rsa mypublickey user2@host.com"</code></p>
<p>SSH keys managed by <a href="/compute/docs/instances/managing-instance-access">OS Login</a> aren't visible in metadata.</p></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">block-project-ssh-keys</code></td>
<td><p>Block project SSH keys from VMs that use metadata-based SSH keys.</p>
<p>For more information, see <a href="/compute/docs/connect/restrict-ssh-keys#block-keys">Restrict SSH keys from VMs</a>.</p></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">disable-https-mds-setup</code></td>
<td><p>Disables automatic HTTPS Metadata Server certificate provisioning by Compute Engine.</p>
<p>For more information, see <a href="/compute/docs/metadata/overview#https-mds-disabling-certificate-setup">Enable automatic certificate setup</a>.</p></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">enable-https-mds-native-cert-store</code></td>
<td><p>Enables Compute Engine to add the root certificate to the OS trust store during automatic HTTPS Metadata Server certificate provisioning.</p>
<p>For more information, see <a href="/compute/docs/metadata/overview#https-mds-trust-store">Enabling root certificate storage in OS trust store</a>.</p></td>
</tr>
</tbody>
</table>

### Predefined guest attribute metadata keys

Predefined metadata keys for instance guest attributes are stored under the following directory:

- `http://metadata.google.internal/computeMetadata/v1/instance/guest-attributes/`

The following table provides a list of metadata keys and directories that Compute Engine automatically creates in the `instance/guest-attributes/` metadata directory:

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="20%">Metadata entry</th>
<th>Description</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td><code translate="no" dir="ltr">guestInventory/</code></td>
<td><p>Stores OS inventory for the VM.</p>
<p>Collects and stores OS details information. This includes information such as hostname, kernel version, architecture, and installed packages details.</p>
<p>For more information about OS inventory, see <a href="/compute/docs/instances/view-os-details">View operating system details</a>.</p></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">hostkeys/</code></td>
<td><p>Stores SSH host keys. Host keys can be used to identify a particular host or machine.</p>
<p>For information host keys, see <a href="https://cloud.google.com/solutions/connecting-securely#storing_host_keys_by_enabling_guest_attributes">Storing host keys by enabling guest attributes</a>.</p></td>
</tr>
</tbody>
</table>

## What's next?

- Learn more about [VM metadata](/compute/docs/metadata/overview).
- Learn how to [set custom metadata](/compute/docs/metadata/setting-custom-metadata).
- Learn how to [set and query guest attributes](/compute/docs/metadata/manage-guest-attributes).
- Learn how to [view and query VM metadata](/compute/docs/metadata/querying-metadata).

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
