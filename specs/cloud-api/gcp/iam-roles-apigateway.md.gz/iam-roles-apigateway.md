# API Gateway roles and permissions

<div class="devsite-article-body clearfix">

This page lists the IAM roles and permissions for API Gateway. To search through all roles and permissions, see the [role and permission index](/iam/docs/roles-permissions).

## API Gateway roles

<div results-count-container="">

</div>

<table class="fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="50%">Role</th>
<th>Permissions</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td class="role-description"><h4 id="apigateway.admin" class="role-title add-link" data-text="ApiGateway Admin " tabindex="-1">ApiGateway Admin</h4>
<p>(<code translate="no" dir="ltr">roles/apigateway.admin</code>)</p>
<span class="role-description"> </span>
<p>Full access to ApiGateway and related resources.</p></td>
<td class="role-permissions"><p><span class="iamperm-wildcard"><code translate="no" dir="ltr">apigateway.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">apigateway.apiconfigs.create</code></li>
<li><code translate="no" dir="ltr">apigateway.apiconfigs.delete</code></li>
<li><code translate="no" dir="ltr">apigateway.apiconfigs.get</code></li>
<li><code translate="no" dir="ltr">apigateway.apiconfigs.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">apigateway.apiconfigs.list</code></li>
<li><code translate="no" dir="ltr">apigateway.apiconfigs.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">apigateway.apiconfigs.update</code></li>
<li><code translate="no" dir="ltr">apigateway.apis.create</code></li>
<li><code translate="no" dir="ltr">apigateway.apis.createTagBinding</code></li>
<li><code translate="no" dir="ltr">apigateway.apis.delete</code></li>
<li><code translate="no" dir="ltr">apigateway.apis.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">apigateway.apis.get</code></li>
<li><code translate="no" dir="ltr">apigateway.apis.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">apigateway.apis.list</code></li>
<li><code translate="no" dir="ltr">apigateway.apis.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">apigateway.apis.listTagBindings</code></li>
<li><code translate="no" dir="ltr">apigateway.apis.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">apigateway.apis.update</code></li>
<li><code translate="no" dir="ltr">apigateway.gateways.create</code></li>
<li><code translate="no" dir="ltr">apigateway.gateways.createTagBinding</code></li>
<li><code translate="no" dir="ltr">apigateway.gateways.delete</code></li>
<li><code translate="no" dir="ltr">apigateway.gateways.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">apigateway.gateways.get</code></li>
<li><code translate="no" dir="ltr">apigateway.gateways.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">apigateway.gateways.list</code></li>
<li><code translate="no" dir="ltr">apigateway.gateways.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">apigateway.gateways.listTagBindings</code></li>
<li><code translate="no" dir="ltr">apigateway.gateways.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">apigateway.gateways.update</code></li>
<li><code translate="no" dir="ltr">apigateway.locations.get</code></li>
<li><code translate="no" dir="ltr">apigateway.locations.list</code></li>
<li><code translate="no" dir="ltr">apigateway.operations.cancel</code></li>
<li><code translate="no" dir="ltr">apigateway.operations.delete</code></li>
<li><code translate="no" dir="ltr">apigateway.operations.get</code></li>
<li><code translate="no" dir="ltr">apigateway.operations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">apihub.runTimeProjectAttachments.list</code></p>
<p><code translate="no" dir="ltr">monitoring.metricDescriptors.list</code></p>
<p><code translate="no" dir="ltr">monitoring.monitoredResourceDescriptors.get</code></p>
<p><code translate="no" dir="ltr">monitoring.timeSeries.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><code translate="no" dir="ltr">servicemanagement.services.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.catalogs.listMembers</code></p>
<p><code translate="no" dir="ltr">serviceusage.consumerpolicy.analyze</code></p>
<p><code translate="no" dir="ltr">serviceusage.consumerpolicy.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.effectivepolicy.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">serviceusage.groups.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">serviceusage.groups.list</code></li>
<li><code translate="no" dir="ltr">serviceusage.groups.listExpandedMembers</code></li>
<li><code translate="no" dir="ltr">serviceusage.groups.listMembers</code></li>
</ul>
<p><code translate="no" dir="ltr">serviceusage.services.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.list</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.listApis</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.listDependentServices</code></p>
<p><code translate="no" dir="ltr">serviceusage.values.test</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="apigateway.editor" class="role-title add-link" data-text="ApiGateway Editor " tabindex="-1">ApiGateway Editor</h4>
<p>(<code translate="no" dir="ltr">roles/apigateway.editor</code>)</p>
<span class="role-description"> </span>
<p>Editor role for ApiGateway</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">apigateway.apiconfigs.create</code></p>
<p><code translate="no" dir="ltr">apigateway.apiconfigs.delete</code></p>
<p><code translate="no" dir="ltr">apigateway.apiconfigs.get</code></p>
<p><code translate="no" dir="ltr">apigateway.apiconfigs.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">apigateway.apiconfigs.list</code></p>
<p><code translate="no" dir="ltr">apigateway.apiconfigs.update</code></p>
<p><code translate="no" dir="ltr">apigateway.apis.create</code></p>
<p><code translate="no" dir="ltr">apigateway.apis.delete</code></p>
<p><code translate="no" dir="ltr">apigateway.apis.get</code></p>
<p><code translate="no" dir="ltr">apigateway.apis.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">apigateway.apis.list</code></p>
<p><code translate="no" dir="ltr">apigateway.apis.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">apigateway.apis.listTagBindings</code></p>
<p><code translate="no" dir="ltr">apigateway.apis.update</code></p>
<p><code translate="no" dir="ltr">apigateway.gateways.create</code></p>
<p><code translate="no" dir="ltr">apigateway.gateways.delete</code></p>
<p><code translate="no" dir="ltr">apigateway.gateways.get</code></p>
<p><code translate="no" dir="ltr">apigateway.gateways.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">apigateway.gateways.list</code></p>
<p><code translate="no" dir="ltr">apigateway.gateways.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">apigateway.gateways.listTagBindings</code></p>
<p><code translate="no" dir="ltr">apigateway.gateways.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">apigateway.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">apigateway.locations.get</code></li>
<li><code translate="no" dir="ltr">apigateway.locations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">apigateway.operations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">apigateway.operations.cancel</code></li>
<li><code translate="no" dir="ltr">apigateway.operations.delete</code></li>
<li><code translate="no" dir="ltr">apigateway.operations.get</code></li>
<li><code translate="no" dir="ltr">apigateway.operations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">apihub.runTimeProjectAttachments.list</code></p>
<p><code translate="no" dir="ltr">monitoring.metricDescriptors.list</code></p>
<p><code translate="no" dir="ltr">monitoring.monitoredResourceDescriptors.get</code></p>
<p><code translate="no" dir="ltr">monitoring.timeSeries.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><code translate="no" dir="ltr">servicemanagement.services.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.catalogs.listMembers</code></p>
<p><code translate="no" dir="ltr">serviceusage.consumerpolicy.analyze</code></p>
<p><code translate="no" dir="ltr">serviceusage.consumerpolicy.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.effectivepolicy.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">serviceusage.groups.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">serviceusage.groups.list</code></li>
<li><code translate="no" dir="ltr">serviceusage.groups.listExpandedMembers</code></li>
<li><code translate="no" dir="ltr">serviceusage.groups.listMembers</code></li>
</ul>
<p><code translate="no" dir="ltr">serviceusage.services.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.list</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.listApis</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.listDependentServices</code></p>
<p><code translate="no" dir="ltr">serviceusage.values.test</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="apigateway.viewer" class="role-title add-link" data-text="ApiGateway Viewer " tabindex="-1">ApiGateway Viewer</h4>
<p>(<code translate="no" dir="ltr">roles/apigateway.viewer</code>)</p>
<span class="role-description"> </span>
<p>Read-only access to ApiGateway and related resources.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">apigateway.apiconfigs.get</code></p>
<p><code translate="no" dir="ltr">apigateway.apiconfigs.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">apigateway.apiconfigs.list</code></p>
<p><code translate="no" dir="ltr">apigateway.apis.get</code></p>
<p><code translate="no" dir="ltr">apigateway.apis.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">apigateway.apis.list</code></p>
<p><code translate="no" dir="ltr">apigateway.apis.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">apigateway.apis.listTagBindings</code></p>
<p><code translate="no" dir="ltr">apigateway.gateways.get</code></p>
<p><code translate="no" dir="ltr">apigateway.gateways.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">apigateway.gateways.list</code></p>
<p><code translate="no" dir="ltr">apigateway.gateways.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">apigateway.gateways.listTagBindings</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">apigateway.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">apigateway.locations.get</code></li>
<li><code translate="no" dir="ltr">apigateway.locations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">apigateway.operations.get</code></p>
<p><code translate="no" dir="ltr">apigateway.operations.list</code></p>
<p><code translate="no" dir="ltr">apihub.runTimeProjectAttachments.list</code></p>
<p><code translate="no" dir="ltr">monitoring.metricDescriptors.list</code></p>
<p><code translate="no" dir="ltr">monitoring.monitoredResourceDescriptors.get</code></p>
<p><code translate="no" dir="ltr">monitoring.timeSeries.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><code translate="no" dir="ltr">servicemanagement.services.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.catalogs.listMembers</code></p>
<p><code translate="no" dir="ltr">serviceusage.consumerpolicy.analyze</code></p>
<p><code translate="no" dir="ltr">serviceusage.consumerpolicy.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.effectivepolicy.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">serviceusage.groups.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">serviceusage.groups.list</code></li>
<li><code translate="no" dir="ltr">serviceusage.groups.listExpandedMembers</code></li>
<li><code translate="no" dir="ltr">serviceusage.groups.listMembers</code></li>
</ul>
<p><code translate="no" dir="ltr">serviceusage.services.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.list</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.listApis</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.listDependentServices</code></p>
<p><code translate="no" dir="ltr">serviceusage.values.test</code></p></td>
</tr>
</tbody>
</table>

### Service agent roles

Service agent roles should only be granted to [service agents](/iam/docs/service-agents).

<div results-count-container="">

</div>

<table class="fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="50%">Role</th>
<th>Permissions</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td class="role-description"><h4 id="apigateway.serviceAgent" class="role-title add-link" data-text="Cloud API Gateway Service Agent " tabindex="-1">Cloud API Gateway Service Agent</h4>
<p>(<code translate="no" dir="ltr">roles/apigateway.serviceAgent</code>)</p>
<span class="role-description"> </span>
<p>Gives Cloud API Gateway service account access to Service Management check and reports as well as impersonation on user-specified service accounts.</p>
<strong>Warning:</strong> Do not grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.</td>
<td class="role-permissions"><p><code translate="no" dir="ltr">iam.serviceAccounts.getAccessToken</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.getOpenIdToken</code></p>
<p><code translate="no" dir="ltr">servicemanagement.services.check</code></p>
<p><code translate="no" dir="ltr">servicemanagement.services.quota</code></p>
<p><code translate="no" dir="ltr">servicemanagement.services.report</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="apigateway_management.serviceAgent" class="role-title add-link" data-text="Cloud API Gateway Management Service Agent " tabindex="-1">Cloud API Gateway Management Service Agent</h4>
<p>(<code translate="no" dir="ltr">roles/apigateway_management.serviceAgent</code>)</p>
<span class="role-description custom"> </span>
<p>Gives Cloud API Gateway service account access to retrieve a Service configuration.</p>
<strong>Warning:</strong> Do not grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.</td>
<td class="role-permissions"><p><code translate="no" dir="ltr">iam.serviceAccounts.get</code></p>
<p><code translate="no" dir="ltr">servicemanagement.services.create</code></p>
<p><code translate="no" dir="ltr">servicemanagement.services.delete</code></p>
<p><code translate="no" dir="ltr">servicemanagement.services.get</code></p>
<p><code translate="no" dir="ltr">servicemanagement.services.list</code></p>
<p><code translate="no" dir="ltr">servicemanagement.services.update</code></p>
<p><code translate="no" dir="ltr">serviceusage.catalogs.listMembers</code></p>
<p><code translate="no" dir="ltr">serviceusage.consumerpolicy.analyze</code></p>
<p><code translate="no" dir="ltr">serviceusage.consumerpolicy.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.effectivepolicy.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">serviceusage.groups.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">serviceusage.groups.list</code></li>
<li><code translate="no" dir="ltr">serviceusage.groups.listExpandedMembers</code></li>
<li><code translate="no" dir="ltr">serviceusage.groups.listMembers</code></li>
</ul>
<p><code translate="no" dir="ltr">serviceusage.services.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.listApis</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.listDependentServices</code></p>
<p><code translate="no" dir="ltr">serviceusage.values.test</code></p></td>
</tr>
</tbody>
</table>

## API Gateway permissions

<div results-count-container="">

</div>

<table class="permissions-table fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="45%">Permission</th>
<th>Included in roles</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td><h4 id="apigateway.apiconfigs.create" class="permission-name add-link" data-text="apigateway.apiconfigs.create" tabindex="-1"><code translate="no" dir="ltr">apigateway.apiconfigs.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.admin">ApiGateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.editor">ApiGateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.editor</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="apigateway.apiconfigs.delete" class="permission-name add-link" data-text="apigateway.apiconfigs.delete" tabindex="-1"><code translate="no" dir="ltr">apigateway.apiconfigs.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.admin">ApiGateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.editor">ApiGateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.editor</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="apigateway.apiconfigs.get" class="permission-name add-link" data-text="apigateway.apiconfigs.get" tabindex="-1"><code translate="no" dir="ltr">apigateway.apiconfigs.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.admin">ApiGateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.editor">ApiGateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.viewer">ApiGateway Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.attackSurfaceManagementScannerServiceAgent">Attack Surface Management Scanner Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.attackSurfaceManagementScannerServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="apigateway.apiconfigs.getIamPolicy" class="permission-name add-link" data-text="apigateway.apiconfigs.getIamPolicy" tabindex="-1"><code translate="no" dir="ltr">apigateway.apiconfigs.getIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.admin">ApiGateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.editor">ApiGateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.viewer">ApiGateway Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="apigateway.apiconfigs.list" class="permission-name add-link" data-text="apigateway.apiconfigs.list" tabindex="-1"><code translate="no" dir="ltr">apigateway.apiconfigs.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.admin">ApiGateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.editor">ApiGateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.viewer">ApiGateway Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="apigateway.apiconfigs.setIamPolicy" class="permission-name add-link" data-text="apigateway.apiconfigs.setIamPolicy" tabindex="-1"><code translate="no" dir="ltr">apigateway.apiconfigs.setIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.admin">ApiGateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="apigateway.apiconfigs.update" class="permission-name add-link" data-text="apigateway.apiconfigs.update" tabindex="-1"><code translate="no" dir="ltr">apigateway.apiconfigs.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.admin">ApiGateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.editor">ApiGateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.editor</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="apigateway.apis.create" class="permission-name add-link" data-text="apigateway.apis.create" tabindex="-1"><code translate="no" dir="ltr">apigateway.apis.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.admin">ApiGateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.editor">ApiGateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.editor</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="apigateway.apis.createTagBinding" class="permission-name add-link" data-text="apigateway.apis.createTagBinding" tabindex="-1"><code translate="no" dir="ltr">apigateway.apis.createTagBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.admin">ApiGateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="apigateway.apis.delete" class="permission-name add-link" data-text="apigateway.apis.delete" tabindex="-1"><code translate="no" dir="ltr">apigateway.apis.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.admin">ApiGateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.editor">ApiGateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.editor</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="apigateway.apis.deleteTagBinding" class="permission-name add-link" data-text="apigateway.apis.deleteTagBinding" tabindex="-1"><code translate="no" dir="ltr">apigateway.apis.deleteTagBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.admin">ApiGateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="apigateway.apis.get" class="permission-name add-link" data-text="apigateway.apis.get" tabindex="-1"><code translate="no" dir="ltr">apigateway.apis.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.admin">ApiGateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.editor">ApiGateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.viewer">ApiGateway Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="apigateway.apis.getIamPolicy" class="permission-name add-link" data-text="apigateway.apis.getIamPolicy" tabindex="-1"><code translate="no" dir="ltr">apigateway.apis.getIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.admin">ApiGateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.editor">ApiGateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.viewer">ApiGateway Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="apigateway.apis.list" class="permission-name add-link" data-text="apigateway.apis.list" tabindex="-1"><code translate="no" dir="ltr">apigateway.apis.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.admin">ApiGateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.editor">ApiGateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.viewer">ApiGateway Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="apigateway.apis.listEffectiveTags" class="permission-name add-link" data-text="apigateway.apis.listEffectiveTags" tabindex="-1"><code translate="no" dir="ltr">apigateway.apis.listEffectiveTags</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.admin">ApiGateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.editor">ApiGateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.viewer">ApiGateway Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagViewer">Tag Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="apigateway.apis.listTagBindings" class="permission-name add-link" data-text="apigateway.apis.listTagBindings" tabindex="-1"><code translate="no" dir="ltr">apigateway.apis.listTagBindings</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.admin">ApiGateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.editor">ApiGateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.viewer">ApiGateway Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagViewer">Tag Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="apigateway.apis.setIamPolicy" class="permission-name add-link" data-text="apigateway.apis.setIamPolicy" tabindex="-1"><code translate="no" dir="ltr">apigateway.apis.setIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.admin">ApiGateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="apigateway.apis.update" class="permission-name add-link" data-text="apigateway.apis.update" tabindex="-1"><code translate="no" dir="ltr">apigateway.apis.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.admin">ApiGateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.editor">ApiGateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.editor</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="apigateway.gateways.create" class="permission-name add-link" data-text="apigateway.gateways.create" tabindex="-1"><code translate="no" dir="ltr">apigateway.gateways.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.admin">ApiGateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.editor">ApiGateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.editor</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="apigateway.gateways.createTagBinding" class="permission-name add-link" data-text="apigateway.gateways.createTagBinding" tabindex="-1"><code translate="no" dir="ltr">apigateway.gateways.createTagBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.admin">ApiGateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="apigateway.gateways.delete" class="permission-name add-link" data-text="apigateway.gateways.delete" tabindex="-1"><code translate="no" dir="ltr">apigateway.gateways.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.admin">ApiGateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.editor">ApiGateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.editor</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="apigateway.gateways.deleteTagBinding" class="permission-name add-link" data-text="apigateway.gateways.deleteTagBinding" tabindex="-1"><code translate="no" dir="ltr">apigateway.gateways.deleteTagBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.admin">ApiGateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="apigateway.gateways.get" class="permission-name add-link" data-text="apigateway.gateways.get" tabindex="-1"><code translate="no" dir="ltr">apigateway.gateways.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.admin">ApiGateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.editor">ApiGateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.viewer">ApiGateway Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="apigateway.gateways.getIamPolicy" class="permission-name add-link" data-text="apigateway.gateways.getIamPolicy" tabindex="-1"><code translate="no" dir="ltr">apigateway.gateways.getIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.admin">ApiGateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.editor">ApiGateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.viewer">ApiGateway Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="apigateway.gateways.list" class="permission-name add-link" data-text="apigateway.gateways.list" tabindex="-1"><code translate="no" dir="ltr">apigateway.gateways.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.admin">ApiGateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.editor">ApiGateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.viewer">ApiGateway Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="apigateway.gateways.listEffectiveTags" class="permission-name add-link" data-text="apigateway.gateways.listEffectiveTags" tabindex="-1"><code translate="no" dir="ltr">apigateway.gateways.listEffectiveTags</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.admin">ApiGateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.editor">ApiGateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.viewer">ApiGateway Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagViewer">Tag Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="apigateway.gateways.listTagBindings" class="permission-name add-link" data-text="apigateway.gateways.listTagBindings" tabindex="-1"><code translate="no" dir="ltr">apigateway.gateways.listTagBindings</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.admin">ApiGateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.editor">ApiGateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.viewer">ApiGateway Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagViewer">Tag Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="apigateway.gateways.setIamPolicy" class="permission-name add-link" data-text="apigateway.gateways.setIamPolicy" tabindex="-1"><code translate="no" dir="ltr">apigateway.gateways.setIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.admin">ApiGateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="apigateway.gateways.update" class="permission-name add-link" data-text="apigateway.gateways.update" tabindex="-1"><code translate="no" dir="ltr">apigateway.gateways.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.admin">ApiGateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.editor">ApiGateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.editor</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="apigateway.locations.get" class="permission-name add-link" data-text="apigateway.locations.get" tabindex="-1"><code translate="no" dir="ltr">apigateway.locations.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.admin">ApiGateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.editor">ApiGateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.viewer">ApiGateway Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="apigateway.locations.list" class="permission-name add-link" data-text="apigateway.locations.list" tabindex="-1"><code translate="no" dir="ltr">apigateway.locations.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.admin">ApiGateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.editor">ApiGateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.viewer">ApiGateway Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="apigateway.operations.cancel" class="permission-name add-link" data-text="apigateway.operations.cancel" tabindex="-1"><code translate="no" dir="ltr">apigateway.operations.cancel</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.admin">ApiGateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.editor">ApiGateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.editor</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="apigateway.operations.delete" class="permission-name add-link" data-text="apigateway.operations.delete" tabindex="-1"><code translate="no" dir="ltr">apigateway.operations.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.admin">ApiGateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.editor">ApiGateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.editor</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="apigateway.operations.get" class="permission-name add-link" data-text="apigateway.operations.get" tabindex="-1"><code translate="no" dir="ltr">apigateway.operations.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.admin">ApiGateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.editor">ApiGateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.viewer">ApiGateway Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="apigateway.operations.list" class="permission-name add-link" data-text="apigateway.operations.list" tabindex="-1"><code translate="no" dir="ltr">apigateway.operations.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.admin">ApiGateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.editor">ApiGateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.viewer">ApiGateway Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
</tbody>
</table>

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
