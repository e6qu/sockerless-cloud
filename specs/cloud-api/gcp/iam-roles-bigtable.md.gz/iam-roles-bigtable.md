# Bigtable roles and permissions

<div class="devsite-article-body clearfix">

This page lists the IAM roles and permissions for Bigtable. To search through all roles and permissions, see the [role and permission index](/iam/docs/roles-permissions).

## Bigtable roles

<div results-count-container="">

</div>

<table class="fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="50%">Role</th>
<th>Permissions</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td class="role-description"><h4 id="bigtable.admin" class="role-title add-link" data-text="Bigtable Administrator " tabindex="-1">Bigtable Administrator</h4>
<p>(<code translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<span class="role-description custom"> </span>
<p>Administers all Bigtable instances within a project, including the data stored within tables. Can create new instances. Intended for project administrators.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Table</li>
</ul></td>
<td class="role-permissions"><p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigtable.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigtable.appProfiles.create</code></li>
<li><code translate="no" dir="ltr">bigtable.appProfiles.delete</code></li>
<li><code translate="no" dir="ltr">bigtable.appProfiles.get</code></li>
<li><code translate="no" dir="ltr">bigtable.appProfiles.list</code></li>
<li><code translate="no" dir="ltr">bigtable.appProfiles.update</code></li>
<li><code translate="no" dir="ltr">bigtable.authorizedViews.create</code></li>
<li><code translate="no" dir="ltr">bigtable.authorizedViews.createTagBinding</code></li>
<li><code translate="no" dir="ltr">bigtable.authorizedViews.delete</code></li>
<li><code translate="no" dir="ltr">bigtable.authorizedViews.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">bigtable.authorizedViews.get</code></li>
<li><code translate="no" dir="ltr">bigtable.authorizedViews.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">bigtable.authorizedViews.list</code></li>
<li><code translate="no" dir="ltr">bigtable.authorizedViews.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">bigtable.authorizedViews.listTagBindings</code></li>
<li><code translate="no" dir="ltr">bigtable.authorizedViews.mutateRows</code></li>
<li><code translate="no" dir="ltr">bigtable.authorizedViews.readRows</code></li>
<li><code translate="no" dir="ltr">bigtable.authorizedViews.sampleRowKeys</code></li>
<li><code translate="no" dir="ltr">bigtable.authorizedViews.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">bigtable.authorizedViews.update</code></li>
<li><code translate="no" dir="ltr">bigtable.backups.create</code></li>
<li><code translate="no" dir="ltr">bigtable.backups.delete</code></li>
<li><code translate="no" dir="ltr">bigtable.backups.get</code></li>
<li><code translate="no" dir="ltr">bigtable.backups.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">bigtable.backups.list</code></li>
<li><code translate="no" dir="ltr">bigtable.backups.read</code></li>
<li><code translate="no" dir="ltr">bigtable.backups.restore</code></li>
<li><code translate="no" dir="ltr">bigtable.backups.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">bigtable.backups.update</code></li>
<li><code translate="no" dir="ltr">bigtable.clusters.create</code></li>
<li><code translate="no" dir="ltr">bigtable.clusters.delete</code></li>
<li><code translate="no" dir="ltr">bigtable.clusters.get</code></li>
<li><code translate="no" dir="ltr">bigtable.clusters.list</code></li>
<li><code translate="no" dir="ltr">bigtable.clusters.update</code></li>
<li><code translate="no" dir="ltr">bigtable.hotTablets.list</code></li>
<li><code translate="no" dir="ltr">bigtable.instances.create</code></li>
<li><code translate="no" dir="ltr">bigtable.instances.createTagBinding</code></li>
<li><code translate="no" dir="ltr">bigtable.instances.delete</code></li>
<li><code translate="no" dir="ltr">bigtable.instances.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">bigtable.instances.executeQuery</code></li>
<li><code translate="no" dir="ltr">bigtable.instances.get</code></li>
<li><code translate="no" dir="ltr">bigtable.instances.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">bigtable.instances.list</code></li>
<li><code translate="no" dir="ltr">bigtable.instances.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">bigtable.instances.listTagBindings</code></li>
<li><code translate="no" dir="ltr">bigtable.instances.ping</code></li>
<li><code translate="no" dir="ltr">bigtable.instances.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">bigtable.instances.update</code></li>
<li><code translate="no" dir="ltr">bigtable.keyvisualizer.get</code></li>
<li><code translate="no" dir="ltr">bigtable.keyvisualizer.list</code></li>
<li><code translate="no" dir="ltr">bigtable.locations.list</code></li>
<li><code translate="no" dir="ltr">bigtable.logicalViews.create</code></li>
<li><code translate="no" dir="ltr">bigtable.logicalViews.delete</code></li>
<li><code translate="no" dir="ltr">bigtable.logicalViews.get</code></li>
<li><code translate="no" dir="ltr">bigtable.logicalViews.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">bigtable.logicalViews.list</code></li>
<li><code translate="no" dir="ltr">bigtable.logicalViews.readRows</code></li>
<li><code translate="no" dir="ltr">bigtable.logicalViews.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">bigtable.logicalViews.update</code></li>
<li><code translate="no" dir="ltr">bigtable.materializedViews.create</code></li>
<li><code translate="no" dir="ltr">bigtable.materializedViews.delete</code></li>
<li><code translate="no" dir="ltr">bigtable.materializedViews.get</code></li>
<li><code translate="no" dir="ltr">bigtable.materializedViews.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">bigtable.materializedViews.list</code></li>
<li><code translate="no" dir="ltr">bigtable.materializedViews.readRows</code></li>
<li><code translate="no" dir="ltr">bigtable.materializedViews.sampleRowKeys</code></li>
<li><code translate="no" dir="ltr">bigtable.materializedViews.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">bigtable.materializedViews.update</code></li>
<li><code translate="no" dir="ltr">bigtable.memoryLayers.get</code></li>
<li><code translate="no" dir="ltr">bigtable.memoryLayers.list</code></li>
<li><code translate="no" dir="ltr">bigtable.memoryLayers.update</code></li>
<li><code translate="no" dir="ltr">bigtable.schemaBundles.create</code></li>
<li><code translate="no" dir="ltr">bigtable.schemaBundles.delete</code></li>
<li><code translate="no" dir="ltr">bigtable.schemaBundles.get</code></li>
<li><code translate="no" dir="ltr">bigtable.schemaBundles.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">bigtable.schemaBundles.list</code></li>
<li><code translate="no" dir="ltr">bigtable.schemaBundles.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">bigtable.schemaBundles.update</code></li>
<li><code translate="no" dir="ltr">bigtable.tables.checkConsistency</code></li>
<li><code translate="no" dir="ltr">bigtable.tables.create</code></li>
<li><code translate="no" dir="ltr">bigtable.tables.delete</code></li>
<li><code translate="no" dir="ltr">bigtable.tables.generateConsistencyToken</code></li>
<li><code translate="no" dir="ltr">bigtable.tables.get</code></li>
<li><code translate="no" dir="ltr">bigtable.tables.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">bigtable.tables.list</code></li>
<li><code translate="no" dir="ltr">bigtable.tables.mutateRows</code></li>
<li><code translate="no" dir="ltr">bigtable.tables.readRows</code></li>
<li><code translate="no" dir="ltr">bigtable.tables.sampleRowKeys</code></li>
<li><code translate="no" dir="ltr">bigtable.tables.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">bigtable.tables.undelete</code></li>
<li><code translate="no" dir="ltr">bigtable.tables.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudkms.keyHandles.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudkms.keyHandles.create</code></li>
<li><code translate="no" dir="ltr">cloudkms.keyHandles.get</code></li>
<li><code translate="no" dir="ltr">cloudkms.keyHandles.list</code></li>
</ul>
<p><code translate="no" dir="ltr">cloudkms.operations.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.projects.showEffectiveAutokeyConfig</code></p>
<p><code translate="no" dir="ltr">monitoring.metricDescriptors.get</code></p>
<p><code translate="no" dir="ltr">monitoring.metricDescriptors.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">monitoring.timeSeries.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">monitoring.timeSeries.create</code></li>
<li><code translate="no" dir="ltr">monitoring.timeSeries.list</code></li>
</ul>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="bigtable.editor" class="role-title add-link" data-text="Bigtable Editor " tabindex="-1">Bigtable Editor</h4>
<p>(<code translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<span class="role-description"> </span>
<p>Editor role for bigtable</p></td>
<td class="role-permissions"><p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigtable.appProfiles.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigtable.appProfiles.create</code></li>
<li><code translate="no" dir="ltr">bigtable.appProfiles.delete</code></li>
<li><code translate="no" dir="ltr">bigtable.appProfiles.get</code></li>
<li><code translate="no" dir="ltr">bigtable.appProfiles.list</code></li>
<li><code translate="no" dir="ltr">bigtable.appProfiles.update</code></li>
</ul>
<p><code translate="no" dir="ltr">bigtable.authorizedViews.create</code></p>
<p><code translate="no" dir="ltr">bigtable.authorizedViews.delete</code></p>
<p><code translate="no" dir="ltr">bigtable.authorizedViews.get</code></p>
<p><code translate="no" dir="ltr">bigtable.authorizedViews.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigtable.authorizedViews.list</code></p>
<p><code translate="no" dir="ltr">bigtable.authorizedViews.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">bigtable.authorizedViews.listTagBindings</code></p>
<p><code translate="no" dir="ltr">bigtable.authorizedViews.mutateRows</code></p>
<p><code translate="no" dir="ltr">bigtable.authorizedViews.readRows</code></p>
<p><code translate="no" dir="ltr">bigtable.authorizedViews.sampleRowKeys</code></p>
<p><code translate="no" dir="ltr">bigtable.authorizedViews.update</code></p>
<p><code translate="no" dir="ltr">bigtable.backups.create</code></p>
<p><code translate="no" dir="ltr">bigtable.backups.delete</code></p>
<p><code translate="no" dir="ltr">bigtable.backups.get</code></p>
<p><code translate="no" dir="ltr">bigtable.backups.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigtable.backups.list</code></p>
<p><code translate="no" dir="ltr">bigtable.backups.read</code></p>
<p><code translate="no" dir="ltr">bigtable.backups.restore</code></p>
<p><code translate="no" dir="ltr">bigtable.backups.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigtable.clusters.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigtable.clusters.create</code></li>
<li><code translate="no" dir="ltr">bigtable.clusters.delete</code></li>
<li><code translate="no" dir="ltr">bigtable.clusters.get</code></li>
<li><code translate="no" dir="ltr">bigtable.clusters.list</code></li>
<li><code translate="no" dir="ltr">bigtable.clusters.update</code></li>
</ul>
<p><code translate="no" dir="ltr">bigtable.hotTablets.list</code></p>
<p><code translate="no" dir="ltr">bigtable.instances.create</code></p>
<p><code translate="no" dir="ltr">bigtable.instances.delete</code></p>
<p><code translate="no" dir="ltr">bigtable.instances.executeQuery</code></p>
<p><code translate="no" dir="ltr">bigtable.instances.get</code></p>
<p><code translate="no" dir="ltr">bigtable.instances.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigtable.instances.list</code></p>
<p><code translate="no" dir="ltr">bigtable.instances.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">bigtable.instances.listTagBindings</code></p>
<p><code translate="no" dir="ltr">bigtable.instances.ping</code></p>
<p><code translate="no" dir="ltr">bigtable.instances.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigtable.keyvisualizer.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigtable.keyvisualizer.get</code></li>
<li><code translate="no" dir="ltr">bigtable.keyvisualizer.list</code></li>
</ul>
<p><code translate="no" dir="ltr">bigtable.locations.list</code></p>
<p><code translate="no" dir="ltr">bigtable.logicalViews.create</code></p>
<p><code translate="no" dir="ltr">bigtable.logicalViews.delete</code></p>
<p><code translate="no" dir="ltr">bigtable.logicalViews.get</code></p>
<p><code translate="no" dir="ltr">bigtable.logicalViews.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigtable.logicalViews.list</code></p>
<p><code translate="no" dir="ltr">bigtable.logicalViews.readRows</code></p>
<p><code translate="no" dir="ltr">bigtable.logicalViews.update</code></p>
<p><code translate="no" dir="ltr">bigtable.materializedViews.create</code></p>
<p><code translate="no" dir="ltr">bigtable.materializedViews.delete</code></p>
<p><code translate="no" dir="ltr">bigtable.materializedViews.get</code></p>
<p><code translate="no" dir="ltr">bigtable.materializedViews.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigtable.materializedViews.list</code></p>
<p><code translate="no" dir="ltr">bigtable.materializedViews.readRows</code></p>
<p><code translate="no" dir="ltr">bigtable.materializedViews.sampleRowKeys</code></p>
<p><code translate="no" dir="ltr">bigtable.materializedViews.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigtable.memoryLayers.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigtable.memoryLayers.get</code></li>
<li><code translate="no" dir="ltr">bigtable.memoryLayers.list</code></li>
<li><code translate="no" dir="ltr">bigtable.memoryLayers.update</code></li>
</ul>
<p><code translate="no" dir="ltr">bigtable.schemaBundles.create</code></p>
<p><code translate="no" dir="ltr">bigtable.schemaBundles.delete</code></p>
<p><code translate="no" dir="ltr">bigtable.schemaBundles.get</code></p>
<p><code translate="no" dir="ltr">bigtable.schemaBundles.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigtable.schemaBundles.list</code></p>
<p><code translate="no" dir="ltr">bigtable.schemaBundles.update</code></p>
<p><code translate="no" dir="ltr">bigtable.tables.checkConsistency</code></p>
<p><code translate="no" dir="ltr">bigtable.tables.create</code></p>
<p><code translate="no" dir="ltr">bigtable.tables.delete</code></p>
<p><code translate="no" dir="ltr">bigtable.tables.generateConsistencyToken</code></p>
<p><code translate="no" dir="ltr">bigtable.tables.get</code></p>
<p><code translate="no" dir="ltr">bigtable.tables.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigtable.tables.list</code></p>
<p><code translate="no" dir="ltr">bigtable.tables.mutateRows</code></p>
<p><code translate="no" dir="ltr">bigtable.tables.readRows</code></p>
<p><code translate="no" dir="ltr">bigtable.tables.sampleRowKeys</code></p>
<p><code translate="no" dir="ltr">bigtable.tables.undelete</code></p>
<p><code translate="no" dir="ltr">bigtable.tables.update</code></p>
<p><code translate="no" dir="ltr">monitoring.metricDescriptors.get</code></p>
<p><code translate="no" dir="ltr">monitoring.metricDescriptors.list</code></p>
<p><code translate="no" dir="ltr">monitoring.timeSeries.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="bigtable.user" class="role-title add-link" data-text="Bigtable User " tabindex="-1">Bigtable User</h4>
<p>(<code translate="no" dir="ltr">roles/bigtable.user</code>)</p>
<span class="role-description custom"> </span>
<p>Provides read-write access to the data stored within Bigtable tables. Intended for application developers or service accounts.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Table</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">bigtable.appProfiles.get</code></p>
<p><code translate="no" dir="ltr">bigtable.appProfiles.list</code></p>
<p><code translate="no" dir="ltr">bigtable.authorizedViews.get</code></p>
<p><code translate="no" dir="ltr">bigtable.authorizedViews.list</code></p>
<p><code translate="no" dir="ltr">bigtable.authorizedViews.mutateRows</code></p>
<p><code translate="no" dir="ltr">bigtable.authorizedViews.readRows</code></p>
<p><code translate="no" dir="ltr">bigtable.authorizedViews.sampleRowKeys</code></p>
<p><code translate="no" dir="ltr">bigtable.backups.get</code></p>
<p><code translate="no" dir="ltr">bigtable.backups.list</code></p>
<p><code translate="no" dir="ltr">bigtable.clusters.get</code></p>
<p><code translate="no" dir="ltr">bigtable.clusters.list</code></p>
<p><code translate="no" dir="ltr">bigtable.hotTablets.list</code></p>
<p><code translate="no" dir="ltr">bigtable.instances.executeQuery</code></p>
<p><code translate="no" dir="ltr">bigtable.instances.get</code></p>
<p><code translate="no" dir="ltr">bigtable.instances.list</code></p>
<p><code translate="no" dir="ltr">bigtable.instances.ping</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigtable.keyvisualizer.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigtable.keyvisualizer.get</code></li>
<li><code translate="no" dir="ltr">bigtable.keyvisualizer.list</code></li>
</ul>
<p><code translate="no" dir="ltr">bigtable.locations.list</code></p>
<p><code translate="no" dir="ltr">bigtable.logicalViews.get</code></p>
<p><code translate="no" dir="ltr">bigtable.logicalViews.list</code></p>
<p><code translate="no" dir="ltr">bigtable.logicalViews.readRows</code></p>
<p><code translate="no" dir="ltr">bigtable.materializedViews.get</code></p>
<p><code translate="no" dir="ltr">bigtable.materializedViews.list</code></p>
<p><code translate="no" dir="ltr">bigtable.materializedViews.readRows</code></p>
<p><code translate="no" dir="ltr">bigtable.materializedViews.sampleRowKeys</code></p>
<p><code translate="no" dir="ltr">bigtable.memoryLayers.get</code></p>
<p><code translate="no" dir="ltr">bigtable.memoryLayers.list</code></p>
<p><code translate="no" dir="ltr">bigtable.schemaBundles.get</code></p>
<p><code translate="no" dir="ltr">bigtable.schemaBundles.list</code></p>
<p><code translate="no" dir="ltr">bigtable.tables.checkConsistency</code></p>
<p><code translate="no" dir="ltr">bigtable.tables.generateConsistencyToken</code></p>
<p><code translate="no" dir="ltr">bigtable.tables.get</code></p>
<p><code translate="no" dir="ltr">bigtable.tables.list</code></p>
<p><code translate="no" dir="ltr">bigtable.tables.mutateRows</code></p>
<p><code translate="no" dir="ltr">bigtable.tables.readRows</code></p>
<p><code translate="no" dir="ltr">bigtable.tables.sampleRowKeys</code></p>
<p><code translate="no" dir="ltr">monitoring.metricDescriptors.get</code></p>
<p><code translate="no" dir="ltr">monitoring.metricDescriptors.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">monitoring.timeSeries.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">monitoring.timeSeries.create</code></li>
<li><code translate="no" dir="ltr">monitoring.timeSeries.list</code></li>
</ul>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="bigtable.viewer" class="role-title add-link" data-text="Bigtable Viewer " tabindex="-1">Bigtable Viewer</h4>
<p>(<code translate="no" dir="ltr">roles/bigtable.viewer</code>)</p>
<span class="role-description custom"> </span>
<p>Provides no data access. Intended as a minimal set of permissions to access the Google Cloud console for Bigtable.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Table</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">bigtable.appProfiles.get</code></p>
<p><code translate="no" dir="ltr">bigtable.appProfiles.list</code></p>
<p><code translate="no" dir="ltr">bigtable.authorizedViews.get</code></p>
<p><code translate="no" dir="ltr">bigtable.authorizedViews.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigtable.authorizedViews.list</code></p>
<p><code translate="no" dir="ltr">bigtable.authorizedViews.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">bigtable.authorizedViews.listTagBindings</code></p>
<p><code translate="no" dir="ltr">bigtable.backups.get</code></p>
<p><code translate="no" dir="ltr">bigtable.backups.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigtable.backups.list</code></p>
<p><code translate="no" dir="ltr">bigtable.clusters.get</code></p>
<p><code translate="no" dir="ltr">bigtable.clusters.list</code></p>
<p><code translate="no" dir="ltr">bigtable.hotTablets.list</code></p>
<p><code translate="no" dir="ltr">bigtable.instances.get</code></p>
<p><code translate="no" dir="ltr">bigtable.instances.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigtable.instances.list</code></p>
<p><code translate="no" dir="ltr">bigtable.instances.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">bigtable.instances.listTagBindings</code></p>
<p><code translate="no" dir="ltr">bigtable.locations.list</code></p>
<p><code translate="no" dir="ltr">bigtable.logicalViews.get</code></p>
<p><code translate="no" dir="ltr">bigtable.logicalViews.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigtable.logicalViews.list</code></p>
<p><code translate="no" dir="ltr">bigtable.materializedViews.get</code></p>
<p><code translate="no" dir="ltr">bigtable.materializedViews.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigtable.materializedViews.list</code></p>
<p><code translate="no" dir="ltr">bigtable.memoryLayers.get</code></p>
<p><code translate="no" dir="ltr">bigtable.memoryLayers.list</code></p>
<p><code translate="no" dir="ltr">bigtable.schemaBundles.get</code></p>
<p><code translate="no" dir="ltr">bigtable.schemaBundles.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigtable.schemaBundles.list</code></p>
<p><code translate="no" dir="ltr">bigtable.tables.checkConsistency</code></p>
<p><code translate="no" dir="ltr">bigtable.tables.generateConsistencyToken</code></p>
<p><code translate="no" dir="ltr">bigtable.tables.get</code></p>
<p><code translate="no" dir="ltr">bigtable.tables.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigtable.tables.list</code></p>
<p><code translate="no" dir="ltr">monitoring.metricDescriptors.get</code></p>
<p><code translate="no" dir="ltr">monitoring.metricDescriptors.list</code></p>
<p><code translate="no" dir="ltr">monitoring.timeSeries.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="bigtable.reader" class="role-title add-link" data-text="Bigtable Reader " tabindex="-1">Bigtable Reader</h4>
<p>(<code translate="no" dir="ltr">roles/bigtable.reader</code>)</p>
<span class="role-description custom"> </span>
<p>Provides read-only access to the data stored within Bigtable tables. Intended for data scientists, dashboard generators, and other data-analysis scenarios.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Table</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">bigtable.appProfiles.get</code></p>
<p><code translate="no" dir="ltr">bigtable.appProfiles.list</code></p>
<p><code translate="no" dir="ltr">bigtable.authorizedViews.get</code></p>
<p><code translate="no" dir="ltr">bigtable.authorizedViews.list</code></p>
<p><code translate="no" dir="ltr">bigtable.authorizedViews.readRows</code></p>
<p><code translate="no" dir="ltr">bigtable.authorizedViews.sampleRowKeys</code></p>
<p><code translate="no" dir="ltr">bigtable.backups.get</code></p>
<p><code translate="no" dir="ltr">bigtable.backups.list</code></p>
<p><code translate="no" dir="ltr">bigtable.clusters.get</code></p>
<p><code translate="no" dir="ltr">bigtable.clusters.list</code></p>
<p><code translate="no" dir="ltr">bigtable.hotTablets.list</code></p>
<p><code translate="no" dir="ltr">bigtable.instances.executeQuery</code></p>
<p><code translate="no" dir="ltr">bigtable.instances.get</code></p>
<p><code translate="no" dir="ltr">bigtable.instances.list</code></p>
<p><code translate="no" dir="ltr">bigtable.instances.ping</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigtable.keyvisualizer.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigtable.keyvisualizer.get</code></li>
<li><code translate="no" dir="ltr">bigtable.keyvisualizer.list</code></li>
</ul>
<p><code translate="no" dir="ltr">bigtable.locations.list</code></p>
<p><code translate="no" dir="ltr">bigtable.logicalViews.get</code></p>
<p><code translate="no" dir="ltr">bigtable.logicalViews.list</code></p>
<p><code translate="no" dir="ltr">bigtable.logicalViews.readRows</code></p>
<p><code translate="no" dir="ltr">bigtable.materializedViews.get</code></p>
<p><code translate="no" dir="ltr">bigtable.materializedViews.list</code></p>
<p><code translate="no" dir="ltr">bigtable.materializedViews.readRows</code></p>
<p><code translate="no" dir="ltr">bigtable.materializedViews.sampleRowKeys</code></p>
<p><code translate="no" dir="ltr">bigtable.memoryLayers.get</code></p>
<p><code translate="no" dir="ltr">bigtable.memoryLayers.list</code></p>
<p><code translate="no" dir="ltr">bigtable.schemaBundles.get</code></p>
<p><code translate="no" dir="ltr">bigtable.schemaBundles.list</code></p>
<p><code translate="no" dir="ltr">bigtable.tables.checkConsistency</code></p>
<p><code translate="no" dir="ltr">bigtable.tables.generateConsistencyToken</code></p>
<p><code translate="no" dir="ltr">bigtable.tables.get</code></p>
<p><code translate="no" dir="ltr">bigtable.tables.list</code></p>
<p><code translate="no" dir="ltr">bigtable.tables.readRows</code></p>
<p><code translate="no" dir="ltr">bigtable.tables.sampleRowKeys</code></p>
<p><code translate="no" dir="ltr">monitoring.metricDescriptors.get</code></p>
<p><code translate="no" dir="ltr">monitoring.metricDescriptors.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">monitoring.timeSeries.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">monitoring.timeSeries.create</code></li>
<li><code translate="no" dir="ltr">monitoring.timeSeries.list</code></li>
</ul>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p></td>
</tr>
</tbody>
</table>

## Bigtable permissions

<div results-count-container="">

</div>

<table class="permissions-table fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="45%">Permission</th>
<th>Included in roles</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td><h4 id="bigtable.appProfiles.create" class="permission-name add-link" data-text="bigtable.appProfiles.create" tabindex="-1"><code translate="no" dir="ltr">bigtable.appProfiles.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigtable.appProfiles.delete" class="permission-name add-link" data-text="bigtable.appProfiles.delete" tabindex="-1"><code translate="no" dir="ltr">bigtable.appProfiles.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigtable.appProfiles.get" class="permission-name add-link" data-text="bigtable.appProfiles.get" tabindex="-1"><code translate="no" dir="ltr">bigtable.appProfiles.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.user">Bigtable User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.viewer">Bigtable Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.reader">Bigtable Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigtable.appProfiles.list" class="permission-name add-link" data-text="bigtable.appProfiles.list" tabindex="-1"><code translate="no" dir="ltr">bigtable.appProfiles.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.user">Bigtable User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.viewer">Bigtable Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.reader">Bigtable Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/databaseinsights#databaseinsights.serviceAgent">Database Insights Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/databaseinsights.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigtable.appProfiles.update" class="permission-name add-link" data-text="bigtable.appProfiles.update" tabindex="-1"><code translate="no" dir="ltr">bigtable.appProfiles.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigtable.authorizedViews.create" class="permission-name add-link" data-text="bigtable.authorizedViews.create" tabindex="-1"><code translate="no" dir="ltr">bigtable.authorizedViews.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigtable.authorizedViews.createTagBinding" class="permission-name add-link" data-text="bigtable.authorizedViews.createTagBinding" tabindex="-1"><code translate="no" dir="ltr">bigtable.authorizedViews.createTagBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigtable.authorizedViews.delete" class="permission-name add-link" data-text="bigtable.authorizedViews.delete" tabindex="-1"><code translate="no" dir="ltr">bigtable.authorizedViews.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigtable.authorizedViews.deleteTagBinding" class="permission-name add-link" data-text="bigtable.authorizedViews.deleteTagBinding" tabindex="-1"><code translate="no" dir="ltr">bigtable.authorizedViews.deleteTagBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigtable.authorizedViews.get" class="permission-name add-link" data-text="bigtable.authorizedViews.get" tabindex="-1"><code translate="no" dir="ltr">bigtable.authorizedViews.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.user">Bigtable User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.viewer">Bigtable Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.reader">Bigtable Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigtable.authorizedViews.getIamPolicy" class="permission-name add-link" data-text="bigtable.authorizedViews.getIamPolicy" tabindex="-1"><code translate="no" dir="ltr">bigtable.authorizedViews.getIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.viewer">Bigtable Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigtable.authorizedViews.list" class="permission-name add-link" data-text="bigtable.authorizedViews.list" tabindex="-1"><code translate="no" dir="ltr">bigtable.authorizedViews.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.user">Bigtable User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.viewer">Bigtable Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.reader">Bigtable Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigtable.authorizedViews.listEffectiveTags" class="permission-name add-link" data-text="bigtable.authorizedViews.listEffectiveTags" tabindex="-1"><code translate="no" dir="ltr">bigtable.authorizedViews.listEffectiveTags</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.viewer">Bigtable Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagViewer">Tag Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigtable.authorizedViews.listTagBindings" class="permission-name add-link" data-text="bigtable.authorizedViews.listTagBindings" tabindex="-1"><code translate="no" dir="ltr">bigtable.authorizedViews.listTagBindings</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.viewer">Bigtable Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagViewer">Tag Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigtable.authorizedViews.mutateRows" class="permission-name add-link" data-text="bigtable.authorizedViews.mutateRows" tabindex="-1"><code translate="no" dir="ltr">bigtable.authorizedViews.mutateRows</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.user">Bigtable User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigtable.authorizedViews.readRows" class="permission-name add-link" data-text="bigtable.authorizedViews.readRows" tabindex="-1"><code translate="no" dir="ltr">bigtable.authorizedViews.readRows</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.user">Bigtable User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.reader">Bigtable Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigtable.authorizedViews.sampleRowKeys" class="permission-name add-link" data-text="bigtable.authorizedViews.sampleRowKeys" tabindex="-1"><code translate="no" dir="ltr">bigtable.authorizedViews.sampleRowKeys</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.user">Bigtable User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.reader">Bigtable Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigtable.authorizedViews.setIamPolicy" class="permission-name add-link" data-text="bigtable.authorizedViews.setIamPolicy" tabindex="-1"><code translate="no" dir="ltr">bigtable.authorizedViews.setIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigtable.authorizedViews.update" class="permission-name add-link" data-text="bigtable.authorizedViews.update" tabindex="-1"><code translate="no" dir="ltr">bigtable.authorizedViews.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigtable.backups.create" class="permission-name add-link" data-text="bigtable.backups.create" tabindex="-1"><code translate="no" dir="ltr">bigtable.backups.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigtable.backups.delete" class="permission-name add-link" data-text="bigtable.backups.delete" tabindex="-1"><code translate="no" dir="ltr">bigtable.backups.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigtable.backups.get" class="permission-name add-link" data-text="bigtable.backups.get" tabindex="-1"><code translate="no" dir="ltr">bigtable.backups.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.user">Bigtable User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.viewer">Bigtable Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.reader">Bigtable Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigtable.backups.getIamPolicy" class="permission-name add-link" data-text="bigtable.backups.getIamPolicy" tabindex="-1"><code translate="no" dir="ltr">bigtable.backups.getIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.viewer">Bigtable Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigtable.backups.list" class="permission-name add-link" data-text="bigtable.backups.list" tabindex="-1"><code translate="no" dir="ltr">bigtable.backups.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.user">Bigtable User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.viewer">Bigtable Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.reader">Bigtable Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/databaseinsights#databaseinsights.serviceAgent">Database Insights Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/databaseinsights.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigtable.backups.read" class="permission-name add-link" data-text="bigtable.backups.read" tabindex="-1"><code translate="no" dir="ltr">bigtable.backups.read</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigtable.backups.restore" class="permission-name add-link" data-text="bigtable.backups.restore" tabindex="-1"><code translate="no" dir="ltr">bigtable.backups.restore</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigtable.backups.setIamPolicy" class="permission-name add-link" data-text="bigtable.backups.setIamPolicy" tabindex="-1"><code translate="no" dir="ltr">bigtable.backups.setIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigtable.backups.update" class="permission-name add-link" data-text="bigtable.backups.update" tabindex="-1"><code translate="no" dir="ltr">bigtable.backups.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigtable.clusters.create" class="permission-name add-link" data-text="bigtable.clusters.create" tabindex="-1"><code translate="no" dir="ltr">bigtable.clusters.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigtable.clusters.delete" class="permission-name add-link" data-text="bigtable.clusters.delete" tabindex="-1"><code translate="no" dir="ltr">bigtable.clusters.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigtable.clusters.get" class="permission-name add-link" data-text="bigtable.clusters.get" tabindex="-1"><code translate="no" dir="ltr">bigtable.clusters.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.user">Bigtable User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.viewer">Bigtable Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.reader">Bigtable Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/databaseinsights#databaseinsights.serviceAgent">Database Insights Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/databaseinsights.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigtable.clusters.list" class="permission-name add-link" data-text="bigtable.clusters.list" tabindex="-1"><code translate="no" dir="ltr">bigtable.clusters.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.user">Bigtable User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.viewer">Bigtable Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.reader">Bigtable Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/databaseinsights#databaseinsights.serviceAgent">Database Insights Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/databaseinsights.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigtable.clusters.update" class="permission-name add-link" data-text="bigtable.clusters.update" tabindex="-1"><code translate="no" dir="ltr">bigtable.clusters.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigtable.hotTablets.list" class="permission-name add-link" data-text="bigtable.hotTablets.list" tabindex="-1"><code translate="no" dir="ltr">bigtable.hotTablets.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.user">Bigtable User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.viewer">Bigtable Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.reader">Bigtable Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigtable.instances.create" class="permission-name add-link" data-text="bigtable.instances.create" tabindex="-1"><code translate="no" dir="ltr">bigtable.instances.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigtable.instances.createTagBinding" class="permission-name add-link" data-text="bigtable.instances.createTagBinding" tabindex="-1"><code translate="no" dir="ltr">bigtable.instances.createTagBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigtable.instances.delete" class="permission-name add-link" data-text="bigtable.instances.delete" tabindex="-1"><code translate="no" dir="ltr">bigtable.instances.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigtable.instances.deleteTagBinding" class="permission-name add-link" data-text="bigtable.instances.deleteTagBinding" tabindex="-1"><code translate="no" dir="ltr">bigtable.instances.deleteTagBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigtable.instances.executeQuery" class="permission-name add-link" data-text="bigtable.instances.executeQuery" tabindex="-1"><code translate="no" dir="ltr">bigtable.instances.executeQuery</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.user">Bigtable User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.reader">Bigtable Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigtable.instances.get" class="permission-name add-link" data-text="bigtable.instances.get" tabindex="-1"><code translate="no" dir="ltr">bigtable.instances.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.user">Bigtable User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.viewer">Bigtable Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.reader">Bigtable Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/databaseinsights#databaseinsights.serviceAgent">Database Insights Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/databaseinsights.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigtable.instances.getIamPolicy" class="permission-name add-link" data-text="bigtable.instances.getIamPolicy" tabindex="-1"><code translate="no" dir="ltr">bigtable.instances.getIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.viewer">Bigtable Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigtable.instances.list" class="permission-name add-link" data-text="bigtable.instances.list" tabindex="-1"><code translate="no" dir="ltr">bigtable.instances.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.user">Bigtable User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.viewer">Bigtable Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.reader">Bigtable Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/databaseinsights#databaseinsights.serviceAgent">Database Insights Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/databaseinsights.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigtable.instances.listEffectiveTags" class="permission-name add-link" data-text="bigtable.instances.listEffectiveTags" tabindex="-1"><code translate="no" dir="ltr">bigtable.instances.listEffectiveTags</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.viewer">Bigtable Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagViewer">Tag Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigtable.instances.listTagBindings" class="permission-name add-link" data-text="bigtable.instances.listTagBindings" tabindex="-1"><code translate="no" dir="ltr">bigtable.instances.listTagBindings</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.viewer">Bigtable Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagViewer">Tag Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigtable.instances.ping" class="permission-name add-link" data-text="bigtable.instances.ping" tabindex="-1"><code translate="no" dir="ltr">bigtable.instances.ping</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.user">Bigtable User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.reader">Bigtable Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigtable.instances.setIamPolicy" class="permission-name add-link" data-text="bigtable.instances.setIamPolicy" tabindex="-1"><code translate="no" dir="ltr">bigtable.instances.setIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigtable.instances.update" class="permission-name add-link" data-text="bigtable.instances.update" tabindex="-1"><code translate="no" dir="ltr">bigtable.instances.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigtable.keyvisualizer.get" class="permission-name add-link" data-text="bigtable.keyvisualizer.get" tabindex="-1"><code translate="no" dir="ltr">bigtable.keyvisualizer.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.user">Bigtable User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.reader">Bigtable Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigtable.keyvisualizer.list" class="permission-name add-link" data-text="bigtable.keyvisualizer.list" tabindex="-1"><code translate="no" dir="ltr">bigtable.keyvisualizer.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.user">Bigtable User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.reader">Bigtable Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigtable.locations.list" class="permission-name add-link" data-text="bigtable.locations.list" tabindex="-1"><code translate="no" dir="ltr">bigtable.locations.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.user">Bigtable User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.viewer">Bigtable Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.reader">Bigtable Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/databaseinsights#databaseinsights.serviceAgent">Database Insights Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/databaseinsights.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigtable.logicalViews.create" class="permission-name add-link" data-text="bigtable.logicalViews.create" tabindex="-1"><code translate="no" dir="ltr">bigtable.logicalViews.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigtable.logicalViews.delete" class="permission-name add-link" data-text="bigtable.logicalViews.delete" tabindex="-1"><code translate="no" dir="ltr">bigtable.logicalViews.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigtable.logicalViews.get" class="permission-name add-link" data-text="bigtable.logicalViews.get" tabindex="-1"><code translate="no" dir="ltr">bigtable.logicalViews.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.user">Bigtable User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.viewer">Bigtable Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.reader">Bigtable Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigtable.logicalViews.getIamPolicy" class="permission-name add-link" data-text="bigtable.logicalViews.getIamPolicy" tabindex="-1"><code translate="no" dir="ltr">bigtable.logicalViews.getIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.viewer">Bigtable Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigtable.logicalViews.list" class="permission-name add-link" data-text="bigtable.logicalViews.list" tabindex="-1"><code translate="no" dir="ltr">bigtable.logicalViews.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.user">Bigtable User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.viewer">Bigtable Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.reader">Bigtable Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigtable.logicalViews.readRows" class="permission-name add-link" data-text="bigtable.logicalViews.readRows" tabindex="-1"><code translate="no" dir="ltr">bigtable.logicalViews.readRows</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.user">Bigtable User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.reader">Bigtable Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigtable.logicalViews.setIamPolicy" class="permission-name add-link" data-text="bigtable.logicalViews.setIamPolicy" tabindex="-1"><code translate="no" dir="ltr">bigtable.logicalViews.setIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigtable.logicalViews.update" class="permission-name add-link" data-text="bigtable.logicalViews.update" tabindex="-1"><code translate="no" dir="ltr">bigtable.logicalViews.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigtable.materializedViews.create" class="permission-name add-link" data-text="bigtable.materializedViews.create" tabindex="-1"><code translate="no" dir="ltr">bigtable.materializedViews.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigtable.materializedViews.delete" class="permission-name add-link" data-text="bigtable.materializedViews.delete" tabindex="-1"><code translate="no" dir="ltr">bigtable.materializedViews.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigtable.materializedViews.get" class="permission-name add-link" data-text="bigtable.materializedViews.get" tabindex="-1"><code translate="no" dir="ltr">bigtable.materializedViews.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.user">Bigtable User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.viewer">Bigtable Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.reader">Bigtable Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigtable.materializedViews.getIamPolicy" class="permission-name add-link" data-text="bigtable.materializedViews.getIamPolicy" tabindex="-1"><code translate="no" dir="ltr">bigtable.materializedViews.getIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.viewer">Bigtable Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigtable.materializedViews.list" class="permission-name add-link" data-text="bigtable.materializedViews.list" tabindex="-1"><code translate="no" dir="ltr">bigtable.materializedViews.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.user">Bigtable User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.viewer">Bigtable Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.reader">Bigtable Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigtable.materializedViews.readRows" class="permission-name add-link" data-text="bigtable.materializedViews.readRows" tabindex="-1"><code translate="no" dir="ltr">bigtable.materializedViews.readRows</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.user">Bigtable User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.reader">Bigtable Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigtable.materializedViews.sampleRowKeys" class="permission-name add-link" data-text="bigtable.materializedViews.sampleRowKeys" tabindex="-1"><code translate="no" dir="ltr">bigtable.materializedViews.sampleRowKeys</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.user">Bigtable User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.reader">Bigtable Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigtable.materializedViews.setIamPolicy" class="permission-name add-link" data-text="bigtable.materializedViews.setIamPolicy" tabindex="-1"><code translate="no" dir="ltr">bigtable.materializedViews.setIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigtable.materializedViews.update" class="permission-name add-link" data-text="bigtable.materializedViews.update" tabindex="-1"><code translate="no" dir="ltr">bigtable.materializedViews.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigtable.memoryLayers.get" class="permission-name add-link" data-text="bigtable.memoryLayers.get" tabindex="-1"><code translate="no" dir="ltr">bigtable.memoryLayers.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.user">Bigtable User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.viewer">Bigtable Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.reader">Bigtable Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigtable.memoryLayers.list" class="permission-name add-link" data-text="bigtable.memoryLayers.list" tabindex="-1"><code translate="no" dir="ltr">bigtable.memoryLayers.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.user">Bigtable User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.viewer">Bigtable Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.reader">Bigtable Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigtable.memoryLayers.update" class="permission-name add-link" data-text="bigtable.memoryLayers.update" tabindex="-1"><code translate="no" dir="ltr">bigtable.memoryLayers.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigtable.schemaBundles.create" class="permission-name add-link" data-text="bigtable.schemaBundles.create" tabindex="-1"><code translate="no" dir="ltr">bigtable.schemaBundles.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigtable.schemaBundles.delete" class="permission-name add-link" data-text="bigtable.schemaBundles.delete" tabindex="-1"><code translate="no" dir="ltr">bigtable.schemaBundles.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigtable.schemaBundles.get" class="permission-name add-link" data-text="bigtable.schemaBundles.get" tabindex="-1"><code translate="no" dir="ltr">bigtable.schemaBundles.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.user">Bigtable User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.viewer">Bigtable Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.reader">Bigtable Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigtable.schemaBundles.getIamPolicy" class="permission-name add-link" data-text="bigtable.schemaBundles.getIamPolicy" tabindex="-1"><code translate="no" dir="ltr">bigtable.schemaBundles.getIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.viewer">Bigtable Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigtable.schemaBundles.list" class="permission-name add-link" data-text="bigtable.schemaBundles.list" tabindex="-1"><code translate="no" dir="ltr">bigtable.schemaBundles.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.user">Bigtable User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.viewer">Bigtable Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.reader">Bigtable Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigtable.schemaBundles.setIamPolicy" class="permission-name add-link" data-text="bigtable.schemaBundles.setIamPolicy" tabindex="-1"><code translate="no" dir="ltr">bigtable.schemaBundles.setIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigtable.schemaBundles.update" class="permission-name add-link" data-text="bigtable.schemaBundles.update" tabindex="-1"><code translate="no" dir="ltr">bigtable.schemaBundles.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigtable.tables.checkConsistency" class="permission-name add-link" data-text="bigtable.tables.checkConsistency" tabindex="-1"><code translate="no" dir="ltr">bigtable.tables.checkConsistency</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.user">Bigtable User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.viewer">Bigtable Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.reader">Bigtable Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigtable.tables.create" class="permission-name add-link" data-text="bigtable.tables.create" tabindex="-1"><code translate="no" dir="ltr">bigtable.tables.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigtable.tables.delete" class="permission-name add-link" data-text="bigtable.tables.delete" tabindex="-1"><code translate="no" dir="ltr">bigtable.tables.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigtable.tables.generateConsistencyToken" class="permission-name add-link" data-text="bigtable.tables.generateConsistencyToken" tabindex="-1"><code translate="no" dir="ltr">bigtable.tables.generateConsistencyToken</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.user">Bigtable User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.viewer">Bigtable Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.reader">Bigtable Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigtable.tables.get" class="permission-name add-link" data-text="bigtable.tables.get" tabindex="-1"><code translate="no" dir="ltr">bigtable.tables.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.user">Bigtable User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.viewer">Bigtable Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.reader">Bigtable Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/automl#automl.serviceAgent">AutoML Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/databaseinsights#databaseinsights.serviceAgent">Database Insights Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/databaseinsights.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visionai#visionai.serviceAgent">Cloud Vision AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visionai.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigtable.tables.getIamPolicy" class="permission-name add-link" data-text="bigtable.tables.getIamPolicy" tabindex="-1"><code translate="no" dir="ltr">bigtable.tables.getIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.viewer">Bigtable Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigtable.tables.list" class="permission-name add-link" data-text="bigtable.tables.list" tabindex="-1"><code translate="no" dir="ltr">bigtable.tables.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.user">Bigtable User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.viewer">Bigtable Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.reader">Bigtable Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/automl#automl.serviceAgent">AutoML Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/databaseinsights#databaseinsights.serviceAgent">Database Insights Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/databaseinsights.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visionai#visionai.serviceAgent">Cloud Vision AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visionai.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigtable.tables.mutateRows" class="permission-name add-link" data-text="bigtable.tables.mutateRows" tabindex="-1"><code translate="no" dir="ltr">bigtable.tables.mutateRows</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.user">Bigtable User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigtable.tables.readRows" class="permission-name add-link" data-text="bigtable.tables.readRows" tabindex="-1"><code translate="no" dir="ltr">bigtable.tables.readRows</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.user">Bigtable User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.reader">Bigtable Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/automl#automl.serviceAgent">AutoML Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.serviceAgent">Discovery Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visionai#visionai.serviceAgent">Cloud Vision AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visionai.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigtable.tables.sampleRowKeys" class="permission-name add-link" data-text="bigtable.tables.sampleRowKeys" tabindex="-1"><code translate="no" dir="ltr">bigtable.tables.sampleRowKeys</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.user">Bigtable User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.reader">Bigtable Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.serviceAgent">Discovery Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigtable.tables.setIamPolicy" class="permission-name add-link" data-text="bigtable.tables.setIamPolicy" tabindex="-1"><code translate="no" dir="ltr">bigtable.tables.setIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigtable.tables.undelete" class="permission-name add-link" data-text="bigtable.tables.undelete" tabindex="-1"><code translate="no" dir="ltr">bigtable.tables.undelete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigtable.tables.update" class="permission-name add-link" data-text="bigtable.tables.update" tabindex="-1"><code translate="no" dir="ltr">bigtable.tables.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
</ul></td>
</tr>
</tbody>
</table>

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
