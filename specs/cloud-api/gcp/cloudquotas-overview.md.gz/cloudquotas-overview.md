# Cloud Quotas overview

<div class="devsite-article-body clearfix">

Google Cloud uses quotas to help maintain fairness and reduce spikes in resource use and availability. A quota restricts how much of a Google Cloud resource your Google Cloud project can use. Quotas apply to a range of resource types, including hardware, software, and network components. For example, quotas can restrict the number of API calls to a service, the number of load balancers used concurrently by your project, or the number of projects that you can create. Quotas protect the community of Google Cloud users by preventing the overloading of services. Quotas also help you to manage your own Google Cloud resources.

The Cloud Quotas system does the following:

- Monitors your consumption of Google Cloud products and services
- Restricts your consumption of those resources
- Provides a way to [request changes to the quota value](/docs/quotas/help/request_increase) and [automate quota adjustments](/docs/quotas/quota-adjuster)

In most cases, when you attempt to consume more of a resource than its quota allows, the system blocks access to the resource, and the task that you're trying to perform fails.

Quotas generally apply at the Google Cloud project level. Your use of a resource in one project doesn't affect your available quota in another project. Within a Google Cloud project, quotas are shared across all applications and IP addresses.

Many services also have system limits. System limits are fixed constraints, such as maximum file sizes or database schema limitations, which cannot be increased or decreased.

To learn about the quotas and system limits for a product, see the product's quotas and limits page—for example, <a href="/storage/quotas" data-track-type="quotas" data-track-name="quotaLink" data-track-metadata-position="body" data-track-metadata-end-goal="viewQuota">Cloud Storage quotas and limits</a>.

The following links provide additional information related to resource usage:

- For resource pricing, see the product's pricing documentation—for example, <a href="https://cloud.google.com/storage/pricing" data-track-type="quotas" data-track-name="pricingInfo" data-track-metadata-position="body" data-track-metadata-end-goal="viewResources">Cloud Storage pricing</a>
- To generate a cost estimate based on your projected usage, use the [pricing calculator](https://cloud.google.com/products/calculator)
- For other API usage metrics, see <a href="/apis/docs/monitoring" data-track-type="quotas" data-track-name="apiExplorer" data-track-metadata-position="body" data-track-metadata-end-goal="viewResources">Monitoring API usage</a>
- If you are a new Google Cloud user, you might be eligible for a <a href="https://cloud.google.com/free/" data-track-type="freeTrial" data-track-name="consoleLink" data-track-metadata-position="prerequisites" data-track-metadata-end-goal="signUp">Free Trial</a>

## Types of quotas

Google Cloud has three types of quotas:

- **Allocation quotas**: Allocation quotas restrict how much of a resource Google Cloud allocates to you. For example, Compute Engine applies an allocation quota to the number of VMs allocated for a Google Cloud project.

- **Rate quotas**: Rate quotas restrict the rate at which you can consume a resource. Rate quotas specify a time period, and the amount of the resource that you are permitted to consume over that time period.

- **Concurrent quotas**: Concurrent quotas restrict the number of operations that run concurrently. Concurrent quotas usually apply to long-running operations. For example, some Compute Engine `insert` operations can run for as long as one hour and are limited by a concurrent quota.

## Quotas and the Google Cloud hierarchy

Most quotas apply to one of the following levels of the Google Cloud [hierarchy](/resource-manager/docs/cloud-platform-resource-hierarchy):

- **Project-level quotas**: Project-level quotas restrict your resource usage within a Google Cloud project. Using the resource in one project doesn't affect your available quota in another project.

- **Folder-level quotas**: Folder-level quotas restrict your resource usage within a Google Cloud folder. Child folders and projects contribute to your quota usage. Folders and projects outside of your folder don't affect your available quota.

- **Organization-level quotas**: Organization-level quotas restrict your resource usage within a Google Cloud organization. Child folders and projects contribute to your quota usage. Resource usage outside of your organization doesn't affect your available quota.

For example, the Compute Engine API has a project-level quota for the number of queries you can make per minute. If one project reaches the quota value in less than a minute, the project cannot make any more queries. Other projects can continue to make queries.

Some quotas apply at the user level. For example, the number of Google Cloud projects you can create is limited by a quota applied at the level of the user or service account.

To identify the Google Cloud hierarchy level of the quotas for your product, see the product's quotas and limits page—for example, <a href="/storage/quotas" data-track-type="quotas" data-track-name="quotaLink" data-track-metadata-position="body" data-track-metadata-end-goal="viewQuota">Cloud Storage quotas and limits</a>.

## Regions and zones

Quotas are global, [regional, or zonal](/compute/docs/regions-zones):

- **Global**: Global quotas restrict resource usage across all regions and zones. Resource usage in one region or zone reduces quota availability for all regions and zones.
- **Regional**: Regional quotas restrict resource usage in a Google Cloud region. Resource use in any zone in the region contributes to regional quota use. Resource usage in one region doesn't affect available quota in another region.
- **Zonal**: Zonal quotas restrict resource usage in a Google Cloud zone. Resource usage in one zone doesn't affect available zonal quota in another zone. If the resource is also subject to a regional quota, usage in one zone affects available quota in other zones by reducing the regional quota shared across zones, even though the zonal quota for other zones is unaffected.

Some resources have multiple location-based quotas. For example, a resource might have both a regional quota and a zonal quota. The zonal quota restricts the amount of use in each zone. The regional quota restricts the total use across all zones in a given region. To find out whether a quota is regional, zonal, or global, follow the instructions to [view dimensions](/docs/quotas/configure-dimensions#view_dimensions).

Regions and zones are examples of quota dimensions. For more information about working with dimensions, see [Configure dimensions](/docs/quotas/configure-dimensions).

## Manage quota values

Managing quota values and planning your resource use accordingly helps prevent errors. Quota values are specific to your project, folder, and organization. For example, you might request an adjustment to the value of a quota in one project, but continue to use the default value in another project. If you're using a <a href="/free/docs/frequently-asked-questions#limitations" data-track-type="quotas" data-track-name="freeTrialLink" data-track-metadata-position="body" data-track-metadata-end-goal="viewQuota">free trial account</a>, you might have lower quota values for some resources compared to the quota values for a billed account. When you enable <a href="/billing/docs/how-to/modify-project#enable_billing_for_a_project" data-track-type="quotas" data-track-name="quotaLink" data-track-metadata-position="body" data-track-metadata-end-goal="enableBilling">billing</a> for your project, the quota values increase for most services. To get alerts when you're approaching a quota value or system limit, [Set up quota alerts](/docs/quotas/set-up-quota-alerts). To learn what to do if you run out of quota or reach a system limit, see [When you run out of quota](#running_out).

### When you run out of quota

Usually, if you run out of quota the task that you're trying to perform fails and you get a [quota error](/docs/quotas/troubleshoot). For example, creating a new project or calling an API throws a quota error if the task requires more quota than you have. When this happens, the task continues to fail until you have enough quota to accomplish the task.

If you want to keep your quota value, you can work within its constraints to make your request:

- **Allocation quotas**: For allocation quotas, you can free up quota by deleting unused resources that count towards the quota or system limit that you want to consume. For example, you could have a quota value of 100 for a certain Compute Engine virtual machine. If you already have 99 of that virtual machine but you want to create ten more, your request will fail because adding ten more exceeds your quota value (you can still provision one more virtual machine). To free up resources, delete nine of the machines.

- **Rate quotas**: For rate quotas, your available quota resets automatically when the time period resets. For example, you could have a quota value of 1000 requests per day for an API. If you already made 1000 requests to that API and you want to make 1000 more, wait until the next day. For per-day quotas, the time period resets at midnight Pacific Time. For per-minute quotas, the time period resets one minute after your first request in a rolling window.

If you want to change your quota value to accommodate more resource use, you can request a quota adjustment. Using more resources can incur more costs. To learn about quota adjustments, see [About quota adjustments](#about_increase_requests).

### About quota adjustments

Most quota adjustment requests are evaluated by automated systems. Their decision is based on criteria including the availability of resources, the length of time you've used Google Cloud, and other factors. Requests that don't meet the criteria are denied.

Evaluation criteria for automated reviews is not disclosed to ensure fairness for all customers and prevent attempts to manipulate the process. Sometimes quota adjustment requests are escalated to human reviewers, who also follow criteria, but can consider your unique circumstances.

For quota adjustment requests that increase your quota value, you might be asked to pay in advance. For example, you might be asked to make a payment if you request more projects that will use paid Google Cloud services. The payment can be applied to any charges you incur in the future and will be visible as a credit in your account. To learn how to request a quota adjustment, see [Request a quota adjustment](/docs/quotas/help/request_increase).

You don't need to have a paid Customer Care service to request a quota adjustment. To automatically request quota adjustments when you're approaching your quota value, you can use the [quota adjuster](/docs/quotas/quota-adjuster). To use the quota adjuster, you must have enough usage history for the adjuster to make informed predictions.

## What's next

- <a href="/docs/quotas/terminology" data-track-type="quotas" data-track-name="quotaLink" data-track-metadata-position="body" data-track-metadata-end-goal="viewQuota">Understand quota and system limit terminology</a>
- <a href="/docs/quotas/permissions" data-track-type="quotas" data-track-name="quotaLink" data-track-metadata-position="body" data-track-metadata-end-goal="setProjectPermissions">Quota permissions</a>
- <a href="/docs/quotas/view-manage" data-track-type="quotas" data-track-name="quotaLink" data-track-metadata-position="body" data-track-metadata-end-goal="viewQuota">View and manage quotas</a>
- <a href="/docs/quotas/set-up-quota-alerts" data-track-type="quotas" data-track-name="quotaLink" data-track-metadata-position="body" data-track-metadata-end-goal="createAlertingPolicy">Monitor and alert</a>
- <a href="/docs/quotas/troubleshoot" data-track-type="troubleshooting" data-track-name="quotaLink" data-track-metadata-position="body" data-track-metadata-end-goal="viewQuota">Troubleshoot</a>

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
