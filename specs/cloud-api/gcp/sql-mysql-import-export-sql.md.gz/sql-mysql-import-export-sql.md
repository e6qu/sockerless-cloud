# Export and import using SQL dump files

<div class="devsite-article-body clearfix">

<div class="nocontent" style="font-size:medium; margin-bottom:40px; border-top:1px solid black;">

<div style="float:right">

<span style="font-weight:bold">MySQL</span> <span style="color:light-gray">  \|  </span><a href="/sql/docs/postgres/import-export/import-export-sql" data-track-type="sqlSwitcher" data-track-name="postgresLink" title="View this page for the PostgreSQL database engine">PostgreSQL</a> <span style="color:light-gray">  \|  </span><a href="/sql/docs/sqlserver/import-export/import-export-sql" data-track-type="sqlSwitcher" data-track-name="sqlServerLink" title="View this page for the SQL Server database engine">SQL Server</a>

</div>

</div>

This page describes exporting and importing data into Cloud SQL instances using SQL dump files.

**Note:** If you're migrating an entire database from a supported database server (on-premises, in AWS, or Cloud SQL) to a new Cloud SQL instance, you can use [Database Migration Service](/database-migration/docs) instead of exporting and then importing files. If you're exporting to create a new instance from the exported file, consider [restoring from a backup to a different instance](/sql/docs/mysql/backup-recovery/restoring#restorebackups-another-instance) or [cloning the instance](/sql/docs/mysql/clone-instance).

You can cancel the import of data into Cloud SQL instances and the export of data from the instances. This data is contained in SQL dump files. For more information about cancelling an import or export operation, see [Cancel the import and export of data](/sql/docs/mysql/import-export/cancel-import-export).

## Before you begin

**Important:** Before starting a large export, ensure that at least 25 percent of the database size is free (on the instance). Doing so helps prevent issues with aggressive autogrowth, which can affect the availability of the instance.

Exports use database resources, but they do not interfere with normal database operations unless the instance is under-provisioned.

For best practices, see [Best Practices for Importing and Exporting Data](/sql/docs/mysql/import-export).

After completing an import operation, [verify](/sql/docs/mysql/import-export#verify) the results.

Note: MySQL 8.0 for Cloud SQL uses `mysql_native_password` as the default authentication plugin for new users instead of `caching_sha2_password`. However, users imported from external instances might be configured to use the `caching_sha2_password` plugin for authentication. This might introduce problems when connecting. For more information, see [MySQL 8 authentication](/sql/docs/mysql/features#mysql8-authentication).

## Export data from Cloud SQL for MySQL

### Required roles and permissions for exporting from Cloud SQL for MySQL

To export data from Cloud SQL into Cloud Storage, the user initiating the export must have one of the following roles:

- The [Cloud SQL Editor](/sql/docs/mysql/iam-roles) role
- A [custom role](/iam/docs/understanding-custom-roles), including the following permissions:
  - `cloudsql.instances.get`
  - `cloudsql.instances.export`

Additionally, the service account for the Cloud SQL instance must have one of the following roles:

- The `storage.objectAdmin` Identity and Access Management (IAM) role
- A custom role, including the following permissions:
  - `storage.objects.create`
  - `storage.objects.list` (for exporting files in parallel only)
  - `storage.objects.delete` (for exporting files in parallel only)

For help with IAM roles, see <a href="/storage/docs/access-control/iam" target="_blank">Identity and Access Management</a>.

**Note**: The changes that you make to the IAM permissions and roles might take a few minutes to take effect. For more information, see [Access change propagation](/iam/docs/access-change-propagation).

### Export to a SQL dump file from Cloud SQL for MySQL

To create a SQL dump file, you export data from Cloud SQL to Cloud Storage. Once the file is in Cloud Storage, you can import it into another Cloud SQL database. You can also download data from Cloud Storage to your local environment if you want to access it locally.

Exporting from Cloud SQL uses the [mysqldump](https://dev.mysql.com/doc/refman/8.4/en/mysqldump.html) utility with the `--single-transaction` and `--hex-blob` options. With the `--single-transaction` option, `mysqldump` starts a transaction before running. Rather than lock the entire database, this lets `mysqldump` read the database in the current state, making for a consistent data dump.

If your SQL dump file contains **DEFINER** clauses (views, triggers, stored_procedures, and so on), then depending on the order these statements are executed, using this file for import could fail. Learn more about [**DEFINER** usage](/sql/docs/mysql/import-export#definer-clause) and potential workarounds in Cloud SQL.

**Note:** If your data contains large objects (blobs), the export can consume a large amount of memory, impacting instance performance. For help, see <a href="/sql/docs/mysql/known-issues#import-export" target="_blank">Known Issues</a>.

To export data from a database on a Cloud SQL instance to a SQL dump file in a Cloud Storage bucket:

<div id="export-database" class="ds-selector-tabs" ds-scope="code-sample">

<div class="section">

### Console

1.  In the Google Cloud console, go to the **Cloud SQL Instances** page.

    <a href="https://console.cloud.google.com/sql" class="button button-primary" target="console">Go to Cloud SQL Instances</a>

2.  To open the **Overview** page of an instance, click the instance name.

3.  Click **Export**.

4.  In the **File format** section, click **SQL** to create a SQL dump file.

5.  In the **Data to export** section, click **One or more databases in this instance** to export specific databases.

6.  Use the **Databases** drop-down menu to select the databases you want to export from.

7.  Optional: Select **Offload export to a temporary instance** to allow other operations to occur while the export is ongoing.

8.  In the **Destination** section, select **Browse** to search for a Cloud Storage bucket or folder for your export.

9.  Click **Export** to begin the export.

</div>

<div class="section">

### gcloud

1.  [Create a Cloud Storage bucket](/storage/docs/creating-buckets).

2.  Find the service account for the Cloud SQL instance you're exporting from. You can do this running the `gcloud sql instances describe` command. Look for the `serviceAccountEmailAddress` field in the output.

    <div>

    </div>

    ``` devsite-click-to-copy
    gcloud sql instances describe INSTANCE_NAME
      
    ```

3.  Use <a href="/sdk/gcloud/reference/storage/buckets/add-iam-policy-binding" target="_blank"><code translate="no" dir="ltr">gcloud storage buckets add-iam-policy-binding</code></a> to grant the `storage.objectAdmin` [IAM role](/storage/docs/access-control/iam-roles) to the service account. For help with setting IAM permissions, see <a href="/storage/docs/access-control/using-iam-permissions" target="_blank">Using IAM permissions</a>.

4.  Export the database to your Cloud Storage bucket:

    **Note**: If you want to use serverless exports, then use the `offload` parameter. Otherwise, remove it from the following command.

    <div>

    </div>

    ``` devsite-click-to-copy
    gcloud sql export sql INSTANCE_NAME gs://BUCKET_NAME/sqldumpfile.gz \
    --database=DATABASE_NAME \
    --offload
      
    ```

    The `export sql` command does not contain triggers or stored procedures, but does contain views. To export triggers and/or stored procedures, use the [mysqldump](#export-mysqldump) tool.

    For more information about using the `export sql` command, see the <a href="/sdk/gcloud/reference/sql/export/sql" target="_blank"><code translate="no" dir="ltr">sql export sql</code></a> command reference page.

5.  If you do not need to retain the IAM role you set previously, [revoke](/iam/docs/granting-changing-revoking-access#revoking-console) it now.

</div>

<div class="section">

### REST v1

1.  Create a bucket for the export:

    <div>

    </div>

    ``` devsite-click-to-copy
    gcloud storage buckets create gs://BUCKET_NAME --project=PROJECT_NAME --location=LOCATION_NAME
    ```

    This step is not required, but strongly recommended, so you do not open up access to any other data.

2.  Provide your instance with the `storage.objectAdmin` [IAM role](/storage/docs/access-control/iam-roles) for your bucket. For help with setting IAM permissions, see [Using IAM permissions](/storage/docs/access-control/using-iam-permissions).

3.  Export your database:

    Before using any of the request data, make the following replacements:

    - `PROJECT_ID`: the project ID
    - `INSTANCE_ID`: the instance ID
    - `BUCKET_NAME`: the Cloud Storage bucket name
    - `PATH_TO_DUMP_FILE`: the path to the SQL dump file
    - `DATABASE_NAME_1`: the name of a database inside the Cloud SQL instance
    - `DATABASE_NAME_2`: the name of a database inside the Cloud SQL instance

    **Note**: To use serverless exports, set the value of the `offload` parameter to `TRUE`. Serverless exports costs extra. See the [pricing page](https://cloud.google.com/sql/pricing#storage-networking-prices).

4.  If you do not need to retain the IAM role you set previously, remove it now.

For the complete list of parameters for the request, see the [instances:export](/sql/docs/mysql/admin-api/rest/v1beta4/instances/export) page.

</div>

<div class="section">

### REST v1beta4

1.  Create a bucket for the export:

    <div>

    </div>

    ``` devsite-click-to-copy
    gcloud storage buckets create gs://BUCKET_NAME --project=PROJECT_NAME --location=LOCATION_NAME
    ```

    This step is not required, but strongly recommended, so you do not open up access to any other data.

2.  Provide your instance with the `storage.objectAdmin` [IAM role](/storage/docs/access-control/iam-roles) for your bucket. For help with setting IAM permissions, see [Using IAM permissions](/storage/docs/access-control/using-iam-permissions).

3.  Export your database:

    Before using any of the request data, make the following replacements:

    - `PROJECT_ID`: the project ID
    - `INSTANCE_ID`: the instance ID
    - `BUCKET_NAME`: the Cloud Storage bucket name
    - `PATH_TO_DUMP_FILE`: the path to the SQL dump file
    - `DATABASE_NAME_1`: the name of a database inside the Cloud SQL instance
    - `DATABASE_NAME_2`: the name of a database inside the Cloud SQL instance

    **Note**: To use serverless exports, set the value of the `offload` parameter to `TRUE`. Serverless exports costs extra. See the [pricing page](https://cloud.google.com/sql/pricing#storage-networking-prices).

4.  If you do not need to retain the IAM role you set previously, [revoke](/iam/docs/granting-changing-revoking-access#revoking-console) it now.

For the complete list of parameters for the request, see the [instances:export](/sql/docs/mysql/admin-api/rest/v1beta4/instances/export) page.

</div>

</div>

### Export from your local MySQL server using mysqldump

If you are exporting data from an on-premises MySQL database for import into a Cloud SQL database, you must use the `mysqldump` utility with the following flags:

- `--databases` You must use the `--databases` option to specify an explicit list of databases to export, and this list must *not* contain the `mysql` system database.
- `--hex-blob` If your database contains any binary fields, you must use this flag to ensure that your binary fields are imported correctly.
- `--set-gtid-purged=OFF` GTID information must not be included in the SQL dump file, and binary logging must not be disabled by the SQL dump file. (Not required for MySQL 5.5 or external replication.)
- `--single-transaction` Starts a transaction before running. Rather than lock the entire database, this lets mysqldump read the database in the current state, making for a consistent data dump.

**Note:** If you intend to import the SQL dump file into a Cloud SQL database, do not export customer-created MySQL users. You must add users directly to the Cloud SQL database. See [Creating a user](/sql/docs/mysql/create-manage-users#creating).

From a command line, run `mysqldump`:

<div>

</div>

``` devsite-click-to-copy
mysqldump --databases DATABASE_NAME -h INSTANCE_IP -u USERNAME -p \
--hex-blob --single-transaction --set-gtid-purged=OFF \
--default-character-set=utf8mb4 > SQL_FILE.sql
```

**Note:** To export stored procedures from a Cloud SQL instance, include the `--routines` flag. To export triggers from a Cloud SQL instance, make sure that `--skip-triggers` is not specified. If binary logging is enabled and you want to export triggers and stored procedures, you must also set the `log_bin_trust_function_creators` flag in your MySQL database.

For help with `mysqldump`, see the <a href="https://dev.mysql.com/doc/refman/8.4/en/mysqldump.html" target="_blank">mysqldump reference</a>.

### External replication to Cloud SQL for MySQL

To create a dump file for use in an external server configuration, see [Replicating from an external server](/sql/docs/mysql/replication/replication-from-external#export).

## Import data to Cloud SQL for MySQL

### Required roles and permissions for importing to Cloud SQL for MySQL

To import data from Cloud Storage into Cloud SQL, the user initiating the import must have one of the following roles:

- The [Cloud SQL Admin](/sql/docs/mysql/iam-roles) role
- A [custom role](/iam/docs/understanding-custom-roles), including the following permissions:
  - `cloudsql.instances.get`
  - `cloudsql.instances.import`

Additionally, the service account for the Cloud SQL instance must have one of the following roles:

- The `storage.objectAdmin` IAM role
- A custom role, including the following permissions:
  - `storage.objects.get`
  - `storage.objects.list` (for importing files in parallel only)

For help with IAM roles, see <a href="/storage/docs/access-control/iam" target="_blank">Identity and Access Management</a>.

**Note**: The changes that you make to the IAM permissions and roles might take a few minutes to take effect. For more information, see [Access change propagation](/iam/docs/access-change-propagation).

### Import a SQL dump file to Cloud SQL for MySQL

SQL files are plain text files with a sequence of SQL commands.

<div id="import-database" class="ds-selector-tabs" ds-scope="code-sample">

<div class="section">

### Console

1.  In the Google Cloud console, go to the **Cloud SQL Instances** page.

    <a href="https://console.cloud.google.com/sql" class="button button-primary" target="console">Go to Cloud SQL Instances</a>

2.  To open the **Overview** page of an instance, click the instance name.

3.  Click **Import**.

4.  In the **File format** section, select **SQL**.

5.  In the **Select source file** section, enter the path to the bucket and SQL dump file to use for the import, browse to an existing file, or upload a local file.

    You can import a compressed (`.gz`) or an uncompressed (`.sql`) file.

6.  In the **Destination** section, select the database that you want the data to be imported into.

    This causes Cloud SQL to run the `USE DATABASE` statement before the import.

    If your SQL dump file includes a `USE DATABASE` statement, it overrides the database you set in the Google Cloud console.

7.  If you want to specify a user to perform the import, select the user.

    If your import file contains statements that must be performed by a specific user, use this field to specify that user.

8.  Click **Import** to start the import.

</div>

<div class="section">

### gcloud

1.  <a href="/storage/docs/creating-buckets" target="_blank">Create a Cloud Storage bucket.</a>

2.  Upload the file to your bucket.

    For help with uploading files to buckets, see <a href="/storage/docs/uploading-objects" target="_blank">Uploading objects</a>.

3.  Describe the instance you are importing to:

    <div>

    </div>

    ``` devsite-click-to-copy
    gcloud sql instances describe INSTANCE_NAME
    ```

4.  Copy the `serviceAccountEmailAddress` field.

5.  Use <a href="/sdk/gcloud/reference/storage/buckets/add-iam-policy-binding" target="_blank"><code translate="no" dir="ltr">gcloud storage buckets add-iam-policy-binding</code></a> to grant the `storage.objectAdmin` <a href="/storage/docs/access-control/iam-roles" target="_blank">IAM role</a> to the service account for the bucket.

    <div>

    </div>

    ``` devsite-click-to-copy
    gcloud storage buckets add-iam-policy-binding gs://BUCKET_NAME \
      --member=serviceAccount:SERVICE-ACCOUNT \
      --role=roles/storage.objectAdmin
      
    ```

    For help with setting IAM permissions, see <a href="/storage/docs/access-control/using-iam-permissions" target="_blank">Using IAM permissions</a>.

6.  Import the database:

    <div>

    </div>

    ``` devsite-click-to-copy
    gcloud sql import sql INSTANCE_NAME gs://BUCKET_NAME/IMPORT_FILE_NAME \
    --database=DATABASE_NAME
    ```

    For information about using the `import sql` command, see the <a href="/sdk/gcloud/reference/sql/import/sql" target="_blank"><code translate="no" dir="ltr">sql import sql</code></a> command reference page.

    If the command returns an error like `ERROR_RDBMS`, review the permissions; this error is often due to permissions issues.

7.  If you do not need to retain the IAM permissions you set previously, remove them using <a href="/sdk/gcloud/reference/storage/buckets/remove-iam-policy-binding" target="_blank"><code translate="no" dir="ltr">gcloud storage buckets remove-iam-policy-binding</code></a>.

</div>

<div class="section">

### REST v1

1.  Create a SQL dump file. The linked instructions set certain flags that make the dump file compatible with Cloud SQL.

    - If you are importing data from an on-premises MySQL server:

    - 1.  [Create a SQL dump file](/sql/docs/mysql/import-export/exporting#export-mysqldump).
      2.  [Create a bucket in Cloud Storage](/storage/docs/creating-buckets).
      3.  [Upload the SQL dump file](/storage/docs/uploading-objects) to the Cloud Storage bucket.

    - If you're importing data from another Cloud SQL instance, see the instructions in [Exporting data from Cloud SQL to a SQL dump file](/sql/docs/mysql/import-export/exporting#cloud-sql).

2.  <a href="/storage/docs/creating-buckets" target="_blank">Create a Cloud Storage bucket.</a>

3.  Upload the file to your bucket.

    For help with uploading files to buckets, see <a href="/storage/docs/uploading-objects" target="_blank">Uploading objects</a>.

4.  Provide your instance with the `storage.objectAdmin` and `objectViewer` [IAM roles](/storage/docs/access-control/iam-roles) for your bucket. For help with setting IAM permissions, see [Using IAM permissions](/storage/docs/access-control/using-iam-permissions).

5.  Import your dump file:

    Before using any of the request data, make the following replacements:

    - `project-id`: The project ID
    - `instance-id`: The instance ID
    - `bucket_name`: The Cloud Storage bucket name
    - `path_to_sql_file`: The path to the SQL file
    - `database_name`: The name of a database inside the Cloud SQL instance

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    POST https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-id/import
    ```

    </div>

    Request JSON body:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    {
     "importContext":
       {
          "fileType": "SQL",
          "uri": "gs://bucket_name/path_to_sql_file",
          "database": "database_name"
        }
    }
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Save the request body in a file named `request.json`, and execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X POST \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         -H "Content-Type: application/json; charset=utf-8" \
         -d @request.json \
         "https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-id/import"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Save the request body in a file named `request.json`, and execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method POST `
        -Headers $headers `
        -ContentType: "application/json; charset=utf-8" `
        -InFile request.json `
        -Uri "https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-id/import" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a JSON response similar to the following:

    <div class="section expandable">

    #### Response

    <div>

    </div>

    ``` readonly
    {
      "kind": "sql#operation",
      "targetLink": "https://sqladmin.googleapis.com/v1/projects/project-id/instances/target-instance-id",
      "status": "PENDING",
      "user": "user@example.com",
      "insertTime": "2020-01-21T22:43:37.981Z",
      "operationType": "UPDATE",
      "name": "operation-id",
      "targetId": "instance-id",
      "selfLink": "https://sqladmin.googleapis.com/v1/projects/project-id/operations/operation-id",
      "targetProject": "project-id"
    }
    ```

    </div>

    For the complete list of parameters for the request, see the [instances:import](/sql/docs/mysql/admin-api/rest/v1beta4/instances/import) page.

6.  If you do not need to retain the IAM permissions you set previously, remove them now.

</div>

<div class="section">

### REST v1beta4

1.  Create a SQL dump file. The linked instructions set certain flags that make the dump file compatible with Cloud SQL.

    - If you are importing data from an on-premises MySQL server:

    - 1.  [Create a SQL dump file](/sql/docs/mysql/import-export/exporting#export-mysqldump).
      2.  [Create a bucket in Cloud Storage](/storage/docs/creating-buckets).
      3.  [Upload the SQL dump file](/storage/docs/uploading-objects) to the Cloud Storage bucket.

    - If you're importing data from another Cloud SQL instance, see the instructions in [Exporting data from Cloud SQL to a SQL dump file](/sql/docs/mysql/import-export/exporting#cloud-sql).

2.  <a href="/storage/docs/creating-buckets" target="_blank">Create a Cloud Storage bucket.</a>

3.  Upload the file to your bucket.

    For help with uploading files to buckets, see <a href="/storage/docs/uploading-objects" target="_blank">Uploading objects</a>.

4.  Provide your instance with the `storage.objectAdmin` <a href="/storage/docs/access-control/iam-roles" target="_blank">IAM role</a> for your bucket. For help with setting IAM permissions, see <a href="/storage/docs/access-control/using-iam-permissions" target="_blank">Using IAM permissions</a>.

5.  Import your dump file:

    Before using any of the request data, make the following replacements:

    - `project-id`: The project ID
    - `instance-id`: The instance ID
    - `bucket_name`: The Cloud Storage bucket name
    - `path_to_sql_file`: The path to the SQL file
    - `database_name`: The name of a database inside the Cloud SQL instance

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    POST https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id/import
    ```

    </div>

    Request JSON body:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    {
     "importContext":
       {
          "fileType": "SQL",
          "uri": "gs://bucket_name/path_to_sql_file",
          "database": "database_name"
        }
    }
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Save the request body in a file named `request.json`, and execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X POST \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         -H "Content-Type: application/json; charset=utf-8" \
         -d @request.json \
         "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id/import"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Save the request body in a file named `request.json`, and execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method POST `
        -Headers $headers `
        -ContentType: "application/json; charset=utf-8" `
        -InFile request.json `
        -Uri "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id/import" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a JSON response similar to the following:

    <div class="section expandable">

    #### Response

    <div>

    </div>

    ``` readonly
    {
      "kind": "sql#operation",
      "targetLink": "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/target-instance-id",
      "status": "PENDING",
      "user": "user@example.com",
      "insertTime": "2020-01-21T22:43:37.981Z",
      "operationType": "UPDATE",
      "name": "operation-id",
      "targetId": "instance-id",
      "selfLink": "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/operations/operation-id",
      "targetProject": "project-id"
    }
    ```

    </div>

    For the complete list of parameters for the request, see the [instances:import](/sql/docs/mysql/admin-api/rest/v1beta4/instances/import) page.

6.  If you do not need to retain the IAM permissions you set previously, remove them now.

</div>

</div>

**Note:** If you get an error message about needing the SUPER privilege when you attempt to import data, your export file contains elements that cannot be imported into Cloud SQL. Make sure you are following the instructions in [exporting data for import into Cloud SQL](/sql/docs/mysql/import-export/exporting) when you create your export file.

## What's next

- Learn how to <a href="/sql/docs/mysql/import-export/checking-status-import-export" target="_blank">check the status of import and export operations</a>.
- Learn more about <a href="/sql/docs/mysql/import-export" target="_blank">best practices for importing and exporting data</a>.
- Learn more about <a href="/storage/docs" target="_blank">Cloud Storage</a>.
- [Known issues for imports and exports](/sql/docs/mysql/known-issues#import-export).

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
