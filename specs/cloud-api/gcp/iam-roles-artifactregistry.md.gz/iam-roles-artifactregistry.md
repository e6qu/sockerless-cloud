# Artifact Registry roles and permissions

<div class="devsite-article-body clearfix">

This page lists the IAM roles and permissions for Artifact Registry. To search through all roles and permissions, see the [role and permission index](/iam/docs/roles-permissions).

## Artifact Registry roles

<div results-count-container="">

</div>

<table class="fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="50%">Role</th>
<th>Permissions</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td class="role-description"><h4 id="artifactregistry.admin" class="role-title add-link" data-text="Artifact Registry Administrator " tabindex="-1">Artifact Registry Administrator</h4>
<p>(<code translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<span class="role-description custom"> </span>
<p>Administrator access to create and manage repositories.</p>
<strong>Warning:</strong> Granting the <code translate="no" dir="ltr">artifactregistry.repositories.create</code> permission to end users through the <code translate="no" dir="ltr">roles/artifactregistry.admin</code> role is highly privileged. Do not grant this role to lower-trust users.</td>
<td class="role-permissions"><p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.aptartifacts.create</code></li>
<li><code translate="no" dir="ltr">artifactregistry.attachments.create</code></li>
<li><code translate="no" dir="ltr">artifactregistry.attachments.delete</code></li>
<li><code translate="no" dir="ltr">artifactregistry.attachments.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.attachments.list</code></li>
<li><code translate="no" dir="ltr">artifactregistry.dockerimages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.dockerimages.list</code></li>
<li><code translate="no" dir="ltr">artifactregistry.files.delete</code></li>
<li><code translate="no" dir="ltr">artifactregistry.files.download</code></li>
<li><code translate="no" dir="ltr">artifactregistry.files.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.files.list</code></li>
<li><code translate="no" dir="ltr">artifactregistry.files.update</code></li>
<li><code translate="no" dir="ltr">artifactregistry.files.upload</code></li>
<li><code translate="no" dir="ltr">artifactregistry.kfpartifacts.create</code></li>
<li><code translate="no" dir="ltr">artifactregistry.locations.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.locations.list</code></li>
<li><code translate="no" dir="ltr">artifactregistry.mavenartifacts.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.mavenartifacts.list</code></li>
<li><code translate="no" dir="ltr">artifactregistry.npmpackages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.npmpackages.list</code></li>
<li><code translate="no" dir="ltr">artifactregistry.packages.delete</code></li>
<li><code translate="no" dir="ltr">artifactregistry.packages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.packages.list</code></li>
<li><code translate="no" dir="ltr">artifactregistry.packages.update</code></li>
<li><code translate="no" dir="ltr">artifactregistry.projectconfigs.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.projectconfigs.update</code></li>
<li><code translate="no" dir="ltr">artifactregistry.projectsettings.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.projectsettings.update</code></li>
<li><code translate="no" dir="ltr">artifactregistry.pythonpackages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.pythonpackages.list</code></li>
<li><code translate="no" dir="ltr">artifactregistry.repositories.create</code></li>
<li><code translate="no" dir="ltr">artifactregistry.repositories.createOnPush</code></li>
<li><code translate="no" dir="ltr">artifactregistry.repositories.createTagBinding</code></li>
<li><code translate="no" dir="ltr">artifactregistry.repositories.delete</code></li>
<li><code translate="no" dir="ltr">artifactregistry.repositories.deleteArtifacts</code></li>
<li><code translate="no" dir="ltr">artifactregistry.repositories.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">artifactregistry.repositories.downloadArtifacts</code></li>
<li><code translate="no" dir="ltr">artifactregistry.repositories.exportArtifacts</code></li>
<li><code translate="no" dir="ltr">artifactregistry.repositories.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.repositories.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">artifactregistry.repositories.list</code></li>
<li><code translate="no" dir="ltr">artifactregistry.repositories.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">artifactregistry.repositories.listTagBindings</code></li>
<li><code translate="no" dir="ltr">artifactregistry.repositories.readViaVirtualRepository</code></li>
<li><code translate="no" dir="ltr">artifactregistry.repositories.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">artifactregistry.repositories.update</code></li>
<li><code translate="no" dir="ltr">artifactregistry.repositories.uploadArtifacts</code></li>
<li><code translate="no" dir="ltr">artifactregistry.rules.create</code></li>
<li><code translate="no" dir="ltr">artifactregistry.rules.delete</code></li>
<li><code translate="no" dir="ltr">artifactregistry.rules.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.rules.list</code></li>
<li><code translate="no" dir="ltr">artifactregistry.rules.update</code></li>
<li><code translate="no" dir="ltr">artifactregistry.tags.create</code></li>
<li><code translate="no" dir="ltr">artifactregistry.tags.delete</code></li>
<li><code translate="no" dir="ltr">artifactregistry.tags.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.tags.list</code></li>
<li><code translate="no" dir="ltr">artifactregistry.tags.update</code></li>
<li><code translate="no" dir="ltr">artifactregistry.versions.delete</code></li>
<li><code translate="no" dir="ltr">artifactregistry.versions.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.versions.list</code></li>
<li><code translate="no" dir="ltr">artifactregistry.versions.update</code></li>
<li><code translate="no" dir="ltr">artifactregistry.yumartifacts.create</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudkms.keyHandles.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudkms.keyHandles.create</code></li>
<li><code translate="no" dir="ltr">cloudkms.keyHandles.get</code></li>
<li><code translate="no" dir="ltr">cloudkms.keyHandles.list</code></li>
</ul>
<p><code translate="no" dir="ltr">cloudkms.operations.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.projects.showEffectiveAutokeyConfig</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="artifactregistry.editor" class="role-title add-link" data-text="Artifact Registry Editor " tabindex="-1">Artifact Registry Editor</h4>
<p>(<code translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<span class="role-description"> </span>
<p>Editor role for Artifact Registry</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">artifactregistry.aptartifacts.create</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.attachments.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.attachments.create</code></li>
<li><code translate="no" dir="ltr">artifactregistry.attachments.delete</code></li>
<li><code translate="no" dir="ltr">artifactregistry.attachments.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.attachments.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.dockerimages.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.dockerimages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.dockerimages.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.files.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.files.delete</code></li>
<li><code translate="no" dir="ltr">artifactregistry.files.download</code></li>
<li><code translate="no" dir="ltr">artifactregistry.files.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.files.list</code></li>
<li><code translate="no" dir="ltr">artifactregistry.files.update</code></li>
<li><code translate="no" dir="ltr">artifactregistry.files.upload</code></li>
</ul>
<p><code translate="no" dir="ltr">artifactregistry.kfpartifacts.create</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.locations.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.locations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.mavenartifacts.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.mavenartifacts.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.mavenartifacts.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.npmpackages.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.npmpackages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.npmpackages.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.packages.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.packages.delete</code></li>
<li><code translate="no" dir="ltr">artifactregistry.packages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.packages.list</code></li>
<li><code translate="no" dir="ltr">artifactregistry.packages.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.projectconfigs.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.projectconfigs.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.projectconfigs.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.projectsettings.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.projectsettings.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.projectsettings.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.pythonpackages.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.pythonpackages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.pythonpackages.list</code></li>
</ul>
<p><code translate="no" dir="ltr">artifactregistry.repositories.create</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.createOnPush</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.delete</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.deleteArtifacts</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.downloadArtifacts</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.exportArtifacts</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.listTagBindings</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.readViaVirtualRepository</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.update</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.uploadArtifacts</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.rules.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.rules.create</code></li>
<li><code translate="no" dir="ltr">artifactregistry.rules.delete</code></li>
<li><code translate="no" dir="ltr">artifactregistry.rules.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.rules.list</code></li>
<li><code translate="no" dir="ltr">artifactregistry.rules.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.tags.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.tags.create</code></li>
<li><code translate="no" dir="ltr">artifactregistry.tags.delete</code></li>
<li><code translate="no" dir="ltr">artifactregistry.tags.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.tags.list</code></li>
<li><code translate="no" dir="ltr">artifactregistry.tags.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.versions.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.versions.delete</code></li>
<li><code translate="no" dir="ltr">artifactregistry.versions.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.versions.list</code></li>
<li><code translate="no" dir="ltr">artifactregistry.versions.update</code></li>
</ul>
<p><code translate="no" dir="ltr">artifactregistry.yumartifacts.create</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="artifactregistry.repoAdmin" class="role-title add-link" data-text="Artifact Registry Repository Administrator " tabindex="-1">Artifact Registry Repository Administrator</h4>
<p>(<code translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<span class="role-description"> </span>
<p>Access to manage artifacts in repositories.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">artifactregistry.aptartifacts.create</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.attachments.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.attachments.create</code></li>
<li><code translate="no" dir="ltr">artifactregistry.attachments.delete</code></li>
<li><code translate="no" dir="ltr">artifactregistry.attachments.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.attachments.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.dockerimages.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.dockerimages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.dockerimages.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.files.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.files.delete</code></li>
<li><code translate="no" dir="ltr">artifactregistry.files.download</code></li>
<li><code translate="no" dir="ltr">artifactregistry.files.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.files.list</code></li>
<li><code translate="no" dir="ltr">artifactregistry.files.update</code></li>
<li><code translate="no" dir="ltr">artifactregistry.files.upload</code></li>
</ul>
<p><code translate="no" dir="ltr">artifactregistry.kfpartifacts.create</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.locations.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.locations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.mavenartifacts.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.mavenartifacts.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.mavenartifacts.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.npmpackages.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.npmpackages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.npmpackages.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.packages.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.packages.delete</code></li>
<li><code translate="no" dir="ltr">artifactregistry.packages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.packages.list</code></li>
<li><code translate="no" dir="ltr">artifactregistry.packages.update</code></li>
</ul>
<p><code translate="no" dir="ltr">artifactregistry.projectconfigs.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.projectsettings.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.pythonpackages.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.pythonpackages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.pythonpackages.list</code></li>
</ul>
<p><code translate="no" dir="ltr">artifactregistry.repositories.deleteArtifacts</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.downloadArtifacts</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.exportArtifacts</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.listTagBindings</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.readViaVirtualRepository</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.uploadArtifacts</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.rules.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.rules.create</code></li>
<li><code translate="no" dir="ltr">artifactregistry.rules.delete</code></li>
<li><code translate="no" dir="ltr">artifactregistry.rules.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.rules.list</code></li>
<li><code translate="no" dir="ltr">artifactregistry.rules.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.tags.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.tags.create</code></li>
<li><code translate="no" dir="ltr">artifactregistry.tags.delete</code></li>
<li><code translate="no" dir="ltr">artifactregistry.tags.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.tags.list</code></li>
<li><code translate="no" dir="ltr">artifactregistry.tags.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.versions.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.versions.delete</code></li>
<li><code translate="no" dir="ltr">artifactregistry.versions.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.versions.list</code></li>
<li><code translate="no" dir="ltr">artifactregistry.versions.update</code></li>
</ul>
<p><code translate="no" dir="ltr">artifactregistry.yumartifacts.create</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="artifactregistry.viewer" class="role-title add-link" data-text="Artifact Registry Viewer " tabindex="-1">Artifact Registry Viewer</h4>
<p>(<code translate="no" dir="ltr">roles/artifactregistry.viewer</code>)</p>
<span class="role-description"> </span>
<p>Viewer role for Artifact Registry</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">artifactregistry.attachments.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.attachments.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.dockerimages.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.dockerimages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.dockerimages.list</code></li>
</ul>
<p><code translate="no" dir="ltr">artifactregistry.files.download</code></p>
<p><code translate="no" dir="ltr">artifactregistry.files.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.files.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.locations.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.locations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.mavenartifacts.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.mavenartifacts.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.mavenartifacts.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.npmpackages.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.npmpackages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.npmpackages.list</code></li>
</ul>
<p><code translate="no" dir="ltr">artifactregistry.packages.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.packages.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.projectconfigs.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.projectsettings.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.pythonpackages.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.pythonpackages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.pythonpackages.list</code></li>
</ul>
<p><code translate="no" dir="ltr">artifactregistry.repositories.downloadArtifacts</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.exportArtifacts</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.listTagBindings</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.readViaVirtualRepository</code></p>
<p><code translate="no" dir="ltr">artifactregistry.rules.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.rules.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.tags.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.tags.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.versions.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.versions.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="artifactregistry.attachmentReader" class="role-title add-link" data-text="Artifact Registry Attachment Reader " tabindex="-1">Artifact Registry Attachment Reader</h4>
<p>(<code translate="no" dir="ltr">roles/artifactregistry.attachmentReader</code>)</p>
<span class="role-description"> </span>
<p>Access to read attachments from a repository</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">artifactregistry.attachments.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.attachments.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.files.download</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="artifactregistry.attachmentWriter" class="role-title add-link" data-text="Artifact Registry Attachment Writer " tabindex="-1">Artifact Registry Attachment Writer</h4>
<p>(<code translate="no" dir="ltr">roles/artifactregistry.attachmentWriter</code>)</p>
<span class="role-description"> </span>
<p>Access to write attachments to a repository</p></td>
<td class="role-permissions"><p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.attachments.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.attachments.create</code></li>
<li><code translate="no" dir="ltr">artifactregistry.attachments.delete</code></li>
<li><code translate="no" dir="ltr">artifactregistry.attachments.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.attachments.list</code></li>
</ul>
<p><code translate="no" dir="ltr">artifactregistry.files.download</code></p>
<p><code translate="no" dir="ltr">artifactregistry.files.upload</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="artifactregistry.containerRegistryMigrationAdmin" class="role-title add-link" data-text="Container Registry -&gt; Artifact Registry Migration Admin " tabindex="-1">Container Registry -&gt; Artifact Registry Migration Admin</h4>
<p>(<code translate="no" dir="ltr">roles/artifactregistry.containerRegistryMigrationAdmin</code>)</p>
<span class="role-description"> </span>
<p>Access to run migration tooling to migrate from Container Registry to Artifact Registry</p></td>
<td class="role-permissions"><p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.projectsettings.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.projectsettings.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.projectsettings.update</code></li>
</ul>
<p><code translate="no" dir="ltr">artifactregistry.repositories.create</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.downloadArtifacts</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.uploadArtifacts</code></p>
<p><code translate="no" dir="ltr">cloudasset.assets.analyzeIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudasset.assets.searchAllIamPolicies</code></p>
<p><code translate="no" dir="ltr">cloudasset.assets.searchAllResources</code></p>
<p><code translate="no" dir="ltr">iam.roles.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.use</code></p>
<p><code translate="no" dir="ltr">storage.objects.get</code></p>
<p><code translate="no" dir="ltr">storage.objects.list</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="artifactregistry.createOnPushRepoAdmin" class="role-title add-link" data-text="Artifact Registry Create-on-Push Repository Administrator " tabindex="-1">Artifact Registry Create-on-Push Repository Administrator</h4>
<p>(<code translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<span class="role-description"> </span>
<p>Access to manage artifacts in repositories, as well as create new repositories on push</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">artifactregistry.aptartifacts.create</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.attachments.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.attachments.create</code></li>
<li><code translate="no" dir="ltr">artifactregistry.attachments.delete</code></li>
<li><code translate="no" dir="ltr">artifactregistry.attachments.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.attachments.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.dockerimages.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.dockerimages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.dockerimages.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.files.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.files.delete</code></li>
<li><code translate="no" dir="ltr">artifactregistry.files.download</code></li>
<li><code translate="no" dir="ltr">artifactregistry.files.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.files.list</code></li>
<li><code translate="no" dir="ltr">artifactregistry.files.update</code></li>
<li><code translate="no" dir="ltr">artifactregistry.files.upload</code></li>
</ul>
<p><code translate="no" dir="ltr">artifactregistry.kfpartifacts.create</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.locations.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.locations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.mavenartifacts.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.mavenartifacts.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.mavenartifacts.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.npmpackages.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.npmpackages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.npmpackages.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.packages.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.packages.delete</code></li>
<li><code translate="no" dir="ltr">artifactregistry.packages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.packages.list</code></li>
<li><code translate="no" dir="ltr">artifactregistry.packages.update</code></li>
</ul>
<p><code translate="no" dir="ltr">artifactregistry.projectconfigs.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.projectsettings.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.pythonpackages.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.pythonpackages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.pythonpackages.list</code></li>
</ul>
<p><code translate="no" dir="ltr">artifactregistry.repositories.createOnPush</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.deleteArtifacts</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.downloadArtifacts</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.exportArtifacts</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.listTagBindings</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.readViaVirtualRepository</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.uploadArtifacts</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.rules.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.rules.create</code></li>
<li><code translate="no" dir="ltr">artifactregistry.rules.delete</code></li>
<li><code translate="no" dir="ltr">artifactregistry.rules.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.rules.list</code></li>
<li><code translate="no" dir="ltr">artifactregistry.rules.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.tags.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.tags.create</code></li>
<li><code translate="no" dir="ltr">artifactregistry.tags.delete</code></li>
<li><code translate="no" dir="ltr">artifactregistry.tags.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.tags.list</code></li>
<li><code translate="no" dir="ltr">artifactregistry.tags.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.versions.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.versions.delete</code></li>
<li><code translate="no" dir="ltr">artifactregistry.versions.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.versions.list</code></li>
<li><code translate="no" dir="ltr">artifactregistry.versions.update</code></li>
</ul>
<p><code translate="no" dir="ltr">artifactregistry.yumartifacts.create</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="artifactregistry.createOnPushWriter" class="role-title add-link" data-text="Artifact Registry Create-on-Push Writer " tabindex="-1">Artifact Registry Create-on-Push Writer</h4>
<p>(<code translate="no" dir="ltr">roles/artifactregistry.createOnPushWriter</code>)</p>
<span class="role-description"> </span>
<p>Access to read and write repository items, as well as create new repositories on push</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">artifactregistry.aptartifacts.create</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.attachments.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.attachments.create</code></li>
<li><code translate="no" dir="ltr">artifactregistry.attachments.delete</code></li>
<li><code translate="no" dir="ltr">artifactregistry.attachments.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.attachments.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.dockerimages.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.dockerimages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.dockerimages.list</code></li>
</ul>
<p><code translate="no" dir="ltr">artifactregistry.files.download</code></p>
<p><code translate="no" dir="ltr">artifactregistry.files.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.files.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.files.update</code></p>
<p><code translate="no" dir="ltr">artifactregistry.files.upload</code></p>
<p><code translate="no" dir="ltr">artifactregistry.kfpartifacts.create</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.locations.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.locations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.mavenartifacts.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.mavenartifacts.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.mavenartifacts.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.npmpackages.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.npmpackages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.npmpackages.list</code></li>
</ul>
<p><code translate="no" dir="ltr">artifactregistry.packages.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.packages.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.packages.update</code></p>
<p><code translate="no" dir="ltr">artifactregistry.projectconfigs.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.projectsettings.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.pythonpackages.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.pythonpackages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.pythonpackages.list</code></li>
</ul>
<p><code translate="no" dir="ltr">artifactregistry.repositories.createOnPush</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.downloadArtifacts</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.exportArtifacts</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.listTagBindings</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.readViaVirtualRepository</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.uploadArtifacts</code></p>
<p><code translate="no" dir="ltr">artifactregistry.rules.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.rules.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.tags.create</code></p>
<p><code translate="no" dir="ltr">artifactregistry.tags.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.tags.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.tags.update</code></p>
<p><code translate="no" dir="ltr">artifactregistry.versions.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.versions.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.yumartifacts.create</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="artifactregistry.reader" class="role-title add-link" data-text="Artifact Registry Reader " tabindex="-1">Artifact Registry Reader</h4>
<p>(<code translate="no" dir="ltr">roles/artifactregistry.reader</code>)</p>
<span class="role-description"> </span>
<p>Access to read repository items.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">artifactregistry.attachments.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.attachments.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.dockerimages.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.dockerimages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.dockerimages.list</code></li>
</ul>
<p><code translate="no" dir="ltr">artifactregistry.files.download</code></p>
<p><code translate="no" dir="ltr">artifactregistry.files.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.files.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.locations.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.locations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.mavenartifacts.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.mavenartifacts.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.mavenartifacts.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.npmpackages.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.npmpackages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.npmpackages.list</code></li>
</ul>
<p><code translate="no" dir="ltr">artifactregistry.packages.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.packages.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.projectconfigs.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.projectsettings.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.pythonpackages.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.pythonpackages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.pythonpackages.list</code></li>
</ul>
<p><code translate="no" dir="ltr">artifactregistry.repositories.downloadArtifacts</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.exportArtifacts</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.listTagBindings</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.readViaVirtualRepository</code></p>
<p><code translate="no" dir="ltr">artifactregistry.rules.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.rules.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.tags.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.tags.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.versions.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.versions.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="artifactregistry.writer" class="role-title add-link" data-text="Artifact Registry Writer " tabindex="-1">Artifact Registry Writer</h4>
<p>(<code translate="no" dir="ltr">roles/artifactregistry.writer</code>)</p>
<span class="role-description"> </span>
<p>Access to read and write repository items.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">artifactregistry.aptartifacts.create</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.attachments.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.attachments.create</code></li>
<li><code translate="no" dir="ltr">artifactregistry.attachments.delete</code></li>
<li><code translate="no" dir="ltr">artifactregistry.attachments.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.attachments.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.dockerimages.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.dockerimages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.dockerimages.list</code></li>
</ul>
<p><code translate="no" dir="ltr">artifactregistry.files.download</code></p>
<p><code translate="no" dir="ltr">artifactregistry.files.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.files.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.files.update</code></p>
<p><code translate="no" dir="ltr">artifactregistry.files.upload</code></p>
<p><code translate="no" dir="ltr">artifactregistry.kfpartifacts.create</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.locations.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.locations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.mavenartifacts.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.mavenartifacts.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.mavenartifacts.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.npmpackages.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.npmpackages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.npmpackages.list</code></li>
</ul>
<p><code translate="no" dir="ltr">artifactregistry.packages.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.packages.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.packages.update</code></p>
<p><code translate="no" dir="ltr">artifactregistry.projectconfigs.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.projectsettings.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.pythonpackages.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.pythonpackages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.pythonpackages.list</code></li>
</ul>
<p><code translate="no" dir="ltr">artifactregistry.repositories.downloadArtifacts</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.exportArtifacts</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.listTagBindings</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.readViaVirtualRepository</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.uploadArtifacts</code></p>
<p><code translate="no" dir="ltr">artifactregistry.rules.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.rules.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.tags.create</code></p>
<p><code translate="no" dir="ltr">artifactregistry.tags.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.tags.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.tags.update</code></p>
<p><code translate="no" dir="ltr">artifactregistry.versions.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.versions.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.yumartifacts.create</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p></td>
</tr>
</tbody>
</table>

### Service agent roles

Service agent roles should only be granted to [service agents](/iam/docs/service-agents).

<div results-count-container="">

</div>

<table class="fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="50%">Role</th>
<th>Permissions</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td class="role-description"><h4 id="artifactregistry.serviceAgent" class="role-title add-link" data-text="Artifact Registry Service Agent " tabindex="-1">Artifact Registry Service Agent</h4>
<p>(<code translate="no" dir="ltr">roles/artifactregistry.serviceAgent</code>)</p>
<span class="role-description"> </span>
<p>Gives the Artifact Registry service account access to managed resources.</p>
<strong>Warning:</strong> Do not grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.</td>
<td class="role-permissions"><p><code translate="no" dir="ltr">artifactregistry.repositories.downloadArtifacts</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.readViaVirtualRepository</code></p>
<p><code translate="no" dir="ltr">artifactregistry.versions.delete</code></p>
<p><code translate="no" dir="ltr">pubsub.topics.publish</code></p></td>
</tr>
</tbody>
</table>

## Artifact Registry permissions

<div results-count-container="">

</div>

<table class="permissions-table fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="45%">Permission</th>
<th>Included in roles</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td><h4 id="artifactregistry.aptartifacts.create" class="permission-name add-link" data-text="artifactregistry.aptartifacts.create" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.aptartifacts.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushWriter">Artifact Registry Create-on-Push Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.writer">Artifact Registry Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAgent">App Engine Standard Environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="artifactregistry.attachments.create" class="permission-name add-link" data-text="artifactregistry.attachments.create" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.attachments.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.attachmentWriter">Artifact Registry Attachment Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.attachmentWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushWriter">Artifact Registry Create-on-Push Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.writer">Artifact Registry Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="artifactregistry.attachments.delete" class="permission-name add-link" data-text="artifactregistry.attachments.delete" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.attachments.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.attachmentWriter">Artifact Registry Attachment Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.attachmentWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushWriter">Artifact Registry Create-on-Push Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.writer">Artifact Registry Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="artifactregistry.attachments.get" class="permission-name add-link" data-text="artifactregistry.attachments.get" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.attachments.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.viewer">Artifact Registry Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.attachmentReader">Artifact Registry Attachment Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.attachmentReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.attachmentWriter">Artifact Registry Attachment Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.attachmentWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushWriter">Artifact Registry Create-on-Push Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.reader">Artifact Registry Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.writer">Artifact Registry Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.projectAdmin">Assured OSS Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.projectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.reader">Assured OSS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.user">Assured OSS User</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminEditor">Security Center Admin Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminViewer">Security Center Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.ServiceAgent">Container Analysis Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containerscanning#containerscanning.ServiceAgent">Container Scanner Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containerscanning.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="artifactregistry.attachments.list" class="permission-name add-link" data-text="artifactregistry.attachments.list" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.attachments.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.viewer">Artifact Registry Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.attachmentReader">Artifact Registry Attachment Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.attachmentReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.attachmentWriter">Artifact Registry Attachment Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.attachmentWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushWriter">Artifact Registry Create-on-Push Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.reader">Artifact Registry Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.writer">Artifact Registry Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.projectAdmin">Assured OSS Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.projectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.reader">Assured OSS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.user">Assured OSS User</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminEditor">Security Center Admin Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminViewer">Security Center Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.ServiceAgent">Container Analysis Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containerscanning#containerscanning.ServiceAgent">Container Scanner Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containerscanning.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="artifactregistry.dockerimages.get" class="permission-name add-link" data-text="artifactregistry.dockerimages.get" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.dockerimages.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.viewer">Artifact Registry Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushWriter">Artifact Registry Create-on-Push Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.reader">Artifact Registry Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.writer">Artifact Registry Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.projectAdmin">Assured OSS Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.projectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.reader">Assured OSS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.user">Assured OSS User</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminEditor">Security Center Admin Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminViewer">Security Center Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAgent">App Engine Standard Environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/binaryauthorization#binaryauthorization.serviceAgent">Binary Authorization Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/binaryauthorization.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/compliancescanning#compliancescanning.serviceAgent">Compliance Scanning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/compliancescanning.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/configdelivery#configdelivery.serviceAgent">Config Delivery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/configdelivery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.ServiceAgent">Container Analysis Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containerscanning#containerscanning.ServiceAgent">Container Scanner Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containerscanning.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.serviceAgent">Firebase App Hosting Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkemulticloud#gkemulticloud.controlPlaneMachineServiceAgent">Anthos Multi-Cloud Control Plane Machine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkemulticloud.controlPlaneMachineServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkemulticloud#gkemulticloud.nodePoolMachineServiceAgent">Anthos Multi-Cloud Node Pool Machine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkemulticloud.nodePoolMachineServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="artifactregistry.dockerimages.list" class="permission-name add-link" data-text="artifactregistry.dockerimages.list" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.dockerimages.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.viewer">Artifact Registry Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushWriter">Artifact Registry Create-on-Push Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.reader">Artifact Registry Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.writer">Artifact Registry Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.projectAdmin">Assured OSS Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.projectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.reader">Assured OSS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.user">Assured OSS User</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminEditor">Security Center Admin Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminViewer">Security Center Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAgent">App Engine Standard Environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/compliancescanning#compliancescanning.serviceAgent">Compliance Scanning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/compliancescanning.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/configdelivery#configdelivery.serviceAgent">Config Delivery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/configdelivery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.ServiceAgent">Container Analysis Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containerscanning#containerscanning.ServiceAgent">Container Scanner Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containerscanning.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.serviceAgent">Firebase App Hosting Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="artifactregistry.files.delete" class="permission-name add-link" data-text="artifactregistry.files.delete" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.files.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="artifactregistry.files.download" class="permission-name add-link" data-text="artifactregistry.files.download" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.files.download</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.viewer">Artifact Registry Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.attachmentReader">Artifact Registry Attachment Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.attachmentReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.attachmentWriter">Artifact Registry Attachment Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.attachmentWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushWriter">Artifact Registry Create-on-Push Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.reader">Artifact Registry Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.writer">Artifact Registry Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.projectAdmin">Assured OSS Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.projectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.reader">Assured OSS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.user">Assured OSS User</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminEditor">Security Center Admin Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminViewer">Security Center Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAgent">App Engine Standard Environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/compliancescanning#compliancescanning.serviceAgent">Compliance Scanning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/compliancescanning.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.ServiceAgent">Container Analysis Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containerscanning#containerscanning.ServiceAgent">Container Scanner Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containerscanning.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/serviceextensions#networkactions.serviceAgent">Network Actions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/networkactions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="artifactregistry.files.get" class="permission-name add-link" data-text="artifactregistry.files.get" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.files.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.viewer">Artifact Registry Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushWriter">Artifact Registry Create-on-Push Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.reader">Artifact Registry Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.writer">Artifact Registry Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.projectAdmin">Assured OSS Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.projectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.reader">Assured OSS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.user">Assured OSS User</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminEditor">Security Center Admin Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminViewer">Security Center Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAgent">App Engine Standard Environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/compliancescanning#compliancescanning.serviceAgent">Compliance Scanning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/compliancescanning.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.ServiceAgent">Container Analysis Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containerscanning#containerscanning.ServiceAgent">Container Scanner Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containerscanning.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="artifactregistry.files.list" class="permission-name add-link" data-text="artifactregistry.files.list" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.files.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.viewer">Artifact Registry Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushWriter">Artifact Registry Create-on-Push Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.reader">Artifact Registry Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.writer">Artifact Registry Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.projectAdmin">Assured OSS Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.projectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.reader">Assured OSS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.user">Assured OSS User</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminEditor">Security Center Admin Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminViewer">Security Center Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAgent">App Engine Standard Environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/compliancescanning#compliancescanning.serviceAgent">Compliance Scanning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/compliancescanning.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.ServiceAgent">Container Analysis Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containerscanning#containerscanning.ServiceAgent">Container Scanner Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containerscanning.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="artifactregistry.files.update" class="permission-name add-link" data-text="artifactregistry.files.update" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.files.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushWriter">Artifact Registry Create-on-Push Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.writer">Artifact Registry Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="artifactregistry.files.upload" class="permission-name add-link" data-text="artifactregistry.files.upload" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.files.upload</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.attachmentWriter">Artifact Registry Attachment Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.attachmentWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushWriter">Artifact Registry Create-on-Push Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.writer">Artifact Registry Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="artifactregistry.kfpartifacts.create" class="permission-name add-link" data-text="artifactregistry.kfpartifacts.create" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.kfpartifacts.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushWriter">Artifact Registry Create-on-Push Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.writer">Artifact Registry Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAgent">App Engine Standard Environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="artifactregistry.locations.get" class="permission-name add-link" data-text="artifactregistry.locations.get" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.locations.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.viewer">Artifact Registry Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushWriter">Artifact Registry Create-on-Push Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.reader">Artifact Registry Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.writer">Artifact Registry Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.projectAdmin">Assured OSS Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.projectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.reader">Assured OSS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.user">Assured OSS User</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminEditor">Security Center Admin Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminViewer">Security Center Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAgent">App Engine Standard Environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/compliancescanning#compliancescanning.serviceAgent">Compliance Scanning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/compliancescanning.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.ServiceAgent">Container Analysis Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containerscanning#containerscanning.ServiceAgent">Container Scanner Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containerscanning.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="artifactregistry.locations.list" class="permission-name add-link" data-text="artifactregistry.locations.list" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.locations.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.viewer">Artifact Registry Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushWriter">Artifact Registry Create-on-Push Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.reader">Artifact Registry Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.writer">Artifact Registry Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.projectAdmin">Assured OSS Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.projectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.reader">Assured OSS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.user">Assured OSS User</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkservices#networkservices.serviceExtensionsAdmin">Service Extensions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networkservices.serviceExtensionsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminEditor">Security Center Admin Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminViewer">Security Center Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAgent">App Engine Standard Environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/compliancescanning#compliancescanning.serviceAgent">Compliance Scanning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/compliancescanning.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.ServiceAgent">Container Analysis Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containerscanning#containerscanning.ServiceAgent">Container Scanner Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containerscanning.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="artifactregistry.mavenartifacts.get" class="permission-name add-link" data-text="artifactregistry.mavenartifacts.get" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.mavenartifacts.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.viewer">Artifact Registry Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushWriter">Artifact Registry Create-on-Push Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.reader">Artifact Registry Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.writer">Artifact Registry Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.projectAdmin">Assured OSS Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.projectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.reader">Assured OSS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.user">Assured OSS User</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminEditor">Security Center Admin Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminViewer">Security Center Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAgent">App Engine Standard Environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/compliancescanning#compliancescanning.serviceAgent">Compliance Scanning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/compliancescanning.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.ServiceAgent">Container Analysis Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containerscanning#containerscanning.ServiceAgent">Container Scanner Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containerscanning.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="artifactregistry.mavenartifacts.list" class="permission-name add-link" data-text="artifactregistry.mavenartifacts.list" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.mavenartifacts.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.viewer">Artifact Registry Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushWriter">Artifact Registry Create-on-Push Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.reader">Artifact Registry Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.writer">Artifact Registry Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.projectAdmin">Assured OSS Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.projectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.reader">Assured OSS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.user">Assured OSS User</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminEditor">Security Center Admin Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminViewer">Security Center Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAgent">App Engine Standard Environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/compliancescanning#compliancescanning.serviceAgent">Compliance Scanning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/compliancescanning.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.ServiceAgent">Container Analysis Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containerscanning#containerscanning.ServiceAgent">Container Scanner Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containerscanning.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="artifactregistry.npmpackages.get" class="permission-name add-link" data-text="artifactregistry.npmpackages.get" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.npmpackages.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.viewer">Artifact Registry Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushWriter">Artifact Registry Create-on-Push Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.reader">Artifact Registry Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.writer">Artifact Registry Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.projectAdmin">Assured OSS Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.projectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.reader">Assured OSS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.user">Assured OSS User</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminEditor">Security Center Admin Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminViewer">Security Center Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAgent">App Engine Standard Environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/compliancescanning#compliancescanning.serviceAgent">Compliance Scanning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/compliancescanning.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.ServiceAgent">Container Analysis Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containerscanning#containerscanning.ServiceAgent">Container Scanner Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containerscanning.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="artifactregistry.npmpackages.list" class="permission-name add-link" data-text="artifactregistry.npmpackages.list" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.npmpackages.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.viewer">Artifact Registry Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushWriter">Artifact Registry Create-on-Push Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.reader">Artifact Registry Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.writer">Artifact Registry Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.projectAdmin">Assured OSS Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.projectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.reader">Assured OSS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.user">Assured OSS User</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminEditor">Security Center Admin Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminViewer">Security Center Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAgent">App Engine Standard Environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/compliancescanning#compliancescanning.serviceAgent">Compliance Scanning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/compliancescanning.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.ServiceAgent">Container Analysis Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containerscanning#containerscanning.ServiceAgent">Container Scanner Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containerscanning.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="artifactregistry.packages.delete" class="permission-name add-link" data-text="artifactregistry.packages.delete" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.packages.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasemods#firebasemods.serviceAgent">Firebase Extensions API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasemods.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="artifactregistry.packages.get" class="permission-name add-link" data-text="artifactregistry.packages.get" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.packages.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.viewer">Artifact Registry Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushWriter">Artifact Registry Create-on-Push Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.reader">Artifact Registry Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.writer">Artifact Registry Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.projectAdmin">Assured OSS Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.projectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.reader">Assured OSS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.user">Assured OSS User</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminEditor">Security Center Admin Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminViewer">Security Center Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAgent">App Engine Standard Environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/compliancescanning#compliancescanning.serviceAgent">Compliance Scanning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/compliancescanning.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.ServiceAgent">Container Analysis Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containerscanning#containerscanning.ServiceAgent">Container Scanner Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containerscanning.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="artifactregistry.packages.list" class="permission-name add-link" data-text="artifactregistry.packages.list" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.packages.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.viewer">Artifact Registry Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushWriter">Artifact Registry Create-on-Push Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.reader">Artifact Registry Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.writer">Artifact Registry Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.projectAdmin">Assured OSS Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.projectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.reader">Assured OSS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.user">Assured OSS User</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkservices#networkservices.serviceExtensionsAdmin">Service Extensions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networkservices.serviceExtensionsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminEditor">Security Center Admin Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminViewer">Security Center Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAgent">App Engine Standard Environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/compliancescanning#compliancescanning.serviceAgent">Compliance Scanning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/compliancescanning.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.ServiceAgent">Container Analysis Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containerscanning#containerscanning.ServiceAgent">Container Scanner Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containerscanning.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="artifactregistry.packages.update" class="permission-name add-link" data-text="artifactregistry.packages.update" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.packages.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushWriter">Artifact Registry Create-on-Push Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.writer">Artifact Registry Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="artifactregistry.projectconfigs.get" class="permission-name add-link" data-text="artifactregistry.projectconfigs.get" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.projectconfigs.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.viewer">Artifact Registry Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushWriter">Artifact Registry Create-on-Push Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.reader">Artifact Registry Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.writer">Artifact Registry Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.projectAdmin">Assured OSS Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.projectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.reader">Assured OSS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.user">Assured OSS User</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminEditor">Security Center Admin Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminViewer">Security Center Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.ServiceAgent">Container Analysis Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containerscanning#containerscanning.ServiceAgent">Container Scanner Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containerscanning.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="artifactregistry.projectconfigs.update" class="permission-name add-link" data-text="artifactregistry.projectconfigs.update" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.projectconfigs.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="artifactregistry.projectsettings.get" class="permission-name add-link" data-text="artifactregistry.projectsettings.get" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.projectsettings.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/appengine#appengine.appAdmin">App Engine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.appAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.viewer">Artifact Registry Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/appengine#appengine.appViewer">App Engine Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.appViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/appengine#appengine.codeViewer">App Engine Code Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.codeViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/appengine#appengine.deployer">App Engine Deployer</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.deployer</code>)</p>
<p><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAdmin">App Engine Service Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.containerRegistryMigrationAdmin">Container Registry -&gt; Artifact Registry Migration Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.containerRegistryMigrationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushWriter">Artifact Registry Create-on-Push Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.reader">Artifact Registry Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.writer">Artifact Registry Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.projectAdmin">Assured OSS Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.projectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.reader">Assured OSS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.user">Assured OSS User</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminEditor">Security Center Admin Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminViewer">Security Center Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAgent">App Engine Standard Environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengineflex#appengineflex.serviceAgent">App Engine flexible environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengineflex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/compliancescanning#compliancescanning.serviceAgent">Compliance Scanning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/compliancescanning.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/configdelivery#configdelivery.serviceAgent">Config Delivery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/configdelivery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.ServiceAgent">Container Analysis Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containerscanning#containerscanning.ServiceAgent">Container Scanner Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containerscanning.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="artifactregistry.projectsettings.update" class="permission-name add-link" data-text="artifactregistry.projectsettings.update" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.projectsettings.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.containerRegistryMigrationAdmin">Container Registry -&gt; Artifact Registry Migration Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.containerRegistryMigrationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="artifactregistry.pythonpackages.get" class="permission-name add-link" data-text="artifactregistry.pythonpackages.get" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.pythonpackages.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.viewer">Artifact Registry Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushWriter">Artifact Registry Create-on-Push Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.reader">Artifact Registry Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.writer">Artifact Registry Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.projectAdmin">Assured OSS Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.projectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.reader">Assured OSS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.user">Assured OSS User</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminEditor">Security Center Admin Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminViewer">Security Center Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAgent">App Engine Standard Environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/compliancescanning#compliancescanning.serviceAgent">Compliance Scanning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/compliancescanning.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.ServiceAgent">Container Analysis Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containerscanning#containerscanning.ServiceAgent">Container Scanner Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containerscanning.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="artifactregistry.pythonpackages.list" class="permission-name add-link" data-text="artifactregistry.pythonpackages.list" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.pythonpackages.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.viewer">Artifact Registry Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushWriter">Artifact Registry Create-on-Push Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.reader">Artifact Registry Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.writer">Artifact Registry Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.projectAdmin">Assured OSS Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.projectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.reader">Assured OSS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.user">Assured OSS User</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminEditor">Security Center Admin Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminViewer">Security Center Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAgent">App Engine Standard Environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/compliancescanning#compliancescanning.serviceAgent">Compliance Scanning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/compliancescanning.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.ServiceAgent">Container Analysis Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containerscanning#containerscanning.ServiceAgent">Container Scanner Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containerscanning.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="artifactregistry.repositories.create" class="permission-name add-link" data-text="artifactregistry.repositories.create" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.repositories.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.containerRegistryMigrationAdmin">Container Registry -&gt; Artifact Registry Migration Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.containerRegistryMigrationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.projectAdmin">Assured OSS Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.projectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAgent">App Engine Standard Environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengineflex#appengineflex.serviceAgent">App Engine flexible environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengineflex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/configdelivery#configdelivery.serviceAgent">Config Delivery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/configdelivery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.serviceAgent">Firebase App Hosting Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/saasservicemgmt#saasservicemgmt.serviceAgent">SaaS Service Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/saasservicemgmt.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="artifactregistry.repositories.createOnPush" class="permission-name add-link" data-text="artifactregistry.repositories.createOnPush" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.repositories.createOnPush</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushWriter">Artifact Registry Create-on-Push Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="artifactregistry.repositories.createTagBinding" class="permission-name add-link" data-text="artifactregistry.repositories.createTagBinding" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.repositories.createTagBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="artifactregistry.repositories.delete" class="permission-name add-link" data-text="artifactregistry.repositories.delete" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.repositories.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.serviceAgent">Firebase App Hosting Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="artifactregistry.repositories.deleteArtifacts" class="permission-name add-link" data-text="artifactregistry.repositories.deleteArtifacts" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.repositories.deleteArtifacts</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/appengine#appengine.appAdmin">App Engine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.appAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.builder">Cloud Run Builder</a> (<code class="role-name" translate="no" dir="ltr">roles/run.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/appengine#appengine.deployer">App Engine Deployer</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.deployer</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.serviceAgent">Firebase App Hosting Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="artifactregistry.repositories.deleteTagBinding" class="permission-name add-link" data-text="artifactregistry.repositories.deleteTagBinding" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.repositories.deleteTagBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="artifactregistry.repositories.downloadArtifacts" class="permission-name add-link" data-text="artifactregistry.repositories.downloadArtifacts" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.repositories.downloadArtifacts</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/appengine#appengine.appAdmin">App Engine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.appAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.viewer">Artifact Registry Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.builder">Cloud Run Builder</a> (<code class="role-name" translate="no" dir="ltr">roles/run.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/appengine#appengine.deployer">App Engine Deployer</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.deployer</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.containerRegistryMigrationAdmin">Container Registry -&gt; Artifact Registry Migration Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.containerRegistryMigrationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushWriter">Artifact Registry Create-on-Push Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.reader">Artifact Registry Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.writer">Artifact Registry Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.projectAdmin">Assured OSS Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.projectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.reader">Assured OSS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.user">Assured OSS User</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminEditor">Security Center Admin Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminViewer">Security Center Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.serverlessImageRegistryScanner">Wiz Serverless &amp; Container Image Registry Scanner</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.serverlessImageRegistryScanner</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.agentSandboxServiceAgent">Vertex AI Agent Sandbox Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.agentSandboxServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.customCodeServiceAgent">Vertex AI Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.customCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAgent">App Engine Standard Environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengineflex#appengineflex.serviceAgent">App Engine flexible environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengineflex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.serviceAgent">Artifact Registry Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/binaryauthorization#binaryauthorization.serviceAgent">Binary Authorization Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/binaryauthorization.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/compliancescanning#compliancescanning.serviceAgent">Compliance Scanning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/compliancescanning.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/configdelivery#configdelivery.serviceAgent">Config Delivery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/configdelivery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.ServiceAgent">Container Analysis Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containerscanning#containerscanning.ServiceAgent">Container Scanner Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containerscanning.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.serviceAgent">Firebase App Hosting Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkemulticloud#gkemulticloud.controlPlaneMachineServiceAgent">Anthos Multi-Cloud Control Plane Machine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkemulticloud.controlPlaneMachineServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkemulticloud#gkemulticloud.nodePoolMachineServiceAgent">Anthos Multi-Cloud Node Pool Machine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkemulticloud.nodePoolMachineServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/serviceextensions#networkactions.serviceAgent">Network Actions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/networkactions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/saasservicemgmt#saasservicemgmt.serviceAgent">SaaS Service Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/saasservicemgmt.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="artifactregistry.repositories.exportArtifacts" class="permission-name add-link" data-text="artifactregistry.repositories.exportArtifacts" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.repositories.exportArtifacts</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.viewer">Artifact Registry Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushWriter">Artifact Registry Create-on-Push Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.reader">Artifact Registry Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.writer">Artifact Registry Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.projectAdmin">Assured OSS Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.projectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.reader">Assured OSS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.user">Assured OSS User</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminEditor">Security Center Admin Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminViewer">Security Center Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.ServiceAgent">Container Analysis Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containerscanning#containerscanning.ServiceAgent">Container Scanner Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containerscanning.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="artifactregistry.repositories.get" class="permission-name add-link" data-text="artifactregistry.repositories.get" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.repositories.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.viewer">Artifact Registry Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.containerRegistryMigrationAdmin">Container Registry -&gt; Artifact Registry Migration Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.containerRegistryMigrationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushWriter">Artifact Registry Create-on-Push Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.reader">Artifact Registry Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.writer">Artifact Registry Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.projectAdmin">Assured OSS Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.projectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.reader">Assured OSS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.user">Assured OSS User</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminEditor">Security Center Admin Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminViewer">Security Center Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.serverlessImageRegistryScanner">Wiz Serverless &amp; Container Image Registry Scanner</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.serverlessImageRegistryScanner</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.customCodeServiceAgent">Vertex AI Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.customCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAgent">App Engine Standard Environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengineflex#appengineflex.serviceAgent">App Engine flexible environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengineflex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.serviceAgent">Artifact Registry Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.serviceAgent">Audit Manager Auditing Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.serviceAgent">Cloud Security Compliance Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/compliancescanning#compliancescanning.serviceAgent">Compliance Scanning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/compliancescanning.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/configdelivery#configdelivery.serviceAgent">Config Delivery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/configdelivery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.ServiceAgent">Container Analysis Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containerscanning#containerscanning.ServiceAgent">Container Scanner Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containerscanning.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.serviceAgent">Firebase App Hosting Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkemulticloud#gkemulticloud.controlPlaneMachineServiceAgent">Anthos Multi-Cloud Control Plane Machine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkemulticloud.controlPlaneMachineServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkemulticloud#gkemulticloud.nodePoolMachineServiceAgent">Anthos Multi-Cloud Node Pool Machine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkemulticloud.nodePoolMachineServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/saasservicemgmt#saasservicemgmt.serviceAgent">SaaS Service Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/saasservicemgmt.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="artifactregistry.repositories.getIamPolicy" class="permission-name add-link" data-text="artifactregistry.repositories.getIamPolicy" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.repositories.getIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.viewer">Artifact Registry Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.containerRegistryMigrationAdmin">Container Registry -&gt; Artifact Registry Migration Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.containerRegistryMigrationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/configdelivery#configdelivery.serviceAgent">Config Delivery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/configdelivery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="artifactregistry.repositories.list" class="permission-name add-link" data-text="artifactregistry.repositories.list" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.repositories.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.viewer">Artifact Registry Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.containerRegistryMigrationAdmin">Container Registry -&gt; Artifact Registry Migration Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.containerRegistryMigrationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushWriter">Artifact Registry Create-on-Push Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.reader">Artifact Registry Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.writer">Artifact Registry Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.projectAdmin">Assured OSS Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.projectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.reader">Assured OSS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.user">Assured OSS User</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkservices#networkservices.serviceExtensionsAdmin">Service Extensions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networkservices.serviceExtensionsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminEditor">Security Center Admin Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminViewer">Security Center Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.customCodeServiceAgent">Vertex AI Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.customCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAgent">App Engine Standard Environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.serviceAgent">Audit Manager Auditing Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.serviceAgent">Cloud Security Compliance Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/compliancescanning#compliancescanning.serviceAgent">Compliance Scanning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/compliancescanning.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/configdelivery#configdelivery.serviceAgent">Config Delivery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/configdelivery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.ServiceAgent">Container Analysis Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containerscanning#containerscanning.ServiceAgent">Container Scanner Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containerscanning.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="artifactregistry.repositories.listEffectiveTags" class="permission-name add-link" data-text="artifactregistry.repositories.listEffectiveTags" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.repositories.listEffectiveTags</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.viewer">Artifact Registry Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagViewer">Tag Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushWriter">Artifact Registry Create-on-Push Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.reader">Artifact Registry Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.writer">Artifact Registry Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.projectAdmin">Assured OSS Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.projectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.reader">Assured OSS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.user">Assured OSS User</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminEditor">Security Center Admin Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminViewer">Security Center Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAgent">App Engine Standard Environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/compliancescanning#compliancescanning.serviceAgent">Compliance Scanning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/compliancescanning.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/configdelivery#configdelivery.serviceAgent">Config Delivery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/configdelivery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.ServiceAgent">Container Analysis Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containerscanning#containerscanning.ServiceAgent">Container Scanner Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containerscanning.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="artifactregistry.repositories.listTagBindings" class="permission-name add-link" data-text="artifactregistry.repositories.listTagBindings" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.repositories.listTagBindings</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.viewer">Artifact Registry Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagViewer">Tag Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushWriter">Artifact Registry Create-on-Push Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.reader">Artifact Registry Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.writer">Artifact Registry Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.projectAdmin">Assured OSS Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.projectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.reader">Assured OSS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.user">Assured OSS User</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminEditor">Security Center Admin Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminViewer">Security Center Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAgent">App Engine Standard Environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/compliancescanning#compliancescanning.serviceAgent">Compliance Scanning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/compliancescanning.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/configdelivery#configdelivery.serviceAgent">Config Delivery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/configdelivery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.ServiceAgent">Container Analysis Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containerscanning#containerscanning.ServiceAgent">Container Scanner Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containerscanning.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="artifactregistry.repositories.readViaVirtualRepository" class="permission-name add-link" data-text="artifactregistry.repositories.readViaVirtualRepository" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.repositories.readViaVirtualRepository</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.viewer">Artifact Registry Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushWriter">Artifact Registry Create-on-Push Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.reader">Artifact Registry Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.writer">Artifact Registry Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.projectAdmin">Assured OSS Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.projectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.reader">Assured OSS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.user">Assured OSS User</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminEditor">Security Center Admin Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminViewer">Security Center Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAgent">App Engine Standard Environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.serviceAgent">Artifact Registry Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/compliancescanning#compliancescanning.serviceAgent">Compliance Scanning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/compliancescanning.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.ServiceAgent">Container Analysis Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containerscanning#containerscanning.ServiceAgent">Container Scanner Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containerscanning.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="artifactregistry.repositories.setIamPolicy" class="permission-name add-link" data-text="artifactregistry.repositories.setIamPolicy" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.repositories.setIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.containerRegistryMigrationAdmin">Container Registry -&gt; Artifact Registry Migration Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.containerRegistryMigrationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/configdelivery#configdelivery.serviceAgent">Config Delivery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/configdelivery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="artifactregistry.repositories.update" class="permission-name add-link" data-text="artifactregistry.repositories.update" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.repositories.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.serviceAgent">Firebase App Hosting Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="artifactregistry.repositories.uploadArtifacts" class="permission-name add-link" data-text="artifactregistry.repositories.uploadArtifacts" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.repositories.uploadArtifacts</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/appengine#appengine.appAdmin">App Engine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.appAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.builder">Cloud Run Builder</a> (<code class="role-name" translate="no" dir="ltr">roles/run.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/appengine#appengine.deployer">App Engine Deployer</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.deployer</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.containerRegistryMigrationAdmin">Container Registry -&gt; Artifact Registry Migration Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.containerRegistryMigrationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushWriter">Artifact Registry Create-on-Push Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.writer">Artifact Registry Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAgent">App Engine Standard Environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengineflex#appengineflex.serviceAgent">App Engine flexible environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengineflex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/configdelivery#configdelivery.serviceAgent">Config Delivery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/configdelivery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/saasservicemgmt#saasservicemgmt.serviceAgent">SaaS Service Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/saasservicemgmt.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="artifactregistry.rules.create" class="permission-name add-link" data-text="artifactregistry.rules.create" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.rules.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="artifactregistry.rules.delete" class="permission-name add-link" data-text="artifactregistry.rules.delete" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.rules.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="artifactregistry.rules.get" class="permission-name add-link" data-text="artifactregistry.rules.get" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.rules.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.viewer">Artifact Registry Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushWriter">Artifact Registry Create-on-Push Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.reader">Artifact Registry Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.writer">Artifact Registry Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.projectAdmin">Assured OSS Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.projectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.reader">Assured OSS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.user">Assured OSS User</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminEditor">Security Center Admin Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminViewer">Security Center Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.ServiceAgent">Container Analysis Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containerscanning#containerscanning.ServiceAgent">Container Scanner Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containerscanning.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="artifactregistry.rules.list" class="permission-name add-link" data-text="artifactregistry.rules.list" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.rules.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.viewer">Artifact Registry Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushWriter">Artifact Registry Create-on-Push Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.reader">Artifact Registry Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.writer">Artifact Registry Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.projectAdmin">Assured OSS Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.projectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.reader">Assured OSS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.user">Assured OSS User</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminEditor">Security Center Admin Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminViewer">Security Center Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.ServiceAgent">Container Analysis Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containerscanning#containerscanning.ServiceAgent">Container Scanner Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containerscanning.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="artifactregistry.rules.update" class="permission-name add-link" data-text="artifactregistry.rules.update" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.rules.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="artifactregistry.tags.create" class="permission-name add-link" data-text="artifactregistry.tags.create" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.tags.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushWriter">Artifact Registry Create-on-Push Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.writer">Artifact Registry Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAgent">App Engine Standard Environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/configdelivery#configdelivery.serviceAgent">Config Delivery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/configdelivery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="artifactregistry.tags.delete" class="permission-name add-link" data-text="artifactregistry.tags.delete" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.tags.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/configdelivery#configdelivery.serviceAgent">Config Delivery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/configdelivery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="artifactregistry.tags.get" class="permission-name add-link" data-text="artifactregistry.tags.get" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.tags.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/appengine#appengine.appAdmin">App Engine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.appAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.viewer">Artifact Registry Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/appengine#appengine.deployer">App Engine Deployer</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.deployer</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushWriter">Artifact Registry Create-on-Push Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.reader">Artifact Registry Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.writer">Artifact Registry Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.projectAdmin">Assured OSS Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.projectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.reader">Assured OSS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.user">Assured OSS User</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminEditor">Security Center Admin Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminViewer">Security Center Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.customCodeServiceAgent">Vertex AI Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.customCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAgent">App Engine Standard Environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/compliancescanning#compliancescanning.serviceAgent">Compliance Scanning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/compliancescanning.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/configdelivery#configdelivery.serviceAgent">Config Delivery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/configdelivery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.ServiceAgent">Container Analysis Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containerscanning#containerscanning.ServiceAgent">Container Scanner Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containerscanning.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="artifactregistry.tags.list" class="permission-name add-link" data-text="artifactregistry.tags.list" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.tags.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.viewer">Artifact Registry Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushWriter">Artifact Registry Create-on-Push Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.reader">Artifact Registry Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.writer">Artifact Registry Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.projectAdmin">Assured OSS Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.projectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.reader">Assured OSS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.user">Assured OSS User</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminEditor">Security Center Admin Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminViewer">Security Center Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAgent">App Engine Standard Environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/compliancescanning#compliancescanning.serviceAgent">Compliance Scanning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/compliancescanning.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/configdelivery#configdelivery.serviceAgent">Config Delivery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/configdelivery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.ServiceAgent">Container Analysis Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containerscanning#containerscanning.ServiceAgent">Container Scanner Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containerscanning.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="artifactregistry.tags.update" class="permission-name add-link" data-text="artifactregistry.tags.update" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.tags.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushWriter">Artifact Registry Create-on-Push Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.writer">Artifact Registry Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAgent">App Engine Standard Environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/configdelivery#configdelivery.serviceAgent">Config Delivery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/configdelivery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="artifactregistry.versions.delete" class="permission-name add-link" data-text="artifactregistry.versions.delete" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.versions.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.serviceAgent">Artifact Registry Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/configdelivery#configdelivery.serviceAgent">Config Delivery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/configdelivery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="artifactregistry.versions.get" class="permission-name add-link" data-text="artifactregistry.versions.get" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.versions.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.viewer">Artifact Registry Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushWriter">Artifact Registry Create-on-Push Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.reader">Artifact Registry Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.writer">Artifact Registry Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.projectAdmin">Assured OSS Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.projectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.reader">Assured OSS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.user">Assured OSS User</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminEditor">Security Center Admin Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminViewer">Security Center Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.customCodeServiceAgent">Vertex AI Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.customCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAgent">App Engine Standard Environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/compliancescanning#compliancescanning.serviceAgent">Compliance Scanning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/compliancescanning.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/configdelivery#configdelivery.serviceAgent">Config Delivery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/configdelivery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.ServiceAgent">Container Analysis Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containerscanning#containerscanning.ServiceAgent">Container Scanner Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containerscanning.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="artifactregistry.versions.list" class="permission-name add-link" data-text="artifactregistry.versions.list" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.versions.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.viewer">Artifact Registry Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushWriter">Artifact Registry Create-on-Push Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.reader">Artifact Registry Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.writer">Artifact Registry Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.projectAdmin">Assured OSS Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.projectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.reader">Assured OSS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.user">Assured OSS User</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkservices#networkservices.serviceExtensionsAdmin">Service Extensions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networkservices.serviceExtensionsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminEditor">Security Center Admin Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminViewer">Security Center Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAgent">App Engine Standard Environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/compliancescanning#compliancescanning.serviceAgent">Compliance Scanning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/compliancescanning.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/configdelivery#configdelivery.serviceAgent">Config Delivery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/configdelivery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.ServiceAgent">Container Analysis Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containerscanning#containerscanning.ServiceAgent">Container Scanner Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containerscanning.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="artifactregistry.versions.update" class="permission-name add-link" data-text="artifactregistry.versions.update" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.versions.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="artifactregistry.yumartifacts.create" class="permission-name add-link" data-text="artifactregistry.yumartifacts.create" tabindex="-1"><code translate="no" dir="ltr">artifactregistry.yumartifacts.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushWriter">Artifact Registry Create-on-Push Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.writer">Artifact Registry Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAgent">App Engine Standard Environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
</tbody>
</table>

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
