# Documents (Input Stage)

<div class="devsite-article-body clearfix devsite-no-page-title">

# Documents (Input Stage)

## Description

Returns documents by looking up a fixed set of predefined documents.

The stage must take one or more documents as input and cannot contain documents with duplicate paths. If a referenced document does not exist, no results will be produced for that document path.

This stage behaves similar to Firestore's `batchGet` and allows filtering on the results directly rather than performing post-filtering steps after the batch operation.

## Examples

<div class="ds-selector-tabs" ds-scope="lang">

<div class="section">

### <span class="two-line-tab"><span tab-label="modular API"></span>Web</span>

<div>

</div>

``` devsite-click-to-copy
const results = await execute(db.pipeline()
  .documents([
    doc(db, "cities", "SF"),
    doc(db, "cities", "DC"),
    doc(db, "cities", "NY")
  ])
);test.firestore.js
```

</div>

<div class="section">

##### Swift

<div>

</div>

``` devsite-click-to-copy
let results = try await db.pipeline()
  .documents([
    db.collection("cities").document("SF"),
    db.collection("cities").document("DC"),
    db.collection("cities").document("NY")
  ]).execute()PipelineSnippets.swift
```

</div>

<div class="section">

##### <span class="two-line-tab">Kotlin <span class="firebase-platform-label">Android</span></span>

<div>

</div>

``` devsite-click-to-copy
val results = db.pipeline()
    .documents(
        db.collection("cities").document("SF"),
        db.collection("cities").document("DC"),
        db.collection("cities").document("NY")
    ).execute()DocSnippets.kt
```

</div>

<div class="section">

##### <span class="two-line-tab">Java <span class="firebase-platform-label">Android</span></span>

<div>

</div>

``` devsite-click-to-copy
      Task<Pipeline.Snapshot> results = db.pipeline()
    .documents(
        db.collection("cities").document("SF"),
        db.collection("cities").document("DC"),
        db.collection("cities").document("NY")
    ).execute();DocSnippets.java
    
```

</div>

<div class="section">

##### Python

<div>

</div>

``` devsite-click-to-copy
results = (
    client.pipeline()
    .documents(
        client.collection("cities").document("SF"),
        client.collection("cities").document("DC"),
        client.collection("cities").document("NY"),
    )
    .execute()
)firestore_pipelines.py
```

</div>

<div class="section">

##### Java

<div>

</div>

``` devsite-click-to-copy
Pipeline.Snapshot results =
    firestore
        .pipeline()
        .documents(
            firestore.collection("cities").document("SF"),
            firestore.collection("cities").document("DC"),
            firestore.collection("cities").document("NY"))
        .execute()
        .get();PipelineSnippets.java
```

</div>

<div class="section">

##### Go

<div>

</div>

``` devsite-click-to-copy
snapshot := client.Pipeline().
 Documents([]*firestore.DocumentRef{
     client.Collection("cities").Doc("SF"),
     client.Collection("cities").Doc("DC"),
     client.Collection("cities").Doc("NY"),
 }).
 Execute(ctx)pipeline_snippets_general.go
```

</div>

</div>

## Behavior

In order to use the `documents(...)` stage, it must appear as the first stage in the pipeline.

The order of documents returned from the `documents(...)` stage is unstable and cannot be relied upon. A subsequent [`sort(...)`](/firestore/native/docs/pipeline/stages/transformation/sort) stage can be used to obtain a deterministic ordering.

For example, for the following documents:

<div>

<div class="section">

### Node.js

<div>

</div>

``` devsite-click-to-copy
await db.collection("cities").doc("SF").set({name: "San Francsico", state: "California"});
await db.collection("cities").doc("NYC").set({name: "New York City", state: "New York"});
await db.collection("cities").doc("CHI").set({name: "Chicago", state: "Illinois"});
```

</div>

</div>

The `documents(...)` stage can be used to retrieve only the `SF` and `NYC` documents and then sort them in ascending order of name.

<div>

<div class="section">

### Node.js

<div>

</div>

``` devsite-click-to-copy
const results = await db.pipeline()
  .documents(
    db.collection("cities").doc("SF"),
    db.collection("cities").doc("NYC"))
  .sort(field("name").ascending())
  .execute();
```

</div>

</div>

This query produces the following documents:

<div>

</div>

``` devsite-click-to-copy
  { name: "New York City", state: "New York" }
  { name: "San Francsico", state: "California" }
```

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
