# API Gateway audit logging

<div class="devsite-article-body clearfix devsite-no-page-title">

# API Gateway audit logging

This document lists the audited methods for API Gateway. Google Cloud services generate audit logs that record administrative and access activities within your Google Cloud resources. For more information about Cloud Audit Logs, see the following:

- [Types of audit logs](/logging/docs/audit#types)
- [Audit log entry structure](/logging/docs/audit#audit_log_entry_structure)
- [Storing and routing audit logs](/logging/docs/audit#storing_and_routing_audit_logs)
- [Cloud Logging pricing summary](/stackdriver/pricing#logs-pricing-summary)
- [Enable Data Access audit logs](/logging/docs/audit/configure-data-access)

## Service name

To view the API Gateway audit logs, do the following:

1.  In the Google Cloud console, go to the Logs Explorer page:

    <a href="https://console.cloud.google.com/logs/query" class="button button-primary" target="console" data-track-name="consoleLink" data-track-type="reference" data-track-metadata-position="body">Go to Logs Explorer</a>

2.  Copy and paste the following query into the **Query** field of the Logs Explorer, and then click **Run query**.

    <div>

    </div>

    ``` devsite-click-to-copy
        protoPayload.serviceName="apigateway.googleapis.com"
      
    ```

## Methods by permission type

Each IAM permission has a `type` property, whose value is an enum that can be one of four values: `ADMIN_READ`, `ADMIN_WRITE`, `DATA_READ`, or `DATA_WRITE`. When you call a method, API Gateway generates an audit log whose category is dependent on the `type` property of the permission required to perform the method. Methods that require an IAM permission with the `type` property value of `DATA_READ`, `DATA_WRITE`, or `ADMIN_READ` generate [Data Access](/logging/docs/audit#data-access) audit logs. Methods that require an IAM permission with the `type` property value of `ADMIN_WRITE` generate [Admin Activity](/logging/docs/audit#admin-activity) audit logs.

API methods in the following list that are marked with (LRO) are long-running operations (LROs). These methods usually generate two audit log entries: one when the operation starts and another when it ends. For more information see [Audit logs for long-running operations](/logging/docs/audit/understanding-audit-logs#lro).

<table class="fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="15%">Permission type</th>
<th>Methods</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td><code translate="no" dir="ltr">ADMIN_READ</code></td>
<td><code translate="no" dir="ltr">google.cloud.apigateway.v1.ApiGatewayService.GetApi</code><br />
<code translate="no" dir="ltr">google.cloud.apigateway.v1.ApiGatewayService.GetApiConfig</code><br />
<code translate="no" dir="ltr">google.cloud.apigateway.v1.ApiGatewayService.GetGateway</code><br />
<code translate="no" dir="ltr">google.cloud.apigateway.v1.ApiGatewayService.ListApiConfigs</code><br />
<code translate="no" dir="ltr">google.cloud.apigateway.v1.ApiGatewayService.ListApis</code><br />
<code translate="no" dir="ltr">google.cloud.apigateway.v1.ApiGatewayService.ListGateways</code><br />
<code translate="no" dir="ltr">google.cloud.apigateway.v1beta.ApiGatewayService.GetApi</code><br />
<code translate="no" dir="ltr">google.cloud.apigateway.v1beta.ApiGatewayService.GetApiConfig</code><br />
<code translate="no" dir="ltr">google.cloud.apigateway.v1beta.ApiGatewayService.GetGateway</code><br />
<code translate="no" dir="ltr">google.cloud.apigateway.v1beta.ApiGatewayService.ListApiConfigs</code><br />
<code translate="no" dir="ltr">google.cloud.apigateway.v1beta.ApiGatewayService.ListApis</code><br />
<code translate="no" dir="ltr">google.cloud.apigateway.v1beta.ApiGatewayService.ListGateways</code><br />
<code translate="no" dir="ltr">GetIamPolicy</code><br />
<code translate="no" dir="ltr">google.longrunning.Operations.GetOperation</code><br />
<code translate="no" dir="ltr">google.longrunning.Operations.ListOperations</code></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">ADMIN_WRITE</code></td>
<td><code translate="no" dir="ltr">google.cloud.apigateway.v1.ApiGatewayService.CreateApi</code> (LRO)<br />
<code translate="no" dir="ltr">google.cloud.apigateway.v1.ApiGatewayService.CreateApiConfig</code> (LRO)<br />
<code translate="no" dir="ltr">google.cloud.apigateway.v1.ApiGatewayService.CreateGateway</code> (LRO)<br />
<code translate="no" dir="ltr">google.cloud.apigateway.v1.ApiGatewayService.DeleteApi</code> (LRO)<br />
<code translate="no" dir="ltr">google.cloud.apigateway.v1.ApiGatewayService.DeleteApiConfig</code> (LRO)<br />
<code translate="no" dir="ltr">google.cloud.apigateway.v1.ApiGatewayService.DeleteGateway</code> (LRO)<br />
<code translate="no" dir="ltr">google.cloud.apigateway.v1.ApiGatewayService.UpdateApi</code> (LRO)<br />
<code translate="no" dir="ltr">google.cloud.apigateway.v1.ApiGatewayService.UpdateApiConfig</code> (LRO)<br />
<code translate="no" dir="ltr">google.cloud.apigateway.v1.ApiGatewayService.UpdateGateway</code> (LRO)<br />
<code translate="no" dir="ltr">google.cloud.apigateway.v1beta.ApiGatewayService.CreateApi</code> (LRO)<br />
<code translate="no" dir="ltr">google.cloud.apigateway.v1beta.ApiGatewayService.CreateApiConfig</code> (LRO)<br />
<code translate="no" dir="ltr">google.cloud.apigateway.v1beta.ApiGatewayService.CreateGateway</code> (LRO)<br />
<code translate="no" dir="ltr">google.cloud.apigateway.v1beta.ApiGatewayService.DeleteApi</code> (LRO)<br />
<code translate="no" dir="ltr">google.cloud.apigateway.v1beta.ApiGatewayService.DeleteApiConfig</code> (LRO)<br />
<code translate="no" dir="ltr">google.cloud.apigateway.v1beta.ApiGatewayService.DeleteGateway</code> (LRO)<br />
<code translate="no" dir="ltr">google.cloud.apigateway.v1beta.ApiGatewayService.UpdateApi</code> (LRO)<br />
<code translate="no" dir="ltr">google.cloud.apigateway.v1beta.ApiGatewayService.UpdateApiConfig</code> (LRO)<br />
<code translate="no" dir="ltr">google.cloud.apigateway.v1beta.ApiGatewayService.UpdateGateway</code> (LRO)<br />
<code translate="no" dir="ltr">SetIamPolicy</code><br />
<code translate="no" dir="ltr">google.longrunning.Operations.CancelOperation</code><br />
<code translate="no" dir="ltr">google.longrunning.Operations.DeleteOperation</code></td>
</tr>
</tbody>
</table>

## API interface audit logs

For information about how and which permissions are evaluated for each method, see the Identity and Access Management documentation for API Gateway.

### `google.cloud.apigateway.v1.ApiGatewayService`

The following audit logs are associated with methods belonging to `google.cloud.apigateway.v1.ApiGatewayService`.

#### `CreateApi`

- **Method**: `google.cloud.apigateway.v1.ApiGatewayService.CreateApi`  
- **Audit log type**: [Admin activity](/logging/docs/audit#admin-activity)  
- **Permissions**:
  - `apigateway.apis.create - ADMIN_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="google.cloud.apigateway.v1.ApiGatewayService.CreateApi" `  

#### `CreateApiConfig`

- **Method**: `google.cloud.apigateway.v1.ApiGatewayService.CreateApiConfig`  
- **Audit log type**: [Admin activity](/logging/docs/audit#admin-activity)  
- **Permissions**:
  - `apigateway.apiconfigs.create - ADMIN_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="google.cloud.apigateway.v1.ApiGatewayService.CreateApiConfig" `  

#### `CreateGateway`

- **Method**: `google.cloud.apigateway.v1.ApiGatewayService.CreateGateway`  
- **Audit log type**: [Admin activity](/logging/docs/audit#admin-activity)  
- **Permissions**:
  - `apigateway.gateways.create - ADMIN_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="google.cloud.apigateway.v1.ApiGatewayService.CreateGateway" `  

#### `DeleteApi`

- **Method**: `google.cloud.apigateway.v1.ApiGatewayService.DeleteApi`  
- **Audit log type**: [Admin activity](/logging/docs/audit#admin-activity)  
- **Permissions**:
  - `apigateway.apis.delete - ADMIN_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="google.cloud.apigateway.v1.ApiGatewayService.DeleteApi" `  

#### `DeleteApiConfig`

- **Method**: `google.cloud.apigateway.v1.ApiGatewayService.DeleteApiConfig`  
- **Audit log type**: [Admin activity](/logging/docs/audit#admin-activity)  
- **Permissions**:
  - `apigateway.apiconfigs.delete - ADMIN_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="google.cloud.apigateway.v1.ApiGatewayService.DeleteApiConfig" `  

#### `DeleteGateway`

- **Method**: `google.cloud.apigateway.v1.ApiGatewayService.DeleteGateway`  
- **Audit log type**: [Admin activity](/logging/docs/audit#admin-activity)  
- **Permissions**:
  - `apigateway.gateways.delete - ADMIN_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="google.cloud.apigateway.v1.ApiGatewayService.DeleteGateway" `  

#### `GetApi`

- **Method**: `google.cloud.apigateway.v1.ApiGatewayService.GetApi`  
- **Audit log type**: [Data access](/logging/docs/audit#data-access)  
- **Permissions**:
  - `apigateway.apis.get - ADMIN_READ`
- **Method is a long-running or streaming operation**: No.  
- **Filter for this method**: ` protoPayload.methodName="google.cloud.apigateway.v1.ApiGatewayService.GetApi" `  

#### `GetApiConfig`

- **Method**: `google.cloud.apigateway.v1.ApiGatewayService.GetApiConfig`  
- **Audit log type**: [Data access](/logging/docs/audit#data-access)  
- **Permissions**:
  - `apigateway.apiconfigs.get - ADMIN_READ`
- **Method is a long-running or streaming operation**: No.  
- **Filter for this method**: ` protoPayload.methodName="google.cloud.apigateway.v1.ApiGatewayService.GetApiConfig" `  

#### `GetGateway`

- **Method**: `google.cloud.apigateway.v1.ApiGatewayService.GetGateway`  
- **Audit log type**: [Data access](/logging/docs/audit#data-access)  
- **Permissions**:
  - `apigateway.gateways.get - ADMIN_READ`
- **Method is a long-running or streaming operation**: No.  
- **Filter for this method**: ` protoPayload.methodName="google.cloud.apigateway.v1.ApiGatewayService.GetGateway" `  

#### `ListApiConfigs`

- **Method**: `google.cloud.apigateway.v1.ApiGatewayService.ListApiConfigs`  
- **Audit log type**: [Data access](/logging/docs/audit#data-access)  
- **Permissions**:
  - `apigateway.apiconfigs.list - ADMIN_READ`
- **Method is a long-running or streaming operation**: No.  
- **Filter for this method**: ` protoPayload.methodName="google.cloud.apigateway.v1.ApiGatewayService.ListApiConfigs" `  

#### `ListApis`

- **Method**: `google.cloud.apigateway.v1.ApiGatewayService.ListApis`  
- **Audit log type**: [Data access](/logging/docs/audit#data-access)  
- **Permissions**:
  - `apigateway.apis.list - ADMIN_READ`
- **Method is a long-running or streaming operation**: No.  
- **Filter for this method**: ` protoPayload.methodName="google.cloud.apigateway.v1.ApiGatewayService.ListApis" `  

#### `ListGateways`

- **Method**: `google.cloud.apigateway.v1.ApiGatewayService.ListGateways`  
- **Audit log type**: [Data access](/logging/docs/audit#data-access)  
- **Permissions**:
  - `apigateway.gateways.list - ADMIN_READ`
- **Method is a long-running or streaming operation**: No.  
- **Filter for this method**: ` protoPayload.methodName="google.cloud.apigateway.v1.ApiGatewayService.ListGateways" `  

#### `UpdateApi`

- **Method**: `google.cloud.apigateway.v1.ApiGatewayService.UpdateApi`  
- **Audit log type**: [Admin activity](/logging/docs/audit#admin-activity)  
- **Permissions**:
  - `apigateway.apis.update - ADMIN_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="google.cloud.apigateway.v1.ApiGatewayService.UpdateApi" `  

#### `UpdateApiConfig`

- **Method**: `google.cloud.apigateway.v1.ApiGatewayService.UpdateApiConfig`  
- **Audit log type**: [Admin activity](/logging/docs/audit#admin-activity)  
- **Permissions**:
  - `apigateway.apiconfigs.update - ADMIN_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="google.cloud.apigateway.v1.ApiGatewayService.UpdateApiConfig" `  

#### `UpdateGateway`

- **Method**: `google.cloud.apigateway.v1.ApiGatewayService.UpdateGateway`  
- **Audit log type**: [Admin activity](/logging/docs/audit#admin-activity)  
- **Permissions**:
  - `apigateway.gateways.update - ADMIN_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="google.cloud.apigateway.v1.ApiGatewayService.UpdateGateway" `  

### `google.cloud.apigateway.v1beta.ApiGatewayService`

The following audit logs are associated with methods belonging to `google.cloud.apigateway.v1beta.ApiGatewayService`.

#### `CreateApi`

- **Method**: `google.cloud.apigateway.v1beta.ApiGatewayService.CreateApi`  
- **Audit log type**: [Admin activity](/logging/docs/audit#admin-activity)  
- **Permissions**:
  - `apigateway.apis.create - ADMIN_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="google.cloud.apigateway.v1beta.ApiGatewayService.CreateApi" `  

#### `CreateApiConfig`

- **Method**: `google.cloud.apigateway.v1beta.ApiGatewayService.CreateApiConfig`  
- **Audit log type**: [Admin activity](/logging/docs/audit#admin-activity)  
- **Permissions**:
  - `apigateway.apiconfigs.create - ADMIN_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="google.cloud.apigateway.v1beta.ApiGatewayService.CreateApiConfig" `  

#### `CreateGateway`

- **Method**: `google.cloud.apigateway.v1beta.ApiGatewayService.CreateGateway`  
- **Audit log type**: [Admin activity](/logging/docs/audit#admin-activity)  
- **Permissions**:
  - `apigateway.gateways.create - ADMIN_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="google.cloud.apigateway.v1beta.ApiGatewayService.CreateGateway" `  

#### `DeleteApi`

- **Method**: `google.cloud.apigateway.v1beta.ApiGatewayService.DeleteApi`  
- **Audit log type**: [Admin activity](/logging/docs/audit#admin-activity)  
- **Permissions**:
  - `apigateway.apis.delete - ADMIN_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="google.cloud.apigateway.v1beta.ApiGatewayService.DeleteApi" `  

#### `DeleteApiConfig`

- **Method**: `google.cloud.apigateway.v1beta.ApiGatewayService.DeleteApiConfig`  
- **Audit log type**: [Admin activity](/logging/docs/audit#admin-activity)  
- **Permissions**:
  - `apigateway.apiconfigs.delete - ADMIN_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="google.cloud.apigateway.v1beta.ApiGatewayService.DeleteApiConfig" `  

#### `DeleteGateway`

- **Method**: `google.cloud.apigateway.v1beta.ApiGatewayService.DeleteGateway`  
- **Audit log type**: [Admin activity](/logging/docs/audit#admin-activity)  
- **Permissions**:
  - `apigateway.gateways.delete - ADMIN_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="google.cloud.apigateway.v1beta.ApiGatewayService.DeleteGateway" `  

#### `GetApi`

- **Method**: `google.cloud.apigateway.v1beta.ApiGatewayService.GetApi`  
- **Audit log type**: [Data access](/logging/docs/audit#data-access)  
- **Permissions**:
  - `apigateway.apis.get - ADMIN_READ`
- **Method is a long-running or streaming operation**: No.  
- **Filter for this method**: ` protoPayload.methodName="google.cloud.apigateway.v1beta.ApiGatewayService.GetApi" `  

#### `GetApiConfig`

- **Method**: `google.cloud.apigateway.v1beta.ApiGatewayService.GetApiConfig`  
- **Audit log type**: [Data access](/logging/docs/audit#data-access)  
- **Permissions**:
  - `apigateway.apiconfigs.get - ADMIN_READ`
- **Method is a long-running or streaming operation**: No.  
- **Filter for this method**: ` protoPayload.methodName="google.cloud.apigateway.v1beta.ApiGatewayService.GetApiConfig" `  

#### `GetGateway`

- **Method**: `google.cloud.apigateway.v1beta.ApiGatewayService.GetGateway`  
- **Audit log type**: [Data access](/logging/docs/audit#data-access)  
- **Permissions**:
  - `apigateway.gateways.get - ADMIN_READ`
- **Method is a long-running or streaming operation**: No.  
- **Filter for this method**: ` protoPayload.methodName="google.cloud.apigateway.v1beta.ApiGatewayService.GetGateway" `  

#### `ListApiConfigs`

- **Method**: `google.cloud.apigateway.v1beta.ApiGatewayService.ListApiConfigs`  
- **Audit log type**: [Data access](/logging/docs/audit#data-access)  
- **Permissions**:
  - `apigateway.apiconfigs.list - ADMIN_READ`
- **Method is a long-running or streaming operation**: No.  
- **Filter for this method**: ` protoPayload.methodName="google.cloud.apigateway.v1beta.ApiGatewayService.ListApiConfigs" `  

#### `ListApis`

- **Method**: `google.cloud.apigateway.v1beta.ApiGatewayService.ListApis`  
- **Audit log type**: [Data access](/logging/docs/audit#data-access)  
- **Permissions**:
  - `apigateway.apis.list - ADMIN_READ`
- **Method is a long-running or streaming operation**: No.  
- **Filter for this method**: ` protoPayload.methodName="google.cloud.apigateway.v1beta.ApiGatewayService.ListApis" `  

#### `ListGateways`

- **Method**: `google.cloud.apigateway.v1beta.ApiGatewayService.ListGateways`  
- **Audit log type**: [Data access](/logging/docs/audit#data-access)  
- **Permissions**:
  - `apigateway.gateways.list - ADMIN_READ`
- **Method is a long-running or streaming operation**: No.  
- **Filter for this method**: ` protoPayload.methodName="google.cloud.apigateway.v1beta.ApiGatewayService.ListGateways" `  

#### `UpdateApi`

- **Method**: `google.cloud.apigateway.v1beta.ApiGatewayService.UpdateApi`  
- **Audit log type**: [Admin activity](/logging/docs/audit#admin-activity)  
- **Permissions**:
  - `apigateway.apis.update - ADMIN_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="google.cloud.apigateway.v1beta.ApiGatewayService.UpdateApi" `  

#### `UpdateApiConfig`

- **Method**: `google.cloud.apigateway.v1beta.ApiGatewayService.UpdateApiConfig`  
- **Audit log type**: [Admin activity](/logging/docs/audit#admin-activity)  
- **Permissions**:
  - `apigateway.apiconfigs.update - ADMIN_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="google.cloud.apigateway.v1beta.ApiGatewayService.UpdateApiConfig" `  

#### `UpdateGateway`

- **Method**: `google.cloud.apigateway.v1beta.ApiGatewayService.UpdateGateway`  
- **Audit log type**: [Admin activity](/logging/docs/audit#admin-activity)  
- **Permissions**:
  - `apigateway.gateways.update - ADMIN_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="google.cloud.apigateway.v1beta.ApiGatewayService.UpdateGateway" `  

### `google.iam.v1.IAMPolicy`

The following audit logs are associated with methods belonging to `google.iam.v1.IAMPolicy`.

#### `GetIamPolicy`

- **Method**: `GetIamPolicy`  
- **Audit log type**: [Data access](/logging/docs/audit#data-access)  
- **Permissions**:
  - `apigateway.apis.getIamPolicy - ADMIN_READ`
  - `apigateway.gateways.getIamPolicy - ADMIN_READ`
- **Method is a long-running or streaming operation**: No.  
- **Filter for this method**: ` protoPayload.methodName="GetIamPolicy" `  

#### `SetIamPolicy`

- **Method**: `SetIamPolicy`  
- **Audit log type**: [Admin activity](/logging/docs/audit#admin-activity)  
- **Permissions**:
  - `apigateway.apiconfigs.setIamPolicy - ADMIN_WRITE`
  - `apigateway.apis.setIamPolicy - ADMIN_WRITE`
  - `apigateway.gateways.setIamPolicy - ADMIN_WRITE`
- **Method is a long-running or streaming operation**: No.  
- **Filter for this method**: ` protoPayload.methodName="SetIamPolicy" `  

### `google.longrunning.Operations`

The following audit logs are associated with methods belonging to `google.longrunning.Operations`.

#### `CancelOperation`

- **Method**: `google.longrunning.Operations.CancelOperation`  
- **Audit log type**: [Admin activity](/logging/docs/audit#admin-activity)  
- **Permissions**:
  - `apigateway.operations.cancel - ADMIN_WRITE`
- **Method is a long-running or streaming operation**: No.  
- **Filter for this method**: ` protoPayload.methodName="google.longrunning.Operations.CancelOperation" `  

#### `DeleteOperation`

- **Method**: `google.longrunning.Operations.DeleteOperation`  
- **Audit log type**: [Admin activity](/logging/docs/audit#admin-activity)  
- **Permissions**:
  - `apigateway.operations.delete - ADMIN_WRITE`
- **Method is a long-running or streaming operation**: No.  
- **Filter for this method**: ` protoPayload.methodName="google.longrunning.Operations.DeleteOperation" `  

#### `GetOperation`

- **Method**: `google.longrunning.Operations.GetOperation`  
- **Audit log type**: [Data access](/logging/docs/audit#data-access)  
- **Permissions**:
  - `apigateway.operations.get - ADMIN_READ`
- **Method is a long-running or streaming operation**: No.  
- **Filter for this method**: ` protoPayload.methodName="google.longrunning.Operations.GetOperation" `  

#### `ListOperations`

- **Method**: `google.longrunning.Operations.ListOperations`  
- **Audit log type**: [Data access](/logging/docs/audit#data-access)  
- **Permissions**:
  - `apigateway.operations.list - ADMIN_READ`
- **Method is a long-running or streaming operation**: No.  
- **Filter for this method**: ` protoPayload.methodName="google.longrunning.Operations.ListOperations" `  

## Methods that don't produce audit logs

A method might not produce audit logs for one or more of the following reasons:

- It is a high volume method involving significant log generation and storage costs.
- It has low auditing value.
- Another audit or platform log already provides method coverage.

The following methods don't produce audit logs:

- `google.cloud.location.Locations.GetLocation`
- `google.cloud.location.Locations.ListLocations`
- `google.longrunning.Operations.WaitOperation`

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
