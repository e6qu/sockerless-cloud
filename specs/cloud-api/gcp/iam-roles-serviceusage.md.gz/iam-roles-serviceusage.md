# Service Usage roles and permissions

<div class="devsite-article-body clearfix">

This page lists the IAM roles and permissions for Service Usage. To search through all roles and permissions, see the [role and permission index](/iam/docs/roles-permissions).

## Service Usage roles

<div results-count-container="">

</div>

<table class="fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="50%">Role</th>
<th>Permissions</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td class="role-description"><h4 id="serviceusage.apiKeysAdmin" class="role-title add-link" data-text="API Keys Admin " tabindex="-1">API Keys Admin</h4>
<p>(<code translate="no" dir="ltr">roles/serviceusage.apiKeysAdmin</code>)</p>
<span class="role-description"> </span>
<p>Ability to create, delete, update, get and list API keys for a project.</p></td>
<td class="role-permissions"><p><span class="iamperm-wildcard"><code translate="no" dir="ltr">apikeys.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">apikeys.keys.create</code></li>
<li><code translate="no" dir="ltr">apikeys.keys.delete</code></li>
<li><code translate="no" dir="ltr">apikeys.keys.get</code></li>
<li><code translate="no" dir="ltr">apikeys.keys.getKeyString</code></li>
<li><code translate="no" dir="ltr">apikeys.keys.list</code></li>
<li><code translate="no" dir="ltr">apikeys.keys.lookup</code></li>
<li><code translate="no" dir="ltr">apikeys.keys.undelete</code></li>
<li><code translate="no" dir="ltr">apikeys.keys.update</code></li>
</ul>
<p><code translate="no" dir="ltr">orgpolicy.policy.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">serviceusage.apiKeys.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">serviceusage.apiKeys.regenerate</code></li>
<li><code translate="no" dir="ltr">serviceusage.apiKeys.revert</code></li>
</ul>
<p><code translate="no" dir="ltr">serviceusage.operations.get</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="serviceusage.serviceUsageAdmin" class="role-title add-link" data-text="Service Usage Admin " tabindex="-1">Service Usage Admin</h4>
<p>(<code translate="no" dir="ltr">roles/serviceusage.serviceUsageAdmin</code>)</p>
<span class="role-description"> </span>
<p>Ability to enable, disable, and inspect service states, inspect operations, and consume quota and billing for a consumer project.</p></td>
<td class="role-permissions"><p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudquotas.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudquotas.quotas.get</code></li>
<li><code translate="no" dir="ltr">cloudquotas.quotas.update</code></li>
</ul>
<p><code translate="no" dir="ltr">monitoring.timeSeries.list</code></p>
<p><code translate="no" dir="ltr">serviceusage.catalogs.listMembers</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">serviceusage.consumerpolicy.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">serviceusage.consumerpolicy.analyze</code></li>
<li><code translate="no" dir="ltr">serviceusage.consumerpolicy.get</code></li>
<li><code translate="no" dir="ltr">serviceusage.consumerpolicy.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">serviceusage.contentsecuritypolicy.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">serviceusage.contentsecuritypolicy.get</code></li>
<li><code translate="no" dir="ltr">serviceusage.contentsecuritypolicy.update</code></li>
</ul>
<p><code translate="no" dir="ltr">serviceusage.effectivemcppolicy.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.effectivepolicy.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">serviceusage.groups.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">serviceusage.groups.list</code></li>
<li><code translate="no" dir="ltr">serviceusage.groups.listExpandedMembers</code></li>
<li><code translate="no" dir="ltr">serviceusage.groups.listMembers</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">serviceusage.mcppolicy.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">serviceusage.mcppolicy.get</code></li>
<li><code translate="no" dir="ltr">serviceusage.mcppolicy.update</code></li>
</ul>
<p><code translate="no" dir="ltr">serviceusage.operations.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">serviceusage.quotas.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">serviceusage.quotas.get</code></li>
<li><code translate="no" dir="ltr">serviceusage.quotas.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">serviceusage.services.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">serviceusage.services.disable</code></li>
<li><code translate="no" dir="ltr">serviceusage.services.enable</code></li>
<li><code translate="no" dir="ltr">serviceusage.services.get</code></li>
<li><code translate="no" dir="ltr">serviceusage.services.list</code></li>
<li><code translate="no" dir="ltr">serviceusage.services.listApis</code></li>
<li><code translate="no" dir="ltr">serviceusage.services.listDependentServices</code></li>
<li><code translate="no" dir="ltr">serviceusage.services.use</code></li>
</ul>
<p><code translate="no" dir="ltr">serviceusage.values.test</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="serviceusage.serviceUsageConsumer" class="role-title add-link" data-text="Service Usage Consumer " tabindex="-1">Service Usage Consumer</h4>
<p>(<code translate="no" dir="ltr">roles/serviceusage.serviceUsageConsumer</code>)</p>
<span class="role-description"> </span>
<p>Ability to inspect service states and operations, and consume quota and billing for a consumer project.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">monitoring.timeSeries.list</code></p>
<p><code translate="no" dir="ltr">serviceusage.catalogs.listMembers</code></p>
<p><code translate="no" dir="ltr">serviceusage.consumerpolicy.analyze</code></p>
<p><code translate="no" dir="ltr">serviceusage.consumerpolicy.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.contentsecuritypolicy.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.effectivemcppolicy.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.effectivepolicy.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">serviceusage.groups.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">serviceusage.groups.list</code></li>
<li><code translate="no" dir="ltr">serviceusage.groups.listExpandedMembers</code></li>
<li><code translate="no" dir="ltr">serviceusage.groups.listMembers</code></li>
</ul>
<p><code translate="no" dir="ltr">serviceusage.mcppolicy.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.operations.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.quotas.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.list</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.listApis</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.listDependentServices</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.use</code></p>
<p><code translate="no" dir="ltr">serviceusage.values.test</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="serviceusage.serviceUsageViewer" class="role-title add-link" data-text="Service Usage Viewer " tabindex="-1">Service Usage Viewer</h4>
<p>(<code translate="no" dir="ltr">roles/serviceusage.serviceUsageViewer</code>)</p>
<span class="role-description"> </span>
<p>Ability to inspect service states and operations for a consumer project.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">monitoring.timeSeries.list</code></p>
<p><code translate="no" dir="ltr">serviceusage.catalogs.listMembers</code></p>
<p><code translate="no" dir="ltr">serviceusage.consumerpolicy.analyze</code></p>
<p><code translate="no" dir="ltr">serviceusage.consumerpolicy.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.contentsecuritypolicy.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.effectivemcppolicy.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.effectivepolicy.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">serviceusage.groups.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">serviceusage.groups.list</code></li>
<li><code translate="no" dir="ltr">serviceusage.groups.listExpandedMembers</code></li>
<li><code translate="no" dir="ltr">serviceusage.groups.listMembers</code></li>
</ul>
<p><code translate="no" dir="ltr">serviceusage.mcppolicy.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.operations.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.quotas.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.list</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.listApis</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.listDependentServices</code></p>
<p><code translate="no" dir="ltr">serviceusage.values.test</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="serviceusage.apiKeysViewer" class="role-title add-link" data-text="API Keys Viewer " tabindex="-1">API Keys Viewer</h4>
<p>(<code translate="no" dir="ltr">roles/serviceusage.apiKeysViewer</code>)</p>
<span class="role-description"> </span>
<p>Ability to get and list API keys for a project.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">apikeys.keys.get</code></p>
<p><code translate="no" dir="ltr">apikeys.keys.getKeyString</code></p>
<p><code translate="no" dir="ltr">apikeys.keys.list</code></p>
<p><code translate="no" dir="ltr">apikeys.keys.lookup</code></p></td>
</tr>
</tbody>
</table>

## Service Usage permissions

<div results-count-container="">

</div>

<table class="permissions-table fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="45%">Permission</th>
<th>Included in roles</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td><h4 id="serviceusage.apiKeys.regenerate" class="permission-name add-link" data-text="serviceusage.apiKeys.regenerate" tabindex="-1"><code translate="no" dir="ltr">serviceusage.apiKeys.regenerate</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.apiKeysAdmin">API Keys Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.apiKeysAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="serviceusage.apiKeys.revert" class="permission-name add-link" data-text="serviceusage.apiKeys.revert" tabindex="-1"><code translate="no" dir="ltr">serviceusage.apiKeys.revert</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.apiKeysAdmin">API Keys Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.apiKeysAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="serviceusage.catalogs.listMembers" class="permission-name add-link" data-text="serviceusage.catalogs.listMembers" tabindex="-1"><code translate="no" dir="ltr">serviceusage.catalogs.listMembers</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.admin">ApiGateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.editor">ApiGateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.viewer">ApiGateway Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/automl#automl.admin">AutoML Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/automl#automl.editor">AutoML Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/automl#automl.viewer">AutoML Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.admin">Recommendations AI Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.editor">Recommendations AI Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.viewer">Recommendations AI Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/capacityplanner#capacityplanner.admin">Capacityplanner Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/capacityplanner.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/capacityplanner#capacityplanner.viewer">Capacity Planner Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/capacityplanner.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.admin">Cloud Scheduler Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.viewer">Cloud Scheduler Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsecurityscanner#cloudsecurityscanner.admin">Web Security Scanner Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecurityscanner.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsecurityscanner#cloudsecurityscanner.editor">Web Security Scanner Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecurityscanner.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsecurityscanner#cloudsecurityscanner.viewer">Web Security Scanner Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecurityscanner.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.admin">Cloud SQL Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.editor">Cloud SQL Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.viewer">Cloud SQL Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercepricemanagement#commercepricemanagement.editor">Commercepricemanagement Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/commercepricemanagement.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercepricemanagement#commercepricemanagement.viewer">Commerce Price Management Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/commercepricemanagement.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.admin">Composer Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.user">Composer User</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.admin">Compute Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.editor">Compute Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.instanceAdmin">Compute Instance Admin (beta)</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.instanceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.instanceAdmin.v1">Compute Instance Admin (v1)</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.instanceAdmin.v1</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.loadBalancerAdmin">Compute Load Balancer Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.loadBalancerAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.networkAdmin">Compute Network Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.networkUser">Compute Network User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.networkUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.networkViewer">Compute Network Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.networkViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.osAdminLogin">Compute OS Admin Login</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.osAdminLogin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.osLogin">Compute OS Login</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.osLogin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.securityAdmin">Compute Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.storageAdmin">Compute Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.storageAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.viewer">Compute Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataprep#dataprep.admin">Dataprep Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.admin">Deployment Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.editor">Deployment Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.viewer">Deployment Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.user">Discovery Engine User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#monitoring.admin">Monitoring Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/monitoring.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#monitoring.editor">Monitoring Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/monitoring.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.admin">Notebooks Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.editor">Notebooks Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.viewer">Notebooks Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/pubsub#pubsub.admin">Pub/Sub Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/pubsub#pubsub.editor">Pub/Sub Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/pubsub#pubsub.viewer">Pub/Sub Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.admin">Service Management Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageAdmin">Service Usage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageConsumer">Service Usage Consumer</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageConsumer</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageViewer">Service Usage Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.admin">Workload Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/androidmanagement#androidmanagement.user">Android Management User</a> (<code class="role-name" translate="no" dir="ltr">roles/androidmanagement.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/workspacemarketplace#appmetadata.workspaceMarketplaceAppConfigurationAdmin">Workspace Marketplace App Configuration Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/appmetadata.workspaceMarketplaceAppConfigurationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.projectAdmin">Assured OSS Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.projectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.reader">Assured OSS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.adminViewer">Recommendations AI Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.adminViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/capacityplanner#capacityplanner.planner">Capacity Planner</a> (<code class="role-name" translate="no" dir="ltr">roles/capacityplanner.planner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudprofiler#cloudprofiler.user">Cloud Profiler User</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudprofiler.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.jobRunner">Cloud Scheduler Job Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.jobRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.studioUser">Cloud SQL Studio User</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.studioUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercepricemanagement#commercepricemanagement.privateOffersAdmin">Commerce Price Management Private Offers Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/commercepricemanagement.privateOffersAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectAdmin">Environment and Storage Object Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectUser">Environment and Storage Object User</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectViewer">Environment and Storage Object Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.imageUser">Compute Image User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.imageUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.loadBalancerServiceUser">Compute Load Balancer Services User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.loadBalancerServiceUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgFirewallPolicyAdmin">Compute Organization Firewall Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgFirewallPolicyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgFirewallPolicyUser">Compute Organization Firewall Policy User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgFirewallPolicyUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgSecurityPolicyAdmin">Compute Organization Security Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgSecurityPolicyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgSecurityPolicyUser">Compute Organization Security Policy User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgSecurityPolicyUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgSecurityResourceAdmin">Compute Organization Resource Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgSecurityResourceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.packetMirroringAdmin">Compute packet mirroring admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.packetMirroringAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.packetMirroringUser">Compute packet mirroring user</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.packetMirroringUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.entitlementManager">Consumer Procurement Entitlement Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.entitlementManager</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.entitlementViewer">Consumer Procurement Entitlement Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.entitlementViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.procurementAdmin">Consumer Procurement Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.procurementAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.procurementViewer">Consumer Procurement Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.procurementViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataprep#dataprep.projects.user">Dataprep User</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.projects.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.typeEditor">Deployment Manager Type Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.typeEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.typeViewer">Deployment Manager Type Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.typeViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceUser">Gemini Enterprise User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.podcastApiUser">Podcast API User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.podcastApiUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/earthengine#earthengine.appsPublisher">Earth Engine Apps Publisher</a> (<code class="role-name" translate="no" dir="ltr">roles/earthengine.appsPublisher</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.growthAdmin">Firebase Grow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.growthAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.growthViewer">Firebase Grow Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.growthViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.qualityAdmin">Firebase Quality Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.qualityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.qualityViewer">Firebase Quality Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.qualityViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.gatewayAdmin">Connect Gateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.gatewayAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.gatewayEditor">Connect Gateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.gatewayEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.gatewayReader">Connect Gateway Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.gatewayReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.scopeEditorProjectLevel">Fleet Project-level Scope Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.scopeEditorProjectLevel</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.scopeViewerProjectLevel">Fleet Project-level Scope Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.scopeViewerProjectLevel</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkservices#networkservices.serviceExtensionsAdmin">Service Extensions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networkservices.serviceExtensionsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkservices#networkservices.serviceExtensionsViewer">Service Extensions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/networkservices.serviceExtensionsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.legacyAdmin">Notebooks Legacy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.legacyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.legacyViewer">Notebooks Legacy Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.legacyViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.runner">Notebooks Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.runner</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminEditor">Security Center Admin Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminViewer">Security Center Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.quotaAdmin">Quota Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.quotaAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.quotaViewer">Quota Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.quotaViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#stackdriver.accounts.editor">Stackdriver Accounts Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/stackdriver.accounts.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.deploymentAdmin">Workload Manager Deployment Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.deploymentAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.workloadViewer">Workload Manager Workload Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.workloadViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.onlinePredictionServiceAgent">Vertex AI Online Prediction Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.onlinePredictionServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/anthos#anthos.serviceAgent">Anthos Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/anthos.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/anthosservicemesh#anthosservicemesh.serviceAgent">Anthos Service Mesh Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/anthosservicemesh.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/anthossupport#anthossupport.serviceAgent">Anthos Support Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/anthossupport.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/apigateway#apigateway_management.serviceAgent">Cloud API Gateway Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway_management.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAgent">App Engine Standard Environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengineflex#appengineflex.serviceAgent">App Engine flexible environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengineflex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/assuredworkloads#assuredworkloads.serviceAgent">Assured Workloads Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredworkloads.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.serviceAgent">Audit Manager Auditing Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/batch#batch.serviceAgent">Google Batch Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/batch.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.serviceAgent">Chronicle Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.serviceAgent">Cloud Security Compliance Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/tpu#cloudtpu.serviceAgent">Cloud TPU V2 API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtpu.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.ServiceAgent">Container Analysis Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datalabeling#datalabeling.serviceAgent">Data Labeling Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datalabeling.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dspm#dspm.serviceAgent">DSPM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.clusterServiceAgent">Edge Container Cluster Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.clusterServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.serviceAgent">Edge Container Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.managementServiceAgent">Firebase Service Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.managementServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.sdkProvisioningServiceAgent">Firebase SDK Provisioning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.sdkProvisioningServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasemods#firebasemods.serviceAgent">Firebase Extensions API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasemods.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/fleetengine#fleetengine.serviceAgent">FleetEngine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/fleetengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/lifesciences#genomics.serviceAgent">Genomics Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/genomics.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkehub#gkehub.serviceAgent">GKE Hub Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.sharedVpcServiceAgent">Cluster Director Shared VPC Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.sharedVpcServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/integrations#integrations.serviceAgent">Application Integration Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/krmapihosting#krmapihosting.anthosApiEndpointServiceAgent">KRM API Hosting AnthosApiEndpoint Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/krmapihosting.anthosApiEndpointServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/lifesciences#lifesciences.serviceAgent">Cloud Life Sciences Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/lifesciences.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/meshcontrolplane#meshcontrolplane.serviceAgent">Mesh Managed Control Plane Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/meshcontrolplane.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusteringress#multiclusteringress.serviceAgent">Multi Cluster Ingress Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusteringress.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/notebooks#notebooks.serviceAgent">AI Platform Notebooks Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.automationServiceAgent">Security Center Automation Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.automationServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.controlServiceAgent">Security Center Control Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.controlServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.securityHealthAnalyticsServiceAgent">Security Health Analytics Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.securityHealthAnalyticsServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.serviceAgent">Security Center Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/spectrumsas#spectrumsas.serviceAgent">Spectrum SAS Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/spectrumsas.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/workstations#workstations.serviceAgent">Workstations Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/workstations.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="serviceusage.consumerpolicy.analyze" class="permission-name add-link" data-text="serviceusage.consumerpolicy.analyze" tabindex="-1"><code translate="no" dir="ltr">serviceusage.consumerpolicy.analyze</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.admin">ApiGateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.editor">ApiGateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.viewer">ApiGateway Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/automl#automl.admin">AutoML Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/automl#automl.editor">AutoML Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/automl#automl.viewer">AutoML Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.admin">Recommendations AI Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.editor">Recommendations AI Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.viewer">Recommendations AI Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/capacityplanner#capacityplanner.admin">Capacityplanner Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/capacityplanner.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/capacityplanner#capacityplanner.viewer">Capacity Planner Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/capacityplanner.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.admin">Cloud Scheduler Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.viewer">Cloud Scheduler Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsecurityscanner#cloudsecurityscanner.admin">Web Security Scanner Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecurityscanner.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsecurityscanner#cloudsecurityscanner.editor">Web Security Scanner Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecurityscanner.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsecurityscanner#cloudsecurityscanner.viewer">Web Security Scanner Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecurityscanner.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.admin">Cloud SQL Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.editor">Cloud SQL Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.viewer">Cloud SQL Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercepricemanagement#commercepricemanagement.editor">Commercepricemanagement Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/commercepricemanagement.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercepricemanagement#commercepricemanagement.viewer">Commerce Price Management Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/commercepricemanagement.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.admin">Composer Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.user">Composer User</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.admin">Compute Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.editor">Compute Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.instanceAdmin">Compute Instance Admin (beta)</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.instanceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.instanceAdmin.v1">Compute Instance Admin (v1)</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.instanceAdmin.v1</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.loadBalancerAdmin">Compute Load Balancer Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.loadBalancerAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.networkAdmin">Compute Network Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.networkUser">Compute Network User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.networkUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.networkViewer">Compute Network Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.networkViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.osAdminLogin">Compute OS Admin Login</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.osAdminLogin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.osLogin">Compute OS Login</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.osLogin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.securityAdmin">Compute Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.storageAdmin">Compute Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.storageAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.viewer">Compute Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataprep#dataprep.admin">Dataprep Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.admin">Deployment Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.editor">Deployment Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.viewer">Deployment Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.user">Discovery Engine User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.admin">Managed Kafka Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.viewer">Managed Kafka Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#monitoring.admin">Monitoring Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/monitoring.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#monitoring.editor">Monitoring Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/monitoring.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.admin">Notebooks Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.editor">Notebooks Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.viewer">Notebooks Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/pubsub#pubsub.admin">Pub/Sub Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/pubsub#pubsub.editor">Pub/Sub Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/pubsub#pubsub.viewer">Pub/Sub Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.admin">Service Management Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageAdmin">Service Usage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageConsumer">Service Usage Consumer</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageConsumer</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageViewer">Service Usage Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.admin">Workload Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/androidmanagement#androidmanagement.user">Android Management User</a> (<code class="role-name" translate="no" dir="ltr">roles/androidmanagement.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/workspacemarketplace#appmetadata.workspaceMarketplaceAppConfigurationAdmin">Workspace Marketplace App Configuration Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/appmetadata.workspaceMarketplaceAppConfigurationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.projectAdmin">Assured OSS Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.projectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.reader">Assured OSS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.adminViewer">Recommendations AI Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.adminViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/capacityplanner#capacityplanner.planner">Capacity Planner</a> (<code class="role-name" translate="no" dir="ltr">roles/capacityplanner.planner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudprofiler#cloudprofiler.user">Cloud Profiler User</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudprofiler.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.jobRunner">Cloud Scheduler Job Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.jobRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.studioUser">Cloud SQL Studio User</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.studioUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercepricemanagement#commercepricemanagement.privateOffersAdmin">Commerce Price Management Private Offers Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/commercepricemanagement.privateOffersAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectAdmin">Environment and Storage Object Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectUser">Environment and Storage Object User</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectViewer">Environment and Storage Object Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.imageUser">Compute Image User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.imageUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.loadBalancerServiceUser">Compute Load Balancer Services User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.loadBalancerServiceUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgFirewallPolicyAdmin">Compute Organization Firewall Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgFirewallPolicyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgFirewallPolicyUser">Compute Organization Firewall Policy User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgFirewallPolicyUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgSecurityPolicyAdmin">Compute Organization Security Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgSecurityPolicyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgSecurityPolicyUser">Compute Organization Security Policy User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgSecurityPolicyUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgSecurityResourceAdmin">Compute Organization Resource Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgSecurityResourceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.packetMirroringAdmin">Compute packet mirroring admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.packetMirroringAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.packetMirroringUser">Compute packet mirroring user</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.packetMirroringUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.entitlementManager">Consumer Procurement Entitlement Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.entitlementManager</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.entitlementViewer">Consumer Procurement Entitlement Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.entitlementViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.procurementAdmin">Consumer Procurement Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.procurementAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.procurementViewer">Consumer Procurement Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.procurementViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataprep#dataprep.projects.user">Dataprep User</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.projects.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.typeEditor">Deployment Manager Type Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.typeEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.typeViewer">Deployment Manager Type Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.typeViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceUser">Gemini Enterprise User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.podcastApiUser">Podcast API User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.podcastApiUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/earthengine#earthengine.appsPublisher">Earth Engine Apps Publisher</a> (<code class="role-name" translate="no" dir="ltr">roles/earthengine.appsPublisher</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.growthAdmin">Firebase Grow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.growthAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.growthViewer">Firebase Grow Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.growthViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.qualityAdmin">Firebase Quality Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.qualityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.qualityViewer">Firebase Quality Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.qualityViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.gatewayAdmin">Connect Gateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.gatewayAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.gatewayEditor">Connect Gateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.gatewayEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.gatewayReader">Connect Gateway Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.gatewayReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.scopeEditorProjectLevel">Fleet Project-level Scope Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.scopeEditorProjectLevel</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.scopeViewerProjectLevel">Fleet Project-level Scope Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.scopeViewerProjectLevel</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.client">Managed Kafka Client</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.client</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.clusterEditor">Managed Kafka Cluster Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.clusterEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.connectorEditor">Managed Kafka Connector Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.connectorEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.consumerGroupEditor">Managed Kafka Consumer Group Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.consumerGroupEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.topicEditor">Managed Kafka Topic Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.topicEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkservices#networkservices.serviceExtensionsAdmin">Service Extensions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networkservices.serviceExtensionsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkservices#networkservices.serviceExtensionsViewer">Service Extensions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/networkservices.serviceExtensionsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.legacyAdmin">Notebooks Legacy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.legacyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.legacyViewer">Notebooks Legacy Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.legacyViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.runner">Notebooks Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.runner</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminEditor">Security Center Admin Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminViewer">Security Center Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.quotaAdmin">Quota Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.quotaAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.quotaViewer">Quota Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.quotaViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#stackdriver.accounts.editor">Stackdriver Accounts Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/stackdriver.accounts.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.deploymentAdmin">Workload Manager Deployment Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.deploymentAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.workloadViewer">Workload Manager Workload Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.workloadViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.onlinePredictionServiceAgent">Vertex AI Online Prediction Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.onlinePredictionServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/anthos#anthos.serviceAgent">Anthos Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/anthos.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/anthosservicemesh#anthosservicemesh.serviceAgent">Anthos Service Mesh Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/anthosservicemesh.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/anthossupport#anthossupport.serviceAgent">Anthos Support Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/anthossupport.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/apigateway#apigateway_management.serviceAgent">Cloud API Gateway Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway_management.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAgent">App Engine Standard Environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengineflex#appengineflex.serviceAgent">App Engine flexible environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengineflex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/assuredworkloads#assuredworkloads.serviceAgent">Assured Workloads Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredworkloads.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.serviceAgent">Audit Manager Auditing Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/batch#batch.serviceAgent">Google Batch Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/batch.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.serviceAgent">Chronicle Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.serviceAgent">Cloud Security Compliance Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/tpu#cloudtpu.serviceAgent">Cloud TPU V2 API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtpu.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.ServiceAgent">Container Analysis Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datalabeling#datalabeling.serviceAgent">Data Labeling Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datalabeling.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dspm#dspm.serviceAgent">DSPM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.clusterServiceAgent">Edge Container Cluster Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.clusterServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.serviceAgent">Edge Container Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.managementServiceAgent">Firebase Service Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.managementServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.sdkProvisioningServiceAgent">Firebase SDK Provisioning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.sdkProvisioningServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasemods#firebasemods.serviceAgent">Firebase Extensions API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasemods.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/fleetengine#fleetengine.serviceAgent">FleetEngine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/fleetengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/lifesciences#genomics.serviceAgent">Genomics Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/genomics.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkehub#gkehub.serviceAgent">GKE Hub Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.sharedVpcServiceAgent">Cluster Director Shared VPC Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.sharedVpcServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/integrations#integrations.serviceAgent">Application Integration Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/krmapihosting#krmapihosting.anthosApiEndpointServiceAgent">KRM API Hosting AnthosApiEndpoint Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/krmapihosting.anthosApiEndpointServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/lifesciences#lifesciences.serviceAgent">Cloud Life Sciences Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/lifesciences.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/meshcontrolplane#meshcontrolplane.serviceAgent">Mesh Managed Control Plane Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/meshcontrolplane.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusteringress#multiclusteringress.serviceAgent">Multi Cluster Ingress Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusteringress.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/notebooks#notebooks.serviceAgent">AI Platform Notebooks Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.automationServiceAgent">Security Center Automation Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.automationServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.controlServiceAgent">Security Center Control Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.controlServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.securityHealthAnalyticsServiceAgent">Security Health Analytics Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.securityHealthAnalyticsServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.serviceAgent">Security Center Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/spectrumsas#spectrumsas.serviceAgent">Spectrum SAS Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/spectrumsas.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/workstations#workstations.serviceAgent">Workstations Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/workstations.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="serviceusage.consumerpolicy.get" class="permission-name add-link" data-text="serviceusage.consumerpolicy.get" tabindex="-1"><code translate="no" dir="ltr">serviceusage.consumerpolicy.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.admin">ApiGateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.editor">ApiGateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.viewer">ApiGateway Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/automl#automl.admin">AutoML Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/automl#automl.editor">AutoML Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/automl#automl.viewer">AutoML Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.admin">Recommendations AI Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.editor">Recommendations AI Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.viewer">Recommendations AI Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/capacityplanner#capacityplanner.admin">Capacityplanner Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/capacityplanner.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/capacityplanner#capacityplanner.viewer">Capacity Planner Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/capacityplanner.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.admin">Cloud Scheduler Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.viewer">Cloud Scheduler Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsecurityscanner#cloudsecurityscanner.admin">Web Security Scanner Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecurityscanner.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsecurityscanner#cloudsecurityscanner.editor">Web Security Scanner Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecurityscanner.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsecurityscanner#cloudsecurityscanner.viewer">Web Security Scanner Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecurityscanner.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.admin">Cloud SQL Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.editor">Cloud SQL Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.viewer">Cloud SQL Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercepricemanagement#commercepricemanagement.editor">Commercepricemanagement Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/commercepricemanagement.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercepricemanagement#commercepricemanagement.viewer">Commerce Price Management Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/commercepricemanagement.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.admin">Composer Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.user">Composer User</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.admin">Compute Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.editor">Compute Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.instanceAdmin">Compute Instance Admin (beta)</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.instanceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.instanceAdmin.v1">Compute Instance Admin (v1)</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.instanceAdmin.v1</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.loadBalancerAdmin">Compute Load Balancer Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.loadBalancerAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.networkAdmin">Compute Network Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.networkUser">Compute Network User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.networkUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.networkViewer">Compute Network Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.networkViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.osAdminLogin">Compute OS Admin Login</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.osAdminLogin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.osLogin">Compute OS Login</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.osLogin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.securityAdmin">Compute Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.storageAdmin">Compute Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.storageAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.viewer">Compute Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataprep#dataprep.admin">Dataprep Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.admin">Deployment Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.editor">Deployment Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.viewer">Deployment Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.user">Discovery Engine User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.admin">Managed Kafka Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.viewer">Managed Kafka Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/mapsanalytics#mapsanalytics.viewer">Maps Analytics Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/mapsanalytics.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#monitoring.admin">Monitoring Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/monitoring.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#monitoring.editor">Monitoring Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/monitoring.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.admin">Notebooks Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.editor">Notebooks Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.viewer">Notebooks Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/pubsub#pubsub.admin">Pub/Sub Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/pubsub#pubsub.editor">Pub/Sub Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/pubsub#pubsub.viewer">Pub/Sub Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.admin">Service Management Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageAdmin">Service Usage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageConsumer">Service Usage Consumer</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageConsumer</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageViewer">Service Usage Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.admin">Workload Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/androidmanagement#androidmanagement.user">Android Management User</a> (<code class="role-name" translate="no" dir="ltr">roles/androidmanagement.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/workspacemarketplace#appmetadata.workspaceMarketplaceAppConfigurationAdmin">Workspace Marketplace App Configuration Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/appmetadata.workspaceMarketplaceAppConfigurationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.projectAdmin">Assured OSS Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.projectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.reader">Assured OSS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.adminViewer">Recommendations AI Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.adminViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/capacityplanner#capacityplanner.planner">Capacity Planner</a> (<code class="role-name" translate="no" dir="ltr">roles/capacityplanner.planner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudprofiler#cloudprofiler.user">Cloud Profiler User</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudprofiler.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.jobRunner">Cloud Scheduler Job Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.jobRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.studioUser">Cloud SQL Studio User</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.studioUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercepricemanagement#commercepricemanagement.privateOffersAdmin">Commerce Price Management Private Offers Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/commercepricemanagement.privateOffersAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectAdmin">Environment and Storage Object Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectUser">Environment and Storage Object User</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectViewer">Environment and Storage Object Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.imageUser">Compute Image User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.imageUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.loadBalancerServiceUser">Compute Load Balancer Services User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.loadBalancerServiceUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgFirewallPolicyAdmin">Compute Organization Firewall Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgFirewallPolicyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgFirewallPolicyUser">Compute Organization Firewall Policy User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgFirewallPolicyUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgSecurityPolicyAdmin">Compute Organization Security Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgSecurityPolicyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgSecurityPolicyUser">Compute Organization Security Policy User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgSecurityPolicyUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgSecurityResourceAdmin">Compute Organization Resource Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgSecurityResourceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.packetMirroringAdmin">Compute packet mirroring admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.packetMirroringAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.packetMirroringUser">Compute packet mirroring user</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.packetMirroringUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.entitlementManager">Consumer Procurement Entitlement Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.entitlementManager</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.entitlementViewer">Consumer Procurement Entitlement Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.entitlementViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.procurementAdmin">Consumer Procurement Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.procurementAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.procurementViewer">Consumer Procurement Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.procurementViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataprep#dataprep.projects.user">Dataprep User</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.projects.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.typeEditor">Deployment Manager Type Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.typeEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.typeViewer">Deployment Manager Type Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.typeViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceUser">Gemini Enterprise User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.podcastApiUser">Podcast API User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.podcastApiUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/earthengine#earthengine.appsPublisher">Earth Engine Apps Publisher</a> (<code class="role-name" translate="no" dir="ltr">roles/earthengine.appsPublisher</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.growthAdmin">Firebase Grow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.growthAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.growthViewer">Firebase Grow Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.growthViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.qualityAdmin">Firebase Quality Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.qualityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.qualityViewer">Firebase Quality Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.qualityViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.gatewayAdmin">Connect Gateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.gatewayAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.gatewayEditor">Connect Gateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.gatewayEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.gatewayReader">Connect Gateway Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.gatewayReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.scopeEditorProjectLevel">Fleet Project-level Scope Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.scopeEditorProjectLevel</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.scopeViewerProjectLevel">Fleet Project-level Scope Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.scopeViewerProjectLevel</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.client">Managed Kafka Client</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.client</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.clusterEditor">Managed Kafka Cluster Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.clusterEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.connectorEditor">Managed Kafka Connector Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.connectorEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.consumerGroupEditor">Managed Kafka Consumer Group Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.consumerGroupEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.topicEditor">Managed Kafka Topic Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.topicEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/mapsanalytics#mapsanalytics.mobilitySolutionsOverageViewer">Mobility Solutions Overages Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/mapsanalytics.mobilitySolutionsOverageViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkservices#networkservices.serviceExtensionsAdmin">Service Extensions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networkservices.serviceExtensionsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkservices#networkservices.serviceExtensionsViewer">Service Extensions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/networkservices.serviceExtensionsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.legacyAdmin">Notebooks Legacy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.legacyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.legacyViewer">Notebooks Legacy Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.legacyViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.runner">Notebooks Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.runner</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminEditor">Security Center Admin Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminViewer">Security Center Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.quotaAdmin">Quota Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.quotaAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.quotaViewer">Quota Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.quotaViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#stackdriver.accounts.editor">Stackdriver Accounts Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/stackdriver.accounts.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.deploymentAdmin">Workload Manager Deployment Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.deploymentAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.workloadViewer">Workload Manager Workload Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.workloadViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.onlinePredictionServiceAgent">Vertex AI Online Prediction Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.onlinePredictionServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/anthos#anthos.serviceAgent">Anthos Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/anthos.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/anthosservicemesh#anthosservicemesh.serviceAgent">Anthos Service Mesh Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/anthosservicemesh.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/anthossupport#anthossupport.serviceAgent">Anthos Support Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/anthossupport.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/apigateway#apigateway_management.serviceAgent">Cloud API Gateway Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway_management.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAgent">App Engine Standard Environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengineflex#appengineflex.serviceAgent">App Engine flexible environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengineflex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/assuredworkloads#assuredworkloads.serviceAgent">Assured Workloads Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredworkloads.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.serviceAgent">Audit Manager Auditing Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/batch#batch.serviceAgent">Google Batch Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/batch.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.serviceAgent">Chronicle Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.serviceAgent">Cloud Security Compliance Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/tpu#cloudtpu.serviceAgent">Cloud TPU V2 API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtpu.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.ServiceAgent">Container Analysis Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datalabeling#datalabeling.serviceAgent">Data Labeling Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datalabeling.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dspm#dspm.serviceAgent">DSPM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.clusterServiceAgent">Edge Container Cluster Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.clusterServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.serviceAgent">Edge Container Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.managementServiceAgent">Firebase Service Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.managementServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.sdkProvisioningServiceAgent">Firebase SDK Provisioning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.sdkProvisioningServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasemods#firebasemods.serviceAgent">Firebase Extensions API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasemods.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/fleetengine#fleetengine.serviceAgent">FleetEngine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/fleetengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/lifesciences#genomics.serviceAgent">Genomics Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/genomics.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkehub#gkehub.serviceAgent">GKE Hub Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.sharedVpcServiceAgent">Cluster Director Shared VPC Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.sharedVpcServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/integrations#integrations.serviceAgent">Application Integration Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/krmapihosting#krmapihosting.anthosApiEndpointServiceAgent">KRM API Hosting AnthosApiEndpoint Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/krmapihosting.anthosApiEndpointServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/lifesciences#lifesciences.serviceAgent">Cloud Life Sciences Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/lifesciences.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/meshcontrolplane#meshcontrolplane.serviceAgent">Mesh Managed Control Plane Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/meshcontrolplane.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusteringress#multiclusteringress.serviceAgent">Multi Cluster Ingress Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusteringress.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/notebooks#notebooks.serviceAgent">AI Platform Notebooks Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.automationServiceAgent">Security Center Automation Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.automationServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.controlServiceAgent">Security Center Control Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.controlServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.securityHealthAnalyticsServiceAgent">Security Health Analytics Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.securityHealthAnalyticsServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.serviceAgent">Security Center Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/spectrumsas#spectrumsas.serviceAgent">Spectrum SAS Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/spectrumsas.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/workstations#workstations.serviceAgent">Workstations Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/workstations.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="serviceusage.consumerpolicy.update" class="permission-name add-link" data-text="serviceusage.consumerpolicy.update" tabindex="-1"><code translate="no" dir="ltr">serviceusage.consumerpolicy.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#monitoring.admin">Monitoring Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/monitoring.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#monitoring.editor">Monitoring Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/monitoring.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageAdmin">Service Usage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.entitlementManager">Consumer Procurement Entitlement Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.entitlementManager</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.procurementAdmin">Consumer Procurement Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.procurementAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.quotaAdmin">Quota Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.quotaAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#stackdriver.accounts.editor">Stackdriver Accounts Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/stackdriver.accounts.editor</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAgent">App Engine Standard Environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengineflex#appengineflex.serviceAgent">App Engine flexible environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengineflex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/assuredworkloads#assuredworkloads.serviceAgent">Assured Workloads Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredworkloads.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.serviceAgent">Chronicle Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.serviceAgent">Cloud Security Compliance Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dspm#dspm.serviceAgent">DSPM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.clusterServiceAgent">Edge Container Cluster Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.clusterServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.managementServiceAgent">Firebase Service Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.managementServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.sdkProvisioningServiceAgent">Firebase SDK Provisioning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.sdkProvisioningServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasemods#firebasemods.serviceAgent">Firebase Extensions API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasemods.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/fleetengine#fleetengine.serviceAgent">FleetEngine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/fleetengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/krmapihosting#krmapihosting.anthosApiEndpointServiceAgent">KRM API Hosting AnthosApiEndpoint Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/krmapihosting.anthosApiEndpointServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.automationServiceAgent">Security Center Automation Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.automationServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.controlServiceAgent">Security Center Control Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.controlServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.serviceAgent">Security Center Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="serviceusage.contentsecuritypolicy.get" class="permission-name add-link" data-text="serviceusage.contentsecuritypolicy.get" tabindex="-1"><code translate="no" dir="ltr">serviceusage.contentsecuritypolicy.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.user">Discovery Engine User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageAdmin">Service Usage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageConsumer">Service Usage Consumer</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageConsumer</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageViewer">Service Usage Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceUser">Gemini Enterprise User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.podcastApiUser">Podcast API User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.podcastApiUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.growthAdmin">Firebase Grow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.growthAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.growthViewer">Firebase Grow Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.growthViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.qualityAdmin">Firebase Quality Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.qualityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.qualityViewer">Firebase Quality Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.qualityViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.serviceAgent">Audit Manager Auditing Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.serviceAgent">Cloud Security Compliance Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.clusterServiceAgent">Edge Container Cluster Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.clusterServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="serviceusage.contentsecuritypolicy.update" class="permission-name add-link" data-text="serviceusage.contentsecuritypolicy.update" tabindex="-1"><code translate="no" dir="ltr">serviceusage.contentsecuritypolicy.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageAdmin">Service Usage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="serviceusage.effectivemcppolicy.get" class="permission-name add-link" data-text="serviceusage.effectivemcppolicy.get" tabindex="-1"><code translate="no" dir="ltr">serviceusage.effectivemcppolicy.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudapiregistry#cloudapiregistry.admin">Cloud API Registry Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudapiregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudapiregistry#cloudapiregistry.viewer">Cloud API Registry Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudapiregistry.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.user">Discovery Engine User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageAdmin">Service Usage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageConsumer">Service Usage Consumer</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageConsumer</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageViewer">Service Usage Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceUser">Gemini Enterprise User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.podcastApiUser">Podcast API User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.podcastApiUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.growthAdmin">Firebase Grow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.growthAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.growthViewer">Firebase Grow Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.growthViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.qualityAdmin">Firebase Quality Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.qualityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.qualityViewer">Firebase Quality Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.qualityViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.serviceAgent">Audit Manager Auditing Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.serviceAgent">Cloud Security Compliance Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.clusterServiceAgent">Edge Container Cluster Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.clusterServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="serviceusage.effectivepolicy.get" class="permission-name add-link" data-text="serviceusage.effectivepolicy.get" tabindex="-1"><code translate="no" dir="ltr">serviceusage.effectivepolicy.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.admin">ApiGateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.editor">ApiGateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.viewer">ApiGateway Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/automl#automl.admin">AutoML Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/automl#automl.editor">AutoML Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/automl#automl.viewer">AutoML Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.admin">Recommendations AI Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.editor">Recommendations AI Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.viewer">Recommendations AI Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/capacityplanner#capacityplanner.admin">Capacityplanner Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/capacityplanner.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/capacityplanner#capacityplanner.viewer">Capacity Planner Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/capacityplanner.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.admin">Cloud Scheduler Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.viewer">Cloud Scheduler Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsecurityscanner#cloudsecurityscanner.admin">Web Security Scanner Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecurityscanner.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsecurityscanner#cloudsecurityscanner.editor">Web Security Scanner Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecurityscanner.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsecurityscanner#cloudsecurityscanner.viewer">Web Security Scanner Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecurityscanner.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.admin">Cloud SQL Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.editor">Cloud SQL Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.viewer">Cloud SQL Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercepricemanagement#commercepricemanagement.editor">Commercepricemanagement Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/commercepricemanagement.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercepricemanagement#commercepricemanagement.viewer">Commerce Price Management Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/commercepricemanagement.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.admin">Composer Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.user">Composer User</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.admin">Compute Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.editor">Compute Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.instanceAdmin">Compute Instance Admin (beta)</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.instanceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.instanceAdmin.v1">Compute Instance Admin (v1)</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.instanceAdmin.v1</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.loadBalancerAdmin">Compute Load Balancer Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.loadBalancerAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.networkAdmin">Compute Network Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.networkUser">Compute Network User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.networkUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.networkViewer">Compute Network Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.networkViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.osAdminLogin">Compute OS Admin Login</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.osAdminLogin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.osLogin">Compute OS Login</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.osLogin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.securityAdmin">Compute Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.storageAdmin">Compute Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.storageAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.viewer">Compute Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataprep#dataprep.admin">Dataprep Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.admin">Deployment Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.editor">Deployment Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.viewer">Deployment Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.user">Discovery Engine User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.admin">Managed Kafka Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.viewer">Managed Kafka Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/mapsanalytics#mapsanalytics.viewer">Maps Analytics Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/mapsanalytics.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#monitoring.admin">Monitoring Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/monitoring.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#monitoring.editor">Monitoring Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/monitoring.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.admin">Notebooks Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.editor">Notebooks Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.viewer">Notebooks Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/pubsub#pubsub.admin">Pub/Sub Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/pubsub#pubsub.editor">Pub/Sub Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/pubsub#pubsub.viewer">Pub/Sub Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.admin">Service Management Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageAdmin">Service Usage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageConsumer">Service Usage Consumer</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageConsumer</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageViewer">Service Usage Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.admin">Workload Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/androidmanagement#androidmanagement.user">Android Management User</a> (<code class="role-name" translate="no" dir="ltr">roles/androidmanagement.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/workspacemarketplace#appmetadata.workspaceMarketplaceAppConfigurationAdmin">Workspace Marketplace App Configuration Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/appmetadata.workspaceMarketplaceAppConfigurationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.projectAdmin">Assured OSS Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.projectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.reader">Assured OSS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.adminViewer">Recommendations AI Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.adminViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/capacityplanner#capacityplanner.planner">Capacity Planner</a> (<code class="role-name" translate="no" dir="ltr">roles/capacityplanner.planner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudprofiler#cloudprofiler.user">Cloud Profiler User</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudprofiler.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.jobRunner">Cloud Scheduler Job Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.jobRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.studioUser">Cloud SQL Studio User</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.studioUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercepricemanagement#commercepricemanagement.privateOffersAdmin">Commerce Price Management Private Offers Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/commercepricemanagement.privateOffersAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectAdmin">Environment and Storage Object Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectUser">Environment and Storage Object User</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectViewer">Environment and Storage Object Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.imageUser">Compute Image User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.imageUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.loadBalancerServiceUser">Compute Load Balancer Services User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.loadBalancerServiceUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgFirewallPolicyAdmin">Compute Organization Firewall Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgFirewallPolicyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgFirewallPolicyUser">Compute Organization Firewall Policy User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgFirewallPolicyUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgSecurityPolicyAdmin">Compute Organization Security Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgSecurityPolicyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgSecurityPolicyUser">Compute Organization Security Policy User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgSecurityPolicyUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgSecurityResourceAdmin">Compute Organization Resource Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgSecurityResourceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.packetMirroringAdmin">Compute packet mirroring admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.packetMirroringAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.packetMirroringUser">Compute packet mirroring user</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.packetMirroringUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.entitlementManager">Consumer Procurement Entitlement Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.entitlementManager</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.entitlementViewer">Consumer Procurement Entitlement Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.entitlementViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.procurementAdmin">Consumer Procurement Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.procurementAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.procurementViewer">Consumer Procurement Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.procurementViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataprep#dataprep.projects.user">Dataprep User</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.projects.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.typeEditor">Deployment Manager Type Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.typeEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.typeViewer">Deployment Manager Type Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.typeViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceUser">Gemini Enterprise User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.podcastApiUser">Podcast API User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.podcastApiUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/earthengine#earthengine.appsPublisher">Earth Engine Apps Publisher</a> (<code class="role-name" translate="no" dir="ltr">roles/earthengine.appsPublisher</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.growthAdmin">Firebase Grow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.growthAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.growthViewer">Firebase Grow Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.growthViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.qualityAdmin">Firebase Quality Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.qualityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.qualityViewer">Firebase Quality Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.qualityViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.gatewayAdmin">Connect Gateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.gatewayAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.gatewayEditor">Connect Gateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.gatewayEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.gatewayReader">Connect Gateway Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.gatewayReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.scopeEditorProjectLevel">Fleet Project-level Scope Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.scopeEditorProjectLevel</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.scopeViewerProjectLevel">Fleet Project-level Scope Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.scopeViewerProjectLevel</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.client">Managed Kafka Client</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.client</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.clusterEditor">Managed Kafka Cluster Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.clusterEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.connectorEditor">Managed Kafka Connector Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.connectorEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.consumerGroupEditor">Managed Kafka Consumer Group Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.consumerGroupEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.topicEditor">Managed Kafka Topic Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.topicEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/mapsanalytics#mapsanalytics.mobilitySolutionsOverageViewer">Mobility Solutions Overages Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/mapsanalytics.mobilitySolutionsOverageViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkservices#networkservices.serviceExtensionsAdmin">Service Extensions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networkservices.serviceExtensionsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkservices#networkservices.serviceExtensionsViewer">Service Extensions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/networkservices.serviceExtensionsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.legacyAdmin">Notebooks Legacy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.legacyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.legacyViewer">Notebooks Legacy Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.legacyViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.runner">Notebooks Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.runner</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminEditor">Security Center Admin Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminViewer">Security Center Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.quotaAdmin">Quota Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.quotaAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.quotaViewer">Quota Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.quotaViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#stackdriver.accounts.editor">Stackdriver Accounts Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/stackdriver.accounts.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.deploymentAdmin">Workload Manager Deployment Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.deploymentAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.workloadViewer">Workload Manager Workload Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.workloadViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.onlinePredictionServiceAgent">Vertex AI Online Prediction Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.onlinePredictionServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/anthos#anthos.serviceAgent">Anthos Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/anthos.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/anthosservicemesh#anthosservicemesh.serviceAgent">Anthos Service Mesh Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/anthosservicemesh.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/anthossupport#anthossupport.serviceAgent">Anthos Support Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/anthossupport.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/apigateway#apigateway_management.serviceAgent">Cloud API Gateway Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway_management.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAgent">App Engine Standard Environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengineflex#appengineflex.serviceAgent">App Engine flexible environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengineflex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/assuredworkloads#assuredworkloads.serviceAgent">Assured Workloads Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredworkloads.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.serviceAgent">Audit Manager Auditing Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/batch#batch.serviceAgent">Google Batch Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/batch.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.serviceAgent">Chronicle Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.serviceAgent">Cloud Security Compliance Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/tpu#cloudtpu.serviceAgent">Cloud TPU V2 API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtpu.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.ServiceAgent">Container Analysis Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datalabeling#datalabeling.serviceAgent">Data Labeling Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datalabeling.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dspm#dspm.serviceAgent">DSPM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.clusterServiceAgent">Edge Container Cluster Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.clusterServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.serviceAgent">Edge Container Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.managementServiceAgent">Firebase Service Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.managementServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.sdkProvisioningServiceAgent">Firebase SDK Provisioning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.sdkProvisioningServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasemods#firebasemods.serviceAgent">Firebase Extensions API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasemods.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/fleetengine#fleetengine.serviceAgent">FleetEngine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/fleetengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/lifesciences#genomics.serviceAgent">Genomics Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/genomics.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkehub#gkehub.serviceAgent">GKE Hub Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.sharedVpcServiceAgent">Cluster Director Shared VPC Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.sharedVpcServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/integrations#integrations.serviceAgent">Application Integration Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/krmapihosting#krmapihosting.anthosApiEndpointServiceAgent">KRM API Hosting AnthosApiEndpoint Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/krmapihosting.anthosApiEndpointServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/lifesciences#lifesciences.serviceAgent">Cloud Life Sciences Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/lifesciences.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/meshcontrolplane#meshcontrolplane.serviceAgent">Mesh Managed Control Plane Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/meshcontrolplane.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusteringress#multiclusteringress.serviceAgent">Multi Cluster Ingress Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusteringress.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/notebooks#notebooks.serviceAgent">AI Platform Notebooks Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.automationServiceAgent">Security Center Automation Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.automationServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.controlServiceAgent">Security Center Control Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.controlServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.securityHealthAnalyticsServiceAgent">Security Health Analytics Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.securityHealthAnalyticsServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.serviceAgent">Security Center Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/spectrumsas#spectrumsas.serviceAgent">Spectrum SAS Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/spectrumsas.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/workstations#workstations.serviceAgent">Workstations Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/workstations.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="serviceusage.groups.list" class="permission-name add-link" data-text="serviceusage.groups.list" tabindex="-1"><code translate="no" dir="ltr">serviceusage.groups.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.admin">ApiGateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.editor">ApiGateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.viewer">ApiGateway Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/automl#automl.admin">AutoML Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/automl#automl.editor">AutoML Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/automl#automl.viewer">AutoML Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.admin">Recommendations AI Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.editor">Recommendations AI Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.viewer">Recommendations AI Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/capacityplanner#capacityplanner.admin">Capacityplanner Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/capacityplanner.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/capacityplanner#capacityplanner.viewer">Capacity Planner Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/capacityplanner.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.admin">Cloud Scheduler Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.viewer">Cloud Scheduler Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsecurityscanner#cloudsecurityscanner.admin">Web Security Scanner Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecurityscanner.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsecurityscanner#cloudsecurityscanner.editor">Web Security Scanner Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecurityscanner.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsecurityscanner#cloudsecurityscanner.viewer">Web Security Scanner Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecurityscanner.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.admin">Cloud SQL Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.editor">Cloud SQL Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.viewer">Cloud SQL Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercepricemanagement#commercepricemanagement.editor">Commercepricemanagement Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/commercepricemanagement.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercepricemanagement#commercepricemanagement.viewer">Commerce Price Management Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/commercepricemanagement.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.admin">Composer Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.user">Composer User</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.admin">Compute Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.editor">Compute Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.instanceAdmin">Compute Instance Admin (beta)</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.instanceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.instanceAdmin.v1">Compute Instance Admin (v1)</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.instanceAdmin.v1</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.loadBalancerAdmin">Compute Load Balancer Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.loadBalancerAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.networkAdmin">Compute Network Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.networkUser">Compute Network User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.networkUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.networkViewer">Compute Network Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.networkViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.osAdminLogin">Compute OS Admin Login</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.osAdminLogin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.osLogin">Compute OS Login</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.osLogin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.securityAdmin">Compute Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.storageAdmin">Compute Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.storageAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.viewer">Compute Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataprep#dataprep.admin">Dataprep Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.admin">Deployment Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.editor">Deployment Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.viewer">Deployment Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.user">Discovery Engine User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.admin">Managed Kafka Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.viewer">Managed Kafka Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/mapsanalytics#mapsanalytics.viewer">Maps Analytics Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/mapsanalytics.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#monitoring.admin">Monitoring Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/monitoring.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#monitoring.editor">Monitoring Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/monitoring.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.admin">Notebooks Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.editor">Notebooks Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.viewer">Notebooks Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/pubsub#pubsub.admin">Pub/Sub Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/pubsub#pubsub.editor">Pub/Sub Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/pubsub#pubsub.viewer">Pub/Sub Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.admin">Service Management Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageAdmin">Service Usage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageConsumer">Service Usage Consumer</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageConsumer</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageViewer">Service Usage Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.admin">Workload Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/androidmanagement#androidmanagement.user">Android Management User</a> (<code class="role-name" translate="no" dir="ltr">roles/androidmanagement.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/workspacemarketplace#appmetadata.workspaceMarketplaceAppConfigurationAdmin">Workspace Marketplace App Configuration Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/appmetadata.workspaceMarketplaceAppConfigurationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.projectAdmin">Assured OSS Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.projectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.reader">Assured OSS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.adminViewer">Recommendations AI Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.adminViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/capacityplanner#capacityplanner.planner">Capacity Planner</a> (<code class="role-name" translate="no" dir="ltr">roles/capacityplanner.planner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudprofiler#cloudprofiler.user">Cloud Profiler User</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudprofiler.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.jobRunner">Cloud Scheduler Job Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.jobRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.studioUser">Cloud SQL Studio User</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.studioUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercepricemanagement#commercepricemanagement.privateOffersAdmin">Commerce Price Management Private Offers Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/commercepricemanagement.privateOffersAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectAdmin">Environment and Storage Object Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectUser">Environment and Storage Object User</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectViewer">Environment and Storage Object Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.imageUser">Compute Image User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.imageUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.loadBalancerServiceUser">Compute Load Balancer Services User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.loadBalancerServiceUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgFirewallPolicyAdmin">Compute Organization Firewall Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgFirewallPolicyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgFirewallPolicyUser">Compute Organization Firewall Policy User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgFirewallPolicyUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgSecurityPolicyAdmin">Compute Organization Security Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgSecurityPolicyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgSecurityPolicyUser">Compute Organization Security Policy User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgSecurityPolicyUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgSecurityResourceAdmin">Compute Organization Resource Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgSecurityResourceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.packetMirroringAdmin">Compute packet mirroring admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.packetMirroringAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.packetMirroringUser">Compute packet mirroring user</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.packetMirroringUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.entitlementManager">Consumer Procurement Entitlement Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.entitlementManager</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.entitlementViewer">Consumer Procurement Entitlement Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.entitlementViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.procurementAdmin">Consumer Procurement Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.procurementAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.procurementViewer">Consumer Procurement Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.procurementViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataprep#dataprep.projects.user">Dataprep User</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.projects.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.typeEditor">Deployment Manager Type Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.typeEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.typeViewer">Deployment Manager Type Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.typeViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceUser">Gemini Enterprise User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.podcastApiUser">Podcast API User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.podcastApiUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/earthengine#earthengine.appsPublisher">Earth Engine Apps Publisher</a> (<code class="role-name" translate="no" dir="ltr">roles/earthengine.appsPublisher</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.growthAdmin">Firebase Grow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.growthAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.growthViewer">Firebase Grow Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.growthViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.qualityAdmin">Firebase Quality Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.qualityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.qualityViewer">Firebase Quality Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.qualityViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.gatewayAdmin">Connect Gateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.gatewayAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.gatewayEditor">Connect Gateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.gatewayEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.gatewayReader">Connect Gateway Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.gatewayReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.scopeEditorProjectLevel">Fleet Project-level Scope Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.scopeEditorProjectLevel</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.scopeViewerProjectLevel">Fleet Project-level Scope Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.scopeViewerProjectLevel</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.client">Managed Kafka Client</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.client</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.clusterEditor">Managed Kafka Cluster Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.clusterEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.connectorEditor">Managed Kafka Connector Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.connectorEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.consumerGroupEditor">Managed Kafka Consumer Group Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.consumerGroupEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.topicEditor">Managed Kafka Topic Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.topicEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/mapsanalytics#mapsanalytics.mobilitySolutionsOverageViewer">Mobility Solutions Overages Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/mapsanalytics.mobilitySolutionsOverageViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkservices#networkservices.serviceExtensionsAdmin">Service Extensions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networkservices.serviceExtensionsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkservices#networkservices.serviceExtensionsViewer">Service Extensions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/networkservices.serviceExtensionsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.legacyAdmin">Notebooks Legacy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.legacyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.legacyViewer">Notebooks Legacy Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.legacyViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.runner">Notebooks Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.runner</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminEditor">Security Center Admin Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminViewer">Security Center Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.quotaAdmin">Quota Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.quotaAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.quotaViewer">Quota Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.quotaViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#stackdriver.accounts.editor">Stackdriver Accounts Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/stackdriver.accounts.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.deploymentAdmin">Workload Manager Deployment Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.deploymentAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.workloadViewer">Workload Manager Workload Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.workloadViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.onlinePredictionServiceAgent">Vertex AI Online Prediction Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.onlinePredictionServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/anthos#anthos.serviceAgent">Anthos Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/anthos.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/anthosservicemesh#anthosservicemesh.serviceAgent">Anthos Service Mesh Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/anthosservicemesh.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/anthossupport#anthossupport.serviceAgent">Anthos Support Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/anthossupport.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/apigateway#apigateway_management.serviceAgent">Cloud API Gateway Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway_management.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAgent">App Engine Standard Environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengineflex#appengineflex.serviceAgent">App Engine flexible environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengineflex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/assuredworkloads#assuredworkloads.serviceAgent">Assured Workloads Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredworkloads.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.serviceAgent">Audit Manager Auditing Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/batch#batch.serviceAgent">Google Batch Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/batch.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.serviceAgent">Chronicle Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.serviceAgent">Cloud Security Compliance Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/tpu#cloudtpu.serviceAgent">Cloud TPU V2 API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtpu.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.ServiceAgent">Container Analysis Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datalabeling#datalabeling.serviceAgent">Data Labeling Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datalabeling.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dspm#dspm.serviceAgent">DSPM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.clusterServiceAgent">Edge Container Cluster Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.clusterServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.serviceAgent">Edge Container Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.managementServiceAgent">Firebase Service Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.managementServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.sdkProvisioningServiceAgent">Firebase SDK Provisioning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.sdkProvisioningServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasemods#firebasemods.serviceAgent">Firebase Extensions API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasemods.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/fleetengine#fleetengine.serviceAgent">FleetEngine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/fleetengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/lifesciences#genomics.serviceAgent">Genomics Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/genomics.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkehub#gkehub.serviceAgent">GKE Hub Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.sharedVpcServiceAgent">Cluster Director Shared VPC Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.sharedVpcServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/integrations#integrations.serviceAgent">Application Integration Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/krmapihosting#krmapihosting.anthosApiEndpointServiceAgent">KRM API Hosting AnthosApiEndpoint Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/krmapihosting.anthosApiEndpointServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/lifesciences#lifesciences.serviceAgent">Cloud Life Sciences Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/lifesciences.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/meshcontrolplane#meshcontrolplane.serviceAgent">Mesh Managed Control Plane Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/meshcontrolplane.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusteringress#multiclusteringress.serviceAgent">Multi Cluster Ingress Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusteringress.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/notebooks#notebooks.serviceAgent">AI Platform Notebooks Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.automationServiceAgent">Security Center Automation Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.automationServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.controlServiceAgent">Security Center Control Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.controlServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.securityHealthAnalyticsServiceAgent">Security Health Analytics Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.securityHealthAnalyticsServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.serviceAgent">Security Center Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/spectrumsas#spectrumsas.serviceAgent">Spectrum SAS Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/spectrumsas.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/workstations#workstations.serviceAgent">Workstations Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/workstations.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="serviceusage.groups.listExpandedMembers" class="permission-name add-link" data-text="serviceusage.groups.listExpandedMembers" tabindex="-1"><code translate="no" dir="ltr">serviceusage.groups.listExpandedMembers</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.admin">ApiGateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.editor">ApiGateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.viewer">ApiGateway Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/automl#automl.admin">AutoML Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/automl#automl.editor">AutoML Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/automl#automl.viewer">AutoML Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.admin">Recommendations AI Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.editor">Recommendations AI Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.viewer">Recommendations AI Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/capacityplanner#capacityplanner.admin">Capacityplanner Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/capacityplanner.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/capacityplanner#capacityplanner.viewer">Capacity Planner Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/capacityplanner.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.admin">Cloud Scheduler Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.viewer">Cloud Scheduler Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsecurityscanner#cloudsecurityscanner.admin">Web Security Scanner Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecurityscanner.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsecurityscanner#cloudsecurityscanner.editor">Web Security Scanner Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecurityscanner.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsecurityscanner#cloudsecurityscanner.viewer">Web Security Scanner Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecurityscanner.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.admin">Cloud SQL Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.editor">Cloud SQL Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.viewer">Cloud SQL Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercepricemanagement#commercepricemanagement.editor">Commercepricemanagement Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/commercepricemanagement.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercepricemanagement#commercepricemanagement.viewer">Commerce Price Management Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/commercepricemanagement.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.admin">Composer Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.user">Composer User</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.admin">Compute Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.editor">Compute Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.instanceAdmin">Compute Instance Admin (beta)</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.instanceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.instanceAdmin.v1">Compute Instance Admin (v1)</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.instanceAdmin.v1</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.loadBalancerAdmin">Compute Load Balancer Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.loadBalancerAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.networkAdmin">Compute Network Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.networkUser">Compute Network User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.networkUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.networkViewer">Compute Network Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.networkViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.osAdminLogin">Compute OS Admin Login</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.osAdminLogin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.osLogin">Compute OS Login</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.osLogin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.securityAdmin">Compute Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.storageAdmin">Compute Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.storageAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.viewer">Compute Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataprep#dataprep.admin">Dataprep Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.admin">Deployment Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.editor">Deployment Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.viewer">Deployment Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.user">Discovery Engine User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.admin">Managed Kafka Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.viewer">Managed Kafka Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#monitoring.admin">Monitoring Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/monitoring.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#monitoring.editor">Monitoring Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/monitoring.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.admin">Notebooks Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.editor">Notebooks Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.viewer">Notebooks Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/pubsub#pubsub.admin">Pub/Sub Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/pubsub#pubsub.editor">Pub/Sub Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/pubsub#pubsub.viewer">Pub/Sub Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.admin">Service Management Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageAdmin">Service Usage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageConsumer">Service Usage Consumer</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageConsumer</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageViewer">Service Usage Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.admin">Workload Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/androidmanagement#androidmanagement.user">Android Management User</a> (<code class="role-name" translate="no" dir="ltr">roles/androidmanagement.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/workspacemarketplace#appmetadata.workspaceMarketplaceAppConfigurationAdmin">Workspace Marketplace App Configuration Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/appmetadata.workspaceMarketplaceAppConfigurationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.projectAdmin">Assured OSS Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.projectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.reader">Assured OSS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.adminViewer">Recommendations AI Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.adminViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/capacityplanner#capacityplanner.planner">Capacity Planner</a> (<code class="role-name" translate="no" dir="ltr">roles/capacityplanner.planner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudprofiler#cloudprofiler.user">Cloud Profiler User</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudprofiler.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.jobRunner">Cloud Scheduler Job Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.jobRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.studioUser">Cloud SQL Studio User</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.studioUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercepricemanagement#commercepricemanagement.privateOffersAdmin">Commerce Price Management Private Offers Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/commercepricemanagement.privateOffersAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectAdmin">Environment and Storage Object Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectUser">Environment and Storage Object User</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectViewer">Environment and Storage Object Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.imageUser">Compute Image User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.imageUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.loadBalancerServiceUser">Compute Load Balancer Services User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.loadBalancerServiceUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgFirewallPolicyAdmin">Compute Organization Firewall Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgFirewallPolicyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgFirewallPolicyUser">Compute Organization Firewall Policy User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgFirewallPolicyUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgSecurityPolicyAdmin">Compute Organization Security Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgSecurityPolicyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgSecurityPolicyUser">Compute Organization Security Policy User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgSecurityPolicyUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgSecurityResourceAdmin">Compute Organization Resource Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgSecurityResourceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.packetMirroringAdmin">Compute packet mirroring admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.packetMirroringAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.packetMirroringUser">Compute packet mirroring user</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.packetMirroringUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.entitlementManager">Consumer Procurement Entitlement Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.entitlementManager</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.entitlementViewer">Consumer Procurement Entitlement Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.entitlementViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.procurementAdmin">Consumer Procurement Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.procurementAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.procurementViewer">Consumer Procurement Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.procurementViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataprep#dataprep.projects.user">Dataprep User</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.projects.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.typeEditor">Deployment Manager Type Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.typeEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.typeViewer">Deployment Manager Type Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.typeViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceUser">Gemini Enterprise User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.podcastApiUser">Podcast API User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.podcastApiUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/earthengine#earthengine.appsPublisher">Earth Engine Apps Publisher</a> (<code class="role-name" translate="no" dir="ltr">roles/earthengine.appsPublisher</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.growthAdmin">Firebase Grow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.growthAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.growthViewer">Firebase Grow Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.growthViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.qualityAdmin">Firebase Quality Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.qualityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.qualityViewer">Firebase Quality Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.qualityViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.gatewayAdmin">Connect Gateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.gatewayAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.gatewayEditor">Connect Gateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.gatewayEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.gatewayReader">Connect Gateway Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.gatewayReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.scopeEditorProjectLevel">Fleet Project-level Scope Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.scopeEditorProjectLevel</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.scopeViewerProjectLevel">Fleet Project-level Scope Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.scopeViewerProjectLevel</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.client">Managed Kafka Client</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.client</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.clusterEditor">Managed Kafka Cluster Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.clusterEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.connectorEditor">Managed Kafka Connector Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.connectorEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.consumerGroupEditor">Managed Kafka Consumer Group Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.consumerGroupEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.topicEditor">Managed Kafka Topic Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.topicEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkservices#networkservices.serviceExtensionsAdmin">Service Extensions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networkservices.serviceExtensionsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkservices#networkservices.serviceExtensionsViewer">Service Extensions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/networkservices.serviceExtensionsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.legacyAdmin">Notebooks Legacy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.legacyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.legacyViewer">Notebooks Legacy Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.legacyViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.runner">Notebooks Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.runner</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminEditor">Security Center Admin Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminViewer">Security Center Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.quotaAdmin">Quota Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.quotaAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.quotaViewer">Quota Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.quotaViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#stackdriver.accounts.editor">Stackdriver Accounts Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/stackdriver.accounts.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.deploymentAdmin">Workload Manager Deployment Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.deploymentAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.workloadViewer">Workload Manager Workload Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.workloadViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.onlinePredictionServiceAgent">Vertex AI Online Prediction Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.onlinePredictionServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/anthos#anthos.serviceAgent">Anthos Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/anthos.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/anthosservicemesh#anthosservicemesh.serviceAgent">Anthos Service Mesh Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/anthosservicemesh.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/anthossupport#anthossupport.serviceAgent">Anthos Support Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/anthossupport.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/apigateway#apigateway_management.serviceAgent">Cloud API Gateway Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway_management.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAgent">App Engine Standard Environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengineflex#appengineflex.serviceAgent">App Engine flexible environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengineflex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/assuredworkloads#assuredworkloads.serviceAgent">Assured Workloads Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredworkloads.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.serviceAgent">Audit Manager Auditing Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/batch#batch.serviceAgent">Google Batch Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/batch.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.serviceAgent">Chronicle Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.serviceAgent">Cloud Security Compliance Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/tpu#cloudtpu.serviceAgent">Cloud TPU V2 API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtpu.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.ServiceAgent">Container Analysis Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datalabeling#datalabeling.serviceAgent">Data Labeling Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datalabeling.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dspm#dspm.serviceAgent">DSPM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.clusterServiceAgent">Edge Container Cluster Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.clusterServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.serviceAgent">Edge Container Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.managementServiceAgent">Firebase Service Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.managementServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.sdkProvisioningServiceAgent">Firebase SDK Provisioning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.sdkProvisioningServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasemods#firebasemods.serviceAgent">Firebase Extensions API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasemods.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/fleetengine#fleetengine.serviceAgent">FleetEngine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/fleetengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/lifesciences#genomics.serviceAgent">Genomics Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/genomics.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkehub#gkehub.serviceAgent">GKE Hub Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.sharedVpcServiceAgent">Cluster Director Shared VPC Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.sharedVpcServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/integrations#integrations.serviceAgent">Application Integration Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/krmapihosting#krmapihosting.anthosApiEndpointServiceAgent">KRM API Hosting AnthosApiEndpoint Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/krmapihosting.anthosApiEndpointServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/lifesciences#lifesciences.serviceAgent">Cloud Life Sciences Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/lifesciences.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/meshcontrolplane#meshcontrolplane.serviceAgent">Mesh Managed Control Plane Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/meshcontrolplane.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusteringress#multiclusteringress.serviceAgent">Multi Cluster Ingress Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusteringress.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/notebooks#notebooks.serviceAgent">AI Platform Notebooks Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.automationServiceAgent">Security Center Automation Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.automationServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.controlServiceAgent">Security Center Control Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.controlServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.securityHealthAnalyticsServiceAgent">Security Health Analytics Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.securityHealthAnalyticsServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.serviceAgent">Security Center Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/spectrumsas#spectrumsas.serviceAgent">Spectrum SAS Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/spectrumsas.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/workstations#workstations.serviceAgent">Workstations Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/workstations.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="serviceusage.groups.listMembers" class="permission-name add-link" data-text="serviceusage.groups.listMembers" tabindex="-1"><code translate="no" dir="ltr">serviceusage.groups.listMembers</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.admin">ApiGateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.editor">ApiGateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.viewer">ApiGateway Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/automl#automl.admin">AutoML Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/automl#automl.editor">AutoML Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/automl#automl.viewer">AutoML Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.admin">Recommendations AI Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.editor">Recommendations AI Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.viewer">Recommendations AI Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/capacityplanner#capacityplanner.admin">Capacityplanner Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/capacityplanner.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/capacityplanner#capacityplanner.viewer">Capacity Planner Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/capacityplanner.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.admin">Cloud Scheduler Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.viewer">Cloud Scheduler Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsecurityscanner#cloudsecurityscanner.admin">Web Security Scanner Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecurityscanner.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsecurityscanner#cloudsecurityscanner.editor">Web Security Scanner Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecurityscanner.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsecurityscanner#cloudsecurityscanner.viewer">Web Security Scanner Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecurityscanner.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.admin">Cloud SQL Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.editor">Cloud SQL Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.viewer">Cloud SQL Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercepricemanagement#commercepricemanagement.editor">Commercepricemanagement Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/commercepricemanagement.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercepricemanagement#commercepricemanagement.viewer">Commerce Price Management Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/commercepricemanagement.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.admin">Composer Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.user">Composer User</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.admin">Compute Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.editor">Compute Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.instanceAdmin">Compute Instance Admin (beta)</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.instanceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.instanceAdmin.v1">Compute Instance Admin (v1)</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.instanceAdmin.v1</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.loadBalancerAdmin">Compute Load Balancer Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.loadBalancerAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.networkAdmin">Compute Network Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.networkUser">Compute Network User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.networkUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.networkViewer">Compute Network Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.networkViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.osAdminLogin">Compute OS Admin Login</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.osAdminLogin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.osLogin">Compute OS Login</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.osLogin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.securityAdmin">Compute Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.storageAdmin">Compute Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.storageAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.viewer">Compute Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataprep#dataprep.admin">Dataprep Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.admin">Deployment Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.editor">Deployment Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.viewer">Deployment Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.user">Discovery Engine User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.admin">Managed Kafka Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.viewer">Managed Kafka Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/mapsanalytics#mapsanalytics.viewer">Maps Analytics Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/mapsanalytics.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#monitoring.admin">Monitoring Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/monitoring.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#monitoring.editor">Monitoring Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/monitoring.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.admin">Notebooks Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.editor">Notebooks Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.viewer">Notebooks Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/pubsub#pubsub.admin">Pub/Sub Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/pubsub#pubsub.editor">Pub/Sub Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/pubsub#pubsub.viewer">Pub/Sub Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.admin">Service Management Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageAdmin">Service Usage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageConsumer">Service Usage Consumer</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageConsumer</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageViewer">Service Usage Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.admin">Workload Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/androidmanagement#androidmanagement.user">Android Management User</a> (<code class="role-name" translate="no" dir="ltr">roles/androidmanagement.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/workspacemarketplace#appmetadata.workspaceMarketplaceAppConfigurationAdmin">Workspace Marketplace App Configuration Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/appmetadata.workspaceMarketplaceAppConfigurationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.projectAdmin">Assured OSS Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.projectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.reader">Assured OSS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.adminViewer">Recommendations AI Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.adminViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/capacityplanner#capacityplanner.planner">Capacity Planner</a> (<code class="role-name" translate="no" dir="ltr">roles/capacityplanner.planner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudprofiler#cloudprofiler.user">Cloud Profiler User</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudprofiler.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.jobRunner">Cloud Scheduler Job Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.jobRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.studioUser">Cloud SQL Studio User</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.studioUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercepricemanagement#commercepricemanagement.privateOffersAdmin">Commerce Price Management Private Offers Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/commercepricemanagement.privateOffersAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectAdmin">Environment and Storage Object Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectUser">Environment and Storage Object User</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectViewer">Environment and Storage Object Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.imageUser">Compute Image User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.imageUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.loadBalancerServiceUser">Compute Load Balancer Services User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.loadBalancerServiceUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgFirewallPolicyAdmin">Compute Organization Firewall Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgFirewallPolicyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgFirewallPolicyUser">Compute Organization Firewall Policy User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgFirewallPolicyUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgSecurityPolicyAdmin">Compute Organization Security Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgSecurityPolicyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgSecurityPolicyUser">Compute Organization Security Policy User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgSecurityPolicyUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgSecurityResourceAdmin">Compute Organization Resource Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgSecurityResourceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.packetMirroringAdmin">Compute packet mirroring admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.packetMirroringAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.packetMirroringUser">Compute packet mirroring user</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.packetMirroringUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.entitlementManager">Consumer Procurement Entitlement Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.entitlementManager</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.entitlementViewer">Consumer Procurement Entitlement Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.entitlementViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.procurementAdmin">Consumer Procurement Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.procurementAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.procurementViewer">Consumer Procurement Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.procurementViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataprep#dataprep.projects.user">Dataprep User</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.projects.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.typeEditor">Deployment Manager Type Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.typeEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.typeViewer">Deployment Manager Type Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.typeViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceUser">Gemini Enterprise User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.podcastApiUser">Podcast API User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.podcastApiUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/earthengine#earthengine.appsPublisher">Earth Engine Apps Publisher</a> (<code class="role-name" translate="no" dir="ltr">roles/earthengine.appsPublisher</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.growthAdmin">Firebase Grow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.growthAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.growthViewer">Firebase Grow Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.growthViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.qualityAdmin">Firebase Quality Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.qualityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.qualityViewer">Firebase Quality Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.qualityViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.gatewayAdmin">Connect Gateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.gatewayAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.gatewayEditor">Connect Gateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.gatewayEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.gatewayReader">Connect Gateway Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.gatewayReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.scopeEditorProjectLevel">Fleet Project-level Scope Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.scopeEditorProjectLevel</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.scopeViewerProjectLevel">Fleet Project-level Scope Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.scopeViewerProjectLevel</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.client">Managed Kafka Client</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.client</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.clusterEditor">Managed Kafka Cluster Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.clusterEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.connectorEditor">Managed Kafka Connector Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.connectorEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.consumerGroupEditor">Managed Kafka Consumer Group Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.consumerGroupEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.topicEditor">Managed Kafka Topic Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.topicEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/mapsanalytics#mapsanalytics.mobilitySolutionsOverageViewer">Mobility Solutions Overages Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/mapsanalytics.mobilitySolutionsOverageViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkservices#networkservices.serviceExtensionsAdmin">Service Extensions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networkservices.serviceExtensionsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkservices#networkservices.serviceExtensionsViewer">Service Extensions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/networkservices.serviceExtensionsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.legacyAdmin">Notebooks Legacy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.legacyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.legacyViewer">Notebooks Legacy Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.legacyViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.runner">Notebooks Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.runner</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminEditor">Security Center Admin Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminViewer">Security Center Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.quotaAdmin">Quota Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.quotaAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.quotaViewer">Quota Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.quotaViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#stackdriver.accounts.editor">Stackdriver Accounts Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/stackdriver.accounts.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.deploymentAdmin">Workload Manager Deployment Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.deploymentAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.workloadViewer">Workload Manager Workload Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.workloadViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.onlinePredictionServiceAgent">Vertex AI Online Prediction Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.onlinePredictionServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/anthos#anthos.serviceAgent">Anthos Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/anthos.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/anthosservicemesh#anthosservicemesh.serviceAgent">Anthos Service Mesh Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/anthosservicemesh.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/anthossupport#anthossupport.serviceAgent">Anthos Support Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/anthossupport.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/apigateway#apigateway_management.serviceAgent">Cloud API Gateway Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway_management.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAgent">App Engine Standard Environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengineflex#appengineflex.serviceAgent">App Engine flexible environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengineflex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/assuredworkloads#assuredworkloads.serviceAgent">Assured Workloads Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredworkloads.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.serviceAgent">Audit Manager Auditing Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/batch#batch.serviceAgent">Google Batch Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/batch.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.serviceAgent">Chronicle Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.serviceAgent">Cloud Security Compliance Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/tpu#cloudtpu.serviceAgent">Cloud TPU V2 API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtpu.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.ServiceAgent">Container Analysis Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datalabeling#datalabeling.serviceAgent">Data Labeling Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datalabeling.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dspm#dspm.serviceAgent">DSPM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.clusterServiceAgent">Edge Container Cluster Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.clusterServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.serviceAgent">Edge Container Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.managementServiceAgent">Firebase Service Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.managementServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.sdkProvisioningServiceAgent">Firebase SDK Provisioning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.sdkProvisioningServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasemods#firebasemods.serviceAgent">Firebase Extensions API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasemods.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/fleetengine#fleetengine.serviceAgent">FleetEngine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/fleetengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/lifesciences#genomics.serviceAgent">Genomics Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/genomics.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkehub#gkehub.serviceAgent">GKE Hub Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.sharedVpcServiceAgent">Cluster Director Shared VPC Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.sharedVpcServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/integrations#integrations.serviceAgent">Application Integration Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/krmapihosting#krmapihosting.anthosApiEndpointServiceAgent">KRM API Hosting AnthosApiEndpoint Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/krmapihosting.anthosApiEndpointServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/lifesciences#lifesciences.serviceAgent">Cloud Life Sciences Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/lifesciences.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/meshcontrolplane#meshcontrolplane.serviceAgent">Mesh Managed Control Plane Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/meshcontrolplane.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusteringress#multiclusteringress.serviceAgent">Multi Cluster Ingress Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusteringress.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/notebooks#notebooks.serviceAgent">AI Platform Notebooks Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.automationServiceAgent">Security Center Automation Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.automationServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.controlServiceAgent">Security Center Control Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.controlServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.securityHealthAnalyticsServiceAgent">Security Health Analytics Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.securityHealthAnalyticsServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.serviceAgent">Security Center Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/spectrumsas#spectrumsas.serviceAgent">Spectrum SAS Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/spectrumsas.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/workstations#workstations.serviceAgent">Workstations Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/workstations.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="serviceusage.mcppolicy.get" class="permission-name add-link" data-text="serviceusage.mcppolicy.get" tabindex="-1"><code translate="no" dir="ltr">serviceusage.mcppolicy.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.user">Discovery Engine User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageAdmin">Service Usage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageConsumer">Service Usage Consumer</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageConsumer</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageViewer">Service Usage Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceUser">Gemini Enterprise User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.podcastApiUser">Podcast API User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.podcastApiUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.growthAdmin">Firebase Grow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.growthAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.growthViewer">Firebase Grow Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.growthViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.qualityAdmin">Firebase Quality Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.qualityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.qualityViewer">Firebase Quality Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.qualityViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.serviceAgent">Audit Manager Auditing Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.serviceAgent">Cloud Security Compliance Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.clusterServiceAgent">Edge Container Cluster Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.clusterServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="serviceusage.mcppolicy.update" class="permission-name add-link" data-text="serviceusage.mcppolicy.update" tabindex="-1"><code translate="no" dir="ltr">serviceusage.mcppolicy.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageAdmin">Service Usage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="serviceusage.operations.get" class="permission-name add-link" data-text="serviceusage.operations.get" tabindex="-1"><code translate="no" dir="ltr">serviceusage.operations.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercebusinessenablement#commercebusinessenablement.admin">Commerce Business Enablement Configuration Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/commercebusinessenablement.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.user">Discovery Engine User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.apiKeysAdmin">API Keys Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.apiKeysAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageAdmin">Service Usage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageConsumer">Service Usage Consumer</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageConsumer</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageViewer">Service Usage Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.entitlementManager">Consumer Procurement Entitlement Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.entitlementManager</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.procurementAdmin">Consumer Procurement Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.procurementAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceUser">Gemini Enterprise User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.podcastApiUser">Podcast API User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.podcastApiUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.growthAdmin">Firebase Grow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.growthAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.growthViewer">Firebase Grow Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.growthViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.qualityAdmin">Firebase Quality Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.qualityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.qualityViewer">Firebase Quality Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.qualityViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.serviceAgent">Audit Manager Auditing Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.serviceAgent">Chronicle Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.serviceAgent">Cloud Security Compliance Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/databaseinsights#databaseinsights.serviceAgent">Database Insights Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/databaseinsights.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.clusterServiceAgent">Edge Container Cluster Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.clusterServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.controlServiceAgent">Security Center Control Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.controlServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.serviceAgent">Security Center Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="serviceusage.quotas.get" class="permission-name add-link" data-text="serviceusage.quotas.get" tabindex="-1"><code translate="no" dir="ltr">serviceusage.quotas.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/capacityplanner#capacityplanner.admin">Capacityplanner Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/capacityplanner.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/capacityplanner#capacityplanner.viewer">Capacity Planner Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/capacityplanner.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsecurityscanner#cloudsecurityscanner.admin">Web Security Scanner Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecurityscanner.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsecurityscanner#cloudsecurityscanner.editor">Web Security Scanner Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecurityscanner.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsecurityscanner#cloudsecurityscanner.viewer">Web Security Scanner Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecurityscanner.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.admin">Cloud SQL Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.editor">Cloud SQL Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.viewer">Cloud SQL Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.admin">Composer Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.user">Composer User</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.admin">Compute Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.editor">Compute Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.instanceAdmin">Compute Instance Admin (beta)</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.instanceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.instanceAdmin.v1">Compute Instance Admin (v1)</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.instanceAdmin.v1</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.loadBalancerAdmin">Compute Load Balancer Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.loadBalancerAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.networkAdmin">Compute Network Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.networkUser">Compute Network User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.networkUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.networkViewer">Compute Network Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.networkViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.osAdminLogin">Compute OS Admin Login</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.osAdminLogin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.osLogin">Compute OS Login</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.osLogin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.securityAdmin">Compute Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.storageAdmin">Compute Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.storageAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.viewer">Compute Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataprep#dataprep.admin">Dataprep Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.admin">Deployment Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.editor">Deployment Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.viewer">Deployment Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.user">Discovery Engine User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/looker#looker.admin">Looker Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/looker.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.admin">Managed Kafka Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.viewer">Managed Kafka Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/migrationcenter#migrationcenter.admin">Migration Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/migrationcenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/migrationcenter#migrationcenter.viewer">Migration Center Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/migrationcenter.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.admin">Notebooks Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.editor">Notebooks Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.viewer">Notebooks Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/pubsub#pubsub.admin">Pub/Sub Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/pubsub#pubsub.editor">Pub/Sub Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/pubsub#pubsub.viewer">Pub/Sub Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.admin">Service Management Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageAdmin">Service Usage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageConsumer">Service Usage Consumer</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageConsumer</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageViewer">Service Usage Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.admin">Workload Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/androidmanagement#androidmanagement.user">Android Management User</a> (<code class="role-name" translate="no" dir="ltr">roles/androidmanagement.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.projectAdmin">Assured OSS Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.projectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.reader">Assured OSS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/capacityplanner#capacityplanner.planner">Capacity Planner</a> (<code class="role-name" translate="no" dir="ltr">roles/capacityplanner.planner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudprofiler#cloudprofiler.user">Cloud Profiler User</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudprofiler.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectAdmin">Environment and Storage Object Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectUser">Environment and Storage Object User</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectViewer">Environment and Storage Object Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.imageUser">Compute Image User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.imageUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.loadBalancerServiceUser">Compute Load Balancer Services User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.loadBalancerServiceUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgFirewallPolicyAdmin">Compute Organization Firewall Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgFirewallPolicyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgFirewallPolicyUser">Compute Organization Firewall Policy User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgFirewallPolicyUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgSecurityPolicyAdmin">Compute Organization Security Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgSecurityPolicyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgSecurityPolicyUser">Compute Organization Security Policy User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgSecurityPolicyUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgSecurityResourceAdmin">Compute Organization Resource Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgSecurityResourceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.packetMirroringAdmin">Compute packet mirroring admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.packetMirroringAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.packetMirroringUser">Compute packet mirroring user</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.packetMirroringUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataprep#dataprep.projects.user">Dataprep User</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.projects.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.typeEditor">Deployment Manager Type Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.typeEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.typeViewer">Deployment Manager Type Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.typeViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceUser">Gemini Enterprise User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.podcastApiUser">Podcast API User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.podcastApiUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.growthAdmin">Firebase Grow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.growthAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.growthViewer">Firebase Grow Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.growthViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.qualityAdmin">Firebase Quality Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.qualityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.qualityViewer">Firebase Quality Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.qualityViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.client">Managed Kafka Client</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.client</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.clusterEditor">Managed Kafka Cluster Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.clusterEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.connectorEditor">Managed Kafka Connector Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.connectorEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.consumerGroupEditor">Managed Kafka Consumer Group Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.consumerGroupEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.topicEditor">Managed Kafka Topic Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.topicEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkservices#networkservices.serviceExtensionsAdmin">Service Extensions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networkservices.serviceExtensionsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkservices#networkservices.serviceExtensionsViewer">Service Extensions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/networkservices.serviceExtensionsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.legacyAdmin">Notebooks Legacy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.legacyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.legacyViewer">Notebooks Legacy Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.legacyViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.runner">Notebooks Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.runner</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminEditor">Security Center Admin Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminViewer">Security Center Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.quotaAdmin">Quota Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.quotaAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.quotaViewer">Quota Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.quotaViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.deploymentAdmin">Workload Manager Deployment Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.deploymentAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.serviceAgent">Audit Manager Auditing Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/batch#batch.serviceAgent">Google Batch Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/batch.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.serviceAgent">Chronicle Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.serviceAgent">Cloud Security Compliance Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/tpu#cloudtpu.serviceAgent">Cloud TPU V2 API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtpu.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.ServiceAgent">Container Analysis Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.clusterServiceAgent">Edge Container Cluster Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.clusterServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasemods#firebasemods.serviceAgent">Firebase Extensions API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasemods.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/lifesciences#genomics.serviceAgent">Genomics Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/genomics.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.sharedVpcServiceAgent">Cluster Director Shared VPC Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.sharedVpcServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/integrations#integrations.serviceAgent">Application Integration Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/lifesciences#lifesciences.serviceAgent">Cloud Life Sciences Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/lifesciences.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/notebooks#notebooks.serviceAgent">AI Platform Notebooks Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.controlServiceAgent">Security Center Control Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.controlServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.securityHealthAnalyticsServiceAgent">Security Health Analytics Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.securityHealthAnalyticsServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.serviceAgent">Security Center Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/spectrumsas#spectrumsas.serviceAgent">Spectrum SAS Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/spectrumsas.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="serviceusage.quotas.update" class="permission-name add-link" data-text="serviceusage.quotas.update" tabindex="-1"><code translate="no" dir="ltr">serviceusage.quotas.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageAdmin">Service Usage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.quotaAdmin">Quota Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.quotaAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="serviceusage.services.disable" class="permission-name add-link" data-text="serviceusage.services.disable" tabindex="-1"><code translate="no" dir="ltr">serviceusage.services.disable</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageAdmin">Service Usage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.entitlementManager">Consumer Procurement Entitlement Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.entitlementManager</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.procurementAdmin">Consumer Procurement Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.procurementAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.quotaAdmin">Quota Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.quotaAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.controlServiceAgent">Security Center Control Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.controlServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.serviceAgent">Security Center Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="serviceusage.services.enable" class="permission-name add-link" data-text="serviceusage.services.enable" tabindex="-1"><code translate="no" dir="ltr">serviceusage.services.enable</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercebusinessenablement#commercebusinessenablement.admin">Commerce Business Enablement Configuration Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/commercebusinessenablement.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#monitoring.admin">Monitoring Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/monitoring.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#monitoring.editor">Monitoring Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/monitoring.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageAdmin">Service Usage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.projectAdmin">Assured OSS Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.projectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.entitlementManager">Consumer Procurement Entitlement Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.entitlementManager</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.procurementAdmin">Consumer Procurement Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.procurementAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.quotaAdmin">Quota Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.quotaAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#stackdriver.accounts.editor">Stackdriver Accounts Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/stackdriver.accounts.editor</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAgent">App Engine Standard Environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengineflex#appengineflex.serviceAgent">App Engine flexible environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengineflex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/assuredworkloads#assuredworkloads.serviceAgent">Assured Workloads Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredworkloads.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.serviceAgent">Chronicle Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.serviceAgent">Cloud Security Compliance Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dspm#dspm.serviceAgent">DSPM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.clusterServiceAgent">Edge Container Cluster Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.clusterServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.managementServiceAgent">Firebase Service Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.managementServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.sdkProvisioningServiceAgent">Firebase SDK Provisioning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.sdkProvisioningServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasemods#firebasemods.serviceAgent">Firebase Extensions API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasemods.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/fleetengine#fleetengine.serviceAgent">FleetEngine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/fleetengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/krmapihosting#krmapihosting.anthosApiEndpointServiceAgent">KRM API Hosting AnthosApiEndpoint Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/krmapihosting.anthosApiEndpointServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.automationServiceAgent">Security Center Automation Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.automationServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.controlServiceAgent">Security Center Control Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.controlServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.serviceAgent">Security Center Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="serviceusage.services.get" class="permission-name add-link" data-text="serviceusage.services.get" tabindex="-1"><code translate="no" dir="ltr">serviceusage.services.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.admin">ApiGateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.editor">ApiGateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.viewer">ApiGateway Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/automl#automl.admin">AutoML Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/automl#automl.editor">AutoML Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/automl#automl.viewer">AutoML Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.admin">Recommendations AI Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.editor">Recommendations AI Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.viewer">Recommendations AI Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioUser">BigQuery Studio User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/capacityplanner#capacityplanner.admin">Capacityplanner Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/capacityplanner.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/capacityplanner#capacityplanner.viewer">Capacity Planner Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/capacityplanner.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.admin">Cloud Scheduler Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.viewer">Cloud Scheduler Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsecurityscanner#cloudsecurityscanner.admin">Web Security Scanner Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecurityscanner.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsecurityscanner#cloudsecurityscanner.editor">Web Security Scanner Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecurityscanner.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsecurityscanner#cloudsecurityscanner.viewer">Web Security Scanner Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecurityscanner.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.admin">Cloud SQL Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.editor">Cloud SQL Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.viewer">Cloud SQL Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercebusinessenablement#commercebusinessenablement.admin">Commerce Business Enablement Configuration Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/commercebusinessenablement.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercepricemanagement#commercepricemanagement.editor">Commercepricemanagement Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/commercepricemanagement.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercepricemanagement#commercepricemanagement.viewer">Commerce Price Management Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/commercepricemanagement.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.admin">Composer Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.user">Composer User</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.admin">Compute Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.editor">Compute Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.instanceAdmin">Compute Instance Admin (beta)</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.instanceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.instanceAdmin.v1">Compute Instance Admin (v1)</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.instanceAdmin.v1</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.loadBalancerAdmin">Compute Load Balancer Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.loadBalancerAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.networkAdmin">Compute Network Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.networkUser">Compute Network User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.networkUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.networkViewer">Compute Network Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.networkViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.osAdminLogin">Compute OS Admin Login</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.osAdminLogin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.osLogin">Compute OS Login</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.osLogin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.securityAdmin">Compute Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.storageAdmin">Compute Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.storageAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.viewer">Compute Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataprep#dataprep.admin">Dataprep Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.admin">Deployment Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.editor">Deployment Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.viewer">Deployment Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.user">Discovery Engine User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.admin">Managed Kafka Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.viewer">Managed Kafka Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#monitoring.admin">Monitoring Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/monitoring.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#monitoring.editor">Monitoring Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/monitoring.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.admin">Notebooks Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.editor">Notebooks Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.viewer">Notebooks Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/pubsub#pubsub.admin">Pub/Sub Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/pubsub#pubsub.editor">Pub/Sub Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/pubsub#pubsub.viewer">Pub/Sub Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.admin">Service Management Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageAdmin">Service Usage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageConsumer">Service Usage Consumer</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageConsumer</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageViewer">Service Usage Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.admin">Workload Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/androidmanagement#androidmanagement.user">Android Management User</a> (<code class="role-name" translate="no" dir="ltr">roles/androidmanagement.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/workspacemarketplace#appmetadata.workspaceMarketplaceAppConfigurationAdmin">Workspace Marketplace App Configuration Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/appmetadata.workspaceMarketplaceAppConfigurationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.projectAdmin">Assured OSS Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.projectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.reader">Assured OSS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.adminViewer">Recommendations AI Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.adminViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/capacityplanner#capacityplanner.planner">Capacity Planner</a> (<code class="role-name" translate="no" dir="ltr">roles/capacityplanner.planner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudprofiler#cloudprofiler.user">Cloud Profiler User</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudprofiler.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.jobRunner">Cloud Scheduler Job Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.jobRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.studioUser">Cloud SQL Studio User</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.studioUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercepricemanagement#commercepricemanagement.privateOffersAdmin">Commerce Price Management Private Offers Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/commercepricemanagement.privateOffersAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectAdmin">Environment and Storage Object Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectUser">Environment and Storage Object User</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectViewer">Environment and Storage Object Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.imageUser">Compute Image User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.imageUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.loadBalancerServiceUser">Compute Load Balancer Services User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.loadBalancerServiceUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgFirewallPolicyAdmin">Compute Organization Firewall Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgFirewallPolicyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgFirewallPolicyUser">Compute Organization Firewall Policy User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgFirewallPolicyUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgSecurityPolicyAdmin">Compute Organization Security Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgSecurityPolicyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgSecurityPolicyUser">Compute Organization Security Policy User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgSecurityPolicyUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgSecurityResourceAdmin">Compute Organization Resource Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgSecurityResourceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.packetMirroringAdmin">Compute packet mirroring admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.packetMirroringAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.packetMirroringUser">Compute packet mirroring user</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.packetMirroringUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.entitlementManager">Consumer Procurement Entitlement Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.entitlementManager</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.entitlementViewer">Consumer Procurement Entitlement Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.entitlementViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.procurementAdmin">Consumer Procurement Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.procurementAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.procurementViewer">Consumer Procurement Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.procurementViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataprep#dataprep.projects.user">Dataprep User</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.projects.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.typeEditor">Deployment Manager Type Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.typeEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.typeViewer">Deployment Manager Type Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.typeViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceUser">Gemini Enterprise User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.podcastApiUser">Podcast API User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.podcastApiUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/earthengine#earthengine.appsPublisher">Earth Engine Apps Publisher</a> (<code class="role-name" translate="no" dir="ltr">roles/earthengine.appsPublisher</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.growthAdmin">Firebase Grow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.growthAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.growthViewer">Firebase Grow Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.growthViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.qualityAdmin">Firebase Quality Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.qualityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.qualityViewer">Firebase Quality Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.qualityViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.gatewayAdmin">Connect Gateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.gatewayAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.gatewayEditor">Connect Gateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.gatewayEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.gatewayReader">Connect Gateway Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.gatewayReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.scopeEditorProjectLevel">Fleet Project-level Scope Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.scopeEditorProjectLevel</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.scopeViewerProjectLevel">Fleet Project-level Scope Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.scopeViewerProjectLevel</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.client">Managed Kafka Client</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.client</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.clusterEditor">Managed Kafka Cluster Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.clusterEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.connectorEditor">Managed Kafka Connector Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.connectorEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.consumerGroupEditor">Managed Kafka Consumer Group Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.consumerGroupEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.topicEditor">Managed Kafka Topic Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.topicEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkservices#networkservices.serviceExtensionsAdmin">Service Extensions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networkservices.serviceExtensionsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkservices#networkservices.serviceExtensionsViewer">Service Extensions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/networkservices.serviceExtensionsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.legacyAdmin">Notebooks Legacy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.legacyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.legacyViewer">Notebooks Legacy Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.legacyViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.runner">Notebooks Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.runner</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminEditor">Security Center Admin Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminViewer">Security Center Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.quotaAdmin">Quota Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.quotaAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.quotaViewer">Quota Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.quotaViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#stackdriver.accounts.editor">Stackdriver Accounts Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/stackdriver.accounts.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.deploymentAdmin">Workload Manager Deployment Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.deploymentAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.workloadViewer">Workload Manager Workload Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.workloadViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.onlinePredictionServiceAgent">Vertex AI Online Prediction Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.onlinePredictionServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/anthos#anthos.serviceAgent">Anthos Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/anthos.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/anthosservicemesh#anthosservicemesh.serviceAgent">Anthos Service Mesh Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/anthosservicemesh.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/anthossupport#anthossupport.serviceAgent">Anthos Support Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/anthossupport.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/apigateway#apigateway_management.serviceAgent">Cloud API Gateway Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway_management.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAgent">App Engine Standard Environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/assuredworkloads#assuredworkloads.serviceAgent">Assured Workloads Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredworkloads.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.serviceAgent">Audit Manager Auditing Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/batch#batch.serviceAgent">Google Batch Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/batch.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.serviceAgent">Chronicle Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.serviceAgent">Cloud Security Compliance Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/tpu#cloudtpu.serviceAgent">Cloud TPU V2 API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtpu.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.ServiceAgent">Container Analysis Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/databaseinsights#databaseinsights.serviceAgent">Database Insights Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/databaseinsights.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datalabeling#datalabeling.serviceAgent">Data Labeling Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datalabeling.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dspm#dspm.serviceAgent">DSPM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.clusterServiceAgent">Edge Container Cluster Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.clusterServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.serviceAgent">Edge Container Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.managementServiceAgent">Firebase Service Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.managementServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.sdkProvisioningServiceAgent">Firebase SDK Provisioning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.sdkProvisioningServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasemods#firebasemods.serviceAgent">Firebase Extensions API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasemods.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/lifesciences#genomics.serviceAgent">Genomics Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/genomics.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkehub#gkehub.serviceAgent">GKE Hub Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.sharedVpcServiceAgent">Cluster Director Shared VPC Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.sharedVpcServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/integrations#integrations.serviceAgent">Application Integration Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/krmapihosting#krmapihosting.anthosApiEndpointServiceAgent">KRM API Hosting AnthosApiEndpoint Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/krmapihosting.anthosApiEndpointServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/lifesciences#lifesciences.serviceAgent">Cloud Life Sciences Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/lifesciences.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/meshcontrolplane#meshcontrolplane.serviceAgent">Mesh Managed Control Plane Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/meshcontrolplane.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusteringress#multiclusteringress.serviceAgent">Multi Cluster Ingress Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusteringress.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/notebooks#notebooks.serviceAgent">AI Platform Notebooks Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.automationServiceAgent">Security Center Automation Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.automationServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.controlServiceAgent">Security Center Control Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.controlServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.securityHealthAnalyticsServiceAgent">Security Health Analytics Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.securityHealthAnalyticsServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.serviceAgent">Security Center Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/spectrumsas#spectrumsas.serviceAgent">Spectrum SAS Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/spectrumsas.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/workstations#workstations.serviceAgent">Workstations Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/workstations.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="serviceusage.services.list" class="permission-name add-link" data-text="serviceusage.services.list" tabindex="-1"><code translate="no" dir="ltr">serviceusage.services.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.admin">ApiGateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.editor">ApiGateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.viewer">ApiGateway Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/automl#automl.admin">AutoML Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/automl#automl.editor">AutoML Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/automl#automl.viewer">AutoML Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.admin">Recommendations AI Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.editor">Recommendations AI Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.viewer">Recommendations AI Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.admin">Cloud Scheduler Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.viewer">Cloud Scheduler Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsecurityscanner#cloudsecurityscanner.admin">Web Security Scanner Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecurityscanner.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsecurityscanner#cloudsecurityscanner.editor">Web Security Scanner Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecurityscanner.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsecurityscanner#cloudsecurityscanner.viewer">Web Security Scanner Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecurityscanner.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.admin">Cloud SQL Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.editor">Cloud SQL Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.viewer">Cloud SQL Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercepricemanagement#commercepricemanagement.editor">Commercepricemanagement Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/commercepricemanagement.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercepricemanagement#commercepricemanagement.viewer">Commerce Price Management Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/commercepricemanagement.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.admin">Composer Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.user">Composer User</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.admin">Compute Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.editor">Compute Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.instanceAdmin">Compute Instance Admin (beta)</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.instanceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.instanceAdmin.v1">Compute Instance Admin (v1)</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.instanceAdmin.v1</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.loadBalancerAdmin">Compute Load Balancer Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.loadBalancerAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.networkAdmin">Compute Network Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.networkUser">Compute Network User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.networkUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.networkViewer">Compute Network Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.networkViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.osAdminLogin">Compute OS Admin Login</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.osAdminLogin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.osLogin">Compute OS Login</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.osLogin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.securityAdmin">Compute Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.storageAdmin">Compute Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.storageAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.viewer">Compute Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataprep#dataprep.admin">Dataprep Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.admin">Deployment Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.editor">Deployment Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.viewer">Deployment Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.user">Discovery Engine User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.admin">Managed Kafka Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.viewer">Managed Kafka Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/mapsanalytics#mapsanalytics.viewer">Maps Analytics Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/mapsanalytics.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.admin">Notebooks Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.editor">Notebooks Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.viewer">Notebooks Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/pubsub#pubsub.admin">Pub/Sub Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/pubsub#pubsub.editor">Pub/Sub Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/pubsub#pubsub.viewer">Pub/Sub Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/retail#retail.admin">Retail Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/retail.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/retail#retail.editor">Retail Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/retail.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/retail#retail.viewer">Retail Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/retail.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageAdmin">Service Usage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageConsumer">Service Usage Consumer</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageConsumer</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageViewer">Service Usage Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/androidmanagement#androidmanagement.user">Android Management User</a> (<code class="role-name" translate="no" dir="ltr">roles/androidmanagement.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.projectAdmin">Assured OSS Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.projectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.reader">Assured OSS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.adminViewer">Recommendations AI Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.adminViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudprofiler#cloudprofiler.user">Cloud Profiler User</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudprofiler.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.jobRunner">Cloud Scheduler Job Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.jobRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.studioUser">Cloud SQL Studio User</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.studioUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercepricemanagement#commercepricemanagement.privateOffersAdmin">Commerce Price Management Private Offers Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/commercepricemanagement.privateOffersAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectAdmin">Environment and Storage Object Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectUser">Environment and Storage Object User</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectViewer">Environment and Storage Object Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.imageUser">Compute Image User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.imageUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.loadBalancerServiceUser">Compute Load Balancer Services User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.loadBalancerServiceUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgFirewallPolicyAdmin">Compute Organization Firewall Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgFirewallPolicyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgFirewallPolicyUser">Compute Organization Firewall Policy User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgFirewallPolicyUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgSecurityPolicyAdmin">Compute Organization Security Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgSecurityPolicyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgSecurityPolicyUser">Compute Organization Security Policy User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgSecurityPolicyUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgSecurityResourceAdmin">Compute Organization Resource Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgSecurityResourceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.packetMirroringAdmin">Compute packet mirroring admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.packetMirroringAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.packetMirroringUser">Compute packet mirroring user</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.packetMirroringUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.entitlementManager">Consumer Procurement Entitlement Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.entitlementManager</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.entitlementViewer">Consumer Procurement Entitlement Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.entitlementViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.procurementAdmin">Consumer Procurement Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.procurementAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.procurementViewer">Consumer Procurement Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.procurementViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataprep#dataprep.projects.user">Dataprep User</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.projects.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceUser">Gemini Enterprise User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.podcastApiUser">Podcast API User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.podcastApiUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.growthAdmin">Firebase Grow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.growthAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.growthViewer">Firebase Grow Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.growthViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.qualityAdmin">Firebase Quality Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.qualityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.qualityViewer">Firebase Quality Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.qualityViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.client">Managed Kafka Client</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.client</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.clusterEditor">Managed Kafka Cluster Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.clusterEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.connectorEditor">Managed Kafka Connector Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.connectorEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.consumerGroupEditor">Managed Kafka Consumer Group Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.consumerGroupEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.topicEditor">Managed Kafka Topic Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.topicEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/mapsanalytics#mapsanalytics.mobilitySolutionsOverageViewer">Mobility Solutions Overages Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/mapsanalytics.mobilitySolutionsOverageViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.legacyAdmin">Notebooks Legacy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.legacyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.legacyViewer">Notebooks Legacy Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.legacyViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.runner">Notebooks Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.runner</code>)</p>
<p><a href="/iam/docs/roles-permissions/retail#retail.merchantApprover">Retail Merchant Approver</a> (<code class="role-name" translate="no" dir="ltr">roles/retail.merchantApprover</code>)</p>
<p><a href="/iam/docs/roles-permissions/retail#retail.merchantCreator">Retail Merchant Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/retail.merchantCreator</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminEditor">Security Center Admin Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminViewer">Security Center Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.quotaAdmin">Quota Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.quotaAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.quotaViewer">Quota Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.quotaViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.workloadViewer">Workload Manager Workload Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.workloadViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/anthos#anthos.serviceAgent">Anthos Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/anthos.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.serviceAgent">Audit Manager Auditing Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/batch#batch.serviceAgent">Google Batch Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/batch.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.serviceAgent">Chronicle Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.serviceAgent">Cloud Security Compliance Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/tpu#cloudtpu.serviceAgent">Cloud TPU V2 API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtpu.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.ServiceAgent">Container Analysis Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/databaseinsights#databaseinsights.serviceAgent">Database Insights Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/databaseinsights.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datalabeling#datalabeling.serviceAgent">Data Labeling Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datalabeling.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dspm#dspm.serviceAgent">DSPM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.clusterServiceAgent">Edge Container Cluster Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.clusterServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.serviceAgent">Edge Container Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.managementServiceAgent">Firebase Service Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.managementServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasemods#firebasemods.serviceAgent">Firebase Extensions API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasemods.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/lifesciences#genomics.serviceAgent">Genomics Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/genomics.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkehub#gkehub.serviceAgent">GKE Hub Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.sharedVpcServiceAgent">Cluster Director Shared VPC Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.sharedVpcServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/integrations#integrations.serviceAgent">Application Integration Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/krmapihosting#krmapihosting.anthosApiEndpointServiceAgent">KRM API Hosting AnthosApiEndpoint Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/krmapihosting.anthosApiEndpointServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/lifesciences#lifesciences.serviceAgent">Cloud Life Sciences Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/lifesciences.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusteringress#multiclusteringress.serviceAgent">Multi Cluster Ingress Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusteringress.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/notebooks#notebooks.serviceAgent">AI Platform Notebooks Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.controlServiceAgent">Security Center Control Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.controlServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.securityHealthAnalyticsServiceAgent">Security Health Analytics Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.securityHealthAnalyticsServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.serviceAgent">Security Center Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/spectrumsas#spectrumsas.serviceAgent">Spectrum SAS Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/spectrumsas.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="serviceusage.services.listApis" class="permission-name add-link" data-text="serviceusage.services.listApis" tabindex="-1"><code translate="no" dir="ltr">serviceusage.services.listApis</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.admin">ApiGateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.editor">ApiGateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.viewer">ApiGateway Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/automl#automl.admin">AutoML Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/automl#automl.editor">AutoML Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/automl#automl.viewer">AutoML Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.admin">Recommendations AI Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.editor">Recommendations AI Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.viewer">Recommendations AI Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/capacityplanner#capacityplanner.admin">Capacityplanner Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/capacityplanner.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/capacityplanner#capacityplanner.viewer">Capacity Planner Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/capacityplanner.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.admin">Cloud Scheduler Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.viewer">Cloud Scheduler Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsecurityscanner#cloudsecurityscanner.admin">Web Security Scanner Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecurityscanner.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsecurityscanner#cloudsecurityscanner.editor">Web Security Scanner Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecurityscanner.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsecurityscanner#cloudsecurityscanner.viewer">Web Security Scanner Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecurityscanner.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.admin">Cloud SQL Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.editor">Cloud SQL Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.viewer">Cloud SQL Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercepricemanagement#commercepricemanagement.editor">Commercepricemanagement Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/commercepricemanagement.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercepricemanagement#commercepricemanagement.viewer">Commerce Price Management Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/commercepricemanagement.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.admin">Composer Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.user">Composer User</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.admin">Compute Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.editor">Compute Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.instanceAdmin">Compute Instance Admin (beta)</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.instanceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.instanceAdmin.v1">Compute Instance Admin (v1)</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.instanceAdmin.v1</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.loadBalancerAdmin">Compute Load Balancer Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.loadBalancerAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.networkAdmin">Compute Network Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.networkUser">Compute Network User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.networkUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.networkViewer">Compute Network Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.networkViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.osAdminLogin">Compute OS Admin Login</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.osAdminLogin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.osLogin">Compute OS Login</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.osLogin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.securityAdmin">Compute Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.storageAdmin">Compute Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.storageAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.viewer">Compute Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataprep#dataprep.admin">Dataprep Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.admin">Deployment Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.editor">Deployment Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.viewer">Deployment Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.user">Discovery Engine User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.admin">Managed Kafka Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.viewer">Managed Kafka Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/mapsanalytics#mapsanalytics.viewer">Maps Analytics Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/mapsanalytics.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#monitoring.admin">Monitoring Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/monitoring.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#monitoring.editor">Monitoring Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/monitoring.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.admin">Notebooks Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.editor">Notebooks Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.viewer">Notebooks Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/pubsub#pubsub.admin">Pub/Sub Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/pubsub#pubsub.editor">Pub/Sub Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/pubsub#pubsub.viewer">Pub/Sub Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.admin">Service Management Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageAdmin">Service Usage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageConsumer">Service Usage Consumer</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageConsumer</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageViewer">Service Usage Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.admin">Workload Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/androidmanagement#androidmanagement.user">Android Management User</a> (<code class="role-name" translate="no" dir="ltr">roles/androidmanagement.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/workspacemarketplace#appmetadata.workspaceMarketplaceAppConfigurationAdmin">Workspace Marketplace App Configuration Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/appmetadata.workspaceMarketplaceAppConfigurationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.projectAdmin">Assured OSS Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.projectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.reader">Assured OSS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.adminViewer">Recommendations AI Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.adminViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/capacityplanner#capacityplanner.planner">Capacity Planner</a> (<code class="role-name" translate="no" dir="ltr">roles/capacityplanner.planner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudprofiler#cloudprofiler.user">Cloud Profiler User</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudprofiler.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.jobRunner">Cloud Scheduler Job Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.jobRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.studioUser">Cloud SQL Studio User</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.studioUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercepricemanagement#commercepricemanagement.privateOffersAdmin">Commerce Price Management Private Offers Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/commercepricemanagement.privateOffersAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectAdmin">Environment and Storage Object Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectUser">Environment and Storage Object User</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectViewer">Environment and Storage Object Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.imageUser">Compute Image User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.imageUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.loadBalancerServiceUser">Compute Load Balancer Services User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.loadBalancerServiceUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgFirewallPolicyAdmin">Compute Organization Firewall Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgFirewallPolicyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgFirewallPolicyUser">Compute Organization Firewall Policy User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgFirewallPolicyUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgSecurityPolicyAdmin">Compute Organization Security Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgSecurityPolicyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgSecurityPolicyUser">Compute Organization Security Policy User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgSecurityPolicyUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgSecurityResourceAdmin">Compute Organization Resource Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgSecurityResourceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.packetMirroringAdmin">Compute packet mirroring admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.packetMirroringAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.packetMirroringUser">Compute packet mirroring user</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.packetMirroringUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.entitlementManager">Consumer Procurement Entitlement Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.entitlementManager</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.entitlementViewer">Consumer Procurement Entitlement Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.entitlementViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.procurementAdmin">Consumer Procurement Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.procurementAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.procurementViewer">Consumer Procurement Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.procurementViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataprep#dataprep.projects.user">Dataprep User</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.projects.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.typeEditor">Deployment Manager Type Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.typeEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.typeViewer">Deployment Manager Type Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.typeViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceUser">Gemini Enterprise User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.podcastApiUser">Podcast API User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.podcastApiUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/earthengine#earthengine.appsPublisher">Earth Engine Apps Publisher</a> (<code class="role-name" translate="no" dir="ltr">roles/earthengine.appsPublisher</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.growthAdmin">Firebase Grow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.growthAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.growthViewer">Firebase Grow Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.growthViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.qualityAdmin">Firebase Quality Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.qualityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.qualityViewer">Firebase Quality Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.qualityViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.gatewayAdmin">Connect Gateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.gatewayAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.gatewayEditor">Connect Gateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.gatewayEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.gatewayReader">Connect Gateway Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.gatewayReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.scopeEditorProjectLevel">Fleet Project-level Scope Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.scopeEditorProjectLevel</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.scopeViewerProjectLevel">Fleet Project-level Scope Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.scopeViewerProjectLevel</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.client">Managed Kafka Client</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.client</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.clusterEditor">Managed Kafka Cluster Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.clusterEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.connectorEditor">Managed Kafka Connector Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.connectorEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.consumerGroupEditor">Managed Kafka Consumer Group Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.consumerGroupEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.topicEditor">Managed Kafka Topic Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.topicEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkservices#networkservices.serviceExtensionsAdmin">Service Extensions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networkservices.serviceExtensionsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkservices#networkservices.serviceExtensionsViewer">Service Extensions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/networkservices.serviceExtensionsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.legacyAdmin">Notebooks Legacy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.legacyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.legacyViewer">Notebooks Legacy Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.legacyViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.runner">Notebooks Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.runner</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminEditor">Security Center Admin Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminViewer">Security Center Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.quotaAdmin">Quota Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.quotaAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.quotaViewer">Quota Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.quotaViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#stackdriver.accounts.editor">Stackdriver Accounts Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/stackdriver.accounts.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.deploymentAdmin">Workload Manager Deployment Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.deploymentAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.workloadViewer">Workload Manager Workload Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.workloadViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.onlinePredictionServiceAgent">Vertex AI Online Prediction Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.onlinePredictionServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/anthos#anthos.serviceAgent">Anthos Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/anthos.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/anthosservicemesh#anthosservicemesh.serviceAgent">Anthos Service Mesh Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/anthosservicemesh.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/anthossupport#anthossupport.serviceAgent">Anthos Support Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/anthossupport.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/apigateway#apigateway_management.serviceAgent">Cloud API Gateway Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway_management.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAgent">App Engine Standard Environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengineflex#appengineflex.serviceAgent">App Engine flexible environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengineflex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/assuredworkloads#assuredworkloads.serviceAgent">Assured Workloads Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredworkloads.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.serviceAgent">Audit Manager Auditing Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/batch#batch.serviceAgent">Google Batch Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/batch.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.serviceAgent">Chronicle Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.serviceAgent">Cloud Security Compliance Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/tpu#cloudtpu.serviceAgent">Cloud TPU V2 API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtpu.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.ServiceAgent">Container Analysis Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datalabeling#datalabeling.serviceAgent">Data Labeling Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datalabeling.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dspm#dspm.serviceAgent">DSPM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.clusterServiceAgent">Edge Container Cluster Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.clusterServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.serviceAgent">Edge Container Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.managementServiceAgent">Firebase Service Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.managementServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.sdkProvisioningServiceAgent">Firebase SDK Provisioning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.sdkProvisioningServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasemods#firebasemods.serviceAgent">Firebase Extensions API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasemods.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/fleetengine#fleetengine.serviceAgent">FleetEngine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/fleetengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/lifesciences#genomics.serviceAgent">Genomics Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/genomics.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkehub#gkehub.serviceAgent">GKE Hub Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.sharedVpcServiceAgent">Cluster Director Shared VPC Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.sharedVpcServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/integrations#integrations.serviceAgent">Application Integration Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/krmapihosting#krmapihosting.anthosApiEndpointServiceAgent">KRM API Hosting AnthosApiEndpoint Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/krmapihosting.anthosApiEndpointServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/lifesciences#lifesciences.serviceAgent">Cloud Life Sciences Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/lifesciences.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/meshcontrolplane#meshcontrolplane.serviceAgent">Mesh Managed Control Plane Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/meshcontrolplane.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusteringress#multiclusteringress.serviceAgent">Multi Cluster Ingress Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusteringress.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/notebooks#notebooks.serviceAgent">AI Platform Notebooks Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.automationServiceAgent">Security Center Automation Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.automationServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.controlServiceAgent">Security Center Control Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.controlServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.securityHealthAnalyticsServiceAgent">Security Health Analytics Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.securityHealthAnalyticsServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.serviceAgent">Security Center Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/spectrumsas#spectrumsas.serviceAgent">Spectrum SAS Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/spectrumsas.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/workstations#workstations.serviceAgent">Workstations Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/workstations.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="serviceusage.services.listDependentServices" class="permission-name add-link" data-text="serviceusage.services.listDependentServices" tabindex="-1"><code translate="no" dir="ltr">serviceusage.services.listDependentServices</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.admin">ApiGateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.editor">ApiGateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.viewer">ApiGateway Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/automl#automl.admin">AutoML Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/automl#automl.editor">AutoML Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/automl#automl.viewer">AutoML Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.admin">Recommendations AI Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.editor">Recommendations AI Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.viewer">Recommendations AI Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/capacityplanner#capacityplanner.admin">Capacityplanner Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/capacityplanner.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/capacityplanner#capacityplanner.viewer">Capacity Planner Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/capacityplanner.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.admin">Cloud Scheduler Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.viewer">Cloud Scheduler Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsecurityscanner#cloudsecurityscanner.admin">Web Security Scanner Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecurityscanner.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsecurityscanner#cloudsecurityscanner.editor">Web Security Scanner Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecurityscanner.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsecurityscanner#cloudsecurityscanner.viewer">Web Security Scanner Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecurityscanner.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.admin">Cloud SQL Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.editor">Cloud SQL Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.viewer">Cloud SQL Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercepricemanagement#commercepricemanagement.editor">Commercepricemanagement Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/commercepricemanagement.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercepricemanagement#commercepricemanagement.viewer">Commerce Price Management Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/commercepricemanagement.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.admin">Composer Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.user">Composer User</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.admin">Compute Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.editor">Compute Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.instanceAdmin">Compute Instance Admin (beta)</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.instanceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.instanceAdmin.v1">Compute Instance Admin (v1)</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.instanceAdmin.v1</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.loadBalancerAdmin">Compute Load Balancer Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.loadBalancerAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.networkAdmin">Compute Network Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.networkUser">Compute Network User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.networkUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.networkViewer">Compute Network Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.networkViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.osAdminLogin">Compute OS Admin Login</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.osAdminLogin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.osLogin">Compute OS Login</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.osLogin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.securityAdmin">Compute Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.storageAdmin">Compute Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.storageAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.viewer">Compute Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataprep#dataprep.admin">Dataprep Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.admin">Deployment Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.editor">Deployment Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.viewer">Deployment Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.user">Discovery Engine User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#monitoring.admin">Monitoring Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/monitoring.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#monitoring.editor">Monitoring Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/monitoring.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.admin">Notebooks Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.editor">Notebooks Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.viewer">Notebooks Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/pubsub#pubsub.admin">Pub/Sub Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/pubsub#pubsub.editor">Pub/Sub Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/pubsub#pubsub.viewer">Pub/Sub Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.admin">Service Management Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageAdmin">Service Usage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageConsumer">Service Usage Consumer</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageConsumer</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageViewer">Service Usage Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.admin">Workload Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/androidmanagement#androidmanagement.user">Android Management User</a> (<code class="role-name" translate="no" dir="ltr">roles/androidmanagement.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/workspacemarketplace#appmetadata.workspaceMarketplaceAppConfigurationAdmin">Workspace Marketplace App Configuration Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/appmetadata.workspaceMarketplaceAppConfigurationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.projectAdmin">Assured OSS Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.projectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.reader">Assured OSS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.adminViewer">Recommendations AI Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.adminViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/capacityplanner#capacityplanner.planner">Capacity Planner</a> (<code class="role-name" translate="no" dir="ltr">roles/capacityplanner.planner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudprofiler#cloudprofiler.user">Cloud Profiler User</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudprofiler.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.jobRunner">Cloud Scheduler Job Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.jobRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.studioUser">Cloud SQL Studio User</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.studioUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercepricemanagement#commercepricemanagement.privateOffersAdmin">Commerce Price Management Private Offers Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/commercepricemanagement.privateOffersAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectAdmin">Environment and Storage Object Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectUser">Environment and Storage Object User</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectViewer">Environment and Storage Object Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.imageUser">Compute Image User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.imageUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.loadBalancerServiceUser">Compute Load Balancer Services User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.loadBalancerServiceUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgFirewallPolicyAdmin">Compute Organization Firewall Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgFirewallPolicyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgFirewallPolicyUser">Compute Organization Firewall Policy User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgFirewallPolicyUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgSecurityPolicyAdmin">Compute Organization Security Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgSecurityPolicyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgSecurityPolicyUser">Compute Organization Security Policy User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgSecurityPolicyUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgSecurityResourceAdmin">Compute Organization Resource Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgSecurityResourceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.packetMirroringAdmin">Compute packet mirroring admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.packetMirroringAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.packetMirroringUser">Compute packet mirroring user</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.packetMirroringUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.entitlementManager">Consumer Procurement Entitlement Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.entitlementManager</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.entitlementViewer">Consumer Procurement Entitlement Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.entitlementViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.procurementAdmin">Consumer Procurement Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.procurementAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.procurementViewer">Consumer Procurement Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.procurementViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataprep#dataprep.projects.user">Dataprep User</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.projects.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.typeEditor">Deployment Manager Type Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.typeEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.typeViewer">Deployment Manager Type Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.typeViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceUser">Gemini Enterprise User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.podcastApiUser">Podcast API User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.podcastApiUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/earthengine#earthengine.appsPublisher">Earth Engine Apps Publisher</a> (<code class="role-name" translate="no" dir="ltr">roles/earthengine.appsPublisher</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.growthAdmin">Firebase Grow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.growthAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.growthViewer">Firebase Grow Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.growthViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.qualityAdmin">Firebase Quality Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.qualityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.qualityViewer">Firebase Quality Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.qualityViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.gatewayAdmin">Connect Gateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.gatewayAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.gatewayEditor">Connect Gateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.gatewayEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.gatewayReader">Connect Gateway Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.gatewayReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.scopeEditorProjectLevel">Fleet Project-level Scope Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.scopeEditorProjectLevel</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.scopeViewerProjectLevel">Fleet Project-level Scope Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.scopeViewerProjectLevel</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkservices#networkservices.serviceExtensionsAdmin">Service Extensions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networkservices.serviceExtensionsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkservices#networkservices.serviceExtensionsViewer">Service Extensions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/networkservices.serviceExtensionsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.legacyAdmin">Notebooks Legacy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.legacyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.legacyViewer">Notebooks Legacy Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.legacyViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.runner">Notebooks Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.runner</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminEditor">Security Center Admin Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminViewer">Security Center Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.quotaAdmin">Quota Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.quotaAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.quotaViewer">Quota Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.quotaViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#stackdriver.accounts.editor">Stackdriver Accounts Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/stackdriver.accounts.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.deploymentAdmin">Workload Manager Deployment Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.deploymentAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.workloadViewer">Workload Manager Workload Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.workloadViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.onlinePredictionServiceAgent">Vertex AI Online Prediction Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.onlinePredictionServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/anthos#anthos.serviceAgent">Anthos Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/anthos.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/anthosservicemesh#anthosservicemesh.serviceAgent">Anthos Service Mesh Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/anthosservicemesh.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/anthossupport#anthossupport.serviceAgent">Anthos Support Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/anthossupport.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/apigateway#apigateway_management.serviceAgent">Cloud API Gateway Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway_management.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAgent">App Engine Standard Environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengineflex#appengineflex.serviceAgent">App Engine flexible environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengineflex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/assuredworkloads#assuredworkloads.serviceAgent">Assured Workloads Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredworkloads.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.serviceAgent">Audit Manager Auditing Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/batch#batch.serviceAgent">Google Batch Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/batch.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.serviceAgent">Chronicle Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.serviceAgent">Cloud Security Compliance Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/tpu#cloudtpu.serviceAgent">Cloud TPU V2 API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtpu.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.ServiceAgent">Container Analysis Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datalabeling#datalabeling.serviceAgent">Data Labeling Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datalabeling.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dspm#dspm.serviceAgent">DSPM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.clusterServiceAgent">Edge Container Cluster Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.clusterServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.serviceAgent">Edge Container Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.managementServiceAgent">Firebase Service Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.managementServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.sdkProvisioningServiceAgent">Firebase SDK Provisioning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.sdkProvisioningServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasemods#firebasemods.serviceAgent">Firebase Extensions API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasemods.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/fleetengine#fleetengine.serviceAgent">FleetEngine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/fleetengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/lifesciences#genomics.serviceAgent">Genomics Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/genomics.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkehub#gkehub.serviceAgent">GKE Hub Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.sharedVpcServiceAgent">Cluster Director Shared VPC Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.sharedVpcServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/integrations#integrations.serviceAgent">Application Integration Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/krmapihosting#krmapihosting.anthosApiEndpointServiceAgent">KRM API Hosting AnthosApiEndpoint Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/krmapihosting.anthosApiEndpointServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/lifesciences#lifesciences.serviceAgent">Cloud Life Sciences Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/lifesciences.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/meshcontrolplane#meshcontrolplane.serviceAgent">Mesh Managed Control Plane Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/meshcontrolplane.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusteringress#multiclusteringress.serviceAgent">Multi Cluster Ingress Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusteringress.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/notebooks#notebooks.serviceAgent">AI Platform Notebooks Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.automationServiceAgent">Security Center Automation Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.automationServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.controlServiceAgent">Security Center Control Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.controlServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.securityHealthAnalyticsServiceAgent">Security Health Analytics Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.securityHealthAnalyticsServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.serviceAgent">Security Center Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/spectrumsas#spectrumsas.serviceAgent">Spectrum SAS Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/spectrumsas.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/workstations#workstations.serviceAgent">Workstations Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/workstations.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="serviceusage.services.use" class="permission-name add-link" data-text="serviceusage.services.use" tabindex="-1"><code translate="no" dir="ltr">serviceusage.services.use</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/actions#actions.Admin">Actions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/actions.Admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/actions#actions.Viewer">Actions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/actions.Viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.user">Discovery Engine User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.admin">DLP Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.user">DLP User</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.admin">Gemini Cloud Assist Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.editor">Gemini Cloud Assist Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.investigationOwner">Gemini Cloud Assist Investigation Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.investigationOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.user">Gemini Cloud Assist User</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.viewer">Gemini Cloud Assist Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.editor">Cloud Memorystore Redis Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.viewer">Cloud Memorystore Redis Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageAdmin">Service Usage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageConsumer">Service Usage Consumer</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageConsumer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.containerRegistryMigrationAdmin">Container Registry -&gt; Artifact Registry Migration Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.containerRegistryMigrationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceUser">Gemini Enterprise User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.podcastApiUser">Podcast API User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.podcastApiUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/fleetengine#fleetengine.deliveryAdmin">Fleet Engine Delivery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/fleetengine.deliveryAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/fleetengine#fleetengine.ondemandAdmin">Fleet Engine On-Demand Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/fleetengine.ondemandAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.investigationAdmin">Gemini Cloud Assist Investigation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.investigationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.investigationCreator">Gemini Cloud Assist Investigation Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.investigationCreator</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.investigationEditor">Gemini Cloud Assist Investigation Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.investigationEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.investigationUser">Gemini Cloud Assist Investigation User</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.investigationUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.investigationViewer">Gemini Cloud Assist Investigation Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.investigationViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/securedlandingzone#securedlandingzone.bqdwProjectRemediator">SLZ BQDW Blueprint Project Level Remediator</a> (<code class="role-name" translate="no" dir="ltr">roles/securedlandingzone.bqdwProjectRemediator</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.agentSandboxServiceAgent">Vertex AI Agent Sandbox Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.agentSandboxServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.customCodeServiceAgent">Vertex AI Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.customCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.extensionServiceAgent">Vertex AI Extension Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.extensionServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.modelMonitoringServiceAgent">Vertex AI Model Monitoring Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.modelMonitoringServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.reasoningEngineServiceAgent">Vertex AI Reasoning Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.reasoningEngineServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.tuningServiceAgent">Vertex AI Tuning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.tuningServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/flow#aisandbox.serviceAgent">FlowService Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aisandbox.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/anthosservicemesh#anthosservicemesh.serviceAgent">Anthos Service Mesh Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/anthosservicemesh.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/assuredworkloads#assuredworkloads.serviceAgent">Assured Workloads Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredworkloads.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/automl#automl.serviceAgent">AutoML Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/batch#batch.serviceAgent">Google Batch Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/batch.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/bigquerydatatransfer#bigquerydatatransfer.serviceAgent">BigQuery Data Transfer Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatatransfer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ces#ces.serviceAgent">Customer Engagement Suite Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ces.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.serviceAgent">Chronicle Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudaicompanion#cloudaicompanion.serviceAgent">Gemini for Google Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudaicompanion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudconfig#cloudconfig.serviceAgent">Infrastructure Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudconfig.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/clouddeploy#clouddeploy.serviceAgent">Cloud Deploy Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploy.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/contactcenterinsights#contactcenterinsights.serviceAgent">Contact Center AI Insights Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/contactcenterinsights.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.defaultNodeServiceAgent">Kubernetes Engine Default Node Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.defaultNodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.nodeServiceAgent">[Deprecated] Kubernetes Engine Node Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.nodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/databaseinsights#databaseinsights.serviceAgent">Database Insights Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/databaseinsights.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datamigration#datamigration.serviceAgent">Database Migration Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datamigration.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprocrm#dataprocrm.nodeServiceAgent">Dataproc Resource Manager Node Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprocrm.nodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datastudio#datastudio.serviceAgent">Data Studio Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datastudio.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dialogflow#dialogflow.serviceAgent">Dialogflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dialogflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/eventarc#eventarc.serviceAgent">Eventarc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/eventarc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/externalexposure#externalexposure.serviceAgent">External Exposure Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/externalexposure.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.managementServiceAgent">Firebase Service Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.managementServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebaseappcheck#firebaseappcheck.serviceAgent">Firebase App Check Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseappcheck.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.serviceAgent">Firebase App Hosting Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasecrash#firebasecrashlytics.serviceAgent">Firebase Crashlytics Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasecrashlytics.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasedatabase#firebasedatabase.serviceAgent">Firebase Realtime Database Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasedatabase.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasedataconnect#firebasedataconnect.serviceAgent">Firebase Data Connect Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasedataconnect.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebaseml#firebaseml.serviceAgent">Firebase AI Logic Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/flow#flow.serviceAgent">Flow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/flow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/lifesciences#genomics.serviceAgent">Genomics Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/genomics.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkemulticloud#gkemulticloud.containerServiceAgent">Anthos Multi-Cloud Container Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkemulticloud.containerServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkemulticloud#gkemulticloud.controlPlaneMachineServiceAgent">Anthos Multi-Cloud Control Plane Machine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkemulticloud.controlPlaneMachineServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkemulticloud#gkemulticloud.nodePoolMachineServiceAgent">Anthos Multi-Cloud Node Pool Machine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkemulticloud.nodePoolMachineServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.serviceAgent">Cluster Director Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/krmapihosting#krmapihosting.anthosApiEndpointServiceAgent">KRM API Hosting AnthosApiEndpoint Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/krmapihosting.anthosApiEndpointServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/krmapihosting#krmapihosting.serviceAgent">KRM API Hosting Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/krmapihosting.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/lifesciences#lifesciences.serviceAgent">Cloud Life Sciences Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/lifesciences.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/looker#looker.restrictedServiceAgent">Looker Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/looker.restrictedServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/looker#looker.serviceAgent">(Legacy) Looker Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/looker.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/managedflink#managedflink.serviceAgent">Managed Flink Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/managedflink.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/meshcontrolplane#meshcontrolplane.serviceAgent">Mesh Managed Control Plane Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/meshcontrolplane.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/anthosservicemesh#meshdataplane.serviceAgent">Mesh Data Plane Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/meshdataplane.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/modelarmor#modelarmor.serviceAgent">Model Armor Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/modelarmor.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/monitoring#monitoring.notificationServiceAgent">Monitoring Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/monitoring.notificationServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusteringress#multiclusteringress.serviceAgent">Multi Cluster Ingress Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusteringress.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/pubsub#pubsub.serviceAgent">Cloud Pub/Sub Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/runapps#runapps.serviceAgent">Serverless Integrations Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/runapps.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securedlandingzone#securedlandingzone.serviceAgent">Secured Landing Zone Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securedlandingzone.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securesourcemanager#securesourcemanager.serviceAgent">Secure Source Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securesourcemanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/storageinsights#storageinsights.serviceAgent">StorageInsights Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/storageinsights.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visionai#visionai.serviceAgent">Cloud Vision AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visionai.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/workflows#workflows.serviceAgent">Cloud Workflows Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/workflows.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/workloadcertificate#workloadcertificate.serviceAgent">Workload Certificate Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadcertificate.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.serviceAgent">Workload Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="serviceusage.values.test" class="permission-name add-link" data-text="serviceusage.values.test" tabindex="-1"><code translate="no" dir="ltr">serviceusage.values.test</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.admin">ApiGateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.editor">ApiGateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.viewer">ApiGateway Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/automl#automl.admin">AutoML Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/automl#automl.editor">AutoML Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/automl#automl.viewer">AutoML Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.admin">Recommendations AI Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.editor">Recommendations AI Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.viewer">Recommendations AI Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/capacityplanner#capacityplanner.admin">Capacityplanner Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/capacityplanner.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/capacityplanner#capacityplanner.viewer">Capacity Planner Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/capacityplanner.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.admin">Cloud Scheduler Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.viewer">Cloud Scheduler Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsecurityscanner#cloudsecurityscanner.admin">Web Security Scanner Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecurityscanner.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsecurityscanner#cloudsecurityscanner.editor">Web Security Scanner Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecurityscanner.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsecurityscanner#cloudsecurityscanner.viewer">Web Security Scanner Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecurityscanner.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.admin">Cloud SQL Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.editor">Cloud SQL Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.viewer">Cloud SQL Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercepricemanagement#commercepricemanagement.editor">Commercepricemanagement Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/commercepricemanagement.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercepricemanagement#commercepricemanagement.viewer">Commerce Price Management Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/commercepricemanagement.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.admin">Composer Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.user">Composer User</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.admin">Compute Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.editor">Compute Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.instanceAdmin">Compute Instance Admin (beta)</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.instanceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.instanceAdmin.v1">Compute Instance Admin (v1)</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.instanceAdmin.v1</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.loadBalancerAdmin">Compute Load Balancer Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.loadBalancerAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.networkAdmin">Compute Network Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.networkUser">Compute Network User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.networkUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.networkViewer">Compute Network Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.networkViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.osAdminLogin">Compute OS Admin Login</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.osAdminLogin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.osLogin">Compute OS Login</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.osLogin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.securityAdmin">Compute Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.storageAdmin">Compute Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.storageAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.viewer">Compute Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataprep#dataprep.admin">Dataprep Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.admin">Deployment Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.editor">Deployment Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.viewer">Deployment Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.user">Discovery Engine User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.admin">Managed Kafka Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.viewer">Managed Kafka Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/mapsanalytics#mapsanalytics.viewer">Maps Analytics Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/mapsanalytics.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#monitoring.admin">Monitoring Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/monitoring.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#monitoring.editor">Monitoring Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/monitoring.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.admin">Notebooks Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.editor">Notebooks Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.viewer">Notebooks Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/pubsub#pubsub.admin">Pub/Sub Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/pubsub#pubsub.editor">Pub/Sub Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/pubsub#pubsub.viewer">Pub/Sub Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.admin">Service Management Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageAdmin">Service Usage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageConsumer">Service Usage Consumer</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageConsumer</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceusage#serviceusage.serviceUsageViewer">Service Usage Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceusage.serviceUsageViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.admin">Workload Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/androidmanagement#androidmanagement.user">Android Management User</a> (<code class="role-name" translate="no" dir="ltr">roles/androidmanagement.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/workspacemarketplace#appmetadata.workspaceMarketplaceAppConfigurationAdmin">Workspace Marketplace App Configuration Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/appmetadata.workspaceMarketplaceAppConfigurationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.projectAdmin">Assured OSS Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.projectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.reader">Assured OSS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.adminViewer">Recommendations AI Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.adminViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/capacityplanner#capacityplanner.planner">Capacity Planner</a> (<code class="role-name" translate="no" dir="ltr">roles/capacityplanner.planner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudprofiler#cloudprofiler.user">Cloud Profiler User</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudprofiler.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.jobRunner">Cloud Scheduler Job Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.jobRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.studioUser">Cloud SQL Studio User</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.studioUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercepricemanagement#commercepricemanagement.privateOffersAdmin">Commerce Price Management Private Offers Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/commercepricemanagement.privateOffersAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectAdmin">Environment and Storage Object Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectUser">Environment and Storage Object User</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectViewer">Environment and Storage Object Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.imageUser">Compute Image User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.imageUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.loadBalancerServiceUser">Compute Load Balancer Services User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.loadBalancerServiceUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgFirewallPolicyAdmin">Compute Organization Firewall Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgFirewallPolicyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgFirewallPolicyUser">Compute Organization Firewall Policy User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgFirewallPolicyUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgSecurityPolicyAdmin">Compute Organization Security Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgSecurityPolicyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgSecurityPolicyUser">Compute Organization Security Policy User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgSecurityPolicyUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgSecurityResourceAdmin">Compute Organization Resource Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgSecurityResourceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.packetMirroringAdmin">Compute packet mirroring admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.packetMirroringAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.packetMirroringUser">Compute packet mirroring user</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.packetMirroringUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.entitlementManager">Consumer Procurement Entitlement Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.entitlementManager</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.entitlementViewer">Consumer Procurement Entitlement Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.entitlementViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.procurementAdmin">Consumer Procurement Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.procurementAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.procurementViewer">Consumer Procurement Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.procurementViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataprep#dataprep.projects.user">Dataprep User</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.projects.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.typeEditor">Deployment Manager Type Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.typeEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.typeViewer">Deployment Manager Type Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.typeViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceUser">Gemini Enterprise User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.podcastApiUser">Podcast API User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.podcastApiUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/earthengine#earthengine.appsPublisher">Earth Engine Apps Publisher</a> (<code class="role-name" translate="no" dir="ltr">roles/earthengine.appsPublisher</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.growthAdmin">Firebase Grow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.growthAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.growthViewer">Firebase Grow Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.growthViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.qualityAdmin">Firebase Quality Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.qualityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.qualityViewer">Firebase Quality Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.qualityViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.gatewayAdmin">Connect Gateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.gatewayAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.gatewayEditor">Connect Gateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.gatewayEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.gatewayReader">Connect Gateway Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.gatewayReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.scopeEditorProjectLevel">Fleet Project-level Scope Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.scopeEditorProjectLevel</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.scopeViewerProjectLevel">Fleet Project-level Scope Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.scopeViewerProjectLevel</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.client">Managed Kafka Client</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.client</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.clusterEditor">Managed Kafka Cluster Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.clusterEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.connectorEditor">Managed Kafka Connector Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.connectorEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.consumerGroupEditor">Managed Kafka Consumer Group Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.consumerGroupEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.topicEditor">Managed Kafka Topic Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.topicEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/mapsanalytics#mapsanalytics.mobilitySolutionsOverageViewer">Mobility Solutions Overages Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/mapsanalytics.mobilitySolutionsOverageViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkservices#networkservices.serviceExtensionsAdmin">Service Extensions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networkservices.serviceExtensionsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkservices#networkservices.serviceExtensionsViewer">Service Extensions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/networkservices.serviceExtensionsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.legacyAdmin">Notebooks Legacy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.legacyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.legacyViewer">Notebooks Legacy Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.legacyViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.runner">Notebooks Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.runner</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminEditor">Security Center Admin Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminViewer">Security Center Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.quotaAdmin">Quota Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.quotaAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.quotaViewer">Quota Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.quotaViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#stackdriver.accounts.editor">Stackdriver Accounts Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/stackdriver.accounts.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.deploymentAdmin">Workload Manager Deployment Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.deploymentAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.workloadViewer">Workload Manager Workload Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.workloadViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.onlinePredictionServiceAgent">Vertex AI Online Prediction Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.onlinePredictionServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/anthos#anthos.serviceAgent">Anthos Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/anthos.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/anthosservicemesh#anthosservicemesh.serviceAgent">Anthos Service Mesh Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/anthosservicemesh.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/anthossupport#anthossupport.serviceAgent">Anthos Support Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/anthossupport.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/apigateway#apigateway_management.serviceAgent">Cloud API Gateway Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway_management.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAgent">App Engine Standard Environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengineflex#appengineflex.serviceAgent">App Engine flexible environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengineflex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/assuredworkloads#assuredworkloads.serviceAgent">Assured Workloads Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredworkloads.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.serviceAgent">Audit Manager Auditing Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/batch#batch.serviceAgent">Google Batch Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/batch.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.serviceAgent">Chronicle Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.serviceAgent">Cloud Security Compliance Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/tpu#cloudtpu.serviceAgent">Cloud TPU V2 API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtpu.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.ServiceAgent">Container Analysis Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datalabeling#datalabeling.serviceAgent">Data Labeling Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datalabeling.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dspm#dspm.serviceAgent">DSPM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.clusterServiceAgent">Edge Container Cluster Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.clusterServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.serviceAgent">Edge Container Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.managementServiceAgent">Firebase Service Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.managementServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.sdkProvisioningServiceAgent">Firebase SDK Provisioning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.sdkProvisioningServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasemods#firebasemods.serviceAgent">Firebase Extensions API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasemods.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/fleetengine#fleetengine.serviceAgent">FleetEngine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/fleetengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/lifesciences#genomics.serviceAgent">Genomics Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/genomics.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkehub#gkehub.serviceAgent">GKE Hub Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.sharedVpcServiceAgent">Cluster Director Shared VPC Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.sharedVpcServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/integrations#integrations.serviceAgent">Application Integration Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/krmapihosting#krmapihosting.anthosApiEndpointServiceAgent">KRM API Hosting AnthosApiEndpoint Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/krmapihosting.anthosApiEndpointServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/lifesciences#lifesciences.serviceAgent">Cloud Life Sciences Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/lifesciences.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/meshcontrolplane#meshcontrolplane.serviceAgent">Mesh Managed Control Plane Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/meshcontrolplane.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusteringress#multiclusteringress.serviceAgent">Multi Cluster Ingress Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusteringress.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/notebooks#notebooks.serviceAgent">AI Platform Notebooks Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.automationServiceAgent">Security Center Automation Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.automationServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.controlServiceAgent">Security Center Control Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.controlServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.securityHealthAnalyticsServiceAgent">Security Health Analytics Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.securityHealthAnalyticsServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.serviceAgent">Security Center Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/spectrumsas#spectrumsas.serviceAgent">Spectrum SAS Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/spectrumsas.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/workstations#workstations.serviceAgent">Workstations Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/workstations.serviceAgent</code>)</li>
</ul></td>
</tr>
</tbody>
</table>

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
