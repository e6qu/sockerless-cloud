# Resource Manager roles and permissions

<div class="devsite-article-body clearfix">

This page lists the IAM roles and permissions for Resource Manager. To search through all roles and permissions, see the [role and permission index](/iam/docs/roles-permissions).

## Resource Manager roles

<div results-count-container="">

</div>

<table class="fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="50%">Role</th>
<th>Permissions</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td class="role-description"><h4 id="resourcemanager.editor" class="role-title add-link" data-text="Resource Manager Editor " tabindex="-1">Resource Manager Editor</h4>
<p>(<code translate="no" dir="ltr">roles/resourcemanager.editor</code>)</p>
<span class="role-description"> </span>
<p>Access to manage Resource Manager resources</p></td>
<td class="role-permissions"><p><span class="iamperm-wildcard"><code translate="no" dir="ltr">resourcemanager.boundaries.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">resourcemanager.boundaries.associateToCapabilityConfig</code></li>
<li><code translate="no" dir="ltr">resourcemanager.boundaries.create</code></li>
<li><code translate="no" dir="ltr">resourcemanager.boundaries.delete</code></li>
<li><code translate="no" dir="ltr">resourcemanager.boundaries.get</code></li>
<li><code translate="no" dir="ltr">resourcemanager.boundaries.list</code></li>
<li><code translate="no" dir="ltr">resourcemanager.boundaries.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">resourcemanager.boundaryConfigs.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">resourcemanager.boundaryConfigs.get</code></li>
<li><code translate="no" dir="ltr">resourcemanager.boundaryConfigs.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">resourcemanager.capabilities.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">resourcemanager.capabilities.get</code></li>
<li><code translate="no" dir="ltr">resourcemanager.capabilities.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">resourcemanager.capabilityConfigs.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">resourcemanager.capabilityConfigs.create</code></li>
<li><code translate="no" dir="ltr">resourcemanager.capabilityConfigs.delete</code></li>
<li><code translate="no" dir="ltr">resourcemanager.capabilityConfigs.get</code></li>
<li><code translate="no" dir="ltr">resourcemanager.capabilityConfigs.list</code></li>
<li><code translate="no" dir="ltr">resourcemanager.capabilityConfigs.update</code></li>
</ul>
<p><code translate="no" dir="ltr">resourcemanager.folders.create</code></p>
<p><code translate="no" dir="ltr">resourcemanager.folders.delete</code></p>
<p><code translate="no" dir="ltr">resourcemanager.folders.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.folders.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.folders.undelete</code></p>
<p><code translate="no" dir="ltr">resourcemanager.folders.update</code></p>
<p><code translate="no" dir="ltr">resourcemanager.organizations.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.associateToCapabilityConfig</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.create</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.move</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">resourcemanager.tagHolds.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">resourcemanager.tagHolds.create</code></li>
<li><code translate="no" dir="ltr">resourcemanager.tagHolds.delete</code></li>
<li><code translate="no" dir="ltr">resourcemanager.tagHolds.list</code></li>
</ul>
<p><code translate="no" dir="ltr">resourcemanager.tagKeys.create</code></p>
<p><code translate="no" dir="ltr">resourcemanager.tagKeys.delete</code></p>
<p><code translate="no" dir="ltr">resourcemanager.tagKeys.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.tagKeys.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.tagKeys.update</code></p>
<p><code translate="no" dir="ltr">resourcemanager.tagValues.create</code></p>
<p><code translate="no" dir="ltr">resourcemanager.tagValues.delete</code></p>
<p><code translate="no" dir="ltr">resourcemanager.tagValues.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.tagValues.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.tagValues.update</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="resourcemanager.folderAdmin" class="role-title add-link" data-text="Folder Admin " tabindex="-1">Folder Admin</h4>
<p>(<code translate="no" dir="ltr">roles/resourcemanager.folderAdmin</code>)</p>
<span class="role-description custom"> </span>
<p>Provides all available permissions for working with folders.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Folder</li>
</ul></td>
<td class="role-permissions"><p><span class="iamperm-wildcard"><code translate="no" dir="ltr">essentialcontacts.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">essentialcontacts.contacts.create</code></li>
<li><code translate="no" dir="ltr">essentialcontacts.contacts.delete</code></li>
<li><code translate="no" dir="ltr">essentialcontacts.contacts.get</code></li>
<li><code translate="no" dir="ltr">essentialcontacts.contacts.list</code></li>
<li><code translate="no" dir="ltr">essentialcontacts.contacts.send</code></li>
<li><code translate="no" dir="ltr">essentialcontacts.contacts.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iam.policybindings.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iam.policybindings.get</code></li>
<li><code translate="no" dir="ltr">iam.policybindings.list</code></li>
</ul>
<p><code translate="no" dir="ltr">orgpolicy.constraints.list</code></p>
<p><code translate="no" dir="ltr">orgpolicy.policies.list</code></p>
<p><code translate="no" dir="ltr">orgpolicy.policy.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">resourcemanager.capabilities.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">resourcemanager.capabilities.get</code></li>
<li><code translate="no" dir="ltr">resourcemanager.capabilities.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">resourcemanager.folders.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">resourcemanager.folders.create</code></li>
<li><code translate="no" dir="ltr">resourcemanager.folders.createPolicyBinding</code></li>
<li><code translate="no" dir="ltr">resourcemanager.folders.delete</code></li>
<li><code translate="no" dir="ltr">resourcemanager.folders.deletePolicyBinding</code></li>
<li><code translate="no" dir="ltr">resourcemanager.folders.get</code></li>
<li><code translate="no" dir="ltr">resourcemanager.folders.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">resourcemanager.folders.list</code></li>
<li><code translate="no" dir="ltr">resourcemanager.folders.move</code></li>
<li><code translate="no" dir="ltr">resourcemanager.folders.searchPolicyBindings</code></li>
<li><code translate="no" dir="ltr">resourcemanager.folders.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">resourcemanager.folders.undelete</code></li>
<li><code translate="no" dir="ltr">resourcemanager.folders.update</code></li>
<li><code translate="no" dir="ltr">resourcemanager.folders.updatePolicyBinding</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">resourcemanager.hierarchyNodes.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">resourcemanager.hierarchyNodes.createTagBinding</code></li>
<li><code translate="no" dir="ltr">resourcemanager.hierarchyNodes.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">resourcemanager.hierarchyNodes.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">resourcemanager.hierarchyNodes.listTagBindings</code></li>
</ul>
<p><code translate="no" dir="ltr">resourcemanager.projects.createPolicyBinding</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.deletePolicyBinding</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.move</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.searchPolicyBindings</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.updatePolicyBinding</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="resourcemanager.organizationAdmin" class="role-title add-link" data-text="Organization Administrator " tabindex="-1">Organization Administrator</h4>
<p>(<code translate="no" dir="ltr">roles/resourcemanager.organizationAdmin</code>)</p>
<span class="role-description"> </span>
<p>Access to manage IAM policies and view organization policies for organizations, folders, and projects.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Project</li>
</ul></td>
<td class="role-permissions"><p><span class="iamperm-wildcard"><code translate="no" dir="ltr">essentialcontacts.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">essentialcontacts.contacts.create</code></li>
<li><code translate="no" dir="ltr">essentialcontacts.contacts.delete</code></li>
<li><code translate="no" dir="ltr">essentialcontacts.contacts.get</code></li>
<li><code translate="no" dir="ltr">essentialcontacts.contacts.list</code></li>
<li><code translate="no" dir="ltr">essentialcontacts.contacts.send</code></li>
<li><code translate="no" dir="ltr">essentialcontacts.contacts.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iam.policybindings.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iam.policybindings.get</code></li>
<li><code translate="no" dir="ltr">iam.policybindings.list</code></li>
</ul>
<p><code translate="no" dir="ltr">orgpolicy.constraints.list</code></p>
<p><code translate="no" dir="ltr">orgpolicy.policies.list</code></p>
<p><code translate="no" dir="ltr">orgpolicy.policy.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">resourcemanager.capabilities.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">resourcemanager.capabilities.get</code></li>
<li><code translate="no" dir="ltr">resourcemanager.capabilities.update</code></li>
</ul>
<p><code translate="no" dir="ltr">resourcemanager.folders.createPolicyBinding</code></p>
<p><code translate="no" dir="ltr">resourcemanager.folders.deletePolicyBinding</code></p>
<p><code translate="no" dir="ltr">resourcemanager.folders.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.folders.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">resourcemanager.folders.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.folders.searchPolicyBindings</code></p>
<p><code translate="no" dir="ltr">resourcemanager.folders.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">resourcemanager.folders.updatePolicyBinding</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">resourcemanager.organizations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">resourcemanager.organizations.createPolicyBinding</code></li>
<li><code translate="no" dir="ltr">resourcemanager.organizations.deletePolicyBinding</code></li>
<li><code translate="no" dir="ltr">resourcemanager.organizations.get</code></li>
<li><code translate="no" dir="ltr">resourcemanager.organizations.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">resourcemanager.organizations.searchPolicyBindings</code></li>
<li><code translate="no" dir="ltr">resourcemanager.organizations.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">resourcemanager.organizations.updatePolicyBinding</code></li>
</ul>
<p><code translate="no" dir="ltr">resourcemanager.projects.createPolicyBinding</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.deletePolicyBinding</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.searchPolicyBindings</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.updatePolicyBinding</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="resourcemanager.projectIamAdmin" class="role-title add-link" data-text="Project IAM Admin " tabindex="-1">Project IAM Admin</h4>
<p>(<code translate="no" dir="ltr">roles/resourcemanager.projectIamAdmin</code>)</p>
<span class="role-description custom"> </span>
<p>Provides permissions to administer allow policies on projects.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Project</li>
</ul></td>
<td class="role-permissions"><p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iam.policybindings.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iam.policybindings.get</code></li>
<li><code translate="no" dir="ltr">iam.policybindings.list</code></li>
</ul>
<p><code translate="no" dir="ltr">resourcemanager.projects.createPolicyBinding</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.deletePolicyBinding</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.searchPolicyBindings</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.updatePolicyBinding</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="resourcemanager.projectMover" class="role-title add-link" data-text="Project Mover " tabindex="-1">Project Mover</h4>
<p>(<code translate="no" dir="ltr">roles/resourcemanager.projectMover</code>)</p>
<span class="role-description custom"> </span>
<p>Provides access to update and move projects.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Project</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.move</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.update</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="resourcemanager.tagAdmin" class="role-title add-link" data-text="Tag Administrator " tabindex="-1">Tag Administrator</h4>
<p>(<code translate="no" dir="ltr">roles/resourcemanager.tagAdmin</code>)</p>
<span class="role-description"> </span>
<p>Access to create, delete, update, and manage access to Tags</p></td>
<td class="role-permissions"><p><span class="iamperm-wildcard"><code translate="no" dir="ltr">resourcemanager.tagHolds.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">resourcemanager.tagHolds.create</code></li>
<li><code translate="no" dir="ltr">resourcemanager.tagHolds.delete</code></li>
<li><code translate="no" dir="ltr">resourcemanager.tagHolds.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">resourcemanager.tagKeys.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">resourcemanager.tagKeys.create</code></li>
<li><code translate="no" dir="ltr">resourcemanager.tagKeys.delete</code></li>
<li><code translate="no" dir="ltr">resourcemanager.tagKeys.get</code></li>
<li><code translate="no" dir="ltr">resourcemanager.tagKeys.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">resourcemanager.tagKeys.list</code></li>
<li><code translate="no" dir="ltr">resourcemanager.tagKeys.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">resourcemanager.tagKeys.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">resourcemanager.tagValues.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">resourcemanager.tagValues.create</code></li>
<li><code translate="no" dir="ltr">resourcemanager.tagValues.delete</code></li>
<li><code translate="no" dir="ltr">resourcemanager.tagValues.get</code></li>
<li><code translate="no" dir="ltr">resourcemanager.tagValues.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">resourcemanager.tagValues.list</code></li>
<li><code translate="no" dir="ltr">resourcemanager.tagValues.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">resourcemanager.tagValues.update</code></li>
</ul></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="resourcemanager.tagUser" class="role-title add-link" data-text="Tag User " tabindex="-1">Tag User</h4>
<p>(<code translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<span class="role-description"> </span>
<p>Access to list Tags and manage their associations with resources</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">alloydb.backups.createTagBinding</code></p>
<p><code translate="no" dir="ltr">alloydb.backups.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">alloydb.backups.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">alloydb.backups.listTagBindings</code></p>
<p><code translate="no" dir="ltr">alloydb.clusters.createTagBinding</code></p>
<p><code translate="no" dir="ltr">alloydb.clusters.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">alloydb.clusters.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">alloydb.clusters.listTagBindings</code></p>
<p><code translate="no" dir="ltr">apigateway.apis.createTagBinding</code></p>
<p><code translate="no" dir="ltr">apigateway.apis.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">apigateway.apis.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">apigateway.apis.listTagBindings</code></p>
<p><code translate="no" dir="ltr">apigateway.gateways.createTagBinding</code></p>
<p><code translate="no" dir="ltr">apigateway.gateways.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">apigateway.gateways.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">apigateway.gateways.listTagBindings</code></p>
<p><code translate="no" dir="ltr">apihub.apis.createTagBinding</code></p>
<p><code translate="no" dir="ltr">apihub.apis.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">apihub.apis.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">apihub.apis.listTagBindings</code></p>
<p><code translate="no" dir="ltr">apihub.deployments.createTagBinding</code></p>
<p><code translate="no" dir="ltr">apihub.deployments.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">apihub.deployments.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">apihub.deployments.listTagBindings</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.createTagBinding</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.listTagBindings</code></p>
<p><code translate="no" dir="ltr">backupdr.backupVaults.createTagBinding</code></p>
<p><code translate="no" dir="ltr">backupdr.backupVaults.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">backupdr.backupVaults.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">backupdr.backupVaults.listTagBindings</code></p>
<p><code translate="no" dir="ltr">backupdr.managementServers.createTagBinding</code></p>
<p><code translate="no" dir="ltr">backupdr.managementServers.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">backupdr.managementServers.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">backupdr.managementServers.listTagBindings</code></p>
<p><code translate="no" dir="ltr">beyondcorp.appConnections.createTagBinding</code></p>
<p><code translate="no" dir="ltr">beyondcorp.appConnections.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">beyondcorp.appConnections.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">beyondcorp.appConnections.listTagBindings</code></p>
<p><code translate="no" dir="ltr">beyondcorp.appConnectors.createTagBinding</code></p>
<p><code translate="no" dir="ltr">beyondcorp.appConnectors.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">beyondcorp.appConnectors.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">beyondcorp.appConnectors.listTagBindings</code></p>
<p><code translate="no" dir="ltr">beyondcorp.appGateways.createTagBinding</code></p>
<p><code translate="no" dir="ltr">beyondcorp.appGateways.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">beyondcorp.appGateways.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">beyondcorp.appGateways.listTagBindings</code></p>
<p><code translate="no" dir="ltr">bigquery.datasets.createTagBinding</code></p>
<p><code translate="no" dir="ltr">bigquery.datasets.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">bigquery.datasets.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">bigquery.datasets.listTagBindings</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.createTagBinding</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.listTagBindings</code></p>
<p><code translate="no" dir="ltr">bigtable.authorizedViews.createTagBinding</code></p>
<p><code translate="no" dir="ltr">bigtable.authorizedViews.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">bigtable.authorizedViews.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">bigtable.authorizedViews.listTagBindings</code></p>
<p><code translate="no" dir="ltr">bigtable.instances.createTagBinding</code></p>
<p><code translate="no" dir="ltr">bigtable.instances.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">bigtable.instances.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">bigtable.instances.listTagBindings</code></p>
<p><code translate="no" dir="ltr">certificatemanager.certissuanceconfigs.createTagBinding</code></p>
<p><code translate="no" dir="ltr">certificatemanager.certissuanceconfigs.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">certificatemanager.certissuanceconfigs.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">certificatemanager.certissuanceconfigs.listTagBindings</code></p>
<p><code translate="no" dir="ltr">certificatemanager.certmapentries.createTagBinding</code></p>
<p><code translate="no" dir="ltr">certificatemanager.certmapentries.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">certificatemanager.certmapentries.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">certificatemanager.certmapentries.listTagBindings</code></p>
<p><code translate="no" dir="ltr">certificatemanager.certmaps.createTagBinding</code></p>
<p><code translate="no" dir="ltr">certificatemanager.certmaps.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">certificatemanager.certmaps.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">certificatemanager.certmaps.listTagBindings</code></p>
<p><code translate="no" dir="ltr">certificatemanager.certs.createTagBinding</code></p>
<p><code translate="no" dir="ltr">certificatemanager.certs.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">certificatemanager.certs.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">certificatemanager.certs.listTagBindings</code></p>
<p><code translate="no" dir="ltr">certificatemanager.dnsauthorizations.createTagBinding</code></p>
<p><code translate="no" dir="ltr">certificatemanager.dnsauthorizations.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">certificatemanager.dnsauthorizations.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">certificatemanager.dnsauthorizations.listTagBindings</code></p>
<p><code translate="no" dir="ltr">certificatemanager.trustconfigs.createTagBinding</code></p>
<p><code translate="no" dir="ltr">certificatemanager.trustconfigs.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">certificatemanager.trustconfigs.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">certificatemanager.trustconfigs.listTagBindings</code></p>
<p><code translate="no" dir="ltr">clouddeploy.deliveryPipelines.createTagBinding</code></p>
<p><code translate="no" dir="ltr">clouddeploy.deliveryPipelines.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">clouddeploy.deliveryPipelines.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">clouddeploy.deliveryPipelines.listTagBindings</code></p>
<p><code translate="no" dir="ltr">clouddeploy.targets.createTagBinding</code></p>
<p><code translate="no" dir="ltr">clouddeploy.targets.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">clouddeploy.targets.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">clouddeploy.targets.listTagBindings</code></p>
<p><code translate="no" dir="ltr">cloudkms.keyRings.createTagBinding</code></p>
<p><code translate="no" dir="ltr">cloudkms.keyRings.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">cloudkms.keyRings.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">cloudkms.keyRings.listTagBindings</code></p>
<p><code translate="no" dir="ltr">cloudsql.instances.createTagBinding</code></p>
<p><code translate="no" dir="ltr">cloudsql.instances.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">cloudsql.instances.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">cloudsql.instances.listTagBindings</code></p>
<p><code translate="no" dir="ltr">composer.environments.createTagBinding</code></p>
<p><code translate="no" dir="ltr">composer.environments.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">composer.environments.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">composer.environments.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.addresses.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.addresses.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.addresses.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.addresses.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.backendBuckets.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.backendBuckets.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.backendBuckets.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.backendBuckets.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.backendServices.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.backendServices.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.backendServices.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.backendServices.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.commitments.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.commitments.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.commitments.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.commitments.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.disks.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.disks.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.disks.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.disks.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.externalVpnGateways.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.externalVpnGateways.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.externalVpnGateways.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.externalVpnGateways.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.firewallPolicies.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.firewallPolicies.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.firewallPolicies.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.firewallPolicies.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.firewalls.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.firewalls.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.firewalls.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.firewalls.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.forwardingRules.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.forwardingRules.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.forwardingRules.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.forwardingRules.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.futureReservations.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.futureReservations.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.futureReservations.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.futureReservations.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.globalAddresses.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.globalAddresses.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.globalAddresses.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.globalAddresses.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.globalForwardingRules.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.globalForwardingRules.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.globalForwardingRules.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.globalForwardingRules.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.globalNetworkEndpointGroups.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.globalNetworkEndpointGroups.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.globalNetworkEndpointGroups.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.globalNetworkEndpointGroups.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.healthChecks.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.healthChecks.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.healthChecks.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.healthChecks.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.httpHealthChecks.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.httpHealthChecks.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.httpHealthChecks.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.httpHealthChecks.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.httpsHealthChecks.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.httpsHealthChecks.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.httpsHealthChecks.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.httpsHealthChecks.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.images.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.images.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.images.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.images.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.instanceGroupManagers.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.instanceGroupManagers.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.instanceGroupManagers.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.instanceGroupManagers.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.instanceGroups.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.instanceGroups.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.instanceGroups.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.instanceGroups.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.instances.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.instances.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.instances.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.instances.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.instantSnapshots.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.instantSnapshots.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.instantSnapshots.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.instantSnapshots.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.interconnectAttachments.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.interconnectAttachments.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.interconnectAttachments.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.interconnectAttachments.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.interconnects.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.interconnects.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.interconnects.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.interconnects.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.licenses.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.licenses.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.licenses.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.licenses.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.machineImages.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.machineImages.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.machineImages.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.machineImages.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.networkAttachments.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.networkAttachments.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.networkAttachments.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.networkAttachments.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.networkEdgeSecurityServices.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.networkEdgeSecurityServices.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.networkEdgeSecurityServices.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.networkEdgeSecurityServices.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.networkEndpointGroups.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.networkEndpointGroups.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.networkEndpointGroups.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.networkEndpointGroups.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.networks.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.networks.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.networks.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.networks.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.packetMirrorings.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.packetMirrorings.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.packetMirrorings.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.packetMirrorings.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.publicDelegatedPrefixes.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.publicDelegatedPrefixes.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.publicDelegatedPrefixes.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.publicDelegatedPrefixes.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.regionBackendBuckets.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.regionBackendBuckets.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.regionBackendBuckets.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.regionBackendBuckets.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.regionBackendServices.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.regionBackendServices.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.regionBackendServices.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.regionBackendServices.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.regionFirewallPolicies.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.regionFirewallPolicies.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.regionFirewallPolicies.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.regionFirewallPolicies.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.regionHealthChecks.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.regionHealthChecks.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.regionHealthChecks.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.regionHealthChecks.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.regionNetworkEndpointGroups.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.regionNetworkEndpointGroups.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.regionNetworkEndpointGroups.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.regionNetworkEndpointGroups.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.regionSecurityPolicies.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.regionSecurityPolicies.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.regionSecurityPolicies.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.regionSecurityPolicies.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.regionSslCertificates.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.regionSslCertificates.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.regionSslCertificates.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.regionSslCertificates.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.regionSslPolicies.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.regionSslPolicies.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.regionSslPolicies.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.regionSslPolicies.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.regionTargetHttpProxies.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.regionTargetHttpProxies.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.regionTargetHttpProxies.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.regionTargetHttpProxies.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.regionTargetHttpsProxies.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.regionTargetHttpsProxies.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.regionTargetHttpsProxies.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.regionTargetHttpsProxies.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.regionTargetTcpProxies.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.regionTargetTcpProxies.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.regionTargetTcpProxies.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.regionTargetTcpProxies.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.regionUrlMaps.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.regionUrlMaps.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.regionUrlMaps.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.regionUrlMaps.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.reservations.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.reservations.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.reservations.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.reservations.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.routers.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.routers.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.routers.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.routers.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.routes.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.routes.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.routes.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.routes.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.securityPolicies.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.securityPolicies.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.securityPolicies.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.securityPolicies.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.serviceAttachments.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.serviceAttachments.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.serviceAttachments.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.serviceAttachments.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.snapshots.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.snapshots.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.snapshots.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.snapshots.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.sslCertificates.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.sslCertificates.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.sslCertificates.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.sslCertificates.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.sslPolicies.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.sslPolicies.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.sslPolicies.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.sslPolicies.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.storagePools.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.storagePools.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.storagePools.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.storagePools.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.subnetworks.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.subnetworks.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.subnetworks.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.subnetworks.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.targetGrpcProxies.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.targetGrpcProxies.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.targetGrpcProxies.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.targetGrpcProxies.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.targetHttpProxies.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.targetHttpProxies.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.targetHttpProxies.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.targetHttpProxies.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.targetHttpsProxies.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.targetHttpsProxies.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.targetHttpsProxies.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.targetHttpsProxies.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.targetInstances.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.targetInstances.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.targetInstances.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.targetInstances.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.targetPools.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.targetPools.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.targetPools.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.targetPools.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.targetSslProxies.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.targetSslProxies.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.targetSslProxies.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.targetSslProxies.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.targetTcpProxies.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.targetTcpProxies.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.targetTcpProxies.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.targetTcpProxies.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.targetVpnGateways.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.targetVpnGateways.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.targetVpnGateways.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.targetVpnGateways.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.urlMaps.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.urlMaps.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.urlMaps.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.urlMaps.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.vpnGateways.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.vpnGateways.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.vpnGateways.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.vpnGateways.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.vpnTunnels.createTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.vpnTunnels.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">compute.vpnTunnels.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.vpnTunnels.listTagBindings</code></p>
<p><code translate="no" dir="ltr">config.deploymentgroups.createTagBinding</code></p>
<p><code translate="no" dir="ltr">config.deploymentgroups.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">config.deploymentgroups.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">config.deploymentgroups.listTagBindings</code></p>
<p><code translate="no" dir="ltr">config.deployments.createTagBinding</code></p>
<p><code translate="no" dir="ltr">config.deployments.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">config.deployments.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">config.deployments.listTagBindings</code></p>
<p><code translate="no" dir="ltr">config.previews.createTagBinding</code></p>
<p><code translate="no" dir="ltr">config.previews.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">config.previews.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">config.previews.listTagBindings</code></p>
<p><code translate="no" dir="ltr">container.clusters.createTagBinding</code></p>
<p><code translate="no" dir="ltr">container.clusters.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">container.clusters.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">container.clusters.listTagBindings</code></p>
<p><code translate="no" dir="ltr">dataflow.jobs.createTagBinding</code></p>
<p><code translate="no" dir="ltr">dataflow.jobs.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">dataflow.jobs.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">dataflow.jobs.listTagBindings</code></p>
<p><code translate="no" dir="ltr">dataflow.snapshots.createTagBinding</code></p>
<p><code translate="no" dir="ltr">dataflow.snapshots.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">dataflow.snapshots.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">dataflow.snapshots.listTagBindings</code></p>
<p><code translate="no" dir="ltr">dataform.repositories.createTagBinding</code></p>
<p><code translate="no" dir="ltr">dataform.repositories.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">dataform.repositories.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">dataform.repositories.listTagBindings</code></p>
<p><code translate="no" dir="ltr">datafusion.instances.createTagBinding</code></p>
<p><code translate="no" dir="ltr">datafusion.instances.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">datafusion.instances.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">datafusion.instances.listTagBindings</code></p>
<p><code translate="no" dir="ltr">datamigration.connectionprofiles.createTagBinding</code></p>
<p><code translate="no" dir="ltr">datamigration.connectionprofiles.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">datamigration.connectionprofiles.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">datamigration.connectionprofiles.listTagBindings</code></p>
<p><code translate="no" dir="ltr">datamigration.migrationjobs.createTagBinding</code></p>
<p><code translate="no" dir="ltr">datamigration.migrationjobs.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">datamigration.migrationjobs.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">datamigration.migrationjobs.listTagBindings</code></p>
<p><code translate="no" dir="ltr">datamigration.privateconnections.createTagBinding</code></p>
<p><code translate="no" dir="ltr">datamigration.privateconnections.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">datamigration.privateconnections.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">datamigration.privateconnections.listTagBindings</code></p>
<p><code translate="no" dir="ltr">dataplex.entryGroups.createTagBinding</code></p>
<p><code translate="no" dir="ltr">dataplex.entryGroups.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">dataplex.entryGroups.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">dataplex.entryGroups.listTagBindings</code></p>
<p><code translate="no" dir="ltr">dataplex.entryTypes.createTagBinding</code></p>
<p><code translate="no" dir="ltr">dataplex.entryTypes.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">dataplex.entryTypes.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">dataplex.entryTypes.listTagBindings</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">dataplex.governanceRules.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">dataplex.governanceRules.createTagBinding</code></li>
<li><code translate="no" dir="ltr">dataplex.governanceRules.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">dataplex.governanceRules.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">dataplex.governanceRules.listTagBindings</code></li>
</ul>
<p><code translate="no" dir="ltr">datastore.databases.createTagBinding</code></p>
<p><code translate="no" dir="ltr">datastore.databases.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">datastore.databases.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">datastore.databases.listTagBindings</code></p>
<p><code translate="no" dir="ltr">datastream.connectionProfiles.createTagBinding</code></p>
<p><code translate="no" dir="ltr">datastream.connectionProfiles.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">datastream.connectionProfiles.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">datastream.connectionProfiles.listTagBindings</code></p>
<p><code translate="no" dir="ltr">datastream.privateConnections.createTagBinding</code></p>
<p><code translate="no" dir="ltr">datastream.privateConnections.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">datastream.privateConnections.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">datastream.privateConnections.listTagBindings</code></p>
<p><code translate="no" dir="ltr">datastream.streams.createTagBinding</code></p>
<p><code translate="no" dir="ltr">datastream.streams.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">datastream.streams.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">datastream.streams.listTagBindings</code></p>
<p><code translate="no" dir="ltr">dns.policies.createTagBinding</code></p>
<p><code translate="no" dir="ltr">dns.policies.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">dns.policies.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">dns.policies.listTagBindings</code></p>
<p><code translate="no" dir="ltr">domains.registrations.createTagBinding</code></p>
<p><code translate="no" dir="ltr">domains.registrations.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">domains.registrations.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">domains.registrations.listTagBindings</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.createTagBinding</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.listTagBindings</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.createTagBinding</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.listTagBindings</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.createTagBinding</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.listTagBindings</code></p>
<p><code translate="no" dir="ltr">file.backups.createTagBinding</code></p>
<p><code translate="no" dir="ltr">file.backups.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">file.backups.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">file.backups.listTagBindings</code></p>
<p><code translate="no" dir="ltr">file.instances.createTagBinding</code></p>
<p><code translate="no" dir="ltr">file.instances.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">file.instances.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">file.instances.listTagBindings</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">file.snapshots.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">file.snapshots.createTagBinding</code></li>
<li><code translate="no" dir="ltr">file.snapshots.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">file.snapshots.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">file.snapshots.listTagBindings</code></li>
</ul>
<p><code translate="no" dir="ltr">financialservices.v1instances.createTagBinding</code></p>
<p><code translate="no" dir="ltr">financialservices.v1instances.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">financialservices.v1instances.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">financialservices.v1instances.listTagBindings</code></p>
<p><code translate="no" dir="ltr">gkemulticloud.attachedClusters.createTagBinding</code></p>
<p><code translate="no" dir="ltr">gkemulticloud.attachedClusters.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">gkemulticloud.attachedClusters.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">gkemulticloud.attachedClusters.listTagBindings</code></p>
<p><code translate="no" dir="ltr">gkeonprem.bareMetalAdminClusters.createTagBinding</code></p>
<p><code translate="no" dir="ltr">gkeonprem.bareMetalAdminClusters.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">gkeonprem.bareMetalAdminClusters.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">gkeonprem.bareMetalAdminClusters.listTagBindings</code></p>
<p><code translate="no" dir="ltr">gkeonprem.bareMetalClusters.createTagBinding</code></p>
<p><code translate="no" dir="ltr">gkeonprem.bareMetalClusters.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">gkeonprem.bareMetalClusters.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">gkeonprem.bareMetalClusters.listTagBindings</code></p>
<p><code translate="no" dir="ltr">gkeonprem.vmwareAdminClusters.createTagBinding</code></p>
<p><code translate="no" dir="ltr">gkeonprem.vmwareAdminClusters.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">gkeonprem.vmwareAdminClusters.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">gkeonprem.vmwareAdminClusters.listTagBindings</code></p>
<p><code translate="no" dir="ltr">gkeonprem.vmwareClusters.createTagBinding</code></p>
<p><code translate="no" dir="ltr">gkeonprem.vmwareClusters.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">gkeonprem.vmwareClusters.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">gkeonprem.vmwareClusters.listTagBindings</code></p>
<p><code translate="no" dir="ltr">iam.roles.createTagBinding</code></p>
<p><code translate="no" dir="ltr">iam.roles.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">iam.roles.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">iam.roles.listTagBindings</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.createTagBinding</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.listTagBindings</code></p>
<p><code translate="no" dir="ltr">krmapihosting.krmApiHosts.createTagBinding</code></p>
<p><code translate="no" dir="ltr">krmapihosting.krmApiHosts.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">krmapihosting.krmApiHosts.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">krmapihosting.krmApiHosts.listTagBindings</code></p>
<p><code translate="no" dir="ltr">livestream.channels.createTagBinding</code></p>
<p><code translate="no" dir="ltr">livestream.channels.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">livestream.channels.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">livestream.channels.listTagBindings</code></p>
<p><code translate="no" dir="ltr">livestream.inputs.createTagBinding</code></p>
<p><code translate="no" dir="ltr">livestream.inputs.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">livestream.inputs.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">livestream.inputs.listTagBindings</code></p>
<p><code translate="no" dir="ltr">livestream.pools.createTagBinding</code></p>
<p><code translate="no" dir="ltr">livestream.pools.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">livestream.pools.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">livestream.pools.listTagBindings</code></p>
<p><code translate="no" dir="ltr">logging.buckets.createTagBinding</code></p>
<p><code translate="no" dir="ltr">logging.buckets.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">logging.buckets.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">logging.buckets.listTagBindings</code></p>
<p><code translate="no" dir="ltr">looker.instances.createTagBinding</code></p>
<p><code translate="no" dir="ltr">looker.instances.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">looker.instances.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">looker.instances.listTagBindings</code></p>
<p><code translate="no" dir="ltr">managedidentities.domains.createTagBinding</code></p>
<p><code translate="no" dir="ltr">managedidentities.domains.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">managedidentities.domains.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">managedidentities.domains.listTagBindings</code></p>
<p><code translate="no" dir="ltr">memcache.instances.createTagBinding</code></p>
<p><code translate="no" dir="ltr">memcache.instances.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">memcache.instances.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">memcache.instances.listTagBindings</code></p>
<p><code translate="no" dir="ltr">metastore.federations.createTagBinding</code></p>
<p><code translate="no" dir="ltr">metastore.federations.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">metastore.federations.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">metastore.federations.listTagBindings</code></p>
<p><code translate="no" dir="ltr">metastore.services.createTagBinding</code></p>
<p><code translate="no" dir="ltr">metastore.services.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">metastore.services.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">metastore.services.listTagBindings</code></p>
<p><code translate="no" dir="ltr">monitoring.alertPolicies.createTagBinding</code></p>
<p><code translate="no" dir="ltr">monitoring.alertPolicies.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">monitoring.alertPolicies.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">monitoring.alertPolicies.listTagBindings</code></p>
<p><code translate="no" dir="ltr">monitoring.dashboards.createTagBinding</code></p>
<p><code translate="no" dir="ltr">monitoring.dashboards.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">monitoring.dashboards.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">monitoring.dashboards.listTagBindings</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.hubs.createTagBinding</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.hubs.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.hubs.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.hubs.listTagBindings</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.spokes.createTagBinding</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.spokes.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.spokes.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.spokes.listTagBindings</code></p>
<p><code translate="no" dir="ltr">networkmanagement.connectivitytests.createTagBinding</code></p>
<p><code translate="no" dir="ltr">networkmanagement.connectivitytests.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">networkmanagement.connectivitytests.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">networkmanagement.connectivitytests.listTagBindings</code></p>
<p><code translate="no" dir="ltr">networksecurity.authorizationPolicies.createTagBinding</code></p>
<p><code translate="no" dir="ltr">networksecurity.authorizationPolicies.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">networksecurity.authorizationPolicies.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">networksecurity.authorizationPolicies.listTagBindings</code></p>
<p><code translate="no" dir="ltr">networksecurity.clientTlsPolicies.createTagBinding</code></p>
<p><code translate="no" dir="ltr">networksecurity.clientTlsPolicies.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">networksecurity.clientTlsPolicies.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">networksecurity.clientTlsPolicies.listTagBindings</code></p>
<p><code translate="no" dir="ltr">networksecurity.serverTlsPolicies.createTagBinding</code></p>
<p><code translate="no" dir="ltr">networksecurity.serverTlsPolicies.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">networksecurity.serverTlsPolicies.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">networksecurity.serverTlsPolicies.listTagBindings</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">networkservices.endpointConfigSelectors.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">networkservices.endpointConfigSelectors.createTagBinding</code></li>
<li><code translate="no" dir="ltr">networkservices.endpointConfigSelectors.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">networkservices.endpointConfigSelectors.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">networkservices.endpointConfigSelectors.listTagBindings</code></li>
</ul>
<p><code translate="no" dir="ltr">networkservices.gateways.createTagBinding</code></p>
<p><code translate="no" dir="ltr">networkservices.gateways.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">networkservices.gateways.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">networkservices.gateways.listTagBindings</code></p>
<p><code translate="no" dir="ltr">networkservices.httpFilters.createTagBinding</code></p>
<p><code translate="no" dir="ltr">networkservices.httpFilters.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">networkservices.httpFilters.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">networkservices.httpFilters.listTagBindings</code></p>
<p><code translate="no" dir="ltr">networkservices.meshes.createTagBinding</code></p>
<p><code translate="no" dir="ltr">networkservices.meshes.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">networkservices.meshes.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">networkservices.meshes.listTagBindings</code></p>
<p><code translate="no" dir="ltr">notebooks.instances.createTagBinding</code></p>
<p><code translate="no" dir="ltr">notebooks.instances.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">notebooks.instances.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">notebooks.instances.listTagBindings</code></p>
<p><code translate="no" dir="ltr">parametermanager.parameters.createTagBinding</code></p>
<p><code translate="no" dir="ltr">parametermanager.parameters.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">parametermanager.parameters.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">parametermanager.parameters.listTagBindings</code></p>
<p><code translate="no" dir="ltr">privateca.caPools.createTagBinding</code></p>
<p><code translate="no" dir="ltr">privateca.caPools.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">privateca.caPools.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">privateca.caPools.listTagBindings</code></p>
<p><code translate="no" dir="ltr">privateca.certificateTemplates.createTagBinding</code></p>
<p><code translate="no" dir="ltr">privateca.certificateTemplates.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">privateca.certificateTemplates.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">privateca.certificateTemplates.listTagBindings</code></p>
<p><code translate="no" dir="ltr">pubsub.snapshots.createTagBinding</code></p>
<p><code translate="no" dir="ltr">pubsub.snapshots.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">pubsub.snapshots.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">pubsub.snapshots.listTagBindings</code></p>
<p><code translate="no" dir="ltr">pubsub.subscriptions.createTagBinding</code></p>
<p><code translate="no" dir="ltr">pubsub.subscriptions.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">pubsub.subscriptions.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">pubsub.subscriptions.listTagBindings</code></p>
<p><code translate="no" dir="ltr">pubsub.topics.createTagBinding</code></p>
<p><code translate="no" dir="ltr">pubsub.topics.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">pubsub.topics.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">pubsub.topics.listTagBindings</code></p>
<p><code translate="no" dir="ltr">recaptchaenterprise.keys.createTagBinding</code></p>
<p><code translate="no" dir="ltr">recaptchaenterprise.keys.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">recaptchaenterprise.keys.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">recaptchaenterprise.keys.listTagBindings</code></p>
<p><code translate="no" dir="ltr">redis.clusters.createTagBinding</code></p>
<p><code translate="no" dir="ltr">redis.clusters.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">redis.clusters.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">redis.clusters.listTagBindings</code></p>
<p><code translate="no" dir="ltr">redis.instances.createTagBinding</code></p>
<p><code translate="no" dir="ltr">redis.instances.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">redis.instances.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">redis.instances.listTagBindings</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">resourcemanager.hierarchyNodes.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">resourcemanager.hierarchyNodes.createTagBinding</code></li>
<li><code translate="no" dir="ltr">resourcemanager.hierarchyNodes.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">resourcemanager.hierarchyNodes.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">resourcemanager.hierarchyNodes.listTagBindings</code></li>
</ul>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.tagKeys.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.tagKeys.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">resourcemanager.tagValueBindings.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">resourcemanager.tagValueBindings.create</code></li>
<li><code translate="no" dir="ltr">resourcemanager.tagValueBindings.delete</code></li>
</ul>
<p><code translate="no" dir="ltr">resourcemanager.tagValues.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.tagValues.list</code></p>
<p><code translate="no" dir="ltr">run.jobs.createTagBinding</code></p>
<p><code translate="no" dir="ltr">run.jobs.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">run.jobs.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">run.jobs.listTagBindings</code></p>
<p><code translate="no" dir="ltr">run.services.createTagBinding</code></p>
<p><code translate="no" dir="ltr">run.services.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">run.services.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">run.services.listTagBindings</code></p>
<p><code translate="no" dir="ltr">secretmanager.secrets.createTagBinding</code></p>
<p><code translate="no" dir="ltr">secretmanager.secrets.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">secretmanager.secrets.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">secretmanager.secrets.listTagBindings</code></p>
<p><code translate="no" dir="ltr">spanner.instances.createTagBinding</code></p>
<p><code translate="no" dir="ltr">spanner.instances.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">spanner.instances.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">spanner.instances.listTagBindings</code></p>
<p><code translate="no" dir="ltr">storage.buckets.createTagBinding</code></p>
<p><code translate="no" dir="ltr">storage.buckets.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">storage.buckets.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">storage.buckets.listTagBindings</code></p>
<p><code translate="no" dir="ltr">tpu.nodes.createTagBinding</code></p>
<p><code translate="no" dir="ltr">tpu.nodes.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">tpu.nodes.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">tpu.nodes.listTagBindings</code></p>
<p><code translate="no" dir="ltr">transcoder.jobTemplates.createTagBinding</code></p>
<p><code translate="no" dir="ltr">transcoder.jobTemplates.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">transcoder.jobTemplates.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">transcoder.jobTemplates.listTagBindings</code></p>
<p><code translate="no" dir="ltr">transcoder.jobs.createTagBinding</code></p>
<p><code translate="no" dir="ltr">transcoder.jobs.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">transcoder.jobs.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">transcoder.jobs.listTagBindings</code></p>
<p><code translate="no" dir="ltr">videostitcher.cdnKeys.createTagBinding</code></p>
<p><code translate="no" dir="ltr">videostitcher.cdnKeys.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">videostitcher.cdnKeys.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">videostitcher.cdnKeys.listTagBindings</code></p>
<p><code translate="no" dir="ltr">videostitcher.liveConfigs.createTagBinding</code></p>
<p><code translate="no" dir="ltr">videostitcher.liveConfigs.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">videostitcher.liveConfigs.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">videostitcher.liveConfigs.listTagBindings</code></p>
<p><code translate="no" dir="ltr">videostitcher.slates.createTagBinding</code></p>
<p><code translate="no" dir="ltr">videostitcher.slates.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">videostitcher.slates.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">videostitcher.slates.listTagBindings</code></p>
<p><code translate="no" dir="ltr">videostitcher.vodConfigs.createTagBinding</code></p>
<p><code translate="no" dir="ltr">videostitcher.vodConfigs.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">videostitcher.vodConfigs.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">videostitcher.vodConfigs.listTagBindings</code></p>
<p><code translate="no" dir="ltr">vmmigration.groups.createTagBinding</code></p>
<p><code translate="no" dir="ltr">vmmigration.groups.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">vmmigration.groups.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">vmmigration.groups.listTagBindings</code></p>
<p><code translate="no" dir="ltr">vmmigration.sources.createTagBinding</code></p>
<p><code translate="no" dir="ltr">vmmigration.sources.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">vmmigration.sources.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">vmmigration.sources.listTagBindings</code></p>
<p><code translate="no" dir="ltr">vmwareengine.networkPeerings.createTagBinding</code></p>
<p><code translate="no" dir="ltr">vmwareengine.networkPeerings.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">vmwareengine.networkPeerings.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">vmwareengine.networkPeerings.listTagBindings</code></p>
<p><code translate="no" dir="ltr">vmwareengine.networkPolicies.createTagBinding</code></p>
<p><code translate="no" dir="ltr">vmwareengine.networkPolicies.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">vmwareengine.networkPolicies.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">vmwareengine.networkPolicies.listTagBindings</code></p>
<p><code translate="no" dir="ltr">vmwareengine.privateClouds.createTagBinding</code></p>
<p><code translate="no" dir="ltr">vmwareengine.privateClouds.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">vmwareengine.privateClouds.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">vmwareengine.privateClouds.listTagBindings</code></p>
<p><code translate="no" dir="ltr">vmwareengine.privateConnections.createTagBinding</code></p>
<p><code translate="no" dir="ltr">vmwareengine.privateConnections.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">vmwareengine.privateConnections.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">vmwareengine.privateConnections.listTagBindings</code></p>
<p><code translate="no" dir="ltr">vmwareengine.vmwareEngineNetworks.createTagBinding</code></p>
<p><code translate="no" dir="ltr">vmwareengine.vmwareEngineNetworks.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">vmwareengine.vmwareEngineNetworks.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">vmwareengine.vmwareEngineNetworks.listTagBindings</code></p>
<p><code translate="no" dir="ltr">workflows.workflows.createTagBinding</code></p>
<p><code translate="no" dir="ltr">workflows.workflows.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">workflows.workflows.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">workflows.workflows.listTagBindings</code></p>
<p><code translate="no" dir="ltr">workstations.workstationClusters.createTagBinding</code></p>
<p><code translate="no" dir="ltr">workstations.workstationClusters.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">workstations.workstationClusters.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">workstations.workstationClusters.listTagBindings</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="resourcemanager.tagViewer" class="role-title add-link" data-text="Tag Viewer " tabindex="-1">Tag Viewer</h4>
<p>(<code translate="no" dir="ltr">roles/resourcemanager.tagViewer</code>)</p>
<span class="role-description"> </span>
<p>Access to list Tags and their associations with resources</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">alloydb.backups.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">alloydb.backups.listTagBindings</code></p>
<p><code translate="no" dir="ltr">alloydb.clusters.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">alloydb.clusters.listTagBindings</code></p>
<p><code translate="no" dir="ltr">apigateway.apis.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">apigateway.apis.listTagBindings</code></p>
<p><code translate="no" dir="ltr">apigateway.gateways.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">apigateway.gateways.listTagBindings</code></p>
<p><code translate="no" dir="ltr">apihub.apis.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">apihub.apis.listTagBindings</code></p>
<p><code translate="no" dir="ltr">apihub.deployments.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">apihub.deployments.listTagBindings</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.listTagBindings</code></p>
<p><code translate="no" dir="ltr">backupdr.backupVaults.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">backupdr.backupVaults.listTagBindings</code></p>
<p><code translate="no" dir="ltr">backupdr.managementServers.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">backupdr.managementServers.listTagBindings</code></p>
<p><code translate="no" dir="ltr">beyondcorp.appConnections.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">beyondcorp.appConnections.listTagBindings</code></p>
<p><code translate="no" dir="ltr">beyondcorp.appConnectors.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">beyondcorp.appConnectors.listTagBindings</code></p>
<p><code translate="no" dir="ltr">beyondcorp.appGateways.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">beyondcorp.appGateways.listTagBindings</code></p>
<p><code translate="no" dir="ltr">bigquery.datasets.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">bigquery.datasets.listTagBindings</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.listTagBindings</code></p>
<p><code translate="no" dir="ltr">bigtable.authorizedViews.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">bigtable.authorizedViews.listTagBindings</code></p>
<p><code translate="no" dir="ltr">bigtable.instances.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">bigtable.instances.listTagBindings</code></p>
<p><code translate="no" dir="ltr">certificatemanager.certissuanceconfigs.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">certificatemanager.certissuanceconfigs.listTagBindings</code></p>
<p><code translate="no" dir="ltr">certificatemanager.certmapentries.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">certificatemanager.certmapentries.listTagBindings</code></p>
<p><code translate="no" dir="ltr">certificatemanager.certmaps.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">certificatemanager.certmaps.listTagBindings</code></p>
<p><code translate="no" dir="ltr">certificatemanager.certs.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">certificatemanager.certs.listTagBindings</code></p>
<p><code translate="no" dir="ltr">certificatemanager.dnsauthorizations.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">certificatemanager.dnsauthorizations.listTagBindings</code></p>
<p><code translate="no" dir="ltr">certificatemanager.trustconfigs.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">certificatemanager.trustconfigs.listTagBindings</code></p>
<p><code translate="no" dir="ltr">clouddeploy.deliveryPipelines.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">clouddeploy.deliveryPipelines.listTagBindings</code></p>
<p><code translate="no" dir="ltr">clouddeploy.targets.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">clouddeploy.targets.listTagBindings</code></p>
<p><code translate="no" dir="ltr">cloudkms.keyRings.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">cloudkms.keyRings.listTagBindings</code></p>
<p><code translate="no" dir="ltr">cloudsql.instances.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">cloudsql.instances.listTagBindings</code></p>
<p><code translate="no" dir="ltr">composer.environments.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">composer.environments.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.addresses.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.addresses.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.backendBuckets.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.backendBuckets.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.backendServices.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.backendServices.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.commitments.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.commitments.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.disks.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.disks.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.externalVpnGateways.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.externalVpnGateways.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.firewallPolicies.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.firewallPolicies.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.firewalls.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.firewalls.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.forwardingRules.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.forwardingRules.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.futureReservations.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.futureReservations.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.globalAddresses.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.globalAddresses.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.globalForwardingRules.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.globalForwardingRules.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.globalNetworkEndpointGroups.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.globalNetworkEndpointGroups.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.healthChecks.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.healthChecks.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.httpHealthChecks.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.httpHealthChecks.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.httpsHealthChecks.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.httpsHealthChecks.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.images.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.images.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.instanceGroupManagers.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.instanceGroupManagers.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.instanceGroups.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.instanceGroups.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.instances.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.instances.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.instantSnapshots.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.instantSnapshots.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.interconnectAttachments.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.interconnectAttachments.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.interconnects.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.interconnects.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.licenses.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.licenses.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.machineImages.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.machineImages.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.networkAttachments.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.networkAttachments.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.networkEdgeSecurityServices.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.networkEdgeSecurityServices.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.networkEndpointGroups.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.networkEndpointGroups.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.networks.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.networks.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.packetMirrorings.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.packetMirrorings.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.publicDelegatedPrefixes.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.publicDelegatedPrefixes.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.regionBackendBuckets.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.regionBackendBuckets.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.regionBackendServices.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.regionBackendServices.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.regionFirewallPolicies.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.regionFirewallPolicies.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.regionHealthChecks.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.regionHealthChecks.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.regionNetworkEndpointGroups.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.regionNetworkEndpointGroups.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.regionSecurityPolicies.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.regionSecurityPolicies.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.regionSslCertificates.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.regionSslCertificates.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.regionSslPolicies.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.regionSslPolicies.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.regionTargetHttpProxies.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.regionTargetHttpProxies.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.regionTargetHttpsProxies.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.regionTargetHttpsProxies.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.regionTargetTcpProxies.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.regionTargetTcpProxies.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.regionUrlMaps.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.regionUrlMaps.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.reservations.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.reservations.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.routers.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.routers.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.routes.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.routes.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.securityPolicies.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.securityPolicies.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.serviceAttachments.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.serviceAttachments.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.snapshots.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.snapshots.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.sslCertificates.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.sslCertificates.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.sslPolicies.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.sslPolicies.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.storagePools.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.storagePools.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.subnetworks.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.subnetworks.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.targetGrpcProxies.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.targetGrpcProxies.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.targetHttpProxies.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.targetHttpProxies.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.targetHttpsProxies.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.targetHttpsProxies.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.targetInstances.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.targetInstances.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.targetPools.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.targetPools.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.targetSslProxies.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.targetSslProxies.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.targetTcpProxies.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.targetTcpProxies.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.targetVpnGateways.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.targetVpnGateways.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.urlMaps.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.urlMaps.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.vpnGateways.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.vpnGateways.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.vpnTunnels.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.vpnTunnels.listTagBindings</code></p>
<p><code translate="no" dir="ltr">config.deploymentgroups.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">config.deploymentgroups.listTagBindings</code></p>
<p><code translate="no" dir="ltr">config.deployments.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">config.deployments.listTagBindings</code></p>
<p><code translate="no" dir="ltr">config.previews.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">config.previews.listTagBindings</code></p>
<p><code translate="no" dir="ltr">container.clusters.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">container.clusters.listTagBindings</code></p>
<p><code translate="no" dir="ltr">dataflow.jobs.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">dataflow.jobs.listTagBindings</code></p>
<p><code translate="no" dir="ltr">dataflow.snapshots.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">dataflow.snapshots.listTagBindings</code></p>
<p><code translate="no" dir="ltr">dataform.repositories.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">dataform.repositories.listTagBindings</code></p>
<p><code translate="no" dir="ltr">datafusion.instances.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">datafusion.instances.listTagBindings</code></p>
<p><code translate="no" dir="ltr">datamigration.connectionprofiles.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">datamigration.connectionprofiles.listTagBindings</code></p>
<p><code translate="no" dir="ltr">datamigration.migrationjobs.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">datamigration.migrationjobs.listTagBindings</code></p>
<p><code translate="no" dir="ltr">datamigration.privateconnections.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">datamigration.privateconnections.listTagBindings</code></p>
<p><code translate="no" dir="ltr">dataplex.entryGroups.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">dataplex.entryGroups.listTagBindings</code></p>
<p><code translate="no" dir="ltr">dataplex.entryTypes.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">dataplex.entryTypes.listTagBindings</code></p>
<p><code translate="no" dir="ltr">dataplex.governanceRules.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">dataplex.governanceRules.listTagBindings</code></p>
<p><code translate="no" dir="ltr">datastore.databases.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">datastore.databases.listTagBindings</code></p>
<p><code translate="no" dir="ltr">datastream.connectionProfiles.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">datastream.connectionProfiles.listTagBindings</code></p>
<p><code translate="no" dir="ltr">datastream.privateConnections.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">datastream.privateConnections.listTagBindings</code></p>
<p><code translate="no" dir="ltr">datastream.streams.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">datastream.streams.listTagBindings</code></p>
<p><code translate="no" dir="ltr">dns.policies.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">dns.policies.listTagBindings</code></p>
<p><code translate="no" dir="ltr">domains.registrations.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">domains.registrations.listTagBindings</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.listTagBindings</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.listTagBindings</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.listTagBindings</code></p>
<p><code translate="no" dir="ltr">file.backups.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">file.backups.listTagBindings</code></p>
<p><code translate="no" dir="ltr">file.instances.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">file.instances.listTagBindings</code></p>
<p><code translate="no" dir="ltr">file.snapshots.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">file.snapshots.listTagBindings</code></p>
<p><code translate="no" dir="ltr">financialservices.v1instances.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">financialservices.v1instances.listTagBindings</code></p>
<p><code translate="no" dir="ltr">gkemulticloud.attachedClusters.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">gkemulticloud.attachedClusters.listTagBindings</code></p>
<p><code translate="no" dir="ltr">gkeonprem.bareMetalAdminClusters.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">gkeonprem.bareMetalAdminClusters.listTagBindings</code></p>
<p><code translate="no" dir="ltr">gkeonprem.bareMetalClusters.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">gkeonprem.bareMetalClusters.listTagBindings</code></p>
<p><code translate="no" dir="ltr">gkeonprem.vmwareAdminClusters.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">gkeonprem.vmwareAdminClusters.listTagBindings</code></p>
<p><code translate="no" dir="ltr">gkeonprem.vmwareClusters.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">gkeonprem.vmwareClusters.listTagBindings</code></p>
<p><code translate="no" dir="ltr">iam.roles.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">iam.roles.listTagBindings</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.listTagBindings</code></p>
<p><code translate="no" dir="ltr">krmapihosting.krmApiHosts.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">krmapihosting.krmApiHosts.listTagBindings</code></p>
<p><code translate="no" dir="ltr">livestream.channels.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">livestream.channels.listTagBindings</code></p>
<p><code translate="no" dir="ltr">livestream.inputs.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">livestream.inputs.listTagBindings</code></p>
<p><code translate="no" dir="ltr">livestream.pools.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">livestream.pools.listTagBindings</code></p>
<p><code translate="no" dir="ltr">logging.buckets.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">logging.buckets.listTagBindings</code></p>
<p><code translate="no" dir="ltr">looker.instances.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">looker.instances.listTagBindings</code></p>
<p><code translate="no" dir="ltr">managedidentities.domains.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">managedidentities.domains.listTagBindings</code></p>
<p><code translate="no" dir="ltr">memcache.instances.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">memcache.instances.listTagBindings</code></p>
<p><code translate="no" dir="ltr">metastore.federations.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">metastore.federations.listTagBindings</code></p>
<p><code translate="no" dir="ltr">metastore.services.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">metastore.services.listTagBindings</code></p>
<p><code translate="no" dir="ltr">monitoring.alertPolicies.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">monitoring.alertPolicies.listTagBindings</code></p>
<p><code translate="no" dir="ltr">monitoring.dashboards.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">monitoring.dashboards.listTagBindings</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.hubs.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.hubs.listTagBindings</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.spokes.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.spokes.listTagBindings</code></p>
<p><code translate="no" dir="ltr">networkmanagement.connectivitytests.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">networkmanagement.connectivitytests.listTagBindings</code></p>
<p><code translate="no" dir="ltr">networksecurity.authorizationPolicies.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">networksecurity.authorizationPolicies.listTagBindings</code></p>
<p><code translate="no" dir="ltr">networksecurity.clientTlsPolicies.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">networksecurity.clientTlsPolicies.listTagBindings</code></p>
<p><code translate="no" dir="ltr">networksecurity.serverTlsPolicies.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">networksecurity.serverTlsPolicies.listTagBindings</code></p>
<p><code translate="no" dir="ltr">networkservices.endpointConfigSelectors.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">networkservices.endpointConfigSelectors.listTagBindings</code></p>
<p><code translate="no" dir="ltr">networkservices.gateways.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">networkservices.gateways.listTagBindings</code></p>
<p><code translate="no" dir="ltr">networkservices.httpFilters.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">networkservices.httpFilters.listTagBindings</code></p>
<p><code translate="no" dir="ltr">networkservices.meshes.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">networkservices.meshes.listTagBindings</code></p>
<p><code translate="no" dir="ltr">notebooks.instances.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">notebooks.instances.listTagBindings</code></p>
<p><code translate="no" dir="ltr">parametermanager.parameters.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">parametermanager.parameters.listTagBindings</code></p>
<p><code translate="no" dir="ltr">privateca.caPools.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">privateca.caPools.listTagBindings</code></p>
<p><code translate="no" dir="ltr">privateca.certificateTemplates.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">privateca.certificateTemplates.listTagBindings</code></p>
<p><code translate="no" dir="ltr">pubsub.snapshots.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">pubsub.snapshots.listTagBindings</code></p>
<p><code translate="no" dir="ltr">pubsub.subscriptions.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">pubsub.subscriptions.listTagBindings</code></p>
<p><code translate="no" dir="ltr">pubsub.topics.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">pubsub.topics.listTagBindings</code></p>
<p><code translate="no" dir="ltr">recaptchaenterprise.keys.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">recaptchaenterprise.keys.listTagBindings</code></p>
<p><code translate="no" dir="ltr">redis.clusters.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">redis.clusters.listTagBindings</code></p>
<p><code translate="no" dir="ltr">redis.instances.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">redis.instances.listTagBindings</code></p>
<p><code translate="no" dir="ltr">resourcemanager.hierarchyNodes.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">resourcemanager.hierarchyNodes.listTagBindings</code></p>
<p><code translate="no" dir="ltr">resourcemanager.tagHolds.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.tagKeys.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.tagKeys.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.tagValues.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.tagValues.list</code></p>
<p><code translate="no" dir="ltr">run.jobs.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">run.jobs.listTagBindings</code></p>
<p><code translate="no" dir="ltr">run.services.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">run.services.listTagBindings</code></p>
<p><code translate="no" dir="ltr">secretmanager.secrets.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">secretmanager.secrets.listTagBindings</code></p>
<p><code translate="no" dir="ltr">spanner.instances.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">spanner.instances.listTagBindings</code></p>
<p><code translate="no" dir="ltr">storage.buckets.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">storage.buckets.listTagBindings</code></p>
<p><code translate="no" dir="ltr">tpu.nodes.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">tpu.nodes.listTagBindings</code></p>
<p><code translate="no" dir="ltr">transcoder.jobTemplates.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">transcoder.jobTemplates.listTagBindings</code></p>
<p><code translate="no" dir="ltr">transcoder.jobs.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">transcoder.jobs.listTagBindings</code></p>
<p><code translate="no" dir="ltr">videostitcher.cdnKeys.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">videostitcher.cdnKeys.listTagBindings</code></p>
<p><code translate="no" dir="ltr">videostitcher.liveConfigs.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">videostitcher.liveConfigs.listTagBindings</code></p>
<p><code translate="no" dir="ltr">videostitcher.slates.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">videostitcher.slates.listTagBindings</code></p>
<p><code translate="no" dir="ltr">videostitcher.vodConfigs.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">videostitcher.vodConfigs.listTagBindings</code></p>
<p><code translate="no" dir="ltr">vmmigration.groups.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">vmmigration.groups.listTagBindings</code></p>
<p><code translate="no" dir="ltr">vmmigration.sources.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">vmmigration.sources.listTagBindings</code></p>
<p><code translate="no" dir="ltr">vmwareengine.networkPeerings.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">vmwareengine.networkPeerings.listTagBindings</code></p>
<p><code translate="no" dir="ltr">vmwareengine.networkPolicies.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">vmwareengine.networkPolicies.listTagBindings</code></p>
<p><code translate="no" dir="ltr">vmwareengine.privateClouds.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">vmwareengine.privateClouds.listTagBindings</code></p>
<p><code translate="no" dir="ltr">vmwareengine.privateConnections.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">vmwareengine.privateConnections.listTagBindings</code></p>
<p><code translate="no" dir="ltr">vmwareengine.vmwareEngineNetworks.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">vmwareengine.vmwareEngineNetworks.listTagBindings</code></p>
<p><code translate="no" dir="ltr">workflows.workflows.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">workflows.workflows.listTagBindings</code></p>
<p><code translate="no" dir="ltr">workstations.workstationClusters.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">workstations.workstationClusters.listTagBindings</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="resourcemanager.viewer" class="role-title add-link" data-text="Resource Manager Viewer " tabindex="-1">Resource Manager Viewer</h4>
<p>(<code translate="no" dir="ltr">roles/resourcemanager.viewer</code>)</p>
<span class="role-description"> </span>
<p>Access to view Resource Manager resources</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">resourcemanager.boundaries.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.boundaries.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.boundaryConfigs.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.capabilities.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.capabilityConfigs.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.capabilityConfigs.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.folders.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.folders.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.organizations.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.tagHolds.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.tagKeys.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.tagKeys.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.tagValues.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.tagValues.list</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="resourcemanager.folderCreator" class="role-title add-link" data-text="Folder Creator " tabindex="-1">Folder Creator</h4>
<p>(<code translate="no" dir="ltr">roles/resourcemanager.folderCreator</code>)</p>
<span class="role-description custom"> </span>
<p>Provides permissions needed to browse the hierarchy and create folders.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Folder</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">essentialcontacts.contacts.get</code></p>
<p><code translate="no" dir="ltr">essentialcontacts.contacts.list</code></p>
<p><code translate="no" dir="ltr">orgpolicy.constraints.list</code></p>
<p><code translate="no" dir="ltr">orgpolicy.policies.list</code></p>
<p><code translate="no" dir="ltr">orgpolicy.policy.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.capabilities.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.folders.create</code></p>
<p><code translate="no" dir="ltr">resourcemanager.folders.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.folders.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="resourcemanager.folderEditor" class="role-title add-link" data-text="Folder Editor " tabindex="-1">Folder Editor</h4>
<p>(<code translate="no" dir="ltr">roles/resourcemanager.folderEditor</code>)</p>
<span class="role-description custom"> </span>
<p>Provides permission to modify folders as well as to view a folder's allow policy.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Folder</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">essentialcontacts.contacts.get</code></p>
<p><code translate="no" dir="ltr">essentialcontacts.contacts.list</code></p>
<p><code translate="no" dir="ltr">orgpolicy.constraints.list</code></p>
<p><code translate="no" dir="ltr">orgpolicy.policies.list</code></p>
<p><code translate="no" dir="ltr">orgpolicy.policy.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">resourcemanager.capabilities.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">resourcemanager.capabilities.get</code></li>
<li><code translate="no" dir="ltr">resourcemanager.capabilities.update</code></li>
</ul>
<p><code translate="no" dir="ltr">resourcemanager.folders.delete</code></p>
<p><code translate="no" dir="ltr">resourcemanager.folders.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.folders.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">resourcemanager.folders.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.folders.searchPolicyBindings</code></p>
<p><code translate="no" dir="ltr">resourcemanager.folders.undelete</code></p>
<p><code translate="no" dir="ltr">resourcemanager.folders.update</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="resourcemanager.folderIamAdmin" class="role-title add-link" data-text="Folder IAM Admin " tabindex="-1">Folder IAM Admin</h4>
<p>(<code translate="no" dir="ltr">roles/resourcemanager.folderIamAdmin</code>)</p>
<span class="role-description custom"> </span>
<p>Provides permissions to administer allow policies on folders.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Folder</li>
</ul></td>
<td class="role-permissions"><p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iam.policybindings.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iam.policybindings.get</code></li>
<li><code translate="no" dir="ltr">iam.policybindings.list</code></li>
</ul>
<p><code translate="no" dir="ltr">resourcemanager.folders.createPolicyBinding</code></p>
<p><code translate="no" dir="ltr">resourcemanager.folders.deletePolicyBinding</code></p>
<p><code translate="no" dir="ltr">resourcemanager.folders.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.folders.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">resourcemanager.folders.searchPolicyBindings</code></p>
<p><code translate="no" dir="ltr">resourcemanager.folders.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">resourcemanager.folders.updatePolicyBinding</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="resourcemanager.folderMover" class="role-title add-link" data-text="Folder Mover " tabindex="-1">Folder Mover</h4>
<p>(<code translate="no" dir="ltr">roles/resourcemanager.folderMover</code>)</p>
<span class="role-description custom"> </span>
<p>Provides permission to move projects and folders into and out of a parent organization or folder.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Folder</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">resourcemanager.folders.move</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.move</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="resourcemanager.folderViewer" class="role-title add-link" data-text="Folder Viewer " tabindex="-1">Folder Viewer</h4>
<p>(<code translate="no" dir="ltr">roles/resourcemanager.folderViewer</code>)</p>
<span class="role-description custom"> </span>
<p>Provides permission to get a folder and list the folders and projects below a resource.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Folder</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">essentialcontacts.contacts.get</code></p>
<p><code translate="no" dir="ltr">essentialcontacts.contacts.list</code></p>
<p><code translate="no" dir="ltr">orgpolicy.constraints.list</code></p>
<p><code translate="no" dir="ltr">orgpolicy.policies.list</code></p>
<p><code translate="no" dir="ltr">orgpolicy.policy.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.capabilities.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.folders.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.folders.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="resourcemanager.lienModifier" class="role-title add-link" data-text="Project Lien Modifier " tabindex="-1">Project Lien Modifier</h4>
<p>(<code translate="no" dir="ltr">roles/resourcemanager.lienModifier</code>)</p>
<span class="role-description custom"> </span>
<p>Provides access to modify Liens on projects.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Project</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">resourcemanager.projects.updateLiens</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="resourcemanager.organizationViewer" class="role-title add-link" data-text="Organization Viewer " tabindex="-1">Organization Viewer</h4>
<p>(<code translate="no" dir="ltr">roles/resourcemanager.organizationViewer</code>)</p>
<span class="role-description custom"> </span>
<p>Provides access to view an organization.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Organization</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">resourcemanager.organizations.get</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="resourcemanager.projectCreator" class="role-title add-link" data-text="Project Creator " tabindex="-1">Project Creator</h4>
<p>(<code translate="no" dir="ltr">roles/resourcemanager.projectCreator</code>)</p>
<span class="role-description custom"> </span>
<p>Provides access to create new projects. Once a user creates a project, they're automatically granted the owner role for that project.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Folder</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">resourcemanager.organizations.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.create</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="resourcemanager.projectDeleter" class="role-title add-link" data-text="Project Deleter " tabindex="-1">Project Deleter</h4>
<p>(<code translate="no" dir="ltr">roles/resourcemanager.projectDeleter</code>)</p>
<span class="role-description custom"> </span>
<p>Provides access to delete Google Cloud projects.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Project</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">resourcemanager.projects.delete</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="resourcemanager.tagHoldAdmin" class="role-title add-link" data-text="Tag Hold Administrator " tabindex="-1">Tag Hold Administrator</h4>
<p>(<code translate="no" dir="ltr">roles/resourcemanager.tagHoldAdmin</code>)</p>
<span class="role-description"> </span>
<p>Access to create, delete and list TagHolds under a TagValue</p></td>
<td class="role-permissions"><p><span class="iamperm-wildcard"><code translate="no" dir="ltr">resourcemanager.tagHolds.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">resourcemanager.tagHolds.create</code></li>
<li><code translate="no" dir="ltr">resourcemanager.tagHolds.delete</code></li>
<li><code translate="no" dir="ltr">resourcemanager.tagHolds.list</code></li>
</ul></td>
</tr>
</tbody>
</table>

## Resource Manager permissions

<div results-count-container="">

</div>

<table class="permissions-table fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="45%">Permission</th>
<th>Included in roles</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td><h4 id="resourcemanager.boundaries.associateToCapabilityConfig" class="permission-name add-link" data-text="resourcemanager.boundaries.associateToCapabilityConfig" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.boundaries.associateToCapabilityConfig</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.editor">Resource Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.editor</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="resourcemanager.boundaries.create" class="permission-name add-link" data-text="resourcemanager.boundaries.create" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.boundaries.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.editor">Resource Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.editor</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="resourcemanager.boundaries.delete" class="permission-name add-link" data-text="resourcemanager.boundaries.delete" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.boundaries.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.editor">Resource Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.editor</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="resourcemanager.boundaries.get" class="permission-name add-link" data-text="resourcemanager.boundaries.get" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.boundaries.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.editor">Resource Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.viewer">Resource Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="resourcemanager.boundaries.list" class="permission-name add-link" data-text="resourcemanager.boundaries.list" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.boundaries.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.editor">Resource Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.viewer">Resource Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="resourcemanager.boundaries.update" class="permission-name add-link" data-text="resourcemanager.boundaries.update" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.boundaries.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.editor">Resource Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.editor</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="resourcemanager.boundaryConfigs.get" class="permission-name add-link" data-text="resourcemanager.boundaryConfigs.get" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.boundaryConfigs.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.editor">Resource Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.viewer">Resource Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="resourcemanager.boundaryConfigs.update" class="permission-name add-link" data-text="resourcemanager.boundaryConfigs.update" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.boundaryConfigs.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.editor">Resource Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.editor</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="resourcemanager.capabilities.get" class="permission-name add-link" data-text="resourcemanager.capabilities.get" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.capabilities.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.editor">Resource Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderAdmin">Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.organizationAdmin">Organization Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.organizationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.viewer">Resource Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderCreator">Folder Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderCreator</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderEditor">Folder Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderViewer">Folder Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderViewer</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="resourcemanager.capabilities.update" class="permission-name add-link" data-text="resourcemanager.capabilities.update" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.capabilities.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.editor">Resource Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderAdmin">Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.organizationAdmin">Organization Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.organizationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderEditor">Folder Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderEditor</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="resourcemanager.capabilityConfigs.create" class="permission-name add-link" data-text="resourcemanager.capabilityConfigs.create" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.capabilityConfigs.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.editor">Resource Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.editor</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="resourcemanager.capabilityConfigs.delete" class="permission-name add-link" data-text="resourcemanager.capabilityConfigs.delete" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.capabilityConfigs.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.editor">Resource Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.editor</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="resourcemanager.capabilityConfigs.get" class="permission-name add-link" data-text="resourcemanager.capabilityConfigs.get" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.capabilityConfigs.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.editor">Resource Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.viewer">Resource Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="resourcemanager.capabilityConfigs.list" class="permission-name add-link" data-text="resourcemanager.capabilityConfigs.list" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.capabilityConfigs.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.editor">Resource Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.viewer">Resource Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="resourcemanager.capabilityConfigs.update" class="permission-name add-link" data-text="resourcemanager.capabilityConfigs.update" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.capabilityConfigs.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.editor">Resource Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.editor</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="resourcemanager.folders.create" class="permission-name add-link" data-text="resourcemanager.folders.create" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.folders.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredworkloads#assuredworkloads.admin">Assured Workloads Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredworkloads.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredworkloads#assuredworkloads.editor">Assured Workloads Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredworkloads.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.editor">Resource Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderAdmin">Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderCreator">Folder Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderCreator</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="resourcemanager.folders.createPolicyBinding" class="permission-name add-link" data-text="resourcemanager.folders.createPolicyBinding" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.folders.createPolicyBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderAdmin">Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.organizationAdmin">Organization Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.organizationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderIamAdmin">Folder IAM Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderIamAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="resourcemanager.folders.delete" class="permission-name add-link" data-text="resourcemanager.folders.delete" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.folders.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.editor">Resource Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderAdmin">Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderEditor">Folder Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderEditor</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="resourcemanager.folders.deletePolicyBinding" class="permission-name add-link" data-text="resourcemanager.folders.deletePolicyBinding" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.folders.deletePolicyBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderAdmin">Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.organizationAdmin">Organization Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.organizationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderIamAdmin">Folder IAM Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderIamAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="resourcemanager.folders.get" class="permission-name add-link" data-text="resourcemanager.folders.get" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.folders.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredworkloads#assuredworkloads.admin">Assured Workloads Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredworkloads.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredworkloads#assuredworkloads.editor">Assured Workloads Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredworkloads.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredworkloads#assuredworkloads.viewer">Assured Workloads Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredworkloads.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.admin">Audit Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/capacityplanner#capacityplanner.admin">Capacityplanner Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/capacityplanner.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/capacityplanner#capacityplanner.viewer">Capacity Planner Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/capacityplanner.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudprivatecatalog#cloudprivatecatalogproducer.admin">Catalog Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudprivatecatalogproducer.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.editor">Resource Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderAdmin">Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.organizationAdmin">Organization Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.organizationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.viewer">Resource Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.admin">Service Management Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apphub#apphub.appManagementViewer">App Management Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apphub.appManagementViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredworkloads#assuredworkloads.reader">Assured Workloads Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredworkloads.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.auditor">Audit Manager Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.auditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/browser#browser">Browser</a> (<code class="role-name" translate="no" dir="ltr">roles/browser</code>)</p>
<p><a href="/iam/docs/roles-permissions/capacityplanner#capacityplanner.planner">Capacity Planner</a> (<code class="role-name" translate="no" dir="ltr">roles/capacityplanner.planner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudprivatecatalog#cloudprivatecatalogproducer.manager">Catalog Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudprivatecatalogproducer.manager</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudprivatecatalog#cloudprivatecatalogproducer.orgAdmin">Catalog Org Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudprivatecatalogproducer.orgAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.folderVmExtensionPolicyAdmin">Folder level Compute VM extension policies admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.folderVmExtensionPolicyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.folderVmExtensionPolicyViewer">Folder level Compute VM extension policies viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.folderVmExtensionPolicyViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/modelarmor#modelarmor.floorSettingsAdmin">Model Armor Floor Setting Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/modelarmor.floorSettingsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/modelarmor#modelarmor.floorSettingsViewer">Model Armor Floor Setting Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/modelarmor.floorSettingsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderCreator">Folder Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderCreator</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderEditor">Folder Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderIamAdmin">Folder IAM Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderIamAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderViewer">Folder Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminEditor">Security Center Admin Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminViewer">Security Center Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.assetsViewer">Security Center Assets Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.assetsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.bigQueryExportsEditor">Security Center BigQuery Exports Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.bigQueryExportsEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.bigQueryExportsViewer">Security Center BigQuery Exports Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.bigQueryExportsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.findingsEditor">Security Center Findings Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.findingsEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.findingsViewer">Security Center Findings Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.findingsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.settingsAdmin">Security Center Settings Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.settingsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.settingsEditor">Security Center Settings Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.settingsEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.settingsViewer">Security Center Settings Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.settingsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.serviceAgent">Audit Manager Auditing Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.serviceAgent">Cloud Security Compliance Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/privilegedaccessmanager#privilegedaccessmanager.folderServiceAgent">Privileged Access Manager Folder Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/privilegedaccessmanager.folderServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/privilegedaccessmanager#privilegedaccessmanager.serviceAgent">Privileged Access Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/privilegedaccessmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/riskmanager#riskmanager.serviceAgent">Risk Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/riskmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.automationServiceAgent">Security Center Automation Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.automationServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.controlServiceAgent">Security Center Control Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.controlServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.serviceAgent">Security Center Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="resourcemanager.folders.getIamPolicy" class="permission-name add-link" data-text="resourcemanager.folders.getIamPolicy" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.folders.getIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderAdmin">Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.organizationAdmin">Organization Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.organizationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderEditor">Folder Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderIamAdmin">Folder IAM Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderIamAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.serviceAgent">Audit Manager Auditing Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.serviceAgent">Cloud Security Compliance Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dspm#dspm.serviceAgent">DSPM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/privilegedaccessmanager#privilegedaccessmanager.folderServiceAgent">Privileged Access Manager Folder Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/privilegedaccessmanager.folderServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/privilegedaccessmanager#privilegedaccessmanager.serviceAgent">Privileged Access Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/privilegedaccessmanager.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="resourcemanager.folders.list" class="permission-name add-link" data-text="resourcemanager.folders.list" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.folders.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredworkloads#assuredworkloads.admin">Assured Workloads Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredworkloads.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredworkloads#assuredworkloads.editor">Assured Workloads Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredworkloads.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredworkloads#assuredworkloads.viewer">Assured Workloads Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredworkloads.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.admin">Audit Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudprivatecatalog#cloudprivatecatalogproducer.admin">Catalog Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudprivatecatalogproducer.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.editor">Resource Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderAdmin">Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.organizationAdmin">Organization Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.organizationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.viewer">Resource Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.admin">Service Management Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apphub#apphub.appManagementViewer">App Management Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apphub.appManagementViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredworkloads#assuredworkloads.reader">Assured Workloads Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredworkloads.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.auditor">Audit Manager Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.auditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/browser#browser">Browser</a> (<code class="role-name" translate="no" dir="ltr">roles/browser</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudprivatecatalog#cloudprivatecatalogproducer.manager">Catalog Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudprivatecatalogproducer.manager</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudprivatecatalog#cloudprivatecatalogproducer.orgAdmin">Catalog Org Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudprivatecatalogproducer.orgAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.folderVmExtensionPolicyAdmin">Folder level Compute VM extension policies admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.folderVmExtensionPolicyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.folderVmExtensionPolicyViewer">Folder level Compute VM extension policies viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.folderVmExtensionPolicyViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/modelarmor#modelarmor.floorSettingsAdmin">Model Armor Floor Setting Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/modelarmor.floorSettingsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/modelarmor#modelarmor.floorSettingsViewer">Model Armor Floor Setting Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/modelarmor.floorSettingsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderCreator">Folder Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderCreator</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderEditor">Folder Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderViewer">Folder Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminEditor">Security Center Admin Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminViewer">Security Center Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.bigQueryExportsEditor">Security Center BigQuery Exports Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.bigQueryExportsEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.bigQueryExportsViewer">Security Center BigQuery Exports Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.bigQueryExportsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.settingsAdmin">Security Center Settings Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.settingsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.settingsEditor">Security Center Settings Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.settingsEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.settingsViewer">Security Center Settings Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.settingsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.serviceAgent">Audit Manager Auditing Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.serviceAgent">Cloud Security Compliance Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/riskmanager#riskmanager.serviceAgent">Risk Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/riskmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.automationServiceAgent">Security Center Automation Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.automationServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.controlServiceAgent">Security Center Control Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.controlServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.serviceAgent">Security Center Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="resourcemanager.folders.move" class="permission-name add-link" data-text="resourcemanager.folders.move" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.folders.move</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderAdmin">Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderMover">Folder Mover</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderMover</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="resourcemanager.folders.searchPolicyBindings" class="permission-name add-link" data-text="resourcemanager.folders.searchPolicyBindings" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.folders.searchPolicyBindings</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderAdmin">Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.organizationAdmin">Organization Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.organizationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderEditor">Folder Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderIamAdmin">Folder IAM Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderIamAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="resourcemanager.folders.setIamPolicy" class="permission-name add-link" data-text="resourcemanager.folders.setIamPolicy" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.folders.setIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderAdmin">Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.organizationAdmin">Organization Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.organizationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderIamAdmin">Folder IAM Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderIamAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/privilegedaccessmanager#privilegedaccessmanager.folderServiceAgent">Privileged Access Manager Folder Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/privilegedaccessmanager.folderServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/privilegedaccessmanager#privilegedaccessmanager.serviceAgent">Privileged Access Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/privilegedaccessmanager.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="resourcemanager.folders.undelete" class="permission-name add-link" data-text="resourcemanager.folders.undelete" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.folders.undelete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.editor">Resource Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderAdmin">Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderEditor">Folder Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderEditor</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="resourcemanager.folders.update" class="permission-name add-link" data-text="resourcemanager.folders.update" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.folders.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.editor">Resource Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderAdmin">Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderEditor">Folder Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderEditor</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="resourcemanager.folders.updatePolicyBinding" class="permission-name add-link" data-text="resourcemanager.folders.updatePolicyBinding" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.folders.updatePolicyBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderAdmin">Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.organizationAdmin">Organization Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.organizationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderIamAdmin">Folder IAM Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderIamAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="resourcemanager.hierarchyNodes.createTagBinding" class="permission-name add-link" data-text="resourcemanager.hierarchyNodes.createTagBinding" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.hierarchyNodes.createTagBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderAdmin">Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dspm#dspm.serviceAgent">DSPM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="resourcemanager.hierarchyNodes.deleteTagBinding" class="permission-name add-link" data-text="resourcemanager.hierarchyNodes.deleteTagBinding" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.hierarchyNodes.deleteTagBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderAdmin">Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dspm#dspm.serviceAgent">DSPM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="resourcemanager.hierarchyNodes.listEffectiveTags" class="permission-name add-link" data-text="resourcemanager.hierarchyNodes.listEffectiveTags" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.hierarchyNodes.listEffectiveTags</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderAdmin">Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagViewer">Tag Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.serviceAgent">Audit Manager Auditing Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.serviceAgent">Cloud Security Compliance Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dspm#dspm.serviceAgent">DSPM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="resourcemanager.hierarchyNodes.listTagBindings" class="permission-name add-link" data-text="resourcemanager.hierarchyNodes.listTagBindings" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.hierarchyNodes.listTagBindings</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderAdmin">Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagViewer">Tag Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.serviceAgent">Audit Manager Auditing Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.serviceAgent">Cloud Security Compliance Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dspm#dspm.serviceAgent">DSPM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="resourcemanager.organizations.createPolicyBinding" class="permission-name add-link" data-text="resourcemanager.organizations.createPolicyBinding" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.organizations.createPolicyBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.organizationAdmin">Organization Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.organizationAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="resourcemanager.organizations.deletePolicyBinding" class="permission-name add-link" data-text="resourcemanager.organizations.deletePolicyBinding" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.organizations.deletePolicyBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.organizationAdmin">Organization Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.organizationAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="resourcemanager.organizations.get" class="permission-name add-link" data-text="resourcemanager.organizations.get" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.organizations.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/accesscontextmanager#accesscontextmanager.admin">Access Context Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/accesscontextmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/accesscontextmanager#accesscontextmanager.editor">Access Context Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/accesscontextmanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/accesscontextmanager#accesscontextmanager.policyAdmin">Access Context Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/accesscontextmanager.policyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/accesscontextmanager#accesscontextmanager.viewer">Access Context Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/accesscontextmanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/advisorynotifications#advisorynotifications.admin">Advisory Notifications Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/advisorynotifications.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/advisorynotifications#advisorynotifications.viewer">Advisory Notifications Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/advisorynotifications.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredworkloads#assuredworkloads.admin">Assured Workloads Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredworkloads.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredworkloads#assuredworkloads.editor">Assured Workloads Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredworkloads.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredworkloads#assuredworkloads.viewer">Assured Workloads Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredworkloads.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.admin">Audit Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/axt#axt.admin">Access Transparency Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/axt.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/beyondcorp#beyondcorp.editor">Cloud BeyondCorp Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/beyondcorp.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/beyondcorp#beyondcorp.viewer">Cloud BeyondCorp Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/beyondcorp.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/capacityplanner#capacityplanner.admin">Capacityplanner Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/capacityplanner.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/capacityplanner#capacityplanner.viewer">Capacity Planner Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/capacityplanner.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/chronicle#chronicle.admin">Chronicle API Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudprivatecatalog#cloudprivatecatalogproducer.admin">Catalog Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudprivatecatalogproducer.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsupport#cloudsupport.admin">Support Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsupport.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercebusinessenablement#commercebusinessenablement.admin">Commerce Business Enablement Configuration Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/commercebusinessenablement.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercebusinessenablement#commercebusinessenablement.viewer">Commerce Business Enablement Configuration Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/commercebusinessenablement.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dspm#dspm.admin">Data Security Posture Management Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dspm#dspm.viewer">Data Security Posture Management Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkmanagement#networkmanagement.admin">Network Management Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networkmanagement.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkmanagement#networkmanagement.editor">Network Management Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/networkmanagement.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkmanagement#networkmanagement.viewer">Network Management Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/networkmanagement.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/policysimulator#policysimulator.orgPolicyAdmin">OrgPolicy Simulator Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/policysimulator.orgPolicyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.editor">Resource Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.organizationAdmin">Organization Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.organizationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.viewer">Resource Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycentermanagement#securitycentermanagement.admin">Security Center Management Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycentermanagement.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycentermanagement#securitycentermanagement.editor">Security Center Management Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycentermanagement.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycentermanagement#securitycentermanagement.viewer">Security Center Management Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycentermanagement.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securityposture#securityposture.admin">Security Posture Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securityposture.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/securityposture#securityposture.viewer">Security Posture Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securityposture.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.admin">Service Management Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/accesscontextmanager#accesscontextmanager.policyEditor">Access Context Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/accesscontextmanager.policyEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/accesscontextmanager#accesscontextmanager.policyReader">Access Context Manager Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/accesscontextmanager.policyReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/accesscontextmanager#accesscontextmanager.vpcScTroubleshooterViewer">VPC Service Controls Troubleshooter Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/accesscontextmanager.vpcScTroubleshooterViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.projectAdmin">Assured OSS Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.projectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.reader">Assured OSS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.user">Assured OSS User</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredworkloads#assuredworkloads.reader">Assured Workloads Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredworkloads.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.auditor">Audit Manager Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.auditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.ccfAdmin">Custom Compliance Framework Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.ccfAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.ccfViewer">Custom Compliance Framework Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.ccfViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/beyondcorp#beyondcorp.subscriptionAdmin">Cloud BeyondCorp Subscription Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/beyondcorp.subscriptionAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/beyondcorp#beyondcorp.subscriptionViewer">Cloud BeyondCorp Subscription Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/beyondcorp.subscriptionViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/billing#billing.creator">Billing Account Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/billing.creator</code>)</p>
<p><a href="/iam/docs/roles-permissions/browser#browser">Browser</a> (<code class="role-name" translate="no" dir="ltr">roles/browser</code>)</p>
<p><a href="/iam/docs/roles-permissions/capacityplanner#capacityplanner.planner">Capacity Planner</a> (<code class="role-name" translate="no" dir="ltr">roles/capacityplanner.planner</code>)</p>
<p><a href="/iam/docs/roles-permissions/chronicle#chronicle.soarAdmin">Chronicle SOAR Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.soarAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/chronicle#chronicle.soarThreatManager">Chronicle SOAR Threat Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.soarThreatManager</code>)</p>
<p><a href="/iam/docs/roles-permissions/chronicle#chronicle.soarVulnerabilityManager">Chronicle SOAR Vulnerability Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.soarVulnerabilityManager</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudprivatecatalog#cloudprivatecatalogproducer.manager">Catalog Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudprivatecatalogproducer.manager</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudprivatecatalog#cloudprivatecatalogproducer.orgAdmin">Catalog Org Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudprivatecatalogproducer.orgAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsupport#cloudsupport.supportSubscriptionEditor">Support Subscription Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsupport.supportSubscriptionEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsupport#cloudsupport.supportSubscriptionViewer">Support Subscription Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsupport.supportSubscriptionViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercebusinessenablement#commercebusinessenablement.resellerDiscountAdmin">Commerce Business Enablement Reseller Discount Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/commercebusinessenablement.resellerDiscountAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercebusinessenablement#commercebusinessenablement.resellerDiscountViewer">Commerce Business Enablement Reseller Discount Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/commercebusinessenablement.resellerDiscountViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgVmExtensionPolicyAdmin">Organization level Compute VM extension policies admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgVmExtensionPolicyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgVmExtensionPolicyViewer">Organization level Compute VM extension policies viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgVmExtensionPolicyViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.xpnAdmin">Compute Shared VPC Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.xpnAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.migrationConfigAdmin">DataCatalog Migration Config Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.migrationConfigAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.searchAdmin">DataCatalog Search Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.searchAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.organizationRoleAdmin">Organization Role Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.organizationRoleAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.organizationRoleViewer">Organization Role Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.organizationRoleViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/modelarmor#modelarmor.floorSettingsAdmin">Model Armor Floor Setting Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/modelarmor.floorSettingsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/modelarmor#modelarmor.floorSettingsViewer">Model Armor Floor Setting Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/modelarmor.floorSettingsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkmanagement#networkmanagement.CloudNetworkInsightsAdmin">Cloud Network Insights Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networkmanagement.CloudNetworkInsightsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkmanagement#networkmanagement.CloudNetworkInsightsEditor">Cloud Network Insights Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/networkmanagement.CloudNetworkInsightsEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkmanagement#networkmanagement.CloudNetworkInsightsViewer">Cloud Network Insights Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/networkmanagement.CloudNetworkInsightsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.organizationViewer">Organization Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.organizationViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.projectCreator">Project Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.projectCreator</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminEditor">Security Center Admin Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminViewer">Security Center Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.assetsViewer">Security Center Assets Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.assetsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.bigQueryExportsEditor">Security Center BigQuery Exports Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.bigQueryExportsEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.bigQueryExportsViewer">Security Center BigQuery Exports Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.bigQueryExportsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.findingsEditor">Security Center Findings Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.findingsEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.findingsViewer">Security Center Findings Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.findingsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.settingsAdmin">Security Center Settings Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.settingsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.settingsEditor">Security Center Settings Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.settingsEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.settingsViewer">Security Center Settings Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.settingsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.sourcesAdmin">Security Center Sources Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.sourcesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.sourcesEditor">Security Center Sources Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.sourcesEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.sourcesViewer">Security Center Sources Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.sourcesViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycentermanagement#securitycentermanagement.customModulesEditor">Security Center Management Custom Modules Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycentermanagement.customModulesEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycentermanagement#securitycentermanagement.customModulesViewer">Security Center Management Custom Modules Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycentermanagement.customModulesViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycentermanagement#securitycentermanagement.etdCustomModulesEditor">Security Center Management Custom ETD Modules Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycentermanagement.etdCustomModulesEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycentermanagement#securitycentermanagement.etdCustomModulesViewer">Security Center Management ETD Custom Modules Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycentermanagement.etdCustomModulesViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycentermanagement#securitycentermanagement.settingsEditor">Security Center Management Settings Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycentermanagement.settingsEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycentermanagement#securitycentermanagement.settingsViewer">Security Center Management Settings Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycentermanagement.settingsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycentermanagement#securitycentermanagement.shaCustomModulesEditor">Security Center Management SHA Custom Modules Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycentermanagement.shaCustomModulesEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycentermanagement#securitycentermanagement.shaCustomModulesViewer">Security Center Management SHA Custom Modules Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycentermanagement.shaCustomModulesViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securityposture#securityposture.postureDeployer">Security Posture Deployer</a> (<code class="role-name" translate="no" dir="ltr">roles/securityposture.postureDeployer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securityposture#securityposture.postureDeploymentsViewer">Security Posture Deployments Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securityposture.postureDeploymentsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securityposture#securityposture.postureViewer">Security Posture Resource Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securityposture.postureViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.quotaAdmin">Quota Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.quotaAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/appengineflex#appengineflex.serviceAgent">App Engine flexible environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengineflex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.serviceAgent">Audit Manager Auditing Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ciem#ciem.serviceAgent">CIEM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ciem.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.serviceAgent">Cloud Security Compliance Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.managementServiceAgent">Firebase Service Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.managementServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/privilegedaccessmanager#privilegedaccessmanager.organizationServiceAgent">Privileged Access Manager Organization Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/privilegedaccessmanager.organizationServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/privilegedaccessmanager#privilegedaccessmanager.serviceAgent">Privileged Access Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/privilegedaccessmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/riskmanager#riskmanager.serviceAgent">Risk Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/riskmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.automationServiceAgent">Security Center Automation Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.automationServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.controlServiceAgent">Security Center Control Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.controlServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.serviceAgent">Security Center Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="resourcemanager.organizations.getIamPolicy" class="permission-name add-link" data-text="resourcemanager.organizations.getIamPolicy" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.organizations.getIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.organizationAdmin">Organization Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.organizationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.organizationRoleAdmin">Organization Role Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.organizationRoleAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.organizationRoleViewer">Organization Role Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.organizationRoleViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.serviceAgent">Audit Manager Auditing Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.soarServiceAgent">Chronicle SOAR Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.soarServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.serviceAgent">Cloud Security Compliance Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dspm#dspm.serviceAgent">DSPM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/privilegedaccessmanager#privilegedaccessmanager.organizationServiceAgent">Privileged Access Manager Organization Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/privilegedaccessmanager.organizationServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/privilegedaccessmanager#privilegedaccessmanager.serviceAgent">Privileged Access Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/privilegedaccessmanager.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="resourcemanager.organizations.searchPolicyBindings" class="permission-name add-link" data-text="resourcemanager.organizations.searchPolicyBindings" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.organizations.searchPolicyBindings</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.organizationAdmin">Organization Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.organizationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="resourcemanager.organizations.setIamPolicy" class="permission-name add-link" data-text="resourcemanager.organizations.setIamPolicy" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.organizations.setIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.organizationAdmin">Organization Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.organizationAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/privilegedaccessmanager#privilegedaccessmanager.organizationServiceAgent">Privileged Access Manager Organization Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/privilegedaccessmanager.organizationServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/privilegedaccessmanager#privilegedaccessmanager.serviceAgent">Privileged Access Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/privilegedaccessmanager.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="resourcemanager.organizations.updatePolicyBinding" class="permission-name add-link" data-text="resourcemanager.organizations.updatePolicyBinding" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.organizations.updatePolicyBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.organizationAdmin">Organization Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.organizationAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="resourcemanager.projects.associateToCapabilityConfig" class="permission-name add-link" data-text="resourcemanager.projects.associateToCapabilityConfig" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.projects.associateToCapabilityConfig</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.editor">Resource Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.editor</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="resourcemanager.projects.create" class="permission-name add-link" data-text="resourcemanager.projects.create" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.projects.create</code></h4></td>
<td><p><a href="/iam/docs/roles-permissions/assuredworkloads#assuredworkloads.admin">Assured Workloads Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredworkloads.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredworkloads#assuredworkloads.editor">Assured Workloads Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredworkloads.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.editor">Resource Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.projectCreator">Project Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.projectCreator</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="resourcemanager.projects.createBillingAssignment" class="permission-name add-link" data-text="resourcemanager.projects.createBillingAssignment" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.projects.createBillingAssignment</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/billing#billing.admin">Billing Account Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/billing.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/billing#billing.projectManager">Project Billing Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/billing.projectManager</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="resourcemanager.projects.createPolicyBinding" class="permission-name add-link" data-text="resourcemanager.projects.createPolicyBinding" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.projects.createPolicyBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderAdmin">Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.organizationAdmin">Organization Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.organizationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.projectIamAdmin">Project IAM Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.projectIamAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="resourcemanager.projects.delete" class="permission-name add-link" data-text="resourcemanager.projects.delete" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.projects.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.projectDeleter">Project Deleter</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.projectDeleter</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="resourcemanager.projects.deleteBillingAssignment" class="permission-name add-link" data-text="resourcemanager.projects.deleteBillingAssignment" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.projects.deleteBillingAssignment</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/billing#billing.admin">Billing Account Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/billing.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/billing#billing.projectManager">Project Billing Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/billing.projectManager</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="resourcemanager.projects.deletePolicyBinding" class="permission-name add-link" data-text="resourcemanager.projects.deletePolicyBinding" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.projects.deletePolicyBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderAdmin">Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.organizationAdmin">Organization Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.organizationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.projectIamAdmin">Project IAM Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.projectIamAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="resourcemanager.projects.get" class="permission-name add-link" data-text="resourcemanager.projects.get" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.projects.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/accessapproval#accessapproval.admin">Access Approval Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/accessapproval.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/accessapproval#accessapproval.editor">Access Approval Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/accessapproval.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/accessapproval#accessapproval.viewer">Access Approval Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/accessapproval.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/accesscontextmanager#accesscontextmanager.admin">Access Context Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/accesscontextmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/accesscontextmanager#accesscontextmanager.editor">Access Context Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/accesscontextmanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/accesscontextmanager#accesscontextmanager.policyAdmin">Access Context Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/accesscontextmanager.policyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/accesscontextmanager#accesscontextmanager.viewer">Access Context Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/accesscontextmanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/actions#actions.Admin">Actions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/actions.Admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/actions#actions.Viewer">Actions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/actions.Viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/advisorynotifications#advisorynotifications.admin">Advisory Notifications Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/advisorynotifications.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/advisorynotifications#advisorynotifications.viewer">Advisory Notifications Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/advisorynotifications.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.admin">Agent Platform Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.editor">Aiplatform Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.user">Agent Platform User</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.viewer">Agent Platform Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/alloydb#alloydb.admin">AlloyDB Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/alloydb.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/alloydb#alloydb.editor">AlloyDB Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/alloydb.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/alloydb#alloydb.viewer">AlloyDB Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/alloydb.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/analyticshub#analyticshub.admin">Analytics Hub Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/analyticshub.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/analyticshub#analyticshub.editor">Analytics Hub Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/analyticshub.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/analyticshub#analyticshub.viewer">Analytics Hub Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/analyticshub.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/androidmanagement#androidmanagement.admin">Androidmanagement Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/androidmanagement.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.admin">ApiGateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.editor">ApiGateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.viewer">ApiGateway Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigee#apigee.admin">Apigee Organization Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigee#apigee.apiAdminV2">Apigee API Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.apiAdminV2</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigee#apigee.editor">Apigee Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigee#apigee.viewer">Apigee Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigeeconnect#apigeeconnect.viewer">Apigeeconnect Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apigeeconnect.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigeeregistry#apigeeregistry.admin">Cloud Apigee Registry Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigeeregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigeeregistry#apigeeregistry.editor">Cloud Apigee Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigeeregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigeeregistry#apigeeregistry.viewer">Cloud Apigee Registry Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apigeeregistry.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apihub#apihub.admin">Cloud API Hub Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apihub.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apihub#apihub.editor">Cloud API Hub Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apihub.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apihub#apihub.viewer">Cloud API Hub Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apihub.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apim#apim.admin">API Management Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apim.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apim#apim.viewer">API Management Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apim.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/appengine#appengine.admin">App Engine Service Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/appengine#appengine.appAdmin">App Engine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.appAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/appengine#appengine.editor">App Engine Service Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/appengine#appengine.viewer">App Engine Service Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apphub#apphub.admin">App Hub Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apphub.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apphub#apphub.editor">App Hub Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apphub.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apphub#apphub.viewer">App Hub Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apphub.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/applianceactivation#applianceactivation.admin">Appliance Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/applianceactivation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/applianceactivation#applianceactivation.viewer">Appliance Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/applianceactivation.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apptopology#apptopology.admin">App Topology Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apptopology.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apptopology#apptopology.viewer">App Topology Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apptopology.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.repoAdmin">Artifact Registry Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.viewer">Artifact Registry Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.editor">Assured OSS Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.viewer">Assured OSS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredworkloads#assuredworkloads.admin">Assured Workloads Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredworkloads.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredworkloads#assuredworkloads.editor">Assured Workloads Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredworkloads.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredworkloads#assuredworkloads.viewer">Assured Workloads Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredworkloads.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.admin">Audit Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.viewer">Auditmanager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/automl#automl.admin">AutoML Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/automl#automl.editor">AutoML Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/automl#automl.viewer">AutoML Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.admin">Recommendations AI Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.editor">Recommendations AI Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.viewer">Recommendations AI Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/autoscaling#autoscaling.admin">Autoscaling Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/autoscaling.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/autoscaling#autoscaling.editor">Autoscaling Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/autoscaling.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/autoscaling#autoscaling.viewer">Autoscaling Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/autoscaling.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/axt#axt.admin">Access Transparency Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/axt.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/backupdr#backupdr.admin">Backup and DR Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/backupdr.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/backupdr#backupdr.editor">Backupdr Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/backupdr.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/backupdr#backupdr.viewer">Backup and DR Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/backupdr.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/baremetalsolution#baremetalsolution.admin">Bare Metal Solution Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/baremetalsolution.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/baremetalsolution#baremetalsolution.editor">Bare Metal Solution Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/baremetalsolution.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/baremetalsolution#baremetalsolution.viewer">Bare Metal Solution Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/baremetalsolution.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/batch#batch.admin">Batch Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/batch.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/batch#batch.viewer">Batch Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/batch.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/beyondcorp#beyondcorp.admin">Cloud BeyondCorp Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/beyondcorp.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/beyondcorp#beyondcorp.editor">Cloud BeyondCorp Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/beyondcorp.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/beyondcorp#beyondcorp.viewer">Cloud BeyondCorp Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/beyondcorp.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/biglake#biglake.admin">BigLake Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/biglake.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/biglake#biglake.editor">BigLake Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/biglake.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/biglake#biglake.viewer">BigLake Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/biglake.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataEditor">BigQuery Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataViewer">BigQuery Data Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.jobUser">BigQuery Job User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.jobUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.metadataViewer">BigQuery Metadata Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.metadataViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.readSessionUser">BigQuery Read Session User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.readSessionUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceAdmin">BigQuery Resource Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceEditor">BigQuery Resource Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceViewer">BigQuery Resource Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioUser">BigQuery Studio User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.user">BigQuery User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerymigration#bigquerymigration.admin">Bigquerymigration Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerymigration.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.user">Bigtable User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.viewer">Bigtable Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/billing#billing.admin">Billing Account Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/billing.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/binaryauthorization#binaryauthorization.admin">Binary Authorization Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/binaryauthorization.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/binaryauthorization#binaryauthorization.editor">Binary Authorization Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/binaryauthorization.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/binaryauthorization#binaryauthorization.viewer">Binary Authorization Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/binaryauthorization.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/blockchainnodeengine#blockchainnodeengine.admin">Blockchain Node Engine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/blockchainnodeengine.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/blockchainnodeengine#blockchainnodeengine.viewer">Blockchain Node Engine Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/blockchainnodeengine.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/blockchainvalidatormanager#blockchainvalidatormanager.admin">Blockchain Validator Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/blockchainvalidatormanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/blockchainvalidatormanager#blockchainvalidatormanager.viewer">Blockchain Validator Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/blockchainvalidatormanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/capacityplanner#capacityplanner.admin">Capacityplanner Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/capacityplanner.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/capacityplanner#capacityplanner.viewer">Capacity Planner Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/capacityplanner.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/carestudio#carestudio.admin">Carestudio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/carestudio.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/carestudio#carestudio.viewer">Care Studio Patients Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/carestudio.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/certificatemanager#certificatemanager.admin">Certificate Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/certificatemanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/certificatemanager#certificatemanager.editor">Certificate Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/certificatemanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/certificatemanager#certificatemanager.viewer">Certificate Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/certificatemanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/ces#ces.admin">Gemini Enterprise for Customer Experience Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/ces.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/ces#ces.viewer">Gemini Enterprise for Customer Experience Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/ces.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/chat#chat.admin">Chat Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/chat.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/chat#chat.viewer">Chat Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/chat.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/chronicle#chronicle.admin">Chronicle API Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/chronicle#chronicle.editor">Chronicle API Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/chronicle#chronicle.viewer">Chronicle API Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/chroniclesm#chroniclesm.editor">Chroniclesm Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/chroniclesm.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloud#cloud.admin">Cloud Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloud.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloud#cloud.viewer">Cloud Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloud.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudaicompanion#cloudaicompanion.admin">Gemini for Google Cloud Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudaicompanion.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudaicompanion#cloudaicompanion.editor">Gemini for Google Cloud Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudaicompanion.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudaicompanion#cloudaicompanion.user">Gemini for Google Cloud User</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudaicompanion.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudaicompanion#cloudaicompanion.viewer">Gemini for Google Cloud Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudaicompanion.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudasset#cloudasset.admin">Cloud Asset Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudasset.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudasset#cloudasset.editor">Cloud Asset Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudasset.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.admin">Cloud Build Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.editor">Cloud Build Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.viewer">Cloud Build Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudconfig#cloudconfig.admin">Firebase Remote Config Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudconfig.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudconfig#cloudconfig.viewer">Firebase Remote Config Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudconfig.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudcontrolspartner#cloudcontrolspartner.viewer">Cloudcontrolspartner Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudcontrolspartner.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/clouddeploy#clouddeploy.admin">Cloud Deploy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploy.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/clouddeploy#clouddeploy.editor">Cloud Deploy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/clouddeploy#clouddeploy.viewer">Cloud Deploy Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploy.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudjobdiscovery#cloudjobdiscovery.admin">Cloud Talent Solution Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudjobdiscovery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudjobdiscovery#cloudjobdiscovery.viewer">Cloud Talent Solution Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudjobdiscovery.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.cryptoKeyEncrypterDecrypter">Cloud KMS CryptoKey Encrypter/Decrypter</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.cryptoKeyEncrypterDecrypter</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.viewer">Cloud KMS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudlocationfinder#cloudlocationfinder.admin">Cloud Location Finder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudlocationfinder.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudlocationfinder#cloudlocationfinder.viewer">Cloud Location Finder Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudlocationfinder.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebasecloudmessaging#cloudmessaging.editor">Firebase Cloud Messaging Service Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudmessaging.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudprivatecatalog#cloudprivatecatalog.admin">Catalog Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudprivatecatalog.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudprivatecatalog#cloudprivatecatalog.viewer">Catalog Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudprivatecatalog.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudprivatecatalog#cloudprivatecatalogproducer.admin">Catalog Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudprivatecatalogproducer.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudprivatecatalog#cloudprivatecatalogproducer.editor">Catalog Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudprivatecatalogproducer.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudprivatecatalog#cloudprivatecatalogproducer.viewer">Catalog Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudprivatecatalogproducer.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudprofiler#cloudprofiler.admin">Cloud Profiler Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudprofiler.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudprofiler#cloudprofiler.viewer">Cloud Profiler Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudprofiler.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudquotas#cloudquotas.admin">Cloud Quotas Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudquotas.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudquotas#cloudquotas.viewer">Cloud Quotas Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudquotas.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.admin">Cloud Scheduler Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.viewer">Cloud Scheduler Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.admin">Compliance Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.viewer">Compliance Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsecurityscanner#cloudsecurityscanner.admin">Web Security Scanner Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecurityscanner.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsecurityscanner#cloudsecurityscanner.editor">Web Security Scanner Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecurityscanner.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.admin">Cloud SQL Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.editor">Cloud SQL Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.viewer">Cloud SQL Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.admin">Cloud Tasks Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.editor">Cloud Tasks Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.viewer">Cloud Tasks Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtestservice#cloudtestservice.admin">Cloud Test Service Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtestservice.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtestservice#cloudtestservice.viewer">Cloud Test Service Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtestservice.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtrace#cloudtrace.admin">Cloud Trace Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtrace.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtrace#cloudtrace.user">Cloud Trace User</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtrace.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtranslate#cloudtranslate.admin">Cloud Translation API Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtranslate.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtranslate#cloudtranslate.editor">Cloud Translation API Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtranslate.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtranslate#cloudtranslate.user">Cloud Translation API User</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtranslate.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtranslate#cloudtranslate.viewer">Cloud Translation API Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtranslate.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/commerceagreementpublishing#commerceagreementpublishing.admin">Commerce Agreement Publishing Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/commerceagreementpublishing.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/commerceagreementpublishing#commerceagreementpublishing.viewer">Commerce Agreement Publishing Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/commerceagreementpublishing.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercebusinessenablement#commercebusinessenablement.admin">Commerce Business Enablement Configuration Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/commercebusinessenablement.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercebusinessenablement#commercebusinessenablement.viewer">Commerce Business Enablement Configuration Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/commercebusinessenablement.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/commerceoffercatalog#commerceoffercatalog.admin">Commerce Offer Catalog Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/commerceoffercatalog.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/commerceorggovernance#commerceorggovernance.admin">Commerce Organization Governance Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/commerceorggovernance.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/commerceorggovernance#commerceorggovernance.viewer">Commerce Organization Governance Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/commerceorggovernance.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercepricemanagement#commercepricemanagement.editor">Commercepricemanagement Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/commercepricemanagement.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercepricemanagement#commercepricemanagement.viewer">Commerce Price Management Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/commercepricemanagement.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/commerceproducer#commerceproducer.admin">Commerce Producer Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/commerceproducer.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/commerceproducer#commerceproducer.viewer">Commerce Producer Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/commerceproducer.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.editor">Composer Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.viewer">Composer Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.admin">Compute Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.editor">Compute Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.instanceAdmin">Compute Instance Admin (beta)</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.instanceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.instanceAdmin.v1">Compute Instance Admin (v1)</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.instanceAdmin.v1</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.loadBalancerAdmin">Compute Load Balancer Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.loadBalancerAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.networkAdmin">Compute Network Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.networkUser">Compute Network User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.networkUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.networkViewer">Compute Network Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.networkViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.osAdminLogin">Compute OS Admin Login</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.osAdminLogin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.osLogin">Compute OS Login</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.osLogin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.securityAdmin">Compute Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.storageAdmin">Compute Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.storageAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.viewer">Compute Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/confidentialcomputing#confidentialcomputing.admin">Confidentialcomputing Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/confidentialcomputing.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/confidentialcomputing#confidentialcomputing.viewer">Confidentialcomputing Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/confidentialcomputing.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/config#config.admin">Cloud Infrastructure Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/config.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/config#config.editor">Cloud Infrastructure Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/config.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/config#config.viewer">Cloud Infrastructure Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/config.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/configdelivery#configdelivery.admin">Configdelivery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/configdelivery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/configdelivery#configdelivery.viewer">Configdelivery Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/configdelivery.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/connectors#connectors.admin">Connector Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/connectors.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/connectors#connectors.editor">Connectors Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/connectors.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/connectors#connectors.viewer">Connectors Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/connectors.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/contactcenteraiplatform#contactcenteraiplatform.admin">Contact Center AI Platform Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/contactcenteraiplatform.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/contactcenteraiplatform#contactcenteraiplatform.viewer">Contact Center AI Platform Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/contactcenteraiplatform.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/container#container.admin">Kubernetes Engine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/container.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/container#container.clusterAdmin">Kubernetes Engine Cluster Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/container.clusterAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/container#container.clusterViewer">Kubernetes Engine Cluster Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/container.clusterViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/container#container.developer">Kubernetes Engine Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/container.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/container#container.editor">Kubernetes Engine Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/container.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/container#container.viewer">Kubernetes Engine Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/container.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.admin">Container Analysis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.editor">Container Analysis Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.viewer">Container Analysis Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/containersecurity#containersecurity.admin">Containersecurity Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/containersecurity.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/containersecurity#containersecurity.viewer">GKE Security Posture Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/containersecurity.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/contentwarehouse#contentwarehouse.admin">Content Warehouse Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/contentwarehouse.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/databasecenter#databasecenter.admin">Database Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/databasecenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/databasecenter#databasecenter.viewer">Database Center Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/databasecenter.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/databaseinsights#databaseinsights.admin">Database Insights Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/databaseinsights.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/databaseinsights#databaseinsights.editor">Database Insights Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/databaseinsights.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/databaseinsights#databaseinsights.viewer">Database Insights Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/databaseinsights.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/databasesconsole#databasesconsole.editor">Databasesconsole Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/databasesconsole.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/databasesconsole#databasesconsole.viewer">Databasesconsole Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/databasesconsole.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.admin">Data Catalog Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.editor">Data Catalog Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.viewer">Data Catalog Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataconnectors#dataconnectors.admin">Data Connectors Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataconnectors.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataconnectors#dataconnectors.editor">Data Connectors Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dataconnectors.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataconnectors#dataconnectors.viewer">Data Connectors Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataconnectors.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.admin">Dataflow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.viewer">Dataflow Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataform#dataform.admin">Dataform Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataform.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataform#dataform.editor">Dataform Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dataform.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataform#dataform.viewer">Dataform Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataform.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/datafusion#datafusion.admin">Cloud Data Fusion Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/datafusion#datafusion.viewer">Cloud Data Fusion Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/datalabeling#datalabeling.admin">Data Labeling Service Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/datalabeling.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/datalabeling#datalabeling.editor">Data Labeling Service Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/datalabeling.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/datalabeling#datalabeling.viewer">Data Labeling Service Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/datalabeling.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/datalineage#datalineage.admin">Data Lineage Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/datalineage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/datalineage#datalineage.editor">Data Lineage Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/datalineage.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/datalineage#datalineage.viewer">Data Lineage Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/datalineage.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/datamigration#datamigration.admin">Database Migration Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/datamigration.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/datamigration#datamigration.editor">Database Migration Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/datamigration.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.admin">Data pipelines Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.viewer">Data pipelines Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.admin">Dataplex Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataprep#dataprep.admin">Dataprep Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.admin">Dataproc Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.editor">Dataproc Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.viewer">Dataproc Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataprocessing#dataprocessing.editor">Dataprocessing Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprocessing.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataprocessing#dataprocessing.viewer">Dataprocessing Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprocessing.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataprocrm#dataprocrm.admin">Dataproc Resource Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprocrm.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataprocrm#dataprocrm.viewer">Dataproc Resource Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprocrm.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firestore#datastore.admin">Cloud Datastore Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/datastore.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firestore#datastore.editor">Cloud Datastore Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/datastore.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firestore#datastore.owner">Cloud Datastore Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/datastore.owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/firestore#datastore.user">Cloud Datastore User</a> (<code class="role-name" translate="no" dir="ltr">roles/datastore.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/firestore#datastore.viewer">Cloud Datastore Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/datastore.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/datastream#datastream.admin">Datastream Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/datastream.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/datastream#datastream.viewer">Datastream Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/datastream.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/datastudio#datastudio.admin">Data Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/datastudio.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/datastudio#datastudio.editor">Data Studio Asset Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/datastudio.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/datastudio#datastudio.viewer">Data Studio Asset Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/datastudio.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dellemccloudonefs#dellemccloudonefs.admin">Dell EMC Cloud OneFS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dellemccloudonefs.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dellemccloudonefs#dellemccloudonefs.viewer">Dell EMC Cloud OneFS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dellemccloudonefs.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.admin">Deployment Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.editor">Deployment Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.viewer">Deployment Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.admin">Application Design Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.editor">Designcenter Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.viewer">Application Design Center Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/developerconnect#developerconnect.admin">Developer Connect Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/developerconnect.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/developerconnect#developerconnect.viewer">Developer Connect Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/developerconnect.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/devicerun#devicerun.admin">Device Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/devicerun.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/devicerun#devicerun.viewer">Device Run Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/devicerun.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/devicestreaming#devicestreaming.admin">Device Streaming Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/devicestreaming.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/devicestreaming#devicestreaming.viewer">Device Streaming Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/devicestreaming.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dialogflow#dialogflow.admin">Dialogflow API Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dialogflow.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dialogflow#dialogflow.viewer">Dialogflow Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dialogflow.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.admin">Discovery Engine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.editor">Discovery Engine Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.user">Discovery Engine User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.viewer">Discovery Engine Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.admin">DLP Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.editor">DLP Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.viewer">DLP Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.admin">DNS Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.editor">DNS Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.viewer">DNS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/clouddocumentai#documentai.admin">Document AI Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/documentai.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/clouddocumentai#documentai.editor">Document AI Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/documentai.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/clouddocumentai#documentai.viewer">Document AI Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/documentai.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/domains#domains.admin">Cloud Domains Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/domains.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/domains#domains.editor">Cloud Domains Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/domains.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/domains#domains.viewer">Cloud Domains Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/domains.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/earth#earth.admin">Earth Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/earth.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/earth#earth.viewer">Earth Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/earth.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/earthengine#earthengine.admin">Earth Engine Resource Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/earthengine.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/earthengine#earthengine.editor">Earth Engine Resource Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/earthengine.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/earthengine#earthengine.viewer">Earth Engine Resource Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/earthengine.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.admin">Edge Container Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.editor">Edge Container Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.viewer">Edge Container Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/edgenetwork#edgenetwork.admin">Edge Network Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/edgenetwork.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/edgenetwork#edgenetwork.editor">Edge Network Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/edgenetwork.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/edgenetwork#edgenetwork.viewer">Edge Network Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/edgenetwork.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/enterpriseknowledgegraph#enterpriseknowledgegraph.admin">Enterprise Knowledge Graph Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/enterpriseknowledgegraph.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/enterpriseknowledgegraph#enterpriseknowledgegraph.editor">Enterprise Knowledge Graph Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/enterpriseknowledgegraph.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/enterpriseknowledgegraph#enterpriseknowledgegraph.viewer">Enterprise Knowledge Graph Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/enterpriseknowledgegraph.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/enterprisepurchasing#enterprisepurchasing.admin">Enterprise Purchasing Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/enterprisepurchasing.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/enterprisepurchasing#enterprisepurchasing.editor">Enterprise Purchasing Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/enterprisepurchasing.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/enterprisepurchasing#enterprisepurchasing.viewer">Enterprise Purchasing Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/enterprisepurchasing.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/errorreporting#errorreporting.admin">Error Reporting Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/errorreporting.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/errorreporting#errorreporting.user">Error Reporting User</a> (<code class="role-name" translate="no" dir="ltr">roles/errorreporting.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/errorreporting#errorreporting.viewer">Error Reporting Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/errorreporting.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/eventarc#eventarc.admin">Eventarc Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/eventarc.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/eventarc#eventarc.editor">Eventarc Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/eventarc.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/eventarc#eventarc.viewer">Eventarc Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/eventarc.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/externalexposure#externalexposure.admin">External Exposure Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/externalexposure.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/externalexposure#externalexposure.viewer">External Exposure Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/externalexposure.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/faulttesting#faulttesting.viewer">Fault Testing Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/faulttesting.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/file#file.admin">Cloud Filestore Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/file.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/financialservices#financialservices.admin">Financial Services Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/financialservices.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/financialservices#financialservices.viewer">Financial Services Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/financialservices.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseabt#firebaseabt.admin">Firebase A/B Testing Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseabt.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseabt#firebaseabt.viewer">Firebase A/B Testing Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseabt.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseappdistro#firebaseappdistro.admin">Firebase App Distribution Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseappdistro.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseappdistro#firebaseappdistro.viewer">Firebase App Distribution Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseappdistro.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.admin">Firebase App Hosting Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.viewer">Firebase App Hosting Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseauth#firebaseauth.admin">Firebase Authentication Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseauth.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseauth#firebaseauth.editor">Firebase Authentication editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseauth.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseauth#firebaseauth.viewer">Firebase Authentication Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseauth.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebasecloudmessaging#firebasecloudmessaging.admin">Firebase Cloud Messaging API Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasecloudmessaging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebasecloudmessaging#firebasecloudmessaging.viewer">Firebase Cloud Messaging API Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasecloudmessaging.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebasecrash#firebasecrashlytics.admin">Firebase Crashlytics Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasecrashlytics.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebasecrash#firebasecrashlytics.viewer">Firebase Crashlytics Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasecrashlytics.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebasedatabase#firebasedatabase.admin">Firebase Realtime Database Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasedatabase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebasedatabase#firebasedatabase.viewer">Firebase Realtime Database Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasedatabase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebasedataconnect#firebasedataconnect.admin">Firebase SQL Connect API Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasedataconnect.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebasedataconnect#firebasedataconnect.viewer">Firebase SQL Connect API Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasedataconnect.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebasedynamiclinks#firebasedynamiclinks.admin">Firebase Dynamic Links Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasedynamiclinks.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebasedynamiclinks#firebasedynamiclinks.editor">Firebasedynamiclinks Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasedynamiclinks.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebasedynamiclinks#firebasedynamiclinks.viewer">Firebase Dynamic Links Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasedynamiclinks.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseextensions#firebaseextensions.editor">Firebaseextensions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseextensions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseextensions#firebaseextensions.viewer">Firebase Extensions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseextensions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseextensionspublisher#firebaseextensionspublisher.admin">Firebaseextensionspublisher Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseextensionspublisher.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseextensionspublisher#firebaseextensionspublisher.viewer">Firebaseextensionspublisher Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseextensionspublisher.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebasehosting#firebasehosting.admin">Firebase Hosting Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasehosting.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebasehosting#firebasehosting.viewer">Firebase Hosting Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasehosting.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseinappmessaging#firebaseinappmessaging.admin">Firebase In-App Messaging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseinappmessaging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseinappmessaging#firebaseinappmessaging.viewer">Firebase In-App Messaging Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseinappmessaging.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseml#firebaseml.admin">Firebase ML Kit Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseml.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseml#firebaseml.viewer">Firebase ML Kit Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseml.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebasecloudmessaging#firebasenotifications.admin">Firebase Cloud Messaging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasenotifications.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebasecloudmessaging#firebasenotifications.viewer">Firebase Cloud Messaging Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasenotifications.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseperformance#firebaseperformance.admin">Firebase Performance Reporting Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseperformance.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseperformance#firebaseperformance.viewer">Firebase Performance Reporting Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseperformance.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaserules#firebaserules.admin">Firebase Rules Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaserules.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaserules#firebaserules.system">Firebase Rules System</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaserules.system</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaserules#firebaserules.viewer">Firebase Rules Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaserules.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebasestorage#firebasestorage.admin">Cloud Storage for Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasestorage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebasestorage#firebasestorage.viewer">Cloud Storage for Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasestorage.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebasevertexai#firebasevertexai.admin">Firebase AI Logic Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasevertexai.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebasevertexai#firebasevertexai.viewer">Firebase AI Logic Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasevertexai.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/fleetengine#fleetengine.viewer">Fleet Engine Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/fleetengine.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/flow#flow.admin">Flow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/flow.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/flow#flow.editor">Flow Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/flow.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/ftp#ftp.admin">Cloud FTP Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/ftp.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/ftp#ftp.viewer">Cloud FTP Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/ftp.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/gdchardwaremanagement#gdchardwaremanagement.admin">GDC Hardware Management Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/gdchardwaremanagement.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/gdchardwaremanagement#gdchardwaremanagement.viewer">Gdchardwaremanagement Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/gdchardwaremanagement.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.admin">Gemini Cloud Assist Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.editor">Gemini Cloud Assist Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.investigationOwner">Gemini Cloud Assist Investigation Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.investigationOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.user">Gemini Cloud Assist User</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.viewer">Gemini Cloud Assist Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminidataanalytics#geminidataanalytics.admin">Gemini Data Analytics Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/geminidataanalytics.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminidataanalytics#geminidataanalytics.viewer">Gemini Data Analytics Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/geminidataanalytics.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkebackup#gkebackup.admin">Backup for GKE Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/gkebackup.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkebackup#gkebackup.editor">Backup for GKE Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/gkebackup.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkebackup#gkebackup.viewer">Backup for GKE Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/gkebackup.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.admin">Fleet Admin (formerly GKE Hub Admin)</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.editor">Fleet Editor (formerly GKE Hub Editor)</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.viewer">Fleet Viewer (formerly GKE Hub Viewer)</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkemulticloud#gkemulticloud.admin">Anthos Multi-cloud Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/gkemulticloud.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkemulticloud#gkemulticloud.editor">Anthos Multi-cloud Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/gkemulticloud.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkemulticloud#gkemulticloud.viewer">Anthos Multi-cloud Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/gkemulticloud.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkeonprem#gkeonprem.admin">GKE on-prem Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/gkeonprem.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkeonprem#gkeonprem.editor">GKE on-prem Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/gkeonprem.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkeonprem#gkeonprem.viewer">GKE on-prem Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/gkeonprem.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/gsuiteaddons#gsuiteaddons.admin">Google Workspace Add-ons Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/gsuiteaddons.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/gsuiteaddons#gsuiteaddons.viewer">Google Workspace Add-ons Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/gsuiteaddons.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.editor">Cluster Director Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">IAM Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">IAM Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.roleAdmin">Role Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.roleAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.roleViewer">Role Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.roleViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountAdmin">Service Account Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountCreator">Create Service Accounts</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountCreator</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountKeyAdmin">Service Account Key Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountKeyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountTokenCreator">Service Account Token Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountTokenCreator</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountUser">Service Account User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountViewer">View Service Accounts</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">IAM Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iap#iap.editor">IAP Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iap.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iap#iap.viewer">IAP Policy Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iap.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/identitytoolkit#identitytoolkit.editor">Identity Toolkit editor</a> (<code class="role-name" translate="no" dir="ltr">roles/identitytoolkit.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/ids#ids.admin">Cloud IDS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/ids.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/ids#ids.editor">Cloud IDS Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/ids.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/ids#ids.viewer">Cloud IDS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/ids.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/integrations#integrations.admin">Integrations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/integrations#integrations.viewer">Integrations Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/issuerswitch#issuerswitch.admin">Issuerswitch Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/issuerswitch.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/issuerswitch#issuerswitch.viewer">Issuerswitch Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/issuerswitch.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/krmapihosting#krmapihosting.admin">Config Controller Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/krmapihosting.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/krmapihosting#krmapihosting.editor">Config Controller Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/krmapihosting.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/krmapihosting#krmapihosting.viewer">Config Controller Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/krmapihosting.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/kubernetesmetadata#kubernetesmetadata.admin">Kubernetesmetadata Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/kubernetesmetadata.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/kubernetesmetadata#kubernetesmetadata.viewer">Kubernetesmetadata Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/kubernetesmetadata.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/licensemanager#licensemanager.admin">Cloud License Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/licensemanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/licensemanager#licensemanager.viewer">Cloud License Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/licensemanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/lifesciences#lifesciences.viewer">Cloud Life Sciences Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/lifesciences.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/livestream#livestream.admin">Live Stream Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/livestream.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/livestream#livestream.editor">Live Stream Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/livestream.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/livestream#livestream.viewer">Live Stream Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/livestream.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.privateLogViewer">Private Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.privateLogViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.viewer">Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/looker#looker.admin">Looker Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/looker.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/looker#looker.viewer">Looker Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/looker.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/lustre#lustre.admin">Google Cloud Managed Lustre Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/lustre.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/lustre#lustre.viewer">Google Cloud Managed Lustre Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/lustre.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/maintenance#maintenance.admin">Maintenance Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/maintenance.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/maintenance#maintenance.viewer">Maintenance API Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/maintenance.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedflink#managedflink.admin">Managed Flink Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/managedflink.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedflink#managedflink.viewer">Managed Flink Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/managedflink.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.admin">Google Cloud Managed Identities Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.editor">Google Cloud Managed Identities Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.viewer">Google Cloud Managed Identities Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.admin">Managed Kafka Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.viewer">Managed Kafka Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/mandiant#mandiant.admin">Mandiant Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/mandiant.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/mandiant#mandiant.viewer">Mandiant Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/mandiant.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/mapsadmin#mapsadmin.admin">Maps API Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/mapsadmin.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/mapsadmin#mapsadmin.viewer">Maps API Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/mapsadmin.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/mapsanalytics#mapsanalytics.admin">Mapsanalytics Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/mapsanalytics.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/mapsanalytics#mapsanalytics.viewer">Maps Analytics Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/mapsanalytics.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/mapsplatformdatasets#mapsplatformdatasets.admin">Maps Platform Datasets Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/mapsplatformdatasets.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/mapsplatformdatasets#mapsplatformdatasets.viewer">Maps Platform Datasets Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/mapsplatformdatasets.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/marketplacesolutions#marketplacesolutions.admin">Marketplace Solutions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/marketplacesolutions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/marketplacesolutions#marketplacesolutions.editor">Marketplace Solutions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/marketplacesolutions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/marketplacesolutions#marketplacesolutions.viewer">Marketplace Solutions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/marketplacesolutions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/mcp#mcp.admin">MCP Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/mcp.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/mcp#mcp.toolUser">MCP Tool User</a> (<code class="role-name" translate="no" dir="ltr">roles/mcp.toolUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/memcache#memcache.admin">Cloud Memorystore Memcached Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/memcache.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/memcache#memcache.editor">Cloud Memorystore Memcached Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/memcache.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/memcache#memcache.viewer">Cloud Memorystore Memcached Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/memcache.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/memorystore#memorystore.admin">Memorystore Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/memorystore.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/memorystore#memorystore.viewer">Memorystore Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/memorystore.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/metastore#metastore.admin">Dataproc Metastore Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/metastore.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/metastore#metastore.editor">Dataproc Metastore Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/metastore.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/metastore#metastore.viewer">Dataproc Metastore Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/metastore.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/migrationcenter#migrationcenter.admin">Migration Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/migrationcenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/migrationcenter#migrationcenter.viewer">Migration Center Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/migrationcenter.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/ml#ml.admin">AI Platform Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/ml#ml.editor">AI Platform Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/ml#ml.viewer">AI Platform Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/modelarmor#modelarmor.admin">Model Armor Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/modelarmor.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/modelarmor#modelarmor.editor">Model Armor Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/modelarmor.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/modelarmor#modelarmor.viewer">Model Armor Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/modelarmor.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#monitoring.admin">Monitoring Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/monitoring.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#monitoring.editor">Monitoring Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/monitoring.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#monitoring.viewer">Monitoring Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/monitoring.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/navigationconnect#navigationconnect.admin">Navigation Connect Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/navigationconnect.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/navigationconnect#navigationconnect.viewer">Navigation Connect Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/navigationconnect.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/nestconsole#nestconsole.admin">Nestconsole Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/nestconsole.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/nestconsole#nestconsole.editor">Nestconsole Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/nestconsole.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/nestconsole#nestconsole.viewer">Nestconsole Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/nestconsole.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/netapp#netapp.admin">Google Cloud NetApp Volumes Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/netapp.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/netapp#netapp.viewer">Google Cloud NetApp Volumes Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/netapp.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/netappcloudvolumes#netappcloudvolumes.admin">NetApp Cloud Volumes Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/netappcloudvolumes.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/netappcloudvolumes#netappcloudvolumes.viewer">NetApp Cloud Volumes Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/netappcloudvolumes.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkconnectivity#networkconnectivity.editor">Network Connectivity Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/networkconnectivity.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkmanagement#networkmanagement.admin">Network Management Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networkmanagement.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkmanagement#networkmanagement.editor">Network Management Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/networkmanagement.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkmanagement#networkmanagement.viewer">Network Management Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/networkmanagement.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/networksecurity#networksecurity.admin">Network Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networksecurity.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networksecurity#networksecurity.editor">Network Security Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/networksecurity.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/networksecurity#networksecurity.viewer">Network Security Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/networksecurity.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkservices#networkservices.admin">Network Services Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networkservices.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkservices#networkservices.editor">Network Services Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/networkservices.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkservices#networkservices.viewer">Network Services Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/networkservices.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.admin">Notebooks Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.editor">Notebooks Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.viewer">Notebooks Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/oauthconfig#oauthconfig.editor">OAuth Config Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/oauthconfig.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/oauthconfig#oauthconfig.viewer">OAuth Config Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/oauthconfig.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/ondemandscanning#ondemandscanning.viewer">On-Demand Scanning Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/ondemandscanning.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#opsconfigmonitoring.admin">Ops Config Monitoring Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/opsconfigmonitoring.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#opsconfigmonitoring.viewer">Ops Config Monitoring Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/opsconfigmonitoring.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.admin">Oracle Database@Google Cloud admin</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.viewer">Oracle Database@Google Cloud viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/parallelstore#parallelstore.admin">Parallelstore Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/parallelstore.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/parallelstore#parallelstore.viewer">Parallelstore Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/parallelstore.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/parametermanager#parametermanager.admin">Parameter Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/parametermanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/parametermanager#parametermanager.editor">Parameter Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/parametermanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/parametermanager#parametermanager.viewer">Parameter Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/parametermanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/paymentsresellersubscription#paymentsresellersubscription.admin">Paymentsresellersubscription Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/paymentsresellersubscription.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/paymentsresellersubscription#paymentsresellersubscription.viewer">Paymentsresellersubscription Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/paymentsresellersubscription.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/policyanalyzer#policyanalyzer.admin">Policyanalyzer Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/policyanalyzer.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/policyanalyzer#policyanalyzer.viewer">Policyanalyzer Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/policyanalyzer.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/policyremediatormanager#policyremediatormanager.admin">Policyremediatormanager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/policyremediatormanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/policyremediatormanager#policyremediatormanager.viewer">Policyremediatormanager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/policyremediatormanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/policysimulator#policysimulator.viewer">Policysimulator Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/policysimulator.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/privateca#privateca.admin">CA Service Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/privateca.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/privateca#privateca.editor">CA Service Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/privateca.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/privateca#privateca.viewer">CA Service Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/privateca.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/privilegedaccessmanager#privilegedaccessmanager.admin">Privileged Access Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/privilegedaccessmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/privilegedaccessmanager#privilegedaccessmanager.editor">Privilegedaccessmanager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/privilegedaccessmanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/privilegedaccessmanager#privilegedaccessmanager.viewer">Privileged Access Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/privilegedaccessmanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/proximitybeacon#proximitybeacon.admin">Beacon Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/proximitybeacon.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/proximitybeacon#proximitybeacon.editor">Beacon Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/proximitybeacon.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/proximitybeacon#proximitybeacon.viewer">Beacon Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/proximitybeacon.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/publicca#publicca.admin">Publicca Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/publicca.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/pubsub#pubsub.admin">Pub/Sub Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/pubsub#pubsub.editor">Pub/Sub Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/pubsub#pubsub.viewer">Pub/Sub Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/readerrevenuesubscriptionlinking#readerrevenuesubscriptionlinking.admin">Subscription Linking Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/readerrevenuesubscriptionlinking.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/readerrevenuesubscriptionlinking#readerrevenuesubscriptionlinking.viewer">Subscription Linking Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/readerrevenuesubscriptionlinking.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recaptchaenterprise#recaptchaenterprise.admin">reCAPTCHA Enterprise Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recaptchaenterprise.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recaptchaenterprise#recaptchaenterprise.editor">reCAPTCHA Enterprise Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/recaptchaenterprise.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/recaptchaenterprise#recaptchaenterprise.viewer">reCAPTCHA Enterprise Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recaptchaenterprise.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.admin">Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.editor">Recommender Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.viewer">Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.editor">Cloud Memorystore Redis Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.viewer">Cloud Memorystore Redis Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/redisenterprisecloud#redisenterprisecloud.admin">Redis Enterprise Cloud Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redisenterprisecloud.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/redisenterprisecloud#redisenterprisecloud.viewer">Redis Enterprise Cloud Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/redisenterprisecloud.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/remotebuildexecution#remotebuildexecution.admin">Remotebuildexecution Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/remotebuildexecution.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/remotebuildexecution#remotebuildexecution.editor">Remotebuildexecution Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/remotebuildexecution.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/remotebuildexecution#remotebuildexecution.viewer">Remotebuildexecution Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/remotebuildexecution.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.editor">Resource Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderAdmin">Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.organizationAdmin">Organization Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.organizationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.projectIamAdmin">Project IAM Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.projectIamAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.projectMover">Project Mover</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.projectMover</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.viewer">Resource Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/retail#retail.admin">Retail Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/retail.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/retail#retail.editor">Retail Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/retail.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/retail#retail.viewer">Retail Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/retail.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/riskmanager#riskmanager.admin">Risk Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/riskmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/riskmanager#riskmanager.editor">Risk Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/riskmanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/riskmanager#riskmanager.viewer">Risk Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/riskmanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/rapidmigrationassessment#rma.admin">Rapid Migration Assessment Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/rma.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/rapidmigrationassessment#rma.viewer">Rapid Migration Assessment Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/rma.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/routeoptimization#routeoptimization.admin">Routeoptimization Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/routeoptimization.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/routeoptimization#routeoptimization.editor">Route Optimization Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/routeoptimization.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/routeoptimization#routeoptimization.viewer">Route Optimization Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/routeoptimization.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.viewer">Cloud Run Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/runapps#runapps.admin">Runapps Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/runapps.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/runapps#runapps.viewer">Serverless Integrations Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/runapps.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/runtimeconfig#runtimeconfig.editor">Runtimeconfig Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/runtimeconfig.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/runtimeconfig#runtimeconfig.viewer">Runtimeconfig Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/runtimeconfig.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/saasconfig#saasconfig.viewer">SaaS Config Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/saasconfig.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/saasservicemgmt#saasservicemgmt.admin">SaaS Service Management Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/saasservicemgmt.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/saasservicemgmt#saasservicemgmt.viewer">SaaS Service Management Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/saasservicemgmt.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.admin">Secret Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.editor">Secret Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.secretAccessor">Secret Manager Secret Accessor</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.secretAccessor</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.viewer">Secret Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securedlandingzone#securedlandingzone.admin">Secured Landing Zone Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securedlandingzone.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/securedlandingzone#securedlandingzone.viewer">Secured Landing Zone Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securedlandingzone.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securesourcemanager#securesourcemanager.admin">Secure Source Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securesourcemanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/securesourcemanager#securesourcemanager.editor">Secure Source Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securesourcemanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securesourcemanager#securesourcemanager.viewer">Secure Source Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securesourcemanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycentermanagement#securitycentermanagement.admin">Security Center Management Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycentermanagement.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycentermanagement#securitycentermanagement.editor">Security Center Management Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycentermanagement.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycentermanagement#securitycentermanagement.viewer">Security Center Management Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycentermanagement.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceconsumermanagement#serviceconsumermanagement.admin">Service Consumer Management Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceconsumermanagement.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceconsumermanagement#serviceconsumermanagement.viewer">Service Consumer Management Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceconsumermanagement.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicedirectory#servicedirectory.admin">Service Directory Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/servicedirectory.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicedirectory#servicedirectory.editor">Service Directory Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/servicedirectory.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicedirectory#servicedirectory.viewer">Service Directory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/servicedirectory.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceextensions#serviceextensions.admin">Service Extensions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceextensions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceextensions#serviceextensions.editor">Service Extensions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceextensions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceextensions#serviceextensions.viewer">Service Extensions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceextensions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicehealth#servicehealth.admin">Servicehealth Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/servicehealth.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicehealth#servicehealth.viewer">Personalized Service Health Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/servicehealth.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.admin">Service Management Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.editor">Service Management Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.viewer">Service Management Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicenetworking#servicenetworking.admin">Service Networking Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/servicenetworking.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicenetworking#servicenetworking.editor">Service Networking Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/servicenetworking.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicenetworking#servicenetworking.viewer">Service Networking Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/servicenetworking.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/source#source.editor">Source Repository Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/source.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/source#source.viewer">Source Repository Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/source.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/spanner#spanner.admin">Cloud Spanner Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/spanner.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/spanner#spanner.editor">Cloud Spanner Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/spanner.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/spanner#spanner.viewer">Cloud Spanner Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/spanner.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#stackdriver.admin">Stackdriver Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/stackdriver.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#stackdriver.viewer">Stackdriver Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/stackdriver.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.editor">Storage Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.folderAdmin">Storage Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectAdmin">Storage Object Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectCreator">Storage Object Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectCreator</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectUser">Storage Object User</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectViewer">Storage Object Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.viewer">Storage Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/storagebatchoperations#storagebatchoperations.admin">Storage Batch Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storagebatchoperations.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storagebatchoperations#storagebatchoperations.viewer">Storage Batch Operations Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/storagebatchoperations.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/storageinsights#storageinsights.admin">Storage Insights Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storageinsights.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storageinsights#storageinsights.viewer">Storage Insights Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/storageinsights.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/storagetransfer#storagetransfer.admin">Storage Transfer Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storagetransfer.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storagetransfer#storagetransfer.viewer">Storage Transfer Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/storagetransfer.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/stream#stream.admin">Stream Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/stream.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/stream#stream.viewer">Stream Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/stream.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/subscribewithgoogledeveloper#subscribewithgoogledeveloper.admin">Subscribewithgoogledeveloper Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/subscribewithgoogledeveloper.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/subscribewithgoogledeveloper#subscribewithgoogledeveloper.viewer">Subscribewithgoogledeveloper Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/subscribewithgoogledeveloper.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.editor">Telcoautomation Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.viewer">Telcoautomation Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telemetry#telemetry.admin">Telemetry Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telemetry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/telemetry#telemetry.editor">Telemetry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/telemetry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/tpu#tpu.admin">TPU Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/tpu.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/tpu#tpu.editor">TPU Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/tpu.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/tpu#tpu.viewer">TPU Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/tpu.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/anthosservicemesh#trafficdirector.admin">Trafficdirector Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/trafficdirector.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/anthosservicemesh#trafficdirector.viewer">Trafficdirector Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/trafficdirector.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/transcoder#transcoder.admin">Transcoder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/transcoder.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/transcoder#transcoder.editor">Transcoder Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/transcoder.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/transcoder#transcoder.viewer">Transcoder Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/transcoder.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/transferappliance#transferappliance.admin">Transfer Appliance Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/transferappliance.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/transferappliance#transferappliance.viewer">Transfer Appliance Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/transferappliance.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/translationhub#translationhub.admin">Translation Hub Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/translationhub.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/translationhub#translationhub.viewer">Translation Hub Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/translationhub.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/vectorsearch#vectorsearch.admin">Vector Search Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/vectorsearch.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/vectorsearch#vectorsearch.viewer">Vector Search Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/vectorsearch.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/videostitcher#videostitcher.admin">Video Stitcher Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/videostitcher.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/videostitcher#videostitcher.viewer">Video Stitcher Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/videostitcher.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/visionai#visionai.admin">VisionAI Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/visionai.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/visionai#visionai.editor">VisionAI Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/visionai.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/visionai#visionai.viewer">VisionAI Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/visionai.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.admin">Visual Inspection AI Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/vmmigration#vmmigration.admin">VM Migration Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/vmmigration.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/vmmigration#vmmigration.viewer">VM Migration Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/vmmigration.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.admin">Vmwareengine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.editor">Vmwareengine Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.viewer">Vmwareengine Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/vpcaccess#vpcaccess.admin">Serverless VPC Access Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/vpcaccess.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/vpcaccess#vpcaccess.user">Serverless VPC Access User</a> (<code class="role-name" translate="no" dir="ltr">roles/vpcaccess.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/vpcaccess#vpcaccess.viewer">Serverless VPC Access Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/vpcaccess.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/workflows#workflows.admin">Workflows Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workflows.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/workflows#workflows.editor">Workflows Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/workflows.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/workflows#workflows.viewer">Workflows Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/workflows.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadcertificate#workloadcertificate.admin">Workload Certificate Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadcertificate.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadcertificate#workloadcertificate.viewer">Workload Certificate Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadcertificate.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadidentity#workloadidentity.admin">Workload Identity API Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadidentity.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadidentity#workloadidentity.viewer">Workload Identity API Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadidentity.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.admin">Workload Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.viewer">Workload Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/workstations#workstations.admin">Cloud Workstations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workstations.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/workstations#workstations.editor">Cloud Workstations Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/workstations.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/accessapproval#accessapproval.approver">Access Approval Approver</a> (<code class="role-name" translate="no" dir="ltr">roles/accessapproval.approver</code>)</p>
<p><a href="/iam/docs/roles-permissions/accessapproval#accessapproval.configEditor">Access Approval Config Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/accessapproval.configEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/accessapproval#accessapproval.invalidator">Access Approval Invalidator</a> (<code class="role-name" translate="no" dir="ltr">roles/accessapproval.invalidator</code>)</p>
<p><a href="/iam/docs/roles-permissions/accesscontextmanager#accesscontextmanager.policyEditor">Access Context Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/accesscontextmanager.policyEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/accesscontextmanager#accesscontextmanager.policyReader">Access Context Manager Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/accesscontextmanager.policyReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/accesscontextmanager#accesscontextmanager.vpcScTroubleshooterViewer">VPC Service Controls Troubleshooter Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/accesscontextmanager.vpcScTroubleshooterViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.colabEnterpriseAdmin">Colab Enterprise Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.colabEnterpriseAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.colabEnterpriseUser">Colab Enterprise User</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.colabEnterpriseUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.entityTypeOwner">Agent Platform Feature Store EntityType owner</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.entityTypeOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.featurestoreAdmin">Agent Platform Feature Store Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.featurestoreAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.featurestoreDataViewer">Agent Platform Feature Store Data Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.featurestoreDataViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.featurestoreDataWriter">Agent Platform Feature Store Data Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.featurestoreDataWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.featurestoreResourceViewer">Agent Platform Feature Store Resource Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.featurestoreResourceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.featurestoreUser">Agent Platform Feature Store User</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.featurestoreUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/alloydb#alloydb.client">AlloyDB Client</a> (<code class="role-name" translate="no" dir="ltr">roles/alloydb.client</code>)</p>
<p><a href="/iam/docs/roles-permissions/alloydb#alloydb.databaseUser">AlloyDB Database User</a> (<code class="role-name" translate="no" dir="ltr">roles/alloydb.databaseUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/analyticshub#analyticshub.listingAdmin">Analytics Hub Listing Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/analyticshub.listingAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/analyticshub#analyticshub.publisher">Analytics Hub Publisher</a> (<code class="role-name" translate="no" dir="ltr">roles/analyticshub.publisher</code>)</p>
<p><a href="/iam/docs/roles-permissions/analyticshub#analyticshub.subscriber">Analytics Hub Subscriber</a> (<code class="role-name" translate="no" dir="ltr">roles/analyticshub.subscriber</code>)</p>
<p><a href="/iam/docs/roles-permissions/analyticshub#analyticshub.subscriptionOwner">Analytics Hub Subscription Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/analyticshub.subscriptionOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigee#apigee.analyticsEditor">Apigee Analytics Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.analyticsEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigee#apigee.analyticsViewer">Apigee Analytics Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.analyticsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigee#apigee.apiReaderV2">Apigee API Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.apiReaderV2</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigee#apigee.developerAdmin">Apigee Developer Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.developerAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigee#apigee.environmentAdmin">Apigee Environment Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.environmentAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigee#apigee.monetizationAdmin">Apigee Monetization Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.monetizationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigee#apigee.portalAdmin">Apigee Portal Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.portalAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigee#apigee.readOnlyAdmin">Apigee Read-only Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.readOnlyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigee#apigee.securityAdmin">Apigee Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigee#apigee.securityViewer">Apigee Security Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.securityViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigee#apigee.spaceConsoleUser">Apigee Space Console User</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.spaceConsoleUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigeeregistry#apigeeregistry.worker">Cloud Apigee Registry Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/apigeeregistry.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/apihub#apihub.addonsAdmin">Cloud API hub Addons Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apihub.addonsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apihub#apihub.attributeAdmin">Cloud API hub Attributes Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apihub.attributeAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apihub#apihub.pluginAdmin">Cloud API hub Plugins Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apihub.pluginAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apihub#apihub.provisioningAdmin">Cloud API hub Provisioning Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apihub.provisioningAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/appengine#appengine.appCreator">App Engine Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.appCreator</code>)</p>
<p><a href="/iam/docs/roles-permissions/appengine#appengine.appViewer">App Engine Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.appViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/appengine#appengine.codeViewer">App Engine Code Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.codeViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/appengine#appengine.debugger">App Engine Managed VM Debug Access</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.debugger</code>)</p>
<p><a href="/iam/docs/roles-permissions/appengine#appengine.deployer">App Engine Deployer</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.deployer</code>)</p>
<p><a href="/iam/docs/roles-permissions/appengine#appengine.memcacheDataAdmin">App Engine Memcache Data Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.memcacheDataAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAdmin">App Engine Service Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apphub#apphub.appManagementViewer">App Management Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apphub.appManagementViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/applianceactivation#applianceactivation.approver">Appliance troubleshooting commands approver</a> (<code class="role-name" translate="no" dir="ltr">roles/applianceactivation.approver</code>)</p>
<p><a href="/iam/docs/roles-permissions/applianceactivation#applianceactivation.troubleshooter">Appliance troubleshooter</a> (<code class="role-name" translate="no" dir="ltr">roles/applianceactivation.troubleshooter</code>)</p>
<p><a href="/iam/docs/roles-permissions/workspacemarketplace#appmetadata.workspaceMarketplaceAppConfigurationAdmin">Workspace Marketplace App Configuration Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/appmetadata.workspaceMarketplaceAppConfigurationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.containerRegistryMigrationAdmin">Container Registry -&gt; Artifact Registry Migration Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.containerRegistryMigrationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushRepoAdmin">Artifact Registry Create-on-Push Repository Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushRepoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.createOnPushWriter">Artifact Registry Create-on-Push Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.createOnPushWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.reader">Artifact Registry Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.writer">Artifact Registry Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.projectAdmin">Assured OSS Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.projectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.reader">Assured OSS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.user">Assured OSS User</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredworkloads#assuredworkloads.reader">Assured Workloads Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredworkloads.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.auditor">Audit Manager Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.auditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/automl#automl.predictor">AutoML Predictor</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.predictor</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.adminViewer">Recommendations AI Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.adminViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/autoscaling#autoscaling.sitesAdmin">Autoscaling Site Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/autoscaling.sitesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/backupdr#backupdr.backupUser">Backup and DR Backup User</a> (<code class="role-name" translate="no" dir="ltr">roles/backupdr.backupUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/backupdr#backupdr.computeEngineOperator">Backup and DR Compute Engine Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/backupdr.computeEngineOperator</code>)</p>
<p><a href="/iam/docs/roles-permissions/backupdr#backupdr.mountUser">Backup and DR Mount User</a> (<code class="role-name" translate="no" dir="ltr">roles/backupdr.mountUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/backupdr#backupdr.restoreUser">Backup and DR Restore User</a> (<code class="role-name" translate="no" dir="ltr">roles/backupdr.restoreUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/backupdr#backupdr.user">Backup and DR User</a> (<code class="role-name" translate="no" dir="ltr">roles/backupdr.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/backupdr#backupdr.userv2">Backup and DR User V2</a> (<code class="role-name" translate="no" dir="ltr">roles/backupdr.userv2</code>)</p>
<p><a href="/iam/docs/roles-permissions/baremetalsolution#baremetalsolution.instancesadmin">Bare Metal Solution Instances Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/baremetalsolution.instancesadmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/baremetalsolution#baremetalsolution.instancesviewer">Bare Metal Solution Instances Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/baremetalsolution.instancesviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/baremetalsolution#baremetalsolution.storageadmin">Bare Metal Solution Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/baremetalsolution.storageadmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/batch#batch.jobsEditor">Batch Job Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/batch.jobsEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/batch#batch.jobsViewer">Batch Job Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/batch.jobsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/batch#batch.resourceAllowancesEditor">Batch ResourceAllowance Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/batch.resourceAllowancesEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/batch#batch.resourceAllowancesViewer">Batch ResourceAllowance Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/batch.resourceAllowancesViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/biglake#biglake.metadataViewer">BigLake Metadata Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/biglake.metadataViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.securityAdmin">BigQuery Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.reader">Bigtable Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/binaryauthorization#binaryauthorization.attestorsAdmin">Binary Authorization Attestor Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/binaryauthorization.attestorsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/binaryauthorization#binaryauthorization.attestorsEditor">Binary Authorization Attestor Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/binaryauthorization.attestorsEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/binaryauthorization#binaryauthorization.attestorsVerifier">Binary Authorization Attestor Image Verifier</a> (<code class="role-name" translate="no" dir="ltr">roles/binaryauthorization.attestorsVerifier</code>)</p>
<p><a href="/iam/docs/roles-permissions/binaryauthorization#binaryauthorization.attestorsViewer">Binary Authorization Attestor Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/binaryauthorization.attestorsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/binaryauthorization#binaryauthorization.policyAdmin">Binary Authorization Policy Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/binaryauthorization.policyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/binaryauthorization#binaryauthorization.policyEditor">Binary Authorization Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/binaryauthorization.policyEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/binaryauthorization#binaryauthorization.policyEvaluator">Binary Authorization Policy Evaluator</a> (<code class="role-name" translate="no" dir="ltr">roles/binaryauthorization.policyEvaluator</code>)</p>
<p><a href="/iam/docs/roles-permissions/binaryauthorization#binaryauthorization.policyViewer">Binary Authorization Policy Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/binaryauthorization.policyViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/browser#browser">Browser</a> (<code class="role-name" translate="no" dir="ltr">roles/browser</code>)</p>
<p><a href="/iam/docs/roles-permissions/capacityplanner#capacityplanner.planner">Capacity Planner</a> (<code class="role-name" translate="no" dir="ltr">roles/capacityplanner.planner</code>)</p>
<p><a href="/iam/docs/roles-permissions/certificatemanager#certificatemanager.owner">Certificate Manager Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/certificatemanager.owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/ces#ces.agentEditor">Gemini Enterprise for Customer Experience Agent Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/ces.agentEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/ces#ces.appEditor">Gemini Enterprise for Customer Experience App Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/ces.appEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/ces#ces.deploymentEditor">Gemini Enterprise for Customer Experience Deployment Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/ces.deploymentEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/ces#ces.evalsEditor">Gemini Enterprise for Customer Experience Evals Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/ces.evalsEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/ces#ces.guardrailsEditor">Gemini Enterprise for Customer Experience Guardrails Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/ces.guardrailsEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/ces#ces.securitySettingsEditor">Gemini Enterprise for Customer Experience Security Settings Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/ces.securitySettingsEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/ces#ces.toolsEditor">Gemini Enterprise for Customer Experience Tools Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/ces.toolsEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/chronicle#chronicle.dataGovernor">Chronicle API Data Governor</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.dataGovernor</code>)</p>
<p><a href="/iam/docs/roles-permissions/chronicle#chronicle.federationAdmin">Chronicle API Federation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.federationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/chronicle#chronicle.federationViewer">Chronicle API Federation Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.federationViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/chronicle#chronicle.limitedViewer">Chronicle API Limited Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.limitedViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/chronicle#chronicle.restrictedDataAccessViewer">Chronicle API Restricted Data Access Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.restrictedDataAccessViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/chronicle#chronicle.soarAdmin">Chronicle SOAR Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.soarAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/chronicle#chronicle.soarRemoteAgent">Chronicle SOAR Remote Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.soarRemoteAgent</code>)</p>
<p><a href="/iam/docs/roles-permissions/chronicle#chronicle.soarThreatManager">Chronicle SOAR Threat Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.soarThreatManager</code>)</p>
<p><a href="/iam/docs/roles-permissions/chronicle#chronicle.soarVulnerabilityManager">Chronicle SOAR Vulnerability Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.soarVulnerabilityManager</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudaicompanion#cloudaicompanion.codeRepositoryIndexesAdmin">Code Repository Indexes Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudaicompanion.codeRepositoryIndexesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudaicompanion#cloudaicompanion.codeRepositoryIndexesViewer">Code Repository Indexes Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudaicompanion.codeRepositoryIndexesViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudaicompanion#cloudaicompanion.codeToolsAdmin">Gemini Code Assist Tools Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudaicompanion.codeToolsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudaicompanion#cloudaicompanion.codeToolsUser">Gemini Code Assist Tools User</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudaicompanion.codeToolsUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.approver">Cloud Build Approver</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.approver</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.editor">Cloud Build Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.viewer">Cloud Build Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.connectionAdmin">Cloud Build Connection Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.connectionAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.connectionViewer">Cloud Build Connection Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.connectionViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.integrationsEditor">Cloud Build Integrations Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.integrationsEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.integrationsOwner">Cloud Build Integrations Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.integrationsOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.integrationsViewer">Cloud Build Integrations Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.integrationsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.workerPoolEditor">Cloud Build WorkerPool Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.workerPoolEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.workerPoolOwner">Cloud Build WorkerPool Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.workerPoolOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.workerPoolViewer">Cloud Build WorkerPool Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.workerPoolViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/clouddeploy#clouddeploy.approver">Cloud Deploy Approver</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploy.approver</code>)</p>
<p><a href="/iam/docs/roles-permissions/clouddeploy#clouddeploy.customTargetTypeAdmin">Cloud Deploy Custom Target Type Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploy.customTargetTypeAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/clouddeploy#clouddeploy.developer">Cloud Deploy Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploy.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/clouddeploy#clouddeploy.operator">Cloud Deploy Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploy.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/clouddeploy#clouddeploy.policyAdmin">Cloud Deploy Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploy.policyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/clouddeploy#clouddeploy.policyOverrider">Cloud Deploy Policy Overrider</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploy.policyOverrider</code>)</p>
<p><a href="/iam/docs/roles-permissions/clouddeploy#clouddeploy.releaser">Cloud Deploy Releaser</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploy.releaser</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudjobdiscovery#cloudjobdiscovery.jobsEditor">Cloud Talent Solution Job Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudjobdiscovery.jobsEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudjobdiscovery#cloudjobdiscovery.jobsViewer">Cloud Talent Solution Job Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudjobdiscovery.jobsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudjobdiscovery#cloudjobdiscovery.profilesEditor">Cloud Talent Solution Profile Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudjobdiscovery.profilesEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudjobdiscovery#cloudjobdiscovery.profilesViewer">Cloud Talent Solution Profile Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudjobdiscovery.profilesViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.cryptoKeyDecrypter">Cloud KMS CryptoKey Decrypter</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.cryptoKeyDecrypter</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.cryptoKeyDecrypterViaDelegation">Cloud KMS CryptoKey Decrypter Via Delegation</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.cryptoKeyDecrypterViaDelegation</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.cryptoKeyEncrypter">Cloud KMS CryptoKey Encrypter</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.cryptoKeyEncrypter</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.cryptoKeyEncrypterDecrypterViaDelegation">Cloud KMS CryptoKey Encrypter/Decrypter Via Delegation</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.cryptoKeyEncrypterDecrypterViaDelegation</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.cryptoKeyEncrypterViaDelegation">Cloud KMS CryptoKey Encrypter Via Delegation</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.cryptoKeyEncrypterViaDelegation</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.cryptoOperator">Cloud KMS Crypto Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.cryptoOperator</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.decapsulator">Cloud KMS CryptoKey Decapsulator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.decapsulator</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.ekmConnectionsAdmin">Cloud KMS EkmConnections Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.ekmConnectionsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.expertPqcSigner">Cloud KMS Expert PQ Asymmetric Signing Key Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.expertPqcSigner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.expertRawAesCbc">Cloud KMS Expert Raw AES-CBC Key Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.expertRawAesCbc</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.expertRawAesCtr">Cloud KMS Expert Raw AES-CTR Key Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.expertRawAesCtr</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.expertRawPKCS1">Cloud KMS Expert Raw PKCS#1 Key Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.expertRawPKCS1</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.importer">Cloud KMS Importer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.importer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.publicKeyViewer">Cloud KMS CryptoKey Public Key Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.publicKeyViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.signer">Cloud KMS CryptoKey Signer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.signer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.signerVerifier">Cloud KMS CryptoKey Signer/Verifier</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.signerVerifier</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.verifier">Cloud KMS CryptoKey Verifier</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.verifier</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudmigration#cloudmigration.inframanager">Velostrata Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudmigration.inframanager</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudnumberregistry#cloudnumberregistry.ipamAdmin">Cloud Number Registry IPAM Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudnumberregistry.ipamAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudnumberregistry#cloudnumberregistry.ipamViewer">Cloud Number Registry IPAM Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudnumberregistry.ipamViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudprivatecatalog#cloudprivatecatalog.consumer">Catalog Consumer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudprivatecatalog.consumer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudprivatecatalog#cloudprivatecatalogproducer.manager">Catalog Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudprivatecatalogproducer.manager</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudprivatecatalog#cloudprivatecatalogproducer.orgAdmin">Catalog Org Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudprivatecatalogproducer.orgAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudprofiler#cloudprofiler.user">Cloud Profiler User</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudprofiler.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.jobRunner">Cloud Scheduler Job Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.jobRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsupport#cloudsupport.advisorySupportEditor">Advisory Support Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsupport.advisorySupportEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsupport#cloudsupport.advisorySupportViewer">Advisory Support Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsupport.advisorySupportViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsupport#cloudsupport.techSupportEditor">Tech Support Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsupport.techSupportEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsupport#cloudsupport.techSupportViewer">Tech Support Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsupport.techSupportViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.enqueuer">Cloud Tasks Enqueuer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.enqueuer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.queueAdmin">Cloud Tasks Queue Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.queueAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.taskDeleter">Cloud Tasks Task Deleter</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.taskDeleter</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.taskRunner">Cloud Tasks Task Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.taskRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtestservice#cloudtestservice.directAccessAdmin">Firebase Test Lab Direct Access Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtestservice.directAccessAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtestservice#cloudtestservice.directAccessViewer">Firebase Test Lab Direct Access Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtestservice.directAccessViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtestservice#cloudtestservice.testAdmin">Firebase Test Lab Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtestservice.testAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtestservice#cloudtestservice.testViewer">Firebase Test Lab Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtestservice.testViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercebusinessenablement#commercebusinessenablement.paymentConfigAdmin">Commerce Business Enablement PaymentConfig Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/commercebusinessenablement.paymentConfigAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercebusinessenablement#commercebusinessenablement.paymentConfigViewer">Commerce Business Enablement PaymentConfig Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/commercebusinessenablement.paymentConfigViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercebusinessenablement#commercebusinessenablement.resellerDiscountAdmin">Commerce Business Enablement Reseller Discount Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/commercebusinessenablement.resellerDiscountAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercebusinessenablement#commercebusinessenablement.resellerDiscountViewer">Commerce Business Enablement Reseller Discount Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/commercebusinessenablement.resellerDiscountViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/commerceorggovernance#commerceorggovernance.user">Governed Marketplace User</a> (<code class="role-name" translate="no" dir="ltr">roles/commerceorggovernance.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercepricemanagement#commercepricemanagement.eventsViewer">Commerce Price Management Events Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/commercepricemanagement.eventsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercepricemanagement#commercepricemanagement.privateOffersAdmin">Commerce Price Management Private Offers Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/commercepricemanagement.privateOffersAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectAdmin">Environment and Storage Object Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectUser">Environment and Storage Object User</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectViewer">Environment and Storage Object Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.imageUser">Compute Image User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.imageUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.loadBalancerServiceUser">Compute Load Balancer Services User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.loadBalancerServiceUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgFirewallPolicyAdmin">Compute Organization Firewall Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgFirewallPolicyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgFirewallPolicyUser">Compute Organization Firewall Policy User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgFirewallPolicyUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgSecurityPolicyAdmin">Compute Organization Security Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgSecurityPolicyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgSecurityPolicyUser">Compute Organization Security Policy User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgSecurityPolicyUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgSecurityResourceAdmin">Compute Organization Resource Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgSecurityResourceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.packetMirroringAdmin">Compute packet mirroring admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.packetMirroringAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.packetMirroringUser">Compute packet mirroring user</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.packetMirroringUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.publicIpAdmin">Compute Public IP Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.publicIpAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.vmExtensionPolicyAdmin">Compute VM extension policy admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.vmExtensionPolicyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.vmExtensionPolicyViewer">Compute VM extension policy viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.vmExtensionPolicyViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.xpnAdmin">Compute Shared VPC Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.xpnAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/configdelivery#configdelivery.configDeliveryAdmin">ConfigDelivery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/configdelivery.configDeliveryAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/configdelivery#configdelivery.configDeliveryViewer">ConfigDelivery Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/configdelivery.configDeliveryViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/configdelivery#configdelivery.resourceBundlePublisher">Config Delivery Resource Bundle Publisher</a> (<code class="role-name" translate="no" dir="ltr">roles/configdelivery.resourceBundlePublisher</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.entitlementManager">Consumer Procurement Entitlement Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.entitlementManager</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.entitlementViewer">Consumer Procurement Entitlement Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.entitlementViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.procurementAdmin">Consumer Procurement Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.procurementAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.procurementViewer">Consumer Procurement Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.procurementViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/container#container.cloudKmsKeyUser">Kubernetes Engine KMS Crypto Key User</a> (<code class="role-name" translate="no" dir="ltr">roles/container.cloudKmsKeyUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.notes.editor">Container Analysis Notes Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.notes.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.notes.viewer">Container Analysis Notes Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.notes.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.occurrences.editor">Container Analysis Occurrences Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.occurrences.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.occurrences.viewer">Container Analysis Occurrences Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.occurrences.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/contentwarehouse#contentwarehouse.documentAdmin">Content Warehouse Document Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/contentwarehouse.documentAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/contentwarehouse#contentwarehouse.documentCreator">Content Warehouse document creator</a> (<code class="role-name" translate="no" dir="ltr">roles/contentwarehouse.documentCreator</code>)</p>
<p><a href="/iam/docs/roles-permissions/contentwarehouse#contentwarehouse.documentEditor">Content Warehouse Document Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/contentwarehouse.documentEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/contentwarehouse#contentwarehouse.documentSchemaViewer">Content Warehouse document schema viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/contentwarehouse.documentSchemaViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/contentwarehouse#contentwarehouse.documentViewer">Content Warehouse Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/contentwarehouse.documentViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/databaseinsights#databaseinsights.monitoringViewer">Database Insights monitoring viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/databaseinsights.monitoringViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/databaseinsights#databaseinsights.recommendationViewer">Database Insights recommendation viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/databaseinsights.recommendationViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/databasesconsole#databasesconsole.studioQueryAdmin">Studio Query Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/databasesconsole.studioQueryAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/databasesconsole#databasesconsole.studioQueryUser">Studio Query User</a> (<code class="role-name" translate="no" dir="ltr">roles/databasesconsole.studioQueryUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.categoryAdmin">Policy Tag Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.categoryAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.dataSteward">DataCatalog Data Steward</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.dataSteward</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.entryGroupCreator">DataCatalog EntryGroup Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.entryGroupCreator</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.entryGroupOwner">DataCatalog EntryGroup Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.entryGroupOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.entryOwner">DataCatalog Entry Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.entryOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.entryViewer">DataCatalog Entry Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.entryViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.migrationConfigAdmin">DataCatalog Migration Config Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.migrationConfigAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.searchAdmin">DataCatalog Search Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.searchAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.tagTemplateOwner">Data Catalog TagTemplate Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.tagTemplateOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.tagTemplateUser">Data Catalog TagTemplate User</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.tagTemplateUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.tagTemplateViewer">Data Catalog TagTemplate Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.tagTemplateViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataconnectors#dataconnectors.connectorAdmin">Connector Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataconnectors.connectorAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.developer">Dataflow Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataform#dataform.codeCommenter">Code Commenter</a> (<code class="role-name" translate="no" dir="ltr">roles/dataform.codeCommenter</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataform#dataform.codeCreator">Code Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/dataform.codeCreator</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataform#dataform.codeEditor">Code Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dataform.codeEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataform#dataform.codeOwner">Code Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/dataform.codeOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataform#dataform.codeViewer">Code Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataform.codeViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataform#dataform.teamFolderCommenter">Team Folder Commenter</a> (<code class="role-name" translate="no" dir="ltr">roles/dataform.teamFolderCommenter</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataform#dataform.teamFolderContributor">Team Folder Contributor</a> (<code class="role-name" translate="no" dir="ltr">roles/dataform.teamFolderContributor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataform#dataform.teamFolderOwner">Team Folder Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/dataform.teamFolderOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataform#dataform.teamFolderViewer">Team Folder Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataform.teamFolderViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/datafusion#datafusion.accessor">Cloud Data Fusion Accessor</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.accessor</code>)</p>
<p><a href="/iam/docs/roles-permissions/datafusion#datafusion.developer">Cloud Data Fusion Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/datafusion#datafusion.operator">Cloud Data Fusion Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/datalineage#datalineage.producer">Data Lineage Events Producer</a> (<code class="role-name" translate="no" dir="ltr">roles/datalineage.producer</code>)</p>
<p><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.invoker">Data pipelines Invoker</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.invoker</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.aspectTypeOwner">Dataplex Aspect Type Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.aspectTypeOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.aspectTypeUser">Dataplex Aspect Type User</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.aspectTypeUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.catalogAdmin">Dataplex Catalog Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.catalogAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.catalogEditor">Dataplex Catalog Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.catalogEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.catalogViewer">Dataplex Catalog Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.catalogViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.contentAdmin">Dataplex Content Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.contentAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.contentCreator">Dataplex Content Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.contentCreator</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.contentEditor">Dataplex Content Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.contentEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.contentUser">Dataplex Content User</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.contentUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.contentViewer">Dataplex Content Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.contentViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.dataDomainAdmin">Dataplex Data Domain Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.dataDomainAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.dataDomainEditor">Dataplex Data Domain Configuration Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.dataDomainEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.dataDomainViewer">Dataplex Data Domain Configuration Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.dataDomainViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.dataProductsAdmin">Dataplex Data Products Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.dataProductsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.dataProductsConsumer">Dataplex Data Products Consumer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.dataProductsConsumer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.dataProductsEditor">Dataplex Data Products Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.dataProductsEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.dataProductsViewer">Dataplex Data Products Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.dataProductsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.entryGroupExporter">Dataplex Entry Group Exporter</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.entryGroupExporter</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.entryGroupImporter">Dataplex Entry Group Importer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.entryGroupImporter</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.entryGroupOwner">Dataplex Entry Group Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.entryGroupOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.entryLinkTypeOwner">Dataplex Entry Link Type Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.entryLinkTypeOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.entryLinkTypeUser">Dataplex Entry Link Type User</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.entryLinkTypeUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.entryOwner">Dataplex Entry and EntryLink Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.entryOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.entryTypeOwner">Dataplex Entry Type Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.entryTypeOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.entryTypeUser">Dataplex Entry Type User</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.entryTypeUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.metadataFeedOwner">Dataplex Metadata Feed Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.metadataFeedOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.metadataFeedViewer">Dataplex Metadata Feed Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.metadataFeedViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.metadataJobOwner">Dataplex Metadata Job Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.metadataJobOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.metadataJobViewer">Dataplex Metadata Job Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.metadataJobViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.metadataReader">Dataplex Metadata Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.metadataReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.metadataWriter">Dataplex Metadata Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.metadataWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataprep#dataprep.projects.user">Dataprep User</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.projects.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.hubAgent">Dataproc Hub Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.hubAgent</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.serverlessEditor">Dataproc Serverless Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serverlessEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.serverlessViewer">Dataproc Serverless Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serverlessViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firestore#datastore.bulkAdmin">Cloud Datastore Bulk Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/datastore.bulkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firestore#datastore.importExportAdmin">Cloud Datastore Import Export Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/datastore.importExportAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firestore#datastore.indexAdmin">Cloud Datastore Index Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/datastore.indexAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firestore#datastore.keyVisualizerViewer">Cloud Datastore Key Visualizer Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/datastore.keyVisualizerViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/datastudio#datastudio.contentManager">Data Studio Workspace Content Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/datastudio.contentManager</code>)</p>
<p><a href="/iam/docs/roles-permissions/datastudio#datastudio.contributor">Data Studio Workspace Contributor</a> (<code class="role-name" translate="no" dir="ltr">roles/datastudio.contributor</code>)</p>
<p><a href="/iam/docs/roles-permissions/datastudio#datastudio.manager">Data Studio Workspace Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/datastudio.manager</code>)</p>
<p><a href="/iam/docs/roles-permissions/datastudio#datastudio.workspaceViewer">Data Studio Workspace Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/datastudio.workspaceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dellemccloudonefs#dellemccloudonefs.user">Dell EMC Cloud OneFS User</a> (<code class="role-name" translate="no" dir="ltr">roles/dellemccloudonefs.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.typeEditor">Deployment Manager Type Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.typeEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.typeViewer">Deployment Manager Type Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.typeViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.applicationAdmin">Application Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.applicationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.applicationEditor">Application Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.applicationEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.applicationViewer">Application Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.applicationViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.user">Application Design Center User</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/developerconnect#developerconnect.insightsAdmin">Developer Connect Insights Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/developerconnect.insightsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/developerconnect#developerconnect.insightsViewer">Developer Connect Insights Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/developerconnect.insightsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/developerconnect#developerconnect.oauthAdmin">Developer Connect OAuth Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/developerconnect.oauthAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/developerconnect#developerconnect.oauthUser">Developer Connect OAuth User</a> (<code class="role-name" translate="no" dir="ltr">roles/developerconnect.oauthUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/developerconnect#developerconnect.user">Developer Connect User</a> (<code class="role-name" translate="no" dir="ltr">roles/developerconnect.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/dialogflow#dialogflow.aamAdmin">CX Premium Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dialogflow.aamAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dialogflow#dialogflow.aamConversationalArchitect">CX Premium Conversational Architect</a> (<code class="role-name" translate="no" dir="ltr">roles/dialogflow.aamConversationalArchitect</code>)</p>
<p><a href="/iam/docs/roles-permissions/dialogflow#dialogflow.aamDialogDesigner">CX Premium Dialog Designer</a> (<code class="role-name" translate="no" dir="ltr">roles/dialogflow.aamDialogDesigner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dialogflow#dialogflow.aamLeadDialogDesigner">CX Premium Lead Dialog Designer</a> (<code class="role-name" translate="no" dir="ltr">roles/dialogflow.aamLeadDialogDesigner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dialogflow#dialogflow.aamViewer">CX Premium Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dialogflow.aamViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dialogflow#dialogflow.consoleAgentEditor">Dialogflow Console Agent Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dialogflow.consoleAgentEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dialogflow#dialogflow.consoleSimulatorUser">Dialogflow Console Simulator User</a> (<code class="role-name" translate="no" dir="ltr">roles/dialogflow.consoleSimulatorUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/dialogflow#dialogflow.consoleSmartMessagingAllowlistEditor">Dialogflow Console Smart Messaging Allowlist Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dialogflow.consoleSmartMessagingAllowlistEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dialogflow#dialogflow.reader">Dialogflow API Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/dialogflow.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceAdmin">Gemini Enterprise Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceEditor">Gemini Enterprise Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceRestrictedUser">Gemini Enterprise Restricted User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceRestrictedUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceUser">Gemini Enterprise User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceViewer">Gemini Enterprise Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.notebookLmOwner">Cloud NotebookLM Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.notebookLmOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.notebookLmUser">Cloud NotebookLM User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.notebookLmUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.podcastApiUser">Podcast API User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.podcastApiUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.connectionsAdmin">DLP Connections Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.connectionsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.subscriptionsAdmin">DLP Subscription Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.subscriptionsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.reader">DNS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/earth#earth.subscriptionsAdmin">Earth Subscriptions Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/earth.subscriptionsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/earth#earth.subscriptionsViewer">Earth Subscriptions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/earth.subscriptionsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/earthengine#earthengine.appsPublisher">Earth Engine Apps Publisher</a> (<code class="role-name" translate="no" dir="ltr">roles/earthengine.appsPublisher</code>)</p>
<p><a href="/iam/docs/roles-permissions/earthengine#earthengine.writer">Earth Engine Resource Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/earthengine.writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.machineUser">Edge Container Machine User</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.machineUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.offlineCredentialUser">Edge Container Cluster offline Credential User</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.offlineCredentialUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/eventarc#eventarc.connectionPublisher">Eventarc Connection Publisher</a> (<code class="role-name" translate="no" dir="ltr">roles/eventarc.connectionPublisher</code>)</p>
<p><a href="/iam/docs/roles-permissions/eventarc#eventarc.developer">Eventarc Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/eventarc.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/eventarc#eventarc.publisher">Eventarc Publisher</a> (<code class="role-name" translate="no" dir="ltr">roles/eventarc.publisher</code>)</p>
<p><a href="/iam/docs/roles-permissions/faulttesting#faulttesting.operator">Fault Testing Admin/Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/faulttesting.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.analyticsAdmin">Firebase Analytics Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.analyticsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.analyticsViewer">Firebase Analytics Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.analyticsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.growthAdmin">Firebase Grow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.growthAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.growthViewer">Firebase Grow Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.growthViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.qualityAdmin">Firebase Quality Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.qualityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.qualityViewer">Firebase Quality Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.qualityViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.developer">Firebase App Hosting Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebasecrash#firebasecrash.symbolMappingsAdmin">Firebase Crash Symbol Uploader</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasecrash.symbolMappingsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseextensions#firebaseextensions.developer">Firebase Extensions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseextensions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseextensionspublisher#firebaseextensionspublisher.extensionsAdmin">Firebase Extensions Publisher - Extensions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseextensionspublisher.extensionsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseextensionspublisher#firebaseextensionspublisher.extensionsViewer">Firebase Extensions Publisher - Extensions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseextensionspublisher.extensionsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/fleetengine#fleetengine.deliveryAdmin">Fleet Engine Delivery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/fleetengine.deliveryAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/fleetengine#fleetengine.deliverySuperUser">Fleet Engine Delivery Super User</a> (<code class="role-name" translate="no" dir="ltr">roles/fleetengine.deliverySuperUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/fleetengine#fleetengine.ondemandAdmin">Fleet Engine On-Demand Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/fleetengine.ondemandAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/fleetengine#fleetengine.serviceSuperUser">Fleet Engine Service Super User</a> (<code class="role-name" translate="no" dir="ltr">roles/fleetengine.serviceSuperUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/gdchardwaremanagement#gdchardwaremanagement.operator">GDC Hardware Management Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/gdchardwaremanagement.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/gdchardwaremanagement#gdchardwaremanagement.reader">GDC Hardware Management Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/gdchardwaremanagement.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.investigationAdmin">Gemini Cloud Assist Investigation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.investigationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.investigationCreator">Gemini Cloud Assist Investigation Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.investigationCreator</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.investigationEditor">Gemini Cloud Assist Investigation Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.investigationEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.investigationUser">Gemini Cloud Assist Investigation User</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.investigationUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.investigationViewer">Gemini Cloud Assist Investigation Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.investigationViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkebackup#gkebackup.backupAdmin">Backup for GKE Backup Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/gkebackup.backupAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkebackup#gkebackup.restoreAdmin">Backup for GKE Restore Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/gkebackup.restoreAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.scopeEditorProjectLevel">Fleet Project-level Scope Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.scopeEditorProjectLevel</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.scopeViewerProjectLevel">Fleet Project-level Scope Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.scopeViewerProjectLevel</code>)</p>
<p><a href="/iam/docs/roles-permissions/gsuiteaddons#gsuiteaddons.developer">Google Workspace Add-ons Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/gsuiteaddons.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/gsuiteaddons#gsuiteaddons.reader">Google Workspace Add-ons Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/gsuiteaddons.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/gsuiteaddons#gsuiteaddons.tester">Google Workspace Add-ons Tester</a> (<code class="role-name" translate="no" dir="ltr">roles/gsuiteaddons.tester</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.annotationEditor">Healthcare Annotation Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.annotationEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.annotationReader">Healthcare Annotation Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.annotationReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.annotationStoreAdmin">Healthcare Annotation Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.annotationStoreAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.annotationStoreViewer">Healthcare Annotation Store Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.annotationStoreViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.attributeDefinitionEditor">Healthcare Attribute Definition Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.attributeDefinitionEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.attributeDefinitionReader">Healthcare Attribute Definition Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.attributeDefinitionReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.consentArtifactAdmin">Healthcare Consent Artifact Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.consentArtifactAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.consentArtifactEditor">Healthcare Consent Artifact Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.consentArtifactEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.consentArtifactReader">Healthcare Consent Artifact Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.consentArtifactReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.consentEditor">Healthcare Consent Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.consentEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.consentReader">Healthcare Consent Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.consentReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.consentStoreAdmin">Healthcare Consent Store Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.consentStoreAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.consentStoreViewer">Healthcare Consent Store Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.consentStoreViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.datasetAdmin">Healthcare Dataset Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.datasetAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.datasetViewer">Healthcare Dataset Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.datasetViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.dicomEditor">Healthcare DICOM Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.dicomEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.dicomStoreAdmin">Healthcare DICOM Store Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.dicomStoreAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.dicomStoreViewer">Healthcare DICOM Store Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.dicomStoreViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.dicomViewer">Healthcare DICOM Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.dicomViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.fhirResourceEditor">Healthcare FHIR Resource Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.fhirResourceEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.fhirResourceReader">Healthcare FHIR Resource Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.fhirResourceReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.fhirStoreAdmin">Healthcare FHIR Store Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.fhirStoreAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.fhirStoreViewer">Healthcare FHIR Store Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.fhirStoreViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.hl7V2Consumer">Healthcare HL7v2 Message Consumer</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.hl7V2Consumer</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.hl7V2Editor">Healthcare HL7v2 Message Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.hl7V2Editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.hl7V2Ingest">Healthcare HL7v2 Message Ingest</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.hl7V2Ingest</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.hl7V2StoreAdmin">Healthcare HL7v2 Store Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.hl7V2StoreAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.hl7V2StoreViewer">Healthcare HL7v2 Store Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.hl7V2StoreViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.nlpServiceViewer">Healthcare NLP Service Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.nlpServiceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.userDataMappingEditor">Healthcare User Data Mapping Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.userDataMappingEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.userDataMappingReader">Healthcare User Data Mapping Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.userDataMappingReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.oauthClientAdmin">IAM OAuth Client Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.oauthClientAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.oauthClientViewer">IAM OAuth Client Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.oauthClientViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.organizationRoleAdmin">Organization Role Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.organizationRoleAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.organizationRoleViewer">Organization Role Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.organizationRoleViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountDeleter">Delete Service Accounts</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountDeleter</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolAdmin">IAM Workload Identity Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolViewer">IAM Workload Identity Pool Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/integrations#integrations.apigeeIntegrationAdminRole">Apigee Integration Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.apigeeIntegrationAdminRole</code>)</p>
<p><a href="/iam/docs/roles-permissions/integrations#integrations.apigeeIntegrationDeployerRole">Apigee Integration Deployer</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.apigeeIntegrationDeployerRole</code>)</p>
<p><a href="/iam/docs/roles-permissions/integrations#integrations.apigeeIntegrationEditorRole">Apigee Integration Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.apigeeIntegrationEditorRole</code>)</p>
<p><a href="/iam/docs/roles-permissions/integrations#integrations.apigeeIntegrationInvokerRole">Apigee Integration Invoker</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.apigeeIntegrationInvokerRole</code>)</p>
<p><a href="/iam/docs/roles-permissions/integrations#integrations.apigeeIntegrationsViewer">Apigee Integration Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.apigeeIntegrationsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/integrations#integrations.apigeeSuspensionResolver">Apigee Integration Approver</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.apigeeSuspensionResolver</code>)</p>
<p><a href="/iam/docs/roles-permissions/integrations#integrations.certificateViewer">Certificate Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.certificateViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/integrations#integrations.integrationAdmin">Application Integration Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.integrationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/integrations#integrations.integrationDeployer">Application Integration Deployer</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.integrationDeployer</code>)</p>
<p><a href="/iam/docs/roles-permissions/integrations#integrations.integrationEditor">Application Integration Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.integrationEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/integrations#integrations.integrationInvoker">Application Integration Invoker</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.integrationInvoker</code>)</p>
<p><a href="/iam/docs/roles-permissions/integrations#integrations.integrationViewer">Application Integration Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.integrationViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/integrations#integrations.sfdcInstanceAdmin">Application Integration SFDC Instance Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.sfdcInstanceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/integrations#integrations.sfdcInstanceEditor">Application Integration SFDC Instance Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.sfdcInstanceEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/integrations#integrations.sfdcInstanceViewer">Application Integration SFDC Instance Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.sfdcInstanceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/integrations#integrations.suspensionResolver">Application Integration Approver</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.suspensionResolver</code>)</p>
<p><a href="/iam/docs/roles-permissions/issuerswitch#issuerswitch.accountManagerAdmin">Issuerswitch Account Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/issuerswitch.accountManagerAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/issuerswitch#issuerswitch.accountManagerTransactionsAdmin">Issuerswitch Account Manager Transactions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/issuerswitch.accountManagerTransactionsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/issuerswitch#issuerswitch.accountManagerTransactionsViewer">Issuerswitch Account Manager Transactions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/issuerswitch.accountManagerTransactionsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/issuerswitch#issuerswitch.issuerParticipantsAdmin">Issuerswitch Participants Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/issuerswitch.issuerParticipantsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/issuerswitch#issuerswitch.resolutionsAdmin">Issuerswitch Resolutions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/issuerswitch.resolutionsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/issuerswitch#issuerswitch.rulesAdmin">Issuerswitch Rules Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/issuerswitch.rulesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/issuerswitch#issuerswitch.rulesViewer">Issuerswitch Rules Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/issuerswitch.rulesViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/issuerswitch#issuerswitch.transactionsViewer">Issuerswitch Transactions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/issuerswitch.transactionsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/looker#looker.instanceUser">Looker Instance User</a> (<code class="role-name" translate="no" dir="ltr">roles/looker.instanceUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/datastudio#lookerstudio.lookerAdmin">Looker Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/lookerstudio.lookerAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/datastudio#lookerstudio.proManager">Looker Studio Pro Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/lookerstudio.proManager</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedflink#managedflink.developer">Managed Flink Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/managedflink.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.backupAdmin">Google Cloud Managed Identities Backup Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.backupAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.backupViewer">Google Cloud Managed Identities Backup Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.backupViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.domainAdmin">Google Cloud Managed Identities Domain Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.domainAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.peeringAdmin">Google Cloud Managed Identities Peering Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.peeringAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.peeringViewer">Google Cloud Managed Identities Peering Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.peeringViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.client">Managed Kafka Client</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.client</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.clusterEditor">Managed Kafka Cluster Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.clusterEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.connectorEditor">Managed Kafka Connector Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.connectorEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.consumerGroupEditor">Managed Kafka Consumer Group Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.consumerGroupEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.topicEditor">Managed Kafka Topic Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.topicEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/mandiant#mandiant.attackSurfaceManagementEditor">Mandiant Attack Surface Management Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/mandiant.attackSurfaceManagementEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/mandiant#mandiant.attackSurfaceManagementViewer">Mandiant Attack Surface Management Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/mandiant.attackSurfaceManagementViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/mandiant#mandiant.digitalThreatMonitoringEditor">Mandiant Digital Threat Monitoring Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/mandiant.digitalThreatMonitoringEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/mandiant#mandiant.digitalThreatMonitoringViewer">Mandiant Digital Threat Monitoring Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/mandiant.digitalThreatMonitoringViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/mandiant#mandiant.expertiseOnDemandEditor">Mandiant Expertise On Demand Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/mandiant.expertiseOnDemandEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/mandiant#mandiant.expertiseOnDemandViewer">Mandiant Expertise On Demand Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/mandiant.expertiseOnDemandViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/mandiant#mandiant.threatIntelEditor">Mandiant Threat Intel Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/mandiant.threatIntelEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/mandiant#mandiant.threatIntelViewer">Mandiant Threat Intel Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/mandiant.threatIntelViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/mandiant#mandiant.validationEditor">Mandiant Validation Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/mandiant.validationEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/mandiant#mandiant.validationViewer">Mandiant Validation Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/mandiant.validationViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/mapsanalytics#mapsanalytics.mobilitySolutionsOverageViewer">Mobility Solutions Overages Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/mapsanalytics.mobilitySolutionsOverageViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/metastore#metastore.metadataOperator">Dataproc Metastore Metadata Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/metastore.metadataOperator</code>)</p>
<p><a href="/iam/docs/roles-permissions/metastore#metastore.user">Dataproc Metastore Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/metastore.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/migrationcenter#migrationcenter.discoveryClientRegistrator">Migration Center Discovery Client Registrator</a> (<code class="role-name" translate="no" dir="ltr">roles/migrationcenter.discoveryClientRegistrator</code>)</p>
<p><a href="/iam/docs/roles-permissions/ml#ml.developer">AI Platform Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/modelarmor#modelarmor.calloutUser">Model Armor Callout User</a> (<code class="role-name" translate="no" dir="ltr">roles/modelarmor.calloutUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/modelarmor#modelarmor.floorSettingsAdmin">Model Armor Floor Setting Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/modelarmor.floorSettingsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/modelarmor#modelarmor.floorSettingsViewer">Model Armor Floor Setting Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/modelarmor.floorSettingsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/modelarmor#modelarmor.user">Model Armor User</a> (<code class="role-name" translate="no" dir="ltr">roles/modelarmor.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#monitoring.metricsScopesAdmin">Monitoring Metrics Scopes Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/monitoring.metricsScopesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#monitoring.metricsScopesViewer">Monitoring Metrics Scopes Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/monitoring.metricsScopesViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/nestconsole#nestconsole.homeDeveloperAdmin">Google Home Developer Console Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/nestconsole.homeDeveloperAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/nestconsole#nestconsole.homeDeveloperEditor">Google Home Developer Console Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/nestconsole.homeDeveloperEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/nestconsole#nestconsole.homeDeveloperViewer">Google Home Developer Console Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/nestconsole.homeDeveloperViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkconnectivity#networkconnectivity.consumerNetworkAdmin">Service Automation Consumer Network Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networkconnectivity.consumerNetworkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkconnectivity#networkconnectivity.groupAdmin">Group Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networkconnectivity.groupAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkconnectivity#networkconnectivity.hubAdmin">Hub &amp; Spoke Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networkconnectivity.hubAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkconnectivity#networkconnectivity.hubViewer">Hub &amp; Spoke Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/networkconnectivity.hubViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkconnectivity#networkconnectivity.multicloudDataTransferConfigAdmin">Multicloud Data Transfer Config Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networkconnectivity.multicloudDataTransferConfigAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkconnectivity#networkconnectivity.multicloudDataTransferConfigViewer">Multicloud Data Transfer Config Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/networkconnectivity.multicloudDataTransferConfigViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkconnectivity#networkconnectivity.multicloudDataTransferDestinationAdmin">Destination Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networkconnectivity.multicloudDataTransferDestinationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkconnectivity#networkconnectivity.multicloudDataTransferDestinationViewer">Destination Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/networkconnectivity.multicloudDataTransferDestinationViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkconnectivity#networkconnectivity.regionalEndpointAdmin">Regional Endpoint Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networkconnectivity.regionalEndpointAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkconnectivity#networkconnectivity.regionalEndpointViewer">Regional Endpoint Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/networkconnectivity.regionalEndpointViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkconnectivity#networkconnectivity.serviceClassUser">Service Class User</a> (<code class="role-name" translate="no" dir="ltr">roles/networkconnectivity.serviceClassUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkconnectivity#networkconnectivity.serviceProducerAdmin">Service Automation Service Producer Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networkconnectivity.serviceProducerAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkconnectivity#networkconnectivity.spokeAdmin">Spoke Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networkconnectivity.spokeAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkconnectivity#networkconnectivity.transportAdmin">Transport Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networkconnectivity.transportAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkconnectivity#networkconnectivity.transportViewer">Transport Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/networkconnectivity.transportViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkmanagement#networkmanagement.CloudNetworkInsightsAdmin">Cloud Network Insights Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networkmanagement.CloudNetworkInsightsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkmanagement#networkmanagement.CloudNetworkInsightsEditor">Cloud Network Insights Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/networkmanagement.CloudNetworkInsightsEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkmanagement#networkmanagement.CloudNetworkInsightsViewer">Cloud Network Insights Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/networkmanagement.CloudNetworkInsightsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/networksecurity#networksecurity.dnsThreatDetectorAdmin">DNS Threat Detector Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networksecurity.dnsThreatDetectorAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networksecurity#networksecurity.dnsThreatDetectorViewer">DNS Threat Detector Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/networksecurity.dnsThreatDetectorViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/networksecurity#networksecurity.firewallEndpointAdmin">Firewall Endpoint Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networksecurity.firewallEndpointAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networksecurity#networksecurity.interceptDeploymentAdmin">Intercept Deployment Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networksecurity.interceptDeploymentAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networksecurity#networksecurity.interceptDeploymentViewer">Intercept Deployment Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/networksecurity.interceptDeploymentViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/networksecurity#networksecurity.interceptEndpointAdmin">Intercept Endpoint Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networksecurity.interceptEndpointAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networksecurity#networksecurity.interceptEndpointViewer">Intercept Endpoint Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/networksecurity.interceptEndpointViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/networksecurity#networksecurity.mirroringDeploymentAdmin">Mirroring Deployment Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networksecurity.mirroringDeploymentAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networksecurity#networksecurity.mirroringDeploymentViewer">Mirroring Deployment Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/networksecurity.mirroringDeploymentViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/networksecurity#networksecurity.mirroringEndpointAdmin">Mirroring Endpoint Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networksecurity.mirroringEndpointAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networksecurity#networksecurity.mirroringEndpointViewer">Mirroring Endpoint Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/networksecurity.mirroringEndpointViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/networksecurity#networksecurity.securityProfileAdmin">Security Profile Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networksecurity.securityProfileAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkservices#networkservices.GoogleTagGatewayPolicyAdmin">Google Tag Gateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networkservices.GoogleTagGatewayPolicyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkservices#networkservices.serviceExtensionsAdmin">Service Extensions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networkservices.serviceExtensionsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkservices#networkservices.serviceExtensionsViewer">Service Extensions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/networkservices.serviceExtensionsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.legacyAdmin">Notebooks Legacy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.legacyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.legacyViewer">Notebooks Legacy Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.legacyViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.runner">Notebooks Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.runner</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.autonomousDatabaseAdmin">Oracle Database@Google Cloud Autonomous Database Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.autonomousDatabaseAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.autonomousDatabaseViewer">Oracle Database@Google Cloud Autonomous Database Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.autonomousDatabaseViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.cloudExadataInfrastructureAdmin">Oracle Database@Google Cloud Exadata Infrastructure Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.cloudExadataInfrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.cloudExadataInfrastructureUser">Oracle Database@Google Cloud Exadata Infrastructure User</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.cloudExadataInfrastructureUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.cloudExadataInfrastructureViewer">Oracle Database@Google Cloud Exadata Infrastructure Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.cloudExadataInfrastructureViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.cloudVmClusterAdmin">Oracle Database@Google Cloud VM Cluster Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.cloudVmClusterAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.cloudVmClusterViewer">Oracle Database@Google Cloud VM Cluster Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.cloudVmClusterViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.databaseViewer">Oracle Database@Google Cloud Container Database Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.databaseViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.dbSystemAdmin">Oracle Database@Google Cloud DB System Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.dbSystemAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.dbSystemViewer">Oracle Database@Google Cloud DB System Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.dbSystemViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.exadbVmClusterAdmin">Oracle Database@Google Cloud Exadata Database Service on Exascale Infrastructure VM Cluster Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.exadbVmClusterAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.exadbVmClusterViewer">Oracle Database@Google Cloud Exadata Database Service on Exascale Infrastructure VM Cluster Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.exadbVmClusterViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.exascaleDbStorageVaultAdmin">Oracle Database@Google Cloud Exadata Database Service on Exascale Infrastructure Storage Vault Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.exascaleDbStorageVaultAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.exascaleDbStorageVaultUser">Oracle Database@Google Cloud Exadata Database Service on Exascale Infrastructure Storage Vault User</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.exascaleDbStorageVaultUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.exascaleDbStorageVaultViewer">Oracle Database@Google Cloud Exadata Database Service on Exascale Infrastructure Storage Vault Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.exascaleDbStorageVaultViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.goldenGateConnectionAdmin">Oracle Database@Google Cloud GoldenGate Connection Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.goldenGateConnectionAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.goldenGateConnectionAssignmentAdmin">Oracle Database@Google Cloud GoldenGate Connection Assignment Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.goldenGateConnectionAssignmentAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.goldenGateConnectionAssignmentViewer">Oracle Database@Google Cloud GoldenGate Connection Assignment Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.goldenGateConnectionAssignmentViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.goldenGateConnectionViewer">Oracle Database@Google Cloud GoldenGate Connection Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.goldenGateConnectionViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.goldenGateConnectionsUser">Oracle Database@Google GoldenGate Connections User</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.goldenGateConnectionsUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.goldenGateDeploymentAdmin">Oracle Database@Google Cloud GoldenGate Deployment Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.goldenGateDeploymentAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.goldenGateDeploymentViewer">Oracle Database@Google Cloud GoldenGate Deployment Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.goldenGateDeploymentViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.goldenGateDeploymentsUser">Oracle Database@Google GoldenGate Deployments User</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.goldenGateDeploymentsUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.networkAdmin">Oracle Database@Google Network Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.odbNetworkAdmin">Oracle Database@Google ODB Network Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.odbNetworkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.odbNetworkViewer">Oracle Database@Google ODB Network Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.odbNetworkViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.odbSubnetAdmin">Oracle Database@Google ODB Subnet Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.odbSubnetAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.odbSubnetUser">Oracle Database@Google ODB Subnet User</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.odbSubnetUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.odbSubnetViewer">Oracle Database@Google ODB Subnet Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.odbSubnetViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.pluggableDatabaseViewer">Oracle Database@Google Cloud Pluggable Database Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.pluggableDatabaseViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/osconfig#osconfig.guestPolicyAdmin">GuestPolicy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/osconfig.guestPolicyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/osconfig#osconfig.guestPolicyEditor">GuestPolicy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/osconfig.guestPolicyEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/osconfig#osconfig.guestPolicyViewer">GuestPolicy Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/osconfig.guestPolicyViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/osconfig#osconfig.instanceOSPoliciesComplianceViewer">InstanceOSPoliciesCompliance Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/osconfig.instanceOSPoliciesComplianceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/osconfig#osconfig.inventoryViewer">OS Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/osconfig.inventoryViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/osconfig#osconfig.osPolicyAssignmentAdmin">OSPolicyAssignment Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/osconfig.osPolicyAssignmentAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/osconfig#osconfig.osPolicyAssignmentEditor">OSPolicyAssignment Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/osconfig.osPolicyAssignmentEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/osconfig#osconfig.osPolicyAssignmentReportViewer">OSPolicyAssignmentReport Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/osconfig.osPolicyAssignmentReportViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/osconfig#osconfig.osPolicyAssignmentViewer">OSPolicyAssignment Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/osconfig.osPolicyAssignmentViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/osconfig#osconfig.patchDeploymentAdmin">PatchDeployment Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/osconfig.patchDeploymentAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/osconfig#osconfig.patchDeploymentViewer">PatchDeployment Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/osconfig.patchDeploymentViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/osconfig#osconfig.patchJobExecutor">Patch Job Executor</a> (<code class="role-name" translate="no" dir="ltr">roles/osconfig.patchJobExecutor</code>)</p>
<p><a href="/iam/docs/roles-permissions/osconfig#osconfig.patchJobViewer">Patch Job Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/osconfig.patchJobViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/osconfig#osconfig.projectFeatureSettingsEditor">Project Feature Settings Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/osconfig.projectFeatureSettingsEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/osconfig#osconfig.projectFeatureSettingsViewer">Project Feature Settings Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/osconfig.projectFeatureSettingsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/osconfig#osconfig.upgradeReportViewer">Upgrade Report Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/osconfig.upgradeReportViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/osconfig#osconfig.vulnerabilityReportViewer">OS VulnerabilityReport Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/osconfig.vulnerabilityReportViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/parametermanager#parametermanager.parameterAccessor">Parameter Manager Parameter Accessor</a> (<code class="role-name" translate="no" dir="ltr">roles/parametermanager.parameterAccessor</code>)</p>
<p><a href="/iam/docs/roles-permissions/parametermanager#parametermanager.parameterVersionAdder">Parameter Manager Parameter Version Adder</a> (<code class="role-name" translate="no" dir="ltr">roles/parametermanager.parameterVersionAdder</code>)</p>
<p><a href="/iam/docs/roles-permissions/parametermanager#parametermanager.parameterVersionManager">Parameter Manager Parameter Version Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/parametermanager.parameterVersionManager</code>)</p>
<p><a href="/iam/docs/roles-permissions/parametermanager#parametermanager.parameterViewer">Parameter Manager Parameter Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/parametermanager.parameterViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/parametermanager#parametermanager.templateVersionManager">Parameter Manager Template Version Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/parametermanager.templateVersionManager</code>)</p>
<p><a href="/iam/docs/roles-permissions/parametermanager#parametermanager.templateViewer">Parameter Manager Template Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/parametermanager.templateViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/paymentsresellersubscription#paymentsresellersubscription.partnerAdmin">Payments Reseller Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/paymentsresellersubscription.partnerAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/paymentsresellersubscription#paymentsresellersubscription.partnerViewer">Payments Reseller Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/paymentsresellersubscription.partnerViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/paymentsresellersubscription#paymentsresellersubscription.productViewer">Payments Reseller Products Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/paymentsresellersubscription.productViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/paymentsresellersubscription#paymentsresellersubscription.promotionViewer">Payments Reseller Promotions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/paymentsresellersubscription.promotionViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/paymentsresellersubscription#paymentsresellersubscription.subscriptionEditor">Payments Reseller Subscriptions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/paymentsresellersubscription.subscriptionEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/paymentsresellersubscription#paymentsresellersubscription.subscriptionViewer">Payments Reseller Subscriptions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/paymentsresellersubscription.subscriptionViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/privateca#privateca.auditor">CA Service Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/privateca.auditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/privateca#privateca.caManager">CA Service Operation Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/privateca.caManager</code>)</p>
<p><a href="/iam/docs/roles-permissions/privateca#privateca.certificateManager">CA Service Certificate Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/privateca.certificateManager</code>)</p>
<p><a href="/iam/docs/roles-permissions/proximitybeacon#proximitybeacon.attachmentEditor">Beacon Attachment Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/proximitybeacon.attachmentEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/proximitybeacon#proximitybeacon.attachmentPublisher">Beacon Attachment Publisher</a> (<code class="role-name" translate="no" dir="ltr">roles/proximitybeacon.attachmentPublisher</code>)</p>
<p><a href="/iam/docs/roles-permissions/proximitybeacon#proximitybeacon.attachmentViewer">Beacon Attachment Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/proximitybeacon.attachmentViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/proximitybeacon#proximitybeacon.beaconEditor">Beacon Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/proximitybeacon.beaconEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/publicca#publicca.externalAccountKeyCreator">External Account Key Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/publicca.externalAccountKeyCreator</code>)</p>
<p><a href="/iam/docs/roles-permissions/recaptchaenterprise#recaptchaenterprise.agent">reCAPTCHA Enterprise Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/recaptchaenterprise.agent</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.alloydbAdmin">AlloyDB Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.alloydbAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.alloydbViewer">AlloyDB Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.alloydbViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.appengineversioncostAdmin">App Engine Version Cost Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.appengineversioncostAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.appengineversioncostViewer">App Engine Version Cost Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.appengineversioncostViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.bigQueryCapacityCommitmentsAdmin">BigQuery Slot Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.bigQueryCapacityCommitmentsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.bigQueryCapacityCommitmentsProjectAdmin">BigQuery Recommender Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.bigQueryCapacityCommitmentsProjectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.bigQueryCapacityCommitmentsProjectViewer">BigQuery Recommender Project Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.bigQueryCapacityCommitmentsProjectViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.bigQueryCapacityCommitmentsViewer">BigQuery Slot Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.bigQueryCapacityCommitmentsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.bigqueryMaterializedViewAdmin">BigQuery Materialized View Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.bigqueryMaterializedViewAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.bigqueryMaterializedViewViewer">BigQuery Materialized View Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.bigqueryMaterializedViewViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.bigqueryPartitionClusterAdmin">BigQuery Partitioning Clustering Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.bigqueryPartitionClusterAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.bigqueryPartitionClusterViewer">BigQuery Partitioning Clustering Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.bigqueryPartitionClusterViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.bigtableClusterPerformanceAdmin">Bigtable Cluster Performance Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.bigtableClusterPerformanceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.bigtableClusterPerformanceViewer">Bigtable Cluster Performance Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.bigtableClusterPerformanceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.cloudAssetInsightsAdmin">Cloud Asset Insights Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.cloudAssetInsightsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.cloudAssetInsightsViewer">Cloud Asset Insights Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.cloudAssetInsightsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.cloudCostRecommendationAdmin">Cloud Cost General Recommendations Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.cloudCostRecommendationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.cloudCostRecommendationViewer">Cloud Cost General Recommendations Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.cloudCostRecommendationViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.cloudDeprecationRecommendationAdmin">Cloud Deprecation General Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.cloudDeprecationRecommendationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.cloudDeprecationRecommendationViewer">Cloud Deprecation General Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.cloudDeprecationRecommendationViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.cloudManageabilityRecommendationAdmin">Cloud Manageability General Recommendations Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.cloudManageabilityRecommendationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.cloudManageabilityRecommendationViewer">Cloud Manageability General Recommendations Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.cloudManageabilityRecommendationViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.cloudPerformanceRecommendationAdmin">Cloud Performance General Recommendations Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.cloudPerformanceRecommendationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.cloudPerformanceRecommendationViewer">Cloud Performance General Recommendations Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.cloudPerformanceRecommendationViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.cloudReliabilityRecommendationAdmin">Cloud Reliability General Recommendations Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.cloudReliabilityRecommendationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.cloudReliabilityRecommendationViewer">Cloud Reliability General Recommendations Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.cloudReliabilityRecommendationViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.cloudSecurityRecommendationAdmin">Cloud Security General Recommendations Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.cloudSecurityRecommendationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.cloudSecurityRecommendationViewer">Cloud Security General Recommendations Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.cloudSecurityRecommendationViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.cloudsqlAdmin">Cloud SQL Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.cloudsqlAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.cloudsqlViewer">Cloud SQL Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.cloudsqlViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.computeAdmin">Compute Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.computeAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.computeViewer">Compute Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.computeViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.containerDiagnosisAdmin">GKE Diagnosis Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.containerDiagnosisAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.containerDiagnosisViewer">GKE Diagnosis Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.containerDiagnosisViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.dataflowDiagnosticsAdmin">Dataflow Diagnostics Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.dataflowDiagnosticsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.dataflowDiagnosticsViewer">Dataflow Diagnostics Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.dataflowDiagnosticsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.errorReportingAdmin">Error Reporting Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.errorReportingAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.errorReportingViewer">Error Reporting Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.errorReportingViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.firestoredatabasefirebaserulesAdmin">Firestore Database Firebase rules Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.firestoredatabasefirebaserulesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.firestoredatabasefirebaserulesViewer">Firestore Database Firebase rules Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.firestoredatabasefirebaserulesViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.firestoredatabasereliabilityAdmin">Firestore Database Reliability Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.firestoredatabasereliabilityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.firestoredatabasereliabilityViewer">Firestore Database Reliability Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.firestoredatabasereliabilityViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.firewallAdmin">Firewall Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.firewallAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.firewallViewer">Firewall Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.firewallViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.gmpAdmin">Google Maps Platform Insights/Recommendations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.gmpAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.gmpViewer">Google Maps Platform Insights/Recommendations Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.gmpViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.iamAdmin">IAM Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.iamAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.iamViewer">IAM Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.iamViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.iampolicychangeriskAdmin">IAM Policy Change Risk Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.iampolicychangeriskAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.iampolicychangeriskViewer">IAM Policy Change Risk Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.iampolicychangeriskViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.memorystoremanageabilityAdmin">Memorystore Manageability Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.memorystoremanageabilityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.memorystoremanageabilityViewer">Memorystore Manageability Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.memorystoremanageabilityViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.memorystoreperformanceAdmin">Memorystore Performance Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.memorystoreperformanceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.memorystoreperformanceViewer">Memorystore Performance Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.memorystoreperformanceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.memorystorereliabilityAdmin">Memorystore Reliability Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.memorystorereliabilityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.memorystorereliabilityViewer">Memorystore Reliability Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.memorystorereliabilityViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.networkAnalyzerAdmin">Network Analyzer Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.networkAnalyzerAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.networkAnalyzerCloudSqlAdmin">Network Analyzer Cloud SQL Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.networkAnalyzerCloudSqlAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.networkAnalyzerCloudSqlViewer">Network Analyzer Cloud SQL Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.networkAnalyzerCloudSqlViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.networkAnalyzerDynamicRouteAdmin">Network Analyzer Dynamic Route Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.networkAnalyzerDynamicRouteAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.networkAnalyzerDynamicRouteViewer">Network Analyzer Dynamic Route Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.networkAnalyzerDynamicRouteViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.networkAnalyzerGkeConnectivityAdmin">Network Analyzer GKE Connectivity Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.networkAnalyzerGkeConnectivityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.networkAnalyzerGkeConnectivityViewer">Network Analyzer GKE Connectivity Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.networkAnalyzerGkeConnectivityViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.networkAnalyzerGkeIpAddressAdmin">Network Analyzer GKE IP Address Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.networkAnalyzerGkeIpAddressAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.networkAnalyzerGkeIpAddressViewer">Network Analyzer GKE IP Address Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.networkAnalyzerGkeIpAddressViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.networkAnalyzerGkeServiceAccountAdmin">Network Analyzer GKE Service Account Insights Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.networkAnalyzerGkeServiceAccountAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.networkAnalyzerGkeServiceAccountViewer">Network Analyzer GKE Service Account Insights Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.networkAnalyzerGkeServiceAccountViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.networkAnalyzerIpAddressAdmin">Network Analyzer IP Address Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.networkAnalyzerIpAddressAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.networkAnalyzerIpAddressViewer">Network Analyzer IP Address Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.networkAnalyzerIpAddressViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.networkAnalyzerLoadBalancerAdmin">Network Analyzer Load Balancer Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.networkAnalyzerLoadBalancerAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.networkAnalyzerLoadBalancerViewer">Network Analyzer Load Balancer Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.networkAnalyzerLoadBalancerViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.networkAnalyzerViewer">Network Analyzer Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.networkAnalyzerViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.networkAnalyzerVpcConnectivityAdmin">Network Analyzer VPC Connectivity Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.networkAnalyzerVpcConnectivityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.networkAnalyzerVpcConnectivityViewer">Network Analyzer VPC Connectivity Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.networkAnalyzerVpcConnectivityViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.orgPolicyAdmin">Org Policy Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.orgPolicyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.orgPolicyViewer">Org Policy Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.orgPolicyViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.productSuggestionAdmin">Product Suggestion Recommenders Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.productSuggestionAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.productSuggestionViewer">Product Suggestion Recommenders Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.productSuggestionViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.projectCudAdmin">Project Usage Commitment Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.projectCudAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.projectCudViewer">Project Usage Commitment Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.projectCudViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.projectUtilAdmin">Project Utilization Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.projectUtilAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.projectUtilViewer">Project Utilization Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.projectUtilViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.recentChangeConfigAdmin">RecentChange RecommenderConfig Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.recentChangeConfigAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.recentchangeriskAdmin">Recent Change Risk Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.recentchangeriskAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.recentchangeriskViewer">Recent Change Risk Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.recentchangeriskViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.serviceLimitAdmin">Service Limit Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.serviceLimitAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.serviceLimitViewer">Service Limit Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.serviceLimitViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.serviceaccntchangeriskAdmin">Service Account Change Risk Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.serviceaccntchangeriskAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.serviceaccntchangeriskViewer">Service Account Change Risk Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.serviceaccntchangeriskViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.spannerAdmin">Spanner Project Reliability Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.spannerAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.spannerViewer">Spanner Project Reliability Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.spannerViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderCreator">Folder Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderCreator</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderEditor">Folder Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderViewer">Folder Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/retail#retail.merchantApprover">Retail Merchant Approver</a> (<code class="role-name" translate="no" dir="ltr">roles/retail.merchantApprover</code>)</p>
<p><a href="/iam/docs/roles-permissions/retail#retail.merchantCreator">Retail Merchant Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/retail.merchantCreator</code>)</p>
<p><a href="/iam/docs/roles-permissions/riskmanager#riskmanager.reviewer">Risk Manager Report Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/riskmanager.reviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/rapidmigrationassessment#rma.runner">Rapid Migration Assessment Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/rma.runner</code>)</p>
<p><a href="/iam/docs/roles-permissions/roads#roads.roadsSelectionAdmin">Roads Selection Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/roads.roadsSelectionAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/roads#roads.roadsSelectionViewer">Roads Selection Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/roads.roadsSelectionViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/runapps#runapps.developer">Serverless Integrations Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/runapps.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/runapps#runapps.operator">Serverless Integrations Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/runapps.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.secretVersionAdder">Secret Manager Secret Version Adder</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.secretVersionAdder</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.secretVersionManager">Secret Manager Secret Version Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.secretVersionManager</code>)</p>
<p><a href="/iam/docs/roles-permissions/securedlandingzone#securedlandingzone.overwatchActivator">Overwatch Activator</a> (<code class="role-name" translate="no" dir="ltr">roles/securedlandingzone.overwatchActivator</code>)</p>
<p><a href="/iam/docs/roles-permissions/securedlandingzone#securedlandingzone.overwatchAdmin">Overwatch Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securedlandingzone.overwatchAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/securedlandingzone#securedlandingzone.overwatchViewer">Overwatch Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securedlandingzone.overwatchViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securesourcemanager#securesourcemanager.developerConnectLinker">Secure Source Manager Developer Connect Linker</a> (<code class="role-name" translate="no" dir="ltr">roles/securesourcemanager.developerConnectLinker</code>)</p>
<p><a href="/iam/docs/roles-permissions/securesourcemanager#securesourcemanager.instanceAccessor">Secure Source Manager Instance Accessor</a> (<code class="role-name" translate="no" dir="ltr">roles/securesourcemanager.instanceAccessor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securesourcemanager#securesourcemanager.instanceManager">Secure Source Manager Instance Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/securesourcemanager.instanceManager</code>)</p>
<p><a href="/iam/docs/roles-permissions/securesourcemanager#securesourcemanager.instanceOwner">Secure Source Manager Instance Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/securesourcemanager.instanceOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/securesourcemanager#securesourcemanager.instanceRepositoryCreator">Secure Source Manager Instance Repository Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/securesourcemanager.instanceRepositoryCreator</code>)</p>
<p><a href="/iam/docs/roles-permissions/securesourcemanager#securesourcemanager.repoAdmin">Secure Source Manager Repository Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securesourcemanager.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/securesourcemanager#securesourcemanager.repoCreator">Secure Source Manager Repository Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/securesourcemanager.repoCreator</code>)</p>
<p><a href="/iam/docs/roles-permissions/securesourcemanager#securesourcemanager.repoPullRequestApprover">Secure Source Manager Repository Pull Request Approver</a> (<code class="role-name" translate="no" dir="ltr">roles/securesourcemanager.repoPullRequestApprover</code>)</p>
<p><a href="/iam/docs/roles-permissions/securesourcemanager#securesourcemanager.repoReader">Secure Source Manager Repository Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/securesourcemanager.repoReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/securesourcemanager#securesourcemanager.repoWriter">Secure Source Manager Repository Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/securesourcemanager.repoWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/securesourcemanager#securesourcemanager.sshKeyUser">Secure Source Manager SSH Key User</a> (<code class="role-name" translate="no" dir="ltr">roles/securesourcemanager.sshKeyUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminEditor">Security Center Admin Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminViewer">Security Center Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.assetsViewer">Security Center Assets Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.assetsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.bigQueryExportsEditor">Security Center BigQuery Exports Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.bigQueryExportsEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.bigQueryExportsViewer">Security Center BigQuery Exports Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.bigQueryExportsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.findingsEditor">Security Center Findings Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.findingsEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.findingsViewer">Security Center Findings Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.findingsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.settingsAdmin">Security Center Settings Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.settingsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.settingsEditor">Security Center Settings Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.settingsEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.settingsViewer">Security Center Settings Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.settingsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycentermanagement#securitycentermanagement.customModulesEditor">Security Center Management Custom Modules Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycentermanagement.customModulesEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycentermanagement#securitycentermanagement.customModulesViewer">Security Center Management Custom Modules Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycentermanagement.customModulesViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycentermanagement#securitycentermanagement.etdCustomModulesEditor">Security Center Management Custom ETD Modules Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycentermanagement.etdCustomModulesEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycentermanagement#securitycentermanagement.etdCustomModulesViewer">Security Center Management ETD Custom Modules Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycentermanagement.etdCustomModulesViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycentermanagement#securitycentermanagement.settingsEditor">Security Center Management Settings Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycentermanagement.settingsEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycentermanagement#securitycentermanagement.settingsViewer">Security Center Management Settings Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycentermanagement.settingsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycentermanagement#securitycentermanagement.shaCustomModulesEditor">Security Center Management SHA Custom Modules Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycentermanagement.shaCustomModulesEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycentermanagement#securitycentermanagement.shaCustomModulesViewer">Security Center Management SHA Custom Modules Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycentermanagement.shaCustomModulesViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicedirectory#servicedirectory.networkAttacher">Service Directory Network Attacher</a> (<code class="role-name" translate="no" dir="ltr">roles/servicedirectory.networkAttacher</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicedirectory#servicedirectory.pscAuthorizedService">Private Service Connect Authorized Service</a> (<code class="role-name" translate="no" dir="ltr">roles/servicedirectory.pscAuthorizedService</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.quotaAdmin">Quota Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.quotaAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/spanner#spanner.backupAdmin">Cloud Spanner Backup Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/spanner.backupAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/spanner#spanner.databaseAdmin">Cloud Spanner Database Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/spanner.databaseAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/spanner#spanner.restoreAdmin">Cloud Spanner Restore Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/spanner.restoreAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#stackdriver.accounts.editor">Stackdriver Accounts Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/stackdriver.accounts.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#stackdriver.accounts.viewer">Stackdriver Accounts Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/stackdriver.accounts.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.hmacKeyAdmin">Storage HMAC Key Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.hmacKeyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.insightsCollectorService">Storage Insights Collector Service</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.insightsCollectorService</code>)</p>
<p><a href="/iam/docs/roles-permissions/storageinsights#storageinsights.analyst">Storage Insights Analyst</a> (<code class="role-name" translate="no" dir="ltr">roles/storageinsights.analyst</code>)</p>
<p><a href="/iam/docs/roles-permissions/storagetransfer#storagetransfer.user">Storage Transfer User</a> (<code class="role-name" translate="no" dir="ltr">roles/storagetransfer.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/stream#stream.contentAdmin">Stream Content Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/stream.contentAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/stream#stream.contentBuilder">Stream Content Builder</a> (<code class="role-name" translate="no" dir="ltr">roles/stream.contentBuilder</code>)</p>
<p><a href="/iam/docs/roles-permissions/stream#stream.instanceAdmin">Stream Instance Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/stream.instanceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/subscribewithgoogledeveloper#subscribewithgoogledeveloper.developer">Subscribe with Google Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/subscribewithgoogledeveloper.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier1">Telco Automation Tier 1 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier1</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier4">Telco Automation Tier 4 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier4</code>)</p>
<p><a href="/iam/docs/roles-permissions/threatintelligence#threatintelligence.alertAdmin">GTI Alert Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/threatintelligence.alertAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/threatintelligence#threatintelligence.alertUser">GTI Alert User</a> (<code class="role-name" translate="no" dir="ltr">roles/threatintelligence.alertUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/threatintelligence#threatintelligence.ctemAdmin">CTEM Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/threatintelligence.ctemAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/threatintelligence#threatintelligence.ctemEditor">CTEM Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/threatintelligence.ctemEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/threatintelligence#threatintelligence.ctemProjectAdmin">CTEM Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/threatintelligence.ctemProjectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/threatintelligence#threatintelligence.ctemViewer">CTEM Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/threatintelligence.ctemViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/translationhub#translationhub.portalUser">Translation Hub Portal User</a> (<code class="role-name" translate="no" dir="ltr">roles/translationhub.portalUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/vectorsearch#vectorsearch.collectionWriter">Vector Search Collection Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/vectorsearch.collectionWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/vectorsearch#vectorsearch.dataObjectWriter">Vector Search DataObject Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/vectorsearch.dataObjectWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/vectorsearch#vectorsearch.indexWriter">Vector Search Index Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/vectorsearch.indexWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/videostitcher#videostitcher.user">Video Stitcher User</a> (<code class="role-name" translate="no" dir="ltr">roles/videostitcher.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.vmwareengineAdmin">VMware Engine Service Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.vmwareengineAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.vmwareenginePrivilegedUser">VMware Engine Service Privileged User</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.vmwareenginePrivilegedUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.vmwareengineViewer">VMware Engine Service Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.vmwareengineViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.workloadScanner">Wiz Workload Scanner</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.workloadScanner</code>)</p>
<p><a href="/iam/docs/roles-permissions/workflows#workflows.invoker">Workflows Invoker</a> (<code class="role-name" translate="no" dir="ltr">roles/workflows.invoker</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadcertificate#workloadcertificate.registrationAdmin">Workload Certificate Registration Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadcertificate.registrationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadcertificate#workloadcertificate.registrationViewer">Workload Certificate Registration Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadcertificate.registrationViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.deploymentAdmin">Workload Manager Deployment Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.deploymentAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.deploymentViewer">Workload Manager Deployment Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.deploymentViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.evaluationAdmin">Workload Manager Evaluation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.evaluationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.evaluationViewer">Workload Manager Evaluation Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.evaluationViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.worker">Workload Manager Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.workloadViewer">Workload Manager Workload Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.workloadViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/workstations#workstations.workstationCreator">Cloud Workstations Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/workstations.workstationCreator</code>)</p>
<p><a href="/iam/docs/roles-permissions/workstations#workstations.workstationLimitExemptedCreator">Cloud Workstations Limit Exempted Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/workstations.workstationLimitExemptedCreator</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.customCodeServiceAgent">Vertex AI Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.customCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.extensionCustomCodeServiceAgent">Vertex AI Extension Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.extensionCustomCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.reasoningEngineServiceAgent">Vertex AI Reasoning Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.reasoningEngineServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.tuningServiceAgent">Vertex AI Tuning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.tuningServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/analyticshub#analyticshub.serviceAgent">Analytics Hub Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/analyticshub.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/anthosservicemesh#anthosservicemesh.serviceAgent">Anthos Service Mesh Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/anthosservicemesh.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/anthossupport#anthossupport.serviceAgent">Anthos Support Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/anthossupport.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengineflex#appengineflex.serviceAgent">App Engine flexible environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengineflex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.serviceAgent">Audit Manager Auditing Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.serviceAgent">Recommendations AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/backupdr#backupdr.serviceAgent">Backup and DR Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/backupdr.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/baremetalsolution#baremetalsolution.serviceAgent">Bare Metal Solution Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/baremetalsolution.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/batch#batch.serviceAgent">Google Batch Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/batch.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/bigquerydatatransfer#bigquerydatatransfer.serviceAgent">BigQuery Data Transfer Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatatransfer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/bigquerymigration#bigquerymigration.serviceAgent">BigQuery Migration Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerymigration.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/binaryauthorization#binaryauthorization.serviceAgent">Binary Authorization Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/binaryauthorization.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.serviceAgent">Chronicle Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.serviceAgent">Cloud Security Compliance Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/tpu#cloudtpu.serviceAgent">Cloud TPU V2 API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtpu.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/compliancescanning#compliancescanning.serviceAgent">Compliance Scanning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/compliancescanning.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/compute#compute.serviceAgent">Compute Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.nodeServiceAgent">[Deprecated] Kubernetes Engine Node Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.nodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.ServiceAgent">Container Analysis Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containerscanning#containerscanning.ServiceAgent">Container Scanner Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containerscanning.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containerthreatdetection#containerthreatdetection.serviceAgent">Container Threat Detection Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containerthreatdetection.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/databaseinsights#databaseinsights.serviceAgent">Database Insights Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/databaseinsights.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataform#dataform.serviceAgent">Dataform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datalabeling#datalabeling.serviceAgent">Data Labeling Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datalabeling.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/designcenter#designcenter.serviceAgent">DesignCenter Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dialogflow#dialogflow.serviceAgent">Dialogflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dialogflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.serviceAgent">Discovery Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.clusterServiceAgent">Edge Container Cluster Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.clusterServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/enterpriseknowledgegraph#enterpriseknowledgegraph.serviceAgent">Enterprise Knowledge Graph Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/enterpriseknowledgegraph.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/file#file.serviceAgent">Cloud Filestore Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/file.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.managementServiceAgent">Firebase Service Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.managementServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.sdkAdminServiceAgent">Firebase Admin SDK Administrator Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.sdkAdminServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasemods#firebasemods.serviceAgent">Firebase Extensions API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasemods.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/fleetengine#fleetengine.serviceAgent">FleetEngine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/fleetengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gameservices#gameservices.serviceAgent">Game Services Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gameservices.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/lifesciences#genomics.serviceAgent">Genomics Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/genomics.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkebackup#gkebackup.serviceAgent">Backup for GKE Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkebackup.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkedataplanemanagement#gkedataplanemanagement.warpRunServiceAgent">Warp Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkedataplanemanagement.warpRunServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkehub#gkehub.serviceAgent">GKE Hub Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkemulticloud#gkemulticloud.containerServiceAgent">Anthos Multi-Cloud Container Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkemulticloud.containerServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkemulticloud#gkemulticloud.serviceAgent">Anthos Multi-Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkemulticloud.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/healthcare#healthcare.serviceAgent">Healthcare Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.serviceAgent">Cluster Director Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.sharedVpcServiceAgent">Cluster Director Shared VPC Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.sharedVpcServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/integrations#integrations.serviceAgent">Application Integration Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/krmapihosting#krmapihosting.anthosApiEndpointServiceAgent">KRM API Hosting AnthosApiEndpoint Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/krmapihosting.anthosApiEndpointServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/krmapihosting#krmapihosting.serviceAgent">KRM API Hosting Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/krmapihosting.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/kuberun#kuberun.eventsControlPlaneServiceAgent">KubeRun Events Control Plane Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/kuberun.eventsControlPlaneServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/kuberun#kuberun.eventsDataPlaneServiceAgent">KubeRun Events Data Plane Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/kuberun.eventsDataPlaneServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/lifesciences#lifesciences.serviceAgent">Cloud Life Sciences Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/lifesciences.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/looker#looker.restrictedServiceAgent">Looker Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/looker.restrictedServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/looker#looker.serviceAgent">(Legacy) Looker Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/looker.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.serviceAgent">Cloud Managed Identities Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/memcache#memcache.serviceAgent">Cloud Memorystore Memcached Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/memcache.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/memorystore#memorystore.serviceAgent">Cloud Memorystore Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/memorystore.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/meshcontrolplane#meshcontrolplane.serviceAgent">Mesh Managed Control Plane Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/meshcontrolplane.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusterservicediscovery#multiclusterservicediscovery.serviceAgent">Multi-Cluster Service Discovery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusterservicediscovery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/notebooks#notebooks.serviceAgent">AI Platform Notebooks Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/oci#oci.serviceAgent">Oracle Database@Google Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/oci.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/osconfig#osconfig.serviceAgent">Cloud OS Config Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/osconfig.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/parallelstore#parallelstore.serviceAgent">Parallelstore Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/parallelstore.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/privilegedaccessmanager#privilegedaccessmanager.projectServiceAgent">Privileged Access Manager Project Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/privilegedaccessmanager.projectServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/privilegedaccessmanager#privilegedaccessmanager.serviceAgent">Privileged Access Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/privilegedaccessmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/pubsub#pubsub.serviceAgent">Cloud Pub/Sub Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/rapidmigrationassessment#rapidmigrationassessment.serviceAgent">RMA Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/rapidmigrationassessment.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/redis#redis.serviceAgent">Cloud Memorystore Redis Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/retail#retail.serviceAgent">Retail Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/retail.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/riskmanager#riskmanager.serviceAgent">Risk Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/riskmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securedlandingzone#securedlandingzone.serviceAgent">Secured Landing Zone Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securedlandingzone.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.attackSurfaceManagementScannerServiceAgent">Attack Surface Management Scanner Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.attackSurfaceManagementScannerServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.automationServiceAgent">Security Center Automation Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.automationServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.controlServiceAgent">Security Center Control Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.controlServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.securityHealthAnalyticsServiceAgent">Security Health Analytics Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.securityHealthAnalyticsServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.serviceAgent">Security Center Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/servicedirectory#servicedirectory.serviceAgent">Service Directory Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/servicedirectory.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/servicenetworking#servicenetworking.serviceAgent">Service Networking Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/servicenetworking.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/spectrumsas#spectrumsas.serviceAgent">Spectrum SAS Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/spectrumsas.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/stream#stream.serviceAgent">Stream Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/stream.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/tpu#tpu.serviceAgent">Cloud TPU API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/tpu.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.serviceAgent">VMware Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vpcaccess#vpcaccess.serviceAgent">Serverless VPC Access Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vpcaccess.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="resourcemanager.projects.getIamPolicy" class="permission-name add-link" data-text="resourcemanager.projects.getIamPolicy" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.projects.getIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigee#apigee.admin">Apigee Organization Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/datastudio#datastudio.editor">Data Studio Asset Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/datastudio.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.roleAdmin">Role Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.roleAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.roleViewer">Role Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.roleViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderAdmin">Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.organizationAdmin">Organization Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.organizationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.projectIamAdmin">Project IAM Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.projectIamAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.admin">Workload Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigee#apigee.developerAdmin">Apigee Developer Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.developerAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigee#apigee.environmentAdmin">Apigee Environment Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.environmentAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigee#apigee.readOnlyAdmin">Apigee Read-only Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.readOnlyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.containerRegistryMigrationAdmin">Container Registry -&gt; Artifact Registry Migration Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.containerRegistryMigrationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/browser#browser">Browser</a> (<code class="role-name" translate="no" dir="ltr">roles/browser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.xpnAdmin">Compute Shared VPC Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.xpnAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/datastudio#datastudio.contentManager">Data Studio Workspace Content Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/datastudio.contentManager</code>)</p>
<p><a href="/iam/docs/roles-permissions/datastudio#datastudio.contributor">Data Studio Workspace Contributor</a> (<code class="role-name" translate="no" dir="ltr">roles/datastudio.contributor</code>)</p>
<p><a href="/iam/docs/roles-permissions/datastudio#datastudio.manager">Data Studio Workspace Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/datastudio.manager</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.analyticsAdmin">Firebase Analytics Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.analyticsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.analyticsViewer">Firebase Analytics Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.analyticsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.growthAdmin">Firebase Grow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.growthAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.growthViewer">Firebase Grow Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.growthViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.qualityAdmin">Firebase Quality Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.qualityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.qualityViewer">Firebase Quality Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.qualityViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.organizationRoleAdmin">Organization Role Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.organizationRoleAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.organizationRoleViewer">Organization Role Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.organizationRoleViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/datastudio#lookerstudio.lookerAdmin">Looker Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/lookerstudio.lookerAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.deploymentAdmin">Workload Manager Deployment Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.deploymentAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/appengineflex#appengineflex.serviceAgent">App Engine flexible environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengineflex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.serviceAgent">Audit Manager Auditing Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.serviceAgent">Cloud Security Compliance Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.serviceAgent">Discovery Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dspm#dspm.serviceAgent">DSPM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.managementServiceAgent">Firebase Service Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.managementServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkehub#gkehub.crossProjectServiceAgent">GKE Hub Cross Project Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.crossProjectServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/krmapihosting#krmapihosting.anthosApiEndpointServiceAgent">KRM API Hosting AnthosApiEndpoint Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/krmapihosting.anthosApiEndpointServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/privilegedaccessmanager#privilegedaccessmanager.projectServiceAgent">Privileged Access Manager Project Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/privilegedaccessmanager.projectServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/privilegedaccessmanager#privilegedaccessmanager.serviceAgent">Privileged Access Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/privilegedaccessmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.automationServiceAgent">Security Center Automation Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.automationServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.controlServiceAgent">Security Center Control Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.controlServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.serviceAgent">Security Center Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="resourcemanager.projects.list" class="permission-name add-link" data-text="resourcemanager.projects.list" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.projects.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/accessapproval#accessapproval.admin">Access Approval Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/accessapproval.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/accessapproval#accessapproval.editor">Access Approval Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/accessapproval.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/accessapproval#accessapproval.viewer">Access Approval Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/accessapproval.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/accesscontextmanager#accesscontextmanager.admin">Access Context Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/accesscontextmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/accesscontextmanager#accesscontextmanager.editor">Access Context Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/accesscontextmanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/accesscontextmanager#accesscontextmanager.policyAdmin">Access Context Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/accesscontextmanager.policyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/accesscontextmanager#accesscontextmanager.viewer">Access Context Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/accesscontextmanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/actions#actions.Admin">Actions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/actions.Admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/actions#actions.Viewer">Actions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/actions.Viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.admin">Agent Platform Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.editor">Aiplatform Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.user">Agent Platform User</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.viewer">Agent Platform Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/alloydb#alloydb.admin">AlloyDB Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/alloydb.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/alloydb#alloydb.editor">AlloyDB Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/alloydb.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/alloydb#alloydb.viewer">AlloyDB Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/alloydb.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/analyticshub#analyticshub.admin">Analytics Hub Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/analyticshub.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/analyticshub#analyticshub.editor">Analytics Hub Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/analyticshub.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/analyticshub#analyticshub.viewer">Analytics Hub Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/analyticshub.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/androidmanagement#androidmanagement.admin">Androidmanagement Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/androidmanagement.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.admin">ApiGateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.editor">ApiGateway Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigateway#apigateway.viewer">ApiGateway Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigee#apigee.admin">Apigee Organization Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigee#apigee.apiAdminV2">Apigee API Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.apiAdminV2</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigee#apigee.editor">Apigee Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigee#apigee.viewer">Apigee Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigeeconnect#apigeeconnect.viewer">Apigeeconnect Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apigeeconnect.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigeeregistry#apigeeregistry.admin">Cloud Apigee Registry Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigeeregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigeeregistry#apigeeregistry.editor">Cloud Apigee Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigeeregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigeeregistry#apigeeregistry.viewer">Cloud Apigee Registry Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apigeeregistry.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apihub#apihub.admin">Cloud API Hub Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apihub.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apihub#apihub.editor">Cloud API Hub Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apihub.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apihub#apihub.viewer">Cloud API Hub Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apihub.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apim#apim.admin">API Management Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apim.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apim#apim.viewer">API Management Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apim.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/appengine#appengine.admin">App Engine Service Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/appengine#appengine.appAdmin">App Engine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.appAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/appengine#appengine.editor">App Engine Service Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/appengine#appengine.viewer">App Engine Service Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apphub#apphub.admin">App Hub Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apphub.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apphub#apphub.editor">App Hub Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apphub.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apphub#apphub.viewer">App Hub Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apphub.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/applianceactivation#applianceactivation.admin">Appliance Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/applianceactivation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/applianceactivation#applianceactivation.viewer">Appliance Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/applianceactivation.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apptopology#apptopology.admin">App Topology Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apptopology.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apptopology#apptopology.viewer">App Topology Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apptopology.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.editor">Artifact Registry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.viewer">Artifact Registry Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.editor">Assured OSS Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.viewer">Assured OSS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredworkloads#assuredworkloads.admin">Assured Workloads Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredworkloads.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredworkloads#assuredworkloads.editor">Assured Workloads Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredworkloads.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredworkloads#assuredworkloads.viewer">Assured Workloads Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredworkloads.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.admin">Audit Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.viewer">Auditmanager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/automl#automl.admin">AutoML Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/automl#automl.editor">AutoML Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/automl#automl.viewer">AutoML Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.admin">Recommendations AI Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.editor">Recommendations AI Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.viewer">Recommendations AI Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/autoscaling#autoscaling.admin">Autoscaling Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/autoscaling.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/autoscaling#autoscaling.editor">Autoscaling Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/autoscaling.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/autoscaling#autoscaling.viewer">Autoscaling Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/autoscaling.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/axt#axt.admin">Access Transparency Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/axt.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/backupdr#backupdr.admin">Backup and DR Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/backupdr.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/backupdr#backupdr.editor">Backupdr Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/backupdr.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/backupdr#backupdr.viewer">Backup and DR Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/backupdr.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/baremetalsolution#baremetalsolution.admin">Bare Metal Solution Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/baremetalsolution.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/baremetalsolution#baremetalsolution.editor">Bare Metal Solution Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/baremetalsolution.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/baremetalsolution#baremetalsolution.viewer">Bare Metal Solution Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/baremetalsolution.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/batch#batch.admin">Batch Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/batch.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/batch#batch.viewer">Batch Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/batch.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/beyondcorp#beyondcorp.admin">Cloud BeyondCorp Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/beyondcorp.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/beyondcorp#beyondcorp.editor">Cloud BeyondCorp Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/beyondcorp.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/beyondcorp#beyondcorp.viewer">Cloud BeyondCorp Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/beyondcorp.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/biglake#biglake.admin">BigLake Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/biglake.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/biglake#biglake.editor">BigLake Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/biglake.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/biglake#biglake.viewer">BigLake Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/biglake.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataEditor">BigQuery Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataViewer">BigQuery Data Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.jobUser">BigQuery Job User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.jobUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.metadataViewer">BigQuery Metadata Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.metadataViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.readSessionUser">BigQuery Read Session User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.readSessionUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceAdmin">BigQuery Resource Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceEditor">BigQuery Resource Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceViewer">BigQuery Resource Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioUser">BigQuery Studio User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.user">BigQuery User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerymigration#bigquerymigration.admin">Bigquerymigration Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerymigration.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.editor">Bigtable Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/billing#billing.admin">Billing Account Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/billing.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/binaryauthorization#binaryauthorization.admin">Binary Authorization Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/binaryauthorization.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/binaryauthorization#binaryauthorization.editor">Binary Authorization Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/binaryauthorization.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/binaryauthorization#binaryauthorization.viewer">Binary Authorization Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/binaryauthorization.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/blockchainnodeengine#blockchainnodeengine.admin">Blockchain Node Engine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/blockchainnodeengine.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/blockchainnodeengine#blockchainnodeengine.viewer">Blockchain Node Engine Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/blockchainnodeengine.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/blockchainvalidatormanager#blockchainvalidatormanager.admin">Blockchain Validator Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/blockchainvalidatormanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/blockchainvalidatormanager#blockchainvalidatormanager.viewer">Blockchain Validator Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/blockchainvalidatormanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/capacityplanner#capacityplanner.admin">Capacityplanner Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/capacityplanner.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/capacityplanner#capacityplanner.viewer">Capacity Planner Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/capacityplanner.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/carestudio#carestudio.admin">Carestudio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/carestudio.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/carestudio#carestudio.viewer">Care Studio Patients Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/carestudio.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/certificatemanager#certificatemanager.admin">Certificate Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/certificatemanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/certificatemanager#certificatemanager.editor">Certificate Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/certificatemanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/certificatemanager#certificatemanager.viewer">Certificate Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/certificatemanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/ces#ces.admin">Gemini Enterprise for Customer Experience Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/ces.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/ces#ces.viewer">Gemini Enterprise for Customer Experience Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/ces.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/chat#chat.admin">Chat Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/chat.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/chat#chat.viewer">Chat Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/chat.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/chronicle#chronicle.admin">Chronicle API Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/chronicle#chronicle.editor">Chronicle API Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/chronicle#chronicle.viewer">Chronicle API Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/chroniclesm#chroniclesm.editor">Chroniclesm Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/chroniclesm.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloud#cloud.admin">Cloud Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloud.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloud#cloud.viewer">Cloud Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloud.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudaicompanion#cloudaicompanion.admin">Gemini for Google Cloud Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudaicompanion.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudaicompanion#cloudaicompanion.editor">Gemini for Google Cloud Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudaicompanion.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudaicompanion#cloudaicompanion.user">Gemini for Google Cloud User</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudaicompanion.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudaicompanion#cloudaicompanion.viewer">Gemini for Google Cloud Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudaicompanion.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudasset#cloudasset.admin">Cloud Asset Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudasset.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudasset#cloudasset.editor">Cloud Asset Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudasset.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.admin">Cloud Build Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.editor">Cloud Build Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.viewer">Cloud Build Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudconfig#cloudconfig.admin">Firebase Remote Config Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudconfig.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudconfig#cloudconfig.viewer">Firebase Remote Config Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudconfig.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudcontrolspartner#cloudcontrolspartner.viewer">Cloudcontrolspartner Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudcontrolspartner.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/clouddeploy#clouddeploy.admin">Cloud Deploy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploy.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/clouddeploy#clouddeploy.editor">Cloud Deploy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/clouddeploy#clouddeploy.viewer">Cloud Deploy Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploy.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudjobdiscovery#cloudjobdiscovery.admin">Cloud Talent Solution Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudjobdiscovery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudjobdiscovery#cloudjobdiscovery.viewer">Cloud Talent Solution Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudjobdiscovery.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudlocationfinder#cloudlocationfinder.admin">Cloud Location Finder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudlocationfinder.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudlocationfinder#cloudlocationfinder.viewer">Cloud Location Finder Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudlocationfinder.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebasecloudmessaging#cloudmessaging.editor">Firebase Cloud Messaging Service Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudmessaging.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudprivatecatalog#cloudprivatecatalog.admin">Catalog Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudprivatecatalog.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudprivatecatalog#cloudprivatecatalog.viewer">Catalog Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudprivatecatalog.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudprivatecatalog#cloudprivatecatalogproducer.admin">Catalog Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudprivatecatalogproducer.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudprivatecatalog#cloudprivatecatalogproducer.editor">Catalog Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudprivatecatalogproducer.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudprivatecatalog#cloudprivatecatalogproducer.viewer">Catalog Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudprivatecatalogproducer.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudprofiler#cloudprofiler.admin">Cloud Profiler Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudprofiler.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudprofiler#cloudprofiler.viewer">Cloud Profiler Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudprofiler.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudquotas#cloudquotas.admin">Cloud Quotas Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudquotas.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudquotas#cloudquotas.viewer">Cloud Quotas Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudquotas.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.admin">Cloud Scheduler Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.viewer">Cloud Scheduler Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.admin">Compliance Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.viewer">Compliance Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsecurityscanner#cloudsecurityscanner.admin">Web Security Scanner Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecurityscanner.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsecurityscanner#cloudsecurityscanner.editor">Web Security Scanner Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecurityscanner.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.admin">Cloud SQL Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.editor">Cloud SQL Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.viewer">Cloud SQL Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.admin">Cloud Tasks Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.editor">Cloud Tasks Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.viewer">Cloud Tasks Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtestservice#cloudtestservice.admin">Cloud Test Service Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtestservice.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtestservice#cloudtestservice.viewer">Cloud Test Service Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtestservice.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtrace#cloudtrace.admin">Cloud Trace Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtrace.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtrace#cloudtrace.user">Cloud Trace User</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtrace.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtranslate#cloudtranslate.admin">Cloud Translation API Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtranslate.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtranslate#cloudtranslate.editor">Cloud Translation API Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtranslate.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtranslate#cloudtranslate.user">Cloud Translation API User</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtranslate.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtranslate#cloudtranslate.viewer">Cloud Translation API Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtranslate.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/commerceagreementpublishing#commerceagreementpublishing.admin">Commerce Agreement Publishing Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/commerceagreementpublishing.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/commerceagreementpublishing#commerceagreementpublishing.viewer">Commerce Agreement Publishing Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/commerceagreementpublishing.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercebusinessenablement#commercebusinessenablement.admin">Commerce Business Enablement Configuration Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/commercebusinessenablement.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercebusinessenablement#commercebusinessenablement.viewer">Commerce Business Enablement Configuration Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/commercebusinessenablement.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/commerceoffercatalog#commerceoffercatalog.admin">Commerce Offer Catalog Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/commerceoffercatalog.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/commerceorggovernance#commerceorggovernance.admin">Commerce Organization Governance Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/commerceorggovernance.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/commerceorggovernance#commerceorggovernance.viewer">Commerce Organization Governance Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/commerceorggovernance.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercepricemanagement#commercepricemanagement.editor">Commercepricemanagement Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/commercepricemanagement.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercepricemanagement#commercepricemanagement.viewer">Commerce Price Management Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/commercepricemanagement.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/commerceproducer#commerceproducer.admin">Commerce Producer Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/commerceproducer.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/commerceproducer#commerceproducer.viewer">Commerce Producer Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/commerceproducer.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.editor">Composer Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.viewer">Composer Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.admin">Compute Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.editor">Compute Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.instanceAdmin">Compute Instance Admin (beta)</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.instanceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.instanceAdmin.v1">Compute Instance Admin (v1)</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.instanceAdmin.v1</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.loadBalancerAdmin">Compute Load Balancer Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.loadBalancerAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.networkAdmin">Compute Network Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.networkUser">Compute Network User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.networkUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.networkViewer">Compute Network Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.networkViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.osAdminLogin">Compute OS Admin Login</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.osAdminLogin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.osLogin">Compute OS Login</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.osLogin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.securityAdmin">Compute Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.storageAdmin">Compute Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.storageAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.viewer">Compute Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/confidentialcomputing#confidentialcomputing.admin">Confidentialcomputing Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/confidentialcomputing.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/confidentialcomputing#confidentialcomputing.viewer">Confidentialcomputing Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/confidentialcomputing.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/config#config.admin">Cloud Infrastructure Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/config.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/config#config.editor">Cloud Infrastructure Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/config.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/config#config.viewer">Cloud Infrastructure Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/config.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/configdelivery#configdelivery.admin">Configdelivery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/configdelivery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/configdelivery#configdelivery.viewer">Configdelivery Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/configdelivery.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/connectors#connectors.admin">Connector Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/connectors.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/connectors#connectors.editor">Connectors Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/connectors.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/connectors#connectors.viewer">Connectors Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/connectors.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/contactcenteraiplatform#contactcenteraiplatform.admin">Contact Center AI Platform Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/contactcenteraiplatform.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/contactcenteraiplatform#contactcenteraiplatform.viewer">Contact Center AI Platform Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/contactcenteraiplatform.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/container#container.admin">Kubernetes Engine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/container.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/container#container.clusterAdmin">Kubernetes Engine Cluster Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/container.clusterAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/container#container.clusterViewer">Kubernetes Engine Cluster Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/container.clusterViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/container#container.developer">Kubernetes Engine Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/container.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/container#container.editor">Kubernetes Engine Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/container.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/container#container.viewer">Kubernetes Engine Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/container.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.admin">Container Analysis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.editor">Container Analysis Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.viewer">Container Analysis Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/containersecurity#containersecurity.admin">Containersecurity Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/containersecurity.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/containersecurity#containersecurity.viewer">GKE Security Posture Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/containersecurity.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/contentwarehouse#contentwarehouse.admin">Content Warehouse Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/contentwarehouse.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/databasecenter#databasecenter.admin">Database Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/databasecenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/databasecenter#databasecenter.viewer">Database Center Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/databasecenter.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/databaseinsights#databaseinsights.admin">Database Insights Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/databaseinsights.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/databaseinsights#databaseinsights.editor">Database Insights Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/databaseinsights.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/databaseinsights#databaseinsights.viewer">Database Insights Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/databaseinsights.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/databasesconsole#databasesconsole.editor">Databasesconsole Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/databasesconsole.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/databasesconsole#databasesconsole.viewer">Databasesconsole Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/databasesconsole.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.admin">Data Catalog Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.editor">Data Catalog Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.viewer">Data Catalog Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataconnectors#dataconnectors.admin">Data Connectors Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataconnectors.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataconnectors#dataconnectors.editor">Data Connectors Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dataconnectors.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataconnectors#dataconnectors.viewer">Data Connectors Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataconnectors.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.admin">Dataflow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.viewer">Dataflow Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataform#dataform.admin">Dataform Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataform.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataform#dataform.editor">Dataform Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dataform.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataform#dataform.viewer">Dataform Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataform.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/datafusion#datafusion.admin">Cloud Data Fusion Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/datafusion#datafusion.viewer">Cloud Data Fusion Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/datalabeling#datalabeling.admin">Data Labeling Service Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/datalabeling.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/datalabeling#datalabeling.editor">Data Labeling Service Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/datalabeling.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/datalabeling#datalabeling.viewer">Data Labeling Service Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/datalabeling.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/datalineage#datalineage.admin">Data Lineage Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/datalineage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/datalineage#datalineage.editor">Data Lineage Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/datalineage.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/datalineage#datalineage.viewer">Data Lineage Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/datalineage.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/datamigration#datamigration.admin">Database Migration Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/datamigration.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/datamigration#datamigration.editor">Database Migration Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/datamigration.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.admin">Data pipelines Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.viewer">Data pipelines Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.admin">Dataplex Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataprep#dataprep.admin">Dataprep Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.admin">Dataproc Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.editor">Dataproc Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.viewer">Dataproc Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataprocessing#dataprocessing.editor">Dataprocessing Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprocessing.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataprocessing#dataprocessing.viewer">Dataprocessing Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprocessing.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataprocrm#dataprocrm.admin">Dataproc Resource Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprocrm.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataprocrm#dataprocrm.viewer">Dataproc Resource Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprocrm.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firestore#datastore.admin">Cloud Datastore Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/datastore.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firestore#datastore.editor">Cloud Datastore Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/datastore.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firestore#datastore.owner">Cloud Datastore Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/datastore.owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/firestore#datastore.user">Cloud Datastore User</a> (<code class="role-name" translate="no" dir="ltr">roles/datastore.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/firestore#datastore.viewer">Cloud Datastore Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/datastore.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/datastream#datastream.admin">Datastream Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/datastream.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/datastream#datastream.viewer">Datastream Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/datastream.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/datastudio#datastudio.admin">Data Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/datastudio.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dellemccloudonefs#dellemccloudonefs.admin">Dell EMC Cloud OneFS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dellemccloudonefs.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dellemccloudonefs#dellemccloudonefs.viewer">Dell EMC Cloud OneFS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dellemccloudonefs.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.admin">Deployment Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.editor">Deployment Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.viewer">Deployment Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.admin">Application Design Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.editor">Designcenter Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.viewer">Application Design Center Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/developerconnect#developerconnect.admin">Developer Connect Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/developerconnect.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/developerconnect#developerconnect.viewer">Developer Connect Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/developerconnect.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/devicerun#devicerun.admin">Device Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/devicerun.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/devicerun#devicerun.viewer">Device Run Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/devicerun.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/devicestreaming#devicestreaming.admin">Device Streaming Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/devicestreaming.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/devicestreaming#devicestreaming.viewer">Device Streaming Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/devicestreaming.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dialogflow#dialogflow.viewer">Dialogflow Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dialogflow.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.admin">Discovery Engine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.editor">Discovery Engine Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.user">Discovery Engine User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.viewer">Discovery Engine Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.admin">DLP Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.editor">DLP Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.viewer">DLP Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.admin">DNS Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.editor">DNS Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.viewer">DNS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/clouddocumentai#documentai.admin">Document AI Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/documentai.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/clouddocumentai#documentai.editor">Document AI Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/documentai.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/clouddocumentai#documentai.viewer">Document AI Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/documentai.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/domains#domains.admin">Cloud Domains Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/domains.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/domains#domains.editor">Cloud Domains Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/domains.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/domains#domains.viewer">Cloud Domains Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/domains.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/earth#earth.admin">Earth Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/earth.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/earth#earth.viewer">Earth Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/earth.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/earthengine#earthengine.admin">Earth Engine Resource Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/earthengine.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/earthengine#earthengine.editor">Earth Engine Resource Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/earthengine.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/earthengine#earthengine.viewer">Earth Engine Resource Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/earthengine.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.admin">Edge Container Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.editor">Edge Container Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.viewer">Edge Container Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/edgenetwork#edgenetwork.admin">Edge Network Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/edgenetwork.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/edgenetwork#edgenetwork.editor">Edge Network Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/edgenetwork.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/edgenetwork#edgenetwork.viewer">Edge Network Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/edgenetwork.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/enterpriseknowledgegraph#enterpriseknowledgegraph.admin">Enterprise Knowledge Graph Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/enterpriseknowledgegraph.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/enterpriseknowledgegraph#enterpriseknowledgegraph.editor">Enterprise Knowledge Graph Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/enterpriseknowledgegraph.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/enterpriseknowledgegraph#enterpriseknowledgegraph.viewer">Enterprise Knowledge Graph Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/enterpriseknowledgegraph.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/enterprisepurchasing#enterprisepurchasing.admin">Enterprise Purchasing Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/enterprisepurchasing.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/enterprisepurchasing#enterprisepurchasing.editor">Enterprise Purchasing Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/enterprisepurchasing.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/enterprisepurchasing#enterprisepurchasing.viewer">Enterprise Purchasing Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/enterprisepurchasing.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/errorreporting#errorreporting.admin">Error Reporting Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/errorreporting.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/errorreporting#errorreporting.user">Error Reporting User</a> (<code class="role-name" translate="no" dir="ltr">roles/errorreporting.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/errorreporting#errorreporting.viewer">Error Reporting Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/errorreporting.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/eventarc#eventarc.admin">Eventarc Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/eventarc.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/eventarc#eventarc.editor">Eventarc Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/eventarc.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/eventarc#eventarc.viewer">Eventarc Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/eventarc.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/externalexposure#externalexposure.admin">External Exposure Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/externalexposure.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/externalexposure#externalexposure.viewer">External Exposure Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/externalexposure.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/faulttesting#faulttesting.viewer">Fault Testing Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/faulttesting.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/file#file.admin">Cloud Filestore Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/file.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/financialservices#financialservices.admin">Financial Services Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/financialservices.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/financialservices#financialservices.viewer">Financial Services Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/financialservices.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseabt#firebaseabt.admin">Firebase A/B Testing Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseabt.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseabt#firebaseabt.viewer">Firebase A/B Testing Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseabt.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseappdistro#firebaseappdistro.admin">Firebase App Distribution Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseappdistro.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseappdistro#firebaseappdistro.viewer">Firebase App Distribution Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseappdistro.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.admin">Firebase App Hosting Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.viewer">Firebase App Hosting Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseauth#firebaseauth.admin">Firebase Authentication Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseauth.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseauth#firebaseauth.editor">Firebase Authentication editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseauth.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseauth#firebaseauth.viewer">Firebase Authentication Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseauth.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebasecloudmessaging#firebasecloudmessaging.admin">Firebase Cloud Messaging API Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasecloudmessaging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebasecloudmessaging#firebasecloudmessaging.viewer">Firebase Cloud Messaging API Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasecloudmessaging.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebasecrash#firebasecrashlytics.admin">Firebase Crashlytics Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasecrashlytics.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebasecrash#firebasecrashlytics.viewer">Firebase Crashlytics Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasecrashlytics.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebasedatabase#firebasedatabase.admin">Firebase Realtime Database Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasedatabase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebasedatabase#firebasedatabase.viewer">Firebase Realtime Database Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasedatabase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebasedataconnect#firebasedataconnect.admin">Firebase SQL Connect API Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasedataconnect.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebasedataconnect#firebasedataconnect.viewer">Firebase SQL Connect API Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasedataconnect.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebasedynamiclinks#firebasedynamiclinks.admin">Firebase Dynamic Links Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasedynamiclinks.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebasedynamiclinks#firebasedynamiclinks.editor">Firebasedynamiclinks Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasedynamiclinks.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebasedynamiclinks#firebasedynamiclinks.viewer">Firebase Dynamic Links Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasedynamiclinks.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseextensions#firebaseextensions.editor">Firebaseextensions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseextensions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseextensions#firebaseextensions.viewer">Firebase Extensions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseextensions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseextensionspublisher#firebaseextensionspublisher.admin">Firebaseextensionspublisher Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseextensionspublisher.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseextensionspublisher#firebaseextensionspublisher.viewer">Firebaseextensionspublisher Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseextensionspublisher.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebasehosting#firebasehosting.admin">Firebase Hosting Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasehosting.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebasehosting#firebasehosting.viewer">Firebase Hosting Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasehosting.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseinappmessaging#firebaseinappmessaging.admin">Firebase In-App Messaging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseinappmessaging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseinappmessaging#firebaseinappmessaging.viewer">Firebase In-App Messaging Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseinappmessaging.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseml#firebaseml.admin">Firebase ML Kit Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseml.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseml#firebaseml.viewer">Firebase ML Kit Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseml.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebasecloudmessaging#firebasenotifications.admin">Firebase Cloud Messaging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasenotifications.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebasecloudmessaging#firebasenotifications.viewer">Firebase Cloud Messaging Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasenotifications.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseperformance#firebaseperformance.admin">Firebase Performance Reporting Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseperformance.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseperformance#firebaseperformance.viewer">Firebase Performance Reporting Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseperformance.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaserules#firebaserules.admin">Firebase Rules Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaserules.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaserules#firebaserules.system">Firebase Rules System</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaserules.system</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaserules#firebaserules.viewer">Firebase Rules Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaserules.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebasestorage#firebasestorage.admin">Cloud Storage for Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasestorage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebasestorage#firebasestorage.viewer">Cloud Storage for Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasestorage.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebasevertexai#firebasevertexai.admin">Firebase AI Logic Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasevertexai.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebasevertexai#firebasevertexai.viewer">Firebase AI Logic Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasevertexai.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/fleetengine#fleetengine.viewer">Fleet Engine Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/fleetengine.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/flow#flow.admin">Flow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/flow.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/flow#flow.editor">Flow Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/flow.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/ftp#ftp.admin">Cloud FTP Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/ftp.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/ftp#ftp.viewer">Cloud FTP Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/ftp.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/gdchardwaremanagement#gdchardwaremanagement.admin">GDC Hardware Management Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/gdchardwaremanagement.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/gdchardwaremanagement#gdchardwaremanagement.viewer">Gdchardwaremanagement Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/gdchardwaremanagement.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.admin">Gemini Cloud Assist Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.editor">Gemini Cloud Assist Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.investigationOwner">Gemini Cloud Assist Investigation Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.investigationOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.user">Gemini Cloud Assist User</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.viewer">Gemini Cloud Assist Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminidataanalytics#geminidataanalytics.admin">Gemini Data Analytics Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/geminidataanalytics.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminidataanalytics#geminidataanalytics.viewer">Gemini Data Analytics Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/geminidataanalytics.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkebackup#gkebackup.admin">Backup for GKE Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/gkebackup.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkebackup#gkebackup.editor">Backup for GKE Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/gkebackup.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkebackup#gkebackup.viewer">Backup for GKE Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/gkebackup.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.admin">Fleet Admin (formerly GKE Hub Admin)</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.editor">Fleet Editor (formerly GKE Hub Editor)</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.viewer">Fleet Viewer (formerly GKE Hub Viewer)</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkemulticloud#gkemulticloud.admin">Anthos Multi-cloud Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/gkemulticloud.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkemulticloud#gkemulticloud.editor">Anthos Multi-cloud Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/gkemulticloud.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkemulticloud#gkemulticloud.viewer">Anthos Multi-cloud Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/gkemulticloud.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkeonprem#gkeonprem.admin">GKE on-prem Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/gkeonprem.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkeonprem#gkeonprem.editor">GKE on-prem Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/gkeonprem.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkeonprem#gkeonprem.viewer">GKE on-prem Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/gkeonprem.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/gsuiteaddons#gsuiteaddons.admin">Google Workspace Add-ons Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/gsuiteaddons.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/gsuiteaddons#gsuiteaddons.viewer">Google Workspace Add-ons Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/gsuiteaddons.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.editor">Cluster Director Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">IAM Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">IAM Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountAdmin">Service Account Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountCreator">Create Service Accounts</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountCreator</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountKeyAdmin">Service Account Key Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountKeyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountTokenCreator">Service Account Token Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountTokenCreator</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountUser">Service Account User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountViewer">View Service Accounts</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">IAM Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iap#iap.editor">IAP Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iap.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iap#iap.viewer">IAP Policy Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iap.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/identitytoolkit#identitytoolkit.editor">Identity Toolkit editor</a> (<code class="role-name" translate="no" dir="ltr">roles/identitytoolkit.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/ids#ids.admin">Cloud IDS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/ids.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/ids#ids.editor">Cloud IDS Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/ids.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/ids#ids.viewer">Cloud IDS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/ids.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/integrations#integrations.admin">Integrations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/integrations#integrations.viewer">Integrations Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/issuerswitch#issuerswitch.admin">Issuerswitch Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/issuerswitch.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/issuerswitch#issuerswitch.viewer">Issuerswitch Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/issuerswitch.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/krmapihosting#krmapihosting.admin">Config Controller Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/krmapihosting.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/krmapihosting#krmapihosting.editor">Config Controller Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/krmapihosting.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/krmapihosting#krmapihosting.viewer">Config Controller Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/krmapihosting.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/kubernetesmetadata#kubernetesmetadata.admin">Kubernetesmetadata Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/kubernetesmetadata.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/kubernetesmetadata#kubernetesmetadata.viewer">Kubernetesmetadata Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/kubernetesmetadata.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/licensemanager#licensemanager.admin">Cloud License Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/licensemanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/licensemanager#licensemanager.viewer">Cloud License Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/licensemanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/lifesciences#lifesciences.viewer">Cloud Life Sciences Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/lifesciences.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/livestream#livestream.admin">Live Stream Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/livestream.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/livestream#livestream.editor">Live Stream Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/livestream.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/livestream#livestream.viewer">Live Stream Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/livestream.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/looker#looker.admin">Looker Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/looker.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/looker#looker.viewer">Looker Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/looker.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/lustre#lustre.admin">Google Cloud Managed Lustre Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/lustre.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/lustre#lustre.viewer">Google Cloud Managed Lustre Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/lustre.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/maintenance#maintenance.admin">Maintenance Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/maintenance.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/maintenance#maintenance.viewer">Maintenance API Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/maintenance.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedflink#managedflink.admin">Managed Flink Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/managedflink.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedflink#managedflink.viewer">Managed Flink Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/managedflink.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.admin">Google Cloud Managed Identities Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.editor">Google Cloud Managed Identities Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.viewer">Google Cloud Managed Identities Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.admin">Managed Kafka Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.viewer">Managed Kafka Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/mandiant#mandiant.admin">Mandiant Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/mandiant.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/mandiant#mandiant.viewer">Mandiant Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/mandiant.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/mapsadmin#mapsadmin.admin">Maps API Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/mapsadmin.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/mapsadmin#mapsadmin.viewer">Maps API Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/mapsadmin.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/mapsanalytics#mapsanalytics.admin">Mapsanalytics Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/mapsanalytics.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/mapsanalytics#mapsanalytics.viewer">Maps Analytics Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/mapsanalytics.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/mapsplatformdatasets#mapsplatformdatasets.admin">Maps Platform Datasets Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/mapsplatformdatasets.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/mapsplatformdatasets#mapsplatformdatasets.viewer">Maps Platform Datasets Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/mapsplatformdatasets.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/marketplacesolutions#marketplacesolutions.admin">Marketplace Solutions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/marketplacesolutions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/marketplacesolutions#marketplacesolutions.editor">Marketplace Solutions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/marketplacesolutions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/marketplacesolutions#marketplacesolutions.viewer">Marketplace Solutions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/marketplacesolutions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/mcp#mcp.admin">MCP Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/mcp.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/mcp#mcp.toolUser">MCP Tool User</a> (<code class="role-name" translate="no" dir="ltr">roles/mcp.toolUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/memcache#memcache.admin">Cloud Memorystore Memcached Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/memcache.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/memcache#memcache.editor">Cloud Memorystore Memcached Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/memcache.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/memcache#memcache.viewer">Cloud Memorystore Memcached Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/memcache.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/memorystore#memorystore.admin">Memorystore Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/memorystore.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/memorystore#memorystore.viewer">Memorystore Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/memorystore.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/metastore#metastore.admin">Dataproc Metastore Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/metastore.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/metastore#metastore.editor">Dataproc Metastore Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/metastore.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/metastore#metastore.viewer">Dataproc Metastore Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/metastore.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/migrationcenter#migrationcenter.admin">Migration Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/migrationcenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/migrationcenter#migrationcenter.viewer">Migration Center Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/migrationcenter.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/ml#ml.admin">AI Platform Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/ml#ml.editor">AI Platform Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/modelarmor#modelarmor.admin">Model Armor Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/modelarmor.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/modelarmor#modelarmor.editor">Model Armor Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/modelarmor.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/modelarmor#modelarmor.viewer">Model Armor Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/modelarmor.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#monitoring.admin">Monitoring Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/monitoring.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#monitoring.editor">Monitoring Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/monitoring.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#monitoring.viewer">Monitoring Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/monitoring.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/navigationconnect#navigationconnect.admin">Navigation Connect Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/navigationconnect.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/navigationconnect#navigationconnect.viewer">Navigation Connect Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/navigationconnect.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/nestconsole#nestconsole.admin">Nestconsole Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/nestconsole.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/nestconsole#nestconsole.editor">Nestconsole Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/nestconsole.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/nestconsole#nestconsole.viewer">Nestconsole Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/nestconsole.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/netapp#netapp.admin">Google Cloud NetApp Volumes Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/netapp.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/netapp#netapp.viewer">Google Cloud NetApp Volumes Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/netapp.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/netappcloudvolumes#netappcloudvolumes.admin">NetApp Cloud Volumes Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/netappcloudvolumes.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/netappcloudvolumes#netappcloudvolumes.viewer">NetApp Cloud Volumes Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/netappcloudvolumes.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkconnectivity#networkconnectivity.editor">Network Connectivity Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/networkconnectivity.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkmanagement#networkmanagement.admin">Network Management Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networkmanagement.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkmanagement#networkmanagement.editor">Network Management Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/networkmanagement.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkmanagement#networkmanagement.viewer">Network Management Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/networkmanagement.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/networksecurity#networksecurity.admin">Network Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networksecurity.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networksecurity#networksecurity.editor">Network Security Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/networksecurity.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/networksecurity#networksecurity.viewer">Network Security Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/networksecurity.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkservices#networkservices.admin">Network Services Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networkservices.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkservices#networkservices.editor">Network Services Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/networkservices.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkservices#networkservices.viewer">Network Services Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/networkservices.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.admin">Notebooks Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.editor">Notebooks Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.viewer">Notebooks Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/oauthconfig#oauthconfig.editor">OAuth Config Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/oauthconfig.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/oauthconfig#oauthconfig.viewer">OAuth Config Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/oauthconfig.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/ondemandscanning#ondemandscanning.viewer">On-Demand Scanning Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/ondemandscanning.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#opsconfigmonitoring.admin">Ops Config Monitoring Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/opsconfigmonitoring.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#opsconfigmonitoring.viewer">Ops Config Monitoring Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/opsconfigmonitoring.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.admin">Oracle Database@Google Cloud admin</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.viewer">Oracle Database@Google Cloud viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/parallelstore#parallelstore.admin">Parallelstore Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/parallelstore.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/parallelstore#parallelstore.viewer">Parallelstore Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/parallelstore.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/parametermanager#parametermanager.admin">Parameter Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/parametermanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/parametermanager#parametermanager.editor">Parameter Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/parametermanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/parametermanager#parametermanager.viewer">Parameter Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/parametermanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/paymentsresellersubscription#paymentsresellersubscription.admin">Paymentsresellersubscription Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/paymentsresellersubscription.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/paymentsresellersubscription#paymentsresellersubscription.viewer">Paymentsresellersubscription Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/paymentsresellersubscription.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/policyanalyzer#policyanalyzer.admin">Policyanalyzer Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/policyanalyzer.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/policyanalyzer#policyanalyzer.viewer">Policyanalyzer Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/policyanalyzer.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/policyremediatormanager#policyremediatormanager.admin">Policyremediatormanager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/policyremediatormanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/policyremediatormanager#policyremediatormanager.viewer">Policyremediatormanager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/policyremediatormanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/policysimulator#policysimulator.viewer">Policysimulator Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/policysimulator.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/privateca#privateca.admin">CA Service Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/privateca.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/privateca#privateca.editor">CA Service Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/privateca.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/privateca#privateca.viewer">CA Service Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/privateca.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/privilegedaccessmanager#privilegedaccessmanager.editor">Privilegedaccessmanager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/privilegedaccessmanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/proximitybeacon#proximitybeacon.admin">Beacon Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/proximitybeacon.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/proximitybeacon#proximitybeacon.editor">Beacon Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/proximitybeacon.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/proximitybeacon#proximitybeacon.viewer">Beacon Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/proximitybeacon.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/publicca#publicca.admin">Publicca Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/publicca.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/readerrevenuesubscriptionlinking#readerrevenuesubscriptionlinking.admin">Subscription Linking Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/readerrevenuesubscriptionlinking.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/readerrevenuesubscriptionlinking#readerrevenuesubscriptionlinking.viewer">Subscription Linking Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/readerrevenuesubscriptionlinking.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recaptchaenterprise#recaptchaenterprise.admin">reCAPTCHA Enterprise Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recaptchaenterprise.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recaptchaenterprise#recaptchaenterprise.editor">reCAPTCHA Enterprise Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/recaptchaenterprise.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/recaptchaenterprise#recaptchaenterprise.viewer">reCAPTCHA Enterprise Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recaptchaenterprise.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.admin">Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.editor">Recommender Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.editor">Cloud Memorystore Redis Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.viewer">Cloud Memorystore Redis Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/redisenterprisecloud#redisenterprisecloud.admin">Redis Enterprise Cloud Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redisenterprisecloud.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/redisenterprisecloud#redisenterprisecloud.viewer">Redis Enterprise Cloud Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/redisenterprisecloud.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/remotebuildexecution#remotebuildexecution.admin">Remotebuildexecution Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/remotebuildexecution.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/remotebuildexecution#remotebuildexecution.editor">Remotebuildexecution Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/remotebuildexecution.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/remotebuildexecution#remotebuildexecution.viewer">Remotebuildexecution Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/remotebuildexecution.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.editor">Resource Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderAdmin">Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.organizationAdmin">Organization Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.organizationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.viewer">Resource Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/retail#retail.admin">Retail Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/retail.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/retail#retail.editor">Retail Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/retail.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/riskmanager#riskmanager.admin">Risk Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/riskmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/riskmanager#riskmanager.editor">Risk Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/riskmanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/riskmanager#riskmanager.viewer">Risk Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/riskmanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/rapidmigrationassessment#rma.admin">Rapid Migration Assessment Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/rma.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/rapidmigrationassessment#rma.viewer">Rapid Migration Assessment Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/rma.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/routeoptimization#routeoptimization.admin">Routeoptimization Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/routeoptimization.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/routeoptimization#routeoptimization.editor">Route Optimization Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/routeoptimization.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/routeoptimization#routeoptimization.viewer">Route Optimization Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/routeoptimization.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.viewer">Cloud Run Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/runapps#runapps.admin">Runapps Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/runapps.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/runapps#runapps.viewer">Serverless Integrations Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/runapps.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/runtimeconfig#runtimeconfig.editor">Runtimeconfig Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/runtimeconfig.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/runtimeconfig#runtimeconfig.viewer">Runtimeconfig Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/runtimeconfig.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/saasconfig#saasconfig.viewer">SaaS Config Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/saasconfig.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/saasservicemgmt#saasservicemgmt.admin">SaaS Service Management Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/saasservicemgmt.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/saasservicemgmt#saasservicemgmt.viewer">SaaS Service Management Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/saasservicemgmt.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.admin">Secret Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.editor">Secret Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.secretAccessor">Secret Manager Secret Accessor</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.secretAccessor</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.viewer">Secret Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securedlandingzone#securedlandingzone.admin">Secured Landing Zone Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securedlandingzone.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/securedlandingzone#securedlandingzone.viewer">Secured Landing Zone Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securedlandingzone.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securesourcemanager#securesourcemanager.admin">Secure Source Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securesourcemanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/securesourcemanager#securesourcemanager.editor">Secure Source Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securesourcemanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securesourcemanager#securesourcemanager.viewer">Secure Source Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securesourcemanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycentermanagement#securitycentermanagement.admin">Security Center Management Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycentermanagement.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycentermanagement#securitycentermanagement.editor">Security Center Management Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycentermanagement.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycentermanagement#securitycentermanagement.viewer">Security Center Management Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycentermanagement.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceconsumermanagement#serviceconsumermanagement.admin">Service Consumer Management Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceconsumermanagement.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceconsumermanagement#serviceconsumermanagement.viewer">Service Consumer Management Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceconsumermanagement.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicedirectory#servicedirectory.admin">Service Directory Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/servicedirectory.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicedirectory#servicedirectory.editor">Service Directory Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/servicedirectory.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicedirectory#servicedirectory.viewer">Service Directory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/servicedirectory.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceextensions#serviceextensions.admin">Service Extensions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceextensions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceextensions#serviceextensions.editor">Service Extensions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceextensions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/serviceextensions#serviceextensions.viewer">Service Extensions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/serviceextensions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicehealth#servicehealth.admin">Servicehealth Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/servicehealth.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicehealth#servicehealth.viewer">Personalized Service Health Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/servicehealth.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.admin">Service Management Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.editor">Service Management Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.viewer">Service Management Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicenetworking#servicenetworking.admin">Service Networking Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/servicenetworking.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicenetworking#servicenetworking.editor">Service Networking Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/servicenetworking.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicenetworking#servicenetworking.viewer">Service Networking Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/servicenetworking.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/source#source.editor">Source Repository Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/source.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/source#source.viewer">Source Repository Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/source.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/spanner#spanner.admin">Cloud Spanner Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/spanner.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/spanner#spanner.editor">Cloud Spanner Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/spanner.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/spanner#spanner.viewer">Cloud Spanner Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/spanner.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#stackdriver.admin">Stackdriver Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/stackdriver.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#stackdriver.viewer">Stackdriver Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/stackdriver.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.editor">Storage Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.folderAdmin">Storage Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectAdmin">Storage Object Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectCreator">Storage Object Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectCreator</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectUser">Storage Object User</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectViewer">Storage Object Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.viewer">Storage Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/storagebatchoperations#storagebatchoperations.admin">Storage Batch Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storagebatchoperations.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storagebatchoperations#storagebatchoperations.viewer">Storage Batch Operations Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/storagebatchoperations.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/storageinsights#storageinsights.admin">Storage Insights Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storageinsights.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storageinsights#storageinsights.viewer">Storage Insights Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/storageinsights.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/storagetransfer#storagetransfer.admin">Storage Transfer Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storagetransfer.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storagetransfer#storagetransfer.viewer">Storage Transfer Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/storagetransfer.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/stream#stream.admin">Stream Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/stream.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/stream#stream.viewer">Stream Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/stream.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/subscribewithgoogledeveloper#subscribewithgoogledeveloper.admin">Subscribewithgoogledeveloper Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/subscribewithgoogledeveloper.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/subscribewithgoogledeveloper#subscribewithgoogledeveloper.viewer">Subscribewithgoogledeveloper Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/subscribewithgoogledeveloper.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.editor">Telcoautomation Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.viewer">Telcoautomation Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telemetry#telemetry.admin">Telemetry Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telemetry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/telemetry#telemetry.editor">Telemetry Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/telemetry.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/tpu#tpu.admin">TPU Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/tpu.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/tpu#tpu.editor">TPU Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/tpu.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/tpu#tpu.viewer">TPU Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/tpu.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/anthosservicemesh#trafficdirector.admin">Trafficdirector Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/trafficdirector.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/anthosservicemesh#trafficdirector.viewer">Trafficdirector Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/trafficdirector.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/transcoder#transcoder.admin">Transcoder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/transcoder.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/transcoder#transcoder.editor">Transcoder Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/transcoder.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/transcoder#transcoder.viewer">Transcoder Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/transcoder.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/transferappliance#transferappliance.admin">Transfer Appliance Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/transferappliance.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/transferappliance#transferappliance.viewer">Transfer Appliance Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/transferappliance.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/translationhub#translationhub.admin">Translation Hub Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/translationhub.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/translationhub#translationhub.viewer">Translation Hub Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/translationhub.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/vectorsearch#vectorsearch.admin">Vector Search Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/vectorsearch.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/vectorsearch#vectorsearch.viewer">Vector Search Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/vectorsearch.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/videostitcher#videostitcher.admin">Video Stitcher Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/videostitcher.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/videostitcher#videostitcher.viewer">Video Stitcher Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/videostitcher.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/visionai#visionai.admin">VisionAI Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/visionai.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/visionai#visionai.editor">VisionAI Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/visionai.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/visionai#visionai.viewer">VisionAI Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/visionai.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.admin">Visual Inspection AI Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/vmmigration#vmmigration.admin">VM Migration Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/vmmigration.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/vmmigration#vmmigration.viewer">VM Migration Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/vmmigration.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.admin">Vmwareengine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.editor">Vmwareengine Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.viewer">Vmwareengine Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/vpcaccess#vpcaccess.admin">Serverless VPC Access Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/vpcaccess.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/vpcaccess#vpcaccess.user">Serverless VPC Access User</a> (<code class="role-name" translate="no" dir="ltr">roles/vpcaccess.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/vpcaccess#vpcaccess.viewer">Serverless VPC Access Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/vpcaccess.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/workflows#workflows.admin">Workflows Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workflows.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/workflows#workflows.editor">Workflows Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/workflows.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/workflows#workflows.viewer">Workflows Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/workflows.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadcertificate#workloadcertificate.admin">Workload Certificate Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadcertificate.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadcertificate#workloadcertificate.viewer">Workload Certificate Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadcertificate.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadidentity#workloadidentity.admin">Workload Identity API Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadidentity.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadidentity#workloadidentity.viewer">Workload Identity API Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadidentity.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.admin">Workload Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.viewer">Workload Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/workstations#workstations.admin">Cloud Workstations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workstations.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/workstations#workstations.editor">Cloud Workstations Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/workstations.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/accessapproval#accessapproval.approver">Access Approval Approver</a> (<code class="role-name" translate="no" dir="ltr">roles/accessapproval.approver</code>)</p>
<p><a href="/iam/docs/roles-permissions/accessapproval#accessapproval.configEditor">Access Approval Config Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/accessapproval.configEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/accessapproval#accessapproval.invalidator">Access Approval Invalidator</a> (<code class="role-name" translate="no" dir="ltr">roles/accessapproval.invalidator</code>)</p>
<p><a href="/iam/docs/roles-permissions/accesscontextmanager#accesscontextmanager.policyEditor">Access Context Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/accesscontextmanager.policyEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/accesscontextmanager#accesscontextmanager.policyReader">Access Context Manager Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/accesscontextmanager.policyReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/accesscontextmanager#accesscontextmanager.vpcScTroubleshooterViewer">VPC Service Controls Troubleshooter Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/accesscontextmanager.vpcScTroubleshooterViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.colabEnterpriseAdmin">Colab Enterprise Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.colabEnterpriseAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.colabEnterpriseUser">Colab Enterprise User</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.colabEnterpriseUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.entityTypeOwner">Agent Platform Feature Store EntityType owner</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.entityTypeOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.featurestoreAdmin">Agent Platform Feature Store Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.featurestoreAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.featurestoreDataViewer">Agent Platform Feature Store Data Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.featurestoreDataViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.featurestoreDataWriter">Agent Platform Feature Store Data Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.featurestoreDataWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.featurestoreResourceViewer">Agent Platform Feature Store Resource Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.featurestoreResourceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.featurestoreUser">Agent Platform Feature Store User</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.featurestoreUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/alloydb#alloydb.client">AlloyDB Client</a> (<code class="role-name" translate="no" dir="ltr">roles/alloydb.client</code>)</p>
<p><a href="/iam/docs/roles-permissions/alloydb#alloydb.databaseUser">AlloyDB Database User</a> (<code class="role-name" translate="no" dir="ltr">roles/alloydb.databaseUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/analyticshub#analyticshub.listingAdmin">Analytics Hub Listing Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/analyticshub.listingAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/analyticshub#analyticshub.publisher">Analytics Hub Publisher</a> (<code class="role-name" translate="no" dir="ltr">roles/analyticshub.publisher</code>)</p>
<p><a href="/iam/docs/roles-permissions/analyticshub#analyticshub.subscriber">Analytics Hub Subscriber</a> (<code class="role-name" translate="no" dir="ltr">roles/analyticshub.subscriber</code>)</p>
<p><a href="/iam/docs/roles-permissions/analyticshub#analyticshub.subscriptionOwner">Analytics Hub Subscription Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/analyticshub.subscriptionOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigee#apigee.analyticsEditor">Apigee Analytics Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.analyticsEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigee#apigee.analyticsViewer">Apigee Analytics Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.analyticsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigee#apigee.apiReaderV2">Apigee API Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.apiReaderV2</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigee#apigee.developerAdmin">Apigee Developer Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.developerAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigee#apigee.environmentAdmin">Apigee Environment Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.environmentAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigee#apigee.monetizationAdmin">Apigee Monetization Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.monetizationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigee#apigee.portalAdmin">Apigee Portal Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.portalAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigee#apigee.readOnlyAdmin">Apigee Read-only Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.readOnlyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigee#apigee.securityAdmin">Apigee Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigee#apigee.securityViewer">Apigee Security Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.securityViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigee#apigee.spaceConsoleUser">Apigee Space Console User</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.spaceConsoleUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigeeregistry#apigeeregistry.worker">Cloud Apigee Registry Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/apigeeregistry.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/apihub#apihub.addonsAdmin">Cloud API hub Addons Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apihub.addonsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apihub#apihub.attributeAdmin">Cloud API hub Attributes Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apihub.attributeAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apihub#apihub.pluginAdmin">Cloud API hub Plugins Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apihub.pluginAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apihub#apihub.provisioningAdmin">Cloud API hub Provisioning Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apihub.provisioningAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/appengine#appengine.appCreator">App Engine Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.appCreator</code>)</p>
<p><a href="/iam/docs/roles-permissions/appengine#appengine.appViewer">App Engine Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.appViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/appengine#appengine.codeViewer">App Engine Code Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.codeViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/appengine#appengine.debugger">App Engine Managed VM Debug Access</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.debugger</code>)</p>
<p><a href="/iam/docs/roles-permissions/appengine#appengine.deployer">App Engine Deployer</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.deployer</code>)</p>
<p><a href="/iam/docs/roles-permissions/appengine#appengine.memcacheDataAdmin">App Engine Memcache Data Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.memcacheDataAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAdmin">App Engine Service Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apphub#apphub.appManagementViewer">App Management Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apphub.appManagementViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/applianceactivation#applianceactivation.approver">Appliance troubleshooting commands approver</a> (<code class="role-name" translate="no" dir="ltr">roles/applianceactivation.approver</code>)</p>
<p><a href="/iam/docs/roles-permissions/applianceactivation#applianceactivation.troubleshooter">Appliance troubleshooter</a> (<code class="role-name" translate="no" dir="ltr">roles/applianceactivation.troubleshooter</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.projectAdmin">Assured OSS Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.projectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.reader">Assured OSS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.user">Assured OSS User</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredworkloads#assuredworkloads.reader">Assured Workloads Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredworkloads.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.auditor">Audit Manager Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.auditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/automl#automl.predictor">AutoML Predictor</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.predictor</code>)</p>
<p><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.adminViewer">Recommendations AI Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.adminViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/autoscaling#autoscaling.sitesAdmin">Autoscaling Site Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/autoscaling.sitesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/backupdr#backupdr.backupUser">Backup and DR Backup User</a> (<code class="role-name" translate="no" dir="ltr">roles/backupdr.backupUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/backupdr#backupdr.computeEngineOperator">Backup and DR Compute Engine Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/backupdr.computeEngineOperator</code>)</p>
<p><a href="/iam/docs/roles-permissions/backupdr#backupdr.mountUser">Backup and DR Mount User</a> (<code class="role-name" translate="no" dir="ltr">roles/backupdr.mountUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/backupdr#backupdr.restoreUser">Backup and DR Restore User</a> (<code class="role-name" translate="no" dir="ltr">roles/backupdr.restoreUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/backupdr#backupdr.user">Backup and DR User</a> (<code class="role-name" translate="no" dir="ltr">roles/backupdr.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/backupdr#backupdr.userv2">Backup and DR User V2</a> (<code class="role-name" translate="no" dir="ltr">roles/backupdr.userv2</code>)</p>
<p><a href="/iam/docs/roles-permissions/baremetalsolution#baremetalsolution.instancesadmin">Bare Metal Solution Instances Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/baremetalsolution.instancesadmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/baremetalsolution#baremetalsolution.instancesviewer">Bare Metal Solution Instances Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/baremetalsolution.instancesviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/baremetalsolution#baremetalsolution.storageadmin">Bare Metal Solution Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/baremetalsolution.storageadmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/batch#batch.jobsEditor">Batch Job Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/batch.jobsEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/batch#batch.jobsViewer">Batch Job Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/batch.jobsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/batch#batch.resourceAllowancesEditor">Batch ResourceAllowance Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/batch.resourceAllowancesEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/batch#batch.resourceAllowancesViewer">Batch ResourceAllowance Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/batch.resourceAllowancesViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/biglake#biglake.metadataViewer">BigLake Metadata Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/biglake.metadataViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.securityAdmin">BigQuery Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/binaryauthorization#binaryauthorization.attestorsAdmin">Binary Authorization Attestor Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/binaryauthorization.attestorsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/binaryauthorization#binaryauthorization.attestorsEditor">Binary Authorization Attestor Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/binaryauthorization.attestorsEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/binaryauthorization#binaryauthorization.attestorsVerifier">Binary Authorization Attestor Image Verifier</a> (<code class="role-name" translate="no" dir="ltr">roles/binaryauthorization.attestorsVerifier</code>)</p>
<p><a href="/iam/docs/roles-permissions/binaryauthorization#binaryauthorization.attestorsViewer">Binary Authorization Attestor Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/binaryauthorization.attestorsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/binaryauthorization#binaryauthorization.policyAdmin">Binary Authorization Policy Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/binaryauthorization.policyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/binaryauthorization#binaryauthorization.policyEditor">Binary Authorization Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/binaryauthorization.policyEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/binaryauthorization#binaryauthorization.policyEvaluator">Binary Authorization Policy Evaluator</a> (<code class="role-name" translate="no" dir="ltr">roles/binaryauthorization.policyEvaluator</code>)</p>
<p><a href="/iam/docs/roles-permissions/binaryauthorization#binaryauthorization.policyViewer">Binary Authorization Policy Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/binaryauthorization.policyViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/browser#browser">Browser</a> (<code class="role-name" translate="no" dir="ltr">roles/browser</code>)</p>
<p><a href="/iam/docs/roles-permissions/capacityplanner#capacityplanner.planner">Capacity Planner</a> (<code class="role-name" translate="no" dir="ltr">roles/capacityplanner.planner</code>)</p>
<p><a href="/iam/docs/roles-permissions/certificatemanager#certificatemanager.owner">Certificate Manager Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/certificatemanager.owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/ces#ces.agentEditor">Gemini Enterprise for Customer Experience Agent Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/ces.agentEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/ces#ces.appEditor">Gemini Enterprise for Customer Experience App Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/ces.appEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/ces#ces.deploymentEditor">Gemini Enterprise for Customer Experience Deployment Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/ces.deploymentEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/ces#ces.evalsEditor">Gemini Enterprise for Customer Experience Evals Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/ces.evalsEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/ces#ces.guardrailsEditor">Gemini Enterprise for Customer Experience Guardrails Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/ces.guardrailsEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/ces#ces.securitySettingsEditor">Gemini Enterprise for Customer Experience Security Settings Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/ces.securitySettingsEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/ces#ces.toolsEditor">Gemini Enterprise for Customer Experience Tools Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/ces.toolsEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/chronicle#chronicle.dataGovernor">Chronicle API Data Governor</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.dataGovernor</code>)</p>
<p><a href="/iam/docs/roles-permissions/chronicle#chronicle.federationAdmin">Chronicle API Federation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.federationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/chronicle#chronicle.federationViewer">Chronicle API Federation Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.federationViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/chronicle#chronicle.limitedViewer">Chronicle API Limited Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.limitedViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/chronicle#chronicle.restrictedDataAccessViewer">Chronicle API Restricted Data Access Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.restrictedDataAccessViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/chronicle#chronicle.soarAdmin">Chronicle SOAR Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.soarAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/chronicle#chronicle.soarRemoteAgent">Chronicle SOAR Remote Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.soarRemoteAgent</code>)</p>
<p><a href="/iam/docs/roles-permissions/chronicle#chronicle.soarThreatManager">Chronicle SOAR Threat Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.soarThreatManager</code>)</p>
<p><a href="/iam/docs/roles-permissions/chronicle#chronicle.soarVulnerabilityManager">Chronicle SOAR Vulnerability Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.soarVulnerabilityManager</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudaicompanion#cloudaicompanion.codeRepositoryIndexesAdmin">Code Repository Indexes Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudaicompanion.codeRepositoryIndexesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudaicompanion#cloudaicompanion.codeRepositoryIndexesViewer">Code Repository Indexes Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudaicompanion.codeRepositoryIndexesViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudaicompanion#cloudaicompanion.codeToolsAdmin">Gemini Code Assist Tools Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudaicompanion.codeToolsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudaicompanion#cloudaicompanion.codeToolsUser">Gemini Code Assist Tools User</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudaicompanion.codeToolsUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.approver">Cloud Build Approver</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.approver</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.editor">Cloud Build Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.viewer">Cloud Build Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.connectionAdmin">Cloud Build Connection Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.connectionAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.connectionViewer">Cloud Build Connection Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.connectionViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.integrationsEditor">Cloud Build Integrations Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.integrationsEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.integrationsOwner">Cloud Build Integrations Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.integrationsOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.integrationsViewer">Cloud Build Integrations Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.integrationsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.workerPoolEditor">Cloud Build WorkerPool Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.workerPoolEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.workerPoolOwner">Cloud Build WorkerPool Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.workerPoolOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.workerPoolViewer">Cloud Build WorkerPool Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.workerPoolViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/clouddeploy#clouddeploy.approver">Cloud Deploy Approver</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploy.approver</code>)</p>
<p><a href="/iam/docs/roles-permissions/clouddeploy#clouddeploy.customTargetTypeAdmin">Cloud Deploy Custom Target Type Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploy.customTargetTypeAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/clouddeploy#clouddeploy.developer">Cloud Deploy Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploy.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/clouddeploy#clouddeploy.operator">Cloud Deploy Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploy.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/clouddeploy#clouddeploy.policyAdmin">Cloud Deploy Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploy.policyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/clouddeploy#clouddeploy.policyOverrider">Cloud Deploy Policy Overrider</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploy.policyOverrider</code>)</p>
<p><a href="/iam/docs/roles-permissions/clouddeploy#clouddeploy.releaser">Cloud Deploy Releaser</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploy.releaser</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudjobdiscovery#cloudjobdiscovery.jobsEditor">Cloud Talent Solution Job Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudjobdiscovery.jobsEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudjobdiscovery#cloudjobdiscovery.jobsViewer">Cloud Talent Solution Job Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudjobdiscovery.jobsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudjobdiscovery#cloudjobdiscovery.profilesEditor">Cloud Talent Solution Profile Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudjobdiscovery.profilesEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudjobdiscovery#cloudjobdiscovery.profilesViewer">Cloud Talent Solution Profile Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudjobdiscovery.profilesViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.cryptoKeyDecrypterViaDelegation">Cloud KMS CryptoKey Decrypter Via Delegation</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.cryptoKeyDecrypterViaDelegation</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.cryptoKeyEncrypterDecrypterViaDelegation">Cloud KMS CryptoKey Encrypter/Decrypter Via Delegation</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.cryptoKeyEncrypterDecrypterViaDelegation</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.cryptoKeyEncrypterViaDelegation">Cloud KMS CryptoKey Encrypter Via Delegation</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.cryptoKeyEncrypterViaDelegation</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.ekmConnectionsAdmin">Cloud KMS EkmConnections Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.ekmConnectionsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.expertPqcSigner">Cloud KMS Expert PQ Asymmetric Signing Key Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.expertPqcSigner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.expertRawAesCbc">Cloud KMS Expert Raw AES-CBC Key Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.expertRawAesCbc</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.expertRawAesCtr">Cloud KMS Expert Raw AES-CTR Key Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.expertRawAesCtr</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.expertRawPKCS1">Cloud KMS Expert Raw PKCS#1 Key Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.expertRawPKCS1</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudnumberregistry#cloudnumberregistry.ipamAdmin">Cloud Number Registry IPAM Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudnumberregistry.ipamAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudnumberregistry#cloudnumberregistry.ipamViewer">Cloud Number Registry IPAM Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudnumberregistry.ipamViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudprivatecatalog#cloudprivatecatalog.consumer">Catalog Consumer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudprivatecatalog.consumer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudprivatecatalog#cloudprivatecatalogproducer.manager">Catalog Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudprivatecatalogproducer.manager</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudprivatecatalog#cloudprivatecatalogproducer.orgAdmin">Catalog Org Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudprivatecatalogproducer.orgAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudprofiler#cloudprofiler.user">Cloud Profiler User</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudprofiler.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.jobRunner">Cloud Scheduler Job Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.jobRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsupport#cloudsupport.advisorySupportEditor">Advisory Support Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsupport.advisorySupportEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsupport#cloudsupport.advisorySupportViewer">Advisory Support Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsupport.advisorySupportViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsupport#cloudsupport.techSupportEditor">Tech Support Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsupport.techSupportEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsupport#cloudsupport.techSupportViewer">Tech Support Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsupport.techSupportViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.enqueuer">Cloud Tasks Enqueuer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.enqueuer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.queueAdmin">Cloud Tasks Queue Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.queueAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.taskDeleter">Cloud Tasks Task Deleter</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.taskDeleter</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.taskRunner">Cloud Tasks Task Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.taskRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtestservice#cloudtestservice.directAccessAdmin">Firebase Test Lab Direct Access Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtestservice.directAccessAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtestservice#cloudtestservice.directAccessViewer">Firebase Test Lab Direct Access Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtestservice.directAccessViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtestservice#cloudtestservice.testAdmin">Firebase Test Lab Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtestservice.testAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtestservice#cloudtestservice.testViewer">Firebase Test Lab Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtestservice.testViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercebusinessenablement#commercebusinessenablement.paymentConfigAdmin">Commerce Business Enablement PaymentConfig Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/commercebusinessenablement.paymentConfigAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercebusinessenablement#commercebusinessenablement.paymentConfigViewer">Commerce Business Enablement PaymentConfig Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/commercebusinessenablement.paymentConfigViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercebusinessenablement#commercebusinessenablement.resellerDiscountAdmin">Commerce Business Enablement Reseller Discount Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/commercebusinessenablement.resellerDiscountAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercebusinessenablement#commercebusinessenablement.resellerDiscountViewer">Commerce Business Enablement Reseller Discount Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/commercebusinessenablement.resellerDiscountViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/commerceorggovernance#commerceorggovernance.user">Governed Marketplace User</a> (<code class="role-name" translate="no" dir="ltr">roles/commerceorggovernance.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercepricemanagement#commercepricemanagement.eventsViewer">Commerce Price Management Events Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/commercepricemanagement.eventsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercepricemanagement#commercepricemanagement.privateOffersAdmin">Commerce Price Management Private Offers Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/commercepricemanagement.privateOffersAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectAdmin">Environment and Storage Object Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectUser">Environment and Storage Object User</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectViewer">Environment and Storage Object Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.imageUser">Compute Image User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.imageUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.loadBalancerServiceUser">Compute Load Balancer Services User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.loadBalancerServiceUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgFirewallPolicyAdmin">Compute Organization Firewall Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgFirewallPolicyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgFirewallPolicyUser">Compute Organization Firewall Policy User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgFirewallPolicyUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgSecurityPolicyAdmin">Compute Organization Security Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgSecurityPolicyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgSecurityPolicyUser">Compute Organization Security Policy User</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgSecurityPolicyUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.orgSecurityResourceAdmin">Compute Organization Resource Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.orgSecurityResourceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.packetMirroringAdmin">Compute packet mirroring admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.packetMirroringAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.packetMirroringUser">Compute packet mirroring user</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.packetMirroringUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.publicIpAdmin">Compute Public IP Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.publicIpAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.vmExtensionPolicyAdmin">Compute VM extension policy admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.vmExtensionPolicyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.vmExtensionPolicyViewer">Compute VM extension policy viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.vmExtensionPolicyViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.xpnAdmin">Compute Shared VPC Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.xpnAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/configdelivery#configdelivery.configDeliveryAdmin">ConfigDelivery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/configdelivery.configDeliveryAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/configdelivery#configdelivery.configDeliveryViewer">ConfigDelivery Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/configdelivery.configDeliveryViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/configdelivery#configdelivery.resourceBundlePublisher">Config Delivery Resource Bundle Publisher</a> (<code class="role-name" translate="no" dir="ltr">roles/configdelivery.resourceBundlePublisher</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.entitlementManager">Consumer Procurement Entitlement Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.entitlementManager</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.entitlementViewer">Consumer Procurement Entitlement Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.entitlementViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.procurementAdmin">Consumer Procurement Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.procurementAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/consumerprocurement#consumerprocurement.procurementViewer">Consumer Procurement Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/consumerprocurement.procurementViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.notes.editor">Container Analysis Notes Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.notes.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.notes.viewer">Container Analysis Notes Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.notes.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.occurrences.editor">Container Analysis Occurrences Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.occurrences.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.occurrences.viewer">Container Analysis Occurrences Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.occurrences.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/contentwarehouse#contentwarehouse.documentAdmin">Content Warehouse Document Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/contentwarehouse.documentAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/contentwarehouse#contentwarehouse.documentCreator">Content Warehouse document creator</a> (<code class="role-name" translate="no" dir="ltr">roles/contentwarehouse.documentCreator</code>)</p>
<p><a href="/iam/docs/roles-permissions/contentwarehouse#contentwarehouse.documentEditor">Content Warehouse Document Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/contentwarehouse.documentEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/contentwarehouse#contentwarehouse.documentSchemaViewer">Content Warehouse document schema viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/contentwarehouse.documentSchemaViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/contentwarehouse#contentwarehouse.documentViewer">Content Warehouse Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/contentwarehouse.documentViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/databaseinsights#databaseinsights.monitoringViewer">Database Insights monitoring viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/databaseinsights.monitoringViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/databaseinsights#databaseinsights.recommendationViewer">Database Insights recommendation viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/databaseinsights.recommendationViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/databasesconsole#databasesconsole.studioQueryAdmin">Studio Query Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/databasesconsole.studioQueryAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/databasesconsole#databasesconsole.studioQueryUser">Studio Query User</a> (<code class="role-name" translate="no" dir="ltr">roles/databasesconsole.studioQueryUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.categoryAdmin">Policy Tag Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.categoryAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.dataSteward">DataCatalog Data Steward</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.dataSteward</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.entryGroupCreator">DataCatalog EntryGroup Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.entryGroupCreator</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.entryGroupOwner">DataCatalog EntryGroup Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.entryGroupOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.entryOwner">DataCatalog Entry Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.entryOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.entryViewer">DataCatalog Entry Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.entryViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.migrationConfigAdmin">DataCatalog Migration Config Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.migrationConfigAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.searchAdmin">DataCatalog Search Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.searchAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.tagTemplateOwner">Data Catalog TagTemplate Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.tagTemplateOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.tagTemplateUser">Data Catalog TagTemplate User</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.tagTemplateUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.tagTemplateViewer">Data Catalog TagTemplate Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.tagTemplateViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataconnectors#dataconnectors.connectorAdmin">Connector Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataconnectors.connectorAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.developer">Dataflow Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataform#dataform.codeCommenter">Code Commenter</a> (<code class="role-name" translate="no" dir="ltr">roles/dataform.codeCommenter</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataform#dataform.codeCreator">Code Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/dataform.codeCreator</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataform#dataform.codeEditor">Code Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dataform.codeEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataform#dataform.codeOwner">Code Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/dataform.codeOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataform#dataform.codeViewer">Code Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataform.codeViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataform#dataform.teamFolderCommenter">Team Folder Commenter</a> (<code class="role-name" translate="no" dir="ltr">roles/dataform.teamFolderCommenter</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataform#dataform.teamFolderContributor">Team Folder Contributor</a> (<code class="role-name" translate="no" dir="ltr">roles/dataform.teamFolderContributor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataform#dataform.teamFolderOwner">Team Folder Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/dataform.teamFolderOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataform#dataform.teamFolderViewer">Team Folder Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataform.teamFolderViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/datafusion#datafusion.accessor">Cloud Data Fusion Accessor</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.accessor</code>)</p>
<p><a href="/iam/docs/roles-permissions/datafusion#datafusion.developer">Cloud Data Fusion Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/datafusion#datafusion.operator">Cloud Data Fusion Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/datalineage#datalineage.producer">Data Lineage Events Producer</a> (<code class="role-name" translate="no" dir="ltr">roles/datalineage.producer</code>)</p>
<p><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.invoker">Data pipelines Invoker</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.invoker</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.aspectTypeOwner">Dataplex Aspect Type Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.aspectTypeOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.aspectTypeUser">Dataplex Aspect Type User</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.aspectTypeUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.catalogAdmin">Dataplex Catalog Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.catalogAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.catalogEditor">Dataplex Catalog Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.catalogEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.catalogViewer">Dataplex Catalog Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.catalogViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.contentAdmin">Dataplex Content Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.contentAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.contentCreator">Dataplex Content Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.contentCreator</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.contentEditor">Dataplex Content Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.contentEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.contentUser">Dataplex Content User</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.contentUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.contentViewer">Dataplex Content Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.contentViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.dataDomainAdmin">Dataplex Data Domain Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.dataDomainAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.dataDomainEditor">Dataplex Data Domain Configuration Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.dataDomainEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.dataDomainViewer">Dataplex Data Domain Configuration Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.dataDomainViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.dataProductsAdmin">Dataplex Data Products Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.dataProductsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.dataProductsConsumer">Dataplex Data Products Consumer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.dataProductsConsumer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.dataProductsEditor">Dataplex Data Products Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.dataProductsEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.dataProductsViewer">Dataplex Data Products Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.dataProductsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.entryGroupExporter">Dataplex Entry Group Exporter</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.entryGroupExporter</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.entryGroupImporter">Dataplex Entry Group Importer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.entryGroupImporter</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.entryGroupOwner">Dataplex Entry Group Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.entryGroupOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.entryLinkTypeOwner">Dataplex Entry Link Type Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.entryLinkTypeOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.entryLinkTypeUser">Dataplex Entry Link Type User</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.entryLinkTypeUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.entryOwner">Dataplex Entry and EntryLink Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.entryOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.entryTypeOwner">Dataplex Entry Type Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.entryTypeOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.entryTypeUser">Dataplex Entry Type User</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.entryTypeUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.metadataFeedOwner">Dataplex Metadata Feed Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.metadataFeedOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.metadataFeedViewer">Dataplex Metadata Feed Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.metadataFeedViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.metadataJobOwner">Dataplex Metadata Job Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.metadataJobOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.metadataJobViewer">Dataplex Metadata Job Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.metadataJobViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.metadataReader">Dataplex Metadata Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.metadataReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.metadataWriter">Dataplex Metadata Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.metadataWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.hubAgent">Dataproc Hub Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.hubAgent</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.serverlessEditor">Dataproc Serverless Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serverlessEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.serverlessViewer">Dataproc Serverless Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serverlessViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firestore#datastore.bulkAdmin">Cloud Datastore Bulk Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/datastore.bulkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firestore#datastore.importExportAdmin">Cloud Datastore Import Export Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/datastore.importExportAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firestore#datastore.indexAdmin">Cloud Datastore Index Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/datastore.indexAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firestore#datastore.keyVisualizerViewer">Cloud Datastore Key Visualizer Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/datastore.keyVisualizerViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dellemccloudonefs#dellemccloudonefs.user">Dell EMC Cloud OneFS User</a> (<code class="role-name" translate="no" dir="ltr">roles/dellemccloudonefs.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.typeEditor">Deployment Manager Type Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.typeEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/deploymentmanager#deploymentmanager.typeViewer">Deployment Manager Type Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/deploymentmanager.typeViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.applicationAdmin">Application Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.applicationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.applicationEditor">Application Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.applicationEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.applicationViewer">Application Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.applicationViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.user">Application Design Center User</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/developerconnect#developerconnect.insightsAdmin">Developer Connect Insights Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/developerconnect.insightsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/developerconnect#developerconnect.insightsViewer">Developer Connect Insights Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/developerconnect.insightsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/developerconnect#developerconnect.oauthAdmin">Developer Connect OAuth Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/developerconnect.oauthAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/developerconnect#developerconnect.oauthUser">Developer Connect OAuth User</a> (<code class="role-name" translate="no" dir="ltr">roles/developerconnect.oauthUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/developerconnect#developerconnect.user">Developer Connect User</a> (<code class="role-name" translate="no" dir="ltr">roles/developerconnect.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/dialogflow#dialogflow.aamAdmin">CX Premium Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dialogflow.aamAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dialogflow#dialogflow.aamConversationalArchitect">CX Premium Conversational Architect</a> (<code class="role-name" translate="no" dir="ltr">roles/dialogflow.aamConversationalArchitect</code>)</p>
<p><a href="/iam/docs/roles-permissions/dialogflow#dialogflow.aamDialogDesigner">CX Premium Dialog Designer</a> (<code class="role-name" translate="no" dir="ltr">roles/dialogflow.aamDialogDesigner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dialogflow#dialogflow.aamLeadDialogDesigner">CX Premium Lead Dialog Designer</a> (<code class="role-name" translate="no" dir="ltr">roles/dialogflow.aamLeadDialogDesigner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dialogflow#dialogflow.aamViewer">CX Premium Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dialogflow.aamViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dialogflow#dialogflow.consoleSimulatorUser">Dialogflow Console Simulator User</a> (<code class="role-name" translate="no" dir="ltr">roles/dialogflow.consoleSimulatorUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/dialogflow#dialogflow.consoleSmartMessagingAllowlistEditor">Dialogflow Console Smart Messaging Allowlist Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dialogflow.consoleSmartMessagingAllowlistEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceAdmin">Gemini Enterprise Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceEditor">Gemini Enterprise Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceRestrictedUser">Gemini Enterprise Restricted User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceRestrictedUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceUser">Gemini Enterprise User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceViewer">Gemini Enterprise Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.notebookLmOwner">Cloud NotebookLM Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.notebookLmOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.notebookLmUser">Cloud NotebookLM User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.notebookLmUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.podcastApiUser">Podcast API User</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.podcastApiUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.connectionsAdmin">DLP Connections Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.connectionsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.subscriptionsAdmin">DLP Subscription Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.subscriptionsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dns#dns.reader">DNS Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/dns.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/earth#earth.subscriptionsAdmin">Earth Subscriptions Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/earth.subscriptionsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/earth#earth.subscriptionsViewer">Earth Subscriptions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/earth.subscriptionsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/earthengine#earthengine.writer">Earth Engine Resource Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/earthengine.writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.machineUser">Edge Container Machine User</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.machineUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.offlineCredentialUser">Edge Container Cluster offline Credential User</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.offlineCredentialUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/eventarc#eventarc.connectionPublisher">Eventarc Connection Publisher</a> (<code class="role-name" translate="no" dir="ltr">roles/eventarc.connectionPublisher</code>)</p>
<p><a href="/iam/docs/roles-permissions/eventarc#eventarc.developer">Eventarc Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/eventarc.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/eventarc#eventarc.publisher">Eventarc Publisher</a> (<code class="role-name" translate="no" dir="ltr">roles/eventarc.publisher</code>)</p>
<p><a href="/iam/docs/roles-permissions/faulttesting#faulttesting.operator">Fault Testing Admin/Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/faulttesting.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.analyticsAdmin">Firebase Analytics Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.analyticsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.analyticsViewer">Firebase Analytics Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.analyticsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.growthAdmin">Firebase Grow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.growthAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.growthViewer">Firebase Grow Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.growthViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.qualityAdmin">Firebase Quality Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.qualityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.qualityViewer">Firebase Quality Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.qualityViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.developer">Firebase App Hosting Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseextensions#firebaseextensions.developer">Firebase Extensions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseextensions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseextensionspublisher#firebaseextensionspublisher.extensionsAdmin">Firebase Extensions Publisher - Extensions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseextensionspublisher.extensionsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseextensionspublisher#firebaseextensionspublisher.extensionsViewer">Firebase Extensions Publisher - Extensions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseextensionspublisher.extensionsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/fleetengine#fleetengine.deliveryAdmin">Fleet Engine Delivery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/fleetengine.deliveryAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/fleetengine#fleetengine.deliverySuperUser">Fleet Engine Delivery Super User</a> (<code class="role-name" translate="no" dir="ltr">roles/fleetengine.deliverySuperUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/fleetengine#fleetengine.ondemandAdmin">Fleet Engine On-Demand Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/fleetengine.ondemandAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/fleetengine#fleetengine.serviceSuperUser">Fleet Engine Service Super User</a> (<code class="role-name" translate="no" dir="ltr">roles/fleetengine.serviceSuperUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/gdchardwaremanagement#gdchardwaremanagement.operator">GDC Hardware Management Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/gdchardwaremanagement.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/gdchardwaremanagement#gdchardwaremanagement.reader">GDC Hardware Management Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/gdchardwaremanagement.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.investigationAdmin">Gemini Cloud Assist Investigation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.investigationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.investigationCreator">Gemini Cloud Assist Investigation Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.investigationCreator</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.investigationEditor">Gemini Cloud Assist Investigation Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.investigationEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.investigationUser">Gemini Cloud Assist Investigation User</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.investigationUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.investigationViewer">Gemini Cloud Assist Investigation Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.investigationViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkebackup#gkebackup.backupAdmin">Backup for GKE Backup Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/gkebackup.backupAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkebackup#gkebackup.restoreAdmin">Backup for GKE Restore Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/gkebackup.restoreAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.scopeEditorProjectLevel">Fleet Project-level Scope Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.scopeEditorProjectLevel</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkehub#gkehub.scopeViewerProjectLevel">Fleet Project-level Scope Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.scopeViewerProjectLevel</code>)</p>
<p><a href="/iam/docs/roles-permissions/gsuiteaddons#gsuiteaddons.developer">Google Workspace Add-ons Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/gsuiteaddons.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/gsuiteaddons#gsuiteaddons.reader">Google Workspace Add-ons Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/gsuiteaddons.reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/gsuiteaddons#gsuiteaddons.tester">Google Workspace Add-ons Tester</a> (<code class="role-name" translate="no" dir="ltr">roles/gsuiteaddons.tester</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.annotationEditor">Healthcare Annotation Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.annotationEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.annotationReader">Healthcare Annotation Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.annotationReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.annotationStoreAdmin">Healthcare Annotation Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.annotationStoreAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.annotationStoreViewer">Healthcare Annotation Store Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.annotationStoreViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.attributeDefinitionEditor">Healthcare Attribute Definition Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.attributeDefinitionEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.attributeDefinitionReader">Healthcare Attribute Definition Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.attributeDefinitionReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.consentArtifactAdmin">Healthcare Consent Artifact Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.consentArtifactAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.consentArtifactEditor">Healthcare Consent Artifact Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.consentArtifactEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.consentArtifactReader">Healthcare Consent Artifact Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.consentArtifactReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.consentEditor">Healthcare Consent Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.consentEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.consentReader">Healthcare Consent Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.consentReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.consentStoreAdmin">Healthcare Consent Store Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.consentStoreAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.consentStoreViewer">Healthcare Consent Store Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.consentStoreViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.datasetAdmin">Healthcare Dataset Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.datasetAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.datasetViewer">Healthcare Dataset Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.datasetViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.dicomEditor">Healthcare DICOM Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.dicomEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.dicomStoreAdmin">Healthcare DICOM Store Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.dicomStoreAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.dicomStoreViewer">Healthcare DICOM Store Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.dicomStoreViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.dicomViewer">Healthcare DICOM Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.dicomViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.fhirResourceEditor">Healthcare FHIR Resource Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.fhirResourceEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.fhirResourceReader">Healthcare FHIR Resource Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.fhirResourceReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.fhirStoreAdmin">Healthcare FHIR Store Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.fhirStoreAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.fhirStoreViewer">Healthcare FHIR Store Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.fhirStoreViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.hl7V2Consumer">Healthcare HL7v2 Message Consumer</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.hl7V2Consumer</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.hl7V2Editor">Healthcare HL7v2 Message Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.hl7V2Editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.hl7V2Ingest">Healthcare HL7v2 Message Ingest</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.hl7V2Ingest</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.hl7V2StoreAdmin">Healthcare HL7v2 Store Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.hl7V2StoreAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.hl7V2StoreViewer">Healthcare HL7v2 Store Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.hl7V2StoreViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.nlpServiceViewer">Healthcare NLP Service Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.nlpServiceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.userDataMappingEditor">Healthcare User Data Mapping Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.userDataMappingEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/healthcare#healthcare.userDataMappingReader">Healthcare User Data Mapping Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.userDataMappingReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.oauthClientAdmin">IAM OAuth Client Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.oauthClientAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.oauthClientViewer">IAM OAuth Client Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.oauthClientViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.organizationRoleAdmin">Organization Role Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.organizationRoleAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.organizationRoleViewer">Organization Role Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.organizationRoleViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountDeleter">Delete Service Accounts</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountDeleter</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolAdmin">IAM Workload Identity Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolViewer">IAM Workload Identity Pool Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/integrations#integrations.apigeeIntegrationAdminRole">Apigee Integration Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.apigeeIntegrationAdminRole</code>)</p>
<p><a href="/iam/docs/roles-permissions/integrations#integrations.apigeeIntegrationDeployerRole">Apigee Integration Deployer</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.apigeeIntegrationDeployerRole</code>)</p>
<p><a href="/iam/docs/roles-permissions/integrations#integrations.apigeeIntegrationEditorRole">Apigee Integration Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.apigeeIntegrationEditorRole</code>)</p>
<p><a href="/iam/docs/roles-permissions/integrations#integrations.apigeeIntegrationInvokerRole">Apigee Integration Invoker</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.apigeeIntegrationInvokerRole</code>)</p>
<p><a href="/iam/docs/roles-permissions/integrations#integrations.apigeeIntegrationsViewer">Apigee Integration Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.apigeeIntegrationsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/integrations#integrations.apigeeSuspensionResolver">Apigee Integration Approver</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.apigeeSuspensionResolver</code>)</p>
<p><a href="/iam/docs/roles-permissions/integrations#integrations.certificateViewer">Certificate Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.certificateViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/integrations#integrations.integrationAdmin">Application Integration Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.integrationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/integrations#integrations.integrationDeployer">Application Integration Deployer</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.integrationDeployer</code>)</p>
<p><a href="/iam/docs/roles-permissions/integrations#integrations.integrationEditor">Application Integration Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.integrationEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/integrations#integrations.integrationInvoker">Application Integration Invoker</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.integrationInvoker</code>)</p>
<p><a href="/iam/docs/roles-permissions/integrations#integrations.integrationViewer">Application Integration Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.integrationViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/integrations#integrations.sfdcInstanceAdmin">Application Integration SFDC Instance Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.sfdcInstanceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/integrations#integrations.sfdcInstanceEditor">Application Integration SFDC Instance Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.sfdcInstanceEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/integrations#integrations.sfdcInstanceViewer">Application Integration SFDC Instance Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.sfdcInstanceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/integrations#integrations.suspensionResolver">Application Integration Approver</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.suspensionResolver</code>)</p>
<p><a href="/iam/docs/roles-permissions/issuerswitch#issuerswitch.accountManagerAdmin">Issuerswitch Account Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/issuerswitch.accountManagerAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/issuerswitch#issuerswitch.accountManagerTransactionsAdmin">Issuerswitch Account Manager Transactions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/issuerswitch.accountManagerTransactionsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/issuerswitch#issuerswitch.accountManagerTransactionsViewer">Issuerswitch Account Manager Transactions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/issuerswitch.accountManagerTransactionsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/issuerswitch#issuerswitch.issuerParticipantsAdmin">Issuerswitch Participants Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/issuerswitch.issuerParticipantsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/issuerswitch#issuerswitch.resolutionsAdmin">Issuerswitch Resolutions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/issuerswitch.resolutionsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/issuerswitch#issuerswitch.rulesAdmin">Issuerswitch Rules Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/issuerswitch.rulesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/issuerswitch#issuerswitch.rulesViewer">Issuerswitch Rules Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/issuerswitch.rulesViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/issuerswitch#issuerswitch.transactionsViewer">Issuerswitch Transactions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/issuerswitch.transactionsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/looker#looker.instanceUser">Looker Instance User</a> (<code class="role-name" translate="no" dir="ltr">roles/looker.instanceUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/datastudio#lookerstudio.proManager">Looker Studio Pro Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/lookerstudio.proManager</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedflink#managedflink.developer">Managed Flink Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/managedflink.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.backupAdmin">Google Cloud Managed Identities Backup Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.backupAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.backupViewer">Google Cloud Managed Identities Backup Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.backupViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.domainAdmin">Google Cloud Managed Identities Domain Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.domainAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.peeringAdmin">Google Cloud Managed Identities Peering Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.peeringAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.peeringViewer">Google Cloud Managed Identities Peering Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.peeringViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.client">Managed Kafka Client</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.client</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.clusterEditor">Managed Kafka Cluster Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.clusterEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.connectorEditor">Managed Kafka Connector Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.connectorEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.consumerGroupEditor">Managed Kafka Consumer Group Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.consumerGroupEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/managedkafka#managedkafka.topicEditor">Managed Kafka Topic Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/managedkafka.topicEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/mandiant#mandiant.attackSurfaceManagementEditor">Mandiant Attack Surface Management Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/mandiant.attackSurfaceManagementEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/mandiant#mandiant.attackSurfaceManagementViewer">Mandiant Attack Surface Management Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/mandiant.attackSurfaceManagementViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/mandiant#mandiant.digitalThreatMonitoringEditor">Mandiant Digital Threat Monitoring Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/mandiant.digitalThreatMonitoringEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/mandiant#mandiant.digitalThreatMonitoringViewer">Mandiant Digital Threat Monitoring Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/mandiant.digitalThreatMonitoringViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/mandiant#mandiant.expertiseOnDemandEditor">Mandiant Expertise On Demand Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/mandiant.expertiseOnDemandEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/mandiant#mandiant.expertiseOnDemandViewer">Mandiant Expertise On Demand Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/mandiant.expertiseOnDemandViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/mandiant#mandiant.threatIntelEditor">Mandiant Threat Intel Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/mandiant.threatIntelEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/mandiant#mandiant.threatIntelViewer">Mandiant Threat Intel Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/mandiant.threatIntelViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/mandiant#mandiant.validationEditor">Mandiant Validation Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/mandiant.validationEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/mandiant#mandiant.validationViewer">Mandiant Validation Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/mandiant.validationViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/mapsanalytics#mapsanalytics.mobilitySolutionsOverageViewer">Mobility Solutions Overages Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/mapsanalytics.mobilitySolutionsOverageViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/metastore#metastore.metadataOperator">Dataproc Metastore Metadata Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/metastore.metadataOperator</code>)</p>
<p><a href="/iam/docs/roles-permissions/metastore#metastore.user">Dataproc Metastore Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/metastore.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/migrationcenter#migrationcenter.discoveryClientRegistrator">Migration Center Discovery Client Registrator</a> (<code class="role-name" translate="no" dir="ltr">roles/migrationcenter.discoveryClientRegistrator</code>)</p>
<p><a href="/iam/docs/roles-permissions/modelarmor#modelarmor.calloutUser">Model Armor Callout User</a> (<code class="role-name" translate="no" dir="ltr">roles/modelarmor.calloutUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/modelarmor#modelarmor.floorSettingsAdmin">Model Armor Floor Setting Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/modelarmor.floorSettingsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/modelarmor#modelarmor.floorSettingsViewer">Model Armor Floor Setting Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/modelarmor.floorSettingsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/modelarmor#modelarmor.user">Model Armor User</a> (<code class="role-name" translate="no" dir="ltr">roles/modelarmor.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#monitoring.metricsScopesAdmin">Monitoring Metrics Scopes Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/monitoring.metricsScopesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#monitoring.metricsScopesViewer">Monitoring Metrics Scopes Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/monitoring.metricsScopesViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/nestconsole#nestconsole.homeDeveloperAdmin">Google Home Developer Console Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/nestconsole.homeDeveloperAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/nestconsole#nestconsole.homeDeveloperEditor">Google Home Developer Console Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/nestconsole.homeDeveloperEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/nestconsole#nestconsole.homeDeveloperViewer">Google Home Developer Console Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/nestconsole.homeDeveloperViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkconnectivity#networkconnectivity.consumerNetworkAdmin">Service Automation Consumer Network Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networkconnectivity.consumerNetworkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkconnectivity#networkconnectivity.groupAdmin">Group Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networkconnectivity.groupAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkconnectivity#networkconnectivity.hubAdmin">Hub &amp; Spoke Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networkconnectivity.hubAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkconnectivity#networkconnectivity.hubViewer">Hub &amp; Spoke Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/networkconnectivity.hubViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkconnectivity#networkconnectivity.multicloudDataTransferConfigAdmin">Multicloud Data Transfer Config Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networkconnectivity.multicloudDataTransferConfigAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkconnectivity#networkconnectivity.multicloudDataTransferConfigViewer">Multicloud Data Transfer Config Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/networkconnectivity.multicloudDataTransferConfigViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkconnectivity#networkconnectivity.multicloudDataTransferDestinationAdmin">Destination Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networkconnectivity.multicloudDataTransferDestinationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkconnectivity#networkconnectivity.multicloudDataTransferDestinationViewer">Destination Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/networkconnectivity.multicloudDataTransferDestinationViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkconnectivity#networkconnectivity.regionalEndpointAdmin">Regional Endpoint Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networkconnectivity.regionalEndpointAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkconnectivity#networkconnectivity.regionalEndpointViewer">Regional Endpoint Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/networkconnectivity.regionalEndpointViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkconnectivity#networkconnectivity.serviceClassUser">Service Class User</a> (<code class="role-name" translate="no" dir="ltr">roles/networkconnectivity.serviceClassUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkconnectivity#networkconnectivity.serviceProducerAdmin">Service Automation Service Producer Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networkconnectivity.serviceProducerAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkconnectivity#networkconnectivity.spokeAdmin">Spoke Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networkconnectivity.spokeAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkconnectivity#networkconnectivity.transportAdmin">Transport Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networkconnectivity.transportAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkconnectivity#networkconnectivity.transportViewer">Transport Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/networkconnectivity.transportViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkmanagement#networkmanagement.CloudNetworkInsightsAdmin">Cloud Network Insights Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networkmanagement.CloudNetworkInsightsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkmanagement#networkmanagement.CloudNetworkInsightsEditor">Cloud Network Insights Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/networkmanagement.CloudNetworkInsightsEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkmanagement#networkmanagement.CloudNetworkInsightsViewer">Cloud Network Insights Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/networkmanagement.CloudNetworkInsightsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/networksecurity#networksecurity.dnsThreatDetectorAdmin">DNS Threat Detector Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networksecurity.dnsThreatDetectorAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networksecurity#networksecurity.dnsThreatDetectorViewer">DNS Threat Detector Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/networksecurity.dnsThreatDetectorViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/networksecurity#networksecurity.firewallEndpointAdmin">Firewall Endpoint Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networksecurity.firewallEndpointAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networksecurity#networksecurity.interceptDeploymentAdmin">Intercept Deployment Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networksecurity.interceptDeploymentAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networksecurity#networksecurity.interceptDeploymentViewer">Intercept Deployment Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/networksecurity.interceptDeploymentViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/networksecurity#networksecurity.interceptEndpointAdmin">Intercept Endpoint Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networksecurity.interceptEndpointAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networksecurity#networksecurity.interceptEndpointViewer">Intercept Endpoint Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/networksecurity.interceptEndpointViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/networksecurity#networksecurity.mirroringDeploymentAdmin">Mirroring Deployment Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networksecurity.mirroringDeploymentAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networksecurity#networksecurity.mirroringDeploymentViewer">Mirroring Deployment Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/networksecurity.mirroringDeploymentViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/networksecurity#networksecurity.mirroringEndpointAdmin">Mirroring Endpoint Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networksecurity.mirroringEndpointAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networksecurity#networksecurity.mirroringEndpointViewer">Mirroring Endpoint Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/networksecurity.mirroringEndpointViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/networksecurity#networksecurity.securityProfileAdmin">Security Profile Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networksecurity.securityProfileAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkservices#networkservices.GoogleTagGatewayPolicyAdmin">Google Tag Gateway Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networkservices.GoogleTagGatewayPolicyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkservices#networkservices.serviceExtensionsAdmin">Service Extensions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/networkservices.serviceExtensionsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/networkservices#networkservices.serviceExtensionsViewer">Service Extensions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/networkservices.serviceExtensionsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.legacyAdmin">Notebooks Legacy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.legacyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.legacyViewer">Notebooks Legacy Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.legacyViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.runner">Notebooks Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.runner</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.autonomousDatabaseAdmin">Oracle Database@Google Cloud Autonomous Database Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.autonomousDatabaseAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.autonomousDatabaseViewer">Oracle Database@Google Cloud Autonomous Database Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.autonomousDatabaseViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.cloudExadataInfrastructureAdmin">Oracle Database@Google Cloud Exadata Infrastructure Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.cloudExadataInfrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.cloudExadataInfrastructureUser">Oracle Database@Google Cloud Exadata Infrastructure User</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.cloudExadataInfrastructureUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.cloudExadataInfrastructureViewer">Oracle Database@Google Cloud Exadata Infrastructure Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.cloudExadataInfrastructureViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.cloudVmClusterAdmin">Oracle Database@Google Cloud VM Cluster Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.cloudVmClusterAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.cloudVmClusterViewer">Oracle Database@Google Cloud VM Cluster Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.cloudVmClusterViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.databaseViewer">Oracle Database@Google Cloud Container Database Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.databaseViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.dbSystemAdmin">Oracle Database@Google Cloud DB System Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.dbSystemAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.dbSystemViewer">Oracle Database@Google Cloud DB System Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.dbSystemViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.exadbVmClusterAdmin">Oracle Database@Google Cloud Exadata Database Service on Exascale Infrastructure VM Cluster Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.exadbVmClusterAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.exadbVmClusterViewer">Oracle Database@Google Cloud Exadata Database Service on Exascale Infrastructure VM Cluster Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.exadbVmClusterViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.exascaleDbStorageVaultAdmin">Oracle Database@Google Cloud Exadata Database Service on Exascale Infrastructure Storage Vault Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.exascaleDbStorageVaultAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.exascaleDbStorageVaultUser">Oracle Database@Google Cloud Exadata Database Service on Exascale Infrastructure Storage Vault User</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.exascaleDbStorageVaultUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.exascaleDbStorageVaultViewer">Oracle Database@Google Cloud Exadata Database Service on Exascale Infrastructure Storage Vault Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.exascaleDbStorageVaultViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.goldenGateConnectionAdmin">Oracle Database@Google Cloud GoldenGate Connection Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.goldenGateConnectionAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.goldenGateConnectionAssignmentAdmin">Oracle Database@Google Cloud GoldenGate Connection Assignment Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.goldenGateConnectionAssignmentAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.goldenGateConnectionAssignmentViewer">Oracle Database@Google Cloud GoldenGate Connection Assignment Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.goldenGateConnectionAssignmentViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.goldenGateConnectionViewer">Oracle Database@Google Cloud GoldenGate Connection Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.goldenGateConnectionViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.goldenGateConnectionsUser">Oracle Database@Google GoldenGate Connections User</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.goldenGateConnectionsUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.goldenGateDeploymentAdmin">Oracle Database@Google Cloud GoldenGate Deployment Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.goldenGateDeploymentAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.goldenGateDeploymentViewer">Oracle Database@Google Cloud GoldenGate Deployment Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.goldenGateDeploymentViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.goldenGateDeploymentsUser">Oracle Database@Google GoldenGate Deployments User</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.goldenGateDeploymentsUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.networkAdmin">Oracle Database@Google Network Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.odbNetworkAdmin">Oracle Database@Google ODB Network Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.odbNetworkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.odbNetworkViewer">Oracle Database@Google ODB Network Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.odbNetworkViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.odbSubnetAdmin">Oracle Database@Google ODB Subnet Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.odbSubnetAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.odbSubnetUser">Oracle Database@Google ODB Subnet User</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.odbSubnetUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.odbSubnetViewer">Oracle Database@Google ODB Subnet Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.odbSubnetViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/oracledatabase#oracledatabase.pluggableDatabaseViewer">Oracle Database@Google Cloud Pluggable Database Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/oracledatabase.pluggableDatabaseViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/osconfig#osconfig.guestPolicyAdmin">GuestPolicy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/osconfig.guestPolicyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/osconfig#osconfig.guestPolicyEditor">GuestPolicy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/osconfig.guestPolicyEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/osconfig#osconfig.guestPolicyViewer">GuestPolicy Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/osconfig.guestPolicyViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/osconfig#osconfig.instanceOSPoliciesComplianceViewer">InstanceOSPoliciesCompliance Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/osconfig.instanceOSPoliciesComplianceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/osconfig#osconfig.inventoryViewer">OS Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/osconfig.inventoryViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/osconfig#osconfig.osPolicyAssignmentAdmin">OSPolicyAssignment Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/osconfig.osPolicyAssignmentAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/osconfig#osconfig.osPolicyAssignmentEditor">OSPolicyAssignment Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/osconfig.osPolicyAssignmentEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/osconfig#osconfig.osPolicyAssignmentReportViewer">OSPolicyAssignmentReport Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/osconfig.osPolicyAssignmentReportViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/osconfig#osconfig.osPolicyAssignmentViewer">OSPolicyAssignment Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/osconfig.osPolicyAssignmentViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/osconfig#osconfig.patchDeploymentAdmin">PatchDeployment Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/osconfig.patchDeploymentAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/osconfig#osconfig.patchDeploymentViewer">PatchDeployment Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/osconfig.patchDeploymentViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/osconfig#osconfig.patchJobExecutor">Patch Job Executor</a> (<code class="role-name" translate="no" dir="ltr">roles/osconfig.patchJobExecutor</code>)</p>
<p><a href="/iam/docs/roles-permissions/osconfig#osconfig.patchJobViewer">Patch Job Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/osconfig.patchJobViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/osconfig#osconfig.projectFeatureSettingsEditor">Project Feature Settings Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/osconfig.projectFeatureSettingsEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/osconfig#osconfig.projectFeatureSettingsViewer">Project Feature Settings Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/osconfig.projectFeatureSettingsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/osconfig#osconfig.upgradeReportViewer">Upgrade Report Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/osconfig.upgradeReportViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/osconfig#osconfig.vulnerabilityReportViewer">OS VulnerabilityReport Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/osconfig.vulnerabilityReportViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/parametermanager#parametermanager.parameterAccessor">Parameter Manager Parameter Accessor</a> (<code class="role-name" translate="no" dir="ltr">roles/parametermanager.parameterAccessor</code>)</p>
<p><a href="/iam/docs/roles-permissions/parametermanager#parametermanager.parameterVersionAdder">Parameter Manager Parameter Version Adder</a> (<code class="role-name" translate="no" dir="ltr">roles/parametermanager.parameterVersionAdder</code>)</p>
<p><a href="/iam/docs/roles-permissions/parametermanager#parametermanager.parameterVersionManager">Parameter Manager Parameter Version Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/parametermanager.parameterVersionManager</code>)</p>
<p><a href="/iam/docs/roles-permissions/parametermanager#parametermanager.parameterViewer">Parameter Manager Parameter Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/parametermanager.parameterViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/parametermanager#parametermanager.templateVersionManager">Parameter Manager Template Version Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/parametermanager.templateVersionManager</code>)</p>
<p><a href="/iam/docs/roles-permissions/parametermanager#parametermanager.templateViewer">Parameter Manager Template Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/parametermanager.templateViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/paymentsresellersubscription#paymentsresellersubscription.partnerAdmin">Payments Reseller Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/paymentsresellersubscription.partnerAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/paymentsresellersubscription#paymentsresellersubscription.partnerViewer">Payments Reseller Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/paymentsresellersubscription.partnerViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/paymentsresellersubscription#paymentsresellersubscription.productViewer">Payments Reseller Products Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/paymentsresellersubscription.productViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/paymentsresellersubscription#paymentsresellersubscription.promotionViewer">Payments Reseller Promotions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/paymentsresellersubscription.promotionViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/paymentsresellersubscription#paymentsresellersubscription.subscriptionEditor">Payments Reseller Subscriptions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/paymentsresellersubscription.subscriptionEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/paymentsresellersubscription#paymentsresellersubscription.subscriptionViewer">Payments Reseller Subscriptions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/paymentsresellersubscription.subscriptionViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/privateca#privateca.auditor">CA Service Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/privateca.auditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/privateca#privateca.caManager">CA Service Operation Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/privateca.caManager</code>)</p>
<p><a href="/iam/docs/roles-permissions/privateca#privateca.certificateManager">CA Service Certificate Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/privateca.certificateManager</code>)</p>
<p><a href="/iam/docs/roles-permissions/proximitybeacon#proximitybeacon.attachmentEditor">Beacon Attachment Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/proximitybeacon.attachmentEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/proximitybeacon#proximitybeacon.attachmentPublisher">Beacon Attachment Publisher</a> (<code class="role-name" translate="no" dir="ltr">roles/proximitybeacon.attachmentPublisher</code>)</p>
<p><a href="/iam/docs/roles-permissions/proximitybeacon#proximitybeacon.attachmentViewer">Beacon Attachment Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/proximitybeacon.attachmentViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/proximitybeacon#proximitybeacon.beaconEditor">Beacon Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/proximitybeacon.beaconEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/publicca#publicca.externalAccountKeyCreator">External Account Key Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/publicca.externalAccountKeyCreator</code>)</p>
<p><a href="/iam/docs/roles-permissions/recaptchaenterprise#recaptchaenterprise.agent">reCAPTCHA Enterprise Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/recaptchaenterprise.agent</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.alloydbAdmin">AlloyDB Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.alloydbAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.alloydbViewer">AlloyDB Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.alloydbViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.appengineversioncostAdmin">App Engine Version Cost Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.appengineversioncostAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.appengineversioncostViewer">App Engine Version Cost Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.appengineversioncostViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.bigQueryCapacityCommitmentsAdmin">BigQuery Slot Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.bigQueryCapacityCommitmentsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.bigQueryCapacityCommitmentsProjectAdmin">BigQuery Recommender Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.bigQueryCapacityCommitmentsProjectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.bigQueryCapacityCommitmentsProjectViewer">BigQuery Recommender Project Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.bigQueryCapacityCommitmentsProjectViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.bigQueryCapacityCommitmentsViewer">BigQuery Slot Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.bigQueryCapacityCommitmentsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.bigqueryMaterializedViewAdmin">BigQuery Materialized View Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.bigqueryMaterializedViewAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.bigqueryMaterializedViewViewer">BigQuery Materialized View Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.bigqueryMaterializedViewViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.bigqueryPartitionClusterAdmin">BigQuery Partitioning Clustering Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.bigqueryPartitionClusterAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.bigqueryPartitionClusterViewer">BigQuery Partitioning Clustering Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.bigqueryPartitionClusterViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.bigtableClusterPerformanceAdmin">Bigtable Cluster Performance Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.bigtableClusterPerformanceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.bigtableClusterPerformanceViewer">Bigtable Cluster Performance Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.bigtableClusterPerformanceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.cloudAssetInsightsAdmin">Cloud Asset Insights Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.cloudAssetInsightsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.cloudAssetInsightsViewer">Cloud Asset Insights Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.cloudAssetInsightsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.cloudCostRecommendationAdmin">Cloud Cost General Recommendations Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.cloudCostRecommendationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.cloudCostRecommendationViewer">Cloud Cost General Recommendations Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.cloudCostRecommendationViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.cloudDeprecationRecommendationAdmin">Cloud Deprecation General Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.cloudDeprecationRecommendationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.cloudDeprecationRecommendationViewer">Cloud Deprecation General Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.cloudDeprecationRecommendationViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.cloudManageabilityRecommendationAdmin">Cloud Manageability General Recommendations Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.cloudManageabilityRecommendationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.cloudManageabilityRecommendationViewer">Cloud Manageability General Recommendations Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.cloudManageabilityRecommendationViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.cloudPerformanceRecommendationAdmin">Cloud Performance General Recommendations Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.cloudPerformanceRecommendationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.cloudPerformanceRecommendationViewer">Cloud Performance General Recommendations Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.cloudPerformanceRecommendationViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.cloudReliabilityRecommendationAdmin">Cloud Reliability General Recommendations Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.cloudReliabilityRecommendationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.cloudReliabilityRecommendationViewer">Cloud Reliability General Recommendations Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.cloudReliabilityRecommendationViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.cloudSecurityRecommendationAdmin">Cloud Security General Recommendations Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.cloudSecurityRecommendationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.cloudSecurityRecommendationViewer">Cloud Security General Recommendations Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.cloudSecurityRecommendationViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.cloudsqlAdmin">Cloud SQL Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.cloudsqlAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.cloudsqlViewer">Cloud SQL Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.cloudsqlViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.computeAdmin">Compute Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.computeAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.computeViewer">Compute Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.computeViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.containerDiagnosisAdmin">GKE Diagnosis Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.containerDiagnosisAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.containerDiagnosisViewer">GKE Diagnosis Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.containerDiagnosisViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.dataflowDiagnosticsAdmin">Dataflow Diagnostics Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.dataflowDiagnosticsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.dataflowDiagnosticsViewer">Dataflow Diagnostics Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.dataflowDiagnosticsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.errorReportingAdmin">Error Reporting Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.errorReportingAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.errorReportingViewer">Error Reporting Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.errorReportingViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.firestoredatabasefirebaserulesAdmin">Firestore Database Firebase rules Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.firestoredatabasefirebaserulesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.firestoredatabasefirebaserulesViewer">Firestore Database Firebase rules Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.firestoredatabasefirebaserulesViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.firestoredatabasereliabilityAdmin">Firestore Database Reliability Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.firestoredatabasereliabilityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.firestoredatabasereliabilityViewer">Firestore Database Reliability Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.firestoredatabasereliabilityViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.firewallAdmin">Firewall Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.firewallAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.firewallViewer">Firewall Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.firewallViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.gmpAdmin">Google Maps Platform Insights/Recommendations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.gmpAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.gmpViewer">Google Maps Platform Insights/Recommendations Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.gmpViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.iamAdmin">IAM Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.iamAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.iamViewer">IAM Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.iamViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.iampolicychangeriskAdmin">IAM Policy Change Risk Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.iampolicychangeriskAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.iampolicychangeriskViewer">IAM Policy Change Risk Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.iampolicychangeriskViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.memorystoremanageabilityAdmin">Memorystore Manageability Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.memorystoremanageabilityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.memorystoremanageabilityViewer">Memorystore Manageability Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.memorystoremanageabilityViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.memorystoreperformanceAdmin">Memorystore Performance Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.memorystoreperformanceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.memorystoreperformanceViewer">Memorystore Performance Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.memorystoreperformanceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.memorystorereliabilityAdmin">Memorystore Reliability Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.memorystorereliabilityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.memorystorereliabilityViewer">Memorystore Reliability Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.memorystorereliabilityViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.networkAnalyzerAdmin">Network Analyzer Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.networkAnalyzerAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.networkAnalyzerCloudSqlAdmin">Network Analyzer Cloud SQL Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.networkAnalyzerCloudSqlAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.networkAnalyzerCloudSqlViewer">Network Analyzer Cloud SQL Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.networkAnalyzerCloudSqlViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.networkAnalyzerDynamicRouteAdmin">Network Analyzer Dynamic Route Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.networkAnalyzerDynamicRouteAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.networkAnalyzerDynamicRouteViewer">Network Analyzer Dynamic Route Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.networkAnalyzerDynamicRouteViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.networkAnalyzerGkeConnectivityAdmin">Network Analyzer GKE Connectivity Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.networkAnalyzerGkeConnectivityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.networkAnalyzerGkeConnectivityViewer">Network Analyzer GKE Connectivity Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.networkAnalyzerGkeConnectivityViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.networkAnalyzerGkeIpAddressAdmin">Network Analyzer GKE IP Address Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.networkAnalyzerGkeIpAddressAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.networkAnalyzerGkeIpAddressViewer">Network Analyzer GKE IP Address Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.networkAnalyzerGkeIpAddressViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.networkAnalyzerGkeServiceAccountAdmin">Network Analyzer GKE Service Account Insights Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.networkAnalyzerGkeServiceAccountAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.networkAnalyzerGkeServiceAccountViewer">Network Analyzer GKE Service Account Insights Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.networkAnalyzerGkeServiceAccountViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.networkAnalyzerIpAddressAdmin">Network Analyzer IP Address Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.networkAnalyzerIpAddressAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.networkAnalyzerIpAddressViewer">Network Analyzer IP Address Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.networkAnalyzerIpAddressViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.networkAnalyzerLoadBalancerAdmin">Network Analyzer Load Balancer Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.networkAnalyzerLoadBalancerAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.networkAnalyzerLoadBalancerViewer">Network Analyzer Load Balancer Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.networkAnalyzerLoadBalancerViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.networkAnalyzerViewer">Network Analyzer Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.networkAnalyzerViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.networkAnalyzerVpcConnectivityAdmin">Network Analyzer VPC Connectivity Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.networkAnalyzerVpcConnectivityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.networkAnalyzerVpcConnectivityViewer">Network Analyzer VPC Connectivity Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.networkAnalyzerVpcConnectivityViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.orgPolicyAdmin">Org Policy Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.orgPolicyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.orgPolicyViewer">Org Policy Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.orgPolicyViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.productSuggestionAdmin">Product Suggestion Recommenders Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.productSuggestionAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.productSuggestionViewer">Product Suggestion Recommenders Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.productSuggestionViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.projectCudAdmin">Project Usage Commitment Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.projectCudAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.projectCudViewer">Project Usage Commitment Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.projectCudViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.projectUtilAdmin">Project Utilization Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.projectUtilAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.projectUtilViewer">Project Utilization Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.projectUtilViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.recentChangeConfigAdmin">RecentChange RecommenderConfig Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.recentChangeConfigAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.recentchangeriskAdmin">Recent Change Risk Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.recentchangeriskAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.recentchangeriskViewer">Recent Change Risk Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.recentchangeriskViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.serviceLimitAdmin">Service Limit Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.serviceLimitAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.serviceLimitViewer">Service Limit Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.serviceLimitViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.serviceaccntchangeriskAdmin">Service Account Change Risk Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.serviceaccntchangeriskAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.serviceaccntchangeriskViewer">Service Account Change Risk Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.serviceaccntchangeriskViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.spannerAdmin">Spanner Project Reliability Recommender Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.spannerAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/recommender#recommender.spannerViewer">Spanner Project Reliability Recommender Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/recommender.spannerViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderCreator">Folder Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderCreator</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderEditor">Folder Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderViewer">Folder Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/retail#retail.merchantApprover">Retail Merchant Approver</a> (<code class="role-name" translate="no" dir="ltr">roles/retail.merchantApprover</code>)</p>
<p><a href="/iam/docs/roles-permissions/retail#retail.merchantCreator">Retail Merchant Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/retail.merchantCreator</code>)</p>
<p><a href="/iam/docs/roles-permissions/riskmanager#riskmanager.reviewer">Risk Manager Report Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/riskmanager.reviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/rapidmigrationassessment#rma.runner">Rapid Migration Assessment Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/rma.runner</code>)</p>
<p><a href="/iam/docs/roles-permissions/roads#roads.roadsSelectionAdmin">Roads Selection Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/roads.roadsSelectionAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/roads#roads.roadsSelectionViewer">Roads Selection Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/roads.roadsSelectionViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/runapps#runapps.developer">Serverless Integrations Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/runapps.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/runapps#runapps.operator">Serverless Integrations Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/runapps.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.secretVersionAdder">Secret Manager Secret Version Adder</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.secretVersionAdder</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.secretVersionManager">Secret Manager Secret Version Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.secretVersionManager</code>)</p>
<p><a href="/iam/docs/roles-permissions/securedlandingzone#securedlandingzone.overwatchActivator">Overwatch Activator</a> (<code class="role-name" translate="no" dir="ltr">roles/securedlandingzone.overwatchActivator</code>)</p>
<p><a href="/iam/docs/roles-permissions/securedlandingzone#securedlandingzone.overwatchAdmin">Overwatch Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securedlandingzone.overwatchAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/securedlandingzone#securedlandingzone.overwatchViewer">Overwatch Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securedlandingzone.overwatchViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securesourcemanager#securesourcemanager.developerConnectLinker">Secure Source Manager Developer Connect Linker</a> (<code class="role-name" translate="no" dir="ltr">roles/securesourcemanager.developerConnectLinker</code>)</p>
<p><a href="/iam/docs/roles-permissions/securesourcemanager#securesourcemanager.instanceAccessor">Secure Source Manager Instance Accessor</a> (<code class="role-name" translate="no" dir="ltr">roles/securesourcemanager.instanceAccessor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securesourcemanager#securesourcemanager.instanceManager">Secure Source Manager Instance Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/securesourcemanager.instanceManager</code>)</p>
<p><a href="/iam/docs/roles-permissions/securesourcemanager#securesourcemanager.instanceOwner">Secure Source Manager Instance Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/securesourcemanager.instanceOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/securesourcemanager#securesourcemanager.instanceRepositoryCreator">Secure Source Manager Instance Repository Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/securesourcemanager.instanceRepositoryCreator</code>)</p>
<p><a href="/iam/docs/roles-permissions/securesourcemanager#securesourcemanager.repoAdmin">Secure Source Manager Repository Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securesourcemanager.repoAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/securesourcemanager#securesourcemanager.repoCreator">Secure Source Manager Repository Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/securesourcemanager.repoCreator</code>)</p>
<p><a href="/iam/docs/roles-permissions/securesourcemanager#securesourcemanager.repoPullRequestApprover">Secure Source Manager Repository Pull Request Approver</a> (<code class="role-name" translate="no" dir="ltr">roles/securesourcemanager.repoPullRequestApprover</code>)</p>
<p><a href="/iam/docs/roles-permissions/securesourcemanager#securesourcemanager.repoReader">Secure Source Manager Repository Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/securesourcemanager.repoReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/securesourcemanager#securesourcemanager.repoWriter">Secure Source Manager Repository Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/securesourcemanager.repoWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/securesourcemanager#securesourcemanager.sshKeyUser">Secure Source Manager SSH Key User</a> (<code class="role-name" translate="no" dir="ltr">roles/securesourcemanager.sshKeyUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminEditor">Security Center Admin Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminViewer">Security Center Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.bigQueryExportsEditor">Security Center BigQuery Exports Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.bigQueryExportsEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.bigQueryExportsViewer">Security Center BigQuery Exports Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.bigQueryExportsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.settingsAdmin">Security Center Settings Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.settingsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.settingsEditor">Security Center Settings Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.settingsEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.settingsViewer">Security Center Settings Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.settingsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycentermanagement#securitycentermanagement.customModulesEditor">Security Center Management Custom Modules Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycentermanagement.customModulesEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycentermanagement#securitycentermanagement.customModulesViewer">Security Center Management Custom Modules Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycentermanagement.customModulesViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycentermanagement#securitycentermanagement.etdCustomModulesEditor">Security Center Management Custom ETD Modules Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycentermanagement.etdCustomModulesEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycentermanagement#securitycentermanagement.etdCustomModulesViewer">Security Center Management ETD Custom Modules Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycentermanagement.etdCustomModulesViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycentermanagement#securitycentermanagement.settingsEditor">Security Center Management Settings Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycentermanagement.settingsEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycentermanagement#securitycentermanagement.settingsViewer">Security Center Management Settings Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycentermanagement.settingsViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycentermanagement#securitycentermanagement.shaCustomModulesEditor">Security Center Management SHA Custom Modules Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycentermanagement.shaCustomModulesEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycentermanagement#securitycentermanagement.shaCustomModulesViewer">Security Center Management SHA Custom Modules Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycentermanagement.shaCustomModulesViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicedirectory#servicedirectory.networkAttacher">Service Directory Network Attacher</a> (<code class="role-name" translate="no" dir="ltr">roles/servicedirectory.networkAttacher</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicedirectory#servicedirectory.pscAuthorizedService">Private Service Connect Authorized Service</a> (<code class="role-name" translate="no" dir="ltr">roles/servicedirectory.pscAuthorizedService</code>)</p>
<p><a href="/iam/docs/roles-permissions/servicemanagement#servicemanagement.quotaAdmin">Quota Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/servicemanagement.quotaAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/spanner#spanner.backupAdmin">Cloud Spanner Backup Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/spanner.backupAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/spanner#spanner.databaseAdmin">Cloud Spanner Database Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/spanner.databaseAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/spanner#spanner.restoreAdmin">Cloud Spanner Restore Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/spanner.restoreAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#stackdriver.accounts.editor">Stackdriver Accounts Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/stackdriver.accounts.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/monitoring#stackdriver.accounts.viewer">Stackdriver Accounts Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/stackdriver.accounts.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.hmacKeyAdmin">Storage HMAC Key Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.hmacKeyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.insightsCollectorService">Storage Insights Collector Service</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.insightsCollectorService</code>)</p>
<p><a href="/iam/docs/roles-permissions/storageinsights#storageinsights.analyst">Storage Insights Analyst</a> (<code class="role-name" translate="no" dir="ltr">roles/storageinsights.analyst</code>)</p>
<p><a href="/iam/docs/roles-permissions/storagetransfer#storagetransfer.user">Storage Transfer User</a> (<code class="role-name" translate="no" dir="ltr">roles/storagetransfer.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/stream#stream.contentAdmin">Stream Content Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/stream.contentAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/stream#stream.contentBuilder">Stream Content Builder</a> (<code class="role-name" translate="no" dir="ltr">roles/stream.contentBuilder</code>)</p>
<p><a href="/iam/docs/roles-permissions/stream#stream.instanceAdmin">Stream Instance Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/stream.instanceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/subscribewithgoogledeveloper#subscribewithgoogledeveloper.developer">Subscribe with Google Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/subscribewithgoogledeveloper.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/threatintelligence#threatintelligence.alertAdmin">GTI Alert Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/threatintelligence.alertAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/threatintelligence#threatintelligence.alertUser">GTI Alert User</a> (<code class="role-name" translate="no" dir="ltr">roles/threatintelligence.alertUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/threatintelligence#threatintelligence.ctemAdmin">CTEM Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/threatintelligence.ctemAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/threatintelligence#threatintelligence.ctemEditor">CTEM Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/threatintelligence.ctemEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/threatintelligence#threatintelligence.ctemProjectAdmin">CTEM Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/threatintelligence.ctemProjectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/threatintelligence#threatintelligence.ctemViewer">CTEM Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/threatintelligence.ctemViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/translationhub#translationhub.portalUser">Translation Hub Portal User</a> (<code class="role-name" translate="no" dir="ltr">roles/translationhub.portalUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/vectorsearch#vectorsearch.collectionWriter">Vector Search Collection Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/vectorsearch.collectionWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/vectorsearch#vectorsearch.dataObjectWriter">Vector Search DataObject Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/vectorsearch.dataObjectWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/vectorsearch#vectorsearch.indexWriter">Vector Search Index Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/vectorsearch.indexWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/videostitcher#videostitcher.user">Video Stitcher User</a> (<code class="role-name" translate="no" dir="ltr">roles/videostitcher.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.vmwareengineAdmin">VMware Engine Service Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.vmwareengineAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.vmwareenginePrivilegedUser">VMware Engine Service Privileged User</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.vmwareenginePrivilegedUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.vmwareengineViewer">VMware Engine Service Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.vmwareengineViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/workflows#workflows.invoker">Workflows Invoker</a> (<code class="role-name" translate="no" dir="ltr">roles/workflows.invoker</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadcertificate#workloadcertificate.registrationAdmin">Workload Certificate Registration Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadcertificate.registrationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadcertificate#workloadcertificate.registrationViewer">Workload Certificate Registration Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadcertificate.registrationViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.deploymentAdmin">Workload Manager Deployment Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.deploymentAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.deploymentViewer">Workload Manager Deployment Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.deploymentViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.evaluationAdmin">Workload Manager Evaluation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.evaluationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.evaluationViewer">Workload Manager Evaluation Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.evaluationViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.worker">Workload Manager Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.workloadViewer">Workload Manager Workload Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.workloadViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/workstations#workstations.workstationCreator">Cloud Workstations Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/workstations.workstationCreator</code>)</p>
<p><a href="/iam/docs/roles-permissions/workstations#workstations.workstationLimitExemptedCreator">Cloud Workstations Limit Exempted Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/workstations.workstationLimitExemptedCreator</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.customCodeServiceAgent">Vertex AI Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.customCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.extensionCustomCodeServiceAgent">Vertex AI Extension Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.extensionCustomCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.reasoningEngineServiceAgent">Vertex AI Reasoning Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.reasoningEngineServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/analyticshub#analyticshub.serviceAgent">Analytics Hub Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/analyticshub.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/anthossupport#anthossupport.serviceAgent">Anthos Support Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/anthossupport.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.serviceAgent">Audit Manager Auditing Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.serviceAgent">Recommendations AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/backupdr#backupdr.serviceAgent">Backup and DR Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/backupdr.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/batch#batch.serviceAgent">Google Batch Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/batch.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/bigquerydatatransfer#bigquerydatatransfer.serviceAgent">BigQuery Data Transfer Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatatransfer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/binaryauthorization#binaryauthorization.serviceAgent">Binary Authorization Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/binaryauthorization.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.serviceAgent">Cloud Security Compliance Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/tpu#cloudtpu.serviceAgent">Cloud TPU V2 API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtpu.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/compliancescanning#compliancescanning.serviceAgent">Compliance Scanning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/compliancescanning.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/compute#compute.serviceAgent">Compute Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.nodeServiceAgent">[Deprecated] Kubernetes Engine Node Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.nodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.ServiceAgent">Container Analysis Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containerscanning#containerscanning.ServiceAgent">Container Scanner Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containerscanning.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containerthreatdetection#containerthreatdetection.serviceAgent">Container Threat Detection Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containerthreatdetection.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataform#dataform.serviceAgent">Dataform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datalabeling#datalabeling.serviceAgent">Data Labeling Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datalabeling.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dialogflow#dialogflow.serviceAgent">Dialogflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dialogflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.serviceAgent">Discovery Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.clusterServiceAgent">Edge Container Cluster Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.clusterServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/enterpriseknowledgegraph#enterpriseknowledgegraph.serviceAgent">Enterprise Knowledge Graph Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/enterpriseknowledgegraph.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/file#file.serviceAgent">Cloud Filestore Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/file.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.sdkAdminServiceAgent">Firebase Admin SDK Administrator Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.sdkAdminServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasemods#firebasemods.serviceAgent">Firebase Extensions API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasemods.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/fleetengine#fleetengine.serviceAgent">FleetEngine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/fleetengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gameservices#gameservices.serviceAgent">Game Services Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gameservices.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/lifesciences#genomics.serviceAgent">Genomics Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/genomics.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkebackup#gkebackup.serviceAgent">Backup for GKE Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkebackup.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkedataplanemanagement#gkedataplanemanagement.warpRunServiceAgent">Warp Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkedataplanemanagement.warpRunServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkehub#gkehub.serviceAgent">GKE Hub Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkemulticloud#gkemulticloud.containerServiceAgent">Anthos Multi-Cloud Container Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkemulticloud.containerServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkemulticloud#gkemulticloud.serviceAgent">Anthos Multi-Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkemulticloud.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/healthcare#healthcare.serviceAgent">Healthcare Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/healthcare.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.sharedVpcServiceAgent">Cluster Director Shared VPC Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.sharedVpcServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/integrations#integrations.serviceAgent">Application Integration Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/krmapihosting#krmapihosting.anthosApiEndpointServiceAgent">KRM API Hosting AnthosApiEndpoint Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/krmapihosting.anthosApiEndpointServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/krmapihosting#krmapihosting.serviceAgent">KRM API Hosting Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/krmapihosting.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/lifesciences#lifesciences.serviceAgent">Cloud Life Sciences Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/lifesciences.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/managedidentities#managedidentities.serviceAgent">Cloud Managed Identities Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/managedidentities.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/memcache#memcache.serviceAgent">Cloud Memorystore Memcached Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/memcache.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/memorystore#memorystore.serviceAgent">Cloud Memorystore Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/memorystore.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/meshcontrolplane#meshcontrolplane.serviceAgent">Mesh Managed Control Plane Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/meshcontrolplane.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/multiclusterservicediscovery#multiclusterservicediscovery.serviceAgent">Multi-Cluster Service Discovery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/multiclusterservicediscovery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/notebooks#notebooks.serviceAgent">AI Platform Notebooks Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/osconfig#osconfig.serviceAgent">Cloud OS Config Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/osconfig.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/parallelstore#parallelstore.serviceAgent">Parallelstore Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/parallelstore.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/pubsub#pubsub.serviceAgent">Cloud Pub/Sub Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/redis#redis.serviceAgent">Cloud Memorystore Redis Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/retail#retail.serviceAgent">Retail Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/retail.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/riskmanager#riskmanager.serviceAgent">Risk Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/riskmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.automationServiceAgent">Security Center Automation Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.automationServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.controlServiceAgent">Security Center Control Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.controlServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.securityHealthAnalyticsServiceAgent">Security Health Analytics Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.securityHealthAnalyticsServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.serviceAgent">Security Center Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/servicedirectory#servicedirectory.serviceAgent">Service Directory Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/servicedirectory.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/servicenetworking#servicenetworking.serviceAgent">Service Networking Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/servicenetworking.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/stream#stream.serviceAgent">Stream Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/stream.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/tpu#tpu.serviceAgent">Cloud TPU API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/tpu.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vmwareengine#vmwareengine.serviceAgent">VMware Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vmwareengine.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="resourcemanager.projects.move" class="permission-name add-link" data-text="resourcemanager.projects.move" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.projects.move</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.editor">Resource Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderAdmin">Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.projectMover">Project Mover</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.projectMover</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderMover">Folder Mover</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderMover</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="resourcemanager.projects.searchPolicyBindings" class="permission-name add-link" data-text="resourcemanager.projects.searchPolicyBindings" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.projects.searchPolicyBindings</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderAdmin">Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.organizationAdmin">Organization Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.organizationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.projectIamAdmin">Project IAM Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.projectIamAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="resourcemanager.projects.setIamPolicy" class="permission-name add-link" data-text="resourcemanager.projects.setIamPolicy" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.projects.setIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderAdmin">Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.organizationAdmin">Organization Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.organizationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.projectIamAdmin">Project IAM Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.projectIamAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/appengineflex#appengineflex.serviceAgent">App Engine flexible environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengineflex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.managementServiceAgent">Firebase Service Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.managementServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkehub#gkehub.crossProjectServiceAgent">GKE Hub Cross Project Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.crossProjectServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/krmapihosting#krmapihosting.anthosApiEndpointServiceAgent">KRM API Hosting AnthosApiEndpoint Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/krmapihosting.anthosApiEndpointServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/privilegedaccessmanager#privilegedaccessmanager.projectServiceAgent">Privileged Access Manager Project Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/privilegedaccessmanager.projectServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/privilegedaccessmanager#privilegedaccessmanager.serviceAgent">Privileged Access Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/privilegedaccessmanager.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="resourcemanager.projects.undelete" class="permission-name add-link" data-text="resourcemanager.projects.undelete" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.projects.undelete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="resourcemanager.projects.update" class="permission-name add-link" data-text="resourcemanager.projects.update" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.projects.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.editor">Resource Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.projectMover">Project Mover</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.projectMover</code>)</p>
<p><a href="/iam/docs/roles-permissions/securedlandingzone#securedlandingzone.bqdwProjectRemediator">SLZ BQDW Blueprint Project Level Remediator</a> (<code class="role-name" translate="no" dir="ltr">roles/securedlandingzone.bqdwProjectRemediator</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.managementServiceAgent">Firebase Service Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.managementServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.sdkAdminServiceAgent">Firebase Admin SDK Administrator Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.sdkAdminServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="resourcemanager.projects.updateLiens" class="permission-name add-link" data-text="resourcemanager.projects.updateLiens" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.projects.updateLiens</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/datastudio#lookerstudio.proManager">Looker Studio Pro Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/lookerstudio.proManager</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.lienModifier">Project Lien Modifier</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.lienModifier</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasemods#firebasemods.serviceAgent">Firebase Extensions API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasemods.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkebackup#gkebackup.serviceAgent">Backup for GKE Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkebackup.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/oci#oci.serviceAgent">Oracle Database@Google Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/oci.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="resourcemanager.projects.updatePolicyBinding" class="permission-name add-link" data-text="resourcemanager.projects.updatePolicyBinding" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.projects.updatePolicyBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderAdmin">Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.organizationAdmin">Organization Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.organizationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.projectIamAdmin">Project IAM Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.projectIamAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="resourcemanager.tagHolds.create" class="permission-name add-link" data-text="resourcemanager.tagHolds.create" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.tagHolds.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.editor">Resource Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagAdmin">Tag Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagHoldAdmin">Tag Hold Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagHoldAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="resourcemanager.tagHolds.delete" class="permission-name add-link" data-text="resourcemanager.tagHolds.delete" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.tagHolds.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.editor">Resource Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagAdmin">Tag Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagHoldAdmin">Tag Hold Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagHoldAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="resourcemanager.tagHolds.list" class="permission-name add-link" data-text="resourcemanager.tagHolds.list" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.tagHolds.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.editor">Resource Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagAdmin">Tag Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagViewer">Tag Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.viewer">Resource Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagHoldAdmin">Tag Hold Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagHoldAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.serviceAgent">Audit Manager Auditing Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.serviceAgent">Cloud Security Compliance Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="resourcemanager.tagKeys.create" class="permission-name add-link" data-text="resourcemanager.tagKeys.create" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.tagKeys.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.editor">Resource Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagAdmin">Tag Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dspm#dspm.serviceAgent">DSPM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="resourcemanager.tagKeys.delete" class="permission-name add-link" data-text="resourcemanager.tagKeys.delete" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.tagKeys.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.editor">Resource Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagAdmin">Tag Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dspm#dspm.serviceAgent">DSPM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="resourcemanager.tagKeys.get" class="permission-name add-link" data-text="resourcemanager.tagKeys.get" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.tagKeys.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.editor">Resource Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagAdmin">Tag Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagViewer">Tag Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.viewer">Resource Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.serviceAgent">Audit Manager Auditing Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.serviceAgent">Cloud Security Compliance Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dspm#dspm.serviceAgent">DSPM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="resourcemanager.tagKeys.getIamPolicy" class="permission-name add-link" data-text="resourcemanager.tagKeys.getIamPolicy" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.tagKeys.getIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagAdmin">Tag Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dspm#dspm.serviceAgent">DSPM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="resourcemanager.tagKeys.list" class="permission-name add-link" data-text="resourcemanager.tagKeys.list" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.tagKeys.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.editor">Resource Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagAdmin">Tag Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagViewer">Tag Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.viewer">Resource Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.serviceAgent">Audit Manager Auditing Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.serviceAgent">Cloud Security Compliance Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dspm#dspm.serviceAgent">DSPM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="resourcemanager.tagKeys.setIamPolicy" class="permission-name add-link" data-text="resourcemanager.tagKeys.setIamPolicy" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.tagKeys.setIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagAdmin">Tag Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="resourcemanager.tagKeys.update" class="permission-name add-link" data-text="resourcemanager.tagKeys.update" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.tagKeys.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.editor">Resource Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagAdmin">Tag Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dspm#dspm.serviceAgent">DSPM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="resourcemanager.tagValueBindings.create" class="permission-name add-link" data-text="resourcemanager.tagValueBindings.create" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.tagValueBindings.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/compute#compute.instanceGroupManagerServiceAgent">Instance Group Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.instanceGroupManagerServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dspm#dspm.serviceAgent">DSPM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/workstations#workstations.serviceAgent">Workstations Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/workstations.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="resourcemanager.tagValueBindings.delete" class="permission-name add-link" data-text="resourcemanager.tagValueBindings.delete" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.tagValueBindings.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/compute#compute.instanceGroupManagerServiceAgent">Instance Group Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.instanceGroupManagerServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dspm#dspm.serviceAgent">DSPM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/workstations#workstations.serviceAgent">Workstations Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/workstations.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="resourcemanager.tagValues.create" class="permission-name add-link" data-text="resourcemanager.tagValues.create" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.tagValues.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.editor">Resource Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagAdmin">Tag Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dspm#dspm.serviceAgent">DSPM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="resourcemanager.tagValues.delete" class="permission-name add-link" data-text="resourcemanager.tagValues.delete" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.tagValues.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.editor">Resource Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagAdmin">Tag Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dspm#dspm.serviceAgent">DSPM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="resourcemanager.tagValues.get" class="permission-name add-link" data-text="resourcemanager.tagValues.get" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.tagValues.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.editor">Resource Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagAdmin">Tag Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagViewer">Tag Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.viewer">Resource Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminEditor">Security Center Admin Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.adminViewer">Security Center Admin Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.adminViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.resourceValueConfigsEditor">Security Center Resource Value Configurations Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.resourceValueConfigsEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.resourceValueConfigsViewer">Security Center Resource Value Configurations Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.resourceValueConfigsViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.serviceAgent">Audit Manager Auditing Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.serviceAgent">Cloud Security Compliance Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/compute#compute.instanceGroupManagerServiceAgent">Instance Group Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.instanceGroupManagerServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dspm#dspm.serviceAgent">DSPM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.controlServiceAgent">Security Center Control Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.controlServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.serviceAgent">Security Center Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="resourcemanager.tagValues.getIamPolicy" class="permission-name add-link" data-text="resourcemanager.tagValues.getIamPolicy" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.tagValues.getIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagAdmin">Tag Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dspm#dspm.serviceAgent">DSPM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="resourcemanager.tagValues.list" class="permission-name add-link" data-text="resourcemanager.tagValues.list" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.tagValues.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.editor">Resource Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagAdmin">Tag Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagViewer">Tag Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.viewer">Resource Manager Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.serviceAgent">Audit Manager Auditing Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.serviceAgent">Cloud Security Compliance Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dspm#dspm.serviceAgent">DSPM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="resourcemanager.tagValues.setIamPolicy" class="permission-name add-link" data-text="resourcemanager.tagValues.setIamPolicy" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.tagValues.setIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagAdmin">Tag Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="resourcemanager.tagValues.update" class="permission-name add-link" data-text="resourcemanager.tagValues.update" tabindex="-1"><code translate="no" dir="ltr">resourcemanager.tagValues.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.editor">Resource Manager Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagAdmin">Tag Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dspm#dspm.serviceAgent">DSPM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.serviceAgent</code>)</li>
</ul></td>
</tr>
</tbody>
</table>

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
