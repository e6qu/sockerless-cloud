# Conversion functions

<div class="devsite-article-body clearfix">

GoogleSQL for BigQuery supports conversion functions. These data type conversions are explicit, but some conversions can happen implicitly. You can learn more about implicit and explicit conversion [here](/bigquery/docs/reference/standard-sql/conversion_rules).

## Function list

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th>Name</th>
<th>Summary</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td><a href="/bigquery/docs/reference/standard-sql/array_functions#array_to_string"><code translate="no" dir="ltr">ARRAY_TO_STRING</code></a></td>
<td>Produces a concatenation of the elements in an array as a <code translate="no" dir="ltr">STRING</code> value.<br />
For more information, see <a href="/bigquery/docs/reference/standard-sql/array_functions">Array functions</a>.</td>
</tr>
<tr class="even">
<td><a href="/bigquery/docs/reference/standard-sql/json_functions#bool_for_json"><code translate="no" dir="ltr">BOOL</code></a></td>
<td>Converts a JSON boolean to a SQL <code translate="no" dir="ltr">BOOL</code> value.<br />
For more information, see <a href="/bigquery/docs/reference/standard-sql/json_functions">JSON functions</a>.</td>
</tr>
<tr class="odd">
<td><a href="/bigquery/docs/reference/standard-sql/conversion_functions#cast"><code translate="no" dir="ltr">CAST</code></a></td>
<td>Convert the results of an expression to the given type.</td>
</tr>
<tr class="even">
<td><a href="/bigquery/docs/reference/standard-sql/string_functions#chr"><code translate="no" dir="ltr">CHR</code></a></td>
<td>Converts a Unicode code point to a character.<br />
For more information, see <a href="/bigquery/docs/reference/standard-sql/string_functions">String functions</a>.</td>
</tr>
<tr class="odd">
<td><a href="/bigquery/docs/reference/standard-sql/string_functions#code_points_to_bytes"><code translate="no" dir="ltr">CODE_POINTS_TO_BYTES</code></a></td>
<td>Converts an array of extended ASCII code points to a <code translate="no" dir="ltr">BYTES</code> value.<br />
For more information, see <a href="/bigquery/docs/reference/standard-sql/string_functions">String aggregate functions</a>.</td>
</tr>
<tr class="even">
<td><a href="/bigquery/docs/reference/standard-sql/string_functions#code_points_to_string"><code translate="no" dir="ltr">CODE_POINTS_TO_STRING</code></a></td>
<td>Converts an array of extended ASCII code points to a <code translate="no" dir="ltr">STRING</code> value.<br />
For more information, see <a href="/bigquery/docs/reference/standard-sql/string_functions">String aggregate functions</a>.</td>
</tr>
<tr class="odd">
<td><a href="/bigquery/docs/reference/standard-sql/date_functions#date_from_unix_date"><code translate="no" dir="ltr">DATE_FROM_UNIX_DATE</code></a></td>
<td>Interprets an <code translate="no" dir="ltr">INT64</code> expression as the number of days since 1970-01-01.<br />
For more information, see <a href="/bigquery/docs/reference/standard-sql/date_functions">Date functions</a>.</td>
</tr>
<tr class="even">
<td><a href="/bigquery/docs/reference/standard-sql/string_functions#from_base32"><code translate="no" dir="ltr">FROM_BASE32</code></a></td>
<td>Converts a base32-encoded <code translate="no" dir="ltr">STRING</code> value into a <code translate="no" dir="ltr">BYTES</code> value.<br />
For more information, see <a href="/bigquery/docs/reference/standard-sql/string_functions">String functions</a>.</td>
</tr>
<tr class="odd">
<td><a href="/bigquery/docs/reference/standard-sql/string_functions#from_base64"><code translate="no" dir="ltr">FROM_BASE64</code></a></td>
<td>Converts a base64-encoded <code translate="no" dir="ltr">STRING</code> value into a <code translate="no" dir="ltr">BYTES</code> value.<br />
For more information, see <a href="/bigquery/docs/reference/standard-sql/string_functions">String functions</a>.</td>
</tr>
<tr class="even">
<td><a href="/bigquery/docs/reference/standard-sql/string_functions#from_hex"><code translate="no" dir="ltr">FROM_HEX</code></a></td>
<td>Converts a hexadecimal-encoded <code translate="no" dir="ltr">STRING</code> value into a <code translate="no" dir="ltr">BYTES</code> value.<br />
For more information, see <a href="/bigquery/docs/reference/standard-sql/string_functions">String functions</a>.</td>
</tr>
<tr class="odd">
<td><a href="/bigquery/docs/reference/standard-sql/json_functions#int64_for_json"><code translate="no" dir="ltr">INT64</code></a></td>
<td>Converts a JSON number to a SQL <code translate="no" dir="ltr">INT64</code> value.<br />
For more information, see <a href="/bigquery/docs/reference/standard-sql/json_functions">JSON functions</a>.</td>
</tr>
<tr class="even">
<td><a href="/bigquery/docs/reference/standard-sql/json_functions#lax_bool"><code translate="no" dir="ltr">LAX_BOOL</code></a></td>
<td>Attempts to convert a JSON value to a SQL <code translate="no" dir="ltr">BOOL</code> value.<br />
For more information, see <a href="/bigquery/docs/reference/standard-sql/json_functions">JSON functions</a>.</td>
</tr>
<tr class="odd">
<td><a href="/bigquery/docs/reference/standard-sql/json_functions#lax_double"><code translate="no" dir="ltr">LAX_FLOAT64</code></a></td>
<td>Attempts to convert a JSON value to a SQL <code translate="no" dir="ltr">FLOAT64</code> value.<br />
For more information, see <a href="/bigquery/docs/reference/standard-sql/json_functions">JSON functions</a>.</td>
</tr>
<tr class="even">
<td><a href="/bigquery/docs/reference/standard-sql/json_functions#lax_int64"><code translate="no" dir="ltr">LAX_INT64</code></a></td>
<td>Attempts to convert a JSON value to a SQL <code translate="no" dir="ltr">INT64</code> value.<br />
For more information, see <a href="/bigquery/docs/reference/standard-sql/json_functions">JSON functions</a>.</td>
</tr>
<tr class="odd">
<td><a href="/bigquery/docs/reference/standard-sql/json_functions#lax_string"><code translate="no" dir="ltr">LAX_STRING</code></a></td>
<td>Attempts to convert a JSON value to a SQL <code translate="no" dir="ltr">STRING</code> value.<br />
For more information, see <a href="/bigquery/docs/reference/standard-sql/json_functions">JSON functions</a>.</td>
</tr>
<tr class="even">
<td><a href="/bigquery/docs/reference/standard-sql/conversion_functions#parse_bignumeric"><code translate="no" dir="ltr">PARSE_BIGNUMERIC</code></a></td>
<td>Converts a <code translate="no" dir="ltr">STRING</code> value to a <code translate="no" dir="ltr">BIGNUMERIC</code> value.</td>
</tr>
<tr class="odd">
<td><a href="/bigquery/docs/reference/standard-sql/date_functions#parse_date"><code translate="no" dir="ltr">PARSE_DATE</code></a></td>
<td>Converts a <code translate="no" dir="ltr">STRING</code> value to a <code translate="no" dir="ltr">DATE</code> value.<br />
For more information, see <a href="/bigquery/docs/reference/standard-sql/date_functions">Date functions</a>.</td>
</tr>
<tr class="even">
<td><a href="/bigquery/docs/reference/standard-sql/datetime_functions#parse_datetime"><code translate="no" dir="ltr">PARSE_DATETIME</code></a></td>
<td>Converts a <code translate="no" dir="ltr">STRING</code> value to a <code translate="no" dir="ltr">DATETIME</code> value.<br />
For more information, see <a href="/bigquery/docs/reference/standard-sql/datetime_functions">Datetime functions</a>.</td>
</tr>
<tr class="odd">
<td><a href="/bigquery/docs/reference/standard-sql/json_functions#parse_json"><code translate="no" dir="ltr">PARSE_JSON</code></a></td>
<td>Converts a JSON-formatted <code translate="no" dir="ltr">STRING</code> value to a <code translate="no" dir="ltr">JSON</code> value.<br />
For more information, see <a href="/bigquery/docs/reference/standard-sql/json_functions">JSON functions</a>.</td>
</tr>
<tr class="even">
<td><a href="/bigquery/docs/reference/standard-sql/conversion_functions#parse_numeric"><code translate="no" dir="ltr">PARSE_NUMERIC</code></a></td>
<td>Converts a <code translate="no" dir="ltr">STRING</code> value to a <code translate="no" dir="ltr">NUMERIC</code> value.</td>
</tr>
<tr class="odd">
<td><a href="/bigquery/docs/reference/standard-sql/time_functions#parse_time"><code translate="no" dir="ltr">PARSE_TIME</code></a></td>
<td>Converts a <code translate="no" dir="ltr">STRING</code> value to a <code translate="no" dir="ltr">TIME</code> value.<br />
For more information, see <a href="/bigquery/docs/reference/standard-sql/time_functions">Time functions</a>.</td>
</tr>
<tr class="even">
<td><a href="/bigquery/docs/reference/standard-sql/timestamp_functions#parse_timestamp"><code translate="no" dir="ltr">PARSE_TIMESTAMP</code></a></td>
<td>Converts a <code translate="no" dir="ltr">STRING</code> value to a <code translate="no" dir="ltr">TIMESTAMP</code> value.<br />
For more information, see <a href="/bigquery/docs/reference/standard-sql/timestamp_functions">Timestamp functions</a>.</td>
</tr>
<tr class="odd">
<td><a href="/bigquery/docs/reference/standard-sql/conversion_functions#safe_casting"><code translate="no" dir="ltr">SAFE_CAST</code></a></td>
<td>Similar to the <code translate="no" dir="ltr">CAST</code> function, but returns <code translate="no" dir="ltr">NULL</code> when a runtime error is produced.</td>
</tr>
<tr class="even">
<td><a href="/bigquery/docs/reference/standard-sql/string_functions#safe_convert_bytes_to_string"><code translate="no" dir="ltr">SAFE_CONVERT_BYTES_TO_STRING</code></a></td>
<td>Converts a <code translate="no" dir="ltr">BYTES</code> value to a <code translate="no" dir="ltr">STRING</code> value and replace any invalid UTF-8 characters with the Unicode replacement character, <code translate="no" dir="ltr">U+FFFD</code>.<br />
For more information, see <a href="/bigquery/docs/reference/standard-sql/string_functions">String functions</a>.</td>
</tr>
<tr class="odd">
<td><a href="/bigquery/docs/reference/standard-sql/json_functions#string_for_json"><code translate="no" dir="ltr">STRING</code> (JSON)</a></td>
<td>Converts a JSON string to a SQL <code translate="no" dir="ltr">STRING</code> value.<br />
For more information, see <a href="/bigquery/docs/reference/standard-sql/json_functions">JSON functions</a>.</td>
</tr>
<tr class="even">
<td><a href="/bigquery/docs/reference/standard-sql/timestamp_functions#string"><code translate="no" dir="ltr">STRING</code> (Timestamp)</a></td>
<td>Converts a <code translate="no" dir="ltr">TIMESTAMP</code> value to a <code translate="no" dir="ltr">STRING</code> value.<br />
For more information, see <a href="/bigquery/docs/reference/standard-sql/timestamp_functions">Timestamp functions</a>.</td>
</tr>
<tr class="odd">
<td><a href="/bigquery/docs/reference/standard-sql/timestamp_functions#timestamp_micros"><code translate="no" dir="ltr">TIMESTAMP_MICROS</code></a></td>
<td>Converts the number of microseconds since 1970-01-01 00:00:00 UTC to a <code translate="no" dir="ltr">TIMESTAMP</code>.<br />
For more information, see <a href="/bigquery/docs/reference/standard-sql/timestamp_functions">Timestamp functions</a>.</td>
</tr>
<tr class="even">
<td><a href="/bigquery/docs/reference/standard-sql/timestamp_functions#timestamp_millis"><code translate="no" dir="ltr">TIMESTAMP_MILLIS</code></a></td>
<td>Converts the number of milliseconds since 1970-01-01 00:00:00 UTC to a <code translate="no" dir="ltr">TIMESTAMP</code>.<br />
For more information, see <a href="/bigquery/docs/reference/standard-sql/timestamp_functions">Timestamp functions</a>.</td>
</tr>
<tr class="odd">
<td><a href="/bigquery/docs/reference/standard-sql/timestamp_functions#timestamp_seconds"><code translate="no" dir="ltr">TIMESTAMP_SECONDS</code></a></td>
<td>Converts the number of seconds since 1970-01-01 00:00:00 UTC to a <code translate="no" dir="ltr">TIMESTAMP</code>.<br />
For more information, see <a href="/bigquery/docs/reference/standard-sql/timestamp_functions">Timestamp functions</a>.</td>
</tr>
<tr class="even">
<td><a href="/bigquery/docs/reference/standard-sql/string_functions#to_base32"><code translate="no" dir="ltr">TO_BASE32</code></a></td>
<td>Converts a <code translate="no" dir="ltr">BYTES</code> value to a base32-encoded <code translate="no" dir="ltr">STRING</code> value.<br />
For more information, see <a href="/bigquery/docs/reference/standard-sql/string_functions">String functions</a>.</td>
</tr>
<tr class="odd">
<td><a href="/bigquery/docs/reference/standard-sql/string_functions#to_base64"><code translate="no" dir="ltr">TO_BASE64</code></a></td>
<td>Converts a <code translate="no" dir="ltr">BYTES</code> value to a base64-encoded <code translate="no" dir="ltr">STRING</code> value.<br />
For more information, see <a href="/bigquery/docs/reference/standard-sql/string_functions">String functions</a>.</td>
</tr>
<tr class="even">
<td><a href="/bigquery/docs/reference/standard-sql/string_functions#to_code_points"><code translate="no" dir="ltr">TO_CODE_POINTS</code></a></td>
<td>Converts a <code translate="no" dir="ltr">STRING</code> or <code translate="no" dir="ltr">BYTES</code> value into an array of extended ASCII code points.<br />
For more information, see <a href="/bigquery/docs/reference/standard-sql/string_functions">String functions</a>.</td>
</tr>
<tr class="odd">
<td><a href="/bigquery/docs/reference/standard-sql/string_functions#to_hex"><code translate="no" dir="ltr">TO_HEX</code></a></td>
<td>Converts a <code translate="no" dir="ltr">BYTES</code> value to a hexadecimal <code translate="no" dir="ltr">STRING</code> value.<br />
For more information, see <a href="/bigquery/docs/reference/standard-sql/string_functions">String functions</a>.</td>
</tr>
<tr class="even">
<td><a href="/bigquery/docs/reference/standard-sql/json_functions#to_json"><code translate="no" dir="ltr">TO_JSON</code></a></td>
<td>Converts a SQL value to a JSON value.<br />
For more information, see <a href="/bigquery/docs/reference/standard-sql/json_functions">JSON functions</a>.</td>
</tr>
<tr class="odd">
<td><a href="/bigquery/docs/reference/standard-sql/json_functions#to_json_string"><code translate="no" dir="ltr">TO_JSON_STRING</code></a></td>
<td>Converts a SQL value to a JSON-formatted <code translate="no" dir="ltr">STRING</code> value.<br />
For more information, see <a href="/bigquery/docs/reference/standard-sql/json_functions">JSON functions</a>.</td>
</tr>
<tr class="even">
<td><a href="/bigquery/docs/reference/standard-sql/date_functions#unix_date"><code translate="no" dir="ltr">UNIX_DATE</code></a></td>
<td>Converts a <code translate="no" dir="ltr">DATE</code> value to the number of days since 1970-01-01.<br />
For more information, see <a href="/bigquery/docs/reference/standard-sql/date_functions">Date functions</a>.</td>
</tr>
<tr class="odd">
<td><a href="/bigquery/docs/reference/standard-sql/timestamp_functions#unix_micros"><code translate="no" dir="ltr">UNIX_MICROS</code></a></td>
<td>Converts a <code translate="no" dir="ltr">TIMESTAMP</code> value to the number of microseconds since 1970-01-01 00:00:00 UTC.<br />
For more information, see <a href="/bigquery/docs/reference/standard-sql/timestamp_functions">Timestamp functions</a>.</td>
</tr>
<tr class="even">
<td><a href="/bigquery/docs/reference/standard-sql/timestamp_functions#unix_millis"><code translate="no" dir="ltr">UNIX_MILLIS</code></a></td>
<td>Converts a <code translate="no" dir="ltr">TIMESTAMP</code> value to the number of milliseconds since 1970-01-01 00:00:00 UTC.<br />
For more information, see <a href="/bigquery/docs/reference/standard-sql/timestamp_functions">Timestamp functions</a>.</td>
</tr>
<tr class="odd">
<td><a href="/bigquery/docs/reference/standard-sql/timestamp_functions#unix_seconds"><code translate="no" dir="ltr">UNIX_SECONDS</code></a></td>
<td>Converts a <code translate="no" dir="ltr">TIMESTAMP</code> value to the number of seconds since 1970-01-01 00:00:00 UTC.<br />
For more information, see <a href="/bigquery/docs/reference/standard-sql/timestamp_functions">Timestamp functions</a>.</td>
</tr>
</tbody>
</table>

## `CAST`

<div>

</div>

``` devsite-click-to-copy
CAST(expression AS typename [format_clause])
```

**Description**

Cast syntax is used in a query to indicate that the result type of an expression should be converted to some other type.

When using `CAST`, a query can fail if GoogleSQL is unable to perform the cast. If you want to protect your queries from these types of errors, you can use [SAFE_CAST](#safe_casting).

Casts between supported types that don't successfully map from the original value to the target domain produce runtime errors. For example, casting `BYTES` to `STRING` where the byte sequence isn't valid UTF-8 results in a runtime error.

Some casts can include a [format clause](/bigquery/docs/reference/standard-sql/format-elements#formatting_syntax), which provides instructions for how to conduct the cast. For example, you could instruct a cast to convert a sequence of bytes to a BASE64-encoded string instead of a UTF-8-encoded string.

The structure of the format clause is unique to each type of cast and more information is available in the section for that cast.

**Examples**

The following query results in `"true"` if `x` is `1`, `"false"` for any other non-`NULL` value, and `NULL` if `x` is `NULL`.

<div>

</div>

``` devsite-click-to-copy
CAST(x=1 AS STRING)
```

### CAST AS ARRAY

<div>

</div>

``` devsite-click-to-copy
CAST(expression AS ARRAY<element_type>)
```

**Description**

GoogleSQL supports [casting](#cast) to `ARRAY`. The `expression` parameter can represent an expression for these data types:

- `ARRAY`

**Conversion rules**

| From    | To      | Rule(s) when casting `x`                                                                                                                         |
|---------|---------|--------------------------------------------------------------------------------------------------------------------------------------------------|
| `ARRAY` | `ARRAY` | Must be the exact same array type.                                                                                                               |
| `NULL`  | `ARRAY` | Casts a `NULL` value to a specific type of array. For example, `CAST(NULL AS ARRAY<FLOAT64>)` returns a `NULL` literal of type `ARRAY<FLOAT64>`. |

### CAST AS BIGNUMERIC

<div>

</div>

``` devsite-click-to-copy
CAST(expression AS BIGNUMERIC)
```

**Description**

GoogleSQL supports [casting](#cast) to `BIGNUMERIC`. The `expression` parameter can represent an expression for these data types:

- `INT64`
- `FLOAT64`
- `NUMERIC`
- `BIGNUMERIC`
- `STRING`

**Conversion rules**

| From     | To           | Rule(s) when casting `x`                                                                                                                                                                                                                                                                                                                                                                     |
|----------|--------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| FLOAT64  | `BIGNUMERIC` | The floating point number will round [half away from zero](https://en.wikipedia.org/wiki/Rounding#Round_half_away_from_zero). Casting a `NaN`, `+inf` or `-inf` will return an error. Casting a value outside the range of `BIGNUMERIC` returns an overflow error.                                                                                                                           |
| `STRING` | `BIGNUMERIC` | The numeric literal contained in the string must not exceed the maximum precision or range of the `BIGNUMERIC` type, or an error will occur. If the number of digits after the decimal point exceeds 38, then the resulting `BIGNUMERIC` value will round [half away from zero](https://en.wikipedia.org/wiki/Rounding#Round_half_away_from_zero) to have 38 digits after the decimal point. |

### CAST AS BOOL

<div>

</div>

``` devsite-click-to-copy
CAST(expression AS BOOL)
```

**Description**

GoogleSQL supports [casting](#cast) to `BOOL`. The `expression` parameter can represent an expression for these data types:

- `INT64`
- `BOOL`
- `STRING`

**Conversion rules**

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr class="header">
<th>From</th>
<th>To</th>
<th>Rule(s) when casting <code translate="no" dir="ltr">x</code></th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td>INT64</td>
<td><code translate="no" dir="ltr">BOOL</code></td>
<td>Returns <code translate="no" dir="ltr">FALSE</code> if <code translate="no" dir="ltr">x</code> is <code translate="no" dir="ltr">0</code>, <code translate="no" dir="ltr">TRUE</code> otherwise.</td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">STRING</code></td>
<td><code translate="no" dir="ltr">BOOL</code></td>
<td>Returns <code translate="no" dir="ltr">TRUE</code> if <code translate="no" dir="ltr">x</code> is <code translate="no" dir="ltr">"true"</code> and <code translate="no" dir="ltr">FALSE</code> if <code translate="no" dir="ltr">x</code> is <code translate="no" dir="ltr">"false"</code><br />
All other values of <code translate="no" dir="ltr">x</code> are invalid and throw an error instead of casting to a boolean.<br />
A string is case-insensitive when converting to a boolean.</td>
</tr>
</tbody>
</table>

### CAST AS BYTES

<div>

</div>

``` devsite-click-to-copy
CAST(expression AS BYTES [format_clause])
```

**Description**

GoogleSQL supports [casting](#cast) to `BYTES`. The `expression` parameter can represent an expression for these data types:

- `BYTES`
- `STRING`

**Format clause**

When an expression of one type is cast to another type, you can use the [format clause](/bigquery/docs/reference/standard-sql/format-elements#formatting_syntax) to provide instructions for how to conduct the cast. You can use the format clause in this section if `expression` is a `STRING`.

- [Format string as bytes](/bigquery/docs/reference/standard-sql/format-elements#format_string_as_bytes)

**Conversion rules**

| From     | To      | Rule(s) when casting `x`                                                                                                                                       |
|----------|---------|----------------------------------------------------------------------------------------------------------------------------------------------------------------|
| `STRING` | `BYTES` | Strings are cast to bytes using UTF-8 encoding. For example, the string "©", when cast to bytes, would become a 2-byte sequence with the hex values C2 and A9. |

### CAST AS DATE

<div>

</div>

``` devsite-click-to-copy
CAST(expression AS DATE [format_clause])
```

**Description**

GoogleSQL supports [casting](#cast) to `DATE`. The `expression` parameter can represent an expression for these data types:

- `STRING`
- `DATETIME`
- `TIMESTAMP`

**Format clause**

When an expression of one type is cast to another type, you can use the [format clause](/bigquery/docs/reference/standard-sql/format-elements#formatting_syntax) to provide instructions for how to conduct the cast. You can use the format clause in this section if `expression` is a `STRING`.

- [Format string as date and time](/bigquery/docs/reference/standard-sql/format-elements#format_string_as_datetime)

**Conversion rules**

| From        | To     | Rule(s) when casting `x`                                                                                                                                                                                                                                            |
|-------------|--------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| `STRING`    | `DATE` | When casting from string to date, the string must conform to the supported date literal format, and is independent of time zone. If the string expression is invalid or represents a date that's outside of the supported min/max range, then an error is produced. |
| `TIMESTAMP` | `DATE` | Casting from a timestamp to date effectively truncates the timestamp as of the default time zone.                                                                                                                                                                   |

### CAST AS DATETIME

<div>

</div>

``` devsite-click-to-copy
CAST(expression AS DATETIME [format_clause])
```

**Description**

GoogleSQL supports [casting](#cast) to `DATETIME`. The `expression` parameter can represent an expression for these data types:

- `STRING`
- `DATETIME`
- `TIMESTAMP`

**Format clause**

When an expression of one type is cast to another type, you can use the [format clause](/bigquery/docs/reference/standard-sql/format-elements#formatting_syntax) to provide instructions for how to conduct the cast. You can use the format clause in this section if `expression` is a `STRING`.

- [Format string as date and time](/bigquery/docs/reference/standard-sql/format-elements#format_string_as_datetime)

**Conversion rules**

| From        | To         | Rule(s) when casting `x`                                                                                                                                                                                                                                                        |
|-------------|------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| `STRING`    | `DATETIME` | When casting from string to datetime, the string must conform to the supported datetime literal format, and is independent of time zone. If the string expression is invalid or represents a datetime that's outside of the supported min/max range, then an error is produced. |
| `TIMESTAMP` | `DATETIME` | Casting from a timestamp to datetime effectively truncates the timestamp as of the default time zone.                                                                                                                                                                           |

### CAST AS FLOAT64

<div>

</div>

``` devsite-click-to-copy
CAST(expression AS FLOAT64)
```

**Description**

GoogleSQL supports [casting](#cast) to floating point types. The `expression` parameter can represent an expression for these data types:

- `INT64`
- `FLOAT64`
- `NUMERIC`
- `BIGNUMERIC`
- `STRING`

**Conversion rules**

| From         | To      | Rule(s) when casting `x`                                                                                                                                                                                                                                                     |
|--------------|---------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| INT64        | FLOAT64 | Returns a close but potentially not exact floating point value.                                                                                                                                                                                                              |
| `NUMERIC`    | FLOAT64 | `NUMERIC` will convert to the closest floating point number with a possible loss of precision.                                                                                                                                                                               |
| `BIGNUMERIC` | FLOAT64 | `BIGNUMERIC` will convert to the closest floating point number with a possible loss of precision.                                                                                                                                                                            |
| `STRING`     | FLOAT64 | Returns `x` as a floating point value, interpreting it as having the same form as a valid floating point literal. Also supports casts from `"[+,-]inf"` to `[,-]Infinity`, `"[+,-]infinity"` to `[,-]Infinity`, and `"[+,-]nan"` to `NaN`. Conversions are case-insensitive. |

### CAST AS INT64

<div>

</div>

``` devsite-click-to-copy
CAST(expression AS INT64)
```

**Description**

GoogleSQL supports [casting](#cast) to integer types. The `expression` parameter can represent an expression for these data types:

- `INT64`
- `FLOAT64`
- `NUMERIC`
- `BIGNUMERIC`
- `BOOL`
- `STRING`

**Conversion rules**

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr class="header">
<th>From</th>
<th>To</th>
<th>Rule(s) when casting <code translate="no" dir="ltr">x</code></th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td>FLOAT64</td>
<td>INT64</td>
<td>Returns the closest integer value.<br />
Halfway cases such as 1.5 or -0.5 round away from zero.</td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">BOOL</code></td>
<td>INT64</td>
<td>Returns <code translate="no" dir="ltr">1</code> if <code translate="no" dir="ltr">x</code> is <code translate="no" dir="ltr">TRUE</code>, <code translate="no" dir="ltr">0</code> otherwise.</td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">STRING</code></td>
<td>INT64</td>
<td>A hex string can be cast to an integer. For example, <code translate="no" dir="ltr">0x123</code> to <code translate="no" dir="ltr">291</code> or <code translate="no" dir="ltr">-0x123</code> to <code translate="no" dir="ltr">-291</code>.</td>
</tr>
</tbody>
</table>

**Examples**

If you are working with hex strings (`0x123`), you can cast those strings as integers:

<div>

</div>

``` devsite-click-to-copy
SELECT '0x123' as hex_value, CAST('0x123' as INT64) as hex_to_int;

/*-----------+------------+
 | hex_value | hex_to_int |
 +-----------+------------+
 | 0x123     | 291        |
 +-----------+------------*/
```

<div>

</div>

``` devsite-click-to-copy
SELECT '-0x123' as hex_value, CAST('-0x123' as INT64) as hex_to_int;

/*-----------+------------+
 | hex_value | hex_to_int |
 +-----------+------------+
 | -0x123    | -291       |
 +-----------+------------*/
```

### CAST AS INTERVAL

<div>

</div>

``` devsite-click-to-copy
CAST(expression AS INTERVAL)
```

**Description**

GoogleSQL supports [casting](#cast) to `INTERVAL`. The `expression` parameter can represent an expression for these data types:

- `STRING`

**Conversion rules**

| From     | To         | Rule(s) when casting `x`                                                                                                                                                                                                                                                                                                                                                                                                                           |
|----------|------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| `STRING` | `INTERVAL` | When casting from string to interval, the string must conform to either [ISO 8601 Duration](https://en.wikipedia.org/wiki/ISO_8601#Durations) standard or to interval literal format 'Y-M D H:M:S.F'. Partial interval literal formats are also accepted when they aren't ambiguous, for example 'H:M:S'. If the string expression is invalid or represents an interval that is outside of the supported min/max range, then an error is produced. |

**Examples**

<div>

</div>

``` devsite-click-to-copy
SELECT input, CAST(input AS INTERVAL) AS output
FROM UNNEST([
  '1-2 3 10:20:30.456',
  '1-2',
  '10:20:30',
  'P1Y2M3D',
  'PT10H20M30,456S'
]) input

/*--------------------+--------------------+
 | input              | output             |
 +--------------------+--------------------+
 | 1-2 3 10:20:30.456 | 1-2 3 10:20:30.456 |
 | 1-2                | 1-2 0 0:0:0        |
 | 10:20:30           | 0-0 0 10:20:30     |
 | P1Y2M3D            | 1-2 3 0:0:0        |
 | PT10H20M30,456S    | 0-0 0 10:20:30.456 |
 +--------------------+--------------------*/
```

### CAST AS NUMERIC

<div>

</div>

``` devsite-click-to-copy
CAST(expression AS NUMERIC)
```

**Description**

GoogleSQL supports [casting](#cast) to `NUMERIC`. The `expression` parameter can represent an expression for these data types:

- `INT64`
- `FLOAT64`
- `NUMERIC`
- `BIGNUMERIC`
- `STRING`

**Conversion rules**

| From      | To        | Rule(s) when casting `x`                                                                                                                                                                                                                                                                                                                                                                    |
|-----------|-----------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| `FLOAT64` | `NUMERIC` | The floating point number will round [half away from zero](https://en.wikipedia.org/wiki/Rounding#Round_half_away_from_zero). Casting a `NaN`, `+inf` or `-inf` will return an error. Casting a value outside the range of `NUMERIC` returns an overflow error.                                                                                                                             |
| `STRING`  | `NUMERIC` | The numeric literal contained in the string must not exceed the maximum precision or range of the `NUMERIC` type, or an error will occur. If the number of digits after the decimal point exceeds nine, then the resulting `NUMERIC` value will round [half away from zero](https://en.wikipedia.org/wiki/Rounding#Round_half_away_from_zero). to have nine digits after the decimal point. |

### CAST AS RANGE

<div>

</div>

``` devsite-click-to-copy
CAST(expression AS RANGE)
```

**Description**

GoogleSQL supports [casting](#cast) to `RANGE`. The `expression` parameter can represent an expression for these data types:

- `STRING`

**Conversion rules**

| From     | To      | Rule(s) when casting `x`                                                                                                                                                                                                                      |
|----------|---------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| `STRING` | `RANGE` | When casting from string to range, the string must conform to the supported range literal format. If the string expression is invalid or represents a range that's outside of the supported subtype min/max range, then an error is produced. |

**Examples**

<div>

</div>

``` devsite-click-to-copy
SELECT CAST(
  '[2020-01-01, 2020-01-02)'
  AS RANGE<DATE>) AS string_to_range

/*----------------------------------------+
 | string_to_range                        |
 +----------------------------------------+
 | [DATE '2020-01-01', DATE '2020-01-02') |
 +----------------------------------------*/
```

<div>

</div>

``` devsite-click-to-copy
SELECT CAST(
  '[2014-09-27 12:30:00.45, 2016-10-17 11:15:00.33)'
  AS RANGE<DATETIME>) AS string_to_range

/*------------------------------------------------------------------------+
 | string_to_range                                                        |
 +------------------------------------------------------------------------+
 | [DATETIME '2014-09-27 12:30:00.45', DATETIME '2016-10-17 11:15:00.33') |
 +------------------------------------------------------------------------*/
```

<div>

</div>

``` devsite-click-to-copy
SELECT CAST(
  '[2014-09-27 12:30:00+08, 2016-10-17 11:15:00+08)'
  AS RANGE<TIMESTAMP>) AS string_to_range

-- Results depend upon where this query was executed.
/*---------------------------------------------------------------------------+
 | string_to_range                                                           |
 +---------------------------------------------------------------------------+
 | [TIMESTAMP '2014-09-27 12:30:00+08', TIMESTAMP '2016-10-17 11:15:00 UTC') |
 +---------------------------------------------------------------------------*/
```

<div>

</div>

``` devsite-click-to-copy
SELECT CAST(
  '[UNBOUNDED, 2020-01-02)'
  AS RANGE<DATE>) AS string_to_range

/*--------------------------------+
 | string_to_range                |
 +--------------------------------+
 | [UNBOUNDED, DATE '2020-01-02') |
 +--------------------------------*/
```

<div>

</div>

``` devsite-click-to-copy
SELECT CAST(
  '[2020-01-01, NULL)'
  AS RANGE<DATE>) AS string_to_range

/*--------------------------------+
 | string_to_range                |
 +--------------------------------+
 | [DATE '2020-01-01', UNBOUNDED) |
 +--------------------------------*/
```

### CAST AS STRING

<div>

</div>

``` devsite-click-to-copy
CAST(expression AS STRING [format_clause [AT TIME ZONE timezone_expr]])
```

**Description**

GoogleSQL supports [casting](#cast) to `STRING`. The `expression` parameter can represent an expression for these data types:

- `INT64`
- `FLOAT64`
- `NUMERIC`
- `BIGNUMERIC`
- `BOOL`
- `BYTES`
- `TIME`
- `DATE`
- `DATETIME`
- `TIMESTAMP`
- `RANGE`
- `INTERVAL`
- `STRING`

**Format clause**

When an expression of one type is cast to another type, you can use the [format clause](/bigquery/docs/reference/standard-sql/format-elements#formatting_syntax) to provide instructions for how to conduct the cast. You can use the format clause in this section if `expression` is one of these data types:

- `INT64`
- `FLOAT64`
- `NUMERIC`
- `BIGNUMERIC`
- `BYTES`
- `TIME`
- `DATE`
- `DATETIME`
- `TIMESTAMP`

The format clause for `STRING` has an additional optional clause called `AT TIME ZONE timezone_expr`, which you can use to specify a specific time zone to use during formatting of a `TIMESTAMP`. If this optional clause isn't included when formatting a `TIMESTAMP`, the default time zone, UTC, is used.

For more information, see the following topics:

- [Format bytes as string](/bigquery/docs/reference/standard-sql/format-elements#format_bytes_as_string)
- [Format date and time as string](/bigquery/docs/reference/standard-sql/format-elements#format_date_time_as_string)
- [Format numeric type as string](/bigquery/docs/reference/standard-sql/format-elements#format_numeric_type_as_string)

**Conversion rules**

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr class="header">
<th>From</th>
<th>To</th>
<th>Rule(s) when casting <code translate="no" dir="ltr">x</code></th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td>FLOAT64</td>
<td><code translate="no" dir="ltr">STRING</code></td>
<td>Returns an approximate string representation. A returned <code translate="no" dir="ltr">NaN</code> or <code translate="no" dir="ltr">0</code> will not be signed.<br />
</td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">BOOL</code></td>
<td><code translate="no" dir="ltr">STRING</code></td>
<td>Returns <code translate="no" dir="ltr">"true"</code> if <code translate="no" dir="ltr">x</code> is <code translate="no" dir="ltr">TRUE</code>, <code translate="no" dir="ltr">"false"</code> otherwise.</td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">BYTES</code></td>
<td><code translate="no" dir="ltr">STRING</code></td>
<td>Returns <code translate="no" dir="ltr">x</code> interpreted as a UTF-8 string.<br />
For example, the bytes literal <code translate="no" dir="ltr">b'\xc2\xa9'</code>, when cast to a string, is interpreted as UTF-8 and becomes the unicode character "©".<br />
An error occurs if <code translate="no" dir="ltr">x</code> isn't valid UTF-8.</td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">TIME</code></td>
<td><code translate="no" dir="ltr">STRING</code></td>
<td>Casting from a time type to a string is independent of time zone and is of the form <code translate="no" dir="ltr">HH:MM:SS</code>.</td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">DATE</code></td>
<td><code translate="no" dir="ltr">STRING</code></td>
<td>Casting from a date type to a string is independent of time zone and is of the form <code translate="no" dir="ltr">YYYY-MM-DD</code>.</td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">DATETIME</code></td>
<td><code translate="no" dir="ltr">STRING</code></td>
<td>Casting from a datetime type to a string is independent of time zone and is of the form <code translate="no" dir="ltr">YYYY-MM-DD HH:MM:SS</code>.</td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">TIMESTAMP</code></td>
<td><code translate="no" dir="ltr">STRING</code></td>
<td>When casting from timestamp types to string, the timestamp is interpreted using the default time zone, UTC. The number of subsecond digits produced depends on the number of trailing zeroes in the subsecond part: the CAST function will truncate zero, three, or six digits.</td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">INTERVAL</code></td>
<td><code translate="no" dir="ltr">STRING</code></td>
<td>Casting from an interval to a string is of the form <code translate="no" dir="ltr">Y-M D H:M:S</code>.</td>
</tr>
</tbody>
</table>

**Examples**

<div>

</div>

``` devsite-click-to-copy
SELECT CAST(CURRENT_DATE() AS STRING) AS current_date

/*---------------+
 | current_date  |
 +---------------+
 | 2021-03-09    |
 +---------------*/
```

<div>

</div>

``` devsite-click-to-copy
SELECT CAST(CURRENT_DATE() AS STRING FORMAT 'DAY') AS current_day

/*-------------+
 | current_day |
 +-------------+
 | MONDAY      |
 +-------------*/
```

<div>

</div>

``` devsite-click-to-copy
SELECT CAST(
  TIMESTAMP '2008-12-25 00:00:00+00:00'
  AS STRING FORMAT 'YYYY-MM-DD HH24:MI:SS TZH:TZM') AS date_time_to_string

-- Results depend upon where this query was executed.
/*------------------------------+
 | date_time_to_string          |
 +------------------------------+
 | 2008-12-24 16:00:00 -08:00   |
 +------------------------------*/
```

<div>

</div>

``` devsite-click-to-copy
SELECT CAST(
  TIMESTAMP '2008-12-25 00:00:00+00:00'
  AS STRING FORMAT 'YYYY-MM-DD HH24:MI:SS TZH:TZM'
  AT TIME ZONE 'Asia/Kolkata') AS date_time_to_string

-- Because the time zone is specified, the result is always the same.
/*------------------------------+
 | date_time_to_string          |
 +------------------------------+
 | 2008-12-25 05:30:00 +05:30   |
 +------------------------------*/
```

<div>

</div>

``` devsite-click-to-copy
SELECT CAST(INTERVAL 3 DAY AS STRING) AS interval_to_string

/*--------------------+
 | interval_to_string |
 +--------------------+
 | 0-0 3 0:0:0        |
 +--------------------*/
```

<div>

</div>

``` devsite-click-to-copy
SELECT CAST(
  INTERVAL "1-2 3 4:5:6.789" YEAR TO SECOND
  AS STRING) AS interval_to_string

/*--------------------+
 | interval_to_string |
 +--------------------+
 | 1-2 3 4:5:6.789    |
 +--------------------*/
```

### CAST AS STRUCT

<div>

</div>

``` devsite-click-to-copy
CAST(expression AS STRUCT)
```

**Description**

GoogleSQL supports [casting](#cast) to `STRUCT`. The `expression` parameter can represent an expression for these data types:

- `STRUCT`

**Conversion rules**

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr class="header">
<th>From</th>
<th>To</th>
<th>Rule(s) when casting <code translate="no" dir="ltr">x</code></th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td><code translate="no" dir="ltr">STRUCT</code></td>
<td><code translate="no" dir="ltr">STRUCT</code></td>
<td>Allowed if the following conditions are met:<br />
&#10;<ol>
<li>The two structs have the same number of fields.</li>
<li>The original struct field types can be explicitly cast to the corresponding target struct field types (as defined by field order, not field name).</li>
</ol></td>
</tr>
</tbody>
</table>

### CAST AS TIME

<div>

</div>

``` devsite-click-to-copy
CAST(expression AS TIME [format_clause])
```

**Description**

GoogleSQL supports [casting](#cast) to TIME. The `expression` parameter can represent an expression for these data types:

- `STRING`
- `TIME`
- `DATETIME`
- `TIMESTAMP`

**Format clause**

When an expression of one type is cast to another type, you can use the [format clause](/bigquery/docs/reference/standard-sql/format-elements#formatting_syntax) to provide instructions for how to conduct the cast. You can use the format clause in this section if `expression` is a `STRING`.

- [Format string as date and time](/bigquery/docs/reference/standard-sql/format-elements#format_string_as_datetime)

**Conversion rules**

| From     | To     | Rule(s) when casting `x`                                                                                                                                                                                                                                            |
|----------|--------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| `STRING` | `TIME` | When casting from string to time, the string must conform to the supported time literal format, and is independent of time zone. If the string expression is invalid or represents a time that's outside of the supported min/max range, then an error is produced. |

### CAST AS TIMESTAMP

<div>

</div>

``` devsite-click-to-copy
CAST(expression AS TIMESTAMP [format_clause [AT TIME ZONE timezone_expr]])
```

**Description**

GoogleSQL supports [casting](#cast) to `TIMESTAMP`. The `expression` parameter can represent an expression for these data types:

- `DATE`
- `DATETIME`
- `STRING`
- `TIMESTAMP`

**Format clause**

When an expression of one type is cast to another type, you can use the [format clause](/bigquery/docs/reference/standard-sql/format-elements#formatting_syntax) to provide instructions for how to conduct the cast. You can use the format clause in this section if `expression` is a `STRING`.

- [Format string as date and time](/bigquery/docs/reference/standard-sql/format-elements#format_string_as_datetime)

The format clause for `TIMESTAMP` has an additional optional clause called `AT TIME ZONE timezone_expr`, which you can use to specify a specific time zone to use during formatting. If this optional clause isn't included, the default time zone, UTC, is used.

**Conversion rules**

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr class="header">
<th>From</th>
<th>To</th>
<th>Rule(s) when casting <code translate="no" dir="ltr">x</code></th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td><code translate="no" dir="ltr">STRING</code></td>
<td><code translate="no" dir="ltr">TIMESTAMP</code></td>
<td>When casting from string to a timestamp, <code translate="no" dir="ltr">string_expression</code> must conform to the supported timestamp literal formats, or else a runtime error occurs. The <code translate="no" dir="ltr">string_expression</code> may itself contain a time zone.<br />
<br />
If there is a time zone in the <code translate="no" dir="ltr">string_expression</code>, that time zone is used for conversion, otherwise the default time zone, UTC, is used. If the string has fewer than six digits, then it's implicitly widened.<br />
<br />
An error is produced if the <code translate="no" dir="ltr">string_expression</code> is invalid, has more than six subsecond digits (i.e., precision greater than microseconds), or represents a time outside of the supported timestamp range.</td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">DATE</code></td>
<td><code translate="no" dir="ltr">TIMESTAMP</code></td>
<td>Casting from a date to a timestamp interprets <code translate="no" dir="ltr">date_expression</code> as of midnight (start of the day) in the default time zone, UTC.</td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">DATETIME</code></td>
<td><code translate="no" dir="ltr">TIMESTAMP</code></td>
<td>Casting from a datetime to a timestamp interprets <code translate="no" dir="ltr">datetime_expression</code> in the default time zone, UTC.<br />
<br />
Most valid datetime values have exactly one corresponding timestamp in each time zone. However, there are certain combinations of valid datetime values and time zones that have zero or two corresponding timestamp values. This happens in a time zone when clocks are set forward or set back, such as for Daylight Savings Time. When there are two valid timestamps, the earlier one is used. When there is no valid timestamp, the length of the gap in time (typically one hour) is added to the datetime.</td>
</tr>
</tbody>
</table>

**Examples**

The following example casts a string-formatted timestamp as a timestamp:

<div>

</div>

``` devsite-click-to-copy
SELECT CAST("2020-06-02 17:00:53.110+00:00" AS TIMESTAMP) AS as_timestamp

-- Results depend upon where this query was executed.
/*-----------------------------+
 | as_timestamp                |
 +-----------------------------+
 | 2020-06-03 00:00:53.110 UTC |
 +-----------------------------*/
```

The following examples cast a string-formatted date and time as a timestamp. These examples return the same output as the previous example.

<div>

</div>

``` devsite-click-to-copy
SELECT CAST('06/02/2020 17:00:53.110' AS TIMESTAMP FORMAT 'MM/DD/YYYY HH24:MI:SS.FF3' AT TIME ZONE 'UTC') AS as_timestamp
```

<div>

</div>

``` devsite-click-to-copy
SELECT CAST('06/02/2020 17:00:53.110' AS TIMESTAMP FORMAT 'MM/DD/YYYY HH24:MI:SS.FF3' AT TIME ZONE '+00') AS as_timestamp
```

<div>

</div>

``` devsite-click-to-copy
SELECT CAST('06/02/2020 17:00:53.110 +00' AS TIMESTAMP FORMAT 'MM/DD/YYYY HH24:MI:SS.FF3 TZH') AS as_timestamp
```

## `PARSE_BIGNUMERIC`

<div>

</div>

``` devsite-click-to-copy
PARSE_BIGNUMERIC(string_expression)
```

**Description**

Converts a `STRING` to a `BIGNUMERIC` value.

The numeric literal contained in the string must not exceed the [maximum precision or range](/bigquery/docs/reference/standard-sql/data-types#decimal_types) of the `BIGNUMERIC` type, or an error occurs. If the number of digits after the decimal point exceeds 38, then the resulting `BIGNUMERIC` value rounds [half away from zero](https://en.wikipedia.org/wiki/Rounding#Round_half_away_from_zero) to have 38 digits after the decimal point.

<div>

</div>

``` devsite-click-to-copy
-- This example shows how a string with a decimal point is parsed.
SELECT PARSE_BIGNUMERIC("123.45") AS parsed;

/*--------+
 | parsed |
 +--------+
 | 123.45 |
 +--------*/

-- This example shows how a string with an exponent is parsed.
SELECT PARSE_BIGNUMERIC("123.456E37") AS parsed;

/*-----------------------------------------+
 | parsed                                  |
 +-----------------------------------------+
 | 123400000000000000000000000000000000000 |
 +-----------------------------------------*/

-- This example shows the rounding when digits after the decimal point exceeds 38.
SELECT PARSE_BIGNUMERIC("1.123456789012345678901234567890123456789") as parsed;

/*------------------------------------------+
 | parsed                                   |
 +------------------------------------------+
 | 1.12345678901234567890123456789012345679 |
 +------------------------------------------*/
```

This function is similar to using the [`CAST AS BIGNUMERIC`](#cast_bignumeric) function except that the `PARSE_BIGNUMERIC` function only accepts string inputs and allows the following in the string:

- Spaces between the sign (+/-) and the number
- Signs (+/-) after the number

Rules for valid input strings:

| Rule                                                                                          | Example Input     | Output     |
|-----------------------------------------------------------------------------------------------|-------------------|------------|
| The string can only contain digits, commas, decimal points and signs.                         | "- 12,34567,89.0" | -123456789 |
| Whitespaces are allowed anywhere except between digits.                                       | " - 12.345 "      | -12.345    |
| Only digits and commas are allowed before the decimal point.                                  | " 12,345,678"     | 12345678   |
| Only digits are allowed after the decimal point.                                              | "1.234 "          | 1.234      |
| Use `E` or `e` for exponents. After the `e`, digits and a leading sign indicator are allowed. | " 123.45e-1"      | 12.345     |
| If the integer part isn't empty, then it must contain at least one digit.                     | " 0,.12 -"        | -0.12      |
| If the string contains a decimal point, then it must contain at least one digit.              | " .1"             | 0.1        |
| The string can't contain more than one sign.                                                  | " 0.5 +"          | 0.5        |

**Return Data Type**

`BIGNUMERIC`

**Examples**

This example shows an input with spaces before, after, and between the sign and the number:

<div>

</div>

``` devsite-click-to-copy
SELECT PARSE_BIGNUMERIC("  -  12.34 ") as parsed;

/*--------+
 | parsed |
 +--------+
 | -12.34 |
 +--------*/
```

This example shows an input with an exponent as well as the sign after the number:

<div>

</div>

``` devsite-click-to-copy
SELECT PARSE_BIGNUMERIC("12.34e-1-") as parsed;

/*--------+
 | parsed |
 +--------+
 | -1.234 |
 +--------*/
```

This example shows an input with multiple commas in the integer part of the number:

<div>

</div>

``` devsite-click-to-copy
SELECT PARSE_BIGNUMERIC("  1,2,,3,.45 + ") as parsed;

/*--------+
 | parsed |
 +--------+
 | 123.45 |
 +--------*/
```

This example shows an input with a decimal point and no digits in the whole number part:

<div>

</div>

``` devsite-click-to-copy
SELECT PARSE_BIGNUMERIC(".1234  ") as parsed;

/*--------+
 | parsed |
 +--------+
 | 0.1234 |
 +--------*/
```

**Examples of invalid inputs**

This example is invalid because the whole number part contains no digits:

<div>

</div>

``` devsite-click-to-copy
SELECT PARSE_BIGNUMERIC(",,,.1234  ") as parsed;
```

This example is invalid because there are whitespaces between digits:

<div>

</div>

``` devsite-click-to-copy
SELECT PARSE_BIGNUMERIC("1  23.4 5  ") as parsed;
```

This example is invalid because the number is empty except for an exponent:

<div>

</div>

``` devsite-click-to-copy
SELECT PARSE_BIGNUMERIC("  e1 ") as parsed;
```

This example is invalid because the string contains multiple signs:

<div>

</div>

``` devsite-click-to-copy
SELECT PARSE_BIGNUMERIC("  - 12.3 - ") as parsed;
```

This example is invalid because the value of the number falls outside the range of `BIGNUMERIC`:

<div>

</div>

``` devsite-click-to-copy
SELECT PARSE_BIGNUMERIC("12.34E100 ") as parsed;
```

This example is invalid because the string contains invalid characters:

<div>

</div>

``` devsite-click-to-copy
SELECT PARSE_BIGNUMERIC("$12.34") as parsed;
```

## `PARSE_NUMERIC`

<div>

</div>

``` devsite-click-to-copy
PARSE_NUMERIC(string_expression)
```

**Description**

Converts a `STRING` to a `NUMERIC` value.

The numeric literal contained in the string must not exceed the [maximum precision or range](/bigquery/docs/reference/standard-sql/data-types#decimal_types) of the `NUMERIC` type, or an error occurs. If the number of digits after the decimal point exceeds nine, then the resulting `NUMERIC` value rounds [half away from zero](https://en.wikipedia.org/wiki/Rounding#Round_half_away_from_zero) to have nine digits after the decimal point.

<div>

</div>

``` devsite-click-to-copy
-- This example shows how a string with a decimal point is parsed.
SELECT PARSE_NUMERIC("123.45") AS parsed;

/*--------+
 | parsed |
 +--------+
 | 123.45 |
 +--------*/

-- This example shows how a string with an exponent is parsed.
SELECT PARSE_NUMERIC("12.34E27") as parsed;

/*-------------------------------+
 | parsed                        |
 +-------------------------------+
 | 12340000000000000000000000000 |
 +-------------------------------*/

-- This example shows the rounding when digits after the decimal point exceeds 9.
SELECT PARSE_NUMERIC("1.0123456789") as parsed;

/*-------------+
 | parsed      |
 +-------------+
 | 1.012345679 |
 +-------------*/
```

This function is similar to using the [`CAST AS NUMERIC`](#cast_numeric) function except that the `PARSE_NUMERIC` function only accepts string inputs and allows the following in the string:

- Spaces between the sign (+/-) and the number
- Signs (+/-) after the number

Rules for valid input strings:

| Rule                                                                                          | Example Input     | Output     |
|-----------------------------------------------------------------------------------------------|-------------------|------------|
| The string can only contain digits, commas, decimal points and signs.                         | "- 12,34567,89.0" | -123456789 |
| Whitespaces are allowed anywhere except between digits.                                       | " - 12.345 "      | -12.345    |
| Only digits and commas are allowed before the decimal point.                                  | " 12,345,678"     | 12345678   |
| Only digits are allowed after the decimal point.                                              | "1.234 "          | 1.234      |
| Use `E` or `e` for exponents. After the `e`, digits and a leading sign indicator are allowed. | " 123.45e-1"      | 12.345     |
| If the integer part isn't empty, then it must contain at least one digit.                     | " 0,.12 -"        | -0.12      |
| If the string contains a decimal point, then it must contain at least one digit.              | " .1"             | 0.1        |
| The string can't contain more than one sign.                                                  | " 0.5 +"          | 0.5        |

**Return Data Type**

`NUMERIC`

**Examples**

This example shows an input with spaces before, after, and between the sign and the number:

<div>

</div>

``` devsite-click-to-copy
SELECT PARSE_NUMERIC("  -  12.34 ") as parsed;

/*--------+
 | parsed |
 +--------+
 | -12.34 |
 +--------*/
```

This example shows an input with an exponent as well as the sign after the number:

<div>

</div>

``` devsite-click-to-copy
SELECT PARSE_NUMERIC("12.34e-1-") as parsed;

/*--------+
 | parsed |
 +--------+
 | -1.234 |
 +--------*/
```

This example shows an input with multiple commas in the integer part of the number:

<div>

</div>

``` devsite-click-to-copy
SELECT PARSE_NUMERIC("  1,2,,3,.45 + ") as parsed;

/*--------+
 | parsed |
 +--------+
 | 123.45 |
 +--------*/
```

This example shows an input with a decimal point and no digits in the whole number part:

<div>

</div>

``` devsite-click-to-copy
SELECT PARSE_NUMERIC(".1234  ") as parsed;

/*--------+
 | parsed |
 +--------+
 | 0.1234 |
 +--------*/
```

**Examples of invalid inputs**

This example is invalid because the whole number part contains no digits:

<div>

</div>

``` devsite-click-to-copy
SELECT PARSE_NUMERIC(",,,.1234  ") as parsed;
```

This example is invalid because there are whitespaces between digits:

<div>

</div>

``` devsite-click-to-copy
SELECT PARSE_NUMERIC("1  23.4 5  ") as parsed;
```

This example is invalid because the number is empty except for an exponent:

<div>

</div>

``` devsite-click-to-copy
SELECT PARSE_NUMERIC("  e1 ") as parsed;
```

This example is invalid because the string contains multiple signs:

<div>

</div>

``` devsite-click-to-copy
SELECT PARSE_NUMERIC("  - 12.3 - ") as parsed;
```

This example is invalid because the value of the number falls outside the range of `BIGNUMERIC`:

<div>

</div>

``` devsite-click-to-copy
SELECT PARSE_NUMERIC("12.34E100 ") as parsed;
```

This example is invalid because the string contains invalid characters:

<div>

</div>

``` devsite-click-to-copy
SELECT PARSE_NUMERIC("$12.34") as parsed;
```

## `SAFE_CAST`

<div>

</div>

``` devsite-click-to-copy
SAFE_CAST(expression AS typename [format_clause])
```

**Description**

When using `CAST`, a query can fail if GoogleSQL is unable to perform the cast. For example, the following query generates an error:

<div>

</div>

``` devsite-click-to-copy
SELECT CAST("apple" AS INT64) AS not_a_number;
```

If you want to protect your queries from these types of errors, you can use `SAFE_CAST`. `SAFE_CAST` replaces runtime errors with `NULL`s. However, during static analysis, impossible casts between two non-castable types still produce an error because the query is invalid.

<div>

</div>

``` devsite-click-to-copy
SELECT SAFE_CAST("apple" AS INT64) AS not_a_number;

/*--------------+
 | not_a_number |
 +--------------+
 | NULL         |
 +--------------*/
```

Some casts can include a [format clause](/bigquery/docs/reference/standard-sql/format-elements#formatting_syntax), which provides instructions for how to conduct the cast. For example, you could instruct a cast to convert a sequence of bytes to a BASE64-encoded string instead of a UTF-8-encoded string.

The structure of the format clause is unique to each type of cast and more information is available in the section for that cast.

If you are casting from bytes to strings, you can also use the function, [`SAFE_CONVERT_BYTES_TO_STRING`](/bigquery/docs/reference/standard-sql/string_functions#safe_convert_bytes_to_string). Any invalid UTF-8 characters are replaced with the unicode replacement character, `U+FFFD`.

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
