# Type Functions Reference

<div class="devsite-article-body clearfix devsite-no-page-title">

# Type Functions Reference

## **Type Functions**

|                       |                                                         |
|-----------------------|---------------------------------------------------------|
| Name                  | Description                                             |
| [`TYPE`](#type)       | Returns the type of the value as a `STRING`.            |
| [`IS_TYPE`](#is_type) | Returns `true` if the value matches the specified type. |

### TYPE

**Syntax:**

<div>

</div>

``` devsite-click-to-copy
type(input: ANY) -> STRING
```

**Description:**

Returns a string representation of the `input` type.

If given an absent value, returns `NULL`.

**Examples:**

| `input`                                | `type(input)`      |
|----------------------------------------|--------------------|
| NULL                                   | `"null"`           |
| true                                   | `"boolean"`        |
| 1                                      | `"int32"`          |
| -3L                                    | `"int64"`          |
| 3.14                                   | `"float64"`        |
| 2024-01-01T00:00:00Z UTC               | `"timestamp"`      |
| "foo"                                  | `"string"`         |
| b"foo"                                 | `"bytes"`          |
| \[1, 2\]                               | `"array"`          |
| {"a": 1}                               | `"map"`            |
| `path("c/d")`                          | `"reference"`      |
| `vector([1.0, 2.0])`                   | `"vector"`         |
| `object_id "a7f2c9d18b3e4509f67c12d8"` | `"object_id"`      |
| `1.2e9m`                               | `"decimal128"`     |
| `regex "/pattern/i"`                   | `"regex"`          |
| `bson_timestamp(1732754912, 500)`      | `"bson_timestamp"` |
| ABSENT                                 | `NULL`             |

**Client examples**

<div class="ds-selector-tabs" ds-scope="lang">

<div class="section">

##### Node.js

<div>

</div>

``` devsite-click-to-copy
const result = await db.pipeline()
  .collection("books")
  .select(field("title").notEqual("1984").as("not1984"))
  .execute();test.firestore.js
```

</div>

<div class="section">

### <span class="two-line-tab"><span tab-label="modular API"></span>Web</span>

<div>

</div>

``` devsite-click-to-copy
const result = await execute(db.pipeline()
  .collection("books")
  .select(field("title").notEqual("1984").as("not1984"))
);test.firestore.js
```

</div>

<div class="section">

##### Swift

<div>

</div>

``` devsite-click-to-copy
let result = try await db.pipeline()
  .collection("books")
  .select([Field("title").notEqual("1984").as("not1984")])
  .execute()PipelineSnippets.swift
```

</div>

<div class="section">

##### <span class="two-line-tab">Kotlin <span class="firebase-platform-label">Android</span></span>

<div>

</div>

``` devsite-click-to-copy
val result = db.pipeline()
    .collection("books")
    .select(field("title").notEqual("1984").alias("not1984"))
    .execute()DocSnippets.kt
```

</div>

<div class="section">

##### <span class="two-line-tab">Java <span class="firebase-platform-label">Android</span></span>

<div>

</div>

``` devsite-click-to-copy
Task<Pipeline.Snapshot> result = db.pipeline()
    .collection("books")
    .select(field("title").notEqual("1984").alias("not1984"))
    .execute();DocSnippets.java
```

</div>

<div class="section">

##### Python

<div>

</div>

``` devsite-click-to-copy
from google.cloud.firestore_v1.pipeline_expressions import Field

result = (
    client.pipeline()
    .collection("books")
    .select(Field.of("title").not_equal("1984").as_("not1984"))
    .execute()
)firestore_pipelines.py
```

</div>

<div class="section">

##### Java

<div>

</div>

``` devsite-click-to-copy
Pipeline.Snapshot result =
    firestore
        .pipeline()
        .collection("books")
        .select(notEqual(field("title"), "1984").as("not1984"))
        .execute()
        .get();PipelineSnippets.java
```

</div>

<div class="section">

##### Go

<div>

</div>

``` devsite-click-to-copy
snapshot := client.Pipeline().
 Collection("books").
 Select(firestore.Fields(
     firestore.NotEqual(firestore.FieldOf("title"), "1984").As("not1984"),
 )).
 Execute(ctx)pipeline_snippets_comparison.go
```

</div>

</div>

### IS_TYPE

**Syntax:**

<div>

</div>

``` devsite-click-to-copy
is_type(input: ANY, type: STRING) -> BOOLEAN
```

**Description:**

Returns `true` if the `input` matches the specified `type`, otherwise `false`. If given an absent `input`, returns `NULL`.

Supported `type` strings are:

- `"null"`
- `"boolean"`
- `"int32"`
- `"int64"`
- `"float64"`
- `"decimal128"`
- `"number"`
- `"timestamp"`
- `"string"`
- `"bytes"`
- `"array"`
- `"map"`
- `"reference"`
- `"vector"`
- `"geo_point"`
- `"max_key"`
- `"min_key"`
- `"object_id"`
- `"regex"`
- `"bson_timestamp"`

**Examples:**

| `input`              | `type`    | `is_type(input, type)` |
|:---------------------|:----------|:-----------------------|
| NULL                 | "null"    | true                   |
| true                 | "boolean" | true                   |
| 3.14                 | "float64" | true                   |
| "foo"                | "string"  | true                   |
| b"foo"               | "string"  | false                  |
| \[1, 2\]             | "array"   | true                   |
| {"a": 1}             | "map"     | true                   |
| `vector([1.0, 2.0])` | "vector"  | true                   |
| ABSENT               | "string"  | NULL                   |
| "bar"                | "other"   | ERROR                  |

## What's next

- See the [Pipeline Queries overview](/firestore/docs/pipeline/overview)

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
