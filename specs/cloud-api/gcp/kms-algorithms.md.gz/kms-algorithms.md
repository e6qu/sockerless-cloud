# Key purposes and algorithms

<div class="devsite-article-body clearfix">

The function of a Cloud KMS key is determined by the following parameters:

- **Protection level**: Controls where cryptographic operations are performed, for example, in Google Cloud hardware security modules or in an external key manager.
- **Purpose**: Determines the cryptographic operations that the key can perform.
- **Algorithm**: The specific parameters that are used for cryptographic operations.

This document lists the protection levels, key purposes, and algorithms that you can use with Cloud KMS. For each one, the "SDK" value is used with gcloud CLI, and the "REST" value is used with the Cloud KMS API. This document also identifies whether each algorithm is considered quantum-safe, and whether an algorithm is the recommended algorithm for its purpose.

For each group of algorithms, select a protection level to see supported algorithms.

## Protection levels

The protection level indicates where cryptographic operations are performed. After you create a key, you can't change the protection level. Some key purposes and algorithms are available only for specific protection levels.

<div>

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th>Protection level</th>
<th>Description</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">software</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">SOFTWARE</code></span></td>
<td>Cryptographic operations are performed in software.</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">hsm</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">HSM</code></span></td>
<td>Cryptographic operations are performed in an HSM.</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">hsm-single-tenant</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">HSM_SINGLE_TENANT</code></span></td>
<td>Cryptographic operations are performed in a dedicated cluster of HSM partitions, exclusively created for a single-tenant Cloud HSM instance.</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">external</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">EXTERNAL</code></span></td>
<td>Cryptographic operations are performed using a key stored in an <a href="/kms/docs/ekm">external key manager</a> connected to Google Cloud using the internet. Limited to symmetric encryption and asymmetric signing.</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">external-vpc</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">EXTERNAL_VPC</code></span></td>
<td>Cryptographic operations are performed using a key stored in an <a href="/kms/docs/ekm">external key manager</a> connected to Google Cloud over Virtual Private Cloud (VPC). Limited to symmetric encryption and asymmetric signing.</td>
</tr>
</tbody>
</table>

</div>

## Key purposes

Cloud KMS supports the following key purposes:

<div>

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr class="header">
<th>Use for</th>
<th>Purpose</th>
<th>Supported methods</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td><a href="/kms/docs/encrypt-decrypt">Symmetric encryption</a></td>
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">encryption</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">ENCRYPT_DECRYPT</code></span></td>
<td><ul>
<li><a href="/kms/docs/reference/rest/v1/projects.locations.keyRings.cryptoKeys/encrypt">cryptoKeys.encrypt</a></li>
<li><a href="/kms/docs/reference/rest/v1/projects.locations.keyRings.cryptoKeys/decrypt">cryptoKeys.decrypt</a></li>
</ul></td>
</tr>
<tr class="even">
<td><a href="/kms/docs/raw-encryption">Raw symmetric encryption</a></td>
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">raw-encryption</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RAW_ENCRYPT_DECRYPT</code></span></td>
<td><ul>
<li><a href="/kms/docs/reference/rest/v1/projects.locations.keyRings.cryptoKeys.cryptoKeyVersions/rawEncrypt">cryptoKeys.rawEncrypt</a></li>
<li><a href="/kms/docs/reference/rest/v1/projects.locations.keyRings.cryptoKeys.cryptoKeyVersions/rawDecrypt">cryptoKeys.rawDecrypt</a></li>
</ul></td>
</tr>
<tr class="odd">
<td><a href="/kms/docs/digital-signatures">Asymmetric signing</a></td>
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">asymmetric-signing</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">ASYMMETRIC_SIGN</code></span></td>
<td><ul>
<li><a href="/kms/docs/reference/rest/v1/projects.locations.keyRings.cryptoKeys.cryptoKeyVersions/asymmetricSign">cryptoKeyVersions.asymmetricSign</a></li>
<li><a href="/kms/docs/reference/rest/v1/projects.locations.keyRings.cryptoKeys.cryptoKeyVersions/getPublicKey">cryptoKeyVersions.getPublicKey</a></li>
</ul></td>
</tr>
<tr class="even">
<td><a href="/kms/docs/asymmetric-encryption">Asymmetric encryption</a></td>
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">asymmetric-encryption</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">ASYMMETRIC_DECRYPT</code></span></td>
<td><ul>
<li><a href="/kms/docs/reference/rest/v1/projects.locations.keyRings.cryptoKeys.cryptoKeyVersions/asymmetricDecrypt">cryptoKeyVersions.asymmetricDecrypt</a></li>
<li><a href="/kms/docs/reference/rest/v1/projects.locations.keyRings.cryptoKeys.cryptoKeyVersions/getPublicKey">cryptoKeyVersions.getPublicKey</a></li>
</ul></td>
</tr>
<tr class="odd">
<td><a href="/kms/docs/key-encapsulation-mechanisms">Key encapsulation mechanisms</a></td>
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">key-encapsulation</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">KEY_ENCAPSULATION</code></span></td>
<td><ul>
<li><a href="/kms/docs/reference/rest/v1/projects.locations.keyRings.cryptoKeys.cryptoKeyVersions/decapsulate">cryptoKeyVersions.decapsulate</a></li>
<li><a href="/kms/docs/reference/rest/v1/projects.locations.keyRings.cryptoKeys.cryptoKeyVersions/getPublicKey">cryptoKeyVersions.getPublicKey</a></li>
</ul></td>
</tr>
<tr class="even">
<td><a href="/kms/docs/mac-signatures">MAC signing</a></td>
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">mac</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">MAC</code></span></td>
<td><ul>
<li><a href="/kms/docs/reference/rest/v1/projects.locations.keyRings.cryptoKeys.cryptoKeyVersions/macSign">cryptoKeyVersions.macSign</a></li>
<li><a href="/kms/docs/reference/rest/v1/projects.locations.keyRings.cryptoKeys.cryptoKeyVersions/macVerify">cryptoKeyVersions.macVerify</a></li>
</ul></td>
</tr>
</tbody>
</table>

</div>

When you create a key, you define the purpose and the algorithm of that key. You can change the algorithm when you create new key versions, subject to the scope of its purpose. The purpose can't be changed.

Two keys with the same purpose may use different underlying algorithms, but they must support the same set of cryptographic operations.

## Symmetric encryption algorithms

The `ENCRYPT_DECRYPT` key purpose enables symmetric encryption. Standard symmetric encryption algorithms use 256-bit Advanced Encryption Standard (AES-256) keys in Galois Counter Mode (GCM). Symmetric encryption algorithms such as AES-256 are generally considered quantum-safe. You can continue to use symmetric encryption.

Algorithm support varies by protection level.

<div class="section">

### Any

<div>

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr class="header">
<th>Algorithm</th>
<th>Description</th>
<th>Quantum-safe</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">google-symmetric-encryption</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">GOOGLE_SYMMETRIC_ENCRYPTION</code></span></td>
<td><p>256-bit Advanced Encryption Standard (AES-256) keys in Galois Counter Mode (GCM), padded with Cloud KMS-internal metadata.</p></td>
<td>Yes</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">external-symmetric-encryption</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">EXTERNAL_SYMMETRIC_ENCRYPTION</code></span></td>
<td><p>256-bit Advanced Encryption Standard (AES-256) keys in Galois Counter Mode (GCM).</p></td>
<td>Yes</td>
</tr>
</tbody>
</table>

</div>

</div>

<div class="section">

### software

<div>

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr class="header">
<th>Algorithm</th>
<th>Description</th>
<th>Quantum-safe</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">google-symmetric-encryption</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">GOOGLE_SYMMETRIC_ENCRYPTION</code></span></td>
<td><p>256-bit Advanced Encryption Standard (AES-256) keys in Galois Counter Mode (GCM), padded with Cloud KMS-internal metadata.</p></td>
<td>Yes</td>
</tr>
</tbody>
</table>

</div>

</div>

<div class="section">

### hsm

<div>

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr class="header">
<th>Algorithm</th>
<th>Description</th>
<th>Quantum-safe</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">google-symmetric-encryption</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">GOOGLE_SYMMETRIC_ENCRYPTION</code></span></td>
<td><p>256-bit Advanced Encryption Standard (AES-256) keys in Galois Counter Mode (GCM), padded with Cloud KMS-internal metadata.</p></td>
<td>Yes</td>
</tr>
</tbody>
</table>

</div>

</div>

<div class="section">

### hsm-single-tenant

<div>

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr class="header">
<th>Algorithm</th>
<th>Description</th>
<th>Quantum-safe</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">google-symmetric-encryption</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">GOOGLE_SYMMETRIC_ENCRYPTION</code></span></td>
<td><p>256-bit Advanced Encryption Standard (AES-256) keys in Galois Counter Mode (GCM), padded with Cloud KMS-internal metadata.</p></td>
<td>Yes</td>
</tr>
</tbody>
</table>

</div>

</div>

<div class="section">

### external

<div>

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr class="header">
<th>Algorithm</th>
<th>Description</th>
<th>Quantum-safe</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">external-symmetric-encryption</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">EXTERNAL_SYMMETRIC_ENCRYPTION</code></span></td>
<td><p>256-bit Advanced Encryption Standard (AES-256) keys in Galois Counter Mode (GCM).</p></td>
<td>Yes</td>
</tr>
</tbody>
</table>

</div>

</div>

<div class="section">

### external-vpc

<div>

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr class="header">
<th>Algorithm</th>
<th>Description</th>
<th>Quantum-safe</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">external-symmetric-encryption</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">EXTERNAL_SYMMETRIC_ENCRYPTION</code></span></td>
<td><p>256-bit Advanced Encryption Standard (AES-256) keys in Galois Counter Mode (GCM).</p></td>
<td>Yes</td>
</tr>
</tbody>
</table>

</div>

</div>

### Raw symmetric encryption algorithms

Raw symmetric encryption algorithms let you perform symmetric encryption and decryption without using Cloud KMS-internal metadata. You can use raw symmetric encryption algorithms with imported keys to encrypt data locally to be decrypted within Google Cloud or to encrypt data in Google Cloud to be decrypted locally.

You can use the algorithms in this table with the following protection levels:

- <span style="white-space: nowrap;">`software`</span>
- <span style="white-space: nowrap;">`hsm`</span>
- <span style="white-space: nowrap;">`hsm-single-tenant`</span>

<div class="section">

### Any

<div>

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr class="header">
<th>Algorithm</th>
<th>Description</th>
<th>Quantum-safe</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">aes-128-cbc</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">AES_128_CBC</code></span></td>
<td><p>128-bit Advanced Encryption Standard (AES-128) keys in Cipher Block Chaining (CBC) mode with no authentication.</p>
<strong>Requires expert role:</strong> Cloud KMS Expert Raw AES-CBC Key Manager (<span style="white-space: nowrap;"><code translate="no" dir="ltr">roles/cloudkms.expertRawAesCbc</code></span>)</td>
<td>Yes</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">aes-128-ctr</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">AES_128_CTR</code></span></td>
<td><p>128-bit Advanced Encryption Standard (AES-128) keys in Counter (CTR) mode with no authentication.</p>
<strong>Requires expert role:</strong> Cloud KMS Expert Raw AES-CTR Key Manager (<span style="white-space: nowrap;"><code translate="no" dir="ltr">roles/cloudkms.expertRawAesCtr</code></span>)</td>
<td>Yes</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">aes-128-gcm</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">AES_128_GCM</code></span></td>
<td><p>128-bit Advanced Encryption Standard (AES-128) keys in Galois Counter Mode (GCM) with additional authenticated data (AAD)</p></td>
<td>Yes</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">aes-256-cbc</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">AES_256_CBC</code></span></td>
<td><p>256-bit Advanced Encryption Standard (AES-256) keys in Cipher Block Chaining (CBC) mode with no authentication.</p>
<strong>Requires expert role:</strong> Cloud KMS Expert Raw AES-CBC Key Manager (<span style="white-space: nowrap;"><code translate="no" dir="ltr">roles/cloudkms.expertRawAesCbc</code></span>)</td>
<td>Yes</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">aes-256-ctr</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">AES_256_CTR</code></span></td>
<td><p>256-bit Advanced Encryption Standard (AES-256) keys in Counter (CTR) mode with no authentication.</p>
<strong>Requires expert role:</strong> Cloud KMS Expert Raw AES-CTR Key Manager (<span style="white-space: nowrap;"><code translate="no" dir="ltr">roles/cloudkms.expertRawAesCtr</code></span>)</td>
<td>Yes</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">aes-256-gcm</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">AES_256_GCM</code></span></td>
<td><p>256-bit Advanced Encryption Standard (AES-256) keys in Galois Counter Mode (GCM) with additional authenticated data (AAD)</p></td>
<td>Yes</td>
</tr>
</tbody>
</table>

</div>

</div>

<div class="section">

### software

<div>

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr class="header">
<th>Algorithm</th>
<th>Description</th>
<th>Quantum-safe</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">aes-128-cbc</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">AES_128_CBC</code></span></td>
<td><p>128-bit Advanced Encryption Standard (AES-128) keys in Cipher Block Chaining (CBC) mode with no authentication.</p>
<strong>Requires expert role:</strong> Cloud KMS Expert Raw AES-CBC Key Manager (<span style="white-space: nowrap;"><code translate="no" dir="ltr">roles/cloudkms.expertRawAesCbc</code></span>)</td>
<td>Yes</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">aes-128-ctr</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">AES_128_CTR</code></span></td>
<td><p>128-bit Advanced Encryption Standard (AES-128) keys in Counter (CTR) mode with no authentication.</p>
<strong>Requires expert role:</strong> Cloud KMS Expert Raw AES-CTR Key Manager (<span style="white-space: nowrap;"><code translate="no" dir="ltr">roles/cloudkms.expertRawAesCtr</code></span>)</td>
<td>Yes</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">aes-128-gcm</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">AES_128_GCM</code></span></td>
<td><p>128-bit Advanced Encryption Standard (AES-128) keys in Galois Counter Mode (GCM) with additional authenticated data (AAD)</p></td>
<td>Yes</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">aes-256-cbc</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">AES_256_CBC</code></span></td>
<td><p>256-bit Advanced Encryption Standard (AES-256) keys in Cipher Block Chaining (CBC) mode with no authentication.</p>
<strong>Requires expert role:</strong> Cloud KMS Expert Raw AES-CBC Key Manager (<span style="white-space: nowrap;"><code translate="no" dir="ltr">roles/cloudkms.expertRawAesCbc</code></span>)</td>
<td>Yes</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">aes-256-ctr</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">AES_256_CTR</code></span></td>
<td><p>256-bit Advanced Encryption Standard (AES-256) keys in Counter (CTR) mode with no authentication.</p>
<strong>Requires expert role:</strong> Cloud KMS Expert Raw AES-CTR Key Manager (<span style="white-space: nowrap;"><code translate="no" dir="ltr">roles/cloudkms.expertRawAesCtr</code></span>)</td>
<td>Yes</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">aes-256-gcm</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">AES_256_GCM</code></span></td>
<td><p>256-bit Advanced Encryption Standard (AES-256) keys in Galois Counter Mode (GCM) with additional authenticated data (AAD)</p></td>
<td>Yes</td>
</tr>
</tbody>
</table>

</div>

</div>

<div class="section">

### hsm

<div>

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr class="header">
<th>Algorithm</th>
<th>Description</th>
<th>Quantum-safe</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">aes-128-cbc</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">AES_128_CBC</code></span></td>
<td><p>128-bit Advanced Encryption Standard (AES-128) keys in Cipher Block Chaining (CBC) mode with no authentication.</p>
<strong>Requires expert role:</strong> Cloud KMS Expert Raw AES-CBC Key Manager (<span style="white-space: nowrap;"><code translate="no" dir="ltr">roles/cloudkms.expertRawAesCbc</code></span>)</td>
<td>Yes</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">aes-128-ctr</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">AES_128_CTR</code></span></td>
<td><p>128-bit Advanced Encryption Standard (AES-128) keys in Counter (CTR) mode with no authentication.</p>
<strong>Requires expert role:</strong> Cloud KMS Expert Raw AES-CTR Key Manager (<span style="white-space: nowrap;"><code translate="no" dir="ltr">roles/cloudkms.expertRawAesCtr</code></span>)</td>
<td>Yes</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">aes-128-gcm</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">AES_128_GCM</code></span></td>
<td><p>128-bit Advanced Encryption Standard (AES-128) keys in Galois Counter Mode (GCM) with additional authenticated data (AAD)</p></td>
<td>Yes</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">aes-256-cbc</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">AES_256_CBC</code></span></td>
<td><p>256-bit Advanced Encryption Standard (AES-256) keys in Cipher Block Chaining (CBC) mode with no authentication.</p>
<strong>Requires expert role:</strong> Cloud KMS Expert Raw AES-CBC Key Manager (<span style="white-space: nowrap;"><code translate="no" dir="ltr">roles/cloudkms.expertRawAesCbc</code></span>)</td>
<td>Yes</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">aes-256-ctr</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">AES_256_CTR</code></span></td>
<td><p>256-bit Advanced Encryption Standard (AES-256) keys in Counter (CTR) mode with no authentication.</p>
<strong>Requires expert role:</strong> Cloud KMS Expert Raw AES-CTR Key Manager (<span style="white-space: nowrap;"><code translate="no" dir="ltr">roles/cloudkms.expertRawAesCtr</code></span>)</td>
<td>Yes</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">aes-256-gcm</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">AES_256_GCM</code></span></td>
<td><p>256-bit Advanced Encryption Standard (AES-256) keys in Galois Counter Mode (GCM) with additional authenticated data (AAD)</p></td>
<td>Yes</td>
</tr>
</tbody>
</table>

</div>

</div>

<div class="section">

### hsm-single-tenant

<div>

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr class="header">
<th>Algorithm</th>
<th>Description</th>
<th>Quantum-safe</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">aes-128-cbc</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">AES_128_CBC</code></span></td>
<td><p>128-bit Advanced Encryption Standard (AES-128) keys in Cipher Block Chaining (CBC) mode with no authentication.</p>
<strong>Requires expert role:</strong> Cloud KMS Expert Raw AES-CBC Key Manager (<span style="white-space: nowrap;"><code translate="no" dir="ltr">roles/cloudkms.expertRawAesCbc</code></span>)</td>
<td>Yes</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">aes-128-ctr</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">AES_128_CTR</code></span></td>
<td><p>128-bit Advanced Encryption Standard (AES-128) keys in Counter (CTR) mode with no authentication.</p>
<strong>Requires expert role:</strong> Cloud KMS Expert Raw AES-CTR Key Manager (<span style="white-space: nowrap;"><code translate="no" dir="ltr">roles/cloudkms.expertRawAesCtr</code></span>)</td>
<td>Yes</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">aes-128-gcm</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">AES_128_GCM</code></span></td>
<td><p>128-bit Advanced Encryption Standard (AES-128) keys in Galois Counter Mode (GCM) with additional authenticated data (AAD)</p></td>
<td>Yes</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">aes-256-cbc</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">AES_256_CBC</code></span></td>
<td><p>256-bit Advanced Encryption Standard (AES-256) keys in Cipher Block Chaining (CBC) mode with no authentication.</p>
<strong>Requires expert role:</strong> Cloud KMS Expert Raw AES-CBC Key Manager (<span style="white-space: nowrap;"><code translate="no" dir="ltr">roles/cloudkms.expertRawAesCbc</code></span>)</td>
<td>Yes</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">aes-256-ctr</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">AES_256_CTR</code></span></td>
<td><p>256-bit Advanced Encryption Standard (AES-256) keys in Counter (CTR) mode with no authentication.</p>
<strong>Requires expert role:</strong> Cloud KMS Expert Raw AES-CTR Key Manager (<span style="white-space: nowrap;"><code translate="no" dir="ltr">roles/cloudkms.expertRawAesCtr</code></span>)</td>
<td>Yes</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">aes-256-gcm</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">AES_256_GCM</code></span></td>
<td><p>256-bit Advanced Encryption Standard (AES-256) keys in Galois Counter Mode (GCM) with additional authenticated data (AAD)</p></td>
<td>Yes</td>
</tr>
</tbody>
</table>

</div>

</div>

<div class="section">

### external

<div>

| Algorithm | Description | Quantum-safe |
|-----------|-------------|--------------|

</div>

</div>

<div class="section">

### external-vpc

<div>

| Algorithm | Description | Quantum-safe |
|-----------|-------------|--------------|

</div>

</div>

## Asymmetric signing algorithms

The `ASYMMETRIC_SIGN` key purpose enables asymmetric signing. These algorithms fall into several categories: elliptic curve, RSA, and post-quantum.

Asymmetric signing algorithms that use elliptic curves and RSA are susceptible to attacks by future quantum computers. For long-term non-repudiation of your signatures, choose a [post-quantum asymmetric signing algorithm](#pqc_signing_algorithms) instead.

### Elliptic curve signing algorithms

The name of the elliptic curve signing algorithm indicates the elliptic curve and the digest algorithm that it uses in the following format:

<div>

</div>

``` devsite-click-to-copy
EC_SIGN_ELLIPTIC_CURVE_DIGEST_ALGORITHM
```

The following table lists elliptic curve algorithms.

Algorithm support varies by protection level.

<div class="section">

### Any

<div>

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr class="header">
<th>Algorithm</th>
<th>Description</th>
<th>Quantum-safe</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">ec-sign-ed25519</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">EC_SIGN_ED25519</code></span></td>
<td><p>EdDSA on the Curve25519 in <a href="https://datatracker.ietf.org/doc/html/rfc8032#section-4">PureEdDSA mode</a>, which takes raw data as input instead of hashed data</p></td>
<td>No</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">ec-sign-p256-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">EC_SIGN_P256_SHA256</code></span></td>
<td><p><strong>Recommended</strong><br />
ECDSA on the P-256 Curve with a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">ec-sign-p384-sha384</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">EC_SIGN_P384_SHA384</code></span></td>
<td><p>ECDSA on the P-384 Curve with a SHA-384 digest</p></td>
<td>No</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">ec-sign-secp256k1-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">EC_SIGN_SECP256K1_SHA256</code></span></td>
<td><p>ECDSA on the Secp256k1 Curve with a SHA-256 digest</p></td>
<td>No</td>
</tr>
</tbody>
</table>

</div>

</div>

<div class="section">

### software

<div>

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr class="header">
<th>Algorithm</th>
<th>Description</th>
<th>Quantum-safe</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">ec-sign-ed25519</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">EC_SIGN_ED25519</code></span></td>
<td><p>EdDSA on the Curve25519 in <a href="https://datatracker.ietf.org/doc/html/rfc8032#section-4">PureEdDSA mode</a>, which takes raw data as input instead of hashed data</p></td>
<td>No</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">ec-sign-p256-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">EC_SIGN_P256_SHA256</code></span></td>
<td><p><strong>Recommended</strong><br />
ECDSA on the P-256 Curve with a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">ec-sign-p384-sha384</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">EC_SIGN_P384_SHA384</code></span></td>
<td><p>ECDSA on the P-384 Curve with a SHA-384 digest</p></td>
<td>No</td>
</tr>
</tbody>
</table>

</div>

</div>

<div class="section">

### hsm

<div>

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr class="header">
<th>Algorithm</th>
<th>Description</th>
<th>Quantum-safe</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">ec-sign-p256-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">EC_SIGN_P256_SHA256</code></span></td>
<td><p><strong>Recommended</strong><br />
ECDSA on the P-256 Curve with a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">ec-sign-p384-sha384</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">EC_SIGN_P384_SHA384</code></span></td>
<td><p>ECDSA on the P-384 Curve with a SHA-384 digest</p></td>
<td>No</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">ec-sign-secp256k1-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">EC_SIGN_SECP256K1_SHA256</code></span></td>
<td><p>ECDSA on the Secp256k1 Curve with a SHA-256 digest</p></td>
<td>No</td>
</tr>
</tbody>
</table>

</div>

</div>

<div class="section">

### hsm-single-tenant

<div>

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr class="header">
<th>Algorithm</th>
<th>Description</th>
<th>Quantum-safe</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">ec-sign-p256-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">EC_SIGN_P256_SHA256</code></span></td>
<td><p><strong>Recommended</strong><br />
ECDSA on the P-256 Curve with a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">ec-sign-p384-sha384</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">EC_SIGN_P384_SHA384</code></span></td>
<td><p>ECDSA on the P-384 Curve with a SHA-384 digest</p></td>
<td>No</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">ec-sign-secp256k1-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">EC_SIGN_SECP256K1_SHA256</code></span></td>
<td><p>ECDSA on the Secp256k1 Curve with a SHA-256 digest</p></td>
<td>No</td>
</tr>
</tbody>
</table>

</div>

</div>

<div class="section">

### external

<div>

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr class="header">
<th>Algorithm</th>
<th>Description</th>
<th>Quantum-safe</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">ec-sign-p256-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">EC_SIGN_P256_SHA256</code></span></td>
<td><p><strong>Recommended</strong><br />
ECDSA on the P-256 Curve with a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">ec-sign-p384-sha384</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">EC_SIGN_P384_SHA384</code></span></td>
<td><p>ECDSA on the P-384 Curve with a SHA-384 digest</p></td>
<td>No</td>
</tr>
</tbody>
</table>

</div>

</div>

<div class="section">

### external-vpc

<div>

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr class="header">
<th>Algorithm</th>
<th>Description</th>
<th>Quantum-safe</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">ec-sign-p256-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">EC_SIGN_P256_SHA256</code></span></td>
<td><p><strong>Recommended</strong><br />
ECDSA on the P-256 Curve with a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">ec-sign-p384-sha384</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">EC_SIGN_P384_SHA384</code></span></td>
<td><p>ECDSA on the P-384 Curve with a SHA-384 digest</p></td>
<td>No</td>
</tr>
</tbody>
</table>

</div>

</div>

**Note:** `secp256k1` curves generate signatures in the "normalized" form only (also known as the "lower-S form"). For additional cryptographic details about these signatures, see [DER encoding](https://en.bitcoin.it/wiki/BIP_0062#DER_encoding).

### RSA signing algorithms

For most RSA signing algorithms, the name of the RSA signing algorithm indicates the padding algorithm, the modulus bit length, and the digest algorithm that it uses in the following format:

<div>

</div>

``` devsite-click-to-copy
RSA_SIGN_PADDING_ALGORITHM_MODULUS_BIT_LENGTH_DIGEST_ALGORITHM
```

Some RSA signing algorithms omit the digest algorithm. These "raw" algorithms are a variant of PKCS \#1 signing that omits encoding into a `DigestInfo`. Instead, raw signing algorithms do the following:

- A digest is computed over the message that will be signed.
- PKCS \#1 padding is applied to the digest directly.
- A signature of the padded digest is computed, using the RSA private key.

For raw RSA signing algorithms, the name of the RSA signing algorithm indicates the padding algorithm and the modulus bit length that it uses in the following format:

<div>

</div>

``` devsite-click-to-copy
RSA_SIGN_RAW_PADDING_ALGORITHM_MODULUS_BIT_LENGTH
```

The following table lists RSA signing algorithms.

Algorithm support varies by protection level.

<div class="section">

### Any

<div>

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr class="header">
<th>Algorithm</th>
<th>Description</th>
<th>Quantum-safe</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-pss-2048-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_PSS_2048_SHA256</code></span></td>
<td><p>RSASSA-PSS 2048-bit key with a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-pss-3072-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_PSS_3072_SHA256</code></span></td>
<td><p><strong>Recommended</strong><br />
RSASSA-PSS 3072-bit key with a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-pss-4096-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_PSS_4096_SHA256</code></span></td>
<td><p>RSASSA-PSS 4096-bit key with a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-pss-4096-sha512</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_PSS_4096_SHA512</code></span></td>
<td><p>RSASSA-PSS 4096-bit key with a SHA-512 digest</p></td>
<td>No</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-pkcs1-2048-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_PKCS1_2048_SHA256</code></span></td>
<td><p>RSASSA-PKCS1 v1.5 with a 2048-bit key and a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-pkcs1-3072-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_PKCS1_3072_SHA256</code></span></td>
<td><p>RSASSA-PKCS1 v1.5 with a 3072-bit key and a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-pkcs1-4096-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_PKCS1_4096_SHA256</code></span></td>
<td><p>RSASSA-PKCS1 v1.5 with a 4096-bit key and a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-pkcs1-4096-sha512</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_PKCS1_4096_SHA512</code></span></td>
<td><p>RSASSA-PKCS1 v1.5 with a 4096-bit key and a SHA-512 digest</p></td>
<td>No</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-raw-pkcs1-2048</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_RAW_PKCS1_2048</code></span></td>
<td><p>RSASSA-PKCS1 v1.5 signing without encoding, with a 2048-bit key</p></td>
<td>No</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-raw-pkcs1-3072</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_RAW_PKCS1_3072</code></span></td>
<td><p>RSASSA-PKCS1 v1.5 signing without encoding, with a 3072-bit key</p></td>
<td>No</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-raw-pkcs1-4096</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_RAW_PKCS1_4096</code></span></td>
<td><p>RSASSA-PKCS1 v1.5 signing without encoding, with a 4096-bit key</p></td>
<td>No</td>
</tr>
</tbody>
</table>

</div>

</div>

<div class="section">

### software

<div>

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr class="header">
<th>Algorithm</th>
<th>Description</th>
<th>Quantum-safe</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-pss-2048-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_PSS_2048_SHA256</code></span></td>
<td><p>RSASSA-PSS 2048-bit key with a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-pss-3072-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_PSS_3072_SHA256</code></span></td>
<td><p><strong>Recommended</strong><br />
RSASSA-PSS 3072-bit key with a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-pss-4096-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_PSS_4096_SHA256</code></span></td>
<td><p>RSASSA-PSS 4096-bit key with a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-pss-4096-sha512</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_PSS_4096_SHA512</code></span></td>
<td><p>RSASSA-PSS 4096-bit key with a SHA-512 digest</p></td>
<td>No</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-pkcs1-2048-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_PKCS1_2048_SHA256</code></span></td>
<td><p>RSASSA-PKCS1 v1.5 with a 2048-bit key and a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-pkcs1-3072-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_PKCS1_3072_SHA256</code></span></td>
<td><p>RSASSA-PKCS1 v1.5 with a 3072-bit key and a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-pkcs1-4096-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_PKCS1_4096_SHA256</code></span></td>
<td><p>RSASSA-PKCS1 v1.5 with a 4096-bit key and a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-pkcs1-4096-sha512</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_PKCS1_4096_SHA512</code></span></td>
<td><p>RSASSA-PKCS1 v1.5 with a 4096-bit key and a SHA-512 digest</p></td>
<td>No</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-raw-pkcs1-2048</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_RAW_PKCS1_2048</code></span></td>
<td><p>RSASSA-PKCS1 v1.5 signing without encoding, with a 2048-bit key</p></td>
<td>No</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-raw-pkcs1-3072</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_RAW_PKCS1_3072</code></span></td>
<td><p>RSASSA-PKCS1 v1.5 signing without encoding, with a 3072-bit key</p></td>
<td>No</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-raw-pkcs1-4096</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_RAW_PKCS1_4096</code></span></td>
<td><p>RSASSA-PKCS1 v1.5 signing without encoding, with a 4096-bit key</p></td>
<td>No</td>
</tr>
</tbody>
</table>

</div>

</div>

<div class="section">

### hsm

<div>

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr class="header">
<th>Algorithm</th>
<th>Description</th>
<th>Quantum-safe</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-pss-2048-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_PSS_2048_SHA256</code></span></td>
<td><p>RSASSA-PSS 2048-bit key with a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-pss-3072-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_PSS_3072_SHA256</code></span></td>
<td><p><strong>Recommended</strong><br />
RSASSA-PSS 3072-bit key with a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-pss-4096-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_PSS_4096_SHA256</code></span></td>
<td><p>RSASSA-PSS 4096-bit key with a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-pss-4096-sha512</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_PSS_4096_SHA512</code></span></td>
<td><p>RSASSA-PSS 4096-bit key with a SHA-512 digest</p></td>
<td>No</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-pkcs1-2048-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_PKCS1_2048_SHA256</code></span></td>
<td><p>RSASSA-PKCS1 v1.5 with a 2048-bit key and a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-pkcs1-3072-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_PKCS1_3072_SHA256</code></span></td>
<td><p>RSASSA-PKCS1 v1.5 with a 3072-bit key and a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-pkcs1-4096-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_PKCS1_4096_SHA256</code></span></td>
<td><p>RSASSA-PKCS1 v1.5 with a 4096-bit key and a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-pkcs1-4096-sha512</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_PKCS1_4096_SHA512</code></span></td>
<td><p>RSASSA-PKCS1 v1.5 with a 4096-bit key and a SHA-512 digest</p></td>
<td>No</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-raw-pkcs1-2048</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_RAW_PKCS1_2048</code></span></td>
<td><p>RSASSA-PKCS1 v1.5 signing without encoding, with a 2048-bit key</p></td>
<td>No</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-raw-pkcs1-3072</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_RAW_PKCS1_3072</code></span></td>
<td><p>RSASSA-PKCS1 v1.5 signing without encoding, with a 3072-bit key</p></td>
<td>No</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-raw-pkcs1-4096</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_RAW_PKCS1_4096</code></span></td>
<td><p>RSASSA-PKCS1 v1.5 signing without encoding, with a 4096-bit key</p></td>
<td>No</td>
</tr>
</tbody>
</table>

</div>

</div>

<div class="section">

### hsm-single-tenant

<div>

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr class="header">
<th>Algorithm</th>
<th>Description</th>
<th>Quantum-safe</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-pss-2048-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_PSS_2048_SHA256</code></span></td>
<td><p>RSASSA-PSS 2048-bit key with a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-pss-3072-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_PSS_3072_SHA256</code></span></td>
<td><p><strong>Recommended</strong><br />
RSASSA-PSS 3072-bit key with a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-pss-4096-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_PSS_4096_SHA256</code></span></td>
<td><p>RSASSA-PSS 4096-bit key with a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-pss-4096-sha512</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_PSS_4096_SHA512</code></span></td>
<td><p>RSASSA-PSS 4096-bit key with a SHA-512 digest</p></td>
<td>No</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-pkcs1-2048-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_PKCS1_2048_SHA256</code></span></td>
<td><p>RSASSA-PKCS1 v1.5 with a 2048-bit key and a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-pkcs1-3072-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_PKCS1_3072_SHA256</code></span></td>
<td><p>RSASSA-PKCS1 v1.5 with a 3072-bit key and a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-pkcs1-4096-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_PKCS1_4096_SHA256</code></span></td>
<td><p>RSASSA-PKCS1 v1.5 with a 4096-bit key and a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-pkcs1-4096-sha512</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_PKCS1_4096_SHA512</code></span></td>
<td><p>RSASSA-PKCS1 v1.5 with a 4096-bit key and a SHA-512 digest</p></td>
<td>No</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-raw-pkcs1-2048</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_RAW_PKCS1_2048</code></span></td>
<td><p>RSASSA-PKCS1 v1.5 signing without encoding, with a 2048-bit key</p></td>
<td>No</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-raw-pkcs1-3072</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_RAW_PKCS1_3072</code></span></td>
<td><p>RSASSA-PKCS1 v1.5 signing without encoding, with a 3072-bit key</p></td>
<td>No</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-raw-pkcs1-4096</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_RAW_PKCS1_4096</code></span></td>
<td><p>RSASSA-PKCS1 v1.5 signing without encoding, with a 4096-bit key</p></td>
<td>No</td>
</tr>
</tbody>
</table>

</div>

</div>

<div class="section">

### external

<div>

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr class="header">
<th>Algorithm</th>
<th>Description</th>
<th>Quantum-safe</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-pss-2048-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_PSS_2048_SHA256</code></span></td>
<td><p>RSASSA-PSS 2048-bit key with a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-pss-3072-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_PSS_3072_SHA256</code></span></td>
<td><p><strong>Recommended</strong><br />
RSASSA-PSS 3072-bit key with a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-pss-4096-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_PSS_4096_SHA256</code></span></td>
<td><p>RSASSA-PSS 4096-bit key with a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-pss-4096-sha512</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_PSS_4096_SHA512</code></span></td>
<td><p>RSASSA-PSS 4096-bit key with a SHA-512 digest</p></td>
<td>No</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-pkcs1-2048-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_PKCS1_2048_SHA256</code></span></td>
<td><p>RSASSA-PKCS1 v1.5 with a 2048-bit key and a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-pkcs1-3072-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_PKCS1_3072_SHA256</code></span></td>
<td><p>RSASSA-PKCS1 v1.5 with a 3072-bit key and a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-pkcs1-4096-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_PKCS1_4096_SHA256</code></span></td>
<td><p>RSASSA-PKCS1 v1.5 with a 4096-bit key and a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-pkcs1-4096-sha512</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_PKCS1_4096_SHA512</code></span></td>
<td><p>RSASSA-PKCS1 v1.5 with a 4096-bit key and a SHA-512 digest</p></td>
<td>No</td>
</tr>
</tbody>
</table>

</div>

</div>

<div class="section">

### external-vpc

<div>

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr class="header">
<th>Algorithm</th>
<th>Description</th>
<th>Quantum-safe</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-pss-2048-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_PSS_2048_SHA256</code></span></td>
<td><p>RSASSA-PSS 2048-bit key with a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-pss-3072-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_PSS_3072_SHA256</code></span></td>
<td><p><strong>Recommended</strong><br />
RSASSA-PSS 3072-bit key with a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-pss-4096-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_PSS_4096_SHA256</code></span></td>
<td><p>RSASSA-PSS 4096-bit key with a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-pss-4096-sha512</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_PSS_4096_SHA512</code></span></td>
<td><p>RSASSA-PSS 4096-bit key with a SHA-512 digest</p></td>
<td>No</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-pkcs1-2048-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_PKCS1_2048_SHA256</code></span></td>
<td><p>RSASSA-PKCS1 v1.5 with a 2048-bit key and a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-pkcs1-3072-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_PKCS1_3072_SHA256</code></span></td>
<td><p>RSASSA-PKCS1 v1.5 with a 3072-bit key and a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-pkcs1-4096-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_PKCS1_4096_SHA256</code></span></td>
<td><p>RSASSA-PKCS1 v1.5 with a 4096-bit key and a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-sign-pkcs1-4096-sha512</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_SIGN_PKCS1_4096_SHA512</code></span></td>
<td><p>RSASSA-PKCS1 v1.5 with a 4096-bit key and a SHA-512 digest</p></td>
<td>No</td>
</tr>
</tbody>
</table>

</div>

</div>

For Probabilistic Signature Scheme (PSS), the salt length used is equal to the length of the digest algorithm and the digest algorithm is also used for the mask generation function (MGF1). For example, `RSA_SIGN_PSS_2048_SHA256` uses PSS with a salt length of 256 bits and takes a SHA-256 hash of the data to be signed, and Cloud KMS will internally use SHA-256 as the hash algorithm for MGF1 when computing the signature.

### PQC signing algorithms

Post-quantum cryptography (PQC) signing algorithm names start with the prefix `PQ_SIGN_`. The following table lists the PQC algorithms that Cloud KMS can use for keys with purpose `ASYMMETRIC_SIGN`. The pure algorithms take raw data as input, while the pre-hash and external-μ (external-mu) algorithms accept a hash value derived from the data.

You can use the algorithms in this table with the following protection levels:

- <span style="white-space: nowrap;">`software`</span>

<div class="section">

### Any

<div>

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr class="header">
<th>Algorithm</th>
<th>Description</th>
<th>Quantum-safe</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">pq-sign-ml-dsa-44</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">PQ_SIGN_ML_DSA_44</code></span></td>
<td><p>Pure module-lattice-based digital signature algorithm using the ML-DSA-44 parameter set (FIPS 204), where the dimensions of the matrix A are (4,4).</p></td>
<td>Yes</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">pq-sign-ml-dsa-44-external-mu</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">PQ_SIGN_ML_DSA_44_EXTERNAL_MU</code></span></td>
<td><p>External-μ module-lattice-based digital signature algorithm using the ML-DSA-44 parameter set (FIPS 204), where the dimensions of the matrix A are (4,4).</p></td>
<td>Yes</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">pq-sign-ml-dsa-65</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">PQ_SIGN_ML_DSA_65</code></span></td>
<td><p>Pure module-lattice-based digital signature algorithm using the ML-DSA-65 parameter set (FIPS 204), where the dimensions of the matrix A are (6,5).</p></td>
<td>Yes</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">pq-sign-ml-dsa-65-external-mu</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">PQ_SIGN_ML_DSA_65_EXTERNAL_MU</code></span></td>
<td><p>External-μ module-lattice-based digital signature algorithm using the ML-DSA-65 parameter set (FIPS 204), where the dimensions of the matrix A are (6,5).</p></td>
<td>Yes</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">pq-sign-ml-dsa-87</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">PQ_SIGN_ML_DSA_87</code></span></td>
<td><p>Pure module-lattice-based digital signature algorithm using the ML-DSA-87 parameter set (FIPS 204), where the dimensions of the matrix A are (8,7).</p></td>
<td>Yes</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">pq-sign-ml-dsa-87-external-mu</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">PQ_SIGN_ML_DSA_87_EXTERNAL_MU</code></span></td>
<td><p>External-μ module-lattice-based digital signature algorithm using the ML-DSA-87 parameter set (FIPS 204), where the dimensions of the matrix A are (8,7).</p></td>
<td>Yes</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">pq-sign-slh-dsa-sha2-128s</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">PQ_SIGN_SLH_DSA_SHA2_128S</code></span></td>
<td><p>Pure stateless hash-based digital signature algorithm.</p></td>
<td>Yes</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">pq-sign-hash-slh-dsa-sha2-128s-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">PQ_SIGN_HASH_SLH_DSA_SHA2_128S_SHA256</code></span></td>
<td><p>Pre-hash stateless hash-based digital signature algorithm.</p></td>
<td>Yes</td>
</tr>
</tbody>
</table>

</div>

</div>

<div class="section">

### software

<div>

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr class="header">
<th>Algorithm</th>
<th>Description</th>
<th>Quantum-safe</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">pq-sign-ml-dsa-44</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">PQ_SIGN_ML_DSA_44</code></span></td>
<td><p>Pure module-lattice-based digital signature algorithm using the ML-DSA-44 parameter set (FIPS 204), where the dimensions of the matrix A are (4,4).</p></td>
<td>Yes</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">pq-sign-ml-dsa-44-external-mu</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">PQ_SIGN_ML_DSA_44_EXTERNAL_MU</code></span></td>
<td><p>External-μ module-lattice-based digital signature algorithm using the ML-DSA-44 parameter set (FIPS 204), where the dimensions of the matrix A are (4,4).</p></td>
<td>Yes</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">pq-sign-ml-dsa-65</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">PQ_SIGN_ML_DSA_65</code></span></td>
<td><p>Pure module-lattice-based digital signature algorithm using the ML-DSA-65 parameter set (FIPS 204), where the dimensions of the matrix A are (6,5).</p></td>
<td>Yes</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">pq-sign-ml-dsa-65-external-mu</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">PQ_SIGN_ML_DSA_65_EXTERNAL_MU</code></span></td>
<td><p>External-μ module-lattice-based digital signature algorithm using the ML-DSA-65 parameter set (FIPS 204), where the dimensions of the matrix A are (6,5).</p></td>
<td>Yes</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">pq-sign-ml-dsa-87</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">PQ_SIGN_ML_DSA_87</code></span></td>
<td><p>Pure module-lattice-based digital signature algorithm using the ML-DSA-87 parameter set (FIPS 204), where the dimensions of the matrix A are (8,7).</p></td>
<td>Yes</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">pq-sign-ml-dsa-87-external-mu</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">PQ_SIGN_ML_DSA_87_EXTERNAL_MU</code></span></td>
<td><p>External-μ module-lattice-based digital signature algorithm using the ML-DSA-87 parameter set (FIPS 204), where the dimensions of the matrix A are (8,7).</p></td>
<td>Yes</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">pq-sign-slh-dsa-sha2-128s</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">PQ_SIGN_SLH_DSA_SHA2_128S</code></span></td>
<td><p>Pure stateless hash-based digital signature algorithm.</p></td>
<td>Yes</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">pq-sign-hash-slh-dsa-sha2-128s-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">PQ_SIGN_HASH_SLH_DSA_SHA2_128S_SHA256</code></span></td>
<td><p>Pre-hash stateless hash-based digital signature algorithm.</p></td>
<td>Yes</td>
</tr>
</tbody>
</table>

</div>

</div>

<div class="section">

### hsm

<div>

| Algorithm | Description | Quantum-safe |
|-----------|-------------|--------------|

</div>

</div>

<div class="section">

### hsm-single-tenant

<div>

| Algorithm | Description | Quantum-safe |
|-----------|-------------|--------------|

</div>

</div>

<div class="section">

### external

<div>

| Algorithm | Description | Quantum-safe |
|-----------|-------------|--------------|

</div>

</div>

<div class="section">

### external-vpc

<div>

| Algorithm | Description | Quantum-safe |
|-----------|-------------|--------------|

</div>

</div>

For more information about module lattice algorithms, see [FIPS 204: Module-Lattice-Based Digital Signature Standard](https://csrc.nist.gov/pubs/fips/204/final). For more information about stateless hash-based signatures, see [FIPS 205: Stateless Hash-Based Digital Signature Standard](https://csrc.nist.gov/pubs/fips/205/final).

**Note:** Use `external_mu` as the `[DIGEST_ALGORITHM]` for all external-μ ML-DSA variants.

## Asymmetric decryption algorithms

Asymmetric decryption algorithms in Cloud KMS are used with a private key to decrypt data that was encrypted outside of Cloud KMS using the corresponding public key. The name of the algorithm indicates the padding algorithm, the modulus bit length, and the digest algorithm that it uses for the mask generation function (MGF1) in the following format:

<div>

</div>

``` devsite-click-to-copy
RSA_DECRYPT_PADDING_ALGORITHM_MODULUS_BIT_LENGTH_DIGEST_ALGORITHM
```

RSA encryption algorithms are susceptible to quantum computing attacks, including "store now, decrypt later" (SNDL) attacks. In an SNDL attack, a bad actor intercepts a ciphertext that they can't decrypt, and then stores it intending to eventually decrypt it using quantum computing. If you're transmitting data that must remain confidential long term despite advances in quantum computing, choose a [key encapsulation algorithm](#key_encapsulation_algorithms) instead.

The following table lists the asymmetric decryption algorithms.

You can use the algorithms in this table with the following protection levels:

- <span style="white-space: nowrap;">`software`</span>
- <span style="white-space: nowrap;">`hsm`</span>
- <span style="white-space: nowrap;">`hsm-single-tenant`</span>

<div class="section">

### Any

<div>

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr class="header">
<th>Algorithm</th>
<th>Description</th>
<th>Quantum-safe</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-decrypt-oaep-2048-sha1</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_DECRYPT_OAEP_2048_SHA1</code></span></td>
<td><p>RSAES-OAEP 2048-bit key with a SHA-1 digest</p></td>
<td>No</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-decrypt-oaep-2048-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_DECRYPT_OAEP_2048_SHA256</code></span></td>
<td><p>RSAES-OAEP 2048-bit key with a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-decrypt-oaep-3072-sha1</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_DECRYPT_OAEP_3072_SHA1</code></span></td>
<td><p>RSAES-OAEP 3072-bit key with a SHA-1 digest</p></td>
<td>No</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-decrypt-oaep-3072-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_DECRYPT_OAEP_3072_SHA256</code></span></td>
<td><p><strong>Recommended</strong><br />
RSAES-OAEP 3072-bit key with a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-decrypt-oaep-4096-sha1</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_DECRYPT_OAEP_4096_SHA1</code></span></td>
<td><p>RSAES-OAEP 4096-bit key with a SHA-1 digest</p></td>
<td>No</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-decrypt-oaep-4096-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_DECRYPT_OAEP_4096_SHA256</code></span></td>
<td><p>RSAES-OAEP 4096-bit key with a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-decrypt-oaep-4096-sha512</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_DECRYPT_OAEP_4096_SHA512</code></span></td>
<td><p>RSAES-OAEP 4096-bit key with a SHA-512 digest</p></td>
<td>No</td>
</tr>
</tbody>
</table>

</div>

</div>

<div class="section">

### software

<div>

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr class="header">
<th>Algorithm</th>
<th>Description</th>
<th>Quantum-safe</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-decrypt-oaep-2048-sha1</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_DECRYPT_OAEP_2048_SHA1</code></span></td>
<td><p>RSAES-OAEP 2048-bit key with a SHA-1 digest</p></td>
<td>No</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-decrypt-oaep-2048-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_DECRYPT_OAEP_2048_SHA256</code></span></td>
<td><p>RSAES-OAEP 2048-bit key with a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-decrypt-oaep-3072-sha1</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_DECRYPT_OAEP_3072_SHA1</code></span></td>
<td><p>RSAES-OAEP 3072-bit key with a SHA-1 digest</p></td>
<td>No</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-decrypt-oaep-3072-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_DECRYPT_OAEP_3072_SHA256</code></span></td>
<td><p><strong>Recommended</strong><br />
RSAES-OAEP 3072-bit key with a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-decrypt-oaep-4096-sha1</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_DECRYPT_OAEP_4096_SHA1</code></span></td>
<td><p>RSAES-OAEP 4096-bit key with a SHA-1 digest</p></td>
<td>No</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-decrypt-oaep-4096-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_DECRYPT_OAEP_4096_SHA256</code></span></td>
<td><p>RSAES-OAEP 4096-bit key with a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-decrypt-oaep-4096-sha512</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_DECRYPT_OAEP_4096_SHA512</code></span></td>
<td><p>RSAES-OAEP 4096-bit key with a SHA-512 digest</p></td>
<td>No</td>
</tr>
</tbody>
</table>

</div>

</div>

<div class="section">

### hsm

<div>

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr class="header">
<th>Algorithm</th>
<th>Description</th>
<th>Quantum-safe</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-decrypt-oaep-2048-sha1</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_DECRYPT_OAEP_2048_SHA1</code></span></td>
<td><p>RSAES-OAEP 2048-bit key with a SHA-1 digest</p></td>
<td>No</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-decrypt-oaep-2048-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_DECRYPT_OAEP_2048_SHA256</code></span></td>
<td><p>RSAES-OAEP 2048-bit key with a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-decrypt-oaep-3072-sha1</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_DECRYPT_OAEP_3072_SHA1</code></span></td>
<td><p>RSAES-OAEP 3072-bit key with a SHA-1 digest</p></td>
<td>No</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-decrypt-oaep-3072-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_DECRYPT_OAEP_3072_SHA256</code></span></td>
<td><p><strong>Recommended</strong><br />
RSAES-OAEP 3072-bit key with a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-decrypt-oaep-4096-sha1</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_DECRYPT_OAEP_4096_SHA1</code></span></td>
<td><p>RSAES-OAEP 4096-bit key with a SHA-1 digest</p></td>
<td>No</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-decrypt-oaep-4096-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_DECRYPT_OAEP_4096_SHA256</code></span></td>
<td><p>RSAES-OAEP 4096-bit key with a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-decrypt-oaep-4096-sha512</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_DECRYPT_OAEP_4096_SHA512</code></span></td>
<td><p>RSAES-OAEP 4096-bit key with a SHA-512 digest</p></td>
<td>No</td>
</tr>
</tbody>
</table>

</div>

</div>

<div class="section">

### hsm-single-tenant

<div>

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr class="header">
<th>Algorithm</th>
<th>Description</th>
<th>Quantum-safe</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-decrypt-oaep-2048-sha1</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_DECRYPT_OAEP_2048_SHA1</code></span></td>
<td><p>RSAES-OAEP 2048-bit key with a SHA-1 digest</p></td>
<td>No</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-decrypt-oaep-2048-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_DECRYPT_OAEP_2048_SHA256</code></span></td>
<td><p>RSAES-OAEP 2048-bit key with a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-decrypt-oaep-3072-sha1</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_DECRYPT_OAEP_3072_SHA1</code></span></td>
<td><p>RSAES-OAEP 3072-bit key with a SHA-1 digest</p></td>
<td>No</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-decrypt-oaep-3072-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_DECRYPT_OAEP_3072_SHA256</code></span></td>
<td><p><strong>Recommended</strong><br />
RSAES-OAEP 3072-bit key with a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-decrypt-oaep-4096-sha1</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_DECRYPT_OAEP_4096_SHA1</code></span></td>
<td><p>RSAES-OAEP 4096-bit key with a SHA-1 digest</p></td>
<td>No</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-decrypt-oaep-4096-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_DECRYPT_OAEP_4096_SHA256</code></span></td>
<td><p>RSAES-OAEP 4096-bit key with a SHA-256 digest</p></td>
<td>No</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">rsa-decrypt-oaep-4096-sha512</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">RSA_DECRYPT_OAEP_4096_SHA512</code></span></td>
<td><p>RSAES-OAEP 4096-bit key with a SHA-512 digest</p></td>
<td>No</td>
</tr>
</tbody>
</table>

</div>

</div>

<div class="section">

### external

<div>

| Algorithm | Description | Quantum-safe |
|-----------|-------------|--------------|

</div>

</div>

<div class="section">

### external-vpc

<div>

| Algorithm | Description | Quantum-safe |
|-----------|-------------|--------------|

</div>

</div>

All of these algorithms use Optimal Asymmetric Encryption Padding (OAEP).

## Key encapsulation algorithms

The `KEY_ENCAPSULATION` key purpose is used to establish shared secrets using [key encapsulation mechanisms](/kms/docs/key-encapsulation-mechanisms).

The following table lists the key encapsulation algorithms.

You can use the algorithms in this table with the following protection levels:

- <span style="white-space: nowrap;">`software`</span>

<div class="section">

### Any

<div>

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr class="header">
<th>Algorithm</th>
<th>Description</th>
<th>Quantum-safe</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">kem-xwing</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">KEM_XWING</code></span></td>
<td><p><strong>Recommended</strong><br />
X-Wing hybrid KEM combining ML-KEM-768 with X25519</p></td>
<td>Yes</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">ml-kem-768</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">ML_KEM_768</code></span></td>
<td><p>Module-lattice-based key-encapsulation mechanism with ML-KEM-768 parameter set (FIPS 203)</p></td>
<td>Yes</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">ml-kem-1024</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">ML_KEM_1024</code></span></td>
<td><p>Module-lattice-based key-encapsulation mechanism with ML-KEM-1024 parameter set (FIPS 203)</p></td>
<td>Yes</td>
</tr>
</tbody>
</table>

</div>

</div>

<div class="section">

### software

<div>

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr class="header">
<th>Algorithm</th>
<th>Description</th>
<th>Quantum-safe</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">kem-xwing</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">KEM_XWING</code></span></td>
<td><p><strong>Recommended</strong><br />
X-Wing hybrid KEM combining ML-KEM-768 with X25519</p></td>
<td>Yes</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">ml-kem-768</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">ML_KEM_768</code></span></td>
<td><p>Module-lattice-based key-encapsulation mechanism with ML-KEM-768 parameter set (FIPS 203)</p></td>
<td>Yes</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">ml-kem-1024</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">ML_KEM_1024</code></span></td>
<td><p>Module-lattice-based key-encapsulation mechanism with ML-KEM-1024 parameter set (FIPS 203)</p></td>
<td>Yes</td>
</tr>
</tbody>
</table>

</div>

</div>

<div class="section">

### hsm

<div>

| Algorithm | Description | Quantum-safe |
|-----------|-------------|--------------|

</div>

</div>

<div class="section">

### hsm-single-tenant

<div>

| Algorithm | Description | Quantum-safe |
|-----------|-------------|--------------|

</div>

</div>

<div class="section">

### external

<div>

| Algorithm | Description | Quantum-safe |
|-----------|-------------|--------------|

</div>

</div>

<div class="section">

### external-vpc

<div>

| Algorithm | Description | Quantum-safe |
|-----------|-------------|--------------|

</div>

</div>

For more information about key encapsulation algorithms, see [FIPS 203: Module-Lattice-Based Key-Encapsulation Mechanism Standard](https://csrc.nist.gov/pubs/fips/203/final).

## MAC signing algorithms

The `MAC` key purpose is used for symmetric MAC signing. The name of the algorithm indicates the hash algorithm in the following format:

<div>

</div>

``` devsite-click-to-copy
HMAC_HASH_ALGORITHM
```

Most symmetric algorithms are generally considered quantum-safe. However, the `HMAC-SHA1` algorithm is not quantum-safe. If you need your symmetric signatures to remain trustworthy long-term despite advances in quantum computing, choose an HMAC key with a larger hash algorithm size.

The following table lists the HMAC algorithms.

You can use the algorithms in this table with the following protection levels:

- <span style="white-space: nowrap;">`software`</span>
- <span style="white-space: nowrap;">`hsm`</span>
- <span style="white-space: nowrap;">`hsm-single-tenant`</span>

<div class="section">

### Any

<div>

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr class="header">
<th>Algorithm</th>
<th>Description</th>
<th>Quantum-safe</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">hmac-sha1</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">HMAC_SHA1</code></span></td>
<td><p>HMAC with a SHA-1 digest</p></td>
<td>No</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">hmac-sha224</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">HMAC_SHA224</code></span></td>
<td><p>HMAC with a SHA-224 digest</p></td>
<td>Yes</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">hmac-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">HMAC_SHA256</code></span></td>
<td><p><strong>Recommended</strong><br />
HMAC with a SHA-256 digest</p></td>
<td>Yes</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">hmac-sha384</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">HMAC_SHA384</code></span></td>
<td><p>HMAC with a SHA-384 digest</p></td>
<td>Yes</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">hmac-sha512</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">HMAC_SHA512</code></span></td>
<td><p>HMAC with a SHA-512 digest</p></td>
<td>Yes</td>
</tr>
</tbody>
</table>

</div>

</div>

<div class="section">

### software

<div>

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr class="header">
<th>Algorithm</th>
<th>Description</th>
<th>Quantum-safe</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">hmac-sha1</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">HMAC_SHA1</code></span></td>
<td><p>HMAC with a SHA-1 digest</p></td>
<td>No</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">hmac-sha224</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">HMAC_SHA224</code></span></td>
<td><p>HMAC with a SHA-224 digest</p></td>
<td>Yes</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">hmac-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">HMAC_SHA256</code></span></td>
<td><p><strong>Recommended</strong><br />
HMAC with a SHA-256 digest</p></td>
<td>Yes</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">hmac-sha384</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">HMAC_SHA384</code></span></td>
<td><p>HMAC with a SHA-384 digest</p></td>
<td>Yes</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">hmac-sha512</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">HMAC_SHA512</code></span></td>
<td><p>HMAC with a SHA-512 digest</p></td>
<td>Yes</td>
</tr>
</tbody>
</table>

</div>

</div>

<div class="section">

### hsm

<div>

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr class="header">
<th>Algorithm</th>
<th>Description</th>
<th>Quantum-safe</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">hmac-sha1</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">HMAC_SHA1</code></span></td>
<td><p>HMAC with a SHA-1 digest</p></td>
<td>No</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">hmac-sha224</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">HMAC_SHA224</code></span></td>
<td><p>HMAC with a SHA-224 digest</p></td>
<td>Yes</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">hmac-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">HMAC_SHA256</code></span></td>
<td><p><strong>Recommended</strong><br />
HMAC with a SHA-256 digest</p></td>
<td>Yes</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">hmac-sha384</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">HMAC_SHA384</code></span></td>
<td><p>HMAC with a SHA-384 digest</p></td>
<td>Yes</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">hmac-sha512</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">HMAC_SHA512</code></span></td>
<td><p>HMAC with a SHA-512 digest</p></td>
<td>Yes</td>
</tr>
</tbody>
</table>

</div>

</div>

<div class="section">

### hsm-single-tenant

<div>

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr class="header">
<th>Algorithm</th>
<th>Description</th>
<th>Quantum-safe</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">hmac-sha1</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">HMAC_SHA1</code></span></td>
<td><p>HMAC with a SHA-1 digest</p></td>
<td>No</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">hmac-sha224</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">HMAC_SHA224</code></span></td>
<td><p>HMAC with a SHA-224 digest</p></td>
<td>Yes</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">hmac-sha256</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">HMAC_SHA256</code></span></td>
<td><p><strong>Recommended</strong><br />
HMAC with a SHA-256 digest</p></td>
<td>Yes</td>
</tr>
<tr class="even">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">hmac-sha384</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">HMAC_SHA384</code></span></td>
<td><p>HMAC with a SHA-384 digest</p></td>
<td>Yes</td>
</tr>
<tr class="odd">
<td>SDK: <span style="white-space: nowrap;"><code translate="no" dir="ltr">hmac-sha512</code></span><br />
REST: <span style="white-space: nowrap;"><code translate="no" dir="ltr">HMAC_SHA512</code></span></td>
<td><p>HMAC with a SHA-512 digest</p></td>
<td>Yes</td>
</tr>
</tbody>
</table>

</div>

</div>

<div class="section">

### external

<div>

| Algorithm | Description | Quantum-safe |
|-----------|-------------|--------------|

</div>

</div>

<div class="section">

### external-vpc

<div>

| Algorithm | Description | Quantum-safe |
|-----------|-------------|--------------|

</div>

</div>

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
