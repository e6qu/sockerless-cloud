# Cloud Key Management Service roles and permissions

<div class="devsite-article-body clearfix">

This page lists the IAM roles and permissions for Cloud Key Management Service. To search through all roles and permissions, see the [role and permission index](/iam/docs/roles-permissions).

## Cloud Key Management Service roles

<div results-count-container="">

</div>

<table class="fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="50%">Role</th>
<th>Permissions</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td class="role-description"><h4 id="cloudkms.admin" class="role-title add-link" data-text="Cloud KMS Admin " tabindex="-1">Cloud KMS Admin</h4>
<p>(<code translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<span class="role-description custom"> </span>
<p>Provides access to Cloud KMS resources, except for access to restricted resource types and cryptographic operations.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>CryptoKey</li>
</ul></td>
<td class="role-permissions"><p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudkms.autokeyConfigs.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudkms.autokeyConfigs.get</code></li>
<li><code translate="no" dir="ltr">cloudkms.autokeyConfigs.update</code></li>
</ul>
<p><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.create</code></p>
<p><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.delete</code></p>
<p><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.destroy</code></p>
<p><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.list</code></p>
<p><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.restore</code></p>
<p><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.trustedImportExport</code></p>
<p><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.update</code></p>
<p><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.useToDecryptViaDelegation</code></p>
<p><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.useToEncryptViaDelegation</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudkms.cryptoKeys.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudkms.cryptoKeys.create</code></li>
<li><code translate="no" dir="ltr">cloudkms.cryptoKeys.delete</code></li>
<li><code translate="no" dir="ltr">cloudkms.cryptoKeys.get</code></li>
<li><code translate="no" dir="ltr">cloudkms.cryptoKeys.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">cloudkms.cryptoKeys.list</code></li>
<li><code translate="no" dir="ltr">cloudkms.cryptoKeys.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">cloudkms.cryptoKeys.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudkms.ekmConfigs.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudkms.ekmConfigs.get</code></li>
<li><code translate="no" dir="ltr">cloudkms.ekmConfigs.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">cloudkms.ekmConfigs.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">cloudkms.ekmConfigs.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudkms.ekmConnections.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudkms.ekmConnections.create</code></li>
<li><code translate="no" dir="ltr">cloudkms.ekmConnections.get</code></li>
<li><code translate="no" dir="ltr">cloudkms.ekmConnections.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">cloudkms.ekmConnections.list</code></li>
<li><code translate="no" dir="ltr">cloudkms.ekmConnections.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">cloudkms.ekmConnections.update</code></li>
<li><code translate="no" dir="ltr">cloudkms.ekmConnections.use</code></li>
<li><code translate="no" dir="ltr">cloudkms.ekmConnections.verifyConnectivity</code></li>
</ul>
<p><code translate="no" dir="ltr">cloudkms.folders.showEffectiveAutokeyConfig</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudkms.importJobs.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudkms.importJobs.create</code></li>
<li><code translate="no" dir="ltr">cloudkms.importJobs.delete</code></li>
<li><code translate="no" dir="ltr">cloudkms.importJobs.get</code></li>
<li><code translate="no" dir="ltr">cloudkms.importJobs.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">cloudkms.importJobs.list</code></li>
<li><code translate="no" dir="ltr">cloudkms.importJobs.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">cloudkms.importJobs.useToImport</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudkms.kajPolicyConfigs.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudkms.kajPolicyConfigs.get</code></li>
<li><code translate="no" dir="ltr">cloudkms.kajPolicyConfigs.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudkms.keyHandles.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudkms.keyHandles.create</code></li>
<li><code translate="no" dir="ltr">cloudkms.keyHandles.get</code></li>
<li><code translate="no" dir="ltr">cloudkms.keyHandles.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudkms.keyRings.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudkms.keyRings.create</code></li>
<li><code translate="no" dir="ltr">cloudkms.keyRings.createTagBinding</code></li>
<li><code translate="no" dir="ltr">cloudkms.keyRings.delete</code></li>
<li><code translate="no" dir="ltr">cloudkms.keyRings.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">cloudkms.keyRings.get</code></li>
<li><code translate="no" dir="ltr">cloudkms.keyRings.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">cloudkms.keyRings.list</code></li>
<li><code translate="no" dir="ltr">cloudkms.keyRings.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">cloudkms.keyRings.listTagBindings</code></li>
<li><code translate="no" dir="ltr">cloudkms.keyRings.setIamPolicy</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudkms.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudkms.locations.generateRandomBytes</code></li>
<li><code translate="no" dir="ltr">cloudkms.locations.get</code></li>
<li><code translate="no" dir="ltr">cloudkms.locations.list</code></li>
<li><code translate="no" dir="ltr">cloudkms.locations.optOutKeyDeletionMsa</code></li>
</ul>
<p><code translate="no" dir="ltr">cloudkms.operations.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudkms.projects.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudkms.projects.showEffectiveAutokeyConfig</code></li>
<li><code translate="no" dir="ltr">cloudkms.projects.showEffectiveKajEnrollmentConfig</code></li>
<li><code translate="no" dir="ltr">cloudkms.projects.showEffectiveKajPolicyConfig</code></li>
</ul>
<p><code translate="no" dir="ltr">cloudkms.protectedResources.search</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudkms.retiredResources.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudkms.retiredResources.get</code></li>
<li><code translate="no" dir="ltr">cloudkms.retiredResources.list</code></li>
</ul>
<p><code translate="no" dir="ltr">cloudkms.singleTenantHsmInstanceProposals.delete</code></p>
<p><code translate="no" dir="ltr">cloudkms.singleTenantHsmInstanceProposals.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.singleTenantHsmInstanceProposals.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudkms.singleTenantHsmInstances.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudkms.singleTenantHsmInstances.create</code></li>
<li><code translate="no" dir="ltr">cloudkms.singleTenantHsmInstances.get</code></li>
<li><code translate="no" dir="ltr">cloudkms.singleTenantHsmInstances.list</code></li>
<li><code translate="no" dir="ltr">cloudkms.singleTenantHsmInstances.use</code></li>
</ul>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="cloudkms.cryptoKeyEncrypterDecrypter" class="role-title add-link" data-text="Cloud KMS CryptoKey Encrypter/Decrypter " tabindex="-1">Cloud KMS CryptoKey Encrypter/Decrypter</h4>
<p>(<code translate="no" dir="ltr">roles/cloudkms.cryptoKeyEncrypterDecrypter</code>)</p>
<span class="role-description custom"> </span>
<p>Provides ability to use Cloud KMS resources for encrypt and decrypt operations only.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>CryptoKey</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.useToDecrypt</code></p>
<p><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.useToEncrypt</code></p>
<p><code translate="no" dir="ltr">cloudkms.locations.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.locations.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="cloudkms.viewer" class="role-title add-link" data-text="Cloud KMS Viewer " tabindex="-1">Cloud KMS Viewer</h4>
<p>(<code translate="no" dir="ltr">roles/cloudkms.viewer</code>)</p>
<span class="role-description"> </span>
<p>Enables Get and List operations.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>CryptoKey</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudkms.autokeyConfigs.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.list</code></p>
<p><code translate="no" dir="ltr">cloudkms.cryptoKeys.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.cryptoKeys.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudkms.cryptoKeys.list</code></p>
<p><code translate="no" dir="ltr">cloudkms.ekmConfigs.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.ekmConfigs.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudkms.ekmConnections.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.ekmConnections.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudkms.ekmConnections.list</code></p>
<p><code translate="no" dir="ltr">cloudkms.ekmConnections.verifyConnectivity</code></p>
<p><code translate="no" dir="ltr">cloudkms.folders.showEffectiveAutokeyConfig</code></p>
<p><code translate="no" dir="ltr">cloudkms.importJobs.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.importJobs.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudkms.importJobs.list</code></p>
<p><code translate="no" dir="ltr">cloudkms.kajPolicyConfigs.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.keyHandles.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.keyHandles.list</code></p>
<p><code translate="no" dir="ltr">cloudkms.keyRings.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.keyRings.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudkms.keyRings.list</code></p>
<p><code translate="no" dir="ltr">cloudkms.keyRings.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">cloudkms.keyRings.listTagBindings</code></p>
<p><code translate="no" dir="ltr">cloudkms.locations.generateRandomBytes</code></p>
<p><code translate="no" dir="ltr">cloudkms.locations.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.locations.list</code></p>
<p><code translate="no" dir="ltr">cloudkms.operations.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudkms.projects.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudkms.projects.showEffectiveAutokeyConfig</code></li>
<li><code translate="no" dir="ltr">cloudkms.projects.showEffectiveKajEnrollmentConfig</code></li>
<li><code translate="no" dir="ltr">cloudkms.projects.showEffectiveKajPolicyConfig</code></li>
</ul>
<p><code translate="no" dir="ltr">cloudkms.protectableResources.list</code></p>
<p><code translate="no" dir="ltr">cloudkms.protectedResources.search</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudkms.retiredResources.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudkms.retiredResources.get</code></li>
<li><code translate="no" dir="ltr">cloudkms.retiredResources.list</code></li>
</ul>
<p><code translate="no" dir="ltr">cloudkms.singleTenantHsmInstanceProposals.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.singleTenantHsmInstanceProposals.list</code></p>
<p><code translate="no" dir="ltr">cloudkms.singleTenantHsmInstances.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.singleTenantHsmInstances.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="cloudkms.autokeyAdmin" class="role-title add-link" data-text="Cloud KMS Autokey Admin " tabindex="-1">Cloud KMS Autokey Admin</h4>
<p>(<code translate="no" dir="ltr">roles/cloudkms.autokeyAdmin</code>)</p>
<span class="role-description"> </span>
<p>Enables management of AutokeyConfig.</p></td>
<td class="role-permissions"><p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudkms.autokeyConfigs.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudkms.autokeyConfigs.get</code></li>
<li><code translate="no" dir="ltr">cloudkms.autokeyConfigs.update</code></li>
</ul>
<p><code translate="no" dir="ltr">cloudkms.folders.showEffectiveAutokeyConfig</code></p>
<p><code translate="no" dir="ltr">cloudkms.projects.showEffectiveAutokeyConfig</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="cloudkms.autokeyUser" class="role-title add-link" data-text="Cloud KMS Autokey User " tabindex="-1">Cloud KMS Autokey User</h4>
<p>(<code translate="no" dir="ltr">roles/cloudkms.autokeyUser</code>)</p>
<span class="role-description"> </span>
<p>Grants ability to use KeyHandle resources.</p></td>
<td class="role-permissions"><p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudkms.keyHandles.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudkms.keyHandles.create</code></li>
<li><code translate="no" dir="ltr">cloudkms.keyHandles.get</code></li>
<li><code translate="no" dir="ltr">cloudkms.keyHandles.list</code></li>
</ul>
<p><code translate="no" dir="ltr">cloudkms.operations.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.projects.showEffectiveAutokeyConfig</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="cloudkms.cryptoKeyDecrypter" class="role-title add-link" data-text="Cloud KMS CryptoKey Decrypter " tabindex="-1">Cloud KMS CryptoKey Decrypter</h4>
<p>(<code translate="no" dir="ltr">roles/cloudkms.cryptoKeyDecrypter</code>)</p>
<span class="role-description custom"> </span>
<p>Provides ability to use Cloud KMS resources for decrypt operations only.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>CryptoKey</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.useToDecrypt</code></p>
<p><code translate="no" dir="ltr">cloudkms.locations.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.locations.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="cloudkms.cryptoKeyDecrypterViaDelegation" class="role-title add-link" data-text="Cloud KMS CryptoKey Decrypter Via Delegation " tabindex="-1">Cloud KMS CryptoKey Decrypter Via Delegation</h4>
<p>(<code translate="no" dir="ltr">roles/cloudkms.cryptoKeyDecrypterViaDelegation</code>)</p>
<span class="role-description custom"> </span>
<p>Enables Decrypt operations via other Google Cloud services</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>CryptoKey</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.useToDecryptViaDelegation</code></p>
<p><code translate="no" dir="ltr">cloudkms.locations.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.locations.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="cloudkms.cryptoKeyEncrypter" class="role-title add-link" data-text="Cloud KMS CryptoKey Encrypter " tabindex="-1">Cloud KMS CryptoKey Encrypter</h4>
<p>(<code translate="no" dir="ltr">roles/cloudkms.cryptoKeyEncrypter</code>)</p>
<span class="role-description custom"> </span>
<p>Provides ability to use Cloud KMS resources for encrypt operations only.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>CryptoKey</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.useToEncrypt</code></p>
<p><code translate="no" dir="ltr">cloudkms.locations.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.locations.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="cloudkms.cryptoKeyEncrypterDecrypterViaDelegation" class="role-title add-link" data-text="Cloud KMS CryptoKey Encrypter/Decrypter Via Delegation " tabindex="-1">Cloud KMS CryptoKey Encrypter/Decrypter Via Delegation</h4>
<p>(<code translate="no" dir="ltr">roles/cloudkms.cryptoKeyEncrypterDecrypterViaDelegation</code>)</p>
<span class="role-description custom"> </span>
<p>Enables Encrypt and Decrypt operations via other Google Cloud services</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>CryptoKey</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.useToDecryptViaDelegation</code></p>
<p><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.useToEncryptViaDelegation</code></p>
<p><code translate="no" dir="ltr">cloudkms.locations.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.locations.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="cloudkms.cryptoKeyEncrypterViaDelegation" class="role-title add-link" data-text="Cloud KMS CryptoKey Encrypter Via Delegation " tabindex="-1">Cloud KMS CryptoKey Encrypter Via Delegation</h4>
<p>(<code translate="no" dir="ltr">roles/cloudkms.cryptoKeyEncrypterViaDelegation</code>)</p>
<span class="role-description custom"> </span>
<p>Enables Encrypt operations via other Google Cloud services</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>CryptoKey</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.useToEncryptViaDelegation</code></p>
<p><code translate="no" dir="ltr">cloudkms.locations.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.locations.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="cloudkms.cryptoOperator" class="role-title add-link" data-text="Cloud KMS Crypto Operator " tabindex="-1">Cloud KMS Crypto Operator</h4>
<p>(<code translate="no" dir="ltr">roles/cloudkms.cryptoOperator</code>)</p>
<span class="role-description"> </span>
<p>Enables all Crypto Operations.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>CryptoKey</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.useToDecapsulate</code></p>
<p><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.useToDecrypt</code></p>
<p><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.useToEncrypt</code></p>
<p><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.useToSign</code></p>
<p><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.useToVerify</code></p>
<p><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.viewPublicKey</code></p>
<p><code translate="no" dir="ltr">cloudkms.locations.generateRandomBytes</code></p>
<p><code translate="no" dir="ltr">cloudkms.locations.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.locations.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="cloudkms.decapsulator" class="role-title add-link" data-text="Cloud KMS CryptoKey Decapsulator Beta " tabindex="-1">Cloud KMS CryptoKey Decapsulator <sup>Beta</sup></h4>
<p>(<code translate="no" dir="ltr">roles/cloudkms.decapsulator</code>)</p>
<span class="role-description"> </span>
<p>Enables Decapsulate and GetPublicKey operations</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.useToDecapsulate</code></p>
<p><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.viewPublicKey</code></p>
<p><code translate="no" dir="ltr">cloudkms.locations.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.locations.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="cloudkms.ekmConnectionsAdmin" class="role-title add-link" data-text="Cloud KMS EkmConnections Admin " tabindex="-1">Cloud KMS EkmConnections Admin</h4>
<p>(<code translate="no" dir="ltr">roles/cloudkms.ekmConnectionsAdmin</code>)</p>
<span class="role-description"> </span>
<p>Enables management of EkmConnections.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudkms.ekmConfigs.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.ekmConfigs.update</code></p>
<p><code translate="no" dir="ltr">cloudkms.ekmConnections.create</code></p>
<p><code translate="no" dir="ltr">cloudkms.ekmConnections.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.ekmConnections.list</code></p>
<p><code translate="no" dir="ltr">cloudkms.ekmConnections.update</code></p>
<p><code translate="no" dir="ltr">cloudkms.ekmConnections.verifyConnectivity</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="cloudkms.encryptionDashboardViewer" class="role-title add-link" data-text="Cloud KMS Encryption Dashboard Viewer " tabindex="-1">Cloud KMS Encryption Dashboard Viewer</h4>
<p>(<code translate="no" dir="ltr">roles/cloudkms.encryptionDashboardViewer</code>)</p>
<span class="role-description"> </span>
<p>Enables viewing KMS encryption dashboard.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudkms.cryptoKeys.list</code></p>
<p><code translate="no" dir="ltr">cloudkms.protectableResources.list</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="cloudkms.expertPqcSigner" class="role-title add-link" data-text="Cloud KMS Expert PQ Asymmetric Signing Key Manager " tabindex="-1">Cloud KMS Expert PQ Asymmetric Signing Key Manager</h4>
<p>(<code translate="no" dir="ltr">roles/cloudkms.expertPqcSigner</code>)</p>
<span class="role-description"> </span>
<p>Enables PQ asymmetric signing key management.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.managePqcSign</code></p>
<p><code translate="no" dir="ltr">cloudkms.locations.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.locations.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="cloudkms.expertRawAesCbc" class="role-title add-link" data-text="Cloud KMS Expert Raw AES-CBC Key Manager " tabindex="-1">Cloud KMS Expert Raw AES-CBC Key Manager</h4>
<p>(<code translate="no" dir="ltr">roles/cloudkms.expertRawAesCbc</code>)</p>
<span class="role-description"> </span>
<p>Enables raw AES-CBC keys management.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>CryptoKey</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.manageRawAesCbcKeys</code></p>
<p><code translate="no" dir="ltr">cloudkms.locations.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.locations.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="cloudkms.expertRawAesCtr" class="role-title add-link" data-text="Cloud KMS Expert Raw AES-CTR Key Manager " tabindex="-1">Cloud KMS Expert Raw AES-CTR Key Manager</h4>
<p>(<code translate="no" dir="ltr">roles/cloudkms.expertRawAesCtr</code>)</p>
<span class="role-description"> </span>
<p>Enables raw AES-CTR keys management.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>CryptoKey</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.manageRawAesCtrKeys</code></p>
<p><code translate="no" dir="ltr">cloudkms.locations.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.locations.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="cloudkms.expertRawPKCS1" class="role-title add-link" data-text="Cloud KMS Expert Raw PKCS#1 Key Manager " tabindex="-1">Cloud KMS Expert Raw PKCS#1 Key Manager</h4>
<p>(<code translate="no" dir="ltr">roles/cloudkms.expertRawPKCS1</code>)</p>
<span class="role-description"> </span>
<p>Enables raw PKCS#1 keys management.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>CryptoKey</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.manageRawPKCS1Keys</code></p>
<p><code translate="no" dir="ltr">cloudkms.locations.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.locations.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="cloudkms.hsmSingleTenantExecutor" class="role-title add-link" data-text="Cloud KMS single-tenant HSM Executor " tabindex="-1">Cloud KMS single-tenant HSM Executor</h4>
<p>(<code translate="no" dir="ltr">roles/cloudkms.hsmSingleTenantExecutor</code>)</p>
<span class="role-description"> </span>
<p>Grants ability to execute SingleTenantHsmInstanceProposal resources.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudkms.operations.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.singleTenantHsmInstanceProposals.execute</code></p>
<p><code translate="no" dir="ltr">cloudkms.singleTenantHsmInstanceProposals.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.singleTenantHsmInstanceProposals.list</code></p>
<p><code translate="no" dir="ltr">cloudkms.singleTenantHsmInstances.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.singleTenantHsmInstances.list</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="cloudkms.hsmSingleTenantKeyCreator" class="role-title add-link" data-text="Cloud KMS single-tenant HSM Key Creator " tabindex="-1">Cloud KMS single-tenant HSM Key Creator</h4>
<p>(<code translate="no" dir="ltr">roles/cloudkms.hsmSingleTenantKeyCreator</code>)</p>
<span class="role-description"> </span>
<p>Grants ability to use single-tenant HSM instances to create keys. This role must be combined with another role that grants the ability to create cryptoKeys.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudkms.singleTenantHsmInstances.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.singleTenantHsmInstances.list</code></p>
<p><code translate="no" dir="ltr">cloudkms.singleTenantHsmInstances.use</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="cloudkms.hsmSingleTenantProposer" class="role-title add-link" data-text="Cloud KMS single-tenant HSM Proposer " tabindex="-1">Cloud KMS single-tenant HSM Proposer</h4>
<p>(<code translate="no" dir="ltr">roles/cloudkms.hsmSingleTenantProposer</code>)</p>
<span class="role-description"> </span>
<p>Grants ability to create SingleTenantHsmInstances and SingleTenantHsmInstanceProposals.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudkms.operations.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.singleTenantHsmInstanceProposals.create</code></p>
<p><code translate="no" dir="ltr">cloudkms.singleTenantHsmInstanceProposals.delete</code></p>
<p><code translate="no" dir="ltr">cloudkms.singleTenantHsmInstanceProposals.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.singleTenantHsmInstanceProposals.list</code></p>
<p><code translate="no" dir="ltr">cloudkms.singleTenantHsmInstances.create</code></p>
<p><code translate="no" dir="ltr">cloudkms.singleTenantHsmInstances.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.singleTenantHsmInstances.list</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="cloudkms.hsmSingleTenantQuorumMember" class="role-title add-link" data-text="Cloud KMS single-tenant HSM Quorum Member " tabindex="-1">Cloud KMS single-tenant HSM Quorum Member</h4>
<p>(<code translate="no" dir="ltr">roles/cloudkms.hsmSingleTenantQuorumMember</code>)</p>
<span class="role-description"> </span>
<p>Grants ability to approve SingleTenantHsmInstanceProposal resources.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudkms.operations.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.singleTenantHsmInstanceProposals.approve</code></p>
<p><code translate="no" dir="ltr">cloudkms.singleTenantHsmInstanceProposals.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.singleTenantHsmInstanceProposals.list</code></p>
<p><code translate="no" dir="ltr">cloudkms.singleTenantHsmInstances.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.singleTenantHsmInstances.list</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="cloudkms.importer" class="role-title add-link" data-text="Cloud KMS Importer " tabindex="-1">Cloud KMS Importer</h4>
<p>(<code translate="no" dir="ltr">roles/cloudkms.importer</code>)</p>
<span class="role-description"> </span>
<p>Enables ImportCryptoKeyVersion, CreateImportJob, ListImportJobs, and GetImportJob operations</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.trustedImportExport</code></p>
<p><code translate="no" dir="ltr">cloudkms.importJobs.create</code></p>
<p><code translate="no" dir="ltr">cloudkms.importJobs.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.importJobs.list</code></p>
<p><code translate="no" dir="ltr">cloudkms.importJobs.useToImport</code></p>
<p><code translate="no" dir="ltr">cloudkms.locations.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.locations.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="cloudkms.keyAccessJustificationsEnrollmentConfigViewer" class="role-title add-link" data-text="Key Access Justifications Enrollment Viewer " tabindex="-1">Key Access Justifications Enrollment Viewer</h4>
<p>(<code translate="no" dir="ltr">roles/cloudkms.keyAccessJustificationsEnrollmentConfigViewer</code>)</p>
<span class="role-description"> </span>
<p>Grant ability to view Key Access Justification enrollment configs of a project.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudkms.projects.showEffectiveKajEnrollmentConfig</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="cloudkms.keyAccessJustificationsPolicyConfigAdmin" class="role-title add-link" data-text="Key Access Justifications Policy Config Admin " tabindex="-1">Key Access Justifications Policy Config Admin</h4>
<p>(<code translate="no" dir="ltr">roles/cloudkms.keyAccessJustificationsPolicyConfigAdmin</code>)</p>
<span class="role-description"> </span>
<p>Grant ability to manage Key Access Justifications Policy at parent resource level.</p></td>
<td class="role-permissions"><p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudkms.kajPolicyConfigs.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudkms.kajPolicyConfigs.get</code></li>
<li><code translate="no" dir="ltr">cloudkms.kajPolicyConfigs.update</code></li>
</ul>
<p><code translate="no" dir="ltr">cloudkms.projects.showEffectiveKajPolicyConfig</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="cloudkms.protectedResourcesViewer" class="role-title add-link" data-text="Cloud KMS Protected Resources Viewer " tabindex="-1">Cloud KMS Protected Resources Viewer</h4>
<p>(<code translate="no" dir="ltr">roles/cloudkms.protectedResourcesViewer</code>)</p>
<span class="role-description"> </span>
<p>Enables viewing protected resources.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudkms.protectedResources.search</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="cloudkms.publicKeyViewer" class="role-title add-link" data-text="Cloud KMS CryptoKey Public Key Viewer " tabindex="-1">Cloud KMS CryptoKey Public Key Viewer</h4>
<p>(<code translate="no" dir="ltr">roles/cloudkms.publicKeyViewer</code>)</p>
<span class="role-description"> </span>
<p>Enables GetPublicKey operations</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>CryptoKey</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.viewPublicKey</code></p>
<p><code translate="no" dir="ltr">cloudkms.locations.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.locations.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="cloudkms.signer" class="role-title add-link" data-text="Cloud KMS CryptoKey Signer " tabindex="-1">Cloud KMS CryptoKey Signer</h4>
<p>(<code translate="no" dir="ltr">roles/cloudkms.signer</code>)</p>
<span class="role-description"> </span>
<p>Enables Sign operations</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>CryptoKey</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.useToSign</code></p>
<p><code translate="no" dir="ltr">cloudkms.locations.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.locations.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="cloudkms.signerVerifier" class="role-title add-link" data-text="Cloud KMS CryptoKey Signer/Verifier " tabindex="-1">Cloud KMS CryptoKey Signer/Verifier</h4>
<p>(<code translate="no" dir="ltr">roles/cloudkms.signerVerifier</code>)</p>
<span class="role-description"> </span>
<p>Enables Sign, Verify, and GetPublicKey operations</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>CryptoKey</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.useToSign</code></p>
<p><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.useToVerify</code></p>
<p><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.viewPublicKey</code></p>
<p><code translate="no" dir="ltr">cloudkms.locations.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.locations.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="cloudkms.verifier" class="role-title add-link" data-text="Cloud KMS CryptoKey Verifier " tabindex="-1">Cloud KMS CryptoKey Verifier</h4>
<p>(<code translate="no" dir="ltr">roles/cloudkms.verifier</code>)</p>
<span class="role-description"> </span>
<p>Enables Verify and GetPublicKey operations</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>CryptoKey</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.useToVerify</code></p>
<p><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.viewPublicKey</code></p>
<p><code translate="no" dir="ltr">cloudkms.locations.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.locations.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p></td>
</tr>
</tbody>
</table>

### Service agent roles

Service agent roles should only be granted to [service agents](/iam/docs/service-agents).

<div results-count-container="">

</div>

<table class="fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="50%">Role</th>
<th>Permissions</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td class="role-description"><h4 id="cloudkms.orgServiceAgent" class="role-title add-link" data-text="Cloud KMS Organization Service Agent " tabindex="-1">Cloud KMS Organization Service Agent</h4>
<p>(<code translate="no" dir="ltr">roles/cloudkms.orgServiceAgent</code>)</p>
<span class="role-description"> </span>
<p>Gives Cloud KMS organization-level service account access to managed resources.</p>
<strong>Warning:</strong> Do not grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.</td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudasset.assets.listResource</code></p>
<p><code translate="no" dir="ltr">cloudasset.assets.searchAllIamPolicies</code></p>
<p><code translate="no" dir="ltr">cloudasset.assets.searchAllResources</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="cloudkms.serviceAgent" class="role-title add-link" data-text="Cloud KMS Service Agent " tabindex="-1">Cloud KMS Service Agent</h4>
<p>(<code translate="no" dir="ltr">roles/cloudkms.serviceAgent</code>)</p>
<span class="role-description"> </span>
<p>Gives Cloud KMS service account access to managed resources.</p>
<strong>Warning:</strong> Do not grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.</td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudasset.assets.listCloudkmsCryptoKeys</code></p>
<p><code translate="no" dir="ltr">cloudasset.assets.listResource</code></p>
<p><code translate="no" dir="ltr">cloudasset.assets.searchAllIamPolicies</code></p>
<p><code translate="no" dir="ltr">cloudasset.assets.searchAllResources</code></p>
<p><code translate="no" dir="ltr">cloudkms.cryptoKeys.create</code></p>
<p><code translate="no" dir="ltr">cloudkms.cryptoKeys.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudkms.cryptoKeys.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudkms.keyRings.create</code></p>
<p><code translate="no" dir="ltr">cloudkms.keyRings.get</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="cloudkmskacls.serviceAgent" class="role-title add-link" data-text="Cloud KMS KACLS Service Agent " tabindex="-1">Cloud KMS KACLS Service Agent</h4>
<p>(<code translate="no" dir="ltr">roles/cloudkmskacls.serviceAgent</code>)</p>
<span class="role-description"> </span>
<p>Grants Cloud KMS KACLS Service Agent access to KMS resource permissions to perform DEK encryption/decryption.</p>
<strong>Warning:</strong> Do not grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.</td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.useToDecrypt</code></p>
<p><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.useToEncrypt</code></p>
<p><code translate="no" dir="ltr">cloudkms.cryptoKeys.get</code></p></td>
</tr>
</tbody>
</table>

## Cloud Key Management Service permissions

<div results-count-container="">

</div>

<table class="permissions-table fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="45%">Permission</th>
<th>Included in roles</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td><h4 id="cloudkms.autokeyConfigs.get" class="permission-name add-link" data-text="cloudkms.autokeyConfigs.get" tabindex="-1"><code translate="no" dir="ltr">cloudkms.autokeyConfigs.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.viewer">Cloud KMS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.autokeyAdmin">Cloud KMS Autokey Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.autokeyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="cloudkms.autokeyConfigs.update" class="permission-name add-link" data-text="cloudkms.autokeyConfigs.update" tabindex="-1"><code translate="no" dir="ltr">cloudkms.autokeyConfigs.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.autokeyAdmin">Cloud KMS Autokey Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.autokeyAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="cloudkms.cryptoKeyVersions.create" class="permission-name add-link" data-text="cloudkms.cryptoKeyVersions.create" tabindex="-1"><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="cloudkms.cryptoKeyVersions.delete" class="permission-name add-link" data-text="cloudkms.cryptoKeyVersions.delete" tabindex="-1"><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="cloudkms.cryptoKeyVersions.destroy" class="permission-name add-link" data-text="cloudkms.cryptoKeyVersions.destroy" tabindex="-1"><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.destroy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="cloudkms.cryptoKeyVersions.get" class="permission-name add-link" data-text="cloudkms.cryptoKeyVersions.get" tabindex="-1"><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.viewer">Cloud KMS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/container#container.cloudKmsKeyUser">Kubernetes Engine KMS Crypto Key User</a> (<code class="role-name" translate="no" dir="ltr">roles/container.cloudKmsKeyUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="cloudkms.cryptoKeyVersions.list" class="permission-name add-link" data-text="cloudkms.cryptoKeyVersions.list" tabindex="-1"><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.viewer">Cloud KMS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="cloudkms.cryptoKeyVersions.managePqcSign" class="permission-name add-link" data-text="cloudkms.cryptoKeyVersions.managePqcSign" tabindex="-1"><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.managePqcSign</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.expertPqcSigner">Cloud KMS Expert PQ Asymmetric Signing Key Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.expertPqcSigner</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="cloudkms.cryptoKeyVersions.manageRawAesCbcKeys" class="permission-name add-link" data-text="cloudkms.cryptoKeyVersions.manageRawAesCbcKeys" tabindex="-1"><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.manageRawAesCbcKeys</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.expertRawAesCbc">Cloud KMS Expert Raw AES-CBC Key Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.expertRawAesCbc</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="cloudkms.cryptoKeyVersions.manageRawAesCtrKeys" class="permission-name add-link" data-text="cloudkms.cryptoKeyVersions.manageRawAesCtrKeys" tabindex="-1"><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.manageRawAesCtrKeys</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.expertRawAesCtr">Cloud KMS Expert Raw AES-CTR Key Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.expertRawAesCtr</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="cloudkms.cryptoKeyVersions.manageRawPKCS1Keys" class="permission-name add-link" data-text="cloudkms.cryptoKeyVersions.manageRawPKCS1Keys" tabindex="-1"><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.manageRawPKCS1Keys</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.expertRawPKCS1">Cloud KMS Expert Raw PKCS#1 Key Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.expertRawPKCS1</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="cloudkms.cryptoKeyVersions.restore" class="permission-name add-link" data-text="cloudkms.cryptoKeyVersions.restore" tabindex="-1"><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.restore</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="cloudkms.cryptoKeyVersions.trustedImportExport" class="permission-name add-link" data-text="cloudkms.cryptoKeyVersions.trustedImportExport" tabindex="-1"><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.trustedImportExport</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.importer">Cloud KMS Importer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.importer</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="cloudkms.cryptoKeyVersions.update" class="permission-name add-link" data-text="cloudkms.cryptoKeyVersions.update" tabindex="-1"><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="cloudkms.cryptoKeyVersions.useToDecapsulate" class="permission-name add-link" data-text="cloudkms.cryptoKeyVersions.useToDecapsulate" tabindex="-1"><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.useToDecapsulate</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.cryptoOperator">Cloud KMS Crypto Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.cryptoOperator</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.decapsulator">Cloud KMS CryptoKey Decapsulator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.decapsulator</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="cloudkms.cryptoKeyVersions.useToDecrypt" class="permission-name add-link" data-text="cloudkms.cryptoKeyVersions.useToDecrypt" tabindex="-1"><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.useToDecrypt</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.cryptoKeyEncrypterDecrypter">Cloud KMS CryptoKey Encrypter/Decrypter</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.cryptoKeyEncrypterDecrypter</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.cryptoKeyDecrypter">Cloud KMS CryptoKey Decrypter</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.cryptoKeyDecrypter</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.cryptoOperator">Cloud KMS Crypto Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.cryptoOperator</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.workloadScanner">Wiz Workload Scanner</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.workloadScanner</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudkms#cloudkmskacls.serviceAgent">Cloud KMS KACLS Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkmskacls.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="cloudkms.cryptoKeyVersions.useToDecryptViaDelegation" class="permission-name add-link" data-text="cloudkms.cryptoKeyVersions.useToDecryptViaDelegation" tabindex="-1"><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.useToDecryptViaDelegation</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.cryptoKeyDecrypterViaDelegation">Cloud KMS CryptoKey Decrypter Via Delegation</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.cryptoKeyDecrypterViaDelegation</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.cryptoKeyEncrypterDecrypterViaDelegation">Cloud KMS CryptoKey Encrypter/Decrypter Via Delegation</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.cryptoKeyEncrypterDecrypterViaDelegation</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="cloudkms.cryptoKeyVersions.useToEncrypt" class="permission-name add-link" data-text="cloudkms.cryptoKeyVersions.useToEncrypt" tabindex="-1"><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.useToEncrypt</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.cryptoKeyEncrypterDecrypter">Cloud KMS CryptoKey Encrypter/Decrypter</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.cryptoKeyEncrypterDecrypter</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.cryptoKeyEncrypter">Cloud KMS CryptoKey Encrypter</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.cryptoKeyEncrypter</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.cryptoOperator">Cloud KMS Crypto Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.cryptoOperator</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.workloadScanner">Wiz Workload Scanner</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.workloadScanner</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudkms#cloudkmskacls.serviceAgent">Cloud KMS KACLS Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkmskacls.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="cloudkms.cryptoKeyVersions.useToEncryptViaDelegation" class="permission-name add-link" data-text="cloudkms.cryptoKeyVersions.useToEncryptViaDelegation" tabindex="-1"><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.useToEncryptViaDelegation</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.cryptoKeyEncrypterDecrypterViaDelegation">Cloud KMS CryptoKey Encrypter/Decrypter Via Delegation</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.cryptoKeyEncrypterDecrypterViaDelegation</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.cryptoKeyEncrypterViaDelegation">Cloud KMS CryptoKey Encrypter Via Delegation</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.cryptoKeyEncrypterViaDelegation</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="cloudkms.cryptoKeyVersions.useToSign" class="permission-name add-link" data-text="cloudkms.cryptoKeyVersions.useToSign" tabindex="-1"><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.useToSign</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.cryptoOperator">Cloud KMS Crypto Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.cryptoOperator</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.signer">Cloud KMS CryptoKey Signer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.signer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.signerVerifier">Cloud KMS CryptoKey Signer/Verifier</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.signerVerifier</code>)</p>
<p><a href="/iam/docs/roles-permissions/container#container.cloudKmsKeyUser">Kubernetes Engine KMS Crypto Key User</a> (<code class="role-name" translate="no" dir="ltr">roles/container.cloudKmsKeyUser</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="cloudkms.cryptoKeyVersions.useToVerify" class="permission-name add-link" data-text="cloudkms.cryptoKeyVersions.useToVerify" tabindex="-1"><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.useToVerify</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.cryptoOperator">Cloud KMS Crypto Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.cryptoOperator</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.signerVerifier">Cloud KMS CryptoKey Signer/Verifier</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.signerVerifier</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.verifier">Cloud KMS CryptoKey Verifier</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.verifier</code>)</p>
<p><a href="/iam/docs/roles-permissions/container#container.cloudKmsKeyUser">Kubernetes Engine KMS Crypto Key User</a> (<code class="role-name" translate="no" dir="ltr">roles/container.cloudKmsKeyUser</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="cloudkms.cryptoKeyVersions.viewPublicKey" class="permission-name add-link" data-text="cloudkms.cryptoKeyVersions.viewPublicKey" tabindex="-1"><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.viewPublicKey</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.cryptoOperator">Cloud KMS Crypto Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.cryptoOperator</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.decapsulator">Cloud KMS CryptoKey Decapsulator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.decapsulator</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.publicKeyViewer">Cloud KMS CryptoKey Public Key Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.publicKeyViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.signerVerifier">Cloud KMS CryptoKey Signer/Verifier</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.signerVerifier</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.verifier">Cloud KMS CryptoKey Verifier</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.verifier</code>)</p>
<p><a href="/iam/docs/roles-permissions/container#container.cloudKmsKeyUser">Kubernetes Engine KMS Crypto Key User</a> (<code class="role-name" translate="no" dir="ltr">roles/container.cloudKmsKeyUser</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="cloudkms.cryptoKeys.create" class="permission-name add-link" data-text="cloudkms.cryptoKeys.create" tabindex="-1"><code translate="no" dir="ltr">cloudkms.cryptoKeys.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/assuredworkloads#assuredworkloads.serviceAgent">Assured Workloads Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredworkloads.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.serviceAgent">Cloud KMS Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="cloudkms.cryptoKeys.delete" class="permission-name add-link" data-text="cloudkms.cryptoKeys.delete" tabindex="-1"><code translate="no" dir="ltr">cloudkms.cryptoKeys.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="cloudkms.cryptoKeys.get" class="permission-name add-link" data-text="cloudkms.cryptoKeys.get" tabindex="-1"><code translate="no" dir="ltr">cloudkms.cryptoKeys.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.viewer">Cloud KMS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/container#container.cloudKmsKeyUser">Kubernetes Engine KMS Crypto Key User</a> (<code class="role-name" translate="no" dir="ltr">roles/container.cloudKmsKeyUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/securedlandingzone#securedlandingzone.bqdwProjectRemediator">SLZ BQDW Blueprint Project Level Remediator</a> (<code class="role-name" translate="no" dir="ltr">roles/securedlandingzone.bqdwProjectRemediator</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.serviceAgent">Audit Manager Auditing Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudkms#cloudkmskacls.serviceAgent">Cloud KMS KACLS Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkmskacls.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.serviceAgent">Cloud Security Compliance Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="cloudkms.cryptoKeys.getIamPolicy" class="permission-name add-link" data-text="cloudkms.cryptoKeys.getIamPolicy" tabindex="-1"><code translate="no" dir="ltr">cloudkms.cryptoKeys.getIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.viewer">Cloud KMS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/securedlandingzone#securedlandingzone.bqdwProjectRemediator">SLZ BQDW Blueprint Project Level Remediator</a> (<code class="role-name" translate="no" dir="ltr">roles/securedlandingzone.bqdwProjectRemediator</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.serviceAgent">Cloud KMS Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="cloudkms.cryptoKeys.list" class="permission-name add-link" data-text="cloudkms.cryptoKeys.list" tabindex="-1"><code translate="no" dir="ltr">cloudkms.cryptoKeys.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.viewer">Cloud KMS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.encryptionDashboardViewer">Cloud KMS Encryption Dashboard Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.encryptionDashboardViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/securedlandingzone#securedlandingzone.bqdwProjectRemediator">SLZ BQDW Blueprint Project Level Remediator</a> (<code class="role-name" translate="no" dir="ltr">roles/securedlandingzone.bqdwProjectRemediator</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.serviceAgent">Audit Manager Auditing Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.serviceAgent">Cloud Security Compliance Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="cloudkms.cryptoKeys.setIamPolicy" class="permission-name add-link" data-text="cloudkms.cryptoKeys.setIamPolicy" tabindex="-1"><code translate="no" dir="ltr">cloudkms.cryptoKeys.setIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/securedlandingzone#securedlandingzone.bqdwProjectRemediator">SLZ BQDW Blueprint Project Level Remediator</a> (<code class="role-name" translate="no" dir="ltr">roles/securedlandingzone.bqdwProjectRemediator</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.serviceAgent">Cloud KMS Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="cloudkms.cryptoKeys.update" class="permission-name add-link" data-text="cloudkms.cryptoKeys.update" tabindex="-1"><code translate="no" dir="ltr">cloudkms.cryptoKeys.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/securedlandingzone#securedlandingzone.bqdwProjectRemediator">SLZ BQDW Blueprint Project Level Remediator</a> (<code class="role-name" translate="no" dir="ltr">roles/securedlandingzone.bqdwProjectRemediator</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="cloudkms.ekmConfigs.get" class="permission-name add-link" data-text="cloudkms.ekmConfigs.get" tabindex="-1"><code translate="no" dir="ltr">cloudkms.ekmConfigs.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.viewer">Cloud KMS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.ekmConnectionsAdmin">Cloud KMS EkmConnections Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.ekmConnectionsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="cloudkms.ekmConfigs.getIamPolicy" class="permission-name add-link" data-text="cloudkms.ekmConfigs.getIamPolicy" tabindex="-1"><code translate="no" dir="ltr">cloudkms.ekmConfigs.getIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.viewer">Cloud KMS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="cloudkms.ekmConfigs.setIamPolicy" class="permission-name add-link" data-text="cloudkms.ekmConfigs.setIamPolicy" tabindex="-1"><code translate="no" dir="ltr">cloudkms.ekmConfigs.setIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="cloudkms.ekmConfigs.update" class="permission-name add-link" data-text="cloudkms.ekmConfigs.update" tabindex="-1"><code translate="no" dir="ltr">cloudkms.ekmConfigs.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.ekmConnectionsAdmin">Cloud KMS EkmConnections Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.ekmConnectionsAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="cloudkms.ekmConnections.create" class="permission-name add-link" data-text="cloudkms.ekmConnections.create" tabindex="-1"><code translate="no" dir="ltr">cloudkms.ekmConnections.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.ekmConnectionsAdmin">Cloud KMS EkmConnections Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.ekmConnectionsAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="cloudkms.ekmConnections.get" class="permission-name add-link" data-text="cloudkms.ekmConnections.get" tabindex="-1"><code translate="no" dir="ltr">cloudkms.ekmConnections.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.viewer">Cloud KMS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.ekmConnectionsAdmin">Cloud KMS EkmConnections Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.ekmConnectionsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudcontrolspartner#cloudcontrolspartner.ekmServiceAgent">Cloud Controls Partner EKM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudcontrolspartner.ekmServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="cloudkms.ekmConnections.getIamPolicy" class="permission-name add-link" data-text="cloudkms.ekmConnections.getIamPolicy" tabindex="-1"><code translate="no" dir="ltr">cloudkms.ekmConnections.getIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.viewer">Cloud KMS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudcontrolspartner#cloudcontrolspartner.ekmServiceAgent">Cloud Controls Partner EKM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudcontrolspartner.ekmServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="cloudkms.ekmConnections.list" class="permission-name add-link" data-text="cloudkms.ekmConnections.list" tabindex="-1"><code translate="no" dir="ltr">cloudkms.ekmConnections.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.viewer">Cloud KMS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.ekmConnectionsAdmin">Cloud KMS EkmConnections Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.ekmConnectionsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudcontrolspartner#cloudcontrolspartner.ekmServiceAgent">Cloud Controls Partner EKM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudcontrolspartner.ekmServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="cloudkms.ekmConnections.setIamPolicy" class="permission-name add-link" data-text="cloudkms.ekmConnections.setIamPolicy" tabindex="-1"><code translate="no" dir="ltr">cloudkms.ekmConnections.setIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="cloudkms.ekmConnections.update" class="permission-name add-link" data-text="cloudkms.ekmConnections.update" tabindex="-1"><code translate="no" dir="ltr">cloudkms.ekmConnections.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.ekmConnectionsAdmin">Cloud KMS EkmConnections Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.ekmConnectionsAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="cloudkms.ekmConnections.use" class="permission-name add-link" data-text="cloudkms.ekmConnections.use" tabindex="-1"><code translate="no" dir="ltr">cloudkms.ekmConnections.use</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="cloudkms.ekmConnections.verifyConnectivity" class="permission-name add-link" data-text="cloudkms.ekmConnections.verifyConnectivity" tabindex="-1"><code translate="no" dir="ltr">cloudkms.ekmConnections.verifyConnectivity</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.viewer">Cloud KMS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.ekmConnectionsAdmin">Cloud KMS EkmConnections Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.ekmConnectionsAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudcontrolspartner#cloudcontrolspartner.ekmServiceAgent">Cloud Controls Partner EKM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudcontrolspartner.ekmServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="cloudkms.folders.showEffectiveAutokeyConfig" class="permission-name add-link" data-text="cloudkms.folders.showEffectiveAutokeyConfig" tabindex="-1"><code translate="no" dir="ltr">cloudkms.folders.showEffectiveAutokeyConfig</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.viewer">Cloud KMS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.autokeyAdmin">Cloud KMS Autokey Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.autokeyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="cloudkms.importJobs.create" class="permission-name add-link" data-text="cloudkms.importJobs.create" tabindex="-1"><code translate="no" dir="ltr">cloudkms.importJobs.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.importer">Cloud KMS Importer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.importer</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="cloudkms.importJobs.delete" class="permission-name add-link" data-text="cloudkms.importJobs.delete" tabindex="-1"><code translate="no" dir="ltr">cloudkms.importJobs.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="cloudkms.importJobs.get" class="permission-name add-link" data-text="cloudkms.importJobs.get" tabindex="-1"><code translate="no" dir="ltr">cloudkms.importJobs.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.viewer">Cloud KMS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.importer">Cloud KMS Importer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.importer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="cloudkms.importJobs.getIamPolicy" class="permission-name add-link" data-text="cloudkms.importJobs.getIamPolicy" tabindex="-1"><code translate="no" dir="ltr">cloudkms.importJobs.getIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.viewer">Cloud KMS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="cloudkms.importJobs.list" class="permission-name add-link" data-text="cloudkms.importJobs.list" tabindex="-1"><code translate="no" dir="ltr">cloudkms.importJobs.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.viewer">Cloud KMS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.importer">Cloud KMS Importer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.importer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="cloudkms.importJobs.setIamPolicy" class="permission-name add-link" data-text="cloudkms.importJobs.setIamPolicy" tabindex="-1"><code translate="no" dir="ltr">cloudkms.importJobs.setIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="cloudkms.importJobs.useToImport" class="permission-name add-link" data-text="cloudkms.importJobs.useToImport" tabindex="-1"><code translate="no" dir="ltr">cloudkms.importJobs.useToImport</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.importer">Cloud KMS Importer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.importer</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="cloudkms.kajPolicyConfigs.get" class="permission-name add-link" data-text="cloudkms.kajPolicyConfigs.get" tabindex="-1"><code translate="no" dir="ltr">cloudkms.kajPolicyConfigs.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.viewer">Cloud KMS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.keyAccessJustificationsPolicyConfigAdmin">Key Access Justifications Policy Config Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.keyAccessJustificationsPolicyConfigAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="cloudkms.kajPolicyConfigs.update" class="permission-name add-link" data-text="cloudkms.kajPolicyConfigs.update" tabindex="-1"><code translate="no" dir="ltr">cloudkms.kajPolicyConfigs.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.keyAccessJustificationsPolicyConfigAdmin">Key Access Justifications Policy Config Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.keyAccessJustificationsPolicyConfigAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="cloudkms.keyHandles.create" class="permission-name add-link" data-text="cloudkms.keyHandles.create" tabindex="-1"><code translate="no" dir="ltr">cloudkms.keyHandles.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/alloydb#alloydb.admin">AlloyDB Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/alloydb.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigee#apigee.admin">Apigee Organization Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigee#apigee.editor">Apigee Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apihub#apihub.admin">Cloud API Hub Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apihub.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/backupdr#backupdr.admin">Backup and DR Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/backupdr.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataEditor">BigQuery Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioUser">BigQuery Studio User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.user">BigQuery User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.admin">Cloud SQL Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.admin">Composer Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.admin">Compute Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.instanceAdmin">Compute Instance Admin (beta)</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.instanceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.instanceAdmin.v1">Compute Instance Admin (v1)</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.instanceAdmin.v1</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.storageAdmin">Compute Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.storageAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/container#container.admin">Kubernetes Engine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/container.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/container#container.clusterAdmin">Kubernetes Engine Cluster Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/container.clusterAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.admin">Dataflow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.admin">Dataproc Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.editor">Dataproc Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/datastream#datastream.admin">Datastream Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/datastream.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/clouddocumentai#documentai.admin">Document AI Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/documentai.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/clouddocumentai#documentai.editor">Document AI Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/documentai.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/file#file.admin">Cloud Filestore Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/file.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/file#file.editor">Cloud Filestore Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/file.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkebackup#gkebackup.admin">Backup for GKE Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/gkebackup.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/memorystore#memorystore.admin">Memorystore Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/memorystore.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/pubsub#pubsub.admin">Pub/Sub Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/pubsub#pubsub.editor">Pub/Sub Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.admin">Secret Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/securesourcemanager#securesourcemanager.admin">Secure Source Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securesourcemanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/spanner#spanner.admin">Cloud Spanner Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/spanner.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/vmmigration#vmmigration.admin">VM Migration Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/vmmigration.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/workflows#workflows.admin">Workflows Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workflows.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/workflows#workflows.editor">Workflows Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/workflows.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/workstations#workstations.admin">Cloud Workstations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workstations.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apihub#apihub.provisioningAdmin">Cloud API hub Provisioning Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apihub.provisioningAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.autokeyUser">Cloud KMS Autokey User</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.autokeyUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectAdmin">Environment and Storage Object Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.developer">Dataflow Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.serverlessEditor">Dataproc Serverless Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serverlessEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.legacyAdmin">Notebooks Legacy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.legacyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/securesourcemanager#securesourcemanager.instanceOwner">Secure Source Manager Instance Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/securesourcemanager.instanceOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/spanner#spanner.databaseAdmin">Cloud Spanner Database Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/spanner.databaseAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="cloudkms.keyHandles.get" class="permission-name add-link" data-text="cloudkms.keyHandles.get" tabindex="-1"><code translate="no" dir="ltr">cloudkms.keyHandles.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/alloydb#alloydb.admin">AlloyDB Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/alloydb.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigee#apigee.admin">Apigee Organization Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigee#apigee.editor">Apigee Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apihub#apihub.admin">Cloud API Hub Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apihub.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/backupdr#backupdr.admin">Backup and DR Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/backupdr.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataEditor">BigQuery Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioUser">BigQuery Studio User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.user">BigQuery User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.viewer">Cloud KMS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.admin">Cloud SQL Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.admin">Composer Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.admin">Compute Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.instanceAdmin">Compute Instance Admin (beta)</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.instanceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.instanceAdmin.v1">Compute Instance Admin (v1)</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.instanceAdmin.v1</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.storageAdmin">Compute Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.storageAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/container#container.admin">Kubernetes Engine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/container.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/container#container.clusterAdmin">Kubernetes Engine Cluster Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/container.clusterAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.admin">Dataflow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.admin">Dataproc Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.editor">Dataproc Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/datastream#datastream.admin">Datastream Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/datastream.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/clouddocumentai#documentai.admin">Document AI Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/documentai.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/clouddocumentai#documentai.editor">Document AI Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/documentai.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/file#file.admin">Cloud Filestore Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/file.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/file#file.editor">Cloud Filestore Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/file.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkebackup#gkebackup.admin">Backup for GKE Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/gkebackup.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/memorystore#memorystore.admin">Memorystore Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/memorystore.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/pubsub#pubsub.admin">Pub/Sub Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/pubsub#pubsub.editor">Pub/Sub Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.admin">Secret Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/securesourcemanager#securesourcemanager.admin">Secure Source Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securesourcemanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/spanner#spanner.admin">Cloud Spanner Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/spanner.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/vmmigration#vmmigration.admin">VM Migration Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/vmmigration.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/workflows#workflows.admin">Workflows Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workflows.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/workflows#workflows.editor">Workflows Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/workflows.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/workstations#workstations.admin">Cloud Workstations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workstations.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apihub#apihub.provisioningAdmin">Cloud API hub Provisioning Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apihub.provisioningAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.autokeyUser">Cloud KMS Autokey User</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.autokeyUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectAdmin">Environment and Storage Object Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.developer">Dataflow Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.serverlessEditor">Dataproc Serverless Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serverlessEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.legacyAdmin">Notebooks Legacy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.legacyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/securesourcemanager#securesourcemanager.instanceOwner">Secure Source Manager Instance Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/securesourcemanager.instanceOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/spanner#spanner.databaseAdmin">Cloud Spanner Database Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/spanner.databaseAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="cloudkms.keyHandles.list" class="permission-name add-link" data-text="cloudkms.keyHandles.list" tabindex="-1"><code translate="no" dir="ltr">cloudkms.keyHandles.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/alloydb#alloydb.admin">AlloyDB Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/alloydb.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigee#apigee.admin">Apigee Organization Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigee#apigee.editor">Apigee Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apihub#apihub.admin">Cloud API Hub Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apihub.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/backupdr#backupdr.admin">Backup and DR Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/backupdr.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataEditor">BigQuery Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioUser">BigQuery Studio User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.user">BigQuery User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.viewer">Cloud KMS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.admin">Cloud SQL Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.admin">Composer Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.admin">Compute Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.instanceAdmin">Compute Instance Admin (beta)</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.instanceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.instanceAdmin.v1">Compute Instance Admin (v1)</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.instanceAdmin.v1</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.storageAdmin">Compute Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.storageAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/container#container.admin">Kubernetes Engine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/container.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/container#container.clusterAdmin">Kubernetes Engine Cluster Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/container.clusterAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.admin">Dataflow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.admin">Dataproc Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.editor">Dataproc Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/datastream#datastream.admin">Datastream Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/datastream.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/clouddocumentai#documentai.admin">Document AI Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/documentai.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/clouddocumentai#documentai.editor">Document AI Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/documentai.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/file#file.admin">Cloud Filestore Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/file.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/file#file.editor">Cloud Filestore Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/file.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkebackup#gkebackup.admin">Backup for GKE Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/gkebackup.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/memorystore#memorystore.admin">Memorystore Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/memorystore.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/pubsub#pubsub.admin">Pub/Sub Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/pubsub#pubsub.editor">Pub/Sub Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.admin">Secret Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/securesourcemanager#securesourcemanager.admin">Secure Source Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securesourcemanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/spanner#spanner.admin">Cloud Spanner Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/spanner.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/vmmigration#vmmigration.admin">VM Migration Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/vmmigration.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/workflows#workflows.admin">Workflows Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workflows.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/workflows#workflows.editor">Workflows Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/workflows.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/workstations#workstations.admin">Cloud Workstations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workstations.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apihub#apihub.provisioningAdmin">Cloud API hub Provisioning Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apihub.provisioningAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.autokeyUser">Cloud KMS Autokey User</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.autokeyUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectAdmin">Environment and Storage Object Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.developer">Dataflow Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.serverlessEditor">Dataproc Serverless Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serverlessEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.legacyAdmin">Notebooks Legacy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.legacyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/securesourcemanager#securesourcemanager.instanceOwner">Secure Source Manager Instance Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/securesourcemanager.instanceOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/spanner#spanner.databaseAdmin">Cloud Spanner Database Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/spanner.databaseAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="cloudkms.keyRings.create" class="permission-name add-link" data-text="cloudkms.keyRings.create" tabindex="-1"><code translate="no" dir="ltr">cloudkms.keyRings.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/assuredworkloads#assuredworkloads.serviceAgent">Assured Workloads Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredworkloads.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.serviceAgent">Cloud KMS Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="cloudkms.keyRings.createTagBinding" class="permission-name add-link" data-text="cloudkms.keyRings.createTagBinding" tabindex="-1"><code translate="no" dir="ltr">cloudkms.keyRings.createTagBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="cloudkms.keyRings.delete" class="permission-name add-link" data-text="cloudkms.keyRings.delete" tabindex="-1"><code translate="no" dir="ltr">cloudkms.keyRings.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="cloudkms.keyRings.deleteTagBinding" class="permission-name add-link" data-text="cloudkms.keyRings.deleteTagBinding" tabindex="-1"><code translate="no" dir="ltr">cloudkms.keyRings.deleteTagBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="cloudkms.keyRings.get" class="permission-name add-link" data-text="cloudkms.keyRings.get" tabindex="-1"><code translate="no" dir="ltr">cloudkms.keyRings.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.viewer">Cloud KMS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.serviceAgent">Cloud KMS Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="cloudkms.keyRings.getIamPolicy" class="permission-name add-link" data-text="cloudkms.keyRings.getIamPolicy" tabindex="-1"><code translate="no" dir="ltr">cloudkms.keyRings.getIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.viewer">Cloud KMS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/securedlandingzone#securedlandingzone.bqdwProjectRemediator">SLZ BQDW Blueprint Project Level Remediator</a> (<code class="role-name" translate="no" dir="ltr">roles/securedlandingzone.bqdwProjectRemediator</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="cloudkms.keyRings.list" class="permission-name add-link" data-text="cloudkms.keyRings.list" tabindex="-1"><code translate="no" dir="ltr">cloudkms.keyRings.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.viewer">Cloud KMS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.serviceAgent">Audit Manager Auditing Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.serviceAgent">Cloud Security Compliance Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="cloudkms.keyRings.listEffectiveTags" class="permission-name add-link" data-text="cloudkms.keyRings.listEffectiveTags" tabindex="-1"><code translate="no" dir="ltr">cloudkms.keyRings.listEffectiveTags</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.viewer">Cloud KMS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagViewer">Tag Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="cloudkms.keyRings.listTagBindings" class="permission-name add-link" data-text="cloudkms.keyRings.listTagBindings" tabindex="-1"><code translate="no" dir="ltr">cloudkms.keyRings.listTagBindings</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.viewer">Cloud KMS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagViewer">Tag Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="cloudkms.keyRings.setIamPolicy" class="permission-name add-link" data-text="cloudkms.keyRings.setIamPolicy" tabindex="-1"><code translate="no" dir="ltr">cloudkms.keyRings.setIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/securedlandingzone#securedlandingzone.bqdwProjectRemediator">SLZ BQDW Blueprint Project Level Remediator</a> (<code class="role-name" translate="no" dir="ltr">roles/securedlandingzone.bqdwProjectRemediator</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="cloudkms.locations.generateRandomBytes" class="permission-name add-link" data-text="cloudkms.locations.generateRandomBytes" tabindex="-1"><code translate="no" dir="ltr">cloudkms.locations.generateRandomBytes</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.viewer">Cloud KMS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.cryptoOperator">Cloud KMS Crypto Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.cryptoOperator</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="cloudkms.locations.get" class="permission-name add-link" data-text="cloudkms.locations.get" tabindex="-1"><code translate="no" dir="ltr">cloudkms.locations.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.cryptoKeyEncrypterDecrypter">Cloud KMS CryptoKey Encrypter/Decrypter</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.cryptoKeyEncrypterDecrypter</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.viewer">Cloud KMS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.cryptoKeyDecrypter">Cloud KMS CryptoKey Decrypter</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.cryptoKeyDecrypter</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.cryptoKeyDecrypterViaDelegation">Cloud KMS CryptoKey Decrypter Via Delegation</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.cryptoKeyDecrypterViaDelegation</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.cryptoKeyEncrypter">Cloud KMS CryptoKey Encrypter</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.cryptoKeyEncrypter</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.cryptoKeyEncrypterDecrypterViaDelegation">Cloud KMS CryptoKey Encrypter/Decrypter Via Delegation</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.cryptoKeyEncrypterDecrypterViaDelegation</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.cryptoKeyEncrypterViaDelegation">Cloud KMS CryptoKey Encrypter Via Delegation</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.cryptoKeyEncrypterViaDelegation</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.cryptoOperator">Cloud KMS Crypto Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.cryptoOperator</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.decapsulator">Cloud KMS CryptoKey Decapsulator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.decapsulator</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.expertPqcSigner">Cloud KMS Expert PQ Asymmetric Signing Key Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.expertPqcSigner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.expertRawAesCbc">Cloud KMS Expert Raw AES-CBC Key Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.expertRawAesCbc</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.expertRawAesCtr">Cloud KMS Expert Raw AES-CTR Key Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.expertRawAesCtr</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.expertRawPKCS1">Cloud KMS Expert Raw PKCS#1 Key Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.expertRawPKCS1</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.importer">Cloud KMS Importer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.importer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.publicKeyViewer">Cloud KMS CryptoKey Public Key Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.publicKeyViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.signer">Cloud KMS CryptoKey Signer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.signer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.signerVerifier">Cloud KMS CryptoKey Signer/Verifier</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.signerVerifier</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.verifier">Cloud KMS CryptoKey Verifier</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.verifier</code>)</p>
<p><a href="/iam/docs/roles-permissions/container#container.cloudKmsKeyUser">Kubernetes Engine KMS Crypto Key User</a> (<code class="role-name" translate="no" dir="ltr">roles/container.cloudKmsKeyUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.workloadScanner">Wiz Workload Scanner</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.workloadScanner</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="cloudkms.locations.list" class="permission-name add-link" data-text="cloudkms.locations.list" tabindex="-1"><code translate="no" dir="ltr">cloudkms.locations.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.cryptoKeyEncrypterDecrypter">Cloud KMS CryptoKey Encrypter/Decrypter</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.cryptoKeyEncrypterDecrypter</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.viewer">Cloud KMS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.cryptoKeyDecrypter">Cloud KMS CryptoKey Decrypter</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.cryptoKeyDecrypter</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.cryptoKeyDecrypterViaDelegation">Cloud KMS CryptoKey Decrypter Via Delegation</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.cryptoKeyDecrypterViaDelegation</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.cryptoKeyEncrypter">Cloud KMS CryptoKey Encrypter</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.cryptoKeyEncrypter</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.cryptoKeyEncrypterDecrypterViaDelegation">Cloud KMS CryptoKey Encrypter/Decrypter Via Delegation</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.cryptoKeyEncrypterDecrypterViaDelegation</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.cryptoKeyEncrypterViaDelegation">Cloud KMS CryptoKey Encrypter Via Delegation</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.cryptoKeyEncrypterViaDelegation</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.cryptoOperator">Cloud KMS Crypto Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.cryptoOperator</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.decapsulator">Cloud KMS CryptoKey Decapsulator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.decapsulator</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.expertPqcSigner">Cloud KMS Expert PQ Asymmetric Signing Key Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.expertPqcSigner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.expertRawAesCbc">Cloud KMS Expert Raw AES-CBC Key Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.expertRawAesCbc</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.expertRawAesCtr">Cloud KMS Expert Raw AES-CTR Key Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.expertRawAesCtr</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.expertRawPKCS1">Cloud KMS Expert Raw PKCS#1 Key Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.expertRawPKCS1</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.importer">Cloud KMS Importer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.importer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.publicKeyViewer">Cloud KMS CryptoKey Public Key Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.publicKeyViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.signer">Cloud KMS CryptoKey Signer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.signer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.signerVerifier">Cloud KMS CryptoKey Signer/Verifier</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.signerVerifier</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.verifier">Cloud KMS CryptoKey Verifier</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.verifier</code>)</p>
<p><a href="/iam/docs/roles-permissions/container#container.cloudKmsKeyUser">Kubernetes Engine KMS Crypto Key User</a> (<code class="role-name" translate="no" dir="ltr">roles/container.cloudKmsKeyUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.workloadScanner">Wiz Workload Scanner</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.workloadScanner</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="cloudkms.locations.optOutKeyDeletionMsa" class="permission-name add-link" data-text="cloudkms.locations.optOutKeyDeletionMsa" tabindex="-1"><code translate="no" dir="ltr">cloudkms.locations.optOutKeyDeletionMsa</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="cloudkms.operations.get" class="permission-name add-link" data-text="cloudkms.operations.get" tabindex="-1"><code translate="no" dir="ltr">cloudkms.operations.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/alloydb#alloydb.admin">AlloyDB Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/alloydb.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigee#apigee.admin">Apigee Organization Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigee#apigee.editor">Apigee Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apihub#apihub.admin">Cloud API Hub Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apihub.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/backupdr#backupdr.admin">Backup and DR Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/backupdr.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataEditor">BigQuery Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioUser">BigQuery Studio User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.user">BigQuery User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.viewer">Cloud KMS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.admin">Cloud SQL Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.admin">Composer Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.admin">Compute Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.instanceAdmin">Compute Instance Admin (beta)</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.instanceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.instanceAdmin.v1">Compute Instance Admin (v1)</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.instanceAdmin.v1</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.storageAdmin">Compute Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.storageAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/container#container.admin">Kubernetes Engine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/container.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/container#container.clusterAdmin">Kubernetes Engine Cluster Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/container.clusterAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.admin">Dataflow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.admin">Dataproc Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.editor">Dataproc Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/datastream#datastream.admin">Datastream Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/datastream.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/clouddocumentai#documentai.admin">Document AI Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/documentai.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/clouddocumentai#documentai.editor">Document AI Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/documentai.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/file#file.admin">Cloud Filestore Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/file.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/file#file.editor">Cloud Filestore Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/file.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkebackup#gkebackup.admin">Backup for GKE Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/gkebackup.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/memorystore#memorystore.admin">Memorystore Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/memorystore.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/pubsub#pubsub.admin">Pub/Sub Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/pubsub#pubsub.editor">Pub/Sub Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.admin">Secret Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/securesourcemanager#securesourcemanager.admin">Secure Source Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securesourcemanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/spanner#spanner.admin">Cloud Spanner Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/spanner.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/vmmigration#vmmigration.admin">VM Migration Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/vmmigration.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/workflows#workflows.admin">Workflows Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workflows.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/workflows#workflows.editor">Workflows Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/workflows.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/workstations#workstations.admin">Cloud Workstations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workstations.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apihub#apihub.provisioningAdmin">Cloud API hub Provisioning Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apihub.provisioningAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.autokeyUser">Cloud KMS Autokey User</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.autokeyUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.hsmSingleTenantExecutor">Cloud KMS single-tenant HSM Executor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.hsmSingleTenantExecutor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.hsmSingleTenantProposer">Cloud KMS single-tenant HSM Proposer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.hsmSingleTenantProposer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.hsmSingleTenantQuorumMember">Cloud KMS single-tenant HSM Quorum Member</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.hsmSingleTenantQuorumMember</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectAdmin">Environment and Storage Object Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.developer">Dataflow Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.serverlessEditor">Dataproc Serverless Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serverlessEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.legacyAdmin">Notebooks Legacy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.legacyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/securesourcemanager#securesourcemanager.instanceOwner">Secure Source Manager Instance Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/securesourcemanager.instanceOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/spanner#spanner.databaseAdmin">Cloud Spanner Database Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/spanner.databaseAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="cloudkms.projects.showEffectiveAutokeyConfig" class="permission-name add-link" data-text="cloudkms.projects.showEffectiveAutokeyConfig" tabindex="-1"><code translate="no" dir="ltr">cloudkms.projects.showEffectiveAutokeyConfig</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/alloydb#alloydb.admin">AlloyDB Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/alloydb.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigee#apigee.admin">Apigee Organization Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apigee#apigee.editor">Apigee Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/apihub#apihub.admin">Cloud API Hub Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apihub.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.admin">Artifact Registry Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/backupdr#backupdr.admin">Backup and DR Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/backupdr.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataEditor">BigQuery Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioUser">BigQuery Studio User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.user">BigQuery User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigtable#bigtable.admin">Bigtable Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigtable.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.viewer">Cloud KMS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudsql#cloudsql.admin">Cloud SQL Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsql.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.admin">Composer Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.admin">Compute Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.instanceAdmin">Compute Instance Admin (beta)</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.instanceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.instanceAdmin.v1">Compute Instance Admin (v1)</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.instanceAdmin.v1</code>)</p>
<p><a href="/iam/docs/roles-permissions/compute#compute.storageAdmin">Compute Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.storageAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/container#container.admin">Kubernetes Engine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/container.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/container#container.clusterAdmin">Kubernetes Engine Cluster Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/container.clusterAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.admin">Dataflow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.admin">Dataproc Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.editor">Dataproc Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/datastream#datastream.admin">Datastream Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/datastream.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/clouddocumentai#documentai.admin">Document AI Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/documentai.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/clouddocumentai#documentai.editor">Document AI Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/documentai.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/file#file.admin">Cloud Filestore Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/file.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/file#file.editor">Cloud Filestore Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/file.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkebackup#gkebackup.admin">Backup for GKE Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/gkebackup.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/memorystore#memorystore.admin">Memorystore Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/memorystore.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/pubsub#pubsub.admin">Pub/Sub Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/pubsub#pubsub.editor">Pub/Sub Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/secretmanager#secretmanager.admin">Secret Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/secretmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/securesourcemanager#securesourcemanager.admin">Secure Source Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securesourcemanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/spanner#spanner.admin">Cloud Spanner Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/spanner.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/vmmigration#vmmigration.admin">VM Migration Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/vmmigration.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/workflows#workflows.admin">Workflows Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workflows.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/workflows#workflows.editor">Workflows Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/workflows.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/workstations#workstations.admin">Cloud Workstations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workstations.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apihub#apihub.provisioningAdmin">Cloud API hub Provisioning Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/apihub.provisioningAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.autokeyAdmin">Cloud KMS Autokey Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.autokeyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.autokeyUser">Cloud KMS Autokey User</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.autokeyUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectAdmin">Environment and Storage Object Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.developer">Dataflow Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.serverlessEditor">Dataproc Serverless Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serverlessEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/notebooks#notebooks.legacyAdmin">Notebooks Legacy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.legacyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/securesourcemanager#securesourcemanager.instanceOwner">Secure Source Manager Instance Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/securesourcemanager.instanceOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/spanner#spanner.databaseAdmin">Cloud Spanner Database Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/spanner.databaseAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="cloudkms.projects.showEffectiveKajEnrollmentConfig" class="permission-name add-link" data-text="cloudkms.projects.showEffectiveKajEnrollmentConfig" tabindex="-1"><code translate="no" dir="ltr">cloudkms.projects.showEffectiveKajEnrollmentConfig</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.viewer">Cloud KMS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.keyAccessJustificationsEnrollmentConfigViewer">Key Access Justifications Enrollment Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.keyAccessJustificationsEnrollmentConfigViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="cloudkms.projects.showEffectiveKajPolicyConfig" class="permission-name add-link" data-text="cloudkms.projects.showEffectiveKajPolicyConfig" tabindex="-1"><code translate="no" dir="ltr">cloudkms.projects.showEffectiveKajPolicyConfig</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.viewer">Cloud KMS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.keyAccessJustificationsPolicyConfigAdmin">Key Access Justifications Policy Config Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.keyAccessJustificationsPolicyConfigAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="cloudkms.protectableResources.list" class="permission-name add-link" data-text="cloudkms.protectableResources.list" tabindex="-1"><code translate="no" dir="ltr">cloudkms.protectableResources.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.viewer">Cloud KMS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.encryptionDashboardViewer">Cloud KMS Encryption Dashboard Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.encryptionDashboardViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="cloudkms.protectedResources.search" class="permission-name add-link" data-text="cloudkms.protectedResources.search" tabindex="-1"><code translate="no" dir="ltr">cloudkms.protectedResources.search</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.viewer">Cloud KMS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.protectedResourcesViewer">Cloud KMS Protected Resources Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.protectedResourcesViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="cloudkms.retiredResources.get" class="permission-name add-link" data-text="cloudkms.retiredResources.get" tabindex="-1"><code translate="no" dir="ltr">cloudkms.retiredResources.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.viewer">Cloud KMS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="cloudkms.retiredResources.list" class="permission-name add-link" data-text="cloudkms.retiredResources.list" tabindex="-1"><code translate="no" dir="ltr">cloudkms.retiredResources.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.viewer">Cloud KMS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="cloudkms.singleTenantHsmInstanceProposals.approve" class="permission-name add-link" data-text="cloudkms.singleTenantHsmInstanceProposals.approve" tabindex="-1"><code translate="no" dir="ltr">cloudkms.singleTenantHsmInstanceProposals.approve</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.hsmSingleTenantQuorumMember">Cloud KMS single-tenant HSM Quorum Member</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.hsmSingleTenantQuorumMember</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="cloudkms.singleTenantHsmInstanceProposals.create" class="permission-name add-link" data-text="cloudkms.singleTenantHsmInstanceProposals.create" tabindex="-1"><code translate="no" dir="ltr">cloudkms.singleTenantHsmInstanceProposals.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.hsmSingleTenantProposer">Cloud KMS single-tenant HSM Proposer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.hsmSingleTenantProposer</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="cloudkms.singleTenantHsmInstanceProposals.delete" class="permission-name add-link" data-text="cloudkms.singleTenantHsmInstanceProposals.delete" tabindex="-1"><code translate="no" dir="ltr">cloudkms.singleTenantHsmInstanceProposals.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.hsmSingleTenantProposer">Cloud KMS single-tenant HSM Proposer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.hsmSingleTenantProposer</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="cloudkms.singleTenantHsmInstanceProposals.execute" class="permission-name add-link" data-text="cloudkms.singleTenantHsmInstanceProposals.execute" tabindex="-1"><code translate="no" dir="ltr">cloudkms.singleTenantHsmInstanceProposals.execute</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.hsmSingleTenantExecutor">Cloud KMS single-tenant HSM Executor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.hsmSingleTenantExecutor</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="cloudkms.singleTenantHsmInstanceProposals.get" class="permission-name add-link" data-text="cloudkms.singleTenantHsmInstanceProposals.get" tabindex="-1"><code translate="no" dir="ltr">cloudkms.singleTenantHsmInstanceProposals.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.viewer">Cloud KMS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.hsmSingleTenantExecutor">Cloud KMS single-tenant HSM Executor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.hsmSingleTenantExecutor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.hsmSingleTenantProposer">Cloud KMS single-tenant HSM Proposer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.hsmSingleTenantProposer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.hsmSingleTenantQuorumMember">Cloud KMS single-tenant HSM Quorum Member</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.hsmSingleTenantQuorumMember</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="cloudkms.singleTenantHsmInstanceProposals.list" class="permission-name add-link" data-text="cloudkms.singleTenantHsmInstanceProposals.list" tabindex="-1"><code translate="no" dir="ltr">cloudkms.singleTenantHsmInstanceProposals.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.viewer">Cloud KMS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.hsmSingleTenantExecutor">Cloud KMS single-tenant HSM Executor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.hsmSingleTenantExecutor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.hsmSingleTenantProposer">Cloud KMS single-tenant HSM Proposer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.hsmSingleTenantProposer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.hsmSingleTenantQuorumMember">Cloud KMS single-tenant HSM Quorum Member</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.hsmSingleTenantQuorumMember</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="cloudkms.singleTenantHsmInstances.create" class="permission-name add-link" data-text="cloudkms.singleTenantHsmInstances.create" tabindex="-1"><code translate="no" dir="ltr">cloudkms.singleTenantHsmInstances.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.hsmSingleTenantProposer">Cloud KMS single-tenant HSM Proposer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.hsmSingleTenantProposer</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="cloudkms.singleTenantHsmInstances.get" class="permission-name add-link" data-text="cloudkms.singleTenantHsmInstances.get" tabindex="-1"><code translate="no" dir="ltr">cloudkms.singleTenantHsmInstances.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.viewer">Cloud KMS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.hsmSingleTenantExecutor">Cloud KMS single-tenant HSM Executor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.hsmSingleTenantExecutor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.hsmSingleTenantKeyCreator">Cloud KMS single-tenant HSM Key Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.hsmSingleTenantKeyCreator</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.hsmSingleTenantProposer">Cloud KMS single-tenant HSM Proposer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.hsmSingleTenantProposer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.hsmSingleTenantQuorumMember">Cloud KMS single-tenant HSM Quorum Member</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.hsmSingleTenantQuorumMember</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="cloudkms.singleTenantHsmInstances.list" class="permission-name add-link" data-text="cloudkms.singleTenantHsmInstances.list" tabindex="-1"><code translate="no" dir="ltr">cloudkms.singleTenantHsmInstances.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.viewer">Cloud KMS Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.hsmSingleTenantExecutor">Cloud KMS single-tenant HSM Executor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.hsmSingleTenantExecutor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.hsmSingleTenantKeyCreator">Cloud KMS single-tenant HSM Key Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.hsmSingleTenantKeyCreator</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.hsmSingleTenantProposer">Cloud KMS single-tenant HSM Proposer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.hsmSingleTenantProposer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.hsmSingleTenantQuorumMember">Cloud KMS single-tenant HSM Quorum Member</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.hsmSingleTenantQuorumMember</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="cloudkms.singleTenantHsmInstances.use" class="permission-name add-link" data-text="cloudkms.singleTenantHsmInstances.use" tabindex="-1"><code translate="no" dir="ltr">cloudkms.singleTenantHsmInstances.use</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.admin">Cloud KMS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudkms#cloudkms.hsmSingleTenantKeyCreator">Cloud KMS single-tenant HSM Key Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudkms.hsmSingleTenantKeyCreator</code>)</p></td>
</tr>
</tbody>
</table>

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
