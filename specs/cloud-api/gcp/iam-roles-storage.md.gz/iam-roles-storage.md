# Cloud Storage roles and permissions

<div class="devsite-article-body clearfix">

This page lists the IAM roles and permissions for Cloud Storage. To search through all roles and permissions, see the [role and permission index](/iam/docs/roles-permissions).

## Cloud Storage roles

<div results-count-container="">

</div>

<table class="fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="50%">Role</th>
<th>Permissions</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td class="role-description"><h4 id="storage.admin" class="role-title add-link" data-text="Storage Admin " tabindex="-1">Storage Admin</h4>
<p>(<code translate="no" dir="ltr">roles/storage.admin</code>)</p>
<span class="role-description custom"> </span>
<p>Grants full control of objects and buckets.</p>
<p>When applied to an individual <strong>bucket</strong>, control applies only to the specified bucket and objects within the bucket.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Bucket</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudaicompanion.instances.completeTask</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudkms.keyHandles.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudkms.keyHandles.create</code></li>
<li><code translate="no" dir="ltr">cloudkms.keyHandles.get</code></li>
<li><code translate="no" dir="ltr">cloudkms.keyHandles.list</code></li>
</ul>
<p><code translate="no" dir="ltr">cloudkms.operations.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.projects.showEffectiveAutokeyConfig</code></p>
<p><code translate="no" dir="ltr">firebase.projects.get</code></p>
<p><code translate="no" dir="ltr">monitoring.dashboards.get</code></p>
<p><code translate="no" dir="ltr">monitoring.dashboards.list</code></p>
<p><code translate="no" dir="ltr">monitoring.groups.get</code></p>
<p><code translate="no" dir="ltr">monitoring.groups.list</code></p>
<p><code translate="no" dir="ltr">monitoring.metricDescriptors.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">monitoring.monitoredResourceDescriptors.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">monitoring.monitoredResourceDescriptors.get</code></li>
<li><code translate="no" dir="ltr">monitoring.monitoredResourceDescriptors.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">monitoring.timeSeries.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">monitoring.timeSeries.create</code></li>
<li><code translate="no" dir="ltr">monitoring.timeSeries.list</code></li>
</ul>
<p><code translate="no" dir="ltr">orgpolicy.policy.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.iamPolicyInsights.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.iamPolicyInsights.get</code></li>
<li><code translate="no" dir="ltr">recommender.iamPolicyInsights.list</code></li>
<li><code translate="no" dir="ltr">recommender.iamPolicyInsights.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.iamPolicyRecommendations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.iamPolicyRecommendations.get</code></li>
<li><code translate="no" dir="ltr">recommender.iamPolicyRecommendations.list</code></li>
<li><code translate="no" dir="ltr">recommender.iamPolicyRecommendations.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.storageBucketSoftDeleteInsights.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.storageBucketSoftDeleteInsights.get</code></li>
<li><code translate="no" dir="ltr">recommender.storageBucketSoftDeleteInsights.list</code></li>
<li><code translate="no" dir="ltr">recommender.storageBucketSoftDeleteInsights.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.storageBucketSoftDeleteRecommendations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.storageBucketSoftDeleteRecommendations.get</code></li>
<li><code translate="no" dir="ltr">recommender.storageBucketSoftDeleteRecommendations.list</code></li>
<li><code translate="no" dir="ltr">recommender.storageBucketSoftDeleteRecommendations.update</code></li>
</ul>
<p><code translate="no" dir="ltr">resourcemanager.hierarchyNodes.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><code translate="no" dir="ltr">stackdriver.projects.get</code></p>
<p><code translate="no" dir="ltr">stackdriver.resourceMetadata.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.anywhereCaches.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.anywhereCaches.create</code></li>
<li><code translate="no" dir="ltr">storage.anywhereCaches.disable</code></li>
<li><code translate="no" dir="ltr">storage.anywhereCaches.get</code></li>
<li><code translate="no" dir="ltr">storage.anywhereCaches.list</code></li>
<li><code translate="no" dir="ltr">storage.anywhereCaches.pause</code></li>
<li><code translate="no" dir="ltr">storage.anywhereCaches.resume</code></li>
<li><code translate="no" dir="ltr">storage.anywhereCaches.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.bucketOperations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.bucketOperations.cancel</code></li>
<li><code translate="no" dir="ltr">storage.bucketOperations.get</code></li>
<li><code translate="no" dir="ltr">storage.bucketOperations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.buckets.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.buckets.create</code></li>
<li><code translate="no" dir="ltr">storage.buckets.createTagBinding</code></li>
<li><code translate="no" dir="ltr">storage.buckets.delete</code></li>
<li><code translate="no" dir="ltr">storage.buckets.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">storage.buckets.enableObjectRetention</code></li>
<li><code translate="no" dir="ltr">storage.buckets.get</code></li>
<li><code translate="no" dir="ltr">storage.buckets.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">storage.buckets.getIpFilter</code></li>
<li><code translate="no" dir="ltr">storage.buckets.getObjectInsights</code></li>
<li><code translate="no" dir="ltr">storage.buckets.list</code></li>
<li><code translate="no" dir="ltr">storage.buckets.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">storage.buckets.listTagBindings</code></li>
<li><code translate="no" dir="ltr">storage.buckets.relocate</code></li>
<li><code translate="no" dir="ltr">storage.buckets.restore</code></li>
<li><code translate="no" dir="ltr">storage.buckets.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">storage.buckets.setIpFilter</code></li>
<li><code translate="no" dir="ltr">storage.buckets.update</code></li>
<li><code translate="no" dir="ltr">storage.buckets.viewIntelligenceDetails</code></li>
<li><code translate="no" dir="ltr">storage.buckets.viewSecurityIntelligenceDetails</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.featureConfigs.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.featureConfigs.create</code></li>
<li><code translate="no" dir="ltr">storage.featureConfigs.delete</code></li>
<li><code translate="no" dir="ltr">storage.featureConfigs.get</code></li>
<li><code translate="no" dir="ltr">storage.featureConfigs.list</code></li>
<li><code translate="no" dir="ltr">storage.featureConfigs.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.folders.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.folders.create</code></li>
<li><code translate="no" dir="ltr">storage.folders.delete</code></li>
<li><code translate="no" dir="ltr">storage.folders.get</code></li>
<li><code translate="no" dir="ltr">storage.folders.list</code></li>
<li><code translate="no" dir="ltr">storage.folders.rename</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.intelligenceConfigs.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.intelligenceConfigs.get</code></li>
<li><code translate="no" dir="ltr">storage.intelligenceConfigs.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.managedFolders.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.managedFolders.create</code></li>
<li><code translate="no" dir="ltr">storage.managedFolders.delete</code></li>
<li><code translate="no" dir="ltr">storage.managedFolders.get</code></li>
<li><code translate="no" dir="ltr">storage.managedFolders.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">storage.managedFolders.list</code></li>
<li><code translate="no" dir="ltr">storage.managedFolders.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">storage.managedFolders.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.multipartUploads.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.multipartUploads.abort</code></li>
<li><code translate="no" dir="ltr">storage.multipartUploads.create</code></li>
<li><code translate="no" dir="ltr">storage.multipartUploads.list</code></li>
<li><code translate="no" dir="ltr">storage.multipartUploads.listParts</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.objects.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.objects.create</code></li>
<li><code translate="no" dir="ltr">storage.objects.createContext</code></li>
<li><code translate="no" dir="ltr">storage.objects.delete</code></li>
<li><code translate="no" dir="ltr">storage.objects.deleteContext</code></li>
<li><code translate="no" dir="ltr">storage.objects.get</code></li>
<li><code translate="no" dir="ltr">storage.objects.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">storage.objects.list</code></li>
<li><code translate="no" dir="ltr">storage.objects.move</code></li>
<li><code translate="no" dir="ltr">storage.objects.overrideUnlockedRetention</code></li>
<li><code translate="no" dir="ltr">storage.objects.restore</code></li>
<li><code translate="no" dir="ltr">storage.objects.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">storage.objects.setRetention</code></li>
<li><code translate="no" dir="ltr">storage.objects.update</code></li>
<li><code translate="no" dir="ltr">storage.objects.updateContext</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storagebatchoperations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storagebatchoperations.bucketOperations.get</code></li>
<li><code translate="no" dir="ltr">storagebatchoperations.bucketOperations.list</code></li>
<li><code translate="no" dir="ltr">storagebatchoperations.jobs.cancel</code></li>
<li><code translate="no" dir="ltr">storagebatchoperations.jobs.create</code></li>
<li><code translate="no" dir="ltr">storagebatchoperations.jobs.delete</code></li>
<li><code translate="no" dir="ltr">storagebatchoperations.jobs.get</code></li>
<li><code translate="no" dir="ltr">storagebatchoperations.jobs.list</code></li>
<li><code translate="no" dir="ltr">storagebatchoperations.locations.get</code></li>
<li><code translate="no" dir="ltr">storagebatchoperations.locations.list</code></li>
<li><code translate="no" dir="ltr">storagebatchoperations.operations.cancel</code></li>
<li><code translate="no" dir="ltr">storagebatchoperations.operations.delete</code></li>
<li><code translate="no" dir="ltr">storagebatchoperations.operations.get</code></li>
<li><code translate="no" dir="ltr">storagebatchoperations.operations.list</code></li>
</ul></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="storage.bucketViewer" class="role-title add-link" data-text="Storage Bucket Viewer Beta " tabindex="-1">Storage Bucket Viewer <sup>Beta</sup></h4>
<p>(<code translate="no" dir="ltr">roles/storage.bucketViewer</code>)</p>
<span class="role-description"> </span>
<p>Grants permission to view buckets and their metadata, excluding IAM policies.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Bucket</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">storage.buckets.get</code></p>
<p><code translate="no" dir="ltr">storage.buckets.list</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="storage.editor" class="role-title add-link" data-text="Storage Editor " tabindex="-1">Storage Editor</h4>
<p>(<code translate="no" dir="ltr">roles/storage.editor</code>)</p>
<span class="role-description"> </span>
<p>Editor role for storage</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Managed folder</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><code translate="no" dir="ltr">storage.buckets.create</code></p>
<p><code translate="no" dir="ltr">storage.buckets.delete</code></p>
<p><code translate="no" dir="ltr">storage.buckets.list</code></p>
<p><code translate="no" dir="ltr">storage.buckets.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">storage.buckets.listTagBindings</code></p>
<p><code translate="no" dir="ltr">storage.buckets.viewIntelligenceDetails</code></p>
<p><code translate="no" dir="ltr">storage.buckets.viewSecurityIntelligenceDetails</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.featureConfigs.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.featureConfigs.create</code></li>
<li><code translate="no" dir="ltr">storage.featureConfigs.delete</code></li>
<li><code translate="no" dir="ltr">storage.featureConfigs.get</code></li>
<li><code translate="no" dir="ltr">storage.featureConfigs.list</code></li>
<li><code translate="no" dir="ltr">storage.featureConfigs.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.folders.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.folders.create</code></li>
<li><code translate="no" dir="ltr">storage.folders.delete</code></li>
<li><code translate="no" dir="ltr">storage.folders.get</code></li>
<li><code translate="no" dir="ltr">storage.folders.list</code></li>
<li><code translate="no" dir="ltr">storage.folders.rename</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.hmacKeys.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.hmacKeys.create</code></li>
<li><code translate="no" dir="ltr">storage.hmacKeys.delete</code></li>
<li><code translate="no" dir="ltr">storage.hmacKeys.get</code></li>
<li><code translate="no" dir="ltr">storage.hmacKeys.list</code></li>
<li><code translate="no" dir="ltr">storage.hmacKeys.update</code></li>
</ul>
<p><code translate="no" dir="ltr">storage.intelligenceConfigs.get</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="storage.folderAdmin" class="role-title add-link" data-text="Storage Folder Admin " tabindex="-1">Storage Folder Admin</h4>
<p>(<code translate="no" dir="ltr">roles/storage.folderAdmin</code>)</p>
<span class="role-description"> </span>
<p>Grants full control over folders and objects, including listing, creating, viewing, and deleting objects.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Managed folder</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">orgpolicy.policy.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.folders.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.folders.create</code></li>
<li><code translate="no" dir="ltr">storage.folders.delete</code></li>
<li><code translate="no" dir="ltr">storage.folders.get</code></li>
<li><code translate="no" dir="ltr">storage.folders.list</code></li>
<li><code translate="no" dir="ltr">storage.folders.rename</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.managedFolders.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.managedFolders.create</code></li>
<li><code translate="no" dir="ltr">storage.managedFolders.delete</code></li>
<li><code translate="no" dir="ltr">storage.managedFolders.get</code></li>
<li><code translate="no" dir="ltr">storage.managedFolders.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">storage.managedFolders.list</code></li>
<li><code translate="no" dir="ltr">storage.managedFolders.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">storage.managedFolders.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.multipartUploads.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.multipartUploads.abort</code></li>
<li><code translate="no" dir="ltr">storage.multipartUploads.create</code></li>
<li><code translate="no" dir="ltr">storage.multipartUploads.list</code></li>
<li><code translate="no" dir="ltr">storage.multipartUploads.listParts</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.objects.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.objects.create</code></li>
<li><code translate="no" dir="ltr">storage.objects.createContext</code></li>
<li><code translate="no" dir="ltr">storage.objects.delete</code></li>
<li><code translate="no" dir="ltr">storage.objects.deleteContext</code></li>
<li><code translate="no" dir="ltr">storage.objects.get</code></li>
<li><code translate="no" dir="ltr">storage.objects.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">storage.objects.list</code></li>
<li><code translate="no" dir="ltr">storage.objects.move</code></li>
<li><code translate="no" dir="ltr">storage.objects.overrideUnlockedRetention</code></li>
<li><code translate="no" dir="ltr">storage.objects.restore</code></li>
<li><code translate="no" dir="ltr">storage.objects.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">storage.objects.setRetention</code></li>
<li><code translate="no" dir="ltr">storage.objects.update</code></li>
<li><code translate="no" dir="ltr">storage.objects.updateContext</code></li>
</ul></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="storage.legacyBucketOwner" class="role-title add-link" data-text="Storage Legacy Bucket Owner " tabindex="-1">Storage Legacy Bucket Owner</h4>
<p>(<code translate="no" dir="ltr">roles/storage.legacyBucketOwner</code>)</p>
<span class="role-description custom"> </span>
<p>Grants permission to create, overwrite, and delete objects; list objects in a bucket and read object metadata, excluding allow policies, when listing; and read and edit bucket metadata, including allow policies.</p>
<p>Use of this role is also reflected in the bucket's ACLs. For more information, see <a href="/storage/docs/access-control/iam#acls">IAM relation to ACLs</a>.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Bucket</li>
</ul></td>
<td class="role-permissions"><p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.anywhereCaches.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.anywhereCaches.create</code></li>
<li><code translate="no" dir="ltr">storage.anywhereCaches.disable</code></li>
<li><code translate="no" dir="ltr">storage.anywhereCaches.get</code></li>
<li><code translate="no" dir="ltr">storage.anywhereCaches.list</code></li>
<li><code translate="no" dir="ltr">storage.anywhereCaches.pause</code></li>
<li><code translate="no" dir="ltr">storage.anywhereCaches.resume</code></li>
<li><code translate="no" dir="ltr">storage.anywhereCaches.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.bucketOperations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.bucketOperations.cancel</code></li>
<li><code translate="no" dir="ltr">storage.bucketOperations.get</code></li>
<li><code translate="no" dir="ltr">storage.bucketOperations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">storage.buckets.createTagBinding</code></p>
<p><code translate="no" dir="ltr">storage.buckets.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">storage.buckets.enableObjectRetention</code></p>
<p><code translate="no" dir="ltr">storage.buckets.get</code></p>
<p><code translate="no" dir="ltr">storage.buckets.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">storage.buckets.getIpFilter</code></p>
<p><code translate="no" dir="ltr">storage.buckets.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">storage.buckets.listTagBindings</code></p>
<p><code translate="no" dir="ltr">storage.buckets.relocate</code></p>
<p><code translate="no" dir="ltr">storage.buckets.restore</code></p>
<p><code translate="no" dir="ltr">storage.buckets.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">storage.buckets.setIpFilter</code></p>
<p><code translate="no" dir="ltr">storage.buckets.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.folders.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.folders.create</code></li>
<li><code translate="no" dir="ltr">storage.folders.delete</code></li>
<li><code translate="no" dir="ltr">storage.folders.get</code></li>
<li><code translate="no" dir="ltr">storage.folders.list</code></li>
<li><code translate="no" dir="ltr">storage.folders.rename</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.managedFolders.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.managedFolders.create</code></li>
<li><code translate="no" dir="ltr">storage.managedFolders.delete</code></li>
<li><code translate="no" dir="ltr">storage.managedFolders.get</code></li>
<li><code translate="no" dir="ltr">storage.managedFolders.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">storage.managedFolders.list</code></li>
<li><code translate="no" dir="ltr">storage.managedFolders.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">storage.managedFolders.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.multipartUploads.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.multipartUploads.abort</code></li>
<li><code translate="no" dir="ltr">storage.multipartUploads.create</code></li>
<li><code translate="no" dir="ltr">storage.multipartUploads.list</code></li>
<li><code translate="no" dir="ltr">storage.multipartUploads.listParts</code></li>
</ul>
<p><code translate="no" dir="ltr">storage.objects.create</code></p>
<p><code translate="no" dir="ltr">storage.objects.createContext</code></p>
<p><code translate="no" dir="ltr">storage.objects.delete</code></p>
<p><code translate="no" dir="ltr">storage.objects.deleteContext</code></p>
<p><code translate="no" dir="ltr">storage.objects.list</code></p>
<p><code translate="no" dir="ltr">storage.objects.restore</code></p>
<p><code translate="no" dir="ltr">storage.objects.setRetention</code></p>
<p><code translate="no" dir="ltr">storage.objects.updateContext</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="storage.legacyBucketReader" class="role-title add-link" data-text="Storage Legacy Bucket Reader " tabindex="-1">Storage Legacy Bucket Reader</h4>
<p>(<code translate="no" dir="ltr">roles/storage.legacyBucketReader</code>)</p>
<span class="role-description custom"> </span>
<p>Grants permission to list a bucket's contents and read bucket metadata, excluding allow policies. Also grants permission to read object metadata, excluding allow policies, when listing objects.</p>
<p>Use of this role is also reflected in the bucket's ACLs. For more information, see <a href="/storage/docs/access-control/iam#acls">IAM relation to ACLs</a>.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Bucket</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">storage.buckets.get</code></p>
<p><code translate="no" dir="ltr">storage.folders.get</code></p>
<p><code translate="no" dir="ltr">storage.folders.list</code></p>
<p><code translate="no" dir="ltr">storage.managedFolders.get</code></p>
<p><code translate="no" dir="ltr">storage.managedFolders.list</code></p>
<p><code translate="no" dir="ltr">storage.multipartUploads.list</code></p>
<p><code translate="no" dir="ltr">storage.objects.list</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="storage.legacyBucketWriter" class="role-title add-link" data-text="Storage Legacy Bucket Writer " tabindex="-1">Storage Legacy Bucket Writer</h4>
<p>(<code translate="no" dir="ltr">roles/storage.legacyBucketWriter</code>)</p>
<span class="role-description custom"> </span>
<p>Grants permission to create, overwrite, and delete objects; list objects in a bucket and read object metadata, excluding allow policies, when listing; and read bucket metadata, excluding allow policies.</p>
<p>Use of this role is also reflected in the bucket's ACLs. For more information, see <a href="/storage/docs/access-control/iam#acls">IAM relation to ACLs</a>.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Bucket</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">storage.buckets.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.folders.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.folders.create</code></li>
<li><code translate="no" dir="ltr">storage.folders.delete</code></li>
<li><code translate="no" dir="ltr">storage.folders.get</code></li>
<li><code translate="no" dir="ltr">storage.folders.list</code></li>
<li><code translate="no" dir="ltr">storage.folders.rename</code></li>
</ul>
<p><code translate="no" dir="ltr">storage.managedFolders.create</code></p>
<p><code translate="no" dir="ltr">storage.managedFolders.delete</code></p>
<p><code translate="no" dir="ltr">storage.managedFolders.get</code></p>
<p><code translate="no" dir="ltr">storage.managedFolders.list</code></p>
<p><code translate="no" dir="ltr">storage.managedFolders.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.multipartUploads.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.multipartUploads.abort</code></li>
<li><code translate="no" dir="ltr">storage.multipartUploads.create</code></li>
<li><code translate="no" dir="ltr">storage.multipartUploads.list</code></li>
<li><code translate="no" dir="ltr">storage.multipartUploads.listParts</code></li>
</ul>
<p><code translate="no" dir="ltr">storage.objects.create</code></p>
<p><code translate="no" dir="ltr">storage.objects.createContext</code></p>
<p><code translate="no" dir="ltr">storage.objects.delete</code></p>
<p><code translate="no" dir="ltr">storage.objects.list</code></p>
<p><code translate="no" dir="ltr">storage.objects.restore</code></p>
<p><code translate="no" dir="ltr">storage.objects.setRetention</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="storage.legacyObjectOwner" class="role-title add-link" data-text="Storage Legacy Object Owner " tabindex="-1">Storage Legacy Object Owner</h4>
<p>(<code translate="no" dir="ltr">roles/storage.legacyObjectOwner</code>)</p>
<span class="role-description custom"> </span>
<p>Grants permission to view and edit objects and their metadata, including ACLs.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Managed folder</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">storage.objects.createContext</code></p>
<p><code translate="no" dir="ltr">storage.objects.deleteContext</code></p>
<p><code translate="no" dir="ltr">storage.objects.get</code></p>
<p><code translate="no" dir="ltr">storage.objects.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">storage.objects.overrideUnlockedRetention</code></p>
<p><code translate="no" dir="ltr">storage.objects.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">storage.objects.setRetention</code></p>
<p><code translate="no" dir="ltr">storage.objects.update</code></p>
<p><code translate="no" dir="ltr">storage.objects.updateContext</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="storage.legacyObjectReader" class="role-title add-link" data-text="Storage Legacy Object Reader " tabindex="-1">Storage Legacy Object Reader</h4>
<p>(<code translate="no" dir="ltr">roles/storage.legacyObjectReader</code>)</p>
<span class="role-description custom"> </span>
<p>Grants permission to view objects and their metadata, excluding ACLs.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Managed folder</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">storage.objects.get</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="storage.objectAdmin" class="role-title add-link" data-text="Storage Object Admin " tabindex="-1">Storage Object Admin</h4>
<p>(<code translate="no" dir="ltr">roles/storage.objectAdmin</code>)</p>
<span class="role-description custom"> </span>
<p>Grants full control of objects, including listing, creating, viewing, and deleting objects.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Managed folder</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">monitoring.timeSeries.create</code></p>
<p><code translate="no" dir="ltr">orgpolicy.policy.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.folders.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.folders.create</code></li>
<li><code translate="no" dir="ltr">storage.folders.delete</code></li>
<li><code translate="no" dir="ltr">storage.folders.get</code></li>
<li><code translate="no" dir="ltr">storage.folders.list</code></li>
<li><code translate="no" dir="ltr">storage.folders.rename</code></li>
</ul>
<p><code translate="no" dir="ltr">storage.managedFolders.create</code></p>
<p><code translate="no" dir="ltr">storage.managedFolders.delete</code></p>
<p><code translate="no" dir="ltr">storage.managedFolders.get</code></p>
<p><code translate="no" dir="ltr">storage.managedFolders.list</code></p>
<p><code translate="no" dir="ltr">storage.managedFolders.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.multipartUploads.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.multipartUploads.abort</code></li>
<li><code translate="no" dir="ltr">storage.multipartUploads.create</code></li>
<li><code translate="no" dir="ltr">storage.multipartUploads.list</code></li>
<li><code translate="no" dir="ltr">storage.multipartUploads.listParts</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.objects.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.objects.create</code></li>
<li><code translate="no" dir="ltr">storage.objects.createContext</code></li>
<li><code translate="no" dir="ltr">storage.objects.delete</code></li>
<li><code translate="no" dir="ltr">storage.objects.deleteContext</code></li>
<li><code translate="no" dir="ltr">storage.objects.get</code></li>
<li><code translate="no" dir="ltr">storage.objects.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">storage.objects.list</code></li>
<li><code translate="no" dir="ltr">storage.objects.move</code></li>
<li><code translate="no" dir="ltr">storage.objects.overrideUnlockedRetention</code></li>
<li><code translate="no" dir="ltr">storage.objects.restore</code></li>
<li><code translate="no" dir="ltr">storage.objects.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">storage.objects.setRetention</code></li>
<li><code translate="no" dir="ltr">storage.objects.update</code></li>
<li><code translate="no" dir="ltr">storage.objects.updateContext</code></li>
</ul></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="storage.objectCreator" class="role-title add-link" data-text="Storage Object Creator " tabindex="-1">Storage Object Creator</h4>
<p>(<code translate="no" dir="ltr">roles/storage.objectCreator</code>)</p>
<span class="role-description custom"> </span>
<p>Allows users to create objects. Does not give permission to view, delete, or overwrite objects.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Managed folder</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">orgpolicy.policy.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><code translate="no" dir="ltr">storage.folders.create</code></p>
<p><code translate="no" dir="ltr">storage.managedFolders.create</code></p>
<p><code translate="no" dir="ltr">storage.multipartUploads.abort</code></p>
<p><code translate="no" dir="ltr">storage.multipartUploads.create</code></p>
<p><code translate="no" dir="ltr">storage.multipartUploads.listParts</code></p>
<p><code translate="no" dir="ltr">storage.objects.create</code></p>
<p><code translate="no" dir="ltr">storage.objects.createContext</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="storage.objectUser" class="role-title add-link" data-text="Storage Object User " tabindex="-1">Storage Object User</h4>
<p>(<code translate="no" dir="ltr">roles/storage.objectUser</code>)</p>
<span class="role-description"> </span>
<p>Access to create, read, update and delete objects and multipart uploads in GCS.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Managed folder</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">monitoring.timeSeries.create</code></p>
<p><code translate="no" dir="ltr">orgpolicy.policy.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.folders.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.folders.create</code></li>
<li><code translate="no" dir="ltr">storage.folders.delete</code></li>
<li><code translate="no" dir="ltr">storage.folders.get</code></li>
<li><code translate="no" dir="ltr">storage.folders.list</code></li>
<li><code translate="no" dir="ltr">storage.folders.rename</code></li>
</ul>
<p><code translate="no" dir="ltr">storage.managedFolders.create</code></p>
<p><code translate="no" dir="ltr">storage.managedFolders.delete</code></p>
<p><code translate="no" dir="ltr">storage.managedFolders.get</code></p>
<p><code translate="no" dir="ltr">storage.managedFolders.list</code></p>
<p><code translate="no" dir="ltr">storage.managedFolders.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.multipartUploads.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.multipartUploads.abort</code></li>
<li><code translate="no" dir="ltr">storage.multipartUploads.create</code></li>
<li><code translate="no" dir="ltr">storage.multipartUploads.list</code></li>
<li><code translate="no" dir="ltr">storage.multipartUploads.listParts</code></li>
</ul>
<p><code translate="no" dir="ltr">storage.objects.create</code></p>
<p><code translate="no" dir="ltr">storage.objects.createContext</code></p>
<p><code translate="no" dir="ltr">storage.objects.delete</code></p>
<p><code translate="no" dir="ltr">storage.objects.deleteContext</code></p>
<p><code translate="no" dir="ltr">storage.objects.get</code></p>
<p><code translate="no" dir="ltr">storage.objects.list</code></p>
<p><code translate="no" dir="ltr">storage.objects.move</code></p>
<p><code translate="no" dir="ltr">storage.objects.restore</code></p>
<p><code translate="no" dir="ltr">storage.objects.update</code></p>
<p><code translate="no" dir="ltr">storage.objects.updateContext</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="storage.objectViewer" class="role-title add-link" data-text="Storage Object Viewer " tabindex="-1">Storage Object Viewer</h4>
<p>(<code translate="no" dir="ltr">roles/storage.objectViewer</code>)</p>
<span class="role-description custom"> </span>
<p>Grants access to view objects and their metadata, excluding ACLs. Can also list the objects in a bucket.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Managed folder</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><code translate="no" dir="ltr">storage.folders.get</code></p>
<p><code translate="no" dir="ltr">storage.folders.list</code></p>
<p><code translate="no" dir="ltr">storage.managedFolders.get</code></p>
<p><code translate="no" dir="ltr">storage.managedFolders.list</code></p>
<p><code translate="no" dir="ltr">storage.objects.get</code></p>
<p><code translate="no" dir="ltr">storage.objects.list</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="storage.viewer" class="role-title add-link" data-text="Storage Viewer " tabindex="-1">Storage Viewer</h4>
<p>(<code translate="no" dir="ltr">roles/storage.viewer</code>)</p>
<span class="role-description"> </span>
<p>Viewer role for storage</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Managed folder</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><code translate="no" dir="ltr">storage.buckets.list</code></p>
<p><code translate="no" dir="ltr">storage.buckets.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">storage.buckets.listTagBindings</code></p>
<p><code translate="no" dir="ltr">storage.buckets.viewIntelligenceDetails</code></p>
<p><code translate="no" dir="ltr">storage.buckets.viewSecurityIntelligenceDetails</code></p>
<p><code translate="no" dir="ltr">storage.featureConfigs.get</code></p>
<p><code translate="no" dir="ltr">storage.featureConfigs.list</code></p>
<p><code translate="no" dir="ltr">storage.folders.get</code></p>
<p><code translate="no" dir="ltr">storage.folders.list</code></p>
<p><code translate="no" dir="ltr">storage.hmacKeys.get</code></p>
<p><code translate="no" dir="ltr">storage.hmacKeys.list</code></p>
<p><code translate="no" dir="ltr">storage.intelligenceConfigs.get</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="storage.annotationGeneratorService" class="role-title add-link" data-text="Storage Annotation Generator Service Beta " tabindex="-1">Storage Annotation Generator Service <sup>Beta</sup></h4>
<p>(<code translate="no" dir="ltr">roles/storage.annotationGeneratorService</code>)</p>
<span class="role-description"> </span>
<p>Grants all permissions needed to generate annotations for objects in a bucket.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Managed folder</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">storage.objects.createContext</code></p>
<p><code translate="no" dir="ltr">storage.objects.deleteContext</code></p>
<p><code translate="no" dir="ltr">storage.objects.get</code></p>
<p><code translate="no" dir="ltr">storage.objects.list</code></p>
<p><code translate="no" dir="ltr">storage.objects.update</code></p>
<p><code translate="no" dir="ltr">storage.objects.updateContext</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="storage.expressModeServiceInput" class="role-title add-link" data-text="Storage Express Mode Service Input Beta " tabindex="-1">Storage Express Mode Service Input <sup>Beta</sup></h4>
<p>(<code translate="no" dir="ltr">roles/storage.expressModeServiceInput</code>)</p>
<span class="role-description"> </span>
<p>Grants permission to Express Mode service accounts at a managed folder so they can create objects but not read them on input folders.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Managed folder</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">storage.objects.create</code></p>
<p><code translate="no" dir="ltr">storage.objects.delete</code></p>
<p><code translate="no" dir="ltr">storage.objects.list</code></p>
<p><code translate="no" dir="ltr">storage.objects.update</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="storage.expressModeServiceOutput" class="role-title add-link" data-text="Storage Express Mode Service Output Beta " tabindex="-1">Storage Express Mode Service Output <sup>Beta</sup></h4>
<p>(<code translate="no" dir="ltr">roles/storage.expressModeServiceOutput</code>)</p>
<span class="role-description"> </span>
<p>Grants permission to Express Mode service accounts at a managed folder so they can read objects but not write them on output folders.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Managed folder</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">storage.objects.delete</code></p>
<p><code translate="no" dir="ltr">storage.objects.get</code></p>
<p><code translate="no" dir="ltr">storage.objects.list</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="storage.expressModeUserAccess" class="role-title add-link" data-text="Storage Express Mode User Access Beta " tabindex="-1">Storage Express Mode User Access <sup>Beta</sup></h4>
<p>(<code translate="no" dir="ltr">roles/storage.expressModeUserAccess</code>)</p>
<span class="role-description"> </span>
<p>Grants permission to Express Mode accounts at the project level so they can read, list, create and delete any object in any of their buckets in Express Mode.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Project</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">orgpolicy.policy.get</code></p>
<p><code translate="no" dir="ltr">storage.buckets.get</code></p>
<p><code translate="no" dir="ltr">storage.buckets.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.multipartUploads.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.multipartUploads.abort</code></li>
<li><code translate="no" dir="ltr">storage.multipartUploads.create</code></li>
<li><code translate="no" dir="ltr">storage.multipartUploads.list</code></li>
<li><code translate="no" dir="ltr">storage.multipartUploads.listParts</code></li>
</ul>
<p><code translate="no" dir="ltr">storage.objects.create</code></p>
<p><code translate="no" dir="ltr">storage.objects.delete</code></p>
<p><code translate="no" dir="ltr">storage.objects.get</code></p>
<p><code translate="no" dir="ltr">storage.objects.list</code></p>
<p><code translate="no" dir="ltr">storage.objects.restore</code></p>
<p><code translate="no" dir="ltr">storage.objects.update</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="storage.hmacKeyAdmin" class="role-title add-link" data-text="Storage HMAC Key Admin " tabindex="-1">Storage HMAC Key Admin</h4>
<p>(<code translate="no" dir="ltr">roles/storage.hmacKeyAdmin</code>)</p>
<span class="role-description custom"> </span>
<p>Full control of Cloud Storage HMAC keys.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Project</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">firebase.projects.get</code></p>
<p><code translate="no" dir="ltr">orgpolicy.policy.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.hmacKeys.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.hmacKeys.create</code></li>
<li><code translate="no" dir="ltr">storage.hmacKeys.delete</code></li>
<li><code translate="no" dir="ltr">storage.hmacKeys.get</code></li>
<li><code translate="no" dir="ltr">storage.hmacKeys.list</code></li>
<li><code translate="no" dir="ltr">storage.hmacKeys.update</code></li>
</ul></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="storage.insightsCollectorService" class="role-title add-link" data-text="Storage Insights Collector Service " tabindex="-1">Storage Insights Collector Service</h4>
<p>(<code translate="no" dir="ltr">roles/storage.insightsCollectorService</code>)</p>
<span class="role-description custom"> </span>
<p>Read-only access to Cloud Storage Inventory metadata for Storage Insights.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Bucket</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><code translate="no" dir="ltr">storage.buckets.get</code></p>
<p><code translate="no" dir="ltr">storage.buckets.getObjectInsights</code></p></td>
</tr>
</tbody>
</table>

## Cloud Storage permissions

<div results-count-container="">

</div>

<table class="permissions-table fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="45%">Permission</th>
<th>Included in roles</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td><h4 id="storage.anywhereCaches.create" class="permission-name add-link" data-text="storage.anywhereCaches.create" tabindex="-1"><code translate="no" dir="ltr">storage.anywhereCaches.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketOwner">Storage Legacy Bucket Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="storage.anywhereCaches.disable" class="permission-name add-link" data-text="storage.anywhereCaches.disable" tabindex="-1"><code translate="no" dir="ltr">storage.anywhereCaches.disable</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketOwner">Storage Legacy Bucket Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="storage.anywhereCaches.get" class="permission-name add-link" data-text="storage.anywhereCaches.get" tabindex="-1"><code translate="no" dir="ltr">storage.anywhereCaches.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketOwner">Storage Legacy Bucket Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.serviceAgent">Cluster Director Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="storage.anywhereCaches.list" class="permission-name add-link" data-text="storage.anywhereCaches.list" tabindex="-1"><code translate="no" dir="ltr">storage.anywhereCaches.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketOwner">Storage Legacy Bucket Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.serviceAgent">Cluster Director Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="storage.anywhereCaches.pause" class="permission-name add-link" data-text="storage.anywhereCaches.pause" tabindex="-1"><code translate="no" dir="ltr">storage.anywhereCaches.pause</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketOwner">Storage Legacy Bucket Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="storage.anywhereCaches.resume" class="permission-name add-link" data-text="storage.anywhereCaches.resume" tabindex="-1"><code translate="no" dir="ltr">storage.anywhereCaches.resume</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketOwner">Storage Legacy Bucket Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="storage.anywhereCaches.update" class="permission-name add-link" data-text="storage.anywhereCaches.update" tabindex="-1"><code translate="no" dir="ltr">storage.anywhereCaches.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketOwner">Storage Legacy Bucket Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="storage.bucketOperations.cancel" class="permission-name add-link" data-text="storage.bucketOperations.cancel" tabindex="-1"><code translate="no" dir="ltr">storage.bucketOperations.cancel</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketOwner">Storage Legacy Bucket Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="storage.bucketOperations.get" class="permission-name add-link" data-text="storage.bucketOperations.get" tabindex="-1"><code translate="no" dir="ltr">storage.bucketOperations.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketOwner">Storage Legacy Bucket Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.managementServiceAgent">Firebase Service Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.managementServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="storage.bucketOperations.list" class="permission-name add-link" data-text="storage.bucketOperations.list" tabindex="-1"><code translate="no" dir="ltr">storage.bucketOperations.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketOwner">Storage Legacy Bucket Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.managementServiceAgent">Firebase Service Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.managementServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="storage.buckets.create" class="permission-name add-link" data-text="storage.buckets.create" tabindex="-1"><code translate="no" dir="ltr">storage.buckets.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/privateca#privateca.admin">CA Service Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/privateca.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.editor">Storage Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/backupdr#backupdr.cloudStorageOperator">Backup and DR Cloud Storage Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/backupdr.cloudStorageOperator</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudmigration#cloudmigration.inframanager">Velostrata Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudmigration.inframanager</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtestservice#cloudtestservice.testAdmin">Firebase Test Lab Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtestservice.testAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/config#config.agent">Cloud Infrastructure Manager Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/config.agent</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/privateca#privateca.caManager">CA Service Operation Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/privateca.caManager</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.dataSecurityScanner">Wiz Data Security Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.dataSecurityScanner</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiedgeportal#aiedgeportal.serviceAgent">AI Edge Portal Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiedgeportal.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.batchPredictionServiceAgent">Vertex AI Batch Prediction Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.batchPredictionServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.customCodeServiceAgent">Vertex AI Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.customCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.modelMonitoringServiceAgent">Vertex AI Model Monitoring Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.modelMonitoringServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.tuningServiceAgent">Vertex AI Tuning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.tuningServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAgent">App Engine Standard Environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengineflex#appengineflex.serviceAgent">App Engine flexible environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengineflex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.serviceAgent">Recommendations AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.serviceAgent">Chronicle Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudasset#cloudasset.serviceAgent">Cloud Asset Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudasset.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudconfig#cloudconfig.serviceAgent">Infrastructure Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudconfig.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/clouddeploy#clouddeploy.serviceAgent">Cloud Deploy Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploy.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/designcenter#designcenter.serviceAgent">DesignCenter Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/devicerun#devicerun.serviceAgent">Device Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/devicerun.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.serviceAgent">Discovery Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.clusterServiceAgent">Edge Container Cluster Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.clusterServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.managementServiceAgent">Firebase Service Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.managementServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.sdkAdminServiceAgent">Firebase Admin SDK Administrator Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.sdkAdminServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.serviceAgent">Cluster Director Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/integrations#integrations.serviceAgent">Application Integration Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/metastore#metastore.serviceAgent">Dataproc Metastore Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/metastore.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/retail#retail.serviceAgent">Retail Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/retail.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/runapps#runapps.serviceAgent">Serverless Integrations Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/runapps.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/saasservicemgmt#saasservicemgmt.serviceAgent">SaaS Service Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/saasservicemgmt.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/spanner#spanner.serviceAgent">Cloud Spanner API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/spanner.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/stream#stream.serviceAgent">Stream Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/stream.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visionai#visionai.serviceAgent">Cloud Vision AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visionai.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="storage.buckets.createTagBinding" class="permission-name add-link" data-text="storage.buckets.createTagBinding" tabindex="-1"><code translate="no" dir="ltr">storage.buckets.createTagBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketOwner">Storage Legacy Bucket Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dspm#dspm.serviceAgent">DSPM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="storage.buckets.delete" class="permission-name add-link" data-text="storage.buckets.delete" tabindex="-1"><code translate="no" dir="ltr">storage.buckets.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.editor">Storage Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudmigration#cloudmigration.inframanager">Velostrata Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudmigration.inframanager</code>)</p>
<p><a href="/iam/docs/roles-permissions/config#config.agent">Cloud Infrastructure Manager Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/config.agent</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.dataSecurityScanner">Wiz Data Security Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.dataSecurityScanner</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.batchPredictionServiceAgent">Vertex AI Batch Prediction Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.batchPredictionServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.customCodeServiceAgent">Vertex AI Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.customCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.modelMonitoringServiceAgent">Vertex AI Model Monitoring Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.modelMonitoringServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengineflex#appengineflex.serviceAgent">App Engine flexible environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengineflex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudconfig#cloudconfig.serviceAgent">Infrastructure Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudconfig.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/designcenter#designcenter.serviceAgent">DesignCenter Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.sdkAdminServiceAgent">Firebase Admin SDK Administrator Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.sdkAdminServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.serviceAgent">Cluster Director Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/metastore#metastore.serviceAgent">Dataproc Metastore Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/metastore.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/runapps#runapps.serviceAgent">Serverless Integrations Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/runapps.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/saasservicemgmt#saasservicemgmt.serviceAgent">SaaS Service Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/saasservicemgmt.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visionai#visionai.serviceAgent">Cloud Vision AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visionai.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="storage.buckets.deleteTagBinding" class="permission-name add-link" data-text="storage.buckets.deleteTagBinding" tabindex="-1"><code translate="no" dir="ltr">storage.buckets.deleteTagBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketOwner">Storage Legacy Bucket Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dspm#dspm.serviceAgent">DSPM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="storage.buckets.enableObjectRetention" class="permission-name add-link" data-text="storage.buckets.enableObjectRetention" tabindex="-1"><code translate="no" dir="ltr">storage.buckets.enableObjectRetention</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketOwner">Storage Legacy Bucket Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="storage.buckets.get" class="permission-name add-link" data-text="storage.buckets.get" tabindex="-1"><code translate="no" dir="ltr">storage.buckets.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.admin">Dataflow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.bucketViewer">Storage Bucket Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.bucketViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketOwner">Storage Legacy Bucket Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketReader">Storage Legacy Bucket Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketWriter">Storage Legacy Bucket Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/backupdr#backupdr.cloudStorageOperator">Backup and DR Cloud Storage Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/backupdr.cloudStorageOperator</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudmigration#cloudmigration.inframanager">Velostrata Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudmigration.inframanager</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtestservice#cloudtestservice.testAdmin">Firebase Test Lab Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtestservice.testAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/config#config.agent">Cloud Infrastructure Manager Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/config.agent</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.worker">Dataflow Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.storageDataOwner">Dataplex Storage Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.storageDataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.storageDataReader">Dataplex Storage Data Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.storageDataReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.hubAgent">Dataproc Hub Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.hubAgent</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.worker">Dataproc Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/securedlandingzone#securedlandingzone.bqdwProjectRemediator">SLZ BQDW Blueprint Project Level Remediator</a> (<code class="role-name" translate="no" dir="ltr">roles/securedlandingzone.bqdwProjectRemediator</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.expressModeUserAccess">Storage Express Mode User Access</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.expressModeUserAccess</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.insightsCollectorService">Storage Insights Collector Service</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.insightsCollectorService</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.dataSecurityScanner">Wiz Data Security Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.dataSecurityScanner</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiedgeportal#aiedgeportal.serviceAgent">AI Edge Portal Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiedgeportal.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.batchPredictionServiceAgent">Vertex AI Batch Prediction Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.batchPredictionServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.customCodeServiceAgent">Vertex AI Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.customCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.modelMonitoringServiceAgent">Vertex AI Model Monitoring Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.modelMonitoringServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.ragServiceAgent">Vertex AI RAG Data Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.ragServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.reasoningEngineServiceAgent">Vertex AI Reasoning Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.reasoningEngineServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.tuningServiceAgent">Vertex AI Tuning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.tuningServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAgent">App Engine Standard Environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengineflex#appengineflex.serviceAgent">App Engine flexible environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengineflex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.serviceAgent">Audit Manager Auditing Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/automl#automl.serviceAgent">AutoML Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.serviceAgent">Recommendations AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.serviceAgent">Chronicle Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.soarServiceAgent">Chronicle SOAR Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.soarServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudasset#cloudasset.serviceAgent">Cloud Asset Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudasset.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudconfig#cloudconfig.serviceAgent">Infrastructure Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudconfig.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/clouddeploy#clouddeploy.serviceAgent">Cloud Deploy Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploy.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudoptimization#cloudoptimization.serviceAgent">Cloud Optimization Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudoptimization.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.serviceAgent">Cloud Security Compliance Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudtranslate#cloudtranslate.serviceAgent">Cloud Translation API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtranslate.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/contentwarehouse#contentwarehouse.serviceAgent">Content Warehouse Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/contentwarehouse.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.discoveryServiceAgent">Dataplex Discovery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.discoveryServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datastream#datastream.serviceAgent">Datastream Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datastream.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datastudio#datastudio.managedStorageServiceAgent">Data Studio Managed Storage Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datastudio.managedStorageServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/designcenter#designcenter.serviceAgent">DesignCenter Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/devicerun#devicerun.serviceAgent">Device Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/devicerun.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.serviceAgent">Discovery Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/clouddocumentai#documentaicore.serviceAgent">DocumentAI Core Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/documentaicore.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.clusterServiceAgent">Edge Container Cluster Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.clusterServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/eventarc#eventarc.serviceAgent">Eventarc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/eventarc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.managementServiceAgent">Firebase Service Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.managementServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.sdkAdminServiceAgent">Firebase Admin SDK Administrator Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.sdkAdminServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasestorage#firebasestorage.serviceAgent">Cloud Storage for Firebase Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasestorage.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasetelemetry#firebasetelemetry.serviceAgent">Firebase Telemetry Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasetelemetry.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firestore#firestore.serviceAgent">Firestore Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firestore.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/generativelanguage#generativelanguage.serviceAgent">Generative Language Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/generativelanguage.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.serviceAgent">Cluster Director Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/integrations#integrations.serviceAgent">Application Integration Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/kuberun#kuberun.eventsControlPlaneServiceAgent">KubeRun Events Control Plane Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/kuberun.eventsControlPlaneServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/metastore#metastore.serviceAgent">Dataproc Metastore Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/metastore.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/retail#retail.serviceAgent">Retail Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/retail.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/routeoptimization#routeoptimization.serviceAgent">Route Optimization Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/routeoptimization.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/runapps#runapps.serviceAgent">Serverless Integrations Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/runapps.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/saasservicemgmt#saasservicemgmt.serviceAgent">SaaS Service Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/saasservicemgmt.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.controlServiceAgent">Security Center Control Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.controlServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.securityResponseServiceAgent">Google Cloud Security Response Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.securityResponseServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.serviceAgent">Security Center Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/spanner#spanner.serviceAgent">Cloud Spanner API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/spanner.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/speech#speech.serviceAgent">Cloud Speech-to-Text Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/speech.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/stream#stream.serviceAgent">Stream Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/stream.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vectorsearch#vectorsearch.serviceAgent">Vector Search Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vectorsearch.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visionai#visionai.serviceAgent">Cloud Vision AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visionai.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="storage.buckets.getIamPolicy" class="permission-name add-link" data-text="storage.buckets.getIamPolicy" tabindex="-1"><code translate="no" dir="ltr">storage.buckets.getIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketOwner">Storage Legacy Bucket Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/securedlandingzone#securedlandingzone.bqdwProjectRemediator">SLZ BQDW Blueprint Project Level Remediator</a> (<code class="role-name" translate="no" dir="ltr">roles/securedlandingzone.bqdwProjectRemediator</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.tuningServiceAgent">Vertex AI Tuning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.tuningServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengineflex#appengineflex.serviceAgent">App Engine flexible environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengineflex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.serviceAgent">Audit Manager Auditing Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.serviceAgent">Chronicle Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.soarServiceAgent">Chronicle SOAR Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.soarServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudasset#cloudasset.serviceAgent">Cloud Asset Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudasset.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.serviceAgent">Cloud Security Compliance Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.serviceAgent">Discovery Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.managementServiceAgent">Firebase Service Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.managementServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasestorage#firebasestorage.serviceAgent">Cloud Storage for Firebase Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasestorage.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.serviceAgent">Cluster Director Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/saasservicemgmt#saasservicemgmt.serviceAgent">SaaS Service Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/saasservicemgmt.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.controlServiceAgent">Security Center Control Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.controlServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.serviceAgent">Security Center Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="storage.buckets.getIpFilter" class="permission-name add-link" data-text="storage.buckets.getIpFilter" tabindex="-1"><code translate="no" dir="ltr">storage.buckets.getIpFilter</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketOwner">Storage Legacy Bucket Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="storage.buckets.getObjectInsights" class="permission-name add-link" data-text="storage.buckets.getObjectInsights" tabindex="-1"><code translate="no" dir="ltr">storage.buckets.getObjectInsights</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.insightsCollectorService">Storage Insights Collector Service</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.insightsCollectorService</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.dataSecurityScanner">Wiz Data Security Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.dataSecurityScanner</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="storage.buckets.list" class="permission-name add-link" data-text="storage.buckets.list" tabindex="-1"><code translate="no" dir="ltr">storage.buckets.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.bucketViewer">Storage Bucket Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.bucketViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.editor">Storage Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.viewer">Storage Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.admin">Workload Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudmigration#cloudmigration.inframanager">Velostrata Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudmigration.inframanager</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/config#config.agent">Cloud Infrastructure Manager Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/config.agent</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/securedlandingzone#securedlandingzone.bqdwProjectRemediator">SLZ BQDW Blueprint Project Level Remediator</a> (<code class="role-name" translate="no" dir="ltr">roles/securedlandingzone.bqdwProjectRemediator</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.expressModeUserAccess">Storage Express Mode User Access</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.expressModeUserAccess</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.deploymentAdmin">Workload Manager Deployment Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.deploymentAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiedgeportal#aiedgeportal.serviceAgent">AI Edge Portal Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiedgeportal.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.batchPredictionServiceAgent">Vertex AI Batch Prediction Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.batchPredictionServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.customCodeServiceAgent">Vertex AI Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.customCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.modelMonitoringServiceAgent">Vertex AI Model Monitoring Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.modelMonitoringServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.ragServiceAgent">Vertex AI RAG Data Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.ragServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.reasoningEngineServiceAgent">Vertex AI Reasoning Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.reasoningEngineServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.tuningServiceAgent">Vertex AI Tuning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.tuningServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.serviceAgent">Audit Manager Auditing Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.soarServiceAgent">Chronicle SOAR Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.soarServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudconfig#cloudconfig.serviceAgent">Infrastructure Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudconfig.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.serviceAgent">Cloud Security Compliance Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/contentwarehouse#contentwarehouse.serviceAgent">Content Warehouse Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/contentwarehouse.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/designcenter#designcenter.serviceAgent">DesignCenter Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/devicerun#devicerun.serviceAgent">Device Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/devicerun.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.clusterServiceAgent">Edge Container Cluster Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.clusterServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.managementServiceAgent">Firebase Service Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.managementServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.sdkAdminServiceAgent">Firebase Admin SDK Administrator Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.sdkAdminServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.serviceAgent">Cluster Director Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/integrations#integrations.serviceAgent">Application Integration Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.controlServiceAgent">Security Center Control Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.controlServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.serviceAgent">Security Center Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/spanner#spanner.serviceAgent">Cloud Spanner API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/spanner.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/speech#speech.serviceAgent">Cloud Speech-to-Text Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/speech.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visionai#visionai.serviceAgent">Cloud Vision AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visionai.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="storage.buckets.listEffectiveTags" class="permission-name add-link" data-text="storage.buckets.listEffectiveTags" tabindex="-1"><code translate="no" dir="ltr">storage.buckets.listEffectiveTags</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagViewer">Tag Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.editor">Storage Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketOwner">Storage Legacy Bucket Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.viewer">Storage Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dspm#dspm.serviceAgent">DSPM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="storage.buckets.listTagBindings" class="permission-name add-link" data-text="storage.buckets.listTagBindings" tabindex="-1"><code translate="no" dir="ltr">storage.buckets.listTagBindings</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagViewer">Tag Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.editor">Storage Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketOwner">Storage Legacy Bucket Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.viewer">Storage Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dspm#dspm.serviceAgent">DSPM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="storage.buckets.relocate" class="permission-name add-link" data-text="storage.buckets.relocate" tabindex="-1"><code translate="no" dir="ltr">storage.buckets.relocate</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketOwner">Storage Legacy Bucket Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="storage.buckets.restore" class="permission-name add-link" data-text="storage.buckets.restore" tabindex="-1"><code translate="no" dir="ltr">storage.buckets.restore</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketOwner">Storage Legacy Bucket Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="storage.buckets.setIamPolicy" class="permission-name add-link" data-text="storage.buckets.setIamPolicy" tabindex="-1"><code translate="no" dir="ltr">storage.buckets.setIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketOwner">Storage Legacy Bucket Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/securedlandingzone#securedlandingzone.bqdwProjectRemediator">SLZ BQDW Blueprint Project Level Remediator</a> (<code class="role-name" translate="no" dir="ltr">roles/securedlandingzone.bqdwProjectRemediator</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/appengineflex#appengineflex.serviceAgent">App Engine flexible environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengineflex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.serviceAgent">Chronicle Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.serviceAgent">Discovery Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.managementServiceAgent">Firebase Service Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.managementServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.serviceAgent">Cluster Director Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/saasservicemgmt#saasservicemgmt.serviceAgent">SaaS Service Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/saasservicemgmt.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="storage.buckets.setIpFilter" class="permission-name add-link" data-text="storage.buckets.setIpFilter" tabindex="-1"><code translate="no" dir="ltr">storage.buckets.setIpFilter</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketOwner">Storage Legacy Bucket Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="storage.buckets.update" class="permission-name add-link" data-text="storage.buckets.update" tabindex="-1"><code translate="no" dir="ltr">storage.buckets.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketOwner">Storage Legacy Bucket Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudmigration#cloudmigration.inframanager">Velostrata Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudmigration.inframanager</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtestservice#cloudtestservice.testAdmin">Firebase Test Lab Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtestservice.testAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/config#config.agent">Cloud Infrastructure Manager Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/config.agent</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/securedlandingzone#securedlandingzone.bqdwProjectRemediator">SLZ BQDW Blueprint Project Level Remediator</a> (<code class="role-name" translate="no" dir="ltr">roles/securedlandingzone.bqdwProjectRemediator</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.dataSecurityScanner">Wiz Data Security Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.dataSecurityScanner</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.batchPredictionServiceAgent">Vertex AI Batch Prediction Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.batchPredictionServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.modelMonitoringServiceAgent">Vertex AI Model Monitoring Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.modelMonitoringServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.tuningServiceAgent">Vertex AI Tuning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.tuningServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengineflex#appengineflex.serviceAgent">App Engine flexible environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengineflex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.soarServiceAgent">Chronicle SOAR Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.soarServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudconfig#cloudconfig.serviceAgent">Infrastructure Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudconfig.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/designcenter#designcenter.serviceAgent">DesignCenter Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.clusterServiceAgent">Edge Container Cluster Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.clusterServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/eventarc#eventarc.serviceAgent">Eventarc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/eventarc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.managementServiceAgent">Firebase Service Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.managementServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.sdkAdminServiceAgent">Firebase Admin SDK Administrator Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.sdkAdminServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.serviceAgent">Cluster Director Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/integrations#integrations.serviceAgent">Application Integration Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/kuberun#kuberun.eventsControlPlaneServiceAgent">KubeRun Events Control Plane Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/kuberun.eventsControlPlaneServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/metastore#metastore.serviceAgent">Dataproc Metastore Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/metastore.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.securityResponseServiceAgent">Google Cloud Security Response Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.securityResponseServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="storage.buckets.viewIntelligenceDetails" class="permission-name add-link" data-text="storage.buckets.viewIntelligenceDetails" tabindex="-1"><code translate="no" dir="ltr">storage.buckets.viewIntelligenceDetails</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.editor">Storage Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.viewer">Storage Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="storage.buckets.viewSecurityIntelligenceDetails" class="permission-name add-link" data-text="storage.buckets.viewSecurityIntelligenceDetails" tabindex="-1"><code translate="no" dir="ltr">storage.buckets.viewSecurityIntelligenceDetails</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.editor">Storage Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.viewer">Storage Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="storage.featureConfigs.create" class="permission-name add-link" data-text="storage.featureConfigs.create" tabindex="-1"><code translate="no" dir="ltr">storage.featureConfigs.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.editor">Storage Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="storage.featureConfigs.delete" class="permission-name add-link" data-text="storage.featureConfigs.delete" tabindex="-1"><code translate="no" dir="ltr">storage.featureConfigs.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.editor">Storage Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="storage.featureConfigs.get" class="permission-name add-link" data-text="storage.featureConfigs.get" tabindex="-1"><code translate="no" dir="ltr">storage.featureConfigs.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.editor">Storage Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.viewer">Storage Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="storage.featureConfigs.list" class="permission-name add-link" data-text="storage.featureConfigs.list" tabindex="-1"><code translate="no" dir="ltr">storage.featureConfigs.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.editor">Storage Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.viewer">Storage Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="storage.featureConfigs.update" class="permission-name add-link" data-text="storage.featureConfigs.update" tabindex="-1"><code translate="no" dir="ltr">storage.featureConfigs.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.editor">Storage Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="storage.folders.create" class="permission-name add-link" data-text="storage.folders.create" tabindex="-1"><code translate="no" dir="ltr">storage.folders.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.admin">Application Design Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.editor">Storage Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.folderAdmin">Storage Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketOwner">Storage Legacy Bucket Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketWriter">Storage Legacy Bucket Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectAdmin">Storage Object Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectCreator">Storage Object Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectCreator</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectUser">Storage Object User</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectAdmin">Environment and Storage Object Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.worker">Dataproc Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.user">Application Design Center User</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.extensionCustomCodeServiceAgent">Vertex AI Extension Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.extensionCustomCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.sdkAdminServiceAgent">Firebase Admin SDK Administrator Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.sdkAdminServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visionai#visionai.serviceAgent">Cloud Vision AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visionai.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="storage.folders.delete" class="permission-name add-link" data-text="storage.folders.delete" tabindex="-1"><code translate="no" dir="ltr">storage.folders.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.admin">Application Design Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.editor">Storage Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.folderAdmin">Storage Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketOwner">Storage Legacy Bucket Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketWriter">Storage Legacy Bucket Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectAdmin">Storage Object Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectUser">Storage Object User</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectAdmin">Environment and Storage Object Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.worker">Dataproc Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.user">Application Design Center User</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.extensionCustomCodeServiceAgent">Vertex AI Extension Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.extensionCustomCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datamigration#datamigration.serviceAgent">Database Migration Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datamigration.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.sdkAdminServiceAgent">Firebase Admin SDK Administrator Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.sdkAdminServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visionai#visionai.serviceAgent">Cloud Vision AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visionai.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="storage.folders.get" class="permission-name add-link" data-text="storage.folders.get" tabindex="-1"><code translate="no" dir="ltr">storage.folders.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.admin">Application Design Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.editor">Designcenter Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.viewer">Application Design Center Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.admin">Gemini Cloud Assist Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.editor">Gemini Cloud Assist Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.user">Gemini Cloud Assist User</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.viewer">Gemini Cloud Assist Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.editor">Storage Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.folderAdmin">Storage Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketOwner">Storage Legacy Bucket Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketReader">Storage Legacy Bucket Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketWriter">Storage Legacy Bucket Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectAdmin">Storage Object Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectUser">Storage Object User</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectViewer">Storage Object Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.viewer">Storage Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apphub#apphub.appManagementViewer">App Management Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apphub.appManagementViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectAdmin">Environment and Storage Object Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectUser">Environment and Storage Object User</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectViewer">Environment and Storage Object Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.worker">Dataproc Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.user">Application Design Center User</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.extensionCustomCodeServiceAgent">Vertex AI Extension Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.extensionCustomCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dialogflow#dialogflow.serviceAgent">Dialogflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dialogflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.sdkAdminServiceAgent">Firebase Admin SDK Administrator Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.sdkAdminServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.serviceAgent">Cluster Director Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visionai#visionai.serviceAgent">Cloud Vision AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visionai.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="storage.folders.list" class="permission-name add-link" data-text="storage.folders.list" tabindex="-1"><code translate="no" dir="ltr">storage.folders.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.admin">Application Design Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.editor">Designcenter Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.viewer">Application Design Center Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.admin">Gemini Cloud Assist Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.editor">Gemini Cloud Assist Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.user">Gemini Cloud Assist User</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.viewer">Gemini Cloud Assist Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.editor">Storage Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.folderAdmin">Storage Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketOwner">Storage Legacy Bucket Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketReader">Storage Legacy Bucket Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketWriter">Storage Legacy Bucket Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectAdmin">Storage Object Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectUser">Storage Object User</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectViewer">Storage Object Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.viewer">Storage Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apphub#apphub.appManagementViewer">App Management Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apphub.appManagementViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectAdmin">Environment and Storage Object Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectUser">Environment and Storage Object User</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectViewer">Environment and Storage Object Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.worker">Dataproc Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.user">Application Design Center User</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.extensionCustomCodeServiceAgent">Vertex AI Extension Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.extensionCustomCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dialogflow#dialogflow.serviceAgent">Dialogflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dialogflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.sdkAdminServiceAgent">Firebase Admin SDK Administrator Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.sdkAdminServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visionai#visionai.serviceAgent">Cloud Vision AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visionai.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="storage.folders.rename" class="permission-name add-link" data-text="storage.folders.rename" tabindex="-1"><code translate="no" dir="ltr">storage.folders.rename</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.admin">Application Design Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.editor">Storage Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.folderAdmin">Storage Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketOwner">Storage Legacy Bucket Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketWriter">Storage Legacy Bucket Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectAdmin">Storage Object Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectUser">Storage Object User</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectAdmin">Environment and Storage Object Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.worker">Dataproc Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.user">Application Design Center User</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.extensionCustomCodeServiceAgent">Vertex AI Extension Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.extensionCustomCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.sdkAdminServiceAgent">Firebase Admin SDK Administrator Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.sdkAdminServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visionai#visionai.serviceAgent">Cloud Vision AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visionai.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="storage.hmacKeys.create" class="permission-name add-link" data-text="storage.hmacKeys.create" tabindex="-1"><code translate="no" dir="ltr">storage.hmacKeys.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.editor">Storage Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.hmacKeyAdmin">Storage HMAC Key Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.hmacKeyAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="storage.hmacKeys.delete" class="permission-name add-link" data-text="storage.hmacKeys.delete" tabindex="-1"><code translate="no" dir="ltr">storage.hmacKeys.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.editor">Storage Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.hmacKeyAdmin">Storage HMAC Key Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.hmacKeyAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="storage.hmacKeys.get" class="permission-name add-link" data-text="storage.hmacKeys.get" tabindex="-1"><code translate="no" dir="ltr">storage.hmacKeys.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.editor">Storage Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.viewer">Storage Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.hmacKeyAdmin">Storage HMAC Key Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.hmacKeyAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="storage.hmacKeys.list" class="permission-name add-link" data-text="storage.hmacKeys.list" tabindex="-1"><code translate="no" dir="ltr">storage.hmacKeys.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.editor">Storage Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.viewer">Storage Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.hmacKeyAdmin">Storage HMAC Key Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.hmacKeyAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="storage.hmacKeys.update" class="permission-name add-link" data-text="storage.hmacKeys.update" tabindex="-1"><code translate="no" dir="ltr">storage.hmacKeys.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.editor">Storage Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.hmacKeyAdmin">Storage HMAC Key Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.hmacKeyAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="storage.intelligenceConfigs.get" class="permission-name add-link" data-text="storage.intelligenceConfigs.get" tabindex="-1"><code translate="no" dir="ltr">storage.intelligenceConfigs.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.editor">Storage Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.viewer">Storage Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dspm#dspm.serviceAgent">DSPM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="storage.intelligenceConfigs.update" class="permission-name add-link" data-text="storage.intelligenceConfigs.update" tabindex="-1"><code translate="no" dir="ltr">storage.intelligenceConfigs.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="storage.managedFolders.create" class="permission-name add-link" data-text="storage.managedFolders.create" tabindex="-1"><code translate="no" dir="ltr">storage.managedFolders.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.admin">Application Design Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.folderAdmin">Storage Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketOwner">Storage Legacy Bucket Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketWriter">Storage Legacy Bucket Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectAdmin">Storage Object Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectCreator">Storage Object Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectCreator</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectUser">Storage Object User</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectAdmin">Environment and Storage Object Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.worker">Dataproc Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.user">Application Design Center User</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.extensionCustomCodeServiceAgent">Vertex AI Extension Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.extensionCustomCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/designcenter#designcenter.serviceAgent">DesignCenter Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.serviceAgent">Discovery Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.sdkAdminServiceAgent">Firebase Admin SDK Administrator Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.sdkAdminServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="storage.managedFolders.delete" class="permission-name add-link" data-text="storage.managedFolders.delete" tabindex="-1"><code translate="no" dir="ltr">storage.managedFolders.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.admin">Application Design Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.folderAdmin">Storage Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketOwner">Storage Legacy Bucket Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketWriter">Storage Legacy Bucket Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectAdmin">Storage Object Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectUser">Storage Object User</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectAdmin">Environment and Storage Object Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.worker">Dataproc Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.user">Application Design Center User</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.extensionCustomCodeServiceAgent">Vertex AI Extension Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.extensionCustomCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/designcenter#designcenter.serviceAgent">DesignCenter Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.serviceAgent">Discovery Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.sdkAdminServiceAgent">Firebase Admin SDK Administrator Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.sdkAdminServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="storage.managedFolders.get" class="permission-name add-link" data-text="storage.managedFolders.get" tabindex="-1"><code translate="no" dir="ltr">storage.managedFolders.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.admin">Application Design Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.editor">Designcenter Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.viewer">Application Design Center Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.admin">Gemini Cloud Assist Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.editor">Gemini Cloud Assist Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.user">Gemini Cloud Assist User</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.viewer">Gemini Cloud Assist Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.folderAdmin">Storage Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketOwner">Storage Legacy Bucket Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketReader">Storage Legacy Bucket Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketWriter">Storage Legacy Bucket Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectAdmin">Storage Object Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectUser">Storage Object User</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectViewer">Storage Object Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apphub#apphub.appManagementViewer">App Management Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apphub.appManagementViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectAdmin">Environment and Storage Object Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectUser">Environment and Storage Object User</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectViewer">Environment and Storage Object Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.worker">Dataproc Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.user">Application Design Center User</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.extensionCustomCodeServiceAgent">Vertex AI Extension Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.extensionCustomCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/designcenter#designcenter.serviceAgent">DesignCenter Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dialogflow#dialogflow.serviceAgent">Dialogflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dialogflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.serviceAgent">Discovery Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.sdkAdminServiceAgent">Firebase Admin SDK Administrator Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.sdkAdminServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="storage.managedFolders.getIamPolicy" class="permission-name add-link" data-text="storage.managedFolders.getIamPolicy" tabindex="-1"><code translate="no" dir="ltr">storage.managedFolders.getIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.folderAdmin">Storage Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketOwner">Storage Legacy Bucket Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/designcenter#designcenter.serviceAgent">DesignCenter Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.serviceAgent">Discovery Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="storage.managedFolders.list" class="permission-name add-link" data-text="storage.managedFolders.list" tabindex="-1"><code translate="no" dir="ltr">storage.managedFolders.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.admin">Application Design Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.editor">Designcenter Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.viewer">Application Design Center Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.admin">Gemini Cloud Assist Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.editor">Gemini Cloud Assist Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.user">Gemini Cloud Assist User</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.viewer">Gemini Cloud Assist Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.folderAdmin">Storage Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketOwner">Storage Legacy Bucket Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketReader">Storage Legacy Bucket Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketWriter">Storage Legacy Bucket Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectAdmin">Storage Object Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectUser">Storage Object User</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectViewer">Storage Object Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apphub#apphub.appManagementViewer">App Management Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apphub.appManagementViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectAdmin">Environment and Storage Object Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectUser">Environment and Storage Object User</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectViewer">Environment and Storage Object Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.worker">Dataproc Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.user">Application Design Center User</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.extensionCustomCodeServiceAgent">Vertex AI Extension Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.extensionCustomCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/designcenter#designcenter.serviceAgent">DesignCenter Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dialogflow#dialogflow.serviceAgent">Dialogflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dialogflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.serviceAgent">Discovery Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.sdkAdminServiceAgent">Firebase Admin SDK Administrator Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.sdkAdminServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="storage.managedFolders.setIamPolicy" class="permission-name add-link" data-text="storage.managedFolders.setIamPolicy" tabindex="-1"><code translate="no" dir="ltr">storage.managedFolders.setIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.folderAdmin">Storage Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketOwner">Storage Legacy Bucket Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.serviceAgent">Discovery Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="storage.managedFolders.update" class="permission-name add-link" data-text="storage.managedFolders.update" tabindex="-1"><code translate="no" dir="ltr">storage.managedFolders.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.admin">Application Design Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.folderAdmin">Storage Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketOwner">Storage Legacy Bucket Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketWriter">Storage Legacy Bucket Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectAdmin">Storage Object Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectUser">Storage Object User</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectAdmin">Environment and Storage Object Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.worker">Dataproc Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.user">Application Design Center User</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.extensionCustomCodeServiceAgent">Vertex AI Extension Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.extensionCustomCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.sdkAdminServiceAgent">Firebase Admin SDK Administrator Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.sdkAdminServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="storage.multipartUploads.abort" class="permission-name add-link" data-text="storage.multipartUploads.abort" tabindex="-1"><code translate="no" dir="ltr">storage.multipartUploads.abort</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.admin">Application Design Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.folderAdmin">Storage Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketOwner">Storage Legacy Bucket Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketWriter">Storage Legacy Bucket Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectAdmin">Storage Object Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectCreator">Storage Object Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectCreator</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectUser">Storage Object User</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectAdmin">Environment and Storage Object Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.worker">Dataproc Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.user">Application Design Center User</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.expressModeUserAccess">Storage Express Mode User Access</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.expressModeUserAccess</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.extensionCustomCodeServiceAgent">Vertex AI Extension Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.extensionCustomCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.sdkAdminServiceAgent">Firebase Admin SDK Administrator Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.sdkAdminServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="storage.multipartUploads.create" class="permission-name add-link" data-text="storage.multipartUploads.create" tabindex="-1"><code translate="no" dir="ltr">storage.multipartUploads.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.admin">Application Design Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.folderAdmin">Storage Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketOwner">Storage Legacy Bucket Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketWriter">Storage Legacy Bucket Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectAdmin">Storage Object Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectCreator">Storage Object Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectCreator</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectUser">Storage Object User</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectAdmin">Environment and Storage Object Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.worker">Dataproc Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.user">Application Design Center User</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.expressModeUserAccess">Storage Express Mode User Access</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.expressModeUserAccess</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.extensionCustomCodeServiceAgent">Vertex AI Extension Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.extensionCustomCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.sdkAdminServiceAgent">Firebase Admin SDK Administrator Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.sdkAdminServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="storage.multipartUploads.list" class="permission-name add-link" data-text="storage.multipartUploads.list" tabindex="-1"><code translate="no" dir="ltr">storage.multipartUploads.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.admin">Application Design Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.admin">Gemini Cloud Assist Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.editor">Gemini Cloud Assist Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.user">Gemini Cloud Assist User</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.folderAdmin">Storage Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketOwner">Storage Legacy Bucket Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketReader">Storage Legacy Bucket Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketWriter">Storage Legacy Bucket Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectAdmin">Storage Object Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectUser">Storage Object User</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectAdmin">Environment and Storage Object Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.worker">Dataproc Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.user">Application Design Center User</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.expressModeUserAccess">Storage Express Mode User Access</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.expressModeUserAccess</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.extensionCustomCodeServiceAgent">Vertex AI Extension Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.extensionCustomCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.sdkAdminServiceAgent">Firebase Admin SDK Administrator Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.sdkAdminServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="storage.multipartUploads.listParts" class="permission-name add-link" data-text="storage.multipartUploads.listParts" tabindex="-1"><code translate="no" dir="ltr">storage.multipartUploads.listParts</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.admin">Application Design Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.admin">Gemini Cloud Assist Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.editor">Gemini Cloud Assist Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.user">Gemini Cloud Assist User</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.folderAdmin">Storage Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketOwner">Storage Legacy Bucket Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketWriter">Storage Legacy Bucket Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectAdmin">Storage Object Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectCreator">Storage Object Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectCreator</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectUser">Storage Object User</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectAdmin">Environment and Storage Object Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.worker">Dataproc Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.user">Application Design Center User</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.expressModeUserAccess">Storage Express Mode User Access</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.expressModeUserAccess</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.extensionCustomCodeServiceAgent">Vertex AI Extension Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.extensionCustomCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.sdkAdminServiceAgent">Firebase Admin SDK Administrator Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.sdkAdminServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="storage.objects.create" class="permission-name add-link" data-text="storage.objects.create" tabindex="-1"><code translate="no" dir="ltr">storage.objects.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.admin">Dataflow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.admin">Application Design Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaserules#firebaserules.system">Firebase Rules System</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaserules.system</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.folderAdmin">Storage Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketOwner">Storage Legacy Bucket Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketWriter">Storage Legacy Bucket Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectAdmin">Storage Object Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectCreator">Storage Object Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectCreator</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectUser">Storage Object User</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/backupdr#backupdr.cloudStorageOperator">Backup and DR Cloud Storage Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/backupdr.cloudStorageOperator</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerymigration#bigquerymigration.worker">Task Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerymigration.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/clouddeploy#clouddeploy.jobRunner">Cloud Deploy Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploy.jobRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudmigration#cloudmigration.storageaccess">Velostrata Storage Access</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudmigration.storageaccess</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtestservice#cloudtestservice.testAdmin">Firebase Test Lab Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtestservice.testAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectAdmin">Environment and Storage Object Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/config#config.agent">Cloud Infrastructure Manager Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/config.agent</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.worker">Dataflow Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.storageDataOwner">Dataplex Storage Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.storageDataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.storageDataWriter">Dataplex Storage Data Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.storageDataWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.worker">Dataproc Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.user">Application Design Center User</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.expressModeServiceInput">Storage Express Mode Service Input</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.expressModeServiceInput</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.expressModeUserAccess">Storage Express Mode User Access</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.expressModeUserAccess</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.dataSecurityScanner">Wiz Data Security Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.dataSecurityScanner</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiedgeportal#aiedgeportal.serviceAgent">AI Edge Portal Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiedgeportal.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.agentSandboxServiceAgent">Vertex AI Agent Sandbox Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.agentSandboxServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.batchPredictionServiceAgent">Vertex AI Batch Prediction Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.batchPredictionServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.customCodeServiceAgent">Vertex AI Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.customCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.extensionCustomCodeServiceAgent">Vertex AI Extension Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.extensionCustomCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.modelMonitoringServiceAgent">Vertex AI Model Monitoring Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.modelMonitoringServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.tuningServiceAgent">Vertex AI Tuning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.tuningServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengineflex#appengineflex.serviceAgent">App Engine flexible environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengineflex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/automl#automl.serviceAgent">AutoML Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.serviceAgent">Recommendations AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ces#ces.serviceAgent">Customer Engagement Suite Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ces.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.serviceAgent">Chronicle Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudasset#cloudasset.serviceAgent">Cloud Asset Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudasset.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudconfig#cloudconfig.serviceAgent">Infrastructure Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudconfig.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudoptimization#cloudoptimization.serviceAgent">Cloud Optimization Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudoptimization.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudtranslate#cloudtranslate.serviceAgent">Cloud Translation API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtranslate.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/compute#compute.serviceAgent">Compute Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/contactcenterinsights#contactcenterinsights.serviceAgent">Contact Center AI Insights Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/contactcenterinsights.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/contentwarehouse#contentwarehouse.serviceAgent">Content Warehouse Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/contentwarehouse.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datalabeling#datalabeling.serviceAgent">Data Labeling Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datalabeling.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datastream#datastream.serviceAgent">Datastream Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datastream.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datastudio#datastudio.managedStorageServiceAgent">Data Studio Managed Storage Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datastudio.managedStorageServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/designcenter#designcenter.serviceAgent">DesignCenter Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/devicerun#devicerun.serviceAgent">Device Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/devicerun.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dialogflow#dialogflow.serviceAgent">Dialogflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dialogflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.serviceAgent">Discovery Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/clouddocumentai#documentaicore.serviceAgent">DocumentAI Core Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/documentaicore.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.clusterServiceAgent">Edge Container Cluster Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.clusterServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.sdkAdminServiceAgent">Firebase Admin SDK Administrator Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.sdkAdminServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasestorage#firebasestorage.serviceAgent">Cloud Storage for Firebase Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasestorage.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firestore#firestore.serviceAgent">Firestore Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firestore.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.serviceAgent">Cluster Director Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/integrations#integrations.serviceAgent">Application Integration Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/livestream#livestream.serviceAgent">Live Stream Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/livestream.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/mediaasset#mediaasset.serviceAgent">Media Asset Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/mediaasset.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/metastore#metastore.serviceAgent">Dataproc Metastore Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/metastore.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/retail#retail.serviceAgent">Retail Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/retail.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/routeoptimization#routeoptimization.serviceAgent">Route Optimization Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/routeoptimization.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/runapps#runapps.serviceAgent">Serverless Integrations Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/runapps.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/saasservicemgmt#saasservicemgmt.serviceAgent">SaaS Service Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/saasservicemgmt.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/spanner#spanner.serviceAgent">Cloud Spanner API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/spanner.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/speech#speech.serviceAgent">Cloud Speech-to-Text Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/speech.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/stream#stream.serviceAgent">Stream Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/stream.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/transcoder#transcoder.serviceAgent">Transcoder Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/transcoder.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vectorsearch#vectorsearch.serviceAgent">Vector Search Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vectorsearch.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visionai#visionai.serviceAgent">Cloud Vision AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visionai.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="storage.objects.createContext" class="permission-name add-link" data-text="storage.objects.createContext" tabindex="-1"><code translate="no" dir="ltr">storage.objects.createContext</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.admin">Application Design Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.folderAdmin">Storage Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketOwner">Storage Legacy Bucket Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketWriter">Storage Legacy Bucket Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyObjectOwner">Storage Legacy Object Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyObjectOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectAdmin">Storage Object Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectCreator">Storage Object Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectCreator</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectUser">Storage Object User</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectAdmin">Environment and Storage Object Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.worker">Dataproc Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.user">Application Design Center User</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.annotationGeneratorService">Storage Annotation Generator Service</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.annotationGeneratorService</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.extensionCustomCodeServiceAgent">Vertex AI Extension Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.extensionCustomCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.sdkAdminServiceAgent">Firebase Admin SDK Administrator Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.sdkAdminServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="storage.objects.delete" class="permission-name add-link" data-text="storage.objects.delete" tabindex="-1"><code translate="no" dir="ltr">storage.objects.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.admin">Application Design Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaserules#firebaserules.system">Firebase Rules System</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaserules.system</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.folderAdmin">Storage Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketOwner">Storage Legacy Bucket Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketWriter">Storage Legacy Bucket Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectAdmin">Storage Object Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectUser">Storage Object User</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/backupdr#backupdr.cloudStorageOperator">Backup and DR Cloud Storage Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/backupdr.cloudStorageOperator</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudmigration#cloudmigration.storageaccess">Velostrata Storage Access</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudmigration.storageaccess</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtestservice#cloudtestservice.testAdmin">Firebase Test Lab Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtestservice.testAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectAdmin">Environment and Storage Object Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/config#config.agent">Cloud Infrastructure Manager Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/config.agent</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.storageDataOwner">Dataplex Storage Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.storageDataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.storageDataWriter">Dataplex Storage Data Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.storageDataWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.worker">Dataproc Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.user">Application Design Center User</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.expressModeServiceInput">Storage Express Mode Service Input</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.expressModeServiceInput</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.expressModeServiceOutput">Storage Express Mode Service Output</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.expressModeServiceOutput</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.expressModeUserAccess">Storage Express Mode User Access</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.expressModeUserAccess</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.dataSecurityScanner">Wiz Data Security Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.dataSecurityScanner</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiedgeportal#aiedgeportal.serviceAgent">AI Edge Portal Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiedgeportal.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.agentSandboxServiceAgent">Vertex AI Agent Sandbox Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.agentSandboxServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.batchPredictionServiceAgent">Vertex AI Batch Prediction Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.batchPredictionServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.customCodeServiceAgent">Vertex AI Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.customCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.extensionCustomCodeServiceAgent">Vertex AI Extension Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.extensionCustomCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.modelMonitoringServiceAgent">Vertex AI Model Monitoring Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.modelMonitoringServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.tuningServiceAgent">Vertex AI Tuning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.tuningServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengineflex#appengineflex.serviceAgent">App Engine flexible environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengineflex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/automl#automl.serviceAgent">AutoML Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.serviceAgent">Recommendations AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ces#ces.serviceAgent">Customer Engagement Suite Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ces.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.serviceAgent">Chronicle Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudasset#cloudasset.serviceAgent">Cloud Asset Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudasset.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudconfig#cloudconfig.serviceAgent">Infrastructure Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudconfig.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudoptimization#cloudoptimization.serviceAgent">Cloud Optimization Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudoptimization.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/contentwarehouse#contentwarehouse.serviceAgent">Content Warehouse Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/contentwarehouse.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datalabeling#datalabeling.serviceAgent">Data Labeling Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datalabeling.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datastudio#datastudio.managedStorageServiceAgent">Data Studio Managed Storage Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datastudio.managedStorageServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/designcenter#designcenter.serviceAgent">DesignCenter Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/devicerun#devicerun.serviceAgent">Device Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/devicerun.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dialogflow#dialogflow.serviceAgent">Dialogflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dialogflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.serviceAgent">Discovery Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/clouddocumentai#documentaicore.serviceAgent">DocumentAI Core Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/documentaicore.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.clusterServiceAgent">Edge Container Cluster Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.clusterServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.sdkAdminServiceAgent">Firebase Admin SDK Administrator Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.sdkAdminServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasestorage#firebasestorage.serviceAgent">Cloud Storage for Firebase Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasestorage.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firestore#firestore.serviceAgent">Firestore Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firestore.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.serviceAgent">Cluster Director Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/livestream#livestream.serviceAgent">Live Stream Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/livestream.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/mediaasset#mediaasset.serviceAgent">Media Asset Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/mediaasset.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/metastore#metastore.serviceAgent">Dataproc Metastore Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/metastore.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/retail#retail.serviceAgent">Retail Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/retail.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/runapps#runapps.serviceAgent">Serverless Integrations Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/runapps.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/saasservicemgmt#saasservicemgmt.serviceAgent">SaaS Service Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/saasservicemgmt.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/spanner#spanner.serviceAgent">Cloud Spanner API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/spanner.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/transcoder#transcoder.serviceAgent">Transcoder Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/transcoder.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visionai#visionai.serviceAgent">Cloud Vision AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visionai.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="storage.objects.deleteContext" class="permission-name add-link" data-text="storage.objects.deleteContext" tabindex="-1"><code translate="no" dir="ltr">storage.objects.deleteContext</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.admin">Application Design Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.folderAdmin">Storage Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketOwner">Storage Legacy Bucket Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyObjectOwner">Storage Legacy Object Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyObjectOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectAdmin">Storage Object Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectUser">Storage Object User</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectAdmin">Environment and Storage Object Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.worker">Dataproc Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.user">Application Design Center User</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.annotationGeneratorService">Storage Annotation Generator Service</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.annotationGeneratorService</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.extensionCustomCodeServiceAgent">Vertex AI Extension Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.extensionCustomCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.sdkAdminServiceAgent">Firebase Admin SDK Administrator Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.sdkAdminServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="storage.objects.get" class="permission-name add-link" data-text="storage.objects.get" tabindex="-1"><code translate="no" dir="ltr">storage.objects.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.admin">Dataflow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.admin">Application Design Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.editor">Designcenter Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.viewer">Application Design Center Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaserules#firebaserules.system">Firebase Rules System</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaserules.system</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.admin">Gemini Cloud Assist Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.editor">Gemini Cloud Assist Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.user">Gemini Cloud Assist User</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.viewer">Gemini Cloud Assist Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.builder">Cloud Run Builder</a> (<code class="role-name" translate="no" dir="ltr">roles/run.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.folderAdmin">Storage Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyObjectOwner">Storage Legacy Object Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyObjectOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyObjectReader">Storage Legacy Object Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyObjectReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectAdmin">Storage Object Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectUser">Storage Object User</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectViewer">Storage Object Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/apphub#apphub.appManagementViewer">App Management Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apphub.appManagementViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.containerRegistryMigrationAdmin">Container Registry -&gt; Artifact Registry Migration Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.containerRegistryMigrationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/backupdr#backupdr.cloudStorageOperator">Backup and DR Cloud Storage Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/backupdr.cloudStorageOperator</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerymigration#bigquerymigration.worker">Task Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerymigration.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/clouddeploy#clouddeploy.jobRunner">Cloud Deploy Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploy.jobRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudmigration#cloudmigration.storageaccess">Velostrata Storage Access</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudmigration.storageaccess</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtestservice#cloudtestservice.testAdmin">Firebase Test Lab Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtestservice.testAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtestservice#cloudtestservice.testViewer">Firebase Test Lab Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtestservice.testViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectAdmin">Environment and Storage Object Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectUser">Environment and Storage Object User</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectViewer">Environment and Storage Object Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/config#config.agent">Cloud Infrastructure Manager Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/config.agent</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.worker">Dataflow Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.storageDataOwner">Dataplex Storage Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.storageDataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.storageDataReader">Dataplex Storage Data Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.storageDataReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.hubAgent">Dataproc Hub Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.hubAgent</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.worker">Dataproc Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.user">Application Design Center User</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.annotationGeneratorService">Storage Annotation Generator Service</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.annotationGeneratorService</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.expressModeServiceOutput">Storage Express Mode Service Output</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.expressModeServiceOutput</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.expressModeUserAccess">Storage Express Mode User Access</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.expressModeUserAccess</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.dataSecurityScanner">Wiz Data Security Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.dataSecurityScanner</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.serverlessImageRegistryScanner">Wiz Serverless &amp; Container Image Registry Scanner</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.serverlessImageRegistryScanner</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiedgeportal#aiedgeportal.serviceAgent">AI Edge Portal Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiedgeportal.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.agentSandboxServiceAgent">Vertex AI Agent Sandbox Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.agentSandboxServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.batchPredictionServiceAgent">Vertex AI Batch Prediction Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.batchPredictionServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.customCodeServiceAgent">Vertex AI Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.customCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.extensionCustomCodeServiceAgent">Vertex AI Extension Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.extensionCustomCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.extensionServiceAgent">Vertex AI Extension Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.extensionServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.modelMonitoringServiceAgent">Vertex AI Model Monitoring Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.modelMonitoringServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.ragServiceAgent">Vertex AI RAG Data Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.ragServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.reasoningEngineServiceAgent">Vertex AI Reasoning Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.reasoningEngineServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.tuningServiceAgent">Vertex AI Tuning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.tuningServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengineflex#appengineflex.serviceAgent">App Engine flexible environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengineflex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/automl#automl.serviceAgent">AutoML Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.serviceAgent">Recommendations AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ces#ces.serviceAgent">Customer Engagement Suite Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ces.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.serviceAgent">Chronicle Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudasset#cloudasset.serviceAgent">Cloud Asset Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudasset.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudconfig#cloudconfig.serviceAgent">Infrastructure Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudconfig.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/clouddeploy#clouddeploy.serviceAgent">Cloud Deploy Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploy.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudoptimization#cloudoptimization.serviceAgent">Cloud Optimization Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudoptimization.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudtranslate#cloudtranslate.serviceAgent">Cloud Translation API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtranslate.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/compliancescanning#compliancescanning.serviceAgent">Compliance Scanning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/compliancescanning.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/compute#compute.serviceAgent">Compute Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/contactcenterinsights#contactcenterinsights.serviceAgent">Contact Center AI Insights Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/contactcenterinsights.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.nodeServiceAgent">[Deprecated] Kubernetes Engine Node Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.nodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.ServiceAgent">Container Analysis Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containerregistry#containerregistry.ServiceAgent">Container Registry Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containerregistry.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containerscanning#containerscanning.ServiceAgent">Container Scanner Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containerscanning.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/contentwarehouse#contentwarehouse.serviceAgent">Content Warehouse Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/contentwarehouse.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datalabeling#datalabeling.serviceAgent">Data Labeling Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datalabeling.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datamigration#datamigration.serviceAgent">Database Migration Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datamigration.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.discoveryServiceAgent">Dataplex Discovery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.discoveryServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datastream#datastream.serviceAgent">Datastream Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datastream.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datastudio#datastudio.managedStorageServiceAgent">Data Studio Managed Storage Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datastudio.managedStorageServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/designcenter#designcenter.serviceAgent">DesignCenter Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/devicerun#devicerun.serviceAgent">Device Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/devicerun.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dialogflow#dialogflow.serviceAgent">Dialogflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dialogflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.serviceAgent">Discovery Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/clouddocumentai#documentaicore.serviceAgent">DocumentAI Core Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/documentaicore.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.clusterServiceAgent">Edge Container Cluster Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.clusterServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/enterpriseknowledgegraph#enterpriseknowledgegraph.serviceAgent">Enterprise Knowledge Graph Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/enterpriseknowledgegraph.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.sdkAdminServiceAgent">Firebase Admin SDK Administrator Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.sdkAdminServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasestorage#firebasestorage.serviceAgent">Cloud Storage for Firebase Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasestorage.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasetelemetry#firebasetelemetry.serviceAgent">Firebase Telemetry Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasetelemetry.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firestore#firestore.serviceAgent">Firestore Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firestore.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/generativelanguage#generativelanguage.serviceAgent">Generative Language Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/generativelanguage.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.serviceAgent">Cluster Director Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/integrations#integrations.serviceAgent">Application Integration Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/livestream#livestream.serviceAgent">Live Stream Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/livestream.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/managedflink#managedflink.serviceAgent">Managed Flink Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/managedflink.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/mediaasset#mediaasset.serviceAgent">Media Asset Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/mediaasset.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/metastore#metastore.serviceAgent">Dataproc Metastore Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/metastore.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/migrationcenter#migrationcenter.serviceAgent">Migration Center Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/migrationcenter.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/retail#retail.serviceAgent">Retail Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/retail.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/routeoptimization#routeoptimization.serviceAgent">Route Optimization Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/routeoptimization.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/runapps#runapps.serviceAgent">Serverless Integrations Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/runapps.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/saasservicemgmt#saasservicemgmt.serviceAgent">SaaS Service Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/saasservicemgmt.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/spanner#spanner.serviceAgent">Cloud Spanner API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/spanner.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/speech#speech.serviceAgent">Cloud Speech-to-Text Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/speech.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/stream#stream.serviceAgent">Stream Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/stream.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/transcoder#transcoder.serviceAgent">Transcoder Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/transcoder.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vectorsearch#vectorsearch.serviceAgent">Vector Search Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vectorsearch.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visionai#visionai.serviceAgent">Cloud Vision AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visionai.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="storage.objects.getIamPolicy" class="permission-name add-link" data-text="storage.objects.getIamPolicy" tabindex="-1"><code translate="no" dir="ltr">storage.objects.getIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.folderAdmin">Storage Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyObjectOwner">Storage Legacy Object Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyObjectOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectAdmin">Storage Object Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectAdmin">Environment and Storage Object Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.worker">Dataproc Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.extensionCustomCodeServiceAgent">Vertex AI Extension Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.extensionCustomCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.tuningServiceAgent">Vertex AI Tuning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.tuningServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengineflex#appengineflex.serviceAgent">App Engine flexible environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengineflex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containerregistry#containerregistry.ServiceAgent">Container Registry Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containerregistry.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.sdkAdminServiceAgent">Firebase Admin SDK Administrator Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.sdkAdminServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasestorage#firebasestorage.serviceAgent">Cloud Storage for Firebase Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasestorage.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="storage.objects.list" class="permission-name add-link" data-text="storage.objects.list" tabindex="-1"><code translate="no" dir="ltr">storage.objects.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.admin">Dataflow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.admin">Application Design Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.editor">Designcenter Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.viewer">Application Design Center Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaserules#firebaserules.system">Firebase Rules System</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaserules.system</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.admin">Gemini Cloud Assist Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.editor">Gemini Cloud Assist Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.user">Gemini Cloud Assist User</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/geminicloudassist#geminicloudassist.viewer">Gemini Cloud Assist Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/geminicloudassist.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.folderAdmin">Storage Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketOwner">Storage Legacy Bucket Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketReader">Storage Legacy Bucket Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketWriter">Storage Legacy Bucket Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectAdmin">Storage Object Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectUser">Storage Object User</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectViewer">Storage Object Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.admin">Workload Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/apphub#apphub.appManagementViewer">App Management Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/apphub.appManagementViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.containerRegistryMigrationAdmin">Container Registry -&gt; Artifact Registry Migration Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.containerRegistryMigrationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/backupdr#backupdr.cloudStorageOperator">Backup and DR Cloud Storage Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/backupdr.cloudStorageOperator</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerymigration#bigquerymigration.orchestrator">Task Orchestrator</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerymigration.orchestrator</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerymigration#bigquerymigration.worker">Task Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerymigration.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/clouddeploy#clouddeploy.jobRunner">Cloud Deploy Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploy.jobRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudmigration#cloudmigration.storageaccess">Velostrata Storage Access</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudmigration.storageaccess</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtestservice#cloudtestservice.testAdmin">Firebase Test Lab Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtestservice.testAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtestservice#cloudtestservice.testViewer">Firebase Test Lab Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtestservice.testViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectAdmin">Environment and Storage Object Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectUser">Environment and Storage Object User</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectViewer">Environment and Storage Object Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/config#config.agent">Cloud Infrastructure Manager Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/config.agent</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.storageDataOwner">Dataplex Storage Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.storageDataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.storageDataReader">Dataplex Storage Data Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.storageDataReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.hubAgent">Dataproc Hub Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.hubAgent</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.worker">Dataproc Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.user">Application Design Center User</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.annotationGeneratorService">Storage Annotation Generator Service</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.annotationGeneratorService</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.expressModeServiceInput">Storage Express Mode Service Input</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.expressModeServiceInput</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.expressModeServiceOutput">Storage Express Mode Service Output</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.expressModeServiceOutput</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.expressModeUserAccess">Storage Express Mode User Access</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.expressModeUserAccess</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.dataSecurityScanner">Wiz Data Security Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.dataSecurityScanner</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.serverlessImageRegistryScanner">Wiz Serverless &amp; Container Image Registry Scanner</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.serverlessImageRegistryScanner</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.deploymentAdmin">Workload Manager Deployment Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.deploymentAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.agentSandboxServiceAgent">Vertex AI Agent Sandbox Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.agentSandboxServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.batchPredictionServiceAgent">Vertex AI Batch Prediction Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.batchPredictionServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.customCodeServiceAgent">Vertex AI Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.customCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.extensionCustomCodeServiceAgent">Vertex AI Extension Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.extensionCustomCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.modelMonitoringServiceAgent">Vertex AI Model Monitoring Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.modelMonitoringServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.ragServiceAgent">Vertex AI RAG Data Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.ragServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.reasoningEngineServiceAgent">Vertex AI Reasoning Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.reasoningEngineServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.tuningServiceAgent">Vertex AI Tuning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.tuningServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengineflex#appengineflex.serviceAgent">App Engine flexible environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengineflex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/automl#automl.serviceAgent">AutoML Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.serviceAgent">Recommendations AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/binaryauthorization#binaryauthorization.serviceAgent">Binary Authorization Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/binaryauthorization.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.serviceAgent">Chronicle Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudconfig#cloudconfig.serviceAgent">Infrastructure Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudconfig.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudoptimization#cloudoptimization.serviceAgent">Cloud Optimization Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudoptimization.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudtranslate#cloudtranslate.serviceAgent">Cloud Translation API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtranslate.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/compliancescanning#compliancescanning.serviceAgent">Compliance Scanning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/compliancescanning.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/compute#compute.serviceAgent">Compute Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/contactcenterinsights#contactcenterinsights.serviceAgent">Contact Center AI Insights Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/contactcenterinsights.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.nodeServiceAgent">[Deprecated] Kubernetes Engine Node Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.nodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containeranalysis#containeranalysis.ServiceAgent">Container Analysis Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containeranalysis.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containerregistry#containerregistry.ServiceAgent">Container Registry Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containerregistry.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/containerscanning#containerscanning.ServiceAgent">Container Scanner Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/containerscanning.ServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/contentwarehouse#contentwarehouse.serviceAgent">Content Warehouse Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/contentwarehouse.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datalabeling#datalabeling.serviceAgent">Data Labeling Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datalabeling.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datamigration#datamigration.serviceAgent">Database Migration Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datamigration.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.discoveryServiceAgent">Dataplex Discovery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.discoveryServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datastream#datastream.serviceAgent">Datastream Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datastream.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datastudio#datastudio.managedStorageServiceAgent">Data Studio Managed Storage Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datastudio.managedStorageServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/designcenter#designcenter.serviceAgent">DesignCenter Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dialogflow#dialogflow.serviceAgent">Dialogflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dialogflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.serviceAgent">Discovery Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/clouddocumentai#documentaicore.serviceAgent">DocumentAI Core Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/documentaicore.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.clusterServiceAgent">Edge Container Cluster Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.clusterServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/enterpriseknowledgegraph#enterpriseknowledgegraph.serviceAgent">Enterprise Knowledge Graph Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/enterpriseknowledgegraph.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.sdkAdminServiceAgent">Firebase Admin SDK Administrator Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.sdkAdminServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasestorage#firebasestorage.serviceAgent">Cloud Storage for Firebase Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasestorage.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firestore#firestore.serviceAgent">Firestore Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firestore.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.serviceAgent">Cluster Director Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/integrations#integrations.serviceAgent">Application Integration Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/livestream#livestream.serviceAgent">Live Stream Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/livestream.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/metastore#metastore.serviceAgent">Dataproc Metastore Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/metastore.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/retail#retail.serviceAgent">Retail Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/retail.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/routeoptimization#routeoptimization.serviceAgent">Route Optimization Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/routeoptimization.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/runapps#runapps.serviceAgent">Serverless Integrations Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/runapps.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/saasservicemgmt#saasservicemgmt.serviceAgent">SaaS Service Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/saasservicemgmt.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/spanner#spanner.serviceAgent">Cloud Spanner API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/spanner.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/speech#speech.serviceAgent">Cloud Speech-to-Text Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/speech.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/stream#stream.serviceAgent">Stream Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/stream.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vectorsearch#vectorsearch.serviceAgent">Vector Search Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vectorsearch.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visionai#visionai.serviceAgent">Cloud Vision AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visionai.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="storage.objects.move" class="permission-name add-link" data-text="storage.objects.move" tabindex="-1"><code translate="no" dir="ltr">storage.objects.move</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.admin">Application Design Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.folderAdmin">Storage Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectAdmin">Storage Object Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectUser">Storage Object User</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectAdmin">Environment and Storage Object Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.user">Application Design Center User</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.extensionCustomCodeServiceAgent">Vertex AI Extension Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.extensionCustomCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.sdkAdminServiceAgent">Firebase Admin SDK Administrator Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.sdkAdminServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="storage.objects.overrideUnlockedRetention" class="permission-name add-link" data-text="storage.objects.overrideUnlockedRetention" tabindex="-1"><code translate="no" dir="ltr">storage.objects.overrideUnlockedRetention</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.folderAdmin">Storage Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyObjectOwner">Storage Legacy Object Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyObjectOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectAdmin">Storage Object Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectAdmin">Environment and Storage Object Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.worker">Dataproc Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.extensionCustomCodeServiceAgent">Vertex AI Extension Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.extensionCustomCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.sdkAdminServiceAgent">Firebase Admin SDK Administrator Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.sdkAdminServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="storage.objects.restore" class="permission-name add-link" data-text="storage.objects.restore" tabindex="-1"><code translate="no" dir="ltr">storage.objects.restore</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.admin">Application Design Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.folderAdmin">Storage Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketOwner">Storage Legacy Bucket Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketWriter">Storage Legacy Bucket Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectAdmin">Storage Object Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectUser">Storage Object User</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectAdmin">Environment and Storage Object Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.worker">Dataproc Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.user">Application Design Center User</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.expressModeUserAccess">Storage Express Mode User Access</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.expressModeUserAccess</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.extensionCustomCodeServiceAgent">Vertex AI Extension Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.extensionCustomCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.sdkAdminServiceAgent">Firebase Admin SDK Administrator Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.sdkAdminServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="storage.objects.setIamPolicy" class="permission-name add-link" data-text="storage.objects.setIamPolicy" tabindex="-1"><code translate="no" dir="ltr">storage.objects.setIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.folderAdmin">Storage Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyObjectOwner">Storage Legacy Object Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyObjectOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectAdmin">Storage Object Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectAdmin">Environment and Storage Object Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.worker">Dataproc Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.extensionCustomCodeServiceAgent">Vertex AI Extension Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.extensionCustomCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.sdkAdminServiceAgent">Firebase Admin SDK Administrator Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.sdkAdminServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="storage.objects.setRetention" class="permission-name add-link" data-text="storage.objects.setRetention" tabindex="-1"><code translate="no" dir="ltr">storage.objects.setRetention</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.folderAdmin">Storage Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketOwner">Storage Legacy Bucket Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketWriter">Storage Legacy Bucket Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyObjectOwner">Storage Legacy Object Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyObjectOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectAdmin">Storage Object Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectAdmin">Environment and Storage Object Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.worker">Dataproc Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.extensionCustomCodeServiceAgent">Vertex AI Extension Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.extensionCustomCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.sdkAdminServiceAgent">Firebase Admin SDK Administrator Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.sdkAdminServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="storage.objects.update" class="permission-name add-link" data-text="storage.objects.update" tabindex="-1"><code translate="no" dir="ltr">storage.objects.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.admin">Application Design Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaserules#firebaserules.system">Firebase Rules System</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaserules.system</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.folderAdmin">Storage Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyObjectOwner">Storage Legacy Object Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyObjectOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectAdmin">Storage Object Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectUser">Storage Object User</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudmigration#cloudmigration.storageaccess">Velostrata Storage Access</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudmigration.storageaccess</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectAdmin">Environment and Storage Object Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/config#config.agent">Cloud Infrastructure Manager Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/config.agent</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.storageDataOwner">Dataplex Storage Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.storageDataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.storageDataWriter">Dataplex Storage Data Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.storageDataWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.worker">Dataproc Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.user">Application Design Center User</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.annotationGeneratorService">Storage Annotation Generator Service</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.annotationGeneratorService</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.expressModeServiceInput">Storage Express Mode Service Input</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.expressModeServiceInput</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.expressModeUserAccess">Storage Express Mode User Access</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.expressModeUserAccess</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.batchPredictionServiceAgent">Vertex AI Batch Prediction Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.batchPredictionServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.customCodeServiceAgent">Vertex AI Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.customCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.extensionCustomCodeServiceAgent">Vertex AI Extension Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.extensionCustomCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.modelMonitoringServiceAgent">Vertex AI Model Monitoring Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.modelMonitoringServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.tuningServiceAgent">Vertex AI Tuning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.tuningServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/automl#automl.serviceAgent">AutoML Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.serviceAgent">Recommendations AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ces#ces.serviceAgent">Customer Engagement Suite Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ces.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudconfig#cloudconfig.serviceAgent">Infrastructure Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudconfig.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudoptimization#cloudoptimization.serviceAgent">Cloud Optimization Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudoptimization.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/compute#compute.serviceAgent">Compute Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/contactcenterinsights#contactcenterinsights.serviceAgent">Contact Center AI Insights Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/contactcenterinsights.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/contentwarehouse#contentwarehouse.serviceAgent">Content Warehouse Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/contentwarehouse.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datalabeling#datalabeling.serviceAgent">Data Labeling Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datalabeling.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/designcenter#designcenter.serviceAgent">DesignCenter Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.serviceAgent">Discovery Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/clouddocumentai#documentaicore.serviceAgent">DocumentAI Core Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/documentaicore.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.clusterServiceAgent">Edge Container Cluster Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.clusterServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.sdkAdminServiceAgent">Firebase Admin SDK Administrator Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.sdkAdminServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasestorage#firebasestorage.serviceAgent">Cloud Storage for Firebase Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasestorage.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.serviceAgent">Cluster Director Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/integrations#integrations.serviceAgent">Application Integration Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/livestream#livestream.serviceAgent">Live Stream Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/livestream.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/metastore#metastore.serviceAgent">Dataproc Metastore Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/metastore.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/retail#retail.serviceAgent">Retail Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/retail.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/routeoptimization#routeoptimization.serviceAgent">Route Optimization Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/routeoptimization.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/speech#speech.serviceAgent">Cloud Speech-to-Text Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/speech.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visionai#visionai.serviceAgent">Cloud Vision AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visionai.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="storage.objects.updateContext" class="permission-name add-link" data-text="storage.objects.updateContext" tabindex="-1"><code translate="no" dir="ltr">storage.objects.updateContext</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.admin">Application Design Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.admin">Storage Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.folderAdmin">Storage Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyBucketOwner">Storage Legacy Bucket Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyBucketOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.legacyObjectOwner">Storage Legacy Object Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.legacyObjectOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectAdmin">Storage Object Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.objectUser">Storage Object User</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.objectUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.environmentAndStorageObjectAdmin">Environment and Storage Object Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.environmentAndStorageObjectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.worker">Dataproc Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/designcenter#designcenter.user">Application Design Center User</a> (<code class="role-name" translate="no" dir="ltr">roles/designcenter.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/storage#storage.annotationGeneratorService">Storage Annotation Generator Service</a> (<code class="role-name" translate="no" dir="ltr">roles/storage.annotationGeneratorService</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.extensionCustomCodeServiceAgent">Vertex AI Extension Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.extensionCustomCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.sdkAdminServiceAgent">Firebase Admin SDK Administrator Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.sdkAdminServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visualinspection#visualinspection.serviceAgent">Visual Inspection AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visualinspection.serviceAgent</code>)</li>
</ul></td>
</tr>
</tbody>
</table>

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
