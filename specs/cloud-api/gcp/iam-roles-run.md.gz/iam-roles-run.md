# Cloud Run roles and permissions

<div class="devsite-article-body clearfix">

This page lists the IAM roles and permissions for Cloud Run. To search through all roles and permissions, see the [role and permission index](/iam/docs/roles-permissions).

## Cloud Run roles

<div results-count-container="">

</div>

<table class="fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="50%">Role</th>
<th>Permissions</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td class="role-description"><h4 id="run.admin" class="role-title add-link" data-text="Cloud Run Admin " tabindex="-1">Cloud Run Admin</h4>
<p>(<code translate="no" dir="ltr">roles/run.admin</code>)</p>
<span class="role-description"> </span>
<p>Full control over all Cloud Run resources.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Cloud Run service</li>
<li>Cloud Run job</li>
<li>Cloud Run instance</li>
<li>Cloud Run worker pool</li>
</ul></td>
<td class="role-permissions"><p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.locations.get</code></li>
<li><code translate="no" dir="ltr">recommender.locations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServiceCostInsights.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServiceCostInsights.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceCostInsights.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceCostInsights.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServiceCostRecommendations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServiceCostRecommendations.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceCostRecommendations.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceCostRecommendations.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServiceIdentityInsights.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServiceIdentityInsights.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceIdentityInsights.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceIdentityInsights.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServiceIdentityRecommendations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServiceIdentityRecommendations.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceIdentityRecommendations.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceIdentityRecommendations.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServicePerformanceInsights.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServicePerformanceInsights.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServicePerformanceInsights.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServicePerformanceInsights.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServicePerformanceRecommendations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServicePerformanceRecommendations.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServicePerformanceRecommendations.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServicePerformanceRecommendations.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServiceSecurityInsights.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServiceSecurityInsights.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceSecurityInsights.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceSecurityInsights.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServiceSecurityRecommendations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServiceSecurityRecommendations.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceSecurityRecommendations.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceSecurityRecommendations.update</code></li>
</ul>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">run.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">run.configurations.get</code></li>
<li><code translate="no" dir="ltr">run.configurations.list</code></li>
<li><code translate="no" dir="ltr">run.executions.cancel</code></li>
<li><code translate="no" dir="ltr">run.executions.delete</code></li>
<li><code translate="no" dir="ltr">run.executions.get</code></li>
<li><code translate="no" dir="ltr">run.executions.list</code></li>
<li><code translate="no" dir="ltr">run.instances.create</code></li>
<li><code translate="no" dir="ltr">run.instances.delete</code></li>
<li><code translate="no" dir="ltr">run.instances.get</code></li>
<li><code translate="no" dir="ltr">run.instances.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">run.instances.invoke</code></li>
<li><code translate="no" dir="ltr">run.instances.list</code></li>
<li><code translate="no" dir="ltr">run.instances.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">run.instances.sshRead</code></li>
<li><code translate="no" dir="ltr">run.instances.sshRoot</code></li>
<li><code translate="no" dir="ltr">run.instances.start</code></li>
<li><code translate="no" dir="ltr">run.instances.stop</code></li>
<li><code translate="no" dir="ltr">run.instances.update</code></li>
<li><code translate="no" dir="ltr">run.jobs.create</code></li>
<li><code translate="no" dir="ltr">run.jobs.createTagBinding</code></li>
<li><code translate="no" dir="ltr">run.jobs.delete</code></li>
<li><code translate="no" dir="ltr">run.jobs.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">run.jobs.get</code></li>
<li><code translate="no" dir="ltr">run.jobs.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">run.jobs.list</code></li>
<li><code translate="no" dir="ltr">run.jobs.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">run.jobs.listTagBindings</code></li>
<li><code translate="no" dir="ltr">run.jobs.run</code></li>
<li><code translate="no" dir="ltr">run.jobs.runWithOverrides</code></li>
<li><code translate="no" dir="ltr">run.jobs.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">run.jobs.sshRead</code></li>
<li><code translate="no" dir="ltr">run.jobs.sshRoot</code></li>
<li><code translate="no" dir="ltr">run.jobs.update</code></li>
<li><code translate="no" dir="ltr">run.locations.list</code></li>
<li><code translate="no" dir="ltr">run.locations.uploadSource</code></li>
<li><code translate="no" dir="ltr">run.operations.delete</code></li>
<li><code translate="no" dir="ltr">run.operations.get</code></li>
<li><code translate="no" dir="ltr">run.operations.list</code></li>
<li><code translate="no" dir="ltr">run.prompts.get</code></li>
<li><code translate="no" dir="ltr">run.revisions.delete</code></li>
<li><code translate="no" dir="ltr">run.revisions.get</code></li>
<li><code translate="no" dir="ltr">run.revisions.list</code></li>
<li><code translate="no" dir="ltr">run.routes.get</code></li>
<li><code translate="no" dir="ltr">run.routes.invoke</code></li>
<li><code translate="no" dir="ltr">run.routes.list</code></li>
<li><code translate="no" dir="ltr">run.services.create</code></li>
<li><code translate="no" dir="ltr">run.services.createTagBinding</code></li>
<li><code translate="no" dir="ltr">run.services.delete</code></li>
<li><code translate="no" dir="ltr">run.services.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">run.services.get</code></li>
<li><code translate="no" dir="ltr">run.services.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">run.services.list</code></li>
<li><code translate="no" dir="ltr">run.services.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">run.services.listTagBindings</code></li>
<li><code translate="no" dir="ltr">run.services.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">run.services.sshRead</code></li>
<li><code translate="no" dir="ltr">run.services.sshRoot</code></li>
<li><code translate="no" dir="ltr">run.services.update</code></li>
<li><code translate="no" dir="ltr">run.tasks.get</code></li>
<li><code translate="no" dir="ltr">run.tasks.list</code></li>
<li><code translate="no" dir="ltr">run.workerpools.create</code></li>
<li><code translate="no" dir="ltr">run.workerpools.delete</code></li>
<li><code translate="no" dir="ltr">run.workerpools.get</code></li>
<li><code translate="no" dir="ltr">run.workerpools.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">run.workerpools.list</code></li>
<li><code translate="no" dir="ltr">run.workerpools.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">run.workerpools.sshRead</code></li>
<li><code translate="no" dir="ltr">run.workerpools.sshRoot</code></li>
<li><code translate="no" dir="ltr">run.workerpools.update</code></li>
</ul></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="run.builder" class="role-title add-link" data-text="Cloud Run Builder " tabindex="-1">Cloud Run Builder</h4>
<p>(<code translate="no" dir="ltr">roles/run.builder</code>)</p>
<span class="role-description"> </span>
<p>Can build Cloud Run functions and source deployed services.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">artifactregistry.repositories.deleteArtifacts</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.downloadArtifacts</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.uploadArtifacts</code></p>
<p><code translate="no" dir="ltr">logging.logEntries.create</code></p>
<p><code translate="no" dir="ltr">source.repos.get</code></p>
<p><code translate="no" dir="ltr">storage.objects.get</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="run.developer" class="role-title add-link" data-text="Cloud Run Developer " tabindex="-1">Cloud Run Developer</h4>
<p>(<code translate="no" dir="ltr">roles/run.developer</code>)</p>
<span class="role-description"> </span>
<p>Read and write access to all Cloud Run resources.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Cloud Run service</li>
<li>Cloud Run job</li>
<li>Cloud Run instance</li>
<li>Cloud Run worker pool</li>
</ul></td>
<td class="role-permissions"><p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.locations.get</code></li>
<li><code translate="no" dir="ltr">recommender.locations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServiceCostInsights.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServiceCostInsights.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceCostInsights.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceCostInsights.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServiceCostRecommendations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServiceCostRecommendations.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceCostRecommendations.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceCostRecommendations.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServiceIdentityInsights.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServiceIdentityInsights.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceIdentityInsights.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceIdentityInsights.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServiceIdentityRecommendations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServiceIdentityRecommendations.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceIdentityRecommendations.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceIdentityRecommendations.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServicePerformanceInsights.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServicePerformanceInsights.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServicePerformanceInsights.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServicePerformanceInsights.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServicePerformanceRecommendations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServicePerformanceRecommendations.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServicePerformanceRecommendations.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServicePerformanceRecommendations.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServiceSecurityInsights.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServiceSecurityInsights.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceSecurityInsights.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceSecurityInsights.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServiceSecurityRecommendations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServiceSecurityRecommendations.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceSecurityRecommendations.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceSecurityRecommendations.update</code></li>
</ul>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">run.configurations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">run.configurations.get</code></li>
<li><code translate="no" dir="ltr">run.configurations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">run.executions.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">run.executions.cancel</code></li>
<li><code translate="no" dir="ltr">run.executions.delete</code></li>
<li><code translate="no" dir="ltr">run.executions.get</code></li>
<li><code translate="no" dir="ltr">run.executions.list</code></li>
</ul>
<p><code translate="no" dir="ltr">run.instances.create</code></p>
<p><code translate="no" dir="ltr">run.instances.delete</code></p>
<p><code translate="no" dir="ltr">run.instances.get</code></p>
<p><code translate="no" dir="ltr">run.instances.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">run.instances.invoke</code></p>
<p><code translate="no" dir="ltr">run.instances.list</code></p>
<p><code translate="no" dir="ltr">run.instances.sshRead</code></p>
<p><code translate="no" dir="ltr">run.instances.sshRoot</code></p>
<p><code translate="no" dir="ltr">run.instances.start</code></p>
<p><code translate="no" dir="ltr">run.instances.stop</code></p>
<p><code translate="no" dir="ltr">run.instances.update</code></p>
<p><code translate="no" dir="ltr">run.jobs.create</code></p>
<p><code translate="no" dir="ltr">run.jobs.delete</code></p>
<p><code translate="no" dir="ltr">run.jobs.get</code></p>
<p><code translate="no" dir="ltr">run.jobs.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">run.jobs.list</code></p>
<p><code translate="no" dir="ltr">run.jobs.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">run.jobs.listTagBindings</code></p>
<p><code translate="no" dir="ltr">run.jobs.run</code></p>
<p><code translate="no" dir="ltr">run.jobs.runWithOverrides</code></p>
<p><code translate="no" dir="ltr">run.jobs.sshRead</code></p>
<p><code translate="no" dir="ltr">run.jobs.sshRoot</code></p>
<p><code translate="no" dir="ltr">run.jobs.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">run.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">run.locations.list</code></li>
<li><code translate="no" dir="ltr">run.locations.uploadSource</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">run.operations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">run.operations.delete</code></li>
<li><code translate="no" dir="ltr">run.operations.get</code></li>
<li><code translate="no" dir="ltr">run.operations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">run.prompts.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">run.revisions.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">run.revisions.delete</code></li>
<li><code translate="no" dir="ltr">run.revisions.get</code></li>
<li><code translate="no" dir="ltr">run.revisions.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">run.routes.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">run.routes.get</code></li>
<li><code translate="no" dir="ltr">run.routes.invoke</code></li>
<li><code translate="no" dir="ltr">run.routes.list</code></li>
</ul>
<p><code translate="no" dir="ltr">run.services.create</code></p>
<p><code translate="no" dir="ltr">run.services.delete</code></p>
<p><code translate="no" dir="ltr">run.services.get</code></p>
<p><code translate="no" dir="ltr">run.services.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">run.services.list</code></p>
<p><code translate="no" dir="ltr">run.services.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">run.services.listTagBindings</code></p>
<p><code translate="no" dir="ltr">run.services.sshRead</code></p>
<p><code translate="no" dir="ltr">run.services.sshRoot</code></p>
<p><code translate="no" dir="ltr">run.services.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">run.tasks.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">run.tasks.get</code></li>
<li><code translate="no" dir="ltr">run.tasks.list</code></li>
</ul>
<p><code translate="no" dir="ltr">run.workerpools.create</code></p>
<p><code translate="no" dir="ltr">run.workerpools.delete</code></p>
<p><code translate="no" dir="ltr">run.workerpools.get</code></p>
<p><code translate="no" dir="ltr">run.workerpools.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">run.workerpools.list</code></p>
<p><code translate="no" dir="ltr">run.workerpools.sshRead</code></p>
<p><code translate="no" dir="ltr">run.workerpools.sshRoot</code></p>
<p><code translate="no" dir="ltr">run.workerpools.update</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="run.editor" class="role-title add-link" data-text="Cloud Run Editor " tabindex="-1">Cloud Run Editor</h4>
<p>(<code translate="no" dir="ltr">roles/run.editor</code>)</p>
<span class="role-description"> </span>
<p>Editor role for Cloud Run</p></td>
<td class="role-permissions"><p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.locations.get</code></li>
<li><code translate="no" dir="ltr">recommender.locations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServiceCostInsights.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServiceCostInsights.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceCostInsights.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceCostInsights.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServiceCostRecommendations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServiceCostRecommendations.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceCostRecommendations.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceCostRecommendations.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServiceIdentityInsights.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServiceIdentityInsights.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceIdentityInsights.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceIdentityInsights.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServiceIdentityRecommendations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServiceIdentityRecommendations.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceIdentityRecommendations.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceIdentityRecommendations.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServicePerformanceInsights.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServicePerformanceInsights.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServicePerformanceInsights.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServicePerformanceInsights.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServicePerformanceRecommendations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServicePerformanceRecommendations.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServicePerformanceRecommendations.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServicePerformanceRecommendations.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServiceSecurityInsights.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServiceSecurityInsights.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceSecurityInsights.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceSecurityInsights.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServiceSecurityRecommendations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServiceSecurityRecommendations.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceSecurityRecommendations.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceSecurityRecommendations.update</code></li>
</ul>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">run.configurations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">run.configurations.get</code></li>
<li><code translate="no" dir="ltr">run.configurations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">run.executions.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">run.executions.cancel</code></li>
<li><code translate="no" dir="ltr">run.executions.delete</code></li>
<li><code translate="no" dir="ltr">run.executions.get</code></li>
<li><code translate="no" dir="ltr">run.executions.list</code></li>
</ul>
<p><code translate="no" dir="ltr">run.instances.create</code></p>
<p><code translate="no" dir="ltr">run.instances.delete</code></p>
<p><code translate="no" dir="ltr">run.instances.get</code></p>
<p><code translate="no" dir="ltr">run.instances.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">run.instances.invoke</code></p>
<p><code translate="no" dir="ltr">run.instances.list</code></p>
<p><code translate="no" dir="ltr">run.instances.sshRead</code></p>
<p><code translate="no" dir="ltr">run.instances.sshRoot</code></p>
<p><code translate="no" dir="ltr">run.instances.start</code></p>
<p><code translate="no" dir="ltr">run.instances.stop</code></p>
<p><code translate="no" dir="ltr">run.instances.update</code></p>
<p><code translate="no" dir="ltr">run.jobs.create</code></p>
<p><code translate="no" dir="ltr">run.jobs.delete</code></p>
<p><code translate="no" dir="ltr">run.jobs.get</code></p>
<p><code translate="no" dir="ltr">run.jobs.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">run.jobs.list</code></p>
<p><code translate="no" dir="ltr">run.jobs.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">run.jobs.listTagBindings</code></p>
<p><code translate="no" dir="ltr">run.jobs.run</code></p>
<p><code translate="no" dir="ltr">run.jobs.runWithOverrides</code></p>
<p><code translate="no" dir="ltr">run.jobs.sshRead</code></p>
<p><code translate="no" dir="ltr">run.jobs.sshRoot</code></p>
<p><code translate="no" dir="ltr">run.jobs.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">run.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">run.locations.list</code></li>
<li><code translate="no" dir="ltr">run.locations.uploadSource</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">run.operations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">run.operations.delete</code></li>
<li><code translate="no" dir="ltr">run.operations.get</code></li>
<li><code translate="no" dir="ltr">run.operations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">run.prompts.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">run.revisions.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">run.revisions.delete</code></li>
<li><code translate="no" dir="ltr">run.revisions.get</code></li>
<li><code translate="no" dir="ltr">run.revisions.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">run.routes.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">run.routes.get</code></li>
<li><code translate="no" dir="ltr">run.routes.invoke</code></li>
<li><code translate="no" dir="ltr">run.routes.list</code></li>
</ul>
<p><code translate="no" dir="ltr">run.services.create</code></p>
<p><code translate="no" dir="ltr">run.services.delete</code></p>
<p><code translate="no" dir="ltr">run.services.get</code></p>
<p><code translate="no" dir="ltr">run.services.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">run.services.list</code></p>
<p><code translate="no" dir="ltr">run.services.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">run.services.listTagBindings</code></p>
<p><code translate="no" dir="ltr">run.services.sshRead</code></p>
<p><code translate="no" dir="ltr">run.services.sshRoot</code></p>
<p><code translate="no" dir="ltr">run.services.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">run.tasks.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">run.tasks.get</code></li>
<li><code translate="no" dir="ltr">run.tasks.list</code></li>
</ul>
<p><code translate="no" dir="ltr">run.workerpools.create</code></p>
<p><code translate="no" dir="ltr">run.workerpools.delete</code></p>
<p><code translate="no" dir="ltr">run.workerpools.get</code></p>
<p><code translate="no" dir="ltr">run.workerpools.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">run.workerpools.list</code></p>
<p><code translate="no" dir="ltr">run.workerpools.sshRead</code></p>
<p><code translate="no" dir="ltr">run.workerpools.sshRoot</code></p>
<p><code translate="no" dir="ltr">run.workerpools.update</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="run.invoker" class="role-title add-link" data-text="Cloud Run Invoker " tabindex="-1">Cloud Run Invoker</h4>
<p>(<code translate="no" dir="ltr">roles/run.invoker</code>)</p>
<span class="role-description"> </span>
<p>Can invoke Cloud Run services, instances and execute Cloud Run jobs.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Cloud Run service</li>
<li>Cloud Run job</li>
<li>Cloud Run instance</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">run.instances.invoke</code></p>
<p><code translate="no" dir="ltr">run.jobs.run</code></p>
<p><code translate="no" dir="ltr">run.routes.invoke</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="run.viewer" class="role-title add-link" data-text="Cloud Run Viewer " tabindex="-1">Cloud Run Viewer</h4>
<p>(<code translate="no" dir="ltr">roles/run.viewer</code>)</p>
<span class="role-description"> </span>
<p>Can view the state of all Cloud Run resources, including IAM policies.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Cloud Run service</li>
<li>Cloud Run job</li>
<li>Cloud Run instance</li>
<li>Cloud Run worker pool</li>
</ul></td>
<td class="role-permissions"><p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.locations.get</code></li>
<li><code translate="no" dir="ltr">recommender.locations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">recommender.runServiceCostInsights.get</code></p>
<p><code translate="no" dir="ltr">recommender.runServiceCostInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.runServiceCostRecommendations.get</code></p>
<p><code translate="no" dir="ltr">recommender.runServiceCostRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.runServiceIdentityInsights.get</code></p>
<p><code translate="no" dir="ltr">recommender.runServiceIdentityInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.runServiceIdentityRecommendations.get</code></p>
<p><code translate="no" dir="ltr">recommender.runServiceIdentityRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.runServicePerformanceInsights.get</code></p>
<p><code translate="no" dir="ltr">recommender.runServicePerformanceInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.runServicePerformanceRecommendations.get</code></p>
<p><code translate="no" dir="ltr">recommender.runServicePerformanceRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.runServiceSecurityInsights.get</code></p>
<p><code translate="no" dir="ltr">recommender.runServiceSecurityInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.runServiceSecurityRecommendations.get</code></p>
<p><code translate="no" dir="ltr">recommender.runServiceSecurityRecommendations.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">run.configurations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">run.configurations.get</code></li>
<li><code translate="no" dir="ltr">run.configurations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">run.executions.get</code></p>
<p><code translate="no" dir="ltr">run.executions.list</code></p>
<p><code translate="no" dir="ltr">run.instances.get</code></p>
<p><code translate="no" dir="ltr">run.instances.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">run.instances.list</code></p>
<p><code translate="no" dir="ltr">run.jobs.get</code></p>
<p><code translate="no" dir="ltr">run.jobs.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">run.jobs.list</code></p>
<p><code translate="no" dir="ltr">run.jobs.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">run.jobs.listTagBindings</code></p>
<p><code translate="no" dir="ltr">run.locations.list</code></p>
<p><code translate="no" dir="ltr">run.operations.get</code></p>
<p><code translate="no" dir="ltr">run.operations.list</code></p>
<p><code translate="no" dir="ltr">run.prompts.get</code></p>
<p><code translate="no" dir="ltr">run.revisions.get</code></p>
<p><code translate="no" dir="ltr">run.revisions.list</code></p>
<p><code translate="no" dir="ltr">run.routes.get</code></p>
<p><code translate="no" dir="ltr">run.routes.list</code></p>
<p><code translate="no" dir="ltr">run.services.get</code></p>
<p><code translate="no" dir="ltr">run.services.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">run.services.list</code></p>
<p><code translate="no" dir="ltr">run.services.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">run.services.listTagBindings</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">run.tasks.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">run.tasks.get</code></li>
<li><code translate="no" dir="ltr">run.tasks.list</code></li>
</ul>
<p><code translate="no" dir="ltr">run.workerpools.get</code></p>
<p><code translate="no" dir="ltr">run.workerpools.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">run.workerpools.list</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="run.jobsExecutor" class="role-title add-link" data-text="Cloud Run Jobs Executor " tabindex="-1">Cloud Run Jobs Executor</h4>
<p>(<code translate="no" dir="ltr">roles/run.jobsExecutor</code>)</p>
<span class="role-description custom"> </span>
<p>Can execute and cancel Cloud Run jobs.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">run.executions.cancel</code></p>
<p><code translate="no" dir="ltr">run.jobs.run</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="run.jobsExecutorWithOverrides" class="role-title add-link" data-text="Cloud Run Jobs Executor With Overrides " tabindex="-1">Cloud Run Jobs Executor With Overrides</h4>
<p>(<code translate="no" dir="ltr">roles/run.jobsExecutorWithOverrides</code>)</p>
<span class="role-description custom"> </span>
<p>Can execute and cancel Cloud Run jobs with overrides.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">run.executions.cancel</code></p>
<p><code translate="no" dir="ltr">run.jobs.run</code></p>
<p><code translate="no" dir="ltr">run.jobs.runWithOverrides</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="run.servicesInvoker" class="role-title add-link" data-text="Cloud Run Service Invoker " tabindex="-1">Cloud Run Service Invoker</h4>
<p>(<code translate="no" dir="ltr">roles/run.servicesInvoker</code>)</p>
<span class="role-description"> </span>
<p>Can invoke Cloud Run services.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">run.routes.invoke</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="run.sourceDeveloper" class="role-title add-link" data-text="Cloud Run Source Developer " tabindex="-1">Cloud Run Source Developer</h4>
<p>(<code translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<span class="role-description"> </span>
<p>Deploy and manage Cloud Run source deployed resources.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">artifactregistry.attachments.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.attachments.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.dockerimages.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.dockerimages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.dockerimages.list</code></li>
</ul>
<p><code translate="no" dir="ltr">artifactregistry.files.download</code></p>
<p><code translate="no" dir="ltr">artifactregistry.files.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.files.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.locations.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.locations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.mavenartifacts.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.mavenartifacts.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.mavenartifacts.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.npmpackages.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.npmpackages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.npmpackages.list</code></li>
</ul>
<p><code translate="no" dir="ltr">artifactregistry.packages.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.packages.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.projectconfigs.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.projectsettings.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.pythonpackages.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.pythonpackages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.pythonpackages.list</code></li>
</ul>
<p><code translate="no" dir="ltr">artifactregistry.repositories.create</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.downloadArtifacts</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.exportArtifacts</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.listTagBindings</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.readViaVirtualRepository</code></p>
<p><code translate="no" dir="ltr">artifactregistry.rules.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.rules.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.tags.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.tags.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.versions.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.versions.list</code></p>
<p><code translate="no" dir="ltr">cloudbuild.builds.create</code></p>
<p><code translate="no" dir="ltr">cloudbuild.builds.get</code></p>
<p><code translate="no" dir="ltr">cloudbuild.builds.list</code></p>
<p><code translate="no" dir="ltr">cloudbuild.builds.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudbuild.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudbuild.locations.get</code></li>
<li><code translate="no" dir="ltr">cloudbuild.locations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudbuild.operations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudbuild.operations.get</code></li>
<li><code translate="no" dir="ltr">cloudbuild.operations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudkms.keyHandles.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudkms.keyHandles.create</code></li>
<li><code translate="no" dir="ltr">cloudkms.keyHandles.get</code></li>
<li><code translate="no" dir="ltr">cloudkms.keyHandles.list</code></li>
</ul>
<p><code translate="no" dir="ltr">cloudkms.operations.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.projects.showEffectiveAutokeyConfig</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.create</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.createTagBinding</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.delete</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.get</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.list</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.listTagBindings</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.publish</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.attach</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.create</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.createTagBinding</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.delete</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.get</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.list</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.listTagBindings</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.publish</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.undelete</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.update</code></p>
<p><code translate="no" dir="ltr">eventarc.enrollments.create</code></p>
<p><code translate="no" dir="ltr">eventarc.enrollments.delete</code></p>
<p><code translate="no" dir="ltr">eventarc.enrollments.get</code></p>
<p><code translate="no" dir="ltr">eventarc.enrollments.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.enrollments.list</code></p>
<p><code translate="no" dir="ltr">eventarc.enrollments.update</code></p>
<p><code translate="no" dir="ltr">eventarc.googleApiSources.create</code></p>
<p><code translate="no" dir="ltr">eventarc.googleApiSources.delete</code></p>
<p><code translate="no" dir="ltr">eventarc.googleApiSources.get</code></p>
<p><code translate="no" dir="ltr">eventarc.googleApiSources.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.googleApiSources.list</code></p>
<p><code translate="no" dir="ltr">eventarc.googleApiSources.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">eventarc.googleChannelConfigs.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">eventarc.googleChannelConfigs.get</code></li>
<li><code translate="no" dir="ltr">eventarc.googleChannelConfigs.update</code></li>
</ul>
<p><code translate="no" dir="ltr">eventarc.kafkaSources.create</code></p>
<p><code translate="no" dir="ltr">eventarc.kafkaSources.delete</code></p>
<p><code translate="no" dir="ltr">eventarc.kafkaSources.get</code></p>
<p><code translate="no" dir="ltr">eventarc.kafkaSources.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.kafkaSources.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">eventarc.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">eventarc.locations.get</code></li>
<li><code translate="no" dir="ltr">eventarc.locations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">eventarc.operations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">eventarc.operations.cancel</code></li>
<li><code translate="no" dir="ltr">eventarc.operations.delete</code></li>
<li><code translate="no" dir="ltr">eventarc.operations.get</code></li>
<li><code translate="no" dir="ltr">eventarc.operations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">eventarc.pipelines.create</code></p>
<p><code translate="no" dir="ltr">eventarc.pipelines.delete</code></p>
<p><code translate="no" dir="ltr">eventarc.pipelines.get</code></p>
<p><code translate="no" dir="ltr">eventarc.pipelines.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.pipelines.list</code></p>
<p><code translate="no" dir="ltr">eventarc.pipelines.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">eventarc.providers.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">eventarc.providers.get</code></li>
<li><code translate="no" dir="ltr">eventarc.providers.list</code></li>
</ul>
<p><code translate="no" dir="ltr">eventarc.triggers.create</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.createTagBinding</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.delete</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.get</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.list</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.listTagBindings</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.undelete</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.update</code></p>
<p><code translate="no" dir="ltr">orgpolicy.policy.get</code></p>
<p><code translate="no" dir="ltr">pubsub.messageTransforms.validate</code></p>
<p><code translate="no" dir="ltr">pubsub.schemas.attach</code></p>
<p><code translate="no" dir="ltr">pubsub.schemas.commit</code></p>
<p><code translate="no" dir="ltr">pubsub.schemas.create</code></p>
<p><code translate="no" dir="ltr">pubsub.schemas.delete</code></p>
<p><code translate="no" dir="ltr">pubsub.schemas.get</code></p>
<p><code translate="no" dir="ltr">pubsub.schemas.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">pubsub.schemas.list</code></p>
<p><code translate="no" dir="ltr">pubsub.schemas.listRevisions</code></p>
<p><code translate="no" dir="ltr">pubsub.schemas.rollback</code></p>
<p><code translate="no" dir="ltr">pubsub.schemas.validate</code></p>
<p><code translate="no" dir="ltr">pubsub.snapshots.create</code></p>
<p><code translate="no" dir="ltr">pubsub.snapshots.createTagBinding</code></p>
<p><code translate="no" dir="ltr">pubsub.snapshots.delete</code></p>
<p><code translate="no" dir="ltr">pubsub.snapshots.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">pubsub.snapshots.get</code></p>
<p><code translate="no" dir="ltr">pubsub.snapshots.list</code></p>
<p><code translate="no" dir="ltr">pubsub.snapshots.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">pubsub.snapshots.listTagBindings</code></p>
<p><code translate="no" dir="ltr">pubsub.snapshots.seek</code></p>
<p><code translate="no" dir="ltr">pubsub.snapshots.update</code></p>
<p><code translate="no" dir="ltr">pubsub.subscriptions.consume</code></p>
<p><code translate="no" dir="ltr">pubsub.subscriptions.create</code></p>
<p><code translate="no" dir="ltr">pubsub.subscriptions.createTagBinding</code></p>
<p><code translate="no" dir="ltr">pubsub.subscriptions.delete</code></p>
<p><code translate="no" dir="ltr">pubsub.subscriptions.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">pubsub.subscriptions.get</code></p>
<p><code translate="no" dir="ltr">pubsub.subscriptions.list</code></p>
<p><code translate="no" dir="ltr">pubsub.subscriptions.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">pubsub.subscriptions.listTagBindings</code></p>
<p><code translate="no" dir="ltr">pubsub.subscriptions.update</code></p>
<p><code translate="no" dir="ltr">pubsub.topics.attachSubscription</code></p>
<p><code translate="no" dir="ltr">pubsub.topics.create</code></p>
<p><code translate="no" dir="ltr">pubsub.topics.createTagBinding</code></p>
<p><code translate="no" dir="ltr">pubsub.topics.delete</code></p>
<p><code translate="no" dir="ltr">pubsub.topics.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">pubsub.topics.detachSubscription</code></p>
<p><code translate="no" dir="ltr">pubsub.topics.get</code></p>
<p><code translate="no" dir="ltr">pubsub.topics.list</code></p>
<p><code translate="no" dir="ltr">pubsub.topics.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">pubsub.topics.listTagBindings</code></p>
<p><code translate="no" dir="ltr">pubsub.topics.publish</code></p>
<p><code translate="no" dir="ltr">pubsub.topics.update</code></p>
<p><code translate="no" dir="ltr">pubsub.topics.updateTag</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.locations.get</code></li>
<li><code translate="no" dir="ltr">recommender.locations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServiceCostInsights.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServiceCostInsights.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceCostInsights.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceCostInsights.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServiceCostRecommendations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServiceCostRecommendations.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceCostRecommendations.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceCostRecommendations.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServiceIdentityInsights.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServiceIdentityInsights.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceIdentityInsights.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceIdentityInsights.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServiceIdentityRecommendations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServiceIdentityRecommendations.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceIdentityRecommendations.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceIdentityRecommendations.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServicePerformanceInsights.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServicePerformanceInsights.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServicePerformanceInsights.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServicePerformanceInsights.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServicePerformanceRecommendations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServicePerformanceRecommendations.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServicePerformanceRecommendations.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServicePerformanceRecommendations.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServiceSecurityInsights.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServiceSecurityInsights.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceSecurityInsights.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceSecurityInsights.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.runServiceSecurityRecommendations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.runServiceSecurityRecommendations.get</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceSecurityRecommendations.list</code></li>
<li><code translate="no" dir="ltr">recommender.runServiceSecurityRecommendations.update</code></li>
</ul>
<p><code translate="no" dir="ltr">remotebuildexecution.blobs.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">run.configurations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">run.configurations.get</code></li>
<li><code translate="no" dir="ltr">run.configurations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">run.executions.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">run.executions.cancel</code></li>
<li><code translate="no" dir="ltr">run.executions.delete</code></li>
<li><code translate="no" dir="ltr">run.executions.get</code></li>
<li><code translate="no" dir="ltr">run.executions.list</code></li>
</ul>
<p><code translate="no" dir="ltr">run.instances.create</code></p>
<p><code translate="no" dir="ltr">run.instances.delete</code></p>
<p><code translate="no" dir="ltr">run.instances.get</code></p>
<p><code translate="no" dir="ltr">run.instances.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">run.instances.invoke</code></p>
<p><code translate="no" dir="ltr">run.instances.list</code></p>
<p><code translate="no" dir="ltr">run.instances.sshRead</code></p>
<p><code translate="no" dir="ltr">run.instances.sshRoot</code></p>
<p><code translate="no" dir="ltr">run.instances.start</code></p>
<p><code translate="no" dir="ltr">run.instances.stop</code></p>
<p><code translate="no" dir="ltr">run.instances.update</code></p>
<p><code translate="no" dir="ltr">run.jobs.create</code></p>
<p><code translate="no" dir="ltr">run.jobs.delete</code></p>
<p><code translate="no" dir="ltr">run.jobs.get</code></p>
<p><code translate="no" dir="ltr">run.jobs.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">run.jobs.list</code></p>
<p><code translate="no" dir="ltr">run.jobs.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">run.jobs.listTagBindings</code></p>
<p><code translate="no" dir="ltr">run.jobs.run</code></p>
<p><code translate="no" dir="ltr">run.jobs.runWithOverrides</code></p>
<p><code translate="no" dir="ltr">run.jobs.sshRead</code></p>
<p><code translate="no" dir="ltr">run.jobs.sshRoot</code></p>
<p><code translate="no" dir="ltr">run.jobs.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">run.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">run.locations.list</code></li>
<li><code translate="no" dir="ltr">run.locations.uploadSource</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">run.operations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">run.operations.delete</code></li>
<li><code translate="no" dir="ltr">run.operations.get</code></li>
<li><code translate="no" dir="ltr">run.operations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">run.prompts.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">run.revisions.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">run.revisions.delete</code></li>
<li><code translate="no" dir="ltr">run.revisions.get</code></li>
<li><code translate="no" dir="ltr">run.revisions.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">run.routes.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">run.routes.get</code></li>
<li><code translate="no" dir="ltr">run.routes.invoke</code></li>
<li><code translate="no" dir="ltr">run.routes.list</code></li>
</ul>
<p><code translate="no" dir="ltr">run.services.create</code></p>
<p><code translate="no" dir="ltr">run.services.delete</code></p>
<p><code translate="no" dir="ltr">run.services.get</code></p>
<p><code translate="no" dir="ltr">run.services.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">run.services.list</code></p>
<p><code translate="no" dir="ltr">run.services.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">run.services.listTagBindings</code></p>
<p><code translate="no" dir="ltr">run.services.sshRead</code></p>
<p><code translate="no" dir="ltr">run.services.sshRoot</code></p>
<p><code translate="no" dir="ltr">run.services.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">run.tasks.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">run.tasks.get</code></li>
<li><code translate="no" dir="ltr">run.tasks.list</code></li>
</ul>
<p><code translate="no" dir="ltr">run.workerpools.create</code></p>
<p><code translate="no" dir="ltr">run.workerpools.delete</code></p>
<p><code translate="no" dir="ltr">run.workerpools.get</code></p>
<p><code translate="no" dir="ltr">run.workerpools.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">run.workerpools.list</code></p>
<p><code translate="no" dir="ltr">run.workerpools.sshRead</code></p>
<p><code translate="no" dir="ltr">run.workerpools.sshRoot</code></p>
<p><code translate="no" dir="ltr">run.workerpools.update</code></p>
<p><code translate="no" dir="ltr">serviceusage.catalogs.listMembers</code></p>
<p><code translate="no" dir="ltr">serviceusage.consumerpolicy.analyze</code></p>
<p><code translate="no" dir="ltr">serviceusage.consumerpolicy.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.effectivepolicy.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">serviceusage.groups.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">serviceusage.groups.list</code></li>
<li><code translate="no" dir="ltr">serviceusage.groups.listExpandedMembers</code></li>
<li><code translate="no" dir="ltr">serviceusage.groups.listMembers</code></li>
</ul>
<p><code translate="no" dir="ltr">serviceusage.quotas.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.list</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.listApis</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.listDependentServices</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.use</code></p>
<p><code translate="no" dir="ltr">serviceusage.values.test</code></p>
<p><code translate="no" dir="ltr">storage.buckets.create</code></p>
<p><code translate="no" dir="ltr">storage.buckets.get</code></p>
<p><code translate="no" dir="ltr">storage.buckets.list</code></p>
<p><code translate="no" dir="ltr">storage.folders.create</code></p>
<p><code translate="no" dir="ltr">storage.folders.get</code></p>
<p><code translate="no" dir="ltr">storage.folders.list</code></p>
<p><code translate="no" dir="ltr">storage.managedFolders.create</code></p>
<p><code translate="no" dir="ltr">storage.managedFolders.get</code></p>
<p><code translate="no" dir="ltr">storage.managedFolders.list</code></p>
<p><code translate="no" dir="ltr">storage.multipartUploads.abort</code></p>
<p><code translate="no" dir="ltr">storage.multipartUploads.create</code></p>
<p><code translate="no" dir="ltr">storage.multipartUploads.listParts</code></p>
<p><code translate="no" dir="ltr">storage.objects.create</code></p>
<p><code translate="no" dir="ltr">storage.objects.createContext</code></p>
<p><code translate="no" dir="ltr">storage.objects.get</code></p>
<p><code translate="no" dir="ltr">storage.objects.list</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="run.sourceViewer" class="role-title add-link" data-text="Cloud Run Source Viewer " tabindex="-1">Cloud Run Source Viewer</h4>
<p>(<code translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<span class="role-description"> </span>
<p>View Cloud Run source deployed resources.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">artifactregistry.repositories.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.list</code></p>
<p><code translate="no" dir="ltr">cloudbuild.builds.get</code></p>
<p><code translate="no" dir="ltr">cloudbuild.builds.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudbuild.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudbuild.locations.get</code></li>
<li><code translate="no" dir="ltr">cloudbuild.locations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudbuild.operations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudbuild.operations.get</code></li>
<li><code translate="no" dir="ltr">cloudbuild.operations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">eventarc.channelConnections.get</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.list</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.listTagBindings</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.get</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.list</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.listTagBindings</code></p>
<p><code translate="no" dir="ltr">eventarc.enrollments.get</code></p>
<p><code translate="no" dir="ltr">eventarc.enrollments.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.enrollments.list</code></p>
<p><code translate="no" dir="ltr">eventarc.googleApiSources.get</code></p>
<p><code translate="no" dir="ltr">eventarc.googleApiSources.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.googleApiSources.list</code></p>
<p><code translate="no" dir="ltr">eventarc.googleChannelConfigs.get</code></p>
<p><code translate="no" dir="ltr">eventarc.kafkaSources.get</code></p>
<p><code translate="no" dir="ltr">eventarc.kafkaSources.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.kafkaSources.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">eventarc.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">eventarc.locations.get</code></li>
<li><code translate="no" dir="ltr">eventarc.locations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">eventarc.messageBuses.get</code></p>
<p><code translate="no" dir="ltr">eventarc.messageBuses.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.messageBuses.list</code></p>
<p><code translate="no" dir="ltr">eventarc.messageBuses.use</code></p>
<p><code translate="no" dir="ltr">eventarc.multiProjectSources.collectGoogleApiEvents</code></p>
<p><code translate="no" dir="ltr">eventarc.operations.get</code></p>
<p><code translate="no" dir="ltr">eventarc.operations.list</code></p>
<p><code translate="no" dir="ltr">eventarc.pipelines.get</code></p>
<p><code translate="no" dir="ltr">eventarc.pipelines.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.pipelines.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">eventarc.providers.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">eventarc.providers.get</code></li>
<li><code translate="no" dir="ltr">eventarc.providers.list</code></li>
</ul>
<p><code translate="no" dir="ltr">eventarc.triggers.get</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.list</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.listTagBindings</code></p>
<p><code translate="no" dir="ltr">pubsub.messageTransforms.validate</code></p>
<p><code translate="no" dir="ltr">pubsub.schemas.get</code></p>
<p><code translate="no" dir="ltr">pubsub.schemas.list</code></p>
<p><code translate="no" dir="ltr">pubsub.schemas.listRevisions</code></p>
<p><code translate="no" dir="ltr">pubsub.schemas.validate</code></p>
<p><code translate="no" dir="ltr">pubsub.snapshots.get</code></p>
<p><code translate="no" dir="ltr">pubsub.snapshots.list</code></p>
<p><code translate="no" dir="ltr">pubsub.snapshots.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">pubsub.snapshots.listTagBindings</code></p>
<p><code translate="no" dir="ltr">pubsub.subscriptions.get</code></p>
<p><code translate="no" dir="ltr">pubsub.subscriptions.list</code></p>
<p><code translate="no" dir="ltr">pubsub.subscriptions.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">pubsub.subscriptions.listTagBindings</code></p>
<p><code translate="no" dir="ltr">pubsub.topics.get</code></p>
<p><code translate="no" dir="ltr">pubsub.topics.list</code></p>
<p><code translate="no" dir="ltr">pubsub.topics.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">pubsub.topics.listTagBindings</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.locations.get</code></li>
<li><code translate="no" dir="ltr">recommender.locations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">recommender.runServiceCostInsights.get</code></p>
<p><code translate="no" dir="ltr">recommender.runServiceCostInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.runServiceCostRecommendations.get</code></p>
<p><code translate="no" dir="ltr">recommender.runServiceCostRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.runServiceIdentityInsights.get</code></p>
<p><code translate="no" dir="ltr">recommender.runServiceIdentityInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.runServiceIdentityRecommendations.get</code></p>
<p><code translate="no" dir="ltr">recommender.runServiceIdentityRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.runServicePerformanceInsights.get</code></p>
<p><code translate="no" dir="ltr">recommender.runServicePerformanceInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.runServicePerformanceRecommendations.get</code></p>
<p><code translate="no" dir="ltr">recommender.runServicePerformanceRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.runServiceSecurityInsights.get</code></p>
<p><code translate="no" dir="ltr">recommender.runServiceSecurityInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.runServiceSecurityRecommendations.get</code></p>
<p><code translate="no" dir="ltr">recommender.runServiceSecurityRecommendations.list</code></p>
<p><code translate="no" dir="ltr">remotebuildexecution.blobs.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">run.configurations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">run.configurations.get</code></li>
<li><code translate="no" dir="ltr">run.configurations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">run.executions.get</code></p>
<p><code translate="no" dir="ltr">run.executions.list</code></p>
<p><code translate="no" dir="ltr">run.instances.get</code></p>
<p><code translate="no" dir="ltr">run.instances.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">run.instances.list</code></p>
<p><code translate="no" dir="ltr">run.jobs.get</code></p>
<p><code translate="no" dir="ltr">run.jobs.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">run.jobs.list</code></p>
<p><code translate="no" dir="ltr">run.jobs.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">run.jobs.listTagBindings</code></p>
<p><code translate="no" dir="ltr">run.locations.list</code></p>
<p><code translate="no" dir="ltr">run.operations.get</code></p>
<p><code translate="no" dir="ltr">run.operations.list</code></p>
<p><code translate="no" dir="ltr">run.prompts.get</code></p>
<p><code translate="no" dir="ltr">run.revisions.get</code></p>
<p><code translate="no" dir="ltr">run.revisions.list</code></p>
<p><code translate="no" dir="ltr">run.routes.get</code></p>
<p><code translate="no" dir="ltr">run.routes.list</code></p>
<p><code translate="no" dir="ltr">run.services.get</code></p>
<p><code translate="no" dir="ltr">run.services.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">run.services.list</code></p>
<p><code translate="no" dir="ltr">run.services.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">run.services.listTagBindings</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">run.tasks.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">run.tasks.get</code></li>
<li><code translate="no" dir="ltr">run.tasks.list</code></li>
</ul>
<p><code translate="no" dir="ltr">run.workerpools.get</code></p>
<p><code translate="no" dir="ltr">run.workerpools.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">run.workerpools.list</code></p>
<p><code translate="no" dir="ltr">serviceusage.catalogs.listMembers</code></p>
<p><code translate="no" dir="ltr">serviceusage.consumerpolicy.analyze</code></p>
<p><code translate="no" dir="ltr">serviceusage.consumerpolicy.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.effectivepolicy.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">serviceusage.groups.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">serviceusage.groups.list</code></li>
<li><code translate="no" dir="ltr">serviceusage.groups.listExpandedMembers</code></li>
<li><code translate="no" dir="ltr">serviceusage.groups.listMembers</code></li>
</ul>
<p><code translate="no" dir="ltr">serviceusage.quotas.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.list</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.listApis</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.listDependentServices</code></p>
<p><code translate="no" dir="ltr">serviceusage.values.test</code></p>
<p><code translate="no" dir="ltr">storage.folders.get</code></p>
<p><code translate="no" dir="ltr">storage.folders.list</code></p>
<p><code translate="no" dir="ltr">storage.managedFolders.get</code></p>
<p><code translate="no" dir="ltr">storage.managedFolders.list</code></p>
<p><code translate="no" dir="ltr">storage.objects.get</code></p>
<p><code translate="no" dir="ltr">storage.objects.list</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="run.sshReader" class="role-title add-link" data-text="Cloud Run SSH Read Only Beta " tabindex="-1">Cloud Run SSH Read Only <sup>Beta</sup></h4>
<p>(<code translate="no" dir="ltr">roles/run.sshReader</code>)</p>
<span class="role-description"> </span>
<p>Can SSH into Cloud Run instances and read data.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">run.instances.sshRead</code></p>
<p><code translate="no" dir="ltr">run.jobs.sshRead</code></p>
<p><code translate="no" dir="ltr">run.services.sshRead</code></p>
<p><code translate="no" dir="ltr">run.workerpools.sshRead</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="run.sshRoot" class="role-title add-link" data-text="Cloud Run SSH Root Access Beta " tabindex="-1">Cloud Run SSH Root Access <sup>Beta</sup></h4>
<p>(<code translate="no" dir="ltr">roles/run.sshRoot</code>)</p>
<span class="role-description"> </span>
<p>Can SSH into Cloud Run instances and run commands as root.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">run.instances.sshRoot</code></p>
<p><code translate="no" dir="ltr">run.jobs.sshRoot</code></p>
<p><code translate="no" dir="ltr">run.services.sshRoot</code></p>
<p><code translate="no" dir="ltr">run.workerpools.sshRoot</code></p></td>
</tr>
</tbody>
</table>

### Service agent roles

Service agent roles should only be granted to [service agents](/iam/docs/service-agents).

<div results-count-container="">

</div>

<table class="fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="50%">Role</th>
<th>Permissions</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td class="role-description"><h4 id="run.serviceAgent" class="role-title add-link" data-text="Cloud Run Service Agent " tabindex="-1">Cloud Run Service Agent</h4>
<p>(<code translate="no" dir="ltr">roles/run.serviceAgent</code>)</p>
<span class="role-description"> </span>
<p>Gives Cloud Run service account access to managed resources.</p>
<strong>Warning:</strong> Do not grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.</td>
<td class="role-permissions"><p><code translate="no" dir="ltr">artifactregistry.attachments.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.attachments.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.dockerimages.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.dockerimages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.dockerimages.list</code></li>
</ul>
<p><code translate="no" dir="ltr">artifactregistry.files.download</code></p>
<p><code translate="no" dir="ltr">artifactregistry.files.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.files.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.locations.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.locations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.mavenartifacts.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.mavenartifacts.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.mavenartifacts.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.npmpackages.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.npmpackages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.npmpackages.list</code></li>
</ul>
<p><code translate="no" dir="ltr">artifactregistry.packages.delete</code></p>
<p><code translate="no" dir="ltr">artifactregistry.packages.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.packages.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.projectconfigs.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.projectsettings.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">artifactregistry.pythonpackages.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">artifactregistry.pythonpackages.get</code></li>
<li><code translate="no" dir="ltr">artifactregistry.pythonpackages.list</code></li>
</ul>
<p><code translate="no" dir="ltr">artifactregistry.repositories.create</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.downloadArtifacts</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.exportArtifacts</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.listTagBindings</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.readViaVirtualRepository</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.update</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.uploadArtifacts</code></p>
<p><code translate="no" dir="ltr">artifactregistry.rules.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.rules.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.tags.delete</code></p>
<p><code translate="no" dir="ltr">artifactregistry.tags.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.tags.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.versions.delete</code></p>
<p><code translate="no" dir="ltr">artifactregistry.versions.get</code></p>
<p><code translate="no" dir="ltr">artifactregistry.versions.list</code></p>
<p><code translate="no" dir="ltr">binaryauthorization.platformPolicies.evaluatePolicy</code></p>
<p><code translate="no" dir="ltr">binaryauthorization.policy.evaluatePolicy</code></p>
<p><code translate="no" dir="ltr">clientauthconfig.clients.list</code></p>
<p><code translate="no" dir="ltr">cloudbuild.builds.create</code></p>
<p><code translate="no" dir="ltr">cloudbuild.builds.get</code></p>
<p><code translate="no" dir="ltr">cloudbuild.workerpools.use</code></p>
<p><code translate="no" dir="ltr">compute.addresses.create</code></p>
<p><code translate="no" dir="ltr">compute.addresses.createInternal</code></p>
<p><code translate="no" dir="ltr">compute.addresses.delete</code></p>
<p><code translate="no" dir="ltr">compute.addresses.deleteInternal</code></p>
<p><code translate="no" dir="ltr">compute.addresses.get</code></p>
<p><code translate="no" dir="ltr">compute.addresses.list</code></p>
<p><code translate="no" dir="ltr">compute.globalOperations.get</code></p>
<p><code translate="no" dir="ltr">compute.networks.access</code></p>
<p><code translate="no" dir="ltr">compute.networks.get</code></p>
<p><code translate="no" dir="ltr">compute.regionOperations.get</code></p>
<p><code translate="no" dir="ltr">compute.subnetworks.get</code></p>
<p><code translate="no" dir="ltr">compute.subnetworks.use</code></p>
<p><code translate="no" dir="ltr">compute.zoneOperations.get</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.actAs</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.getAccessToken</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.getOpenIdToken</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.signBlob</code></p>
<p><code translate="no" dir="ltr">networkservices.meshes.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><code translate="no" dir="ltr">run.routes.invoke</code></p>
<p><code translate="no" dir="ltr">serviceusage.catalogs.listMembers</code></p>
<p><code translate="no" dir="ltr">serviceusage.consumerpolicy.analyze</code></p>
<p><code translate="no" dir="ltr">serviceusage.consumerpolicy.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.effectivepolicy.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">serviceusage.groups.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">serviceusage.groups.list</code></li>
<li><code translate="no" dir="ltr">serviceusage.groups.listExpandedMembers</code></li>
<li><code translate="no" dir="ltr">serviceusage.groups.listMembers</code></li>
</ul>
<p><code translate="no" dir="ltr">serviceusage.services.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.listApis</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.listDependentServices</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.use</code></p>
<p><code translate="no" dir="ltr">serviceusage.values.test</code></p>
<p><code translate="no" dir="ltr">storage.buckets.create</code></p>
<p><code translate="no" dir="ltr">storage.buckets.get</code></p>
<p><code translate="no" dir="ltr">storage.buckets.update</code></p>
<p><code translate="no" dir="ltr">storage.folders.get</code></p>
<p><code translate="no" dir="ltr">storage.folders.list</code></p>
<p><code translate="no" dir="ltr">storage.managedFolders.get</code></p>
<p><code translate="no" dir="ltr">storage.managedFolders.list</code></p>
<p><code translate="no" dir="ltr">storage.objects.create</code></p>
<p><code translate="no" dir="ltr">storage.objects.delete</code></p>
<p><code translate="no" dir="ltr">storage.objects.get</code></p>
<p><code translate="no" dir="ltr">storage.objects.list</code></p>
<p><code translate="no" dir="ltr">storage.objects.update</code></p>
<p><code translate="no" dir="ltr">vpcaccess.connectors.get</code></p></td>
</tr>
</tbody>
</table>

## Cloud Run permissions

<div results-count-container="">

</div>

<table class="permissions-table fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="45%">Permission</th>
<th>Included in roles</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td><h4 id="run.configurations.get" class="permission-name add-link" data-text="run.configurations.get" tabindex="-1"><code translate="no" dir="ltr">run.configurations.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.viewer">Cloud Run Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="run.configurations.list" class="permission-name add-link" data-text="run.configurations.list" tabindex="-1"><code translate="no" dir="ltr">run.configurations.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.viewer">Cloud Run Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="run.executions.cancel" class="permission-name add-link" data-text="run.executions.cancel" tabindex="-1"><code translate="no" dir="ltr">run.executions.cancel</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.jobsExecutor">Cloud Run Jobs Executor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.jobsExecutor</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.jobsExecutorWithOverrides">Cloud Run Jobs Executor With Overrides</a> (<code class="role-name" translate="no" dir="ltr">roles/run.jobsExecutorWithOverrides</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="run.executions.delete" class="permission-name add-link" data-text="run.executions.delete" tabindex="-1"><code translate="no" dir="ltr">run.executions.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="run.executions.get" class="permission-name add-link" data-text="run.executions.get" tabindex="-1"><code translate="no" dir="ltr">run.executions.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.viewer">Cloud Run Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="run.executions.list" class="permission-name add-link" data-text="run.executions.list" tabindex="-1"><code translate="no" dir="ltr">run.executions.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.viewer">Cloud Run Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="run.instances.create" class="permission-name add-link" data-text="run.instances.create" tabindex="-1"><code translate="no" dir="ltr">run.instances.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="run.instances.delete" class="permission-name add-link" data-text="run.instances.delete" tabindex="-1"><code translate="no" dir="ltr">run.instances.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="run.instances.get" class="permission-name add-link" data-text="run.instances.get" tabindex="-1"><code translate="no" dir="ltr">run.instances.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.viewer">Cloud Run Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="run.instances.getIamPolicy" class="permission-name add-link" data-text="run.instances.getIamPolicy" tabindex="-1"><code translate="no" dir="ltr">run.instances.getIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.viewer">Cloud Run Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="run.instances.invoke" class="permission-name add-link" data-text="run.instances.invoke" tabindex="-1"><code translate="no" dir="ltr">run.instances.invoke</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.invoker">Cloud Run Invoker</a> (<code class="role-name" translate="no" dir="ltr">roles/run.invoker</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="run.instances.list" class="permission-name add-link" data-text="run.instances.list" tabindex="-1"><code translate="no" dir="ltr">run.instances.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.viewer">Cloud Run Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="run.instances.setIamPolicy" class="permission-name add-link" data-text="run.instances.setIamPolicy" tabindex="-1"><code translate="no" dir="ltr">run.instances.setIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="run.instances.sshRead" class="permission-name add-link" data-text="run.instances.sshRead" tabindex="-1"><code translate="no" dir="ltr">run.instances.sshRead</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sshReader">Cloud Run SSH Read Only</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sshReader</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="run.instances.sshRoot" class="permission-name add-link" data-text="run.instances.sshRoot" tabindex="-1"><code translate="no" dir="ltr">run.instances.sshRoot</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sshRoot">Cloud Run SSH Root Access</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sshRoot</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="run.instances.start" class="permission-name add-link" data-text="run.instances.start" tabindex="-1"><code translate="no" dir="ltr">run.instances.start</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="run.instances.stop" class="permission-name add-link" data-text="run.instances.stop" tabindex="-1"><code translate="no" dir="ltr">run.instances.stop</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="run.instances.update" class="permission-name add-link" data-text="run.instances.update" tabindex="-1"><code translate="no" dir="ltr">run.instances.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="run.jobs.create" class="permission-name add-link" data-text="run.jobs.create" tabindex="-1"><code translate="no" dir="ltr">run.jobs.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="run.jobs.createTagBinding" class="permission-name add-link" data-text="run.jobs.createTagBinding" tabindex="-1"><code translate="no" dir="ltr">run.jobs.createTagBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="run.jobs.delete" class="permission-name add-link" data-text="run.jobs.delete" tabindex="-1"><code translate="no" dir="ltr">run.jobs.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="run.jobs.deleteTagBinding" class="permission-name add-link" data-text="run.jobs.deleteTagBinding" tabindex="-1"><code translate="no" dir="ltr">run.jobs.deleteTagBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="run.jobs.get" class="permission-name add-link" data-text="run.jobs.get" tabindex="-1"><code translate="no" dir="ltr">run.jobs.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.viewer">Cloud Run Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/eventarc#eventarc.serviceAgent">Eventarc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/eventarc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/runapps#runapps.serviceAgent">Serverless Integrations Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/runapps.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="run.jobs.getIamPolicy" class="permission-name add-link" data-text="run.jobs.getIamPolicy" tabindex="-1"><code translate="no" dir="ltr">run.jobs.getIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.viewer">Cloud Run Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="run.jobs.list" class="permission-name add-link" data-text="run.jobs.list" tabindex="-1"><code translate="no" dir="ltr">run.jobs.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.viewer">Cloud Run Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/runapps#runapps.serviceAgent">Serverless Integrations Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/runapps.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="run.jobs.listEffectiveTags" class="permission-name add-link" data-text="run.jobs.listEffectiveTags" tabindex="-1"><code translate="no" dir="ltr">run.jobs.listEffectiveTags</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagViewer">Tag Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.viewer">Cloud Run Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="run.jobs.listTagBindings" class="permission-name add-link" data-text="run.jobs.listTagBindings" tabindex="-1"><code translate="no" dir="ltr">run.jobs.listTagBindings</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagViewer">Tag Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.viewer">Cloud Run Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="run.jobs.run" class="permission-name add-link" data-text="run.jobs.run" tabindex="-1"><code translate="no" dir="ltr">run.jobs.run</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.invoker">Cloud Run Invoker</a> (<code class="role-name" translate="no" dir="ltr">roles/run.invoker</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.jobsExecutor">Cloud Run Jobs Executor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.jobsExecutor</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.jobsExecutorWithOverrides">Cloud Run Jobs Executor With Overrides</a> (<code class="role-name" translate="no" dir="ltr">roles/run.jobsExecutorWithOverrides</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ces#ces.serviceAgent">Customer Engagement Suite Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ces.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dialogflow#dialogflow.serviceAgent">Dialogflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dialogflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/integrations#integrations.serviceAgent">Application Integration Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/spanner#spanner.serviceAgent">Cloud Spanner API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/spanner.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visionai#visionai.serviceAgent">Cloud Vision AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visionai.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="run.jobs.runWithOverrides" class="permission-name add-link" data-text="run.jobs.runWithOverrides" tabindex="-1"><code translate="no" dir="ltr">run.jobs.runWithOverrides</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.jobsExecutorWithOverrides">Cloud Run Jobs Executor With Overrides</a> (<code class="role-name" translate="no" dir="ltr">roles/run.jobsExecutorWithOverrides</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="run.jobs.setIamPolicy" class="permission-name add-link" data-text="run.jobs.setIamPolicy" tabindex="-1"><code translate="no" dir="ltr">run.jobs.setIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="run.jobs.sshRead" class="permission-name add-link" data-text="run.jobs.sshRead" tabindex="-1"><code translate="no" dir="ltr">run.jobs.sshRead</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sshReader">Cloud Run SSH Read Only</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sshReader</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="run.jobs.sshRoot" class="permission-name add-link" data-text="run.jobs.sshRoot" tabindex="-1"><code translate="no" dir="ltr">run.jobs.sshRoot</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sshRoot">Cloud Run SSH Root Access</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sshRoot</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="run.jobs.update" class="permission-name add-link" data-text="run.jobs.update" tabindex="-1"><code translate="no" dir="ltr">run.jobs.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="run.locations.list" class="permission-name add-link" data-text="run.locations.list" tabindex="-1"><code translate="no" dir="ltr">run.locations.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.viewer">Cloud Run Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="run.locations.uploadSource" class="permission-name add-link" data-text="run.locations.uploadSource" tabindex="-1"><code translate="no" dir="ltr">run.locations.uploadSource</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="run.operations.delete" class="permission-name add-link" data-text="run.operations.delete" tabindex="-1"><code translate="no" dir="ltr">run.operations.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.serviceAgent">Firebase App Hosting Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="run.operations.get" class="permission-name add-link" data-text="run.operations.get" tabindex="-1"><code translate="no" dir="ltr">run.operations.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.viewer">Cloud Run Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.serviceAgent">Firebase App Hosting Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="run.operations.list" class="permission-name add-link" data-text="run.operations.list" tabindex="-1"><code translate="no" dir="ltr">run.operations.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.viewer">Cloud Run Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="run.prompts.get" class="permission-name add-link" data-text="run.prompts.get" tabindex="-1"><code translate="no" dir="ltr">run.prompts.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.viewer">Cloud Run Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="run.revisions.delete" class="permission-name add-link" data-text="run.revisions.delete" tabindex="-1"><code translate="no" dir="ltr">run.revisions.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.serviceAgent">Firebase App Hosting Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="run.revisions.get" class="permission-name add-link" data-text="run.revisions.get" tabindex="-1"><code translate="no" dir="ltr">run.revisions.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.viewer">Cloud Run Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.serverlessImageRegistryScanner">Wiz Serverless &amp; Container Image Registry Scanner</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.serverlessImageRegistryScanner</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.serviceAgent">Firebase App Hosting Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="run.revisions.list" class="permission-name add-link" data-text="run.revisions.list" tabindex="-1"><code translate="no" dir="ltr">run.revisions.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.viewer">Cloud Run Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="run.routes.get" class="permission-name add-link" data-text="run.routes.get" tabindex="-1"><code translate="no" dir="ltr">run.routes.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.viewer">Cloud Run Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.serviceAgent">Firebase App Hosting Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="run.routes.invoke" class="permission-name add-link" data-text="run.routes.invoke" tabindex="-1"><code translate="no" dir="ltr">run.routes.invoke</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.invoker">Cloud Run Invoker</a> (<code class="role-name" translate="no" dir="ltr">roles/run.invoker</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.servicesInvoker">Cloud Run Service Invoker</a> (<code class="role-name" translate="no" dir="ltr">roles/run.servicesInvoker</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ces#ces.serviceAgent">Customer Engagement Suite Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ces.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dialogflow#dialogflow.serviceAgent">Dialogflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dialogflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.serviceAgent">Firebase App Hosting Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasedataconnect#firebasedataconnect.serviceAgent">Firebase Data Connect Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasedataconnect.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/integrations#integrations.serviceAgent">Application Integration Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/monitoring#monitoring.notificationServiceAgent">Monitoring Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/monitoring.notificationServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/spanner#spanner.serviceAgent">Cloud Spanner API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/spanner.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visionai#visionai.serviceAgent">Cloud Vision AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visionai.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="run.routes.list" class="permission-name add-link" data-text="run.routes.list" tabindex="-1"><code translate="no" dir="ltr">run.routes.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.viewer">Cloud Run Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="run.services.create" class="permission-name add-link" data-text="run.services.create" tabindex="-1"><code translate="no" dir="ltr">run.services.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.serviceAgent">Firebase App Hosting Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="run.services.createTagBinding" class="permission-name add-link" data-text="run.services.createTagBinding" tabindex="-1"><code translate="no" dir="ltr">run.services.createTagBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="run.services.delete" class="permission-name add-link" data-text="run.services.delete" tabindex="-1"><code translate="no" dir="ltr">run.services.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.serviceAgent">Firebase App Hosting Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="run.services.deleteTagBinding" class="permission-name add-link" data-text="run.services.deleteTagBinding" tabindex="-1"><code translate="no" dir="ltr">run.services.deleteTagBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="run.services.get" class="permission-name add-link" data-text="run.services.get" tabindex="-1"><code translate="no" dir="ltr">run.services.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.viewer">Cloud Run Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/eventarc#eventarc.serviceAgent">Eventarc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/eventarc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.serviceAgent">Firebase App Hosting Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/runapps#runapps.serviceAgent">Serverless Integrations Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/runapps.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="run.services.getIamPolicy" class="permission-name add-link" data-text="run.services.getIamPolicy" tabindex="-1"><code translate="no" dir="ltr">run.services.getIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.viewer">Cloud Run Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasemods#firebasemods.serviceAgent">Firebase Extensions API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasemods.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="run.services.list" class="permission-name add-link" data-text="run.services.list" tabindex="-1"><code translate="no" dir="ltr">run.services.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.viewer">Cloud Run Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/runapps#runapps.serviceAgent">Serverless Integrations Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/runapps.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="run.services.listEffectiveTags" class="permission-name add-link" data-text="run.services.listEffectiveTags" tabindex="-1"><code translate="no" dir="ltr">run.services.listEffectiveTags</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagViewer">Tag Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.viewer">Cloud Run Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="run.services.listTagBindings" class="permission-name add-link" data-text="run.services.listTagBindings" tabindex="-1"><code translate="no" dir="ltr">run.services.listTagBindings</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagViewer">Tag Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.viewer">Cloud Run Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="run.services.setIamPolicy" class="permission-name add-link" data-text="run.services.setIamPolicy" tabindex="-1"><code translate="no" dir="ltr">run.services.setIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/firebasemods#firebasemods.serviceAgent">Firebase Extensions API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasemods.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="run.services.sshRead" class="permission-name add-link" data-text="run.services.sshRead" tabindex="-1"><code translate="no" dir="ltr">run.services.sshRead</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sshReader">Cloud Run SSH Read Only</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sshReader</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="run.services.sshRoot" class="permission-name add-link" data-text="run.services.sshRoot" tabindex="-1"><code translate="no" dir="ltr">run.services.sshRoot</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sshRoot">Cloud Run SSH Root Access</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sshRoot</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="run.services.update" class="permission-name add-link" data-text="run.services.update" tabindex="-1"><code translate="no" dir="ltr">run.services.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.serviceAgent">Firebase App Hosting Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="run.tasks.get" class="permission-name add-link" data-text="run.tasks.get" tabindex="-1"><code translate="no" dir="ltr">run.tasks.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.viewer">Cloud Run Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="run.tasks.list" class="permission-name add-link" data-text="run.tasks.list" tabindex="-1"><code translate="no" dir="ltr">run.tasks.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.viewer">Cloud Run Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="run.workerpools.create" class="permission-name add-link" data-text="run.workerpools.create" tabindex="-1"><code translate="no" dir="ltr">run.workerpools.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="run.workerpools.delete" class="permission-name add-link" data-text="run.workerpools.delete" tabindex="-1"><code translate="no" dir="ltr">run.workerpools.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="run.workerpools.get" class="permission-name add-link" data-text="run.workerpools.get" tabindex="-1"><code translate="no" dir="ltr">run.workerpools.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.viewer">Cloud Run Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="run.workerpools.getIamPolicy" class="permission-name add-link" data-text="run.workerpools.getIamPolicy" tabindex="-1"><code translate="no" dir="ltr">run.workerpools.getIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.viewer">Cloud Run Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="run.workerpools.list" class="permission-name add-link" data-text="run.workerpools.list" tabindex="-1"><code translate="no" dir="ltr">run.workerpools.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.viewer">Cloud Functions Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.viewer">Cloud Run Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceViewer">Cloud Run Source Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="run.workerpools.setIamPolicy" class="permission-name add-link" data-text="run.workerpools.setIamPolicy" tabindex="-1"><code translate="no" dir="ltr">run.workerpools.setIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="run.workerpools.sshRead" class="permission-name add-link" data-text="run.workerpools.sshRead" tabindex="-1"><code translate="no" dir="ltr">run.workerpools.sshRead</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sshReader">Cloud Run SSH Read Only</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sshReader</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="run.workerpools.sshRoot" class="permission-name add-link" data-text="run.workerpools.sshRoot" tabindex="-1"><code translate="no" dir="ltr">run.workerpools.sshRoot</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sshRoot">Cloud Run SSH Root Access</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sshRoot</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="run.workerpools.update" class="permission-name add-link" data-text="run.workerpools.update" tabindex="-1"><code translate="no" dir="ltr">run.workerpools.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.admin">Cloud Functions Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.editor">Cloud Functions Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.admin">Cloud Run Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/run.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.developer">Cloud Run Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.editor">Cloud Run Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/run.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.developer">Cloud Functions Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.sourceDeveloper">Cloud Run Source Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/run.sourceDeveloper</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
</ul></td>
</tr>
</tbody>
</table>

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
