# Resource attributes for IAM Conditions

<div class="devsite-article-body clearfix">

This topic contains a list of values that can be used for [resource attributes](/iam/docs/conditions-attribute-reference#resource) in a condition, including string values for resource service, resource type, and the format for resource name strings.

You can use resource attributes to change the scope of the grant provided by a role binding. When a role contains permissions that apply to different kinds of resources, a condition can grant a subset of the role's permissions based on the resource service, resource type, and resource name.

Resource attributes are available for the Google Cloud services and resource types that are listed on this page. Other services and resource types do not recognize resource attributes.

For more information about Identity and Access Management (IAM) Conditions, see the following:

- [Conditions overview](/iam/docs/conditions-overview)
- [Managing conditional role bindings](/iam/docs/managing-conditional-policies)

<span id="resource_service_values"></span>

## Resource service values

The following table lists the values that the resource service attribute can contain.

Resource service value

</div>

REST reference

`agentregistry.googleapis.com`

<a href="/agent-registry/reference/rest" aria-label="Agent Registry API reference">API reference</a>

`apigee.googleapis.com`

<a href="/apigee/docs/reference/apis/apigee/rest" aria-label="Apigee API reference">API reference</a>

`apihub.googleapis.com`

<a href="/apigee/docs/reference/apis/apihub/rest" aria-label="Apigee API Hub API reference">API reference</a>

`backupdr.googleapis.com`

<a href="/backup-disaster-recovery/docs/reference/rest" aria-label="Backup and DR Service API reference">API reference</a>

`bigquery.googleapis.com`

<a href="/bigquery/docs/reference/rest" aria-label="BigQuery API reference">API reference</a>

`bigqueryreservation.googleapis.com`

<a href="/bigquery/docs/reference/reservations/rest" aria-label="BigQuery Reservation API API reference">API reference</a>

`bigtableadmin.googleapis.com`

<a href="/bigtable/docs/reference/admin/rest" aria-label="Bigtable API reference">API reference</a>

`binaryauthorization.googleapis.com`

<a href="/binary-authorization/docs/reference/rest" aria-label="Binary Authorization API reference">API reference</a>

`ces.googleapis.com`

<a href="/customer-engagement-ai/conversational-agents/ps/reference/rest" aria-label="Customer Experience Agent Studio API reference">API reference</a>

`clouddeploy.googleapis.com`

<a href="/deploy/docs/api/reference/rest" aria-label="Cloud Deploy API reference">API reference</a>

`cloudkms.googleapis.com`

<a href="/kms/docs/reference/rest" aria-label="Cloud Key Management Service API reference">API reference</a>

`cloudresourcemanager.googleapis.com`

<a href="/resource-manager/reference/rest" aria-label="Resource Manager API reference">API reference</a>

`compute.googleapis.com`

<a href="/compute/docs/reference/rest/v1" aria-label="Compute Engine API reference">API reference</a>

`container.googleapis.com`

<a href="/kubernetes-engine/docs/reference/rest" aria-label="Google Kubernetes Engine API reference">API reference</a>

`connectors.googleapis.com`

<a href="/integration-connectors/docs/reference/rest" aria-label="Integration Connectors API reference">API reference</a>

`dataform.googleapis.com`

<a href="/dataform/reference/rest" aria-label="Dataform API reference">API reference</a>

`dns.googleapis.com`

<a href="/dns/docs/reference/rest/v1" aria-label="Cloud DNS API reference">API reference</a>

`firestore.googleapis.com`

<a href="/firestore/docs/reference/rest" aria-label="Firestore API reference">API reference</a>

`iap.googleapis.com`

<a href="/iap/docs/reference/rest" aria-label="Identity-Aware Proxy API reference">API reference</a>

`integrations.googleapis.com`

[API reference](/application-integration/docs/reference/rest)

`logging.googleapis.com`

<a href="/logging/docs/reference/rest" aria-label="Cloud Logging API reference">API reference</a>

`managedkafka.googleapis.com`

<a href="/managed-service-for-apache-kafka/docs/reference/rest" aria-label="Google Cloud Managed Service for Apache Kafka API reference">API reference</a>

`networksecurity.googleapis.com`

<a href="/firewall/docs/reference/network-security/rest" aria-label="Cloud NGFW API reference">API reference</a>

`parametermanager.googleapis.com`

<a href="/secret-manager/parameter-manager/docs/reference/rest" aria-label="Parameter Manager API reference">API reference</a>

`pubsublite.googleapis.com`

<a href="/pubsub/lite/docs/reference/rest" aria-label="Pub/Sub Lite API reference">API reference</a>

`secretmanager.googleapis.com`

<a href="/secret-manager/docs/reference/rest" aria-label="Secret Manager API reference">API reference</a>

`spanner.googleapis.com`

<a href="/spanner/docs/reference/rest" aria-label="Spanner API reference">API reference</a>

`sqladmin.googleapis.com`

<a href="/sql/docs/mysql/admin-api" aria-label="Cloud SQL API reference">API reference</a>

`storage.googleapis.com`

<a href="/storage/docs/json_api" aria-label="Cloud Storage API reference">API reference</a>

<span id="resource_type_values"></span>

## Resource type values

The following table lists the values that the resource type attribute can contain.

Resource type value

Reference

`agentregistry.googleapis.com/Skill`

<a href="/agent-registry/reference/rest/v1alpha/projects.locations.skills" aria-label="agentregistry.googleapis.com/Skill reference">Read more</a>

`agentregistry.googleapis.com/SkillRevision`

<a href="/agent-registry/reference/rest/v1alpha/projects.locations.skills.revisions" aria-label="agentregistry.googleapis.com/SkillRevision reference">Read more</a>

`apigee.googleapis.com/ApiProduct`

<a href="/apigee/docs/reference/apis/apigee/rest/v1/organizations.apiproducts" aria-label="apigee.googleapis.com/ApiProduct reference">Read more</a>

`apigee.googleapis.com/ApiProductAttribute`

<a href="/apigee/docs/reference/apis/apigee/rest/v1/organizations.apiproducts.attributes" aria-label="apigee.googleapis.com/ApiProductAttribute reference">Read more</a>

`apigee.googleapis.com/Cache`

<a href="/apigee/docs/reference/apis/apigee/rest/v1/organizations.environments.caches" aria-label="apigee.googleapis.com/Cache reference">Read more</a>

`apigee.googleapis.com/Developer`

<a href="/apigee/docs/reference/apis/apigee/rest/v1/organizations.developers" aria-label="apigee.googleapis.com/Developer reference">Read more</a>

`apigee.googleapis.com/DeveloperApp`

<a href="/apigee/docs/reference/apis/apigee/rest/v1/organizations.developers.apps" aria-label="apigee.googleapis.com/DeveloperApp reference">Read more</a>

`apigee.googleapis.com/DeveloperAppAttribute`

<a href="/apigee/docs/reference/apis/apigee/rest/v1/organizations.developers.apps.attributes" aria-label="apigee.googleapis.com/DeveloperAppAttribute reference">Read more</a>

`apigee.googleapis.com/DeveloperAttribute`

<a href="/apigee/docs/reference/apis/apigee/rest/v1/organizations.developers/attributes" aria-label="apigee.googleapis.com/DeveloperAttribute reference">Read more</a>

`apigee.googleapis.com/Export`

<a href="/apigee/docs/reference/apis/apigee/rest/v1/organizations.environments.analytics.exports" aria-label="apigee.googleapis.com/Export reference">Read more</a>

`apigee.googleapis.com/FlowHook`

<a href="/apigee/docs/reference/apis/apigee/rest/v1/organizations.environments.flowhooks" aria-label="apigee.googleapis.com/FlowHook reference">Read more</a>

`apigee.googleapis.com/KeyStore`

<a href="/apigee/docs/reference/apis/apigee/rest/v1/organizations.environments.keystores" aria-label="apigee.googleapis.com/KeyStore reference">Read more</a>

`apigee.googleapis.com/KeyStoreAlias`

<a href="/apigee/docs/reference/apis/apigee/rest/v1/organizations.environments.keystores.aliases" aria-label="apigee.googleapis.com/KeyStoreAlias reference">Read more</a>

`apigee.googleapis.com/KeyValueEntry`

<a href="/apigee/docs/reference/apis/apigee/rest/v1/organizations.keyvaluemaps.entries" aria-label="apigee.googleapis.com/KeyValueEntry reference">Read more</a>

`apigee.googleapis.com/KeyValueMap`

<a href="/apigee/docs/reference/apis/apigee/rest/v1/organizations.keyvaluemaps" aria-label="apigee.googleapis.com/KeyValueMap reference">Read more</a>

`apigee.googleapis.com/Proxy`

<a href="/apigee/docs/reference/apis/apigee/rest/v1/ApiProxy" aria-label="apigee.googleapis.com/Proxy reference">Read more</a>

`apigee.googleapis.com/ProxyRevision`

<a href="/apigee/docs/reference/apis/apigee/rest/v1/ApiProxyRevision" aria-label="apigee.googleapis.com/ProxyRevision reference">Read more</a>

`apigee.googleapis.com/Query`

<a href="/apigee/docs/reference/apis/apigee/rest/v1/organizations.environments.queries" aria-label="apigee.googleapis.com/Query reference">Read more</a>

`apigee.googleapis.com/RatePlan`

<a href="/apigee/docs/reference/apis/apigee/rest/v1/organizations.apiproducts.rateplans" aria-label="apigee.googleapis.com/RatePlan reference">Read more</a>

`apigee.googleapis.com/Reference`

<a href="/apigee/docs/reference/apis/apigee/rest/v1/organizations.environments.references" aria-label="apigee.googleapis.com/Reference reference">Read more</a>

`apigee.googleapis.com/SharedFlow`

<a href="/apigee/docs/reference/apis/apigee/rest/v1/SharedFlow" aria-label="apigee.googleapis.com/SharedFlow reference">Read more</a>

`apigee.googleapis.com/SharedFlowRevision`

<a href="/apigee/docs/reference/apis/apigee/rest/v1/SharedFlowRevision" aria-label="apigee.googleapis.com/SharedFlowRevision reference">Read more</a>

`apigee.googleapis.com/TargetServer`

<a href="/apigee/docs/reference/apis/apigee/rest/v1/organizations.environments.targetservers" aria-label="apigee.googleapis.com/TargetServer reference">Read more</a>

`apigee.googleapis.com/TraceSession`

<a href="/apigee/docs/reference/apis/apigee/rest/v1/organizations.environments.apis.revisions.debugsessions" aria-label="apigee.googleapis.com/TraceSession reference">Read more</a>

`apihub.googleapis.com/Api`

<a href="/apigee/docs/reference/apis/apihub/rest/v1/projects.locations.apis" aria-label="apihub.googleapis.com/Api reference">Read more</a>

`apihub.googleapis.com/Deployment`

<a href="/apigee/docs/reference/apis/apihub/rest/v1/projects.locations.deployments" aria-label="apihub.googleapis.com/Deployment reference">Read more</a>

`apihub.googleapis.com/Version`

<a href="/apigee/docs/reference/apis/apihub/rest/v1/projects.locations.apis.versions" aria-label="apihub.googleapis.com/Version reference">Read more</a>

`apihub.googleapis.com/Spec`

<a href="/apigee/docs/reference/apis/apihub/rest/v1/projects.locations.apis.versions.specs" aria-label="apihub.googleapis.com/Specs reference">Read more</a>

`apihub.googleapis.com/ApiOperation`

<a href="/apigee/docs/reference/apis/apihub/rest/v1/projects.locations.apis.versions.operations" aria-label="apihub.googleapis.com/Operations reference">Read more</a>

`apihub.googleapis.com/Definition`

<a href="/apigee/docs/reference/apis/apihub/rest/v1/projects.locations.apis.versions.definitions" aria-label="apihub.googleapis.com/Definitions reference">Read more</a>

`backupdr.googleapis.com/BackupVaults`

<a href="/backup-disaster-recovery/docs/concepts/backup-vault" aria-label="Conceptual information about backup vaults">Read more</a>

`bigquery.googleapis.com/Dataset`

<a href="/bigquery/docs/reference/rest/v2/datasets" aria-label="bigquery.googleapis.com/Dataset reference">Read more</a>

`bigquery.googleapis.com/Model`

<a href="/bigquery/docs/reference/rest/v2/models" aria-label="bigquery.googleapis.com/Model reference">Read more</a>

`bigquery.googleapis.com/Routine`

<a href="/bigquery/docs/reference/rest/v2/routines" aria-label="bigquery.googleapis.com/Routine reference">Read more</a>

`bigquery.googleapis.com/Table`

<a href="/bigquery/docs/reference/rest/v2/tables" aria-label="bigquery.googleapis.com/Table reference">Read more</a>

`bigqueryreservation.googleapis.com/Assignment`

<a href="/bigquery/docs/reference/reservations/rest/v1/projects.locations.reservations.assignments" aria-label="bigqueryreservation.googleapis.com/Assignment reference">Read more</a>

`bigqueryreservation.googleapis.com/BiReservation`

<a href="/bigquery/docs/reference/reservations/rest/v1/BiReservation" aria-label="bigqueryreservation.googleapis.com/BiReservation reference">Read more</a>

`bigqueryreservation.googleapis.com/CapacityCommitment`

<a href="/bigquery/docs/reference/reservations/rest/v1/projects.locations.capacityCommitments" aria-label="bigqueryreservation.googleapis.com/CapacityCommitment reference">Read more</a>

`bigqueryreservation.googleapis.com/Location`

<a href="/bigquery/docs/reference/reservations/rest/v1/projects.locations" aria-label="bigqueryreservation.googleapis.com/Location reference">Read more</a>

`bigqueryreservation.googleapis.com/Reservation`

<a href="/bigquery/docs/reference/reservations/rest/v1/projects.locations.reservations" aria-label="bigqueryreservation.googleapis.com/Reservation reference">Read more</a>

`bigtableadmin.googleapis.com/AppProfile`

<a href="/bigtable/docs/reference/admin/rest/v2/projects.instances.appProfiles" aria-label="bigtableadmin.googleapis.com/AppProfile reference">Read more</a>

`bigtableadmin.googleapis.com/Backup`

<a href="/bigtable/docs/reference/admin/rest/v2/projects.instances.clusters.backups" aria-label="bigtableadmin.googleapis.com/Backup reference">Read more</a>

`bigtableadmin.googleapis.com/Cluster`

<a href="/bigtable/docs/reference/admin/rest/v2/projects.instances.clusters" aria-label="bigtableadmin.googleapis.com/Cluster reference">Read more</a>

`bigtableadmin.googleapis.com/Instance`

<a href="/bigtable/docs/reference/admin/rest/v2/projects.instances" aria-label="bigtableadmin.googleapis.com/Instance reference">Read more</a>

`bigtableadmin.googleapis.com/Table`

<a href="/bigtable/docs/reference/admin/rest/v2/projects.instances.tables" aria-label="bigtableadmin.googleapis.com/Table reference">Read more</a>

`binaryauthorization.googleapis.com/Attestor`

<a href="/binary-authorization/docs/reference/rest/v1/projects.attestors" aria-label="binaryauthorization.googleapis.com/Attestor reference">Read more</a>

`binaryauthorization.googleapis.com/ContinuousValidationConfig`

<a href="/binary-authorization/docs/reference/rest/v1alpha2/projects.continuousValidationConfig" aria-label="binaryauthorization.googleapis.com/ContinuousValidationConfig reference">Read more</a>

`binaryauthorization.googleapis.com/Policy`

<a href="/binary-authorization/docs/reference/rest/v1/projects.policy" aria-label="binaryauthorization.googleapis.com/Policy reference">Read more</a>

`ces.googleapis.com/App`

<a href="/customer-engagement-ai/conversational-agents/ps/reference/rest/v1/projects.locations.apps" aria-label="ces.googleapis.com/App reference">Read more</a>

`ces.googleapis.com/Operation`

<a href="/customer-engagement-ai/conversational-agents/ps/reference/rest/v1/projects.locations.operations" aria-label="ces.googleapis.com/Operation reference">Read more</a>

`cloud.googleapis.com/Location`<sup>1</sup>

<a href="/kms/docs/reference/rest/v1/projects.locations" aria-label="cloud.googleapis.com/Location reference">Read more</a>

`cloudkms.googleapis.com/CryptoKey`

<a href="/kms/docs/object-hierarchy#key" aria-label="cloudkms.googleapis.com/CryptoKey reference">Read more</a>

`cloudkms.googleapis.com/CryptoKeyVersion`

<a href="/kms/docs/object-hierarchy#key_version" aria-label="cloudkms.googleapis.com/CryptoKeyVersion reference">Read more</a>

`cloudkms.googleapis.com/KeyRing`

<a href="/kms/docs/object-hierarchy#key_ring" aria-label="cloudkms.googleapis.com/KeyRing reference">Read more</a>

`cloudresourcemanager.googleapis.com/Project`<sup>2</sup>

<a href="/resource-manager/docs/cloud-platform-resource-hierarchy#projects" aria-label="cloudresourcemanager.googleapis.com/Project reference">Read more</a>

`compute.googleapis.com/BackendService`

<a href="/load-balancing/docs/backend-service" aria-label="compute.googleapis.com/BackendService reference">Read more</a>

`compute.googleapis.com/Disk`

<a href="/compute/docs/disks#pdspecs" aria-label="compute.googleapis.com/Disk reference">Read more</a>

`compute.googleapis.com/Firewall`

<a href="/vpc/docs/firewalls" aria-label="compute.googleapis.com/Firewall reference">Read more</a>

`compute.googleapis.com/ForwardingRule`

<a href="/load-balancing/docs/forwarding-rule-concepts" aria-label="compute.googleapis.com/ForwardingRule reference">Read more</a>

`compute.googleapis.com/GlobalForwardingRule`

<a href="/load-balancing/docs/forwarding-rule-concepts" aria-label="compute.googleapis.com/GlobalForwardingRule reference">Read more</a>

`compute.googleapis.com/Image`

<a href="/compute/docs/images" aria-label="compute.googleapis.com/Image reference">Read more</a>

`compute.googleapis.com/Instance`

<a href="/compute/docs/instances" aria-label="compute.googleapis.com/Instance reference">Read more</a>

`compute.googleapis.com/InstanceTemplate`

<a href="/compute/docs/instance-templates" aria-label="compute.googleapis.com/InstanceTemplate reference">Read more</a>

`compute.googleapis.com/Snapshot`

<a href="/compute/docs/disks/create-snapshots" aria-label="compute.googleapis.com/Snapshot reference">Read more</a>

`compute.googleapis.com/TargetHttpProxy`

<a href="/load-balancing/docs/target-proxies" aria-label="compute.googleapis.com/TargetHttpProxy reference">Read more</a>

`compute.googleapis.com/TargetHttpsProxy`

<a href="/load-balancing/docs/target-proxies" aria-label="compute.googleapis.com/TargetHttpsProxy reference">Read more</a>

`compute.googleapis.com/TargetSslProxy`

<a href="/load-balancing/docs/target-proxies" aria-label="compute.googleapis.com/TargetSslProxy reference">Read more</a>

`compute.googleapis.com/TargetTcpProxy`

<a href="/load-balancing/docs/target-proxies" aria-label="compute.googleapis.com/TargetTcpProxy reference">Read more</a>

`connectors.googleapis.com/Connection`

<a href="/integration-connectors/docs/reference/rest/v1/projects.locations.connections" aria-label="connectors.googleapis.com/Connection reference">Read more</a>

`connectors.googleapis.com/ConnectionSchemaMetadata`

<a href="/integration-connectors/docs/reference/rest/v1/projects.locations.connections.connectionSchemaMetadata" aria-label="connectors.googleapis.com/ConnectionSchemaMetadata reference">Read more</a>

`connectors.googleapis.com/EndpointAttachment`

<a href="/integration-connectors/docs/reference/rest/v1/projects.locations.endpointAttachments" aria-label="connectors.googleapis.com/EndpointAttachment reference">Read more</a>

`connectors.googleapis.com/EventSubscription`

<a href="/integration-connectors/docs/reference/rest/v1/projects.locations.connections.eventSubscriptions" aria-label="connectors.googleapis.com/EventSubscription reference">Read more</a>

`connectors.googleapis.com/ManagedZone`

<a href="/integration-connectors/docs/reference/rest/v1/projects.locations.global.managedZones" aria-label="connectors.googleapis.com/ManagedZone reference">Read more</a>

`container.googleapis.com/Cluster`

<a href="/kubernetes-engine/docs/reference/rest/v1/projects.zones.clusters" aria-label="container.googleapis.com/Cluster reference">Read more</a>

`dataform.googleapis.com/CompilationResult`

<a href="/dataform/reference/rest/v1beta1/projects.locations.repositories.compilationResults" aria-label="dataform.googleapis.com/CompilationResult reference">Read more</a>

`dataform.googleapis.com/Location`

<a href="/dataform/reference/rest/v1beta1/projects.locations" aria-label="dataform.googleapis.com/Location reference">Read more</a>

`dataform.googleapis.com/ReleaseConfig`

<a href="/dataform/reference/rest/v1beta1/projects.locations.repositories.releaseConfigs" aria-label="dataform.googleapis.com/ReleaseConfig reference">Read more</a>

`dataform.googleapis.com/Repository`

<a href="/dataform/reference/rest/v1beta1/projects.locations.repositories" aria-label="dataform.googleapis.com/Repository reference">Read more</a>

`dataform.googleapis.com/WorkflowConfig`

<a href="/dataform/reference/rest/v1beta1/projects.locations.repositories.workflowConfigs" aria-label="dataform.googleapis.com/WorkflowConfig reference">Read more</a>

`dataform.googleapis.com/WorkflowInvocation`

<a href="/dataform/reference/rest/v1beta1/projects.locations.repositories.workflowInvocations" aria-label="dataform.googleapis.com/WorkflowInvocation reference">Read more</a>

`dataform.googleapis.com/Workspace`

<a href="/dataform/reference/rest/v1beta1/projects.locations.repositories.workspaces" aria-label="dataform.googleapis.com/Workspace reference">Read more</a>

`dns.googleapis.com/ResourceRecordSet`

<a href="/dns/docs/reference/rest/v1/resourceRecordSets" aria-label="dns.googleapis.com/ResourceRecordSet reference">Read more</a>

`firestore.googleapis.com/Database`

[Read more](/firestore/docs/reference/rest/v1/projects.databases)

`iap.googleapis.com/Tunnel`

<a href="/iap/docs/managing-access#resources_and_permissions" aria-label="iap.googleapis.com/Tunnel reference">Read more</a>

`iap.googleapis.com/TunnelInstance`

<a href="/iap/docs/managing-access#resources_and_permissions" aria-label="iap.googleapis.com/TunnelInstance reference">Read more</a>

`iap.googleapis.com/TunnelZone`

<a href="/iap/docs/managing-access#resources_and_permissions" aria-label="iap.googleapis.com/TunnelZone reference">Read more</a>

`iap.googleapis.com/Web`

<a href="/iap/docs/managing-access#resources_and_permissions" aria-label="iap.googleapis.com/Web reference">Read more</a>

`iap.googleapis.com/WebService`

<a href="/iap/docs/managing-access#resources_and_permissions" aria-label="iap.googleapis.com/WebService reference">Read more</a>

`iap.googleapis.com/WebServiceVersion`

<a href="/iap/docs/managing-access#resources_and_permissions" aria-label="iap.googleapis.com/WebServiceVersion reference">Read more</a>

`iap.googleapis.com/WebType`

<a href="/iap/docs/managing-access#resources_and_permissions" aria-label="iap.googleapis.com/WebType reference">Read more</a>

`integrations.googleapis.com/AuthConfig`

[Read more](/application-integration/docs/reference/rest/v1/projects.locations.authConfigs)

`integrations.googleapis.com/Execution`

[Read more](/application-integration/docs/reference/rest/v1/projects.locations.integrations.executions)

`integrations.googleapis.com/Integration`

[Read more](/application-integration/docs/reference/rest/v1/projects.locations.integrations)

`integrations.googleapis.com/IntegrationVersion`

[Read more](/application-integration/docs/reference/rest/v1/projects.locations.integrations.versions)

`integrations.googleapis.com/Location`

n/a

`integrations.googleapis.com/Suspension`

[Read more](/application-integration/docs/reference/rest/v1/projects.locations.integrations.executions.suspensions)

`logging.googleapis.com/LogBucket`

<a href="/logging/docs/reference/v2/rest/v2/projects.locations.buckets" aria-label="logging.googleapis.com/LogBucket reference">Read more</a>

`logging.googleapis.com/LogView`

<a href="/logging/docs/reference/v2/rest/v2/projects.locations.buckets.views" aria-label="logging.googleapis.com/LogView reference">Read more</a>

`managedkafka.googleapis.com/Cluster`

<a href="/managed-service-for-apache-kafka/docs/reference/rest/v1/projects.locations.clusters" aria-label="managedkafka.googleapis.com/Cluster reference">Read more</a>

`managedkafka.googleapis.com/ConsumerGroup`

<a href="/managed-service-for-apache-kafka/docs/reference/rest/v1/projects.locations.clusters.consumerGroups" aria-label="managedkafka.googleapis.com/ConsumerGroup reference">Read more</a>

`managedkafka.googleapis.com/Operation`

<a href="/managed-service-for-apache-kafka/docs/reference/rest/v1/projects.locations.operations" aria-label="managedkafka.googleapis.com/Operation reference">Read more</a>

`managedkafka.googleapis.com/Topic`

<a href="/managed-service-for-apache-kafka/docs/reference/rest/v1/projects.locations.clusters.topics" aria-label="managedkafka.googleapis.com/Topic reference">Read more</a>

`networksecurity.googleapis.com/AddressGroup`

<a href="/firewall/docs/reference/network-security/rest/v1/projects.locations.addressGroups" aria-label="networksecurity.googleapis.com/AddressGroup reference">Read more</a>

`networksecurity.googleapis.com/FirewallEndpoint`

<a href="/firewall/docs/reference/network-security/rest/v1/organizations.locations.firewallEndpoints" aria-label="networksecurity.googleapis.com/FirewallEndpoint reference">Read more</a>

`networksecurity.googleapis.com/FirewallEndpointAssociation`

<a href="/firewall/docs/reference/network-security/rest/v1/projects.locations.firewallEndpointAssociations" aria-label="networksecurity.googleapis.com/FirewallEndpointAssociation reference">Read more</a>

`networksecurity.googleapis.com/InterceptDeployment`

<a href="/network-security-integration/docs/reference/rest/v1/projects.locations.interceptDeployments" aria-label="networksecurity.googleapis.com/InterceptDeployment reference">Read more</a>

`networksecurity.googleapis.com/InterceptDeploymentGroup`

<a href="/network-security-integration/docs/reference/rest/v1/projects.locations.interceptDeploymentGroups" aria-label="networksecurity.googleapis.com/InterceptDeploymentGroup reference">Read more</a>

`networksecurity.googleapis.com/InterceptEndpointGroup`

<a href="/network-security-integration/docs/reference/rest/v1/projects.locations.interceptEndpointGroups" aria-label="networksecurity.googleapis.com/InterceptEndpointGroup reference">Read more</a>

`networksecurity.googleapis.com/InterceptEndpointGroupAssociation`

<a href="/network-security-integration/docs/reference/rest/v1/projects.locations.interceptEndpointGroupAssociations" aria-label="networksecurity.googleapis.com/InterceptEndpointGroupAssociation reference">Read more</a>

`networksecurity.googleapis.com/MirroringDeployment`

<a href="/network-security-integration/docs/reference/rest/v1/projects.locations.mirroringDeployments" aria-label="networksecurity.googleapis.com/MirroringDeployment reference">Read more</a>

`networksecurity.googleapis.com/MirroringDeploymentGroup`

<a href="/network-security-integration/docs/reference/rest/v1/projects.locations.mirroringDeploymentGroups" aria-label="networksecurity.googleapis.com/MirroringDeploymentGroup reference">Read more</a>

`networksecurity.googleapis.com/MirroringEndpointGroup`

<a href="/network-security-integration/docs/reference/rest/v1/projects.locations.mirroringEndpointGroups" aria-label="networksecurity.googleapis.com/MirroringEndpointGroup reference">Read more</a>

`networksecurity.googleapis.com/MirroringEndpointGroupAssociation`

<a href="/network-security-integration/docs/reference/rest/v1/projects.locations.mirroringEndpointGroupAssociations" aria-label="networksecurity.googleapis.com/MirroringEndpointGroupAssociation reference">Read more</a>

`networksecurity.googleapis.com/SecurityProfile`

<a href="/firewall/docs/reference/network-security/rest/v1/organizations.locations.securityProfiles" aria-label="networksecurity.googleapis.com/SecurityProfile reference">Read more</a>

`networksecurity.googleapis.com/SecurityProfileGroup`

<a href="/firewall/docs/reference/network-security/rest/v1/organizations.locations.securityProfileGroups" aria-label="networksecurity.googleapis.com/SecurityProfileGroup reference">Read more</a>

`parametermanager.googleapis.com/Parameter`

<a href="/secret-manager/parameter-manager/docs/reference/rest/v1/projects.locations.parameters" aria-label="parametermanager.googleapis.com/Parameter reference">Read more</a>

`parametermanager.googleapis.com/ParameterVersion`

<a href="/secret-manager/parameter-manager/docs/reference/rest/v1/projects.locations.parameters.versions" aria-label="parametermanager.googleapis.com/ParameterVersion reference">Read more</a>

`pubsublite.googleapis.com/Location`

<a href="/pubsub/lite/docs/reference/rest" aria-label="pubsublite.googleapis.com/Location reference">Read more</a>

`pubsublite.googleapis.com/Subscription`

<a href="/pubsub/lite/docs/reference/rest/v1/admin.projects.locations.subscriptions" aria-label="pubsublite.googleapis.com/Subscription reference">Read more</a>

`pubsublite.googleapis.com/Topic`

<a href="/pubsub/lite/docs/reference/rest/v1/admin.projects.locations.topics" aria-label="pubsublite.googleapis.com/Topic reference">Read more</a>

`secretmanager.googleapis.com/Secret`

<a href="/secret-manager/docs/reference/rest/v1/projects.secrets" aria-label="secretmanager.googleapis.com/Secret reference">Read more</a>

`secretmanager.googleapis.com/SecretVersion`

<a href="/secret-manager/docs/reference/rest/v1/projects.secrets.versions" aria-label="secretmanager.googleapis.com/SecretVersion reference">Read more</a>

`spanner.googleapis.com/Backup`

<a href="/spanner/docs/reference/rest/v1/projects.instances.backups" aria-label="spanner.googleapis.com/Backup reference">Read more</a>

`spanner.googleapis.com/Database`

<a href="/spanner/docs/reference/rest/v1/projects.instances.databases" aria-label="spanner.googleapis.com/Database reference">Read more</a>

`spanner.googleapis.com/Instance`

<a href="/spanner/docs/reference/rest/v1/projects.instances" aria-label="spanner.googleapis.com/Instance reference">Read more</a>

`sqladmin.googleapis.com/BackupRun`

<a href="/sql/docs/mysql/admin-api/rest/v1/backupRuns" aria-label="sqladmin.googleapis.com/BackupRun reference">Read more</a>

`sqladmin.googleapis.com/Instance`

<a href="/sql/docs/mysql/admin-api/rest/v1/instances" aria-label="sqladmin.googleapis.com/Instance reference">Read more</a>

`storage.googleapis.com/Bucket`

<a href="/storage/docs/buckets" aria-label="storage.googleapis.com/Bucket reference">Read more</a>

`storage.googleapis.com/Folder`

<a href="/storage/docs/folders-overview" aria-label="storage.googleapis.com/Folder reference">Read more</a>

`storage.googleapis.com/ManagedFolder`

<a href="/storage/docs/managed-folders" aria-label="storage.googleapis.com/ManagedFolder reference">Read more</a>

`storage.googleapis.com/Object`

<a href="/storage/docs/objects" aria-label="storage.googleapis.com/Object reference">Read more</a>

<sup>1</sup> Cloud Key Management Service uses this resource type as the parent of [key ring](/kms/docs/object-hierarchy#key_ring) resources.

<sup>2</sup> Apigee uses this resource type as the parent of any resource that belongs to an Apigee organization.

<span id="resource_name_format"></span>

## Resource name format

The following table lists the format of each type of resource name attribute.

**Note:** Ensure that you use the correct identifier for your project. Project IDs are alphanumeric, and project numbers are numeric. You can't substitute the project ID for the project number, or the project number for the project ID. For more information, see [Creating and managing projects](/resource-manager/docs/creating-managing-projects#before_you_begin).

Resource reference

Resource name format template

Agent Registry [skills](/agent-registry/reference/rest/v1alpha/projects.locations.skills)

`projects/``project-id``/locations/``location``/skills/``skill-id`

Agent Registry [skill-revisions](/agent-registry/reference/rest/v1alpha/projects.locations.skills.revisions)

`projects/``project-id``/locations/``location``/skills/``skill-id``/revisions/``skill-revision-id`

Apigee [API product attributes](/apigee/docs/reference/apis/apigee/rest/v1/organizations.apiproducts.attributes)

`organizations/``organization-name``/apiproducts/``product-id``/attributes/``attribute-id`

Apigee [API products](/apigee/docs/reference/apis/apigee/rest/v1/organizations.apiproducts)

`organizations/``organization-name``/apiproducts/``product-id`

Apigee [API proxies](/apigee/docs/reference/apis/apigee/rest/v1/ApiProxy)

`organizations/``organization-name``/apis/``proxy-id`

Apigee [API proxy key-value map entries](/apigee/docs/reference/apis/apigee/rest/v1/organizations.keyvaluemaps.entries)

`organizations/``organization-name``/api/``proxy-id``/keyvaluemaps/``keyvaluemap-id``/entries/``entry-id`

Apigee [API proxy key-value maps](/apigee/docs/reference/apis/apigee/rest/v1/organizations.keyvaluemaps)

`organizations/``organization-name``/apis/``proxy-id``/keyvaluemaps/``key-value-map-id`

Apigee [API proxy revisions](/apigee/docs/reference/apis/apigee/rest/v1/ApiProxyRevision)

`organizations/``organization-name``/apis/``proxy-id``/revisions/``revision-id`

Apigee [caches](/apigee/docs/reference/apis/apigee/rest/v1/organizations.environments.caches)

`organizations/``organization-name``/environments/``environment-id``/caches/``cache-id`

Apigee [developer app attributes](/apigee/docs/reference/apis/apigee/rest/v1/organizations.developers.apps.attributes)

`organizations/``organization-name``/developers/``developer-id``/apps/``app-id``/attributes/``attribute-id`

Apigee [developer apps](/apigee/docs/reference/apis/apigee/rest/v1/organizations.developers.apps)

`organizations/``organization-name``/developers/``developer-id``/apps/``app-id`

Apigee [developer attributes](/apigee/docs/reference/apis/apigee/rest/v1/organizations.developers/attributes)

`organizations/``organization-name``/developers/``developer-id``/attributes/``attribute-id`

Apigee [developers](/apigee/docs/reference/apis/apigee/rest/v1/organizations.developers)

`organizations/``organization-name``/developers/``developer-id`

Apigee [environment key-value map entries](/apigee/docs/reference/apis/apigee/rest/v1/organizations.keyvaluemaps.entries)

`organizations/``organization-name``/environments/``environment-id``/keyvaluemaps/``keyvaluemap-id``/entries/``entry-id`

Apigee [environment key-value maps](/apigee/docs/reference/apis/apigee/rest/v1/organizations.keyvaluemaps)

`organizations/``organization-name``/environments/``environment``/keyvaluemaps/``key-value-map-id`

Apigee [exports](/apigee/docs/reference/apis/apigee/rest/v1/organizations.environments.analytics.exports)

`organizations/``organization-name``/environments/``environment-id``/analytics/exports/``export-id`

Apigee [flow hooks](/apigee/docs/reference/apis/apigee/rest/v1/organizations.environments.flowhooks)

`organizations/``organization-name``/environments/``environment-id``/flowhooks/``flowhook-id`

Apigee [keystore aliases](/apigee/docs/reference/apis/apigee/rest/v1/organizations.environments.keystores.aliases)

`organizations/``organization-name``/environments/``environment-id``/keystores/``keystore-id``/aliases/``alias-id`

Apigee [keystores](/apigee/docs/reference/apis/apigee/rest/v1/organizations.environments.keystores)

`organizations/``organization-name``/environments/``environment-id``/keystores/``keystore-id`

Apigee [queries](/apigee/docs/reference/apis/apigee/rest/v1/organizations.environments.queries)

`organizations/``organization-name``/environments/``environment-id``/queries/``query-id`

Apigee [rate plans](/apigee/docs/reference/apis/apigee/rest/v1/organizations.apiproducts.rateplans)

`organizations/``organization-name``/apiproducts/``product-id``/rateplans/``rate-plan-id`

Apigee [references](/apigee/docs/reference/apis/apigee/rest/v1/organizations.environments.references)

`organizations/``organization-name``/environments/``environment-id``/references/``reference-id`

Apigee [shared flow revisions](/apigee/docs/reference/apis/apigee/rest/v1/SharedFlowRevision)

`organizations/``organization-name``/sharedflows/``shared-flow-id``/revisions/``revision-id`

Apigee [shared flows](/apigee/docs/reference/apis/apigee/rest/v1/SharedFlow)

`organizations/``organization-name``/sharedflows/``shared-flow-id`

Apigee [target servers](/apigee/docs/reference/apis/apigee/rest/v1/organizations.environments.targetservers)

`organizations/``organization-name``/environments/``environment-id``/targetservers/``targetserver-id`

Apigee [trace (debug) sessions](/apigee/docs/reference/apis/apigee/rest/v1/organizations.environments.apis.revisions.debugsessions)

`organizations/``organization-name``/environments/``environment-id``/apis/``proxy-id``/revisions/``revision-id``/debugsessions/``session-id`

Apigee API Hub [apis](/apigee/docs/reference/apis/apihub/rest/v1/projects.locations.apis)

`projects/``project-id``/locations/``location-id``/apis/``api-id`

Apigee API Hub [deployments](/apigee/docs/reference/apis/apihub/rest/v1/projects.locations.deployments)

`projects/``project-id``/locations/``location-id``/deployments/``deployment-id`

Apigee API Hub [versions](/apigee/docs/reference/apis/apihub/rest/v1/projects.locations.apis.versions)

`projects/``project-id``/locations/``location-id``/apis/``api-id``/versions/``version-id`

Apigee API Hub [specs](/apigee/docs/reference/apis/apihub/rest/v1/projects.locations.apis.versions.specs)

`projects/``project-id``/locations/``location-id``/apis/``api-id``/versions/``version-id``/specs/``spec-id`

Apigee API Hub [operations](/apigee/docs/reference/apis/apihub/rest/v1/projects.locations.apis.versions.operations)

`projects/``project-id``/locations/``location-id``/apis/``api-id``/versions/``version-id``/operations/``operation-id`

Apigee API Hub [definitions](/apigee/docs/reference/apis/apihub/rest/v1/projects.locations.apis.versions.definitions)

`projects/``project-id``/locations/``location-id``/apis/``api-id``/versions/``version-id``/definitions/``definition-id`

Backup and DR Service [backupVaults](/backup-disaster-recovery/docs/concepts/backup-vault) <span data-title="Preview" aria-label="Preview"><span class="material-icons" aria-hidden="true" translate="no">science</span></span>

`projects/``project-id``/locations/``location-id``/backupVaults/``backup-vault-id`

BigQuery [datasets](/bigquery/docs/reference/rest/v2/datasets)

`projects/``project-id``/datasets/``dataset-id`

BigQuery [models](/bigquery/docs/reference/rest/v2/models)

`projects/``project-id``/datasets/``dataset-id``/models/``model-id`

BigQuery [routines](/bigquery/docs/reference/rest/v2/routines)

`projects/``project-id``/datasets/``dataset-id``/routines/``routine-id`

BigQuery [tables](/bigquery/docs/reference/rest/v2/tables)

`projects/``project-id``/datasets/``dataset-id``/tables/``table-id`

BigQuery Reservation API [assignments](/bigquery/docs/reference/reservations/rest/v1/projects.locations.reservations.assignments)

`projects/``project-id``/locations/``location-id``/reservations/``reservation-id``/assignments/``assignment-id`

BigQuery Reservation API [BI reservations](/bigquery/docs/reference/reservations/rest/v1/BiReservation)

`projects/``project-id``/locations/``location-id``/biReservation`

BigQuery Reservation API [capacity commitments](/bigquery/docs/reference/reservations/rest/v1/projects.locations.capacityCommitments)

`projects/``project-id``/locations/``location-id``/capacityCommitments/``capacity-commitment-id`

BigQuery Reservation API [locations](/bigquery/docs/reference/reservations/rest/v1/projects.locations)

`projects/``project-id``/locations/``location-id`

BigQuery Reservation API [reservations](/bigquery/docs/reference/reservations/rest/v1/projects.locations.reservations)

`projects/``project-id``/locations/``location-id``/reservations/``reservation-id`

Binary Authorization [attestors](/binary-authorization/docs/reference/rest/v1/projects.attestors)

`projects/``project-number``/attestors/``attestor-id`

Binary Authorization [continuous validation configs](/binary-authorization/docs/reference/rest/v1alpha2/projects.continuousValidationConfig)

`projects/``project-number``/continuousValidationConfig`

Binary Authorization [policies](/binary-authorization/docs/reference/rest/v1/projects.policy)

`projects/``project-number``/policy`

Customer Experience Agent Studio [apps](/customer-engagement-ai/conversational-agents/ps/reference/rest/v1/projects.locations.apps)

`projects/``project-id``/locations/``location-id``/apps/``app-id`

Customer Experience Agent Studio [operations](/customer-engagement-ai/conversational-agents/ps/reference/rest/v1/projects.locations.operations)

`projects/``project-id``/locations/``location-id``/operations/``operation-id`

Bigtable [appProfiles](/bigtable/docs/reference/admin/rest/v2/projects.instances.appProfiles)

`projects/``project-id``/instances/``instance-id``/appProfiles/``appProfile-id`

Bigtable [backups](/bigtable/docs/reference/admin/rest/v2/projects.instances.clusters.backups)

`projects/``project-id``/instances/``instance-id``/clusters/``cluster-id``/backups/``backup-id`

Bigtable [clusters](/bigtable/docs/reference/admin/rest/v2/projects.instances.clusters)

`projects/``project-id``/instances/``instance-id``/clusters/``cluster-id`

Bigtable [instances](/bigtable/docs/reference/admin/rest/v2/projects.instances)

`projects/``project-id``/instances/``instance-id`

Bigtable [tables](/bigtable/docs/reference/admin/rest/v2/projects.instances.tables)

`projects/``project-id``/instances/``instance-id``/tables/``table-id`

Cloud Deploy [automation runs](/deploy/docs/api/reference/rest/v1/projects.locations.deliveryPipelines.automationRuns)

`projects/``project-id``/locations/``location-id``/deliveryPipelines/``delivery-pipeline-id``/automationRuns/``automation-run-id`

Cloud Deploy [automations](/deploy/docs/api/reference/rest/v1/projects.locations.deliveryPipelines.automations)

`projects/``project-id``/locations/``location-id``/deliveryPipelines/``delivery-pipeline-id``/automations/``automation-id`

Cloud Deploy [custom target types](/deploy/docs/api/reference/rest/v1/projects.locations.customTargetTypes)

`projects/``project-id``/locations/``location-id``/customTargetTypes/``custom-target-type-id`

Cloud Deploy [delivery pipelines](/deploy/docs/api/reference/rest/v1/projects.locations.deliveryPipelines)

`projects/``project-id``/locations/``location-id``/deliveryPipelines/``delivery-pipeline-id`

Cloud Deploy [job runs](/deploy/docs/api/reference/rest/v1/projects.locations.deliveryPipelines.releases.rollouts.jobRuns)

`projects/``project-id``/locations/``location-id``/deliveryPipelines/``delivery-pipeline-id``/releases/``release-id``/rollouts/``rollout-id``/jobRuns/``job-run-id`

Cloud Deploy [releases](/deploy/docs/api/reference/rest/v1/projects.locations.deliveryPipelines.releases)

`projects/``project-id``/locations/``location-id``/deliveryPipelines/``delivery-pipeline-id``/releases/``release-id`

Cloud Deploy [rollouts](/deploy/docs/api/reference/rest/v1/projects.locations.deliveryPipelines.releases.rollouts)

`projects/``project-id``/locations/``location-id``/deliveryPipelines/``delivery-pipeline-id``/releases/``release-id``/rollouts/``rollout-id`

Cloud Deploy [targets](/deploy/docs/api/reference/rest/v1/projects.locations.targets)

`projects/``project-id``/locations/``location-id``/targets/``target-id`

Firestore [databases](/firestore/docs/reference/rest/v1/projects.databases)

`projects/``project-id``/databases/``database-id`

Cloud NGFW [address groups](/firewall/docs/reference/network-security/rest/v1/projects.locations.addressGroups)

`projects/``project-number``/locations/``location``/addressGroups/``address-group-name`  
`organizations/``organization-id``/locations/``location``/addressGroups/``address-group-name`

Cloud NGFW [firewall endpoints](/firewall/docs/reference/network-security/rest/v1/organizations.locations.firewallEndpoints)

`projects/``project-number``/locations/``location``/firewallEndpoints/``firewall-endpoint-id`  
`organizations/``organization-id``/locations/``location``/firewallEndpoints/``firewall-endpoint-id`

Cloud NGFW [firewall endpoint associations](/firewall/docs/reference/network-security/rest/v1/projects.locations.firewallEndpointAssociations)

`projects/``project-number``/locations/``location``/firewallEndpointAssociations/``firewall-endpoint-association-id`

Cloud NGFW [security profile groups](/firewall/docs/reference/network-security/rest/v1/projects.locations.securityProfileGroups)<sup>1</sup>

`projects/``project-number``/locations/``location``/securityProfileGroups/``security-profile-group-id`

Cloud NGFW [security profiles](/firewall/docs/reference/network-security/rest/v1/projects.locations.securityProfiles)<sup>1</sup>

`projects/``project-number``/locations/``location``/securityProfiles/``security-profile-id`

Network Security Integration [intercept deployment groups](/network-security-integration/docs/reference/rest/v1/projects.locations.interceptDeploymentGroups)

`projects/``project-number``/locations/``location``/interceptDeploymentGroups/``intercept-deployment-group-id`

Network Security Integration [intercept deployments](/network-security-integration/docs/reference/rest/v1/projects.locations.interceptDeployments)

`projects/``project-number``/locations/``location``/interceptDeployments/``intercept-deployment-id`

Network Security Integration [intercept endpoint group associations](/network-security-integration/docs/reference/rest/v1/projects.locations.interceptEndpointGroupAssociations)

`projects/``project-number``/locations/``location``/interceptEndpointGroupAssociations/``intercept-endpoint-group-association-id`

Network Security Integration [intercept endpoint groups](/network-security-integration/docs/reference/rest/v1/projects.locations.interceptEndpointGroups)

`projects/``project-number``/locations/``location``/interceptEndpoints/``intercept-endpoint-group-id`

Network Security Integration [mirroring deployment groups](/network-security-integration/docs/reference/rest/v1/projects.locations.mirroringDeploymentGroups)

`projects/``project-number``/locations/``location``/mirroringDeploymentGroups/``mirroring-deployment-group-id`

Network Security Integration [mirroring deployments](/network-security-integration/docs/reference/rest/v1/projects.locations.mirroringDeployments)

`projects/``project-number``/locations/``location``/mirroringDeployments/``mirroring-deployment-id`

Network Security Integration [mirroring endpoint group associations](/network-security-integration/docs/reference/rest/v1/projects.locations.mirroringEndpointGroupAssociations)

`projects/``project-number``/locations/``location``/mirroringEndpointGroupAssociations/``mirroring-endpoint-group-association-id`

Network Security Integration [mirroring endpoint groups](/network-security-integration/docs/reference/rest/v1/projects.locations.mirroringEndpointGroups)

`projects/``project-number``/locations/``location``/mirroringEndpoints/``mirroring-endpoint-group-id`

Cloud Key Management Service [crypto keys](/kms/docs/reference/rest/v1/projects.locations.keyRings.cryptoKeys)

`projects/``project-id``/locations/``location-id``/keyRings/``keyring-id``/cryptoKeys/``cryptokey-id`

Cloud Key Management Service [crypto key versions](/kms/docs/reference/rest/v1/projects.locations.keyRings.cryptoKeys.cryptoKeyVersions)

`projects/``project-id``/locations/``location-id``/keyRings/``keyring-id``/cryptoKeys/``cryptokey-id``/cryptoKeyVersions/``cryptokeyversion-id`

Cloud Key Management Service [key rings](/kms/docs/reference/rest/v1/projects.locations.keyRings)

`projects/``project-id``/locations/``location-id``/keyRings/``keyring-id`

Cloud Logging [log buckets](/logging/docs/reference/v2/rest/v2/projects.locations.buckets)

`projects/``project-id``/locations/``location-id``/buckets/``bucket-id`

Cloud Logging [log views](/logging/docs/reference/v2/rest/v2/projects.locations.buckets.views)

`projects/``project-id``/locations/``location-id``/buckets/``bucket-id``/views/``view-id`

Spanner [backups](/spanner/docs/reference/rest/v1/projects.instances.backups)

`projects/``project-id``/instances/``instance-id``/backups/``backup-id`

Spanner [databases](/spanner/docs/reference/rest/v1/projects.instances.databases)

`projects/``project-id``/instances/``instance-id``/databases/``database-id`

Spanner [instances](/spanner/docs/reference/rest/v1/projects.instances)

`projects/``project-id``/instances/``instance-id`

Cloud SQL [backup runs](/sql/docs/mysql/admin-api/rest/v1/backupRuns)

`projects/``project-id``/instances/``instance-id``/backupRuns/``backup-id`

Cloud SQL [instances](/sql/docs/mysql/admin-api/rest/v1/instances)

`projects/``project-id``/instances/``instance-id`

Cloud Storage [buckets](/storage/docs/json_api/v1/buckets)<sup>2</sup>

`projects/_/buckets/``bucket-name`

Cloud Storage [folders](/storage/docs/json_api/v1/folders) in buckets with hierarchical namespace enabled<sup>2, 3</sup>

`projects/_/buckets/``bucket-name``/folders/``folder-name`

Cloud Storage [managed folders](/storage/docs/json_api/v1/managedFolder)<sup>2, 4</sup>

`projects/_/buckets/``bucket-name``/managedFolders/``managed-folder-name`

Cloud Storage [objects](/storage/docs/json_api/v1/objects)<sup>2, 5</sup>

`projects/_/buckets/``bucket-name``/objects/``object-name`

Compute Engine [global backend services](/compute/docs/reference/rest/v1/backendServices)

`projects/``project-id``/global/backendServices/``backend-service-id`

Compute Engine [regional backend services](/compute/docs/reference/rest/v1/backendServices)

`projects/``project-id``/regions/``region-id``/backendServices/``backend-service-id`

Compute Engine [firewalls](/compute/docs/reference/rest/v1/firewalls)

`projects/``project-id``/global/firewalls/``firewall-id`

Compute Engine [global forwarding rules](/compute/docs/reference/rest/v1/globalForwardingRules)

`projects/``project-id``/global/forwardingRules/``forwarding-rule-id`

Compute Engine [regional forwarding rules](/compute/docs/reference/rest/v1/forwardingRules)

`projects/``project-id``/regions/``region-id``/forwardingRules/``forwarding-rule-id`

Compute Engine [images](/compute/docs/reference/rest/v1/images)

`projects/``project-id``/global/images/``image-id`

Compute Engine [instance templates](/compute/docs/reference/rest/v1/instanceTemplates)

`projects/``project-id``/global/instanceTemplates/``instance-template-id`

Compute Engine [instances](/compute/docs/reference/rest/v1/instances)

`projects/``project-id``/zones/``zone-id``/instances/``instance-id`

Compute Engine [regional persistent disks](/compute/docs/reference/rest/v1/regionDisks)

`projects/``project-id``/regions/``region-id``/disks/``disk-id`

Compute Engine [zonal persistent disks](/compute/docs/reference/rest/v1/disks)

`projects/``project-id``/zones/``zone-id``/disks/``disk-id`

Compute Engine [snapshots](/compute/docs/reference/rest/v1/snapshots)

`projects/``project-id``/global/snapshots/``snapshot-id`

Compute Engine [global target HTTP proxies](/compute/docs/reference/rest/v1/targetHttpProxies)

`projects/``project-id``/global/targetHttpProxies/``target-http-proxy-id`

Compute Engine [regional target HTTP proxies](/compute/docs/reference/rest/v1/regionTargetHttpProxies)

`projects/``project-id``/regions/``region-id``/targetHttpProxies/``target-http-proxy-id`

Compute Engine [global target HTTPS proxies](/compute/docs/reference/rest/v1/targetHttpsProxies)

`projects/``project-id``/global/targetHttpsProxies/``target-https-proxy-id`

Compute Engine [regional target HTTPS proxies](/compute/docs/reference/rest/v1/regionTargetHttpsProxies)

`projects/``project-id``/regions/``region-id``/targetHttpsProxies/``target-https-proxy-id`

Compute Engine [target SSL proxies](/compute/docs/reference/rest/v1/targetSslProxies)

`projects/``project-id``/global/targetSslProxies/``target-ssl-proxy-id`

Compute Engine [target TCP proxies](/compute/docs/reference/rest/v1/targetTcpProxies)

`projects/``project-id``/global/targetTcpProxies/``target-tcp-proxy-id`

Google Kubernetes Engine [zonal clusters](/kubernetes-engine/docs/reference/rest/v1/projects.zones.clusters)

`projects/``project-id``/zones/``zone``/clusters/``cluster-id`

Google Kubernetes Engine [regional clusters](/kubernetes-engine/docs/reference/rest/v1/projects.locations.clusters)

`projects/``project-id``/locations/``location``/clusters/``cluster-id`

Dataform [compilation results](/dataform/reference/rest/v1beta1/projects.locations.repositories.compilationResults)

`projects/``project-id``/locations/``location``/repositories/``repository``/compilationResults/``compilation-result`

Dataform [locations](/dataform/reference/rest/v1beta1/projects.locations)

`projects/``project-id``/locations/``location`

Dataform [release configs](/dataform/reference/rest/v1beta1/projects.locations.repositories.releaseConfigs)

`projects/``project-id``/locations/``location``/repositories/``repository``/releaseConfigs/``release-config`

Dataform [repositories](/dataform/reference/rest/v1beta1/projects.locations.repositories)

`projects/``project-id``/locations/``location``/repositories/``repository`

Dataform [workflow configs](/dataform/reference/rest/v1beta1/projects.locations.repositories.workflowConfigs)

`projects/``project-id``/locations/``location``/repositories/``repository``/workflowConfigs/``workflow-config`

Dataform [workflow invocations](/dataform/reference/rest/v1beta1/projects.locations.repositories.workflowInvocations)

`projects/``project-id``/locations/``location``/repositories/``repository``/workflowInvocations/``workflow-invocation`

Dataform [workspaces](/dataform/reference/rest/v1beta1/projects.locations.repositories.workspaces)

`projects/``project-id``/locations/``location``/repositories/``repository``/workspaces/``workspace`

Cloud DNS [resource record sets](/dns/docs/reference/rest/v1/resourceRecordSets)

`projects/``project-id``/managedZones/``zone-id``/rrsets/``rrset-name``/``rrset-type`

Integration Connectors [connections](/integration-connectors/docs/reference/rest/v1/projects.locations.connections)

`projects/``project-id``/locations/``location``/connections/``connection-name`

Integration Connectors [connection schema metadata](/integration-connectors/docs/reference/rest/v1/projects.locations.connections.connectionSchemaMetadata)

`projects/``project-id``/locations/``location``/connections/``connection-name``/connectionSchemaMetadata`

Integration Connectors [endpoint attachments](/integration-connectors/docs/reference/rest/v1/projects.locations.endpointAttachments)

`projects/``project-id``/locations/``location``/endpointAttachments/``endpoint-attachment-name`

Integration Connectors [event subscriptions](/integration-connectors/docs/reference/rest/v1/projects.locations.connections.eventSubscriptions)

`projects/``project-id``/locations/``location``/eventSubscriptions/``event-subscription-name`

Integration Connectors [managed zones](/integration-connectors/docs/reference/rest/v1/projects.locations.global.managedZones)

`projects/``project-id``/locations/global/managedZones/``managed-zone-name`

Google Cloud Managed Service for Apache Kafka [clusters](/managed-service-for-apache-kafka/docs/reference/rest/v1/projects.locations.clusters)

`projects/``project-number``/locations/``location``/clusters/``cluster-name`

Google Cloud Managed Service for Apache Kafka [consumer groups](/managed-service-for-apache-kafka/docs/reference/rest/v1/projects.locations.clusters.consumerGroups)

`projects/``project-number``/locations/``location``/clusters/``cluster-name``/consumerGroups/``consumer-group`

Google Cloud Managed Service for Apache Kafka [operations](/managed-service-for-apache-kafka/docs/reference/rest/v1/projects.locations.operations)

`projects/``project-number``/locations/``location``/operations/``operation`

Google Cloud Managed Service for Apache Kafka [topics](/managed-service-for-apache-kafka/docs/reference/rest/v1/projects.locations.clusters.topics)

`projects/``project-number``/locations/``location``/clusters/``cluster-name``/topics/``topic-name`

Parameter Manager [parameters](/secret-manager/parameter-manager/docs/reference/rest/v1/projects.locations.parameters)

`projects/``project-number``/locations/``location``/parameters/``parameter-id`

Parameter Manager [parameter versions](/secret-manager/parameter-manager/docs/reference/rest/v1/projects.locations.parameters.versions)

`projects/``project-number``/locations/``location``/parameters/``parameter-id``/versions/version-id`

Pub/Sub Lite [locations](/pubsub/lite/docs/reference/rest)

`projects/``project-number``/locations/``location`

Pub/Sub Lite [subscriptions](/pubsub/lite/docs/reference/rest/v1/admin.projects.locations.subscriptions)

`projects/``project-number``/locations/``location``/subscriptions/``subscription-id`

Pub/Sub Lite [topics](/pubsub/lite/docs/reference/rest/v1/admin.projects.locations.topics)

`projects/``project-number``/locations/``location``/topics/``topic-id`

Resource Manager [organizations](/resource-manager/reference/rest/v3/organizations)<sup>6</sup>

`organizations/``organization-name`

Secret Manager [secrets](/secret-manager/docs/reference/rest/v1/projects.secrets)

`projects/``project-number``/secrets/``secret-id`

Secret Manager [secret versions](/secret-manager/docs/reference/rest/v1/projects.secrets.versions)<sup>7</sup>

`projects/``project-number``/secrets/``secret-id``/versions/``secret-version`

<sup>1</sup> IAM Conditions only supports project-level Cloud NGFW resources. Organization-level Cloud NGFW resources are not supported.

<sup>2</sup> For Cloud Storage, resource names contain an underscore (`_`) rather than a project ID. You *cannot* replace the underscore with a project ID, project name, or project number.

<sup>3</sup> Use the entire [folder name](/storage/docs/folders-overview#folder-metadata), including forward slashes.

<sup>4</sup> Use the entire [managed folder name](/storage/docs/managed-folders#managed_folder_names), including forward slashes.

<sup>5</sup> Use the entire [object name](/storage/docs/objects#naming), including forward slashes.

<sup>6</sup> Apigee uses this format when you list any type of resource that belongs to an Apigee organization.

<sup>7</sup> If a condition evaluates the resource name for a secret version, the secret version in the request must exactly match the secret version in the condition for the condition to be satisfied. For example, if the version in the condition is `latest`, only a request with the version `latest` satisfies the condition; a request with the version `3` does not satisfy the condition, even if `3` is the latest version.

## Resource tags

You can attach [tags](/iam/docs/tags-access-control) to organizations, projects, and folders. Any Google Cloud resource can inherit tags from these higher-level resources.

You can use a few different types of identifiers to refer to tag keys and values:

- A *permanent ID*, which is globally unique and can never be reused. For example, a tag key could have the permanent ID `tagKeys/123456789012`, and a tag value could have the permanent ID `tagValues/567890123456`.
- A *short name*. The short name for each key must be unique within the project or organization under which the key is defined, and the short name for each value must be unique for its associated key. For example, a tag key could have the short name `env`, and a tag value could have the short name `prod`.
- A *namespaced name*, which adds your organization's numeric ID or project's ID to the short name of a tag key. For example, a tag key created for an organization could have the namespaced name `123456789012/env`. To learn how to get your organization ID, see [Getting your organization resource ID](/resource-manager/docs/creating-managing-organization#retrieving_your_organization_id). A tag key created for a project could have the namespaced name `myproject/env`. To learn how to get your project ID, see [Identifying projects](/resource-manager/docs/creating-managing-projects#identifying_projects).

The specific identifiers depend on the tag keys and values that you have created for your organization. To learn how to list the tag keys and values that are available to you, see [Listing tag keys](/resource-manager/docs/tags/tags-creating-and-managing#listing_keys) and [Listing tag values](/resource-manager/docs/tags/tags-creating-and-managing#listing_values).

Send feedback

<div class="devsite-floating-action-buttons">

</div>
