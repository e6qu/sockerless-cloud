# Serverless VPC Access roles and permissions

<div class="devsite-article-body clearfix">

This page lists the IAM roles and permissions for Serverless VPC Access. To search through all roles and permissions, see the [role and permission index](/iam/docs/roles-permissions).

## Serverless VPC Access roles

<div results-count-container="">

</div>

<table class="fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="50%">Role</th>
<th>Permissions</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td class="role-description"><h4 id="vpcaccess.admin" class="role-title add-link" data-text="Serverless VPC Access Admin " tabindex="-1">Serverless VPC Access Admin</h4>
<p>(<code translate="no" dir="ltr">roles/vpcaccess.admin</code>)</p>
<span class="role-description"> </span>
<p>Full access to all Serverless VPC Access resources</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">vpcaccess.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">vpcaccess.connectors.create</code></li>
<li><code translate="no" dir="ltr">vpcaccess.connectors.delete</code></li>
<li><code translate="no" dir="ltr">vpcaccess.connectors.get</code></li>
<li><code translate="no" dir="ltr">vpcaccess.connectors.list</code></li>
<li><code translate="no" dir="ltr">vpcaccess.connectors.update</code></li>
<li><code translate="no" dir="ltr">vpcaccess.locations.list</code></li>
<li><code translate="no" dir="ltr">vpcaccess.operations.get</code></li>
<li><code translate="no" dir="ltr">vpcaccess.operations.list</code></li>
</ul></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="vpcaccess.user" class="role-title add-link" data-text="Serverless VPC Access User " tabindex="-1">Serverless VPC Access User</h4>
<p>(<code translate="no" dir="ltr">roles/vpcaccess.user</code>)</p>
<span class="role-description"> </span>
<p>User of Serverless VPC Access connectors</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">compute.networks.access</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><code translate="no" dir="ltr">vpcaccess.connectors.get</code></p>
<p><code translate="no" dir="ltr">vpcaccess.connectors.list</code></p>
<p><code translate="no" dir="ltr">vpcaccess.locations.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">vpcaccess.operations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">vpcaccess.operations.get</code></li>
<li><code translate="no" dir="ltr">vpcaccess.operations.list</code></li>
</ul></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="vpcaccess.viewer" class="role-title add-link" data-text="Serverless VPC Access Viewer " tabindex="-1">Serverless VPC Access Viewer</h4>
<p>(<code translate="no" dir="ltr">roles/vpcaccess.viewer</code>)</p>
<span class="role-description"> </span>
<p>Viewer of all Serverless VPC Access resources</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><code translate="no" dir="ltr">vpcaccess.connectors.get</code></p>
<p><code translate="no" dir="ltr">vpcaccess.connectors.list</code></p>
<p><code translate="no" dir="ltr">vpcaccess.locations.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">vpcaccess.operations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">vpcaccess.operations.get</code></li>
<li><code translate="no" dir="ltr">vpcaccess.operations.list</code></li>
</ul></td>
</tr>
</tbody>
</table>

### Service agent roles

Service agent roles should only be granted to [service agents](/iam/docs/service-agents).

<div results-count-container="">

</div>

<table class="fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="50%">Role</th>
<th>Permissions</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td class="role-description"><h4 id="vpcaccess.serviceAgent" class="role-title add-link" data-text="Serverless VPC Access Service Agent " tabindex="-1">Serverless VPC Access Service Agent</h4>
<p>(<code translate="no" dir="ltr">roles/vpcaccess.serviceAgent</code>)</p>
<span class="role-description"> </span>
<p>Can create and manage resources to support serverless application to connect to virtual private cloud.</p>
<strong>Warning:</strong> Do not grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.</td>
<td class="role-permissions"><p><code translate="no" dir="ltr">billing.accounts.get</code></p>
<p><code translate="no" dir="ltr">compute.addresses.createInternal</code></p>
<p><code translate="no" dir="ltr">compute.addresses.deleteInternal</code></p>
<p><code translate="no" dir="ltr">compute.addresses.get</code></p>
<p><code translate="no" dir="ltr">compute.addresses.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.autoscalers.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.autoscalers.create</code></li>
<li><code translate="no" dir="ltr">compute.autoscalers.delete</code></li>
<li><code translate="no" dir="ltr">compute.autoscalers.get</code></li>
<li><code translate="no" dir="ltr">compute.autoscalers.list</code></li>
<li><code translate="no" dir="ltr">compute.autoscalers.update</code></li>
</ul>
<p><code translate="no" dir="ltr">compute.disks.create</code></p>
<p><code translate="no" dir="ltr">compute.firewalls.create</code></p>
<p><code translate="no" dir="ltr">compute.firewalls.delete</code></p>
<p><code translate="no" dir="ltr">compute.firewalls.get</code></p>
<p><code translate="no" dir="ltr">compute.firewalls.list</code></p>
<p><code translate="no" dir="ltr">compute.firewalls.update</code></p>
<p><code translate="no" dir="ltr">compute.healthChecks.create</code></p>
<p><code translate="no" dir="ltr">compute.healthChecks.delete</code></p>
<p><code translate="no" dir="ltr">compute.healthChecks.get</code></p>
<p><code translate="no" dir="ltr">compute.healthChecks.list</code></p>
<p><code translate="no" dir="ltr">compute.healthChecks.update</code></p>
<p><code translate="no" dir="ltr">compute.healthChecks.use</code></p>
<p><code translate="no" dir="ltr">compute.healthChecks.useReadOnly</code></p>
<p><code translate="no" dir="ltr">compute.httpHealthChecks.create</code></p>
<p><code translate="no" dir="ltr">compute.httpHealthChecks.delete</code></p>
<p><code translate="no" dir="ltr">compute.httpHealthChecks.get</code></p>
<p><code translate="no" dir="ltr">compute.httpHealthChecks.list</code></p>
<p><code translate="no" dir="ltr">compute.httpHealthChecks.use</code></p>
<p><code translate="no" dir="ltr">compute.httpHealthChecks.useReadOnly</code></p>
<p><code translate="no" dir="ltr">compute.httpsHealthChecks.create</code></p>
<p><code translate="no" dir="ltr">compute.httpsHealthChecks.delete</code></p>
<p><code translate="no" dir="ltr">compute.httpsHealthChecks.get</code></p>
<p><code translate="no" dir="ltr">compute.httpsHealthChecks.update</code></p>
<p><code translate="no" dir="ltr">compute.httpsHealthChecks.use</code></p>
<p><code translate="no" dir="ltr">compute.httpsHealthChecks.useReadOnly</code></p>
<p><code translate="no" dir="ltr">compute.images.get</code></p>
<p><code translate="no" dir="ltr">compute.images.useReadOnly</code></p>
<p><code translate="no" dir="ltr">compute.instanceGroupManagers.create</code></p>
<p><code translate="no" dir="ltr">compute.instanceGroupManagers.delete</code></p>
<p><code translate="no" dir="ltr">compute.instanceGroupManagers.get</code></p>
<p><code translate="no" dir="ltr">compute.instanceGroupManagers.update</code></p>
<p><code translate="no" dir="ltr">compute.instanceGroupManagers.use</code></p>
<p><code translate="no" dir="ltr">compute.instanceGroups.create</code></p>
<p><code translate="no" dir="ltr">compute.instanceGroups.delete</code></p>
<p><code translate="no" dir="ltr">compute.instanceGroups.get</code></p>
<p><code translate="no" dir="ltr">compute.instanceGroups.update</code></p>
<p><code translate="no" dir="ltr">compute.instanceTemplates.create</code></p>
<p><code translate="no" dir="ltr">compute.instanceTemplates.delete</code></p>
<p><code translate="no" dir="ltr">compute.instanceTemplates.get</code></p>
<p><code translate="no" dir="ltr">compute.instanceTemplates.useReadOnly</code></p>
<p><code translate="no" dir="ltr">compute.instances.create</code></p>
<p><code translate="no" dir="ltr">compute.instances.delete</code></p>
<p><code translate="no" dir="ltr">compute.instances.get</code></p>
<p><code translate="no" dir="ltr">compute.instances.getGuestAttributes</code></p>
<p><code translate="no" dir="ltr">compute.instances.list</code></p>
<p><code translate="no" dir="ltr">compute.instances.reset</code></p>
<p><code translate="no" dir="ltr">compute.instances.setLabels</code></p>
<p><code translate="no" dir="ltr">compute.instances.setMetadata</code></p>
<p><code translate="no" dir="ltr">compute.instances.setTags</code></p>
<p><code translate="no" dir="ltr">compute.instances.start</code></p>
<p><code translate="no" dir="ltr">compute.instances.stop</code></p>
<p><code translate="no" dir="ltr">compute.instances.use</code></p>
<p><code translate="no" dir="ltr">compute.machineTypes.get</code></p>
<p><code translate="no" dir="ltr">compute.networks.get</code></p>
<p><code translate="no" dir="ltr">compute.networks.updatePolicy</code></p>
<p><code translate="no" dir="ltr">compute.networks.use</code></p>
<p><code translate="no" dir="ltr">compute.projects.get</code></p>
<p><code translate="no" dir="ltr">compute.projects.setCommonInstanceMetadata</code></p>
<p><code translate="no" dir="ltr">compute.regionOperations.get</code></p>
<p><code translate="no" dir="ltr">compute.regionOperations.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.regions.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.regions.get</code></li>
<li><code translate="no" dir="ltr">compute.regions.list</code></li>
</ul>
<p><code translate="no" dir="ltr">compute.subnetworks.create</code></p>
<p><code translate="no" dir="ltr">compute.subnetworks.delete</code></p>
<p><code translate="no" dir="ltr">compute.subnetworks.get</code></p>
<p><code translate="no" dir="ltr">compute.subnetworks.list</code></p>
<p><code translate="no" dir="ltr">compute.subnetworks.use</code></p>
<p><code translate="no" dir="ltr">compute.zoneOperations.get</code></p>
<p><code translate="no" dir="ltr">compute.zoneOperations.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.zones.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.zones.get</code></li>
<li><code translate="no" dir="ltr">compute.zones.list</code></li>
</ul>
<p><code translate="no" dir="ltr">deploymentmanager.compositeTypes.get</code></p>
<p><code translate="no" dir="ltr">deploymentmanager.deployments.create</code></p>
<p><code translate="no" dir="ltr">deploymentmanager.deployments.delete</code></p>
<p><code translate="no" dir="ltr">deploymentmanager.deployments.get</code></p>
<p><code translate="no" dir="ltr">deploymentmanager.deployments.list</code></p>
<p><code translate="no" dir="ltr">deploymentmanager.deployments.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">deploymentmanager.manifests.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">deploymentmanager.manifests.get</code></li>
<li><code translate="no" dir="ltr">deploymentmanager.manifests.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">deploymentmanager.operations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">deploymentmanager.operations.get</code></li>
<li><code translate="no" dir="ltr">deploymentmanager.operations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">deploymentmanager.typeProviders.create</code></p>
<p><code translate="no" dir="ltr">deploymentmanager.typeProviders.get</code></p>
<p><code translate="no" dir="ltr">logging.logEntries.create</code></p>
<p><code translate="no" dir="ltr">logging.logMetrics.create</code></p>
<p><code translate="no" dir="ltr">logging.logMetrics.delete</code></p>
<p><code translate="no" dir="ltr">logging.logMetrics.get</code></p>
<p><code translate="no" dir="ltr">logging.logMetrics.update</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p></td>
</tr>
</tbody>
</table>

## Serverless VPC Access permissions

<table class="permissions-table fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="45%">Permission</th>
<th>Included in roles</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td><h4 id="vpcaccess.connectors.create" class="permission-name add-link" data-text="vpcaccess.connectors.create" tabindex="-1"><code translate="no" dir="ltr">vpcaccess.connectors.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/vpcaccess#vpcaccess.admin">Serverless VPC Access Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/vpcaccess.admin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="vpcaccess.connectors.delete" class="permission-name add-link" data-text="vpcaccess.connectors.delete" tabindex="-1"><code translate="no" dir="ltr">vpcaccess.connectors.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/vpcaccess#vpcaccess.admin">Serverless VPC Access Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/vpcaccess.admin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="vpcaccess.connectors.get" class="permission-name add-link" data-text="vpcaccess.connectors.get" tabindex="-1"><code translate="no" dir="ltr">vpcaccess.connectors.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/vpcaccess#vpcaccess.admin">Serverless VPC Access Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/vpcaccess.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/vpcaccess#vpcaccess.user">Serverless VPC Access User</a> (<code class="role-name" translate="no" dir="ltr">roles/vpcaccess.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/vpcaccess#vpcaccess.viewer">Serverless VPC Access Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/vpcaccess.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.standardServiceAgent">Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.standardServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataconnectors#dataconnectors.serviceAgent">Data Connectors Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataconnectors.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/runapps#runapps.serviceAgent">Serverless Integrations Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/runapps.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="vpcaccess.connectors.list" class="permission-name add-link" data-text="vpcaccess.connectors.list" tabindex="-1"><code translate="no" dir="ltr">vpcaccess.connectors.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/vpcaccess#vpcaccess.admin">Serverless VPC Access Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/vpcaccess.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/vpcaccess#vpcaccess.user">Serverless VPC Access User</a> (<code class="role-name" translate="no" dir="ltr">roles/vpcaccess.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/vpcaccess#vpcaccess.viewer">Serverless VPC Access Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/vpcaccess.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/runapps#runapps.serviceAgent">Serverless Integrations Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/runapps.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="vpcaccess.connectors.update" class="permission-name add-link" data-text="vpcaccess.connectors.update" tabindex="-1"><code translate="no" dir="ltr">vpcaccess.connectors.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/vpcaccess#vpcaccess.admin">Serverless VPC Access Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/vpcaccess.admin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="vpcaccess.locations.list" class="permission-name add-link" data-text="vpcaccess.locations.list" tabindex="-1"><code translate="no" dir="ltr">vpcaccess.locations.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/vpcaccess#vpcaccess.admin">Serverless VPC Access Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/vpcaccess.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/vpcaccess#vpcaccess.user">Serverless VPC Access User</a> (<code class="role-name" translate="no" dir="ltr">roles/vpcaccess.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/vpcaccess#vpcaccess.viewer">Serverless VPC Access Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/vpcaccess.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="vpcaccess.operations.get" class="permission-name add-link" data-text="vpcaccess.operations.get" tabindex="-1"><code translate="no" dir="ltr">vpcaccess.operations.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/vpcaccess#vpcaccess.admin">Serverless VPC Access Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/vpcaccess.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/vpcaccess#vpcaccess.user">Serverless VPC Access User</a> (<code class="role-name" translate="no" dir="ltr">roles/vpcaccess.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/vpcaccess#vpcaccess.viewer">Serverless VPC Access Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/vpcaccess.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="vpcaccess.operations.list" class="permission-name add-link" data-text="vpcaccess.operations.list" tabindex="-1"><code translate="no" dir="ltr">vpcaccess.operations.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/vpcaccess#vpcaccess.admin">Serverless VPC Access Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/vpcaccess.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/vpcaccess#vpcaccess.user">Serverless VPC Access User</a> (<code class="role-name" translate="no" dir="ltr">roles/vpcaccess.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/vpcaccess#vpcaccess.viewer">Serverless VPC Access Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/vpcaccess.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
</tbody>
</table>

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
