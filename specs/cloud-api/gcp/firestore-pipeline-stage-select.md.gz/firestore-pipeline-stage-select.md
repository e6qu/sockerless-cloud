# Select (Transformation Stage)

<div class="devsite-article-body clearfix devsite-no-page-title">

# Select (Transformation Stage)

## Description

Generates new documents, either by referencing a subset of existing fields, or by assigning a field to the result of a given expression.

## Examples

<div class="ds-selector-tabs" ds-scope="lang">

<div class="section">

### <span class="two-line-tab"><span tab-label="modular API"></span>Web</span>

<div>

</div>

``` devsite-click-to-copy
const result = await execute(db.pipeline()
  .collection("books")
  .select(field("soldBooks").multiply(field("price")).round().as("partialRevenue"))
  .aggregate(field("partialRevenue").sum().as("totalRevenue"))
  );test.firestore.js
```

</div>

<div class="section">

##### Swift

<div>

</div>

``` devsite-click-to-copy
let result = try await db.pipeline()
  .collection("books")
  .select([Field("soldBooks").multiply(Field("price")).round().as("partialRevenue")])
  .aggregate([Field("partialRevenue").sum().as("totalRevenue")])
  .execute()PipelineSnippets.swift
```

</div>

<div class="section">

##### <span class="two-line-tab">Kotlin <span class="firebase-platform-label">Android</span></span>

<div>

</div>

``` devsite-click-to-copy
val result = db.pipeline()
    .collection("books")
    .select(Expression.multiply(field("soldBooks"), field("price")).round().alias("partialRevenue"))
    .aggregate(AggregateFunction.sum("partialRevenue").alias("totalRevenue"))
    .execute()DocSnippets.kt
```

</div>

<div class="section">

##### <span class="two-line-tab">Java <span class="firebase-platform-label">Android</span></span>

<div>

</div>

``` devsite-click-to-copy
Task<Pipeline.Snapshot> result = db.pipeline()
    .collection("books")
    .select(Expression.multiply(field("soldBooks"), field("price")).round().alias("partialRevenue"))
    .aggregate(AggregateFunction.sum("partialRevenue").alias("totalRevenue"))
    .execute();DocSnippets.java
```

</div>

<div class="section">

##### Python

<div>

</div>

``` devsite-click-to-copy
from google.cloud.firestore_v1.pipeline_expressions import Field

result = (
    client.pipeline()
    .collection("books")
    .select(
        Field.of("soldBooks")
        .multiply(Field.of("price"))
        .round()
        .as_("partialRevenue")
    )
    .aggregate(Field.of("partialRevenue").sum().as_("totalRevenue"))
    .execute()
)firestore_pipelines.py
```

</div>

<div class="section">

##### Java

<div>

</div>

``` devsite-click-to-copy
Pipeline.Snapshot result =
    firestore
        .pipeline()
        .collection("books")
        .select(round(multiply(field("soldBooks"), field("price"))).as("partialRevenue"))
        .aggregate(sum("partialRevenue").as("totalRevenue"))
        .execute()
        .get();PipelineSnippets.java
```

</div>

<div class="section">

##### Go

<div>

</div>

``` devsite-click-to-copy
snapshot := client.Pipeline().
 Collection("books").
 Select(firestore.Fields(
     firestore.Round(firestore.Multiply(firestore.FieldOf("soldBooks"), firestore.FieldOf("price"))).As("partialRevenue"),
 )).
 Aggregate(firestore.Accumulators(
     firestore.Sum("partialRevenue").As("totalRevenue"),
 )).
 Execute(ctx)pipeline_snippets_arithmetic.go
```

</div>

</div>

## Behavior

### Document Metadata Fields

The `select(...)` stage only emits the fields or expressions explicitly specified in the stage. This is a divergence from Core operations where the `select(...)` setting on a query acts as a property mask rather than a projection and also **always** includes the document's metadata fields of `__name__`, `__create_time__`, and `__update_time__`.

To get Core operations-style behavior in a `select(...)` the fields must be explicitly specified like:

<div>

<div class="section">

### Node.js

<div>

</div>

``` devsite-click-to-copy
const results = await db.pipeline()
  .collection("/users")
  .select(
    field("__name__"),
    field("__create_time__"),
    field("__update_time__"),
    field("email"))
  .execute();
```

</div>

</div>

### Position of a Select Stage

There are no restrictions on when a select stage can be used, but any fields not included in a select stage won't be accessible to subsequent stages in a pipeline. For example, to select only the `name` and `location` fields of all cities in Canada from the following dataset:

<div>

<div class="section">

### Node.js

<div>

</div>

``` devsite-click-to-copy
await db.collection("cities").doc("SF").set({
  name: "San Francisco",
  population: 800000,
  location: {country: "USA", state: "California"}
});

await db.collection("cities").doc("TO").set({
  name: "Toronto",
  population: 3000000,
  location: {country: "Canada", province: "Ontario"}
});
```

</div>

</div>

The following pipeline can be used:

<div>

<div class="section">

### Node.js

<div>

</div>

``` devsite-click-to-copy
const names = await db.pipeline()
  .collection("/cities")
  .where(equal(field("location.country"), "Canada"))
  .select(stringConcat(field("name"), ", ", field("location.country")).as("name"), "population")
  .execute();
```

</div>

</div>

Which produces the following documents:

<div>

</div>

``` devsite-click-to-copy
{ name: "Toronto, Canada", population: 3000000 },
```

However, if the `select(...)` stage is instead placed before the [`where(...)`](/firestore/native/docs/pipeline/stages/transformation/where) stage, like:

<div>

<div class="section">

### Node.js

<div>

</div>

``` devsite-click-to-copy
const names = await db.pipeline()
  .collection("/cities")
  .select(stringConcat(field("name"), ",", field("location.country")).as("name"), "population")
  .where(equal(field("location.country"), "Canada"))
  .execute();
```

</div>

</div>

No documents will be produced, because `location.country` has been removed from the document before the execution of the [`where(...)`](/firestore/native/docs/pipeline/stages/transformation/where) stage.

### Select Nested Fields

The `select(...)` stage can be used to select nested fields from both maps and arrays. For example, to select the nested `country` field and first entry of the `landmarks` array from the following documents:

<div>

<div class="section">

### Node.js

<div>

</div>

``` devsite-click-to-copy
await db.collection("cities").doc("SF").set({
  name: "San Francisco",
  population: 800000,
  location: { country: "USA", state: "California" },
  landmarks: [ "Golden Gate Bridge", "Alcatraz" ]
});

await db.collection("cities").doc("TO").set({
  name: "Toronto",
  population:  3000000,
  province: "ON",
  location: { country: "Canada", province: "Ontario" },
  landmarks: [ "CN Tower", "Casa Loma" ]
});

await db.collection("cities").doc("AT").set({
  name: "Atlantis",
  population: null
});
```

</div>

</div>

The following pipeline can be used:

<div>

<div class="section">

### Node.js

<div>

</div>

``` devsite-click-to-copy
const locations = await db.pipeline()
  .collection("/cities")
  .select(
    field("name").as("city"),
    field("location.country").as("country"),
    field("landmarks").offset(0).as("topLandmark"))
  .execute();
```

</div>

</div>

Which produces the following documents:

<div>

</div>

``` devsite-click-to-copy
{ city: "San Francisco", country: "USA", topLandmark: "Golden Gate Bridge" },
{ city: "Toronto", country: "Canada", topLandmark: "CN Tower" },
{ city: "Atlantis" }
```

If a nested map value or array value does not exist, it is not included in the resulting document. Array and map access in the select stage behaves identically to the [`offset(...)`](/firestore/native/docs/pipeline/stages/transformation/offset) and `get_field(...)` functions, respectively.

### Assign Nested Fields

The result of an expression can also be assigned to a nested field, making it possible to have the `select(...)` stage return a subset of nested fields from the previous stage. For example the following can be used to ensure only the `city` & `state` information is returned while still preserving the document's original shape:

<div>

<div class="section">

### Node.js

<div>

</div>

``` devsite-click-to-copy
const results = await db.pipeline()
  .collection("/users")
  .addFields(
    field("__name__"),
    field("address.city").as("address.city"),
    field("address.state").as("address.state"))
  .execute();
```

</div>

</div>

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
