# Comparison Functions Reference

<div class="devsite-article-body clearfix devsite-no-page-title">

# Comparison Functions Reference

## **Comparison Functions**

|                                                   |                                  |
|---------------------------------------------------|----------------------------------|
| Name                                              | Description                      |
| [`EQUAL`](#equal)                                 | Equality comparison              |
| [`GREATER_THAN`](#greater_than)                   | Greater than comparison          |
| [`GREATER_THAN_OR_EQUAL`](#greater_than_or_equal) | Greater than or equal comparison |
| [`LESS_THAN`](#less_than)                         | Less than comparison             |
| [`LESS_THAN_OR_EQUAL`](#less_than_or_equal)       | Less than or equal comparison    |
| [`NOT_EQUAL`](#not_equal)                         | Not equals comparison            |
| [`CMP`](#cmp)                                     | General comparison               |

### EQUAL

**Syntax:**

<div>

</div>

``` devsite-click-to-copy
equal(x: ANY, y: ANY) -> BOOLEAN
```

**Examples:**

| `x`    | `y`      | `equal(x, y)` |
|:-------|:---------|:--------------|
| 1L     | 1L       | `TRUE`        |
| 1.0    | 1L       | `TRUE`        |
| -1.0   | 1L       | `FALSE`       |
| NaN    | NaN      | `TRUE`        |
| `NULL` | `NULL`   | `TRUE`        |
| `NULL` | `ABSENT` | `FALSE`       |

**Description:**

Returns `TRUE` if `x` and `y` are equal, and `FALSE` otherwise.

<div class="ds-selector-tabs" ds-scope="lang">

<div class="section">

##### Node.js

<div>

</div>

``` devsite-click-to-copy
const result = await db.pipeline()
  .collection("books")
  .select(field("rating").equal(5).as("hasPerfectRating"))
  .execute();test.firestore.js
```

</div>

<div class="section">

### <span class="two-line-tab"><span tab-label="modular API"></span>Web</span>

<div>

</div>

``` devsite-click-to-copy
const result = await execute(db.pipeline()
  .collection("books")
  .select(field("rating").equal(5).as("hasPerfectRating"))
);test.firestore.js
```

</div>

<div class="section">

##### Swift

<div>

</div>

``` devsite-click-to-copy
let result = try await db.pipeline()
  .collection("books")
  .select([Field("rating").equal(5).as("hasPerfectRating")])
  .execute()PipelineSnippets.swift
```

</div>

<div class="section">

##### <span class="two-line-tab">Kotlin <span class="firebase-platform-label">Android</span></span>

<div>

</div>

``` devsite-click-to-copy
val result = db.pipeline()
    .collection("books")
    .select(field("rating").equal(5).alias("hasPerfectRating"))
    .execute()DocSnippets.kt
```

</div>

<div class="section">

##### <span class="two-line-tab">Java <span class="firebase-platform-label">Android</span></span>

<div>

</div>

``` devsite-click-to-copy
Task<Pipeline.Snapshot> result = db.pipeline()
    .collection("books")
    .select(field("rating").equal(5).alias("hasPerfectRating"))
    .execute();DocSnippets.java
```

</div>

<div class="section">

##### Python

<div>

</div>

``` devsite-click-to-copy
from google.cloud.firestore_v1.pipeline_expressions import Field

result = (
    client.pipeline()
    .collection("books")
    .select(Field.of("rating").equal(5).as_("hasPerfectRating"))
    .execute()
)firestore_pipelines.py
```

</div>

<div class="section">

##### Java

<div>

</div>

``` devsite-click-to-copy
Pipeline.Snapshot result =
    firestore
        .pipeline()
        .collection("books")
        .select(equal(field("rating"), 5).as("hasPerfectRating"))
        .execute()
        .get();PipelineSnippets.java
```

</div>

<div class="section">

##### Go

<div>

</div>

``` devsite-click-to-copy
snapshot := client.Pipeline().
 Collection("books").
 Select(firestore.Fields(
     firestore.Equal(firestore.FieldOf("rating"), 5).As("hasPerfectRating"),
 )).
 Execute(ctx)pipeline_snippets_comparison.go
```

</div>

</div>

### GREATER_THAN

**Syntax:**

<div>

</div>

``` devsite-click-to-copy
greater_than(x: ANY, y: ANY) -> BOOLEAN
```

**Description:**

Returns `TRUE` if `x` is greater than `y`, and `FALSE` otherwise.

If `x` and `y` are not comparable, returns `FALSE`.

**Examples:**

| `x`    | `y`    | `greater_than(x, y)` |
|:-------|:-------|:---------------------|
| 1L     | 0.0    | `TRUE`               |
| 1L     | 1L     | `FALSE`              |
| 1L     | 2L     | `FALSE`              |
| "foo"  | 0L     | `FALSE`              |
| 0L     | "foo"  | `FALSE`              |
| NaN    | 0L     | `FALSE`              |
| 0L     | NaN    | `FALSE`              |
| `NULL` | `NULL` | `FALSE`              |

<div class="ds-selector-tabs" ds-scope="lang">

<div class="section">

##### Node.js

<div>

</div>

``` devsite-click-to-copy
const result = await db.pipeline()
  .collection("books")
  .select(field("rating").greaterThan(4).as("hasHighRating"))
  .execute();test.firestore.js
```

</div>

<div class="section">

### <span class="two-line-tab"><span tab-label="modular API"></span>Web</span>

<div>

</div>

``` devsite-click-to-copy
const result = await execute(db.pipeline()
  .collection("books")
  .select(field("rating").greaterThan(4).as("hasHighRating"))
);test.firestore.js
```

</div>

<div class="section">

##### Swift

<div>

</div>

``` devsite-click-to-copy
let result = try await db.pipeline()
  .collection("books")
  .select([Field("rating").greaterThan(4).as("hasHighRating")])
  .execute()PipelineSnippets.swift
```

</div>

<div class="section">

##### <span class="two-line-tab">Kotlin <span class="firebase-platform-label">Android</span></span>

<div>

</div>

``` devsite-click-to-copy
val result = db.pipeline()
    .collection("books")
    .select(field("rating").greaterThan(4).alias("hasHighRating"))
    .execute()DocSnippets.kt
```

</div>

<div class="section">

##### <span class="two-line-tab">Java <span class="firebase-platform-label">Android</span></span>

<div>

</div>

``` devsite-click-to-copy
Task<Pipeline.Snapshot> result = db.pipeline()
    .collection("books")
    .select(field("rating").greaterThan(4).alias("hasHighRating"))
    .execute();DocSnippets.java
```

</div>

<div class="section">

##### Python

<div>

</div>

``` devsite-click-to-copy
from google.cloud.firestore_v1.pipeline_expressions import Field

result = (
    client.pipeline()
    .collection("books")
    .select(Field.of("rating").greater_than(4).as_("hasHighRating"))
    .execute()
)firestore_pipelines.py
```

</div>

<div class="section">

##### Java

<div>

</div>

``` devsite-click-to-copy
Pipeline.Snapshot result =
    firestore
        .pipeline()
        .collection("books")
        .select(greaterThan(field("rating"), 4).as("hasHighRating"))
        .execute()
        .get();PipelineSnippets.java
```

</div>

<div class="section">

##### Go

<div>

</div>

``` devsite-click-to-copy
snapshot := client.Pipeline().
 Collection("books").
 Select(firestore.Fields(
     firestore.GreaterThan(firestore.FieldOf("rating"), 4).As("hasHighRating"),
 )).
 Execute(ctx)pipeline_snippets_comparison.go
```

</div>

</div>

### GREATER_THAN_OR_EQUAL

**Syntax:**

<div>

</div>

``` devsite-click-to-copy
greater_than_or_equal(x: ANY, y: ANY) -> BOOLEAN
```

**Description:**

Returns `TRUE` if `x` is greater than or equal to `y`, and `FALSE` otherwise.

If `x` and `y` are not comparable, returns `FALSE`.

**Examples:**

| `x`    | `y`    | `greater_than_or_equal(x, y)` |
|:-------|:-------|:------------------------------|
| 1L     | 0.0    | `TRUE`                        |
| 1L     | 1L     | `TRUE`                        |
| 1L     | 2L     | `FALSE`                       |
| "foo"  | 0L     | `FALSE`                       |
| 0L     | "foo"  | `FALSE`                       |
| NaN    | 0L     | `FALSE`                       |
| 0L     | NaN    | `FALSE`                       |
| `NULL` | `NULL` | `TRUE`                        |

<div class="ds-selector-tabs" ds-scope="lang">

<div class="section">

##### Node.js

<div>

</div>

``` devsite-click-to-copy
const result = await db.pipeline()
  .collection("books")
  .select(field("published").greaterThanOrEqual(1900).as("publishedIn20thCentury"))
  .execute();test.firestore.js
```

</div>

<div class="section">

### <span class="two-line-tab"><span tab-label="modular API"></span>Web</span>

<div>

</div>

``` devsite-click-to-copy
const result = await execute(db.pipeline()
  .collection("books")
  .select(field("published").greaterThanOrEqual(1900).as("publishedIn20thCentury"))
);test.firestore.js
```

</div>

<div class="section">

##### Swift

<div>

</div>

``` devsite-click-to-copy
let result = try await db.pipeline()
  .collection("books")
  .select([Field("published").greaterThanOrEqual(1900).as("publishedIn20thCentury")])
  .execute()PipelineSnippets.swift
```

</div>

<div class="section">

##### <span class="two-line-tab">Kotlin <span class="firebase-platform-label">Android</span></span>

<div>

</div>

``` devsite-click-to-copy
val result = db.pipeline()
    .collection("books")
    .select(field("published").greaterThanOrEqual(1900).alias("publishedIn20thCentury"))
    .execute()DocSnippets.kt
```

</div>

<div class="section">

##### <span class="two-line-tab">Java <span class="firebase-platform-label">Android</span></span>

<div>

</div>

``` devsite-click-to-copy
Task<Pipeline.Snapshot> result = db.pipeline()
    .collection("books")
    .select(field("published").greaterThanOrEqual(1900).alias("publishedIn20thCentury"))
    .execute();DocSnippets.java
```

</div>

<div class="section">

##### Python

<div>

</div>

``` devsite-click-to-copy
from google.cloud.firestore_v1.pipeline_expressions import Field

result = (
    client.pipeline()
    .collection("books")
    .select(
        Field.of("published")
        .greater_than_or_equal(1900)
        .as_("publishedIn20thCentury")
    )
    .execute()
)firestore_pipelines.py
```

</div>

<div class="section">

##### Java

<div>

</div>

``` devsite-click-to-copy
Pipeline.Snapshot result =
    firestore
        .pipeline()
        .collection("books")
        .select(greaterThanOrEqual(field("published"), 1900).as("publishedIn20thCentury"))
        .execute()
        .get();PipelineSnippets.java
```

</div>

<div class="section">

##### Go

<div>

</div>

``` devsite-click-to-copy
snapshot := client.Pipeline().
 Collection("books").
 Select(firestore.Fields(
     firestore.GreaterThanOrEqual(firestore.FieldOf("published"), 1900).As("publishedIn20thCentury"),
 )).
 Execute(ctx)pipeline_snippets_comparison.go
```

</div>

</div>

### LESS_THAN

**Syntax:**

<div>

</div>

``` devsite-click-to-copy
less_than(x: ANY, y: ANY) -> BOOLEAN
```

**Description:**

Returns `TRUE` if `x` is less than `y`, and `FALSE` otherwise.

If `x` and `y` are not comparable, returns `FALSE`.

**Examples:**

| `x`    | `y`    | `less_than(x, y)` |
|:-------|:-------|:------------------|
| 1L     | 0.0    | `FALSE`           |
| 1L     | 1L     | `FALSE`           |
| 1L     | 2L     | `TRUE`            |
| "foo"  | 0L     | `FALSE`           |
| 0L     | "foo"  | `FALSE`           |
| NaN    | 0L     | `FALSE`           |
| 0L     | NaN    | `FALSE`           |
| `NULL` | `NULL` | `FALSE`           |

<div class="ds-selector-tabs" ds-scope="lang">

<div class="section">

##### Node.js

<div>

</div>

``` devsite-click-to-copy
const result = await db.pipeline()
  .collection("books")
  .select(field("published").lessThan(1923).as("isPublicDomainProbably"))
  .execute();test.firestore.js
```

</div>

<div class="section">

### <span class="two-line-tab"><span tab-label="modular API"></span>Web</span>

<div>

</div>

``` devsite-click-to-copy
const result = await execute(db.pipeline()
  .collection("books")
  .select(field("published").lessThan(1923).as("isPublicDomainProbably"))
);test.firestore.js
```

</div>

<div class="section">

##### Swift

<div>

</div>

``` devsite-click-to-copy
let result = try await db.pipeline()
  .collection("books")
  .select([Field("published").lessThan(1923).as("isPublicDomainProbably")])
  .execute()PipelineSnippets.swift
```

</div>

<div class="section">

##### <span class="two-line-tab">Kotlin <span class="firebase-platform-label">Android</span></span>

<div>

</div>

``` devsite-click-to-copy
val result = db.pipeline()
    .collection("books")
    .select(field("published").lessThan(1923).alias("isPublicDomainProbably"))
    .execute()DocSnippets.kt
```

</div>

<div class="section">

##### <span class="two-line-tab">Java <span class="firebase-platform-label">Android</span></span>

<div>

</div>

``` devsite-click-to-copy
Task<Pipeline.Snapshot> result = db.pipeline()
    .collection("books")
    .select(field("published").lessThan(1923).alias("isPublicDomainProbably"))
    .execute();DocSnippets.java
```

</div>

<div class="section">

##### Python

<div>

</div>

``` devsite-click-to-copy
from google.cloud.firestore_v1.pipeline_expressions import Field

result = (
    client.pipeline()
    .collection("books")
    .select(Field.of("published").less_than(1923).as_("isPublicDomainProbably"))
    .execute()
)firestore_pipelines.py
```

</div>

<div class="section">

##### Java

<div>

</div>

``` devsite-click-to-copy
Pipeline.Snapshot result =
    firestore
        .pipeline()
        .collection("books")
        .select(lessThan(field("published"), 1923).as("isPublicDomainProbably"))
        .execute()
        .get();PipelineSnippets.java
```

</div>

<div class="section">

##### Go

<div>

</div>

``` devsite-click-to-copy
snapshot := client.Pipeline().
 Collection("books").
 Select(firestore.Fields(
     firestore.LessThan(firestore.FieldOf("published"), 1923).As("isPublicDomainProbably"),
 )).
 Execute(ctx)pipeline_snippets_comparison.go
```

</div>

</div>

### LESS_THAN_OR_EQUAL

**Syntax:**

<div>

</div>

``` devsite-click-to-copy
less_than_or_equal(x: ANY, y: ANY) -> BOOLEAN
```

**Description:**

Returns `TRUE` if `x` is less than or equal to `y`, and `FALSE` otherwise.

If `x` and `y` are not comparable, returns `FALSE`.

**Examples:**

| `x`    | `y`    | `less_than(x, y)` |
|:-------|:-------|:------------------|
| 1L     | 0.0    | `FALSE`           |
| 1L     | 1L     | `TRUE`            |
| 1L     | 2L     | `TRUE`            |
| "foo"  | 0L     | `FALSE`           |
| 0L     | "foo"  | `FALSE`           |
| NaN    | 0L     | `FALSE`           |
| 0L     | NaN    | `FALSE`           |
| `NULL` | `NULL` | `TRUE`            |

<div class="ds-selector-tabs" ds-scope="lang">

<div class="section">

##### Node.js

<div>

</div>

``` devsite-click-to-copy
const result = await db.pipeline()
  .collection("books")
  .select(field("rating").lessThanOrEqual(2).as("hasBadRating"))
  .execute();test.firestore.js
```

</div>

<div class="section">

### <span class="two-line-tab"><span tab-label="modular API"></span>Web</span>

<div>

</div>

``` devsite-click-to-copy
const result = await execute(db.pipeline()
  .collection("books")
  .select(field("rating").lessThanOrEqual(2).as("hasBadRating"))
);test.firestore.js
```

</div>

<div class="section">

##### Swift

<div>

</div>

``` devsite-click-to-copy
let result = try await db.pipeline()
  .collection("books")
  .select([Field("rating").lessThanOrEqual(2).as("hasBadRating")])
  .execute()PipelineSnippets.swift
```

</div>

<div class="section">

##### <span class="two-line-tab">Kotlin <span class="firebase-platform-label">Android</span></span>

<div>

</div>

``` devsite-click-to-copy
val result = db.pipeline()
    .collection("books")
    .select(field("rating").lessThanOrEqual(2).alias("hasBadRating"))
    .execute()DocSnippets.kt
```

</div>

<div class="section">

##### <span class="two-line-tab">Java <span class="firebase-platform-label">Android</span></span>

<div>

</div>

``` devsite-click-to-copy
Task<Pipeline.Snapshot> result = db.pipeline()
    .collection("books")
    .select(field("rating").lessThanOrEqual(2).alias("hasBadRating"))
    .execute();DocSnippets.java
```

</div>

<div class="section">

##### Python

<div>

</div>

``` devsite-click-to-copy
from google.cloud.firestore_v1.pipeline_expressions import Field

result = (
    client.pipeline()
    .collection("books")
    .select(Field.of("rating").less_than_or_equal(2).as_("hasBadRating"))
    .execute()
)firestore_pipelines.py
```

</div>

<div class="section">

##### Java

<div>

</div>

``` devsite-click-to-copy
Pipeline.Snapshot result =
    firestore
        .pipeline()
        .collection("books")
        .select(lessThanOrEqual(field("rating"), 2).as("hasBadRating"))
        .execute()
        .get();PipelineSnippets.java
```

</div>

<div class="section">

##### Go

<div>

</div>

``` devsite-click-to-copy
snapshot := client.Pipeline().
 Collection("books").
 Select(firestore.Fields(
     firestore.LessThanOrEqual(firestore.FieldOf("rating"), 2).As("hasBadRating"),
 )).
 Execute(ctx)pipeline_snippets_comparison.go
```

</div>

</div>

### NOT_EQUAL

**Syntax:**

<div>

</div>

``` devsite-click-to-copy
not_equal(x: ANY, y: ANY) -> BOOLEAN
```

**Description:**

Returns `TRUE` if `x` is not equal to `y`, and `FALSE` otherwise.

**Examples:**

| `x`    | `y`      | `not_equal(x, y)` |
|:-------|:---------|:------------------|
| 1L     | 1L       | `FALSE`           |
| 1.0    | 1L       | `FALSE`           |
| -1.0   | 1L       | `TRUE`            |
| NaN    | 0L       | `TRUE`            |
| NaN    | NaN      | `FALSE`           |
| `NULL` | `NULL`   | `FALSE`           |
| `NULL` | `ABSENT` | `TRUE`            |

<div class="ds-selector-tabs" ds-scope="lang">

<div class="section">

##### Node.js

<div>

</div>

``` devsite-click-to-copy
const result = await db.pipeline()
  .collection("books")
  .select(field("title").notEqual("1984").as("not1984"))
  .execute();test.firestore.js
```

</div>

<div class="section">

### <span class="two-line-tab"><span tab-label="modular API"></span>Web</span>

<div>

</div>

``` devsite-click-to-copy
const result = await execute(db.pipeline()
  .collection("books")
  .select(field("title").notEqual("1984").as("not1984"))
);test.firestore.js
```

</div>

<div class="section">

##### Swift

<div>

</div>

``` devsite-click-to-copy
let result = try await db.pipeline()
  .collection("books")
  .select([Field("title").notEqual("1984").as("not1984")])
  .execute()PipelineSnippets.swift
```

</div>

<div class="section">

##### <span class="two-line-tab">Kotlin <span class="firebase-platform-label">Android</span></span>

<div>

</div>

``` devsite-click-to-copy
val result = db.pipeline()
    .collection("books")
    .select(field("title").notEqual("1984").alias("not1984"))
    .execute()DocSnippets.kt
```

</div>

<div class="section">

##### <span class="two-line-tab">Java <span class="firebase-platform-label">Android</span></span>

<div>

</div>

``` devsite-click-to-copy
Task<Pipeline.Snapshot> result = db.pipeline()
    .collection("books")
    .select(field("title").notEqual("1984").alias("not1984"))
    .execute();DocSnippets.java
```

</div>

<div class="section">

##### Python

<div>

</div>

``` devsite-click-to-copy
from google.cloud.firestore_v1.pipeline_expressions import Field

result = (
    client.pipeline()
    .collection("books")
    .select(Field.of("title").not_equal("1984").as_("not1984"))
    .execute()
)firestore_pipelines.py
```

</div>

<div class="section">

##### Java

<div>

</div>

``` devsite-click-to-copy
Pipeline.Snapshot result =
    firestore
        .pipeline()
        .collection("books")
        .select(notEqual(field("title"), "1984").as("not1984"))
        .execute()
        .get();PipelineSnippets.java
```

</div>

<div class="section">

##### Go

<div>

</div>

``` devsite-click-to-copy
snapshot := client.Pipeline().
 Collection("books").
 Select(firestore.Fields(
     firestore.NotEqual(firestore.FieldOf("title"), "1984").As("not1984"),
 )).
 Execute(ctx)pipeline_snippets_comparison.go
```

</div>

</div>

### CMP

**Syntax:**

<div>

</div>

``` devsite-click-to-copy
cmp(x: ANY, y: ANY) -> Int64
```

**Description:**

Compares `x` & `y`, returning:

- `1L` if `x` is greater than `y`.
- `-1L` if `x` is less than `y`.
- `0L` otherwise.

Unlike other comparison functions, the `cmp(...)` function works across types, following the same ordering used in the `sort(...)` stage. See [value type order](/firestore/native/docs/concepts/data-types) for how values are ordered across types.

**Examples:**

| `x`    | `y`      | `cmp(x, y)` |
|:-------|:---------|:------------|
| 1L     | 1L       | 0L          |
| 1.0    | 1L       | 0L          |
| -1.0   | 1L       | -1L         |
| 42.5D  | "foo"    | -1L         |
| `NULL` | `NULL`   | 0L          |
| `NULL` | `ABSENT` | 0L          |

## What's next

- See the [Pipeline Queries overview](/firestore/docs/pipeline/overview)

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
