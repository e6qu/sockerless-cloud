# Cancel the import and export of data

<div class="devsite-article-body clearfix">

<div class="nocontent" style="font-size:medium; margin-bottom:40px; border-top:1px solid black;">

<div style="float:right">

<a href="/sql/docs/mysql/import-export/cancel-import-export" data-track-type="sqlSwitcher" data-track-name="mysqlLink" title="View this page for the MySQL database engine">MySQL</a> <span style="color:light-gray">  \|  </span><span style="font-weight:bold">PostgreSQL</span> <span style="color:light-gray">  \|  </span><a href="/sql/docs/sqlserver/import-export/cancel-import-export" data-track-type="sqlSwitcher" data-track-name="sqlServerLink" title="View this page for the SQL Server database engine">SQL Server</a>

</div>

</div>

This page describes how to cancel the import and export of data into Cloud SQL instances. This data is contained in either [SQL dump files](/sql/docs/postgres/import-export/import-export-sql) or [CSV files](/sql/docs/postgres/import-export/import-export-csv).

## Before you begin

To cancel the import and export of data, you need the ID of the import or export operation. You need to specify this ID in the `gcloud` or REST API command so that Cloud SQL knows which operation to cancel.

The operation ID is returned in the `name` field of the response. To obtain this ID, see [Export and import using SQL dump files](/sql/docs/postgres/import-export/import-export-sql).

You can also find the operation ID by making an [`operations.list`](/sql/docs/postgres/admin-api/rest/v1beta4/operations/list) call on the Cloud SQL instance.

## Cancel the import or export operation

You can use `gcloud` or REST API commands to cancel an import or export operation.

<div id="export-database" class="ds-selector-tabs" ds-scope="code-sample">

<div class="section">

### gcloud

Use the `gcloud sql operations cancel` command to cancel the operation.

<div>

</div>

``` devsite-click-to-copy
gcloud sql operations cancel operation-ID
```

Replace the `operation-ID` variable with the ID of the operation. For more information, see [Before you begin](#before-you-begin).

</div>

<div class="section">

### REST v1

Before using any of the request data, make the following replacements:

- `project-ID`: The project ID.
- `operation-ID`: The ID of the import or export operation. For more information, see [Before you begin](/sql/docs/postgres/import-export/cancel-import-export#before-you-begin).

HTTP method and URL:

<div class="section">

<div>

</div>

``` devsite-click-to-copy
POST https://sqladmin.googleapis.com/v1/projects/project-ID/operations/operation-ID/cancel
```

</div>

To send your request, expand one of these options:

<div class="section expandable">

#### curl (Linux, macOS, or Cloud Shell)

**Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).

Execute the following command:

<div class="section">

<div>

</div>

``` devsite-click-to-copy
curl -X POST \
     -H "Authorization: Bearer $(gcloud auth print-access-token)" \
     -H "Content-Type: application/json; charset=utf-8" \
     -d "" \
     "https://sqladmin.googleapis.com/v1/projects/project-ID/operations/operation-ID/cancel"
```

</div>

</div>

<div class="section expandable">

#### PowerShell (Windows)

**Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).

Execute the following command:

<div class="section">

<div>

</div>

``` devsite-click-to-copy
$cred = gcloud auth print-access-token
$headers = @{ "Authorization" = "Bearer $cred" }

Invoke-WebRequest `
    -Method POST `
    -Headers $headers `
    -Uri "https://sqladmin.googleapis.com/v1/projects/project-ID/operations/operation-ID/cancel" | Select-Object -Expand Content
```

</div>

</div>

You should receive a JSON response similar to the following:

<div class="section expandable">

#### Response

<div>

</div>

``` readonly
{}
```

</div>

This REST API call doesn't return any response. For more information about checking the cancellation status of the import or export operation, see [Check the cancelled status](#check-canceled-status).

</div>

<div class="section">

### REST v1beta4

Before using any of the request data, make the following replacements:

- `project-ID`: The project ID.
- `operation-ID`: The ID of the import or export operation. For more information, see [Before you begin](/sql/docs/postgres/import-export/cancel-import-export#before-you-begin).

HTTP method and URL:

<div class="section">

<div>

</div>

``` devsite-click-to-copy
POST https://sqladmin.googleapis.com/v1beta4/projects/project-ID/operations/operation-ID/cancel
```

</div>

To send your request, expand one of these options:

<div class="section expandable">

#### curl (Linux, macOS, or Cloud Shell)

**Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).

Execute the following command:

<div class="section">

<div>

</div>

``` devsite-click-to-copy
curl -X POST \
     -H "Authorization: Bearer $(gcloud auth print-access-token)" \
     -H "Content-Type: application/json; charset=utf-8" \
     -d "" \
     "https://sqladmin.googleapis.com/v1beta4/projects/project-ID/operations/operation-ID/cancel"
```

</div>

</div>

<div class="section expandable">

#### PowerShell (Windows)

**Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).

Execute the following command:

<div class="section">

<div>

</div>

``` devsite-click-to-copy
$cred = gcloud auth print-access-token
$headers = @{ "Authorization" = "Bearer $cred" }

Invoke-WebRequest `
    -Method POST `
    -Headers $headers `
    -Uri "https://sqladmin.googleapis.com/v1beta4/projects/project-ID/operations/operation-ID/cancel" | Select-Object -Expand Content
```

</div>

</div>

You should receive a JSON response similar to the following:

<div class="section expandable">

#### Response

<div>

</div>

``` readonly
{}
```

</div>

This REST API call doesn't return any response. For more information about checking the cancellation status of the import or export operation, see [Check the cancelled status](#check-canceled-status).

</div>

</div>

## Check the cancelled status

You can use `gcloud` or REST API commands to check the status of a cancelled import or export operation.

<div id="export-database" class="ds-selector-tabs" ds-scope="code-sample">

<div class="section">

### gcloud

Use the ` `[`gcloud sql operations describe`](/sdk/gcloud/reference/sql/operations/describe)` ``command to check the status of the cancelled operation.`` `

<div>

</div>

``` devsite-click-to-copy
gcloud sql operations describe operation-ID
```

Replace the `operation-ID` variable with the ID of the cancelled operation. For more information, see [Before you begin](#before-you-begin).

</div>

<div class="section">

### REST v1

Before using any of the request data, make the following replacements:

- `project-ID`: The project ID.
- `operation-ID`: The ID of the import or export operation. For more information, see [Before you begin](/sql/docs/postgres/import-export/cancel-import-export#before-you-begin).

HTTP method and URL:

<div class="section">

<div>

</div>

``` devsite-click-to-copy
GET https://sqladmin.googleapis.com/v1/projects/project-ID/operations/operation-ID
```

</div>

To send your request, expand one of these options:

<div class="section expandable">

#### curl (Linux, macOS, or Cloud Shell)

**Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).

Execute the following command:

<div class="section">

<div>

</div>

``` devsite-click-to-copy
curl -X GET \
     -H "Authorization: Bearer $(gcloud auth print-access-token)" \
     "https://sqladmin.googleapis.com/v1/projects/project-ID/operations/operation-ID"
```

</div>

</div>

<div class="section expandable">

#### PowerShell (Windows)

**Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).

Execute the following command:

<div class="section">

<div>

</div>

``` devsite-click-to-copy
$cred = gcloud auth print-access-token
$headers = @{ "Authorization" = "Bearer $cred" }

Invoke-WebRequest `
    -Method GET `
    -Headers $headers `
    -Uri "https://sqladmin.googleapis.com/v1/projects/project-ID/operations/operation-ID" | Select-Object -Expand Content
```

</div>

</div>

You should receive a JSON response similar to the following:

<div class="section expandable">

#### Response

<div>

</div>

``` readonly
{
  "kind": "sql#operation",
"targetLink": "https://sqladmin.googleapis.com/v1/projects/project-ID",
  "status": "DONE",
  "user": "user@example.com",
  "insertTime": "2022-11-08T22:12:58.199Z",
  "startTime": "2022-11-08T22:13:04.798Z",
  "endTime": "2022-11-08T22:13:45.862Z",
  "error": {
    "kind": "sql#operationErrors",
    "errors": [
      {
        "kind": "sql#operationError",
        "code": "CANCEL_SUCCESSFUL",
        "message": "Operation successfully cancelled"
      }
    ]
  },
  "operationType": "EXPORT",
  "exportContext": {
    "uri": "gs://replica-bucket/source-database.sql",
    "kind": "sql#exportContext",
    "sqlExportOptions": {
      "schemaOnly": false,
      "mysqlExportOptions": {
        "masterData": 0
      }
    },
    "fileType": "SQL"
  },
  "name": "operation-ID",
  "targetId": "cloud-sql-instance-display-name",
  "selfLink": "https://sqladmin.googleapis.com/v1/projects/project-ID/operations/operation-ID",
  "targetProject": "project-ID",
  "instanceUid": "cloud-sql-instance-ID"
}
```

</div>

</div>

<div class="section">

### REST v1beta4

Before using any of the request data, make the following replacements:

- `project-ID`: The project ID.
- `operation-ID`: The ID of the import or export operation. For more information, see [Before you begin](/sql/docs/postgres/import-export/cancel-import-export#before-you-begin).

HTTP method and URL:

<div class="section">

<div>

</div>

``` devsite-click-to-copy
GET https://sqladmin.googleapis.com/v1beta4/projects/project-ID/operations/operation-ID
```

</div>

To send your request, expand one of these options:

<div class="section expandable">

#### curl (Linux, macOS, or Cloud Shell)

**Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).

Execute the following command:

<div class="section">

<div>

</div>

``` devsite-click-to-copy
curl -X GET \
     -H "Authorization: Bearer $(gcloud auth print-access-token)" \
     "https://sqladmin.googleapis.com/v1beta4/projects/project-ID/operations/operation-ID"
```

</div>

</div>

<div class="section expandable">

#### PowerShell (Windows)

**Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).

Execute the following command:

<div class="section">

<div>

</div>

``` devsite-click-to-copy
$cred = gcloud auth print-access-token
$headers = @{ "Authorization" = "Bearer $cred" }

Invoke-WebRequest `
    -Method GET `
    -Headers $headers `
    -Uri "https://sqladmin.googleapis.com/v1beta4/projects/project-ID/operations/operation-ID" | Select-Object -Expand Content
```

</div>

</div>

You should receive a JSON response similar to the following:

<div class="section expandable">

#### Response

<div>

</div>

``` readonly
{
  "kind": "sql#operation",
"targetLink": "https://sqladmin.googleapis.com/v1beta4/projects/project-ID",
  "status": "DONE",
  "user": "user@example.com",
  "insertTime": "2022-11-08T22:12:58.199Z",
  "startTime": "2022-11-08T22:13:04.798Z",
  "endTime": "2022-11-08T22:13:45.862Z",
  "error": {
    "kind": "sql#operationErrors",
    "errors": [
      {
        "kind": "sql#operationError",
        "code": "CANCEL_SUCCESSFUL",
        "message": "Operation successfully cancelled"
      }
    ]
  },
  "operationType": "EXPORT",
  "exportContext": {
    "uri": "gs://replica-bucket/source-database.sql",
    "kind": "sql#exportContext",
    "sqlExportOptions": {
      "schemaOnly": false,
      "mysqlExportOptions": {
        "masterData": 0
      }
    },
    "fileType": "SQL"
  },
  "name": "operation-ID",
  "targetId": "cloud-sql-instance-display-name",
  "selfLink": "https://sqladmin.googleapis.com/v1beta4/projects/project-ID/operations/operation-ID",
  "targetProject": "project-ID",
  "instanceUid": "cloud-sql-instance-ID"
}
```

</div>

</div>

</div>

## Troubleshoot

Issue

</div>

Troubleshooting

Error message: `You can't cancel operation [operation-ID] because this operation isn't in progress.`

You're trying to cancel an import or export operation that's completed, failed, or cancelled. If the operation is running, you can cancel it.

Error message: `You can't cancel operation [operation-ID] because Cloud SQL doesn't support the cancellation of an [operation-type] operation.`

Cloud SQL doesn't support the cancellation of the operation because it has an [operation type](/sql/docs/postgres/admin-api/rest/v1beta4/operations#sqloperationtype) other than `IMPORT` or `EXPORT`.

Error message: `The [operation-type] operation isn't cancelled. Wait and retry in a few seconds.`

Cloud SQL can't cancel the import or export operation at this time. Try again in a few seconds. If the problem persists, contact [Google Cloud Support](/support).

## What's next

- Learn more about <a href="/sql/docs/postgres/import-export" target="_blank">best practices for importing and exporting data</a>.
- Learn how to <a href="/sql/docs/postgres/import-export/import-export-sql" target="_blank">export and import data into Cloud SQL instances using SQL dump files</a>.
- Learn how to <a href="/sql/docs/postgres/import-export/checking-status-import-export" target="_blank">check the status of import and export operations</a>.
- <a href="/sql/docs/postgres/known-issues#import-export" target="_blank">Known issues for imports and exports</a>.

Send feedback

<div class="devsite-floating-action-buttons">

</div>
