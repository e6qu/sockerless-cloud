# Collection (Input Stage)

<div class="devsite-article-body clearfix devsite-no-page-title">

# Collection (Input Stage)

## Description

Returns all documents from a given collection. The collection can be nested.

## Examples

<div class="ds-selector-tabs" ds-scope="lang">

<div class="section">

### <span class="two-line-tab"><span tab-label="modular API"></span>Web</span>

<div>

</div>

``` devsite-click-to-copy
const results = await execute(db.pipeline()
  .collection("users/bob/games")
  .sort(field("name").ascending())
  );test.firestore.js
```

</div>

<div class="section">

##### Swift

<div>

</div>

``` devsite-click-to-copy
let results = try await db.pipeline()
  .collection("users/bob/games")
  .sort([Field("name").ascending()])
  .execute()PipelineSnippets.swift
```

</div>

<div class="section">

##### <span class="two-line-tab">Kotlin <span class="firebase-platform-label">Android</span></span>

<div>

</div>

``` devsite-click-to-copy
val results = db.pipeline()
    .collection("users/bob/games")
    .sort(field("name").ascending())
    .execute()DocSnippets.kt
```

</div>

<div class="section">

##### <span class="two-line-tab">Java <span class="firebase-platform-label">Android</span></span>

<div>

</div>

``` devsite-click-to-copy
Task<Pipeline.Snapshot> results = db.pipeline()
    .collection("users/bob/games")
    .sort(field("name").ascending())
    .execute();DocSnippets.java
```

</div>

<div class="section">

##### Python

<div>

</div>

``` devsite-click-to-copy
from google.cloud.firestore_v1.pipeline_expressions import Field

results = (
    client.pipeline()
    .collection("users/bob/games")
    .sort(Field.of("name").ascending())
    .execute()
)firestore_pipelines.py
```

</div>

<div class="section">

##### Java

<div>

</div>

``` devsite-click-to-copy
Pipeline.Snapshot results =
    firestore
        .pipeline()
        .collection("users/bob/games")
        .sort(ascending(field("name")))
        .execute()
        .get();PipelineSnippets.java
```

</div>

<div class="section">

##### Go

<div>

</div>

``` devsite-click-to-copy
snapshot := client.Pipeline().
 Collection("users/bob/games").
 Sort(firestore.Orders(firestore.Ascending(firestore.FieldOf("name")))).
 Execute(ctx)pipeline_snippets_general.go
```

</div>

</div>

## Behavior

In order to use the `collection(...)` stage, it must appear as the first stage in the pipeline (or sub-pipeline).

The order of documents returned from the `collection(...)` stage is unstable and cannot be relied upon. Firestore will attempt to execute the query in the most efficient way possible, which can change the order depending on the schema or index configuration. A subsequent [`sort(...)`](/firestore/native/docs/pipeline/stages/transformation/sort) stage can be used to obtain a deterministic ordering.

For example, for the following documents:

<div>

<div class="section">

### Node.js

<div>

</div>

``` devsite-click-to-copy
await db.collection("cities").doc("SF").set({name: "San Francsico", state: "California"});
await db.collection("cities").doc("NYC").set({name: "New York City", state: "New York"});
await db.collection("cities").doc("CHI").set({name: "Chicago", state: "Illinois"});
await db.collection("states").doc("CA").set({name: "California"});
```

</div>

</div>

The `collection` stage can be used to retrieve all cities in the `cities` collection and then sort them in ascending order of name.

<div>

<div class="section">

### Node.js

<div>

</div>

``` devsite-click-to-copy
const results = await db.pipeline()
  .collection("/cities")
  .sort(field("name").ascending())
  .execute();
```

</div>

</div>

This query produces the following documents:

<div>

</div>

``` devsite-click-to-copy
  { name: "Chicago", state: "Illinois" }
  { name: "New York City", state: "New York" }
  { name: "San Francisco", state: "California" }
```

### Subcollections

The `collection(...)` stage can also be used to target collections under a specific parent by providing the full path to the stage.

For example, for the following documents:

<div>

<div class="section">

### Node.js

<div>

</div>

``` devsite-click-to-copy
await db.collection("cities/SF/departments").doc("building").set({name: "SF Building Deparment", employees: 750});
await db.collection("cities/NY/departments").doc("building").set({name: "NY Building Deparment", employees: 1000});
await db.collection("cities/CHI/departments").doc("building").set({name: "CHI Building Deparment", employees: 900});
await db.collection("cities/NY/departments").doc("finance").set({name: "NY Finance Deparment", employees: 1200});
```

</div>

</div>

For this example, we only want the departments of New York city.

<div>

<div class="section">

### Node.js

<div>

</div>

``` devsite-click-to-copy
const results = await db.pipeline()
  .collection("/cities/NY/departments")
  .sort(field("employees").ascending())
  .execute();
```

</div>

</div>

This will return all departments under the full path `cities/NY/departments`.

<div>

</div>

``` devsite-click-to-copy
  { name: "NY Building Deparment", employees: 1000 }
  { name: "NY Finance Deparment", employees: 1200 }
```

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
