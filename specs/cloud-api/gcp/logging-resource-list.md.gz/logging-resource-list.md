<div class="devsite-article-meta nocontent" role="navigation" nosnippet="">

- <a href="https://docs.cloud.google.com/" class="devsite-breadcrumb-link gc-analytics-event" data-category="Site-Wide Custom Events" data-label="Breadcrumbs" data-value="1" data-track-type="globalNav" data-track-name="breadcrumb" data-track-metadata-position="1" data-track-metadata-eventdetail="Google Cloud Documentation">Home</a>

- <div class="devsite-breadcrumb-guillemet material-icons" aria-hidden="true">

  </div>

  <a href="https://docs.cloud.google.com/docs" class="devsite-breadcrumb-link gc-analytics-event" data-category="Site-Wide Custom Events" data-label="Breadcrumbs" data-value="2" data-track-type="globalNav" data-track-name="breadcrumb" data-track-metadata-position="2" data-track-metadata-eventdetail="Documentation">Documentation</a>

- <div class="devsite-breadcrumb-guillemet material-icons" aria-hidden="true">

  </div>

  <a href="https://docs.cloud.google.com/docs/observability" class="devsite-breadcrumb-link gc-analytics-event" data-category="Site-Wide Custom Events" data-label="Breadcrumbs" data-value="3" data-track-type="globalNav" data-track-name="breadcrumb" data-track-metadata-position="3" data-track-metadata-eventdetail="Observability and monitoring">Observability</a>

- <div class="devsite-breadcrumb-guillemet material-icons" aria-hidden="true">

  </div>

  <a href="https://docs.cloud.google.com/logging/docs" class="devsite-breadcrumb-link gc-analytics-event" data-category="Site-Wide Custom Events" data-label="Breadcrumbs" data-value="4" data-track-type="globalNav" data-track-name="breadcrumb" data-track-metadata-position="4" data-track-metadata-eventdetail="Cloud Logging">Cloud Logging</a>

- <div class="devsite-breadcrumb-guillemet material-icons" aria-hidden="true">

  </div>

  <a href="https://docs.cloud.google.com/logging/docs/apis" class="devsite-breadcrumb-link gc-analytics-event" data-category="Site-Wide Custom Events" data-label="Breadcrumbs" data-value="5" data-track-type="globalNav" data-track-name="breadcrumb" data-track-metadata-position="5" data-track-metadata-eventdetail="">Reference</a>

</div>

Send feedback

# Monitored resources and services <span slot="popout-heading"> Stay organized with collections </span> <span slot="popout-contents"> Save and categorize content based on your preferences. </span>

<div class="devsite-article-body clearfix">

This page provides information about the Google Cloud resource types and services that Cloud Logging uses. This information can help you understand [Google Cloud platform logs](/logging/docs/api/platform-logs), which are service-specific logs that can help you debug and troubleshoot issues as well as understand the Google Cloud services you're using.

If you use BindPlane to write your on-premise and hybrid cloud logs, then you can find these logs under the resource type `generic_node`.

## Monitored resource types

The following table lists all the Cloud Logging monitored resource types, their labels, and descriptive information. The information shown for each monitored resource type is defined in the [`MonitoredResourceDescriptor` object](/logging/docs/reference/v2/rest/v2/monitoredResourceDescriptors/list#MonitoredResourceDescriptor). This table is regenerated frequently, and the timestamp is shown at the end of the table.

When writing log entries, `MonitoredResourceDescriptor.type` has to be one of the following types. You can't create your own monitored resource types; these are created by Google Cloud. For non-Google Cloud resources, we recommend you can use the generic types `generic_node` or `generic_task`.

The list of monitored resource types in Logging might not match [list of monitored resource types in Monitoring](/monitoring/api/resources).

<table class="fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="40%">Resource type<br />
Display name</th>
<th>Description<br />
Labels</th>
</tr>
</thead>
<tbody>
<tr id="tag_abuseevent.googleapis.com/Location" class="odd">
<td><code translate="no" dir="ltr">abuseevent.googleapis.com/Location</code><br />
Abuse Event</td>
<td>A GCP resource container associated with an abuse event.<br />
<code translate="no" dir="ltr">resource_container</code>: The GCP resource identifier associated with the abuse event.<br />
<code translate="no" dir="ltr">location</code>: The location where the abuse event was observed.</td>
</tr>
<tr id="tag_aiplatform.googleapis.com/DeploymentResourcePool" class="even">
<td><code translate="no" dir="ltr">aiplatform.googleapis.com/DeploymentResourcePool</code><br />
Vertex AI Deployment Resource Pool</td>
<td>A Vertex AI Deployment Resource Pool.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP Project owning the Deployment Resource Pool.<br />
<code translate="no" dir="ltr">location</code>: The region in which the service is running.<br />
<code translate="no" dir="ltr">deployment_resource_pool_id</code>: The ID of the Deployment Resource Pool.</td>
</tr>
<tr id="tag_aiplatform.googleapis.com/Endpoint" class="odd">
<td><code translate="no" dir="ltr">aiplatform.googleapis.com/Endpoint</code><br />
Vertex AI Endpoint</td>
<td>A Vertex AI API Endpoint where Models are deployed into it.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP Project owning the Endpoint.<br />
<code translate="no" dir="ltr">location</code>: The region in which the service is running.<br />
<code translate="no" dir="ltr">endpoint_id</code>: The ID of the Endpoint.</td>
</tr>
<tr id="tag_aiplatform.googleapis.com/Featurestore" class="even">
<td><code translate="no" dir="ltr">aiplatform.googleapis.com/Featurestore</code><br />
Vertex AI Feature Store</td>
<td>A Vertex AI Feature Store.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP Project owning the Featurestore.<br />
<code translate="no" dir="ltr">location</code>: The region in which the service is running.<br />
<code translate="no" dir="ltr">featurestore_id</code>: The ID of the Featurestore.</td>
</tr>
<tr id="tag_aiplatform.googleapis.com/Index" class="odd">
<td><code translate="no" dir="ltr">aiplatform.googleapis.com/Index</code><br />
Matching Engine Index</td>
<td>An Index built through the cloud Matching Engine service.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP Project owning the Index.<br />
<code translate="no" dir="ltr">location</code>: The region in which the service is running.<br />
<code translate="no" dir="ltr">index_id</code>: The ID of the Index.</td>
</tr>
<tr id="tag_aiplatform.googleapis.com/IndexEndpoint" class="even">
<td><code translate="no" dir="ltr">aiplatform.googleapis.com/IndexEndpoint</code><br />
Matching Engine Index Endpoint</td>
<td>An Endpoint to which Matching Engine Indexes are deployed.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP Project owning the Index.<br />
<code translate="no" dir="ltr">location</code>: The region in which the service is running.<br />
<code translate="no" dir="ltr">index_endpoint_id</code>: The ID of the index endpoint.</td>
</tr>
<tr id="tag_aiplatform.googleapis.com/ModelMonitor" class="odd">
<td><code translate="no" dir="ltr">aiplatform.googleapis.com/ModelMonitor</code><br />
Vertex AI Model Monitor</td>
<td>A Vertex AI Model Monitor.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP Project owning the Model Monitor.<br />
<code translate="no" dir="ltr">location</code>: The region in which the service is running.<br />
<code translate="no" dir="ltr">model_monitor_id</code>: The identifier of the Model Monitor.</td>
</tr>
<tr id="tag_aiplatform.googleapis.com/OnlineEvaluator" class="even">
<td><code translate="no" dir="ltr">aiplatform.googleapis.com/OnlineEvaluator</code><br />
Vertex AI Online Evaluator</td>
<td>A Vertex AI Online Evaluator.<br />
<code translate="no" dir="ltr">resource_container</code>: The resource container of the Online Evaluator.<br />
<code translate="no" dir="ltr">location</code>: The location of the Online Evaluator.<br />
<code translate="no" dir="ltr">online_evaluator_id</code>: The ID of the Online Evaluator resource.</td>
</tr>
<tr id="tag_aiplatform.googleapis.com/PipelineJob" class="odd">
<td><code translate="no" dir="ltr">aiplatform.googleapis.com/PipelineJob</code><br />
Vertex Pipelines Job</td>
<td>A Vertex Pipelines Job.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">location</code>: The region in which the service is running.<br />
<code translate="no" dir="ltr">pipeline_job_id</code>: The ID of the PipelineJob.</td>
</tr>
<tr id="tag_aiplatform.googleapis.com/PublisherModel" class="even">
<td><code translate="no" dir="ltr">aiplatform.googleapis.com/PublisherModel</code><br />
Vertex AI Model Garden Publisher Model</td>
<td>A Vertex AI Model Garden Publisher Model.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP Project owning the Endpoint.<br />
<code translate="no" dir="ltr">location</code>: The region in which the service is running.<br />
<code translate="no" dir="ltr">publisher</code>: The publisher of the model.<br />
<code translate="no" dir="ltr">model_user_id</code>: The resource ID of the PublisherModel.<br />
<code translate="no" dir="ltr">model_version_id</code>: The version ID of the PublisherModel.</td>
</tr>
<tr id="tag_aiplatform.googleapis.com/ReasoningEngine" class="odd">
<td><code translate="no" dir="ltr">aiplatform.googleapis.com/ReasoningEngine</code><br />
Vertex AI Reasoning Engine</td>
<td>A Vertex AI Reasoning Engine.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP Project owning the ReasoningEngine.<br />
<code translate="no" dir="ltr">location</code>: The region in which the service is running.<br />
<code translate="no" dir="ltr">reasoning_engine_id</code>: The numeric ID of the Reasoning Engine instance.</td>
</tr>
<tr id="tag_aiplatform.googleapis.com/ServerlessRayJob" class="even">
<td><code translate="no" dir="ltr">aiplatform.googleapis.com/ServerlessRayJob</code><br />
Vertex AI Serverless Ray Job</td>
<td>A Vertex AI Serverless Ray Job.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP Project owning the Serverless Ray Job.<br />
<code translate="no" dir="ltr">location</code>: The region in which the service is running.<br />
<code translate="no" dir="ltr">job_id</code>: The ID of the Serverless Ray Job.</td>
</tr>
<tr id="tag_alloydb.googleapis.com/Cluster" class="odd">
<td><code translate="no" dir="ltr">alloydb.googleapis.com/Cluster</code><br />
AlloyDB cluster</td>
<td>Monitored resource representing an AlloyDB cluster.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The Google Cloud region in which the AlloyDB cluster is running.<br />
<code translate="no" dir="ltr">cluster_id</code>: AlloyDB cluster identifier.</td>
</tr>
<tr id="tag_alloydb.googleapis.com/Instance" class="even">
<td><code translate="no" dir="ltr">alloydb.googleapis.com/Instance</code><br />
AlloyDB instance</td>
<td>Monitored resource representing an AlloyDB instance.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The Google Cloud region in which the AlloyDB instance is running.<br />
<code translate="no" dir="ltr">cluster_id</code>: AlloyDB cluster identifier.<br />
<code translate="no" dir="ltr">instance_id</code>: AlloyDB instance identifier.</td>
</tr>
<tr id="tag_anthos_l4lb" class="odd">
<td><code translate="no" dir="ltr">anthos_l4lb</code><br />
Anthos L4LB</td>
<td>An Anthos L4 load balancer instance.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">location</code>: The GCP region where to store metrics.<br />
<code translate="no" dir="ltr">kind</code>: The kind of the load balancer.<br />
<code translate="no" dir="ltr">group_name</code>: The name of the load balancer group.<br />
<code translate="no" dir="ltr">hostname</code>: The hostname of the instance running LB.</td>
</tr>
<tr id="tag_api" class="even">
<td><code translate="no" dir="ltr">api</code><br />
Produced API</td>
<td>An API provided by the producer.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">service</code>: The API service name, such as "cloudsql.googleapis.com".<br />
<code translate="no" dir="ltr">method</code>: The API method, such as "disks.list".<br />
<code translate="no" dir="ltr">version</code>: The API version, such as "v1".<br />
<code translate="no" dir="ltr">location</code>: The service specific notion of location. This can be the name of a zone, region, or "global".</td>
</tr>
<tr id="tag_apigateway.googleapis.com/Gateway" class="odd">
<td><code translate="no" dir="ltr">apigateway.googleapis.com/Gateway</code><br />
API Gateway</td>
<td>Fully managed API Gateway.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP Project owning the Gateway.<br />
<code translate="no" dir="ltr">location</code>: The region in which the Gateway is running.<br />
<code translate="no" dir="ltr">gateway_id</code>: The ID of the Gateway.</td>
</tr>
<tr id="tag_apigee.googleapis.com/Environment" class="even">
<td><code translate="no" dir="ltr">apigee.googleapis.com/Environment</code><br />
Apigee environment</td>
<td>Monitored resource for Apigee environment.<br />
<code translate="no" dir="ltr">resource_container</code>: The GCP project ID that writes to this monitored resource.<br />
<code translate="no" dir="ltr">org</code>: An organization is a container for all the objects in an Apigee account.<br />
<code translate="no" dir="ltr">env</code>: An environment is a runtime execution context for the proxies in an organization.<br />
<code translate="no" dir="ltr">location</code>: Location where the Apigee infrastructure is provisioned.</td>
</tr>
<tr id="tag_apigee.googleapis.com/Instance" class="odd">
<td><code translate="no" dir="ltr">apigee.googleapis.com/Instance</code><br />
Apigee instance</td>
<td>Monitored resource for Apigee instance.<br />
<code translate="no" dir="ltr">resource_container</code>: The GCP project ID that writes to this monitored resource.<br />
<code translate="no" dir="ltr">org</code>: An organization is a container for all the objects in an Apigee account.<br />
<code translate="no" dir="ltr">location</code>: Location of the Apigee Instance.<br />
<code translate="no" dir="ltr">instance_id</code>: Instance ID of the Apigee application.</td>
</tr>
<tr id="tag_app_script_function" class="even">
<td><code translate="no" dir="ltr">app_script_function</code><br />
Apps Script Function</td>
<td>An Apps Script function.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">invocation_type</code>: The invocation type.<br />
<code translate="no" dir="ltr">function_name</code>: The function name.</td>
</tr>
<tr id="tag_artifactregistry.googleapis.com/Project" class="odd">
<td><code translate="no" dir="ltr">artifactregistry.googleapis.com/Project</code><br />
Artifact Registry Project</td>
<td>A Cloud project in Artifact Registry.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP resource container associated with this resource, such as "my_project" or "organizations/5678".<br />
<code translate="no" dir="ltr">location</code>: Location of resource.</td>
</tr>
<tr id="tag_artifactregistry.googleapis.com/Repository" class="even">
<td><code translate="no" dir="ltr">artifactregistry.googleapis.com/Repository</code><br />
Artifact Registry Repository</td>
<td>A repository in Artifact Registry.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP resource container associated with this resource, such as "my_project" or "organizations/5678".<br />
<code translate="no" dir="ltr">location</code>: Location of resource.<br />
<code translate="no" dir="ltr">repository_id</code>: The identifier of the Artifact Registry repository, such as "my_repository".</td>
</tr>
<tr id="tag_assistant_action" class="odd">
<td><code translate="no" dir="ltr">assistant_action</code><br />
Google Assistant Action</td>
<td>An Action in a Google Assistant App.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">version_id</code>: Stringified version ID of the assistant agent.<br />
<code translate="no" dir="ltr">action_id</code>: Action ID of the assistant agent.</td>
</tr>
<tr id="tag_assistant_action_project" class="even">
<td><code translate="no" dir="ltr">assistant_action_project</code><br />
Google Assistant Action Project</td>
<td>A project in a Google Assistant Action.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".</td>
</tr>
<tr id="tag_audited_resource" class="odd">
<td><code translate="no" dir="ltr">audited_resource</code><br />
Audited Resource</td>
<td>A Google Cloud resource that produces an audit log.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">service</code>: The name of the API service generating the audit log.<br />
<code translate="no" dir="ltr">method</code>: The name of the API method generating the audit log.</td>
</tr>
<tr id="tag_authztoolkitcontrol.googleapis.com/TargetAssociation" class="even">
<td><code translate="no" dir="ltr">authztoolkitcontrol.googleapis.com/TargetAssociation</code><br />
AuthzToolkit TargetAssociation</td>
<td>A target association resource in AuthzToolkit.<br />
<code translate="no" dir="ltr">resource_container</code>: The GCP container associated with the target association.<br />
<code translate="no" dir="ltr">location</code>: The region that contains the target association.<br />
<code translate="no" dir="ltr">target_association_id</code>: The target association id.</td>
</tr>
<tr id="tag_autoscaler" class="odd">
<td><code translate="no" dir="ltr">autoscaler</code><br />
Autoscaler</td>
<td>An autoscaler for a single managed instance group.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">location</code>: The zone or region for the autoscaler.<br />
<code translate="no" dir="ltr">autoscaler_id</code>: The identifier for the autoscaler.<br />
<code translate="no" dir="ltr">autoscaler_name</code>: The name of the autoscaler.<br />
<code translate="no" dir="ltr">instance_group_manager_id</code>: The identifier for the managed instance group scaled by the given autoscaler.<br />
<code translate="no" dir="ltr">instance_group_manager_name</code>: The name of the managed instance group scaled by the givenautoscaler.</td>
</tr>
<tr id="tag_aws_alb_load_balancer" class="even">
<td><code translate="no" dir="ltr">aws_alb_load_balancer</code><br />
Amazon ALB Load Balancer</td>
<td>A load balancer in Amazon ALB.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project under which data is stored for the AWS account specified in the aws_account label, such as "my-project".<br />
<code translate="no" dir="ltr">name</code>: The name of the load balancer.<br />
<code translate="no" dir="ltr">region</code>: The AWS region for the load balancer. The format of this field is "aws:{region}", where supported values for {region} are listed at <a href="http://docs.aws.amazon.com/general/latest/gr/rande.html">http://docs.aws.amazon.com/general/latest/gr/rande.html</a>.<br />
<code translate="no" dir="ltr">aws_account</code>: The AWS account number for the load balancer.</td>
</tr>
<tr id="tag_aws_cloudfront_distribution" class="odd">
<td><code translate="no" dir="ltr">aws_cloudfront_distribution</code><br />
Amazon CloudFront CDN</td>
<td>A CloudFront content distribution network.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project under which data is stored for the AWS account specified in the aws_account label, such as "my-project".<br />
<code translate="no" dir="ltr">distribution_id</code>: The CloudFront distribution identifier assigned by AWS.<br />
<code translate="no" dir="ltr">region</code>: The AWS region for the CloudFront distribution. The format of this field is "aws:{region}", where supported values for {region} are listed at <a href="http://docs.aws.amazon.com/general/latest/gr/rande.html">http://docs.aws.amazon.com/general/latest/gr/rande.html</a>.<br />
<code translate="no" dir="ltr">aws_account</code>: The AWS account number for the CDN.</td>
</tr>
<tr id="tag_aws_ec2_instance" class="even">
<td><code translate="no" dir="ltr">aws_ec2_instance</code><br />
Amazon EC2 Instance</td>
<td>A VM instance in Amazon EC2.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project under which data is stored for the AWS account specified in the aws_account label, such as "my-project".<br />
<code translate="no" dir="ltr">instance_id</code>: The VM instance identifier assigned by AWS.<br />
<code translate="no" dir="ltr">aws_account</code>: The AWS account number under which the VM is running.<br />
<code translate="no" dir="ltr">region</code>: The AWS region in which the VM is running. Supported AWS region values are listed by service at <a href="http://docs.aws.amazon.com/general/latest/gr/rande.html">http://docs.aws.amazon.com/general/latest/gr/rande.html</a>. The value supplied for this label must be prefixed with 'aws:' (for example, 'aws:us-east-1' is a valid value while 'us-east-1' is not).</td>
</tr>
<tr id="tag_aws_elasticache_cluster" class="odd">
<td><code translate="no" dir="ltr">aws_elasticache_cluster</code><br />
Amazon Elasticache Cluster</td>
<td>A cache cluster in Amazon Elasticache.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project under which data is stored for the AWS account specified in the aws_account label, such as "my-project".<br />
<code translate="no" dir="ltr">cluster_id</code>: The cluster identifier.<br />
<code translate="no" dir="ltr">region</code>: The AWS region for the cluster. The format of this field is "aws:{region}", where supported values for {region} are listed at <a href="http://docs.aws.amazon.com/general/latest/gr/rande.html">http://docs.aws.amazon.com/general/latest/gr/rande.html</a>.<br />
<code translate="no" dir="ltr">aws_account</code>: The AWS account number for the cluster.</td>
</tr>
<tr id="tag_aws_lambda_function" class="even">
<td><code translate="no" dir="ltr">aws_lambda_function</code><br />
Amazon Lambda Function</td>
<td>A function in Amazon Lambda.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project under which data is stored for the AWS account specified in the aws_account label, such as "my-project".<br />
<code translate="no" dir="ltr">function_name</code>: The function name.<br />
<code translate="no" dir="ltr">region</code>: The AWS region for the function. The format of this field is "aws:{region}", where supported values for {region} are listed at <a href="http://docs.aws.amazon.com/general/latest/gr/rande.html">http://docs.aws.amazon.com/general/latest/gr/rande.html</a>.<br />
<code translate="no" dir="ltr">aws_account</code>: The AWS account number for the function.</td>
</tr>
<tr id="tag_aws_rds_database" class="odd">
<td><code translate="no" dir="ltr">aws_rds_database</code><br />
Amazon RDS Database</td>
<td>A database in Amazon Relational Database Service.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project under which data is stored for the AWS account specified in the aws_account label, such as "my-project".<br />
<code translate="no" dir="ltr">name</code>: The database name.<br />
<code translate="no" dir="ltr">region</code>: The AWS region for the database. The format of this field is "aws:{region}", where supported values for {region} are listed at <a href="http://docs.aws.amazon.com/general/latest/gr/rande.html">http://docs.aws.amazon.com/general/latest/gr/rande.html</a>.<br />
<code translate="no" dir="ltr">aws_account</code>: The AWS account number for the database.</td>
</tr>
<tr id="tag_aws_s3_bucket" class="even">
<td><code translate="no" dir="ltr">aws_s3_bucket</code><br />
Amazon S3 Bucket</td>
<td>A bucket in Amazon S3.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project under which data is stored for the AWS account specified in the aws_account label, such as "my-project".<br />
<code translate="no" dir="ltr">bucket_name</code>: The bucket name.<br />
<code translate="no" dir="ltr">region</code>: The AWS region for the bucket. The format of this field is "aws:{region}", where supported values for {region} are listed at <a href="http://docs.aws.amazon.com/general/latest/gr/rande.html">http://docs.aws.amazon.com/general/latest/gr/rande.html</a>.<br />
<code translate="no" dir="ltr">aws_account</code>: The AWS account number for the bucket.</td>
</tr>
<tr id="tag_aws_sqs_queue" class="odd">
<td><code translate="no" dir="ltr">aws_sqs_queue</code><br />
Amazon SQS Queue</td>
<td>A queue in Amazon Simple Queue Service.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project under which data is stored for the AWS account specified in the aws_account label, such as "my-project".<br />
<code translate="no" dir="ltr">queue</code>: The queue name.<br />
<code translate="no" dir="ltr">region</code>: The AWS region for the queue. The format of this field is "aws:{region}", where supported values for {region} are listed at <a href="http://docs.aws.amazon.com/general/latest/gr/rande.html">http://docs.aws.amazon.com/general/latest/gr/rande.html</a>.<br />
<code translate="no" dir="ltr">aws_account</code>: The AWS account number for the queue.</td>
</tr>
<tr id="tag_backupdr.googleapis.com/AutoProtectionPolicy" class="even">
<td><code translate="no" dir="ltr">backupdr.googleapis.com/AutoProtectionPolicy</code><br />
Auto Protection Policy</td>
<td>Represents a single Auto Protection Policy resource.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The GCP location.<br />
<code translate="no" dir="ltr">auto_protection_policy_id</code>: The ID of the Auto Protection Policy.</td>
</tr>
<tr id="tag_backupdr.googleapis.com/AutoProtectionPolicyBinding" class="odd">
<td><code translate="no" dir="ltr">backupdr.googleapis.com/AutoProtectionPolicyBinding</code><br />
Auto Protection Policy Binding</td>
<td>Represents a single Auto Protection Policy Binding resource.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The GCP location.<br />
<code translate="no" dir="ltr">auto_protection_policy_id</code>: The ID of the Auto Protection Policy.<br />
<code translate="no" dir="ltr">binding_id</code>: The ID of the Auto Protection Policy Binding.</td>
</tr>
<tr id="tag_backupdr.googleapis.com/BackupDRProject" class="even">
<td><code translate="no" dir="ltr">backupdr.googleapis.com/BackupDRProject</code><br />
BackupDR Project</td>
<td>A BackupDR Project.<br />
<code translate="no" dir="ltr">resource_container</code>: Backup and DR API enabled project.<br />
<code translate="no" dir="ltr">location</code>: The GCP location.</td>
</tr>
<tr id="tag_backupdr.googleapis.com/BackupPlan" class="odd">
<td><code translate="no" dir="ltr">backupdr.googleapis.com/BackupPlan</code><br />
Backup Plan</td>
<td>Represents a single Backup Plan resource.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The GCP location.<br />
<code translate="no" dir="ltr">backup_plan_id</code>: The ID of the Backup Plan.</td>
</tr>
<tr id="tag_backupdr.googleapis.com/BackupPlanAssociation" class="even">
<td><code translate="no" dir="ltr">backupdr.googleapis.com/BackupPlanAssociation</code><br />
Backup Plan Association</td>
<td>Represents a single Backup Plan Association resource.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The GCP location.<br />
<code translate="no" dir="ltr">backup_plan_association_id</code>: The ID of the Backup Plan Association.</td>
</tr>
<tr id="tag_backupdr.googleapis.com/BackupRecoveryAppliance" class="odd">
<td><code translate="no" dir="ltr">backupdr.googleapis.com/BackupRecoveryAppliance</code><br />
Backup Recovery Appliance</td>
<td>A Backup Recovery Appliance.<br />
<code translate="no" dir="ltr">resource_container</code>: Backup and DR API enabled project.<br />
<code translate="no" dir="ltr">location</code>: The GCP location.<br />
<code translate="no" dir="ltr">backup_recovery_appliance_id</code>: The Backup recovery appliance Id.<br />
<code translate="no" dir="ltr">management_server_id</code>: Name of the management server.</td>
</tr>
<tr id="tag_backupdr.googleapis.com/BackupVault" class="even">
<td><code translate="no" dir="ltr">backupdr.googleapis.com/BackupVault</code><br />
BackupVault</td>
<td>A specialized storage for Google Cloud Backup and DR backups.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP project on which the BackupDR API is enabled, such as "my-project".<br />
<code translate="no" dir="ltr">location</code>: The GCP location.<br />
<code translate="no" dir="ltr">backup_vault_id</code>: The BackupVault ID.</td>
</tr>
<tr id="tag_backupdr.googleapis.com/ManagementConsole" class="odd">
<td><code translate="no" dir="ltr">backupdr.googleapis.com/ManagementConsole</code><br />
Management Console</td>
<td>A Backup and DR management console.<br />
<code translate="no" dir="ltr">resource_container</code>: Backup and DR API enabled project.<br />
<code translate="no" dir="ltr">location</code>: The GCP location.<br />
<code translate="no" dir="ltr">management_server_id</code>: Name of the management server.</td>
</tr>
<tr id="tag_baremetalsolution.googleapis.com/Instance" class="even">
<td><code translate="no" dir="ltr">baremetalsolution.googleapis.com/Instance</code><br />
Bare Metal Solution Instance</td>
<td>Bare Metal Solution Instance.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The GCP location where the instance resource resides.<br />
<code translate="no" dir="ltr">instance_id</code>: The ID of the instance resource.</td>
</tr>
<tr id="tag_batch.googleapis.com/Job" class="odd">
<td><code translate="no" dir="ltr">batch.googleapis.com/Job</code><br />
Job</td>
<td>A Google Batch job managed by the Google Batch service.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP project associated with the job.<br />
<code translate="no" dir="ltr">location</code>: The region where the job has been created.<br />
<code translate="no" dir="ltr">job_id</code>: The identifier of the Job.</td>
</tr>
<tr id="tag_beyondcorp.googleapis.com/SecurityGateway" class="even">
<td><code translate="no" dir="ltr">beyondcorp.googleapis.com/SecurityGateway</code><br />
Security Gateway</td>
<td>Chrome Enterprise Premium Security Gateway.<br />
<code translate="no" dir="ltr">resource_container</code>: The GCP container associated with the Security Gateway.<br />
<code translate="no" dir="ltr">location</code>: The region that contains the Security Gateway.<br />
<code translate="no" dir="ltr">security_gateway_id</code>: The Security Gateway ID.</td>
</tr>
<tr id="tag_bigquery.googleapis.com/ManagedRoutineInvocation" class="odd">
<td><code translate="no" dir="ltr">bigquery.googleapis.com/ManagedRoutineInvocation</code><br />
BigQuery Managed Routine Invocation</td>
<td>Logs and metrics from BigQuery Managed Routines.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP resource container associated with this resource, such as "my-project" or "organizations/123".<br />
<code translate="no" dir="ltr">location</code>: The cloud location of the managed routine.<br />
<code translate="no" dir="ltr">query_job_id</code>: The identifier of the BigQuery job that invoked the managed routine.<br />
<code translate="no" dir="ltr">routine_project_id</code>: The project id of the invoked routine.<br />
<code translate="no" dir="ltr">routine_dataset_id</code>: The dataset id of the invoked routine.<br />
<code translate="no" dir="ltr">routine_id</code>: The id of the invoked routine.</td>
</tr>
<tr id="tag_bigquery.googleapis.com/SparkJob" class="even">
<td><code translate="no" dir="ltr">bigquery.googleapis.com/SparkJob</code><br />
BigQuery Spark Job</td>
<td>Logs and metrics from BigQuery Spark Jobs.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP resource container associated with this resource, such as "my-project" or "organizations/123".<br />
<code translate="no" dir="ltr">location</code>: The Cloud location of the Spark job.<br />
<code translate="no" dir="ltr">spark_job_id</code>: The ID of the Spark job.</td>
</tr>
<tr id="tag_bigquery_biengine_model" class="odd">
<td><code translate="no" dir="ltr">bigquery_biengine_model</code><br />
BigQuery BI Engine Model</td>
<td>BigQuery BI Engine Model.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">location</code>: The Google Cloud location of the resource.<br />
<code translate="no" dir="ltr">model_id</code>: The identifier of the BI model.</td>
</tr>
<tr id="tag_bigquery_dataset" class="even">
<td><code translate="no" dir="ltr">bigquery_dataset</code><br />
BigQuery Dataset</td>
<td>A dataset in BigQuery.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">dataset_id</code>: The name of the BigQuery dataset.</td>
</tr>
<tr id="tag_bigquery_dts_config" class="odd">
<td><code translate="no" dir="ltr">bigquery_dts_config</code><br />
BigQuery DTS Config</td>
<td>A BigQuery Data Transfer Service configuration.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">location</code>: The Google Cloud location of the resource<br />
<code translate="no" dir="ltr">config_id</code>: The id of the DTS configuration.</td>
</tr>
<tr id="tag_bigquery_project" class="even">
<td><code translate="no" dir="ltr">bigquery_project</code><br />
BigQuery Project</td>
<td>BigQuery Project.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">location</code>: Location of the resource.</td>
</tr>
<tr id="tag_bigquery_resource" class="odd">
<td><code translate="no" dir="ltr">bigquery_resource</code><br />
BigQuery</td>
<td>A BigQuery resource.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".</td>
</tr>
<tr id="tag_billing_account" class="even">
<td><code translate="no" dir="ltr">billing_account</code><br />
Cloud Billing Account</td>
<td>A Cloud Billing Account.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">account_id</code>: The unique id of the billing account.</td>
</tr>
<tr id="tag_build" class="odd">
<td><code translate="no" dir="ltr">build</code><br />
Cloud Build</td>
<td>A build in Cloud Build.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">build_id</code>: The unique id of the build.<br />
<code translate="no" dir="ltr">build_trigger_id</code>: The unique id of the build trigger.</td>
</tr>
<tr id="tag_businessaicode.googleapis.com/BAICInstance" class="even">
<td><code translate="no" dir="ltr">businessaicode.googleapis.com/BAICInstance</code><br />
Business AI Code Instance</td>
<td>An instance resource that represents a Business AI Code configuration.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP container associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The location of the resource.</td>
</tr>
<tr id="tag_certificatemanager.googleapis.com/Project" class="odd">
<td><code translate="no" dir="ltr">certificatemanager.googleapis.com/Project</code><br />
Certificate Manager project</td>
<td>Certificate Manager project.<br />
<code translate="no" dir="ltr">resource_container</code>: The GCP container associated with the resource.<br />
<code translate="no" dir="ltr">location</code>: GCP location.</td>
</tr>
<tr id="tag_chronicle.googleapis.com/Compliance" class="even">
<td><code translate="no" dir="ltr">chronicle.googleapis.com/Compliance</code><br />
Chronicle Compliance</td>
<td>A Chronicle compliance object<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">location</code>: The physical location of the Chronicle instance.<br />
<code translate="no" dir="ltr">instance_id</code>: The unique identifier for the Chronicle instance.</td>
</tr>
<tr id="tag_chronicle.googleapis.com/LogType" class="odd">
<td><code translate="no" dir="ltr">chronicle.googleapis.com/LogType</code><br />
Chronicle Log Type</td>
<td>A Chronicle logtype object<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">location</code>: The physical location of the cluster that contains the logtype object.<br />
<code translate="no" dir="ltr">log_type</code>: The name of the log type.</td>
</tr>
<tr id="tag_client_auth_config_brand" class="even">
<td><code translate="no" dir="ltr">client_auth_config_brand</code><br />
OAuth2 Brand</td>
<td>Consent screen data shown to users during three-legged OAuth2 flows.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">brand_id</code>: The unique id of the brand.</td>
</tr>
<tr id="tag_client_auth_config_client" class="odd">
<td><code translate="no" dir="ltr">client_auth_config_client</code><br />
OAuth2 Client</td>
<td>A client used in OAuth2 flows.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">client_id</code>: The unique id of the client.</td>
</tr>
<tr id="tag_cloud_composer_environment" class="even">
<td><code translate="no" dir="ltr">cloud_composer_environment</code><br />
Cloud Composer Environment</td>
<td>A Composer environment runs the managed Apache Airflow service.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">location</code>: The Cloud Composer location in which the environment is running.<br />
<code translate="no" dir="ltr">environment_name</code>: The user-specified environment name.</td>
</tr>
<tr id="tag_cloud_dataproc_batch" class="odd">
<td><code translate="no" dir="ltr">cloud_dataproc_batch</code><br />
Cloud Dataproc Batch</td>
<td>A Dataproc batch execution.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">location</code>: The Cloud Dataproc region to which the batch was submitted.<br />
<code translate="no" dir="ltr">batch_id</code>: The user-specified batch id.</td>
</tr>
<tr id="tag_cloud_dataproc_cluster" class="even">
<td><code translate="no" dir="ltr">cloud_dataproc_cluster</code><br />
Cloud Dataproc Cluster</td>
<td>A Dataproc cluster with separate cluster name and id labels.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">cluster_name</code>: The user-specified cluster name.<br />
<code translate="no" dir="ltr">cluster_uuid</code>: The generated cluster id.<br />
<code translate="no" dir="ltr">region</code>: The Cloud Dataproc region in which the cluster is running.</td>
</tr>
<tr id="tag_cloud_dataproc_job" class="odd">
<td><code translate="no" dir="ltr">cloud_dataproc_job</code><br />
Cloud Dataproc Job</td>
<td>A Dataproc job execution.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">region</code>: The Cloud Dataproc region to which the job was submitted.<br />
<code translate="no" dir="ltr">job_id</code>: The user-specified job id.<br />
<code translate="no" dir="ltr">job_uuid</code>: The generated job uuid.</td>
</tr>
<tr id="tag_cloud_dataproc_session" class="even">
<td><code translate="no" dir="ltr">cloud_dataproc_session</code><br />
Cloud Dataproc Session</td>
<td>A Dataproc session execution.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">location</code>: The Cloud Dataproc region in which the session was created.<br />
<code translate="no" dir="ltr">session_id</code>: The user-specified session id.</td>
</tr>
<tr id="tag_cloud_debugger_resource" class="odd">
<td><code translate="no" dir="ltr">cloud_debugger_resource</code><br />
Cloud Debugger</td>
<td>A Google Cloud Debugger resource.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">app</code>: The application to which the debugger is attached.</td>
</tr>
<tr id="tag_cloud_function" class="even">
<td><code translate="no" dir="ltr">cloud_function</code><br />
Cloud Function</td>
<td>A function in Google Cloud Functions.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">function_name</code>: The short function name.<br />
<code translate="no" dir="ltr">region</code>: The region in which the function is running.</td>
</tr>
<tr id="tag_cloud_osconfig_patch_job" class="odd">
<td><code translate="no" dir="ltr">cloud_osconfig_patch_job</code><br />
OS Patch Job</td>
<td>A Google Cloud OS Patch Job.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">patch_job_id</code>: Identifier of the job.</td>
</tr>
<tr id="tag_cloud_run_instance" class="even">
<td><code translate="no" dir="ltr">cloud_run_instance</code><br />
Cloud Run Instance</td>
<td>An instance in Cloud Run.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">instance_name</code>: Name of the monitored instance.<br />
<code translate="no" dir="ltr">location</code>: Region where the instance exists.</td>
</tr>
<tr id="tag_cloud_run_job" class="odd">
<td><code translate="no" dir="ltr">cloud_run_job</code><br />
Cloud Run Job</td>
<td>A job in Cloud Run.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">job_name</code>: Name of the monitored job.<br />
<code translate="no" dir="ltr">location</code>: Region where the job exists.</td>
</tr>
<tr id="tag_cloud_run_revision" class="even">
<td><code translate="no" dir="ltr">cloud_run_revision</code><br />
Cloud Run Revision</td>
<td>A revision in Cloud Run.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">service_name</code>: Name of the service.<br />
<code translate="no" dir="ltr">revision_name</code>: Name of the monitored revision.<br />
<code translate="no" dir="ltr">location</code>: Region where the service is running.<br />
<code translate="no" dir="ltr">configuration_name</code>: Name of the configuration which created the monitored revision.</td>
</tr>
<tr id="tag_cloud_run_worker_pool" class="odd">
<td><code translate="no" dir="ltr">cloud_run_worker_pool</code><br />
Cloud Run Worker Pool</td>
<td>A worker pool in Cloud Run.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">worker_pool_name</code>: Name of the worker pool.<br />
<code translate="no" dir="ltr">revision_name</code>: Name of the monitored revision.<br />
<code translate="no" dir="ltr">location</code>: Region where the worker pool is running.<br />
<code translate="no" dir="ltr">configuration_name</code>: Name of the configuration which created the monitored revision.</td>
</tr>
<tr id="tag_cloud_scheduler_job" class="even">
<td><code translate="no" dir="ltr">cloud_scheduler_job</code><br />
Cloud Scheduler Job</td>
<td>A Cloud Scheduler Job.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">location</code>: The region of the job.<br />
<code translate="no" dir="ltr">job_id</code>: Identifier of the job.</td>
</tr>
<tr id="tag_cloud_tasks_queue" class="odd">
<td><code translate="no" dir="ltr">cloud_tasks_queue</code><br />
Cloud Tasks Queue</td>
<td>A queue in Cloud Tasks.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">queue_id</code>: The name of the queue.<br />
<code translate="no" dir="ltr">target_type</code>: The target type the queue is dispatching to.<br />
<code translate="no" dir="ltr">location</code>: The zone or region where the application is running.</td>
</tr>
<tr id="tag_cloudaicompanion.googleapis.com/Instance" class="even">
<td><code translate="no" dir="ltr">cloudaicompanion.googleapis.com/Instance</code><br />
Gemini for Google Cloud Instance</td>
<td>An instance resource that represents a Gemini for Google Cloud configuration.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP container associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The location of the resource.<br />
<code translate="no" dir="ltr">instance_id</code>: The ID of the instance resource.</td>
</tr>
<tr id="tag_cloudcontrolspartner.googleapis.com/Location" class="odd">
<td><code translate="no" dir="ltr">cloudcontrolspartner.googleapis.com/Location</code><br />
Location</td>
<td>A Google Cloud Resource.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP container associated with the resource.<br />
<code translate="no" dir="ltr">location</code>: The region in which the job is running.</td>
</tr>
<tr id="tag_clouddeploy.googleapis.com/DeliveryPipeline" class="even">
<td><code translate="no" dir="ltr">clouddeploy.googleapis.com/DeliveryPipeline</code><br />
Cloud Deploy Delivery Pipeline</td>
<td>A Cloud Deploy Delivery Pipeline.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the Google Cloud project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The Google Cloud location where the resource resides.<br />
<code translate="no" dir="ltr">pipeline_id</code>: ID of the delivery pipeline resource.</td>
</tr>
<tr id="tag_cloudkms_cryptokey" class="odd">
<td><code translate="no" dir="ltr">cloudkms_cryptokey</code><br />
Cloud KMS CryptoKey</td>
<td>Cryptographic key in the KMS.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">location</code>: The region Crypto Key belongs to.<br />
<code translate="no" dir="ltr">key_ring_id</code>: Key Ring the Crypto Key belongs to.<br />
<code translate="no" dir="ltr">crypto_key_id</code>: Crypto Key Identifier.</td>
</tr>
<tr id="tag_cloudkms_cryptokeyversion" class="even">
<td><code translate="no" dir="ltr">cloudkms_cryptokeyversion</code><br />
Cloud KMS CryptoKeyVersion</td>
<td>Version of a cryptographic key.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">location</code>: The region Crypto Key Version belongs to.<br />
<code translate="no" dir="ltr">key_ring_id</code>: Key Ring the Crypto Key Version belongs to.<br />
<code translate="no" dir="ltr">crypto_key_id</code>: Crypto Key the Crypto Key Version belongs to.<br />
<code translate="no" dir="ltr">crypto_key_version_id</code>: Crypto Key Version Identifier.</td>
</tr>
<tr id="tag_cloudkms_keyring" class="odd">
<td><code translate="no" dir="ltr">cloudkms_keyring</code><br />
Cloud KMS Key Ring</td>
<td>Collection of cryptographic keys.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">location</code>: The region Key Ring belongs to.<br />
<code translate="no" dir="ltr">key_ring_id</code>: Key Ring Identifier.</td>
</tr>
<tr id="tag_cloudml_job" class="even">
<td><code translate="no" dir="ltr">cloudml_job</code><br />
Cloud ML Job</td>
<td>A Google Cloud ML job.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">job_id</code>: An immutable identifier for a job.<br />
<code translate="no" dir="ltr">region</code>: Cloud ML region.</td>
</tr>
<tr id="tag_cloudml_model_version" class="odd">
<td><code translate="no" dir="ltr">cloudml_model_version</code><br />
Cloud ML Model Version</td>
<td>A Google Cloud ML model version.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">model_id</code>: An immutable identifier for a model.<br />
<code translate="no" dir="ltr">version_id</code>: An immutable identifier for a version.<br />
<code translate="no" dir="ltr">region</code>: Cloud ML region.</td>
</tr>
<tr id="tag_cloudsql_database" class="even">
<td><code translate="no" dir="ltr">cloudsql_database</code><br />
Cloud SQL Database</td>
<td>A Cloud SQL instance.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">database_id</code>: The Google Cloud SQL instance name.<br />
<code translate="no" dir="ltr">region</code>: The Google Cloud SQL region in which the database is running.</td>
</tr>
<tr id="tag_cloudvolumesgcp-api.netapp.com/CloudVolume" class="odd">
<td><code translate="no" dir="ltr">cloudvolumesgcp-api.netapp.com/CloudVolume</code><br />
Monitored Resource for NetApp CVS</td>
<td>Monitored Resource for NetApp CVS.<br />
<code translate="no" dir="ltr">resource_container</code>: Project information.<br />
<code translate="no" dir="ltr">location</code>: Region/Zone information.<br />
<code translate="no" dir="ltr">volume_id</code>: ID of the volume.<br />
<code translate="no" dir="ltr">service_type</code>: Service type of the volume or replication relationship.<br />
<code translate="no" dir="ltr">name</code>: Name of the volume or replication relationship.</td>
</tr>
<tr id="tag_compute.googleapis.com/Machine" class="even">
<td><code translate="no" dir="ltr">compute.googleapis.com/Machine</code><br />
Machine</td>
<td>A Compute Engine Machine ID<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">zone</code>: The zone of the GCP project associated with the machine.<br />
<code translate="no" dir="ltr">machine_id</code>: The obfuscated ID of the machine</td>
</tr>
<tr id="tag_compute.googleapis.com/Reservation" class="odd">
<td><code translate="no" dir="ltr">compute.googleapis.com/Reservation</code><br />
Reservation</td>
<td>Monitored resource representing a reservation.<br />
<code translate="no" dir="ltr">resource_container</code>: The GCP container (e.g. project number) associated with the reservation.<br />
<code translate="no" dir="ltr">location</code>: The zone that contains the reservation.<br />
<code translate="no" dir="ltr">reservation_id</code>: Reservation resource ID.</td>
</tr>
<tr id="tag_connectors.googleapis.com/Connection" class="even">
<td><code translate="no" dir="ltr">connectors.googleapis.com/Connection</code><br />
Connectors</td>
<td>Monitored resource for Connectors.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: GCP region location of the connection.<br />
<code translate="no" dir="ltr">connection</code>: The name of the connection.</td>
</tr>
<tr id="tag_consumed_api" class="odd">
<td><code translate="no" dir="ltr">consumed_api</code><br />
Consumed API</td>
<td>An API used by customers.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as 'my-project'.<br />
<code translate="no" dir="ltr">service</code>: The API service name, such as 'cloudsql.googleapis.com'.<br />
<code translate="no" dir="ltr">method</code>: The API method name, such as 'disks.list'.<br />
<code translate="no" dir="ltr">version</code>: The API version, such as 'v1'.<br />
<code translate="no" dir="ltr">location</code>: The service specific notion of location. This can be a name of a zone or region. If a service does not have any notion of zones then 'global' can be used.<br />
<code translate="no" dir="ltr">credential_id</code>: The client credential ID, such as an API key ID or the OAuth client ID.</td>
</tr>
<tr id="tag_contactcenteraiplatform.googleapis.com/ContactCenter" class="even">
<td><code translate="no" dir="ltr">contactcenteraiplatform.googleapis.com/ContactCenter</code><br />
CCAI Platform Contact Center</td>
<td>A CCAI Platform Contact Center instance.<br />
<code translate="no" dir="ltr">resource_container</code>: Container of the current project.<br />
<code translate="no" dir="ltr">resource_id</code>: The identifier of the Contact Center instance.<br />
<code translate="no" dir="ltr">location</code>: The region in which the Contact Center is running.</td>
</tr>
<tr id="tag_container" class="odd">
<td><code translate="no" dir="ltr">container</code><br />
GKE Container</td>
<td>A Google Kubernetes Engine (GKE) container instance.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">cluster_name</code>: An immutable name for the cluster the container is running in.<br />
<code translate="no" dir="ltr">namespace_id</code>: Immutable ID of the cluster namespace the container is running in.<br />
<code translate="no" dir="ltr">instance_id</code>: Immutable ID of the Compute Engine instance the container is running in.<br />
<code translate="no" dir="ltr">pod_id</code>: Immutable ID of the pod the container is running in.<br />
<code translate="no" dir="ltr">container_name</code>: Immutable name of the container.<br />
<code translate="no" dir="ltr">zone</code>: The Compute Engine zone in which the instance is running.</td>
</tr>
<tr id="tag_container.googleapis.com/Cluster" class="even">
<td><code translate="no" dir="ltr">container.googleapis.com/Cluster</code><br />
Kubernetes Cluster Limits</td>
<td>Kubernetes Cluster.<br />
<code translate="no" dir="ltr">resource_container</code>: Project or organization.<br />
<code translate="no" dir="ltr">location</code>: Region or zone where the cluster was created.<br />
<code translate="no" dir="ltr">cluster_name</code>: Cluster name.</td>
</tr>
<tr id="tag_container.googleapis.com/NodePool" class="odd">
<td><code translate="no" dir="ltr">container.googleapis.com/NodePool</code><br />
GKE Node Pool</td>
<td>GKE Node Pool.<br />
<code translate="no" dir="ltr">resource_container</code>: Project or organization.<br />
<code translate="no" dir="ltr">location</code>: Region or zone where the cluster was created.<br />
<code translate="no" dir="ltr">cluster_name</code>: Cluster name.<br />
<code translate="no" dir="ltr">node_pool_name</code>: Node pool name.</td>
</tr>
<tr id="tag_contextawareaccess.googleapis.com/Location" class="even">
<td><code translate="no" dir="ltr">contextawareaccess.googleapis.com/Location</code><br />
Location</td>
<td>Access summary for risk based access levels.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the Google Cloud organization associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The location of the resource.</td>
</tr>
<tr id="tag_csr_repository" class="odd">
<td><code translate="no" dir="ltr">csr_repository</code><br />
Cloud Source Repository</td>
<td>A repository in Google Cloud Source Repositories.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">name</code>: The name of the repository.</td>
</tr>
<tr id="tag_dataflow_step" class="even">
<td><code translate="no" dir="ltr">dataflow_step</code><br />
Dataflow Step</td>
<td>A step in a Dataflow job.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">job_id</code>: The ID of the job.<br />
<code translate="no" dir="ltr">step_id</code>: The ID of the step.<br />
<code translate="no" dir="ltr">job_name</code>: The name of the job.<br />
<code translate="no" dir="ltr">region</code>: The region in which the job is running.</td>
</tr>
<tr id="tag_dataform.googleapis.com/Repository" class="odd">
<td><code translate="no" dir="ltr">dataform.googleapis.com/Repository</code><br />
Dataform Repository</td>
<td>A Repository on Google Cloud Dataform.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP resource container associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">location</code>: The region in which the Repository is created.<br />
<code translate="no" dir="ltr">repository_id</code>: The user-specified ID of the Repository.</td>
</tr>
<tr id="tag_datafusion.googleapis.com/InstanceV2" class="even">
<td><code translate="no" dir="ltr">datafusion.googleapis.com/InstanceV2</code><br />
Cloud Data Fusion Instance</td>
<td>An instance of Cloud Data Fusion.<br />
<code translate="no" dir="ltr">resource_container</code>: The ID of the customer project.<br />
<code translate="no" dir="ltr">org_id</code>: The ID of the organization that the customer project belongs to.<br />
<code translate="no" dir="ltr">location</code>: The zone/region that the instance is hosted in.<br />
<code translate="no" dir="ltr">edition</code>: The edition of the instance.<br />
<code translate="no" dir="ltr">is_private_ip_enabled</code>: Does the instance use private IP.<br />
<code translate="no" dir="ltr">version</code>: The data plane version of the instance.<br />
<code translate="no" dir="ltr">instance_id</code>: The instance ID.<br />
<code translate="no" dir="ltr">namespace</code>: Name of the namespace.</td>
</tr>
<tr id="tag_datafusion.googleapis.com/InstanceV3" class="odd">
<td><code translate="no" dir="ltr">datafusion.googleapis.com/InstanceV3</code><br />
Cloud Data Fusion Instance</td>
<td>An instance of Cloud Data Fusion.<br />
<code translate="no" dir="ltr">resource_container</code>: The ID of the customer project.<br />
<code translate="no" dir="ltr">location</code>: The zone/region that the instance is hosted in.<br />
<code translate="no" dir="ltr">edition</code>: The edition of the instance.<br />
<code translate="no" dir="ltr">is_private_ip_enabled</code>: Does the instance use private IP.<br />
<code translate="no" dir="ltr">version</code>: The data plane version of the instance.<br />
<code translate="no" dir="ltr">instance_id</code>: The instance ID.</td>
</tr>
<tr id="tag_datafusion.googleapis.com/PipelineV2" class="even">
<td><code translate="no" dir="ltr">datafusion.googleapis.com/PipelineV2</code><br />
Cloud Data Fusion Pipeline</td>
<td>A deployed Pipeline in a Cloud Data Fusion instance.<br />
<code translate="no" dir="ltr">resource_container</code>: The ID of the customer project.<br />
<code translate="no" dir="ltr">org_id</code>: The ID of the organization that the customer project belongs to.<br />
<code translate="no" dir="ltr">location</code>: The zone/region that the instance is hosted in.<br />
<code translate="no" dir="ltr">edition</code>: The edition of the instance.<br />
<code translate="no" dir="ltr">is_private_ip_enabled</code>: Does the instance use private IP.<br />
<code translate="no" dir="ltr">version</code>: The data plane version of the instance.<br />
<code translate="no" dir="ltr">instance_id</code>: The instance ID.<br />
<code translate="no" dir="ltr">namespace</code>: The namespace of the pipeline.<br />
<code translate="no" dir="ltr">pipeline_id</code>: The Pipeline ID.<br />
<code translate="no" dir="ltr">run_id</code>: The Run ID.</td>
</tr>
<tr id="tag_datamigration.googleapis.com/MigrationJob" class="odd">
<td><code translate="no" dir="ltr">datamigration.googleapis.com/MigrationJob</code><br />
Database migration service migration job</td>
<td>Database migration service migration job.<br />
<code translate="no" dir="ltr">resource_container</code>: The resource container (project ID).<br />
<code translate="no" dir="ltr">location</code>: The location.<br />
<code translate="no" dir="ltr">migration_job_id</code>: The migration job ID.</td>
</tr>
<tr id="tag_dataplex.googleapis.com/Asset" class="even">
<td><code translate="no" dir="ltr">dataplex.googleapis.com/Asset</code><br />
Cloud Dataplex Asset</td>
<td>An Asset within a Cloud Dataplex Lake.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The GCP region associated with this resource.<br />
<code translate="no" dir="ltr">lake_id</code>: The identifier of the Lake resource containing this resource.<br />
<code translate="no" dir="ltr">zone_id</code>: The identifier of the Zone resource containing this resource.<br />
<code translate="no" dir="ltr">asset_id</code>: The identifier of this Asset resource.</td>
</tr>
<tr id="tag_dataplex.googleapis.com/DataScan" class="odd">
<td><code translate="no" dir="ltr">dataplex.googleapis.com/DataScan</code><br />
Cloud Dataplex DataScan</td>
<td>A DataScan resource in Dataplex.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The GCP region associated with this resource.<br />
<code translate="no" dir="ltr">datascan_id</code>: The identifier of this DataScan resource.</td>
</tr>
<tr id="tag_dataplex.googleapis.com/EntryLink" class="even">
<td><code translate="no" dir="ltr">dataplex.googleapis.com/EntryLink</code><br />
Cloud Dataplex Glossary Entry Link Resource</td>
<td>A Glossary Entry Link resource in Dataplex.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The cloud region that contains the resource.<br />
<code translate="no" dir="ltr">entry_group_id</code>: The user-provided identifier for the entry group resource.<br />
<code translate="no" dir="ltr">entry_link_id</code>: The user-provided identifier for the entry link resource.</td>
</tr>
<tr id="tag_dataplex.googleapis.com/EntryLinkType" class="odd">
<td><code translate="no" dir="ltr">dataplex.googleapis.com/EntryLinkType</code><br />
Cloud Dataplex Entry Link Type Resource</td>
<td>An Entry Link Type resource in Dataplex.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The cloud region that contains the resource.<br />
<code translate="no" dir="ltr">entry_link_type_id</code>: The user-provided identifier for the entry link type resource.</td>
</tr>
<tr id="tag_dataplex.googleapis.com/Environment" class="even">
<td><code translate="no" dir="ltr">dataplex.googleapis.com/Environment</code><br />
Cloud Dataplex Environment</td>
<td>An Environment within a Cloud Dataplex Lake.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The GCP region associated with this resource.<br />
<code translate="no" dir="ltr">lake_id</code>: The identifier of the Lake resource containing this resource.<br />
<code translate="no" dir="ltr">environment_id</code>: The identifier of this Environment resource.</td>
</tr>
<tr id="tag_dataplex.googleapis.com/Glossary" class="odd">
<td><code translate="no" dir="ltr">dataplex.googleapis.com/Glossary</code><br />
Cloud Dataplex Glossary Resource</td>
<td>A Glossary resource in Dataplex.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The cloud region that contains the resource.<br />
<code translate="no" dir="ltr">glossary_id</code>: The user-provided identifier for the glossary resource.</td>
</tr>
<tr id="tag_dataplex.googleapis.com/GlossaryCategory" class="even">
<td><code translate="no" dir="ltr">dataplex.googleapis.com/GlossaryCategory</code><br />
Cloud Dataplex Glossary Category Resource</td>
<td>A Glossary Category resource in Dataplex.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The cloud region that contains the resource.<br />
<code translate="no" dir="ltr">glossary_id</code>: The user-provided identifier for the glossary resource.<br />
<code translate="no" dir="ltr">glossary_category_id</code>: The user-provided identifier for the glossary category resource.</td>
</tr>
<tr id="tag_dataplex.googleapis.com/GlossaryTerm" class="odd">
<td><code translate="no" dir="ltr">dataplex.googleapis.com/GlossaryTerm</code><br />
Cloud Dataplex Glossary Term Resource</td>
<td>A Glossary Term resource in Dataplex.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The cloud region that contains the resource.<br />
<code translate="no" dir="ltr">glossary_id</code>: The user-provided identifier for the glossary resource.<br />
<code translate="no" dir="ltr">glossary_term_id</code>: The user-provided identifier for the glossary term resource.</td>
</tr>
<tr id="tag_dataplex.googleapis.com/GovernanceRule" class="even">
<td><code translate="no" dir="ltr">dataplex.googleapis.com/GovernanceRule</code><br />
Cloud Dataplex Governance Rule</td>
<td>A Governance rule resource in Dataplex.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The cloud region that contains the resource.<br />
<code translate="no" dir="ltr">rule_id</code>: The user-provided identifier for the governance rule.</td>
</tr>
<tr id="tag_dataplex.googleapis.com/Lake" class="odd">
<td><code translate="no" dir="ltr">dataplex.googleapis.com/Lake</code><br />
Cloud Dataplex Lake</td>
<td>A Cloud Dataplex Lake.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The GCP region associated with this resource.<br />
<code translate="no" dir="ltr">lake_id</code>: The identifier of this Lake resource.</td>
</tr>
<tr id="tag_dataplex.googleapis.com/Project" class="even">
<td><code translate="no" dir="ltr">dataplex.googleapis.com/Project</code><br />
Cloud Dataplex Project.</td>
<td>Cloud Dataplex Project.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The location of the resource.</td>
</tr>
<tr id="tag_dataplex.googleapis.com/Task" class="odd">
<td><code translate="no" dir="ltr">dataplex.googleapis.com/Task</code><br />
Cloud Dataplex Task</td>
<td>A Task within a Cloud Dataplex Lake.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The GCP region associated with this resource.<br />
<code translate="no" dir="ltr">lake_id</code>: The identifier of the Lake resource containing this resource.<br />
<code translate="no" dir="ltr">task_id</code>: The identifier of this Task resource.</td>
</tr>
<tr id="tag_dataplex.googleapis.com/Zone" class="even">
<td><code translate="no" dir="ltr">dataplex.googleapis.com/Zone</code><br />
Cloud Dataplex Zone</td>
<td>A Zone within a Cloud Dataplex Lake.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The GCP region associated with this resource.<br />
<code translate="no" dir="ltr">lake_id</code>: The identifier of the Lake resource containing this resource.<br />
<code translate="no" dir="ltr">zone_id</code>: The identifier of this Zone resource.</td>
</tr>
<tr id="tag_datastore_database" class="odd">
<td><code translate="no" dir="ltr">datastore_database</code><br />
Cloud Datastore Database</td>
<td>A Cloud Datastore database.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">database_id</code>: The unique id of the database.</td>
</tr>
<tr id="tag_datastore_index" class="even">
<td><code translate="no" dir="ltr">datastore_index</code><br />
Cloud Datastore Index</td>
<td>A Cloud Datastore index.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">database_id</code>: The database the index belongs to.<br />
<code translate="no" dir="ltr">index_id</code>: The unique id of the index.</td>
</tr>
<tr id="tag_datastream.googleapis.com/Stream" class="odd">
<td><code translate="no" dir="ltr">datastream.googleapis.com/Stream</code><br />
Datastream Stream</td>
<td>A Datastream stream.<br />
<code translate="no" dir="ltr">resource_container</code>: The resource container (project ID).<br />
<code translate="no" dir="ltr">location</code>: The location.<br />
<code translate="no" dir="ltr">stream_id</code>: The stream ID.</td>
</tr>
<tr id="tag_dell_emc_cloud_onefs_cluster" class="even">
<td><code translate="no" dir="ltr">dell_emc_cloud_onefs_cluster</code><br />
Dell EMC Cloud OneFS Cluster</td>
<td>Multi-protocol access to files and directories on GCP, Isilon Cloud OneFS clusters with SMB for Windows, and NFS for UNIX file systems.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">location</code>: The Google Cloud location in which the cluster is running.<br />
<code translate="no" dir="ltr">cluster_id</code>: Unique identifier of the cluster.</td>
</tr>
<tr id="tag_deployment" class="odd">
<td><code translate="no" dir="ltr">deployment</code><br />
Deployment</td>
<td>A Deployment Manager deployment.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">name</code>: Name that uniquely identifies the deployment within a project.</td>
</tr>
<tr id="tag_deployment_manager_manifest" class="even">
<td><code translate="no" dir="ltr">deployment_manager_manifest</code><br />
Deployment Manager Manifest</td>
<td>A Deployment Manager manifest which is used to specify the contents of a deployment.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">manifest_name</code>: Name that uniquely identifies the manifest within a project.<br />
<code translate="no" dir="ltr">deployment_name</code>: Name of the deployment.</td>
</tr>
<tr id="tag_deployment_manager_operation" class="odd">
<td><code translate="no" dir="ltr">deployment_manager_operation</code><br />
Deployment Manager Operation</td>
<td>A Deployment Manager operation.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">operation_name</code>: Name that uniquely identifies the operation within a project.</td>
</tr>
<tr id="tag_deployment_manager_resource" class="even">
<td><code translate="no" dir="ltr">deployment_manager_resource</code><br />
Deployment Manager Resource</td>
<td>Deployment Manager's record of Google Cloud Platform resources in a Deployment, such as a VM or a bucket.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">resource_name</code>: Name of the resource, unique within a deployment.<br />
<code translate="no" dir="ltr">deployment_name</code>: Name of the deployment.</td>
</tr>
<tr id="tag_deployment_manager_type" class="odd">
<td><code translate="no" dir="ltr">deployment_manager_type</code><br />
Deployment Manager Type</td>
<td>A Deployment Manager type.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">name</code>: Name that uniquely identifies the type within a project.</td>
</tr>
<tr id="tag_dialogflow.googleapis.com/Location" class="even">
<td><code translate="no" dir="ltr">dialogflow.googleapis.com/Location</code><br />
Dialogflow Location</td>
<td>A Dialogflow Location (sometimes called Region).<br />
<code translate="no" dir="ltr">resource_container</code>: The id of the GCP resource container associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: Location of resource.</td>
</tr>
<tr id="tag_discoveryengine.googleapis.com/Agent" class="odd">
<td><code translate="no" dir="ltr">discoveryengine.googleapis.com/Agent</code><br />
Gemini Enterprise Agent</td>
<td>A specific Agent resource within Gemini Enterprise, mapping to discoveryengine.googleapis.com/Agent.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The Google Cloud location where the Agent is located.<br />
<code translate="no" dir="ltr">assistant_id</code>: The unique identifier of the Assistant.<br />
<code translate="no" dir="ltr">engine_id</code>: The unique identifier of the Engine.<br />
<code translate="no" dir="ltr">agent_id</code>: The unique identifier of the Agent.</td>
</tr>
<tr id="tag_discoveryengine.googleapis.com/AgentToolInvocation" class="even">
<td><code translate="no" dir="ltr">discoveryengine.googleapis.com/AgentToolInvocation</code><br />
Gemini Enterprise Agent Tool Invocation</td>
<td>An Invocation of a specific Tool within the context of Gemini Enterprise Agent. This resource type is used for tracking tool-level metrics and latencies scoped to individual agents.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The Google Cloud location where the Tool is located.<br />
<code translate="no" dir="ltr">assistant_id</code>: The unique identifier of the Assistant using the tool.<br />
<code translate="no" dir="ltr">engine_id</code>: The unique identifier of the Engine where the tool is used.<br />
<code translate="no" dir="ltr">agent_id</code>: The unique identifier of the Agent using the tool.<br />
<code translate="no" dir="ltr">tool_id</code>: The unique identifier of the Tool.</td>
</tr>
<tr id="tag_discoveryengine.googleapis.com/DataConnector" class="odd">
<td><code translate="no" dir="ltr">discoveryengine.googleapis.com/DataConnector</code><br />
Gemini Enterprise Data Connector</td>
<td>A specific Data Connector resource within Gemini Enterprise, mapping to discoveryengine.googleapis.com/DataConnector.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The Google Cloud location where the Data Connector is located.<br />
<code translate="no" dir="ltr">connector_id</code>: The unique identifier of the Data Connector.<br />
<code translate="no" dir="ltr">data_source</code>: Type of the Data Connector.</td>
</tr>
<tr id="tag_discoveryengine.googleapis.com/Engine" class="even">
<td><code translate="no" dir="ltr">discoveryengine.googleapis.com/Engine</code><br />
Gemini Enterprise Engine</td>
<td>A specific Engine (app) resource within Gemini Enterprise, mapping to discoveryengine.googleapis.com/Engine.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The Google Cloud location where the Engine is located.<br />
<code translate="no" dir="ltr">collection_id</code>: The Collection the Engine belongs to (e.g. default_collection).<br />
<code translate="no" dir="ltr">engine_id</code>: The unique identifier of the Engine.</td>
</tr>
<tr id="tag_dns_managed_zone" class="odd">
<td><code translate="no" dir="ltr">dns_managed_zone</code><br />
Managed DNS Zone</td>
<td>A ManagedZone in the Google Cloud DNS service.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">zone_name</code>: The name of the ManagedZone.<br />
<code translate="no" dir="ltr">location</code>: The location field is provided for compatibility with other GCP services. Its value is always set to 'global'</td>
</tr>
<tr id="tag_dns_policy" class="even">
<td><code translate="no" dir="ltr">dns_policy</code><br />
Cloud DNS Policy</td>
<td>A Policy in the Google Cloud DNS service.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">policy_name</code>: The name of the Policy.<br />
<code translate="no" dir="ltr">location</code>: The location field is provided for compatibility with other GCP services. Its value is always set to 'global'</td>
</tr>
<tr id="tag_dns_query" class="odd">
<td><code translate="no" dir="ltr">dns_query</code><br />
Cloud DNS Query</td>
<td>A DNS query to a private DNS handled by the Google Cloud DNS service.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">target_name</code>: The DNS name managed by Cloud DNS to be resolved (e.g. the zone name, policy name, internal domain name). External names will have the value "external"<br />
<code translate="no" dir="ltr">location</code>: The GCP zone where the DNS request was received (e.g. us-east1, us-west1).<br />
<code translate="no" dir="ltr">target_type</code>: The target of the resolution of the DNS query (e.g. public-zone, private-zone, external).<br />
<code translate="no" dir="ltr">source_type</code>: Source of the query (e.g. gce-vm, internet).</td>
</tr>
<tr id="tag_dns_resource_record_set" class="even">
<td><code translate="no" dir="ltr">dns_resource_record_set</code><br />
Cloud DNS Resource Record Set</td>
<td>A ResourceRecordSet in the Google Cloud DNS service.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">name</code>: The name of the ResourceRecordSet.<br />
<code translate="no" dir="ltr">type</code>: The type of the ResourceRecordSet.<br />
<code translate="no" dir="ltr">location</code>: The GCP region where the ResourceRecordSet is located.</td>
</tr>
<tr id="tag_dns_response_policy" class="odd">
<td><code translate="no" dir="ltr">dns_response_policy</code><br />
Cloud DNS Response Policy</td>
<td>A ResponsePolicy in the Google Cloud DNS service.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">location</code>: The GCP region where the ResponsePolicy is located.<br />
<code translate="no" dir="ltr">response_policy_name</code>: The name of the ResponsePolicy.</td>
</tr>
<tr id="tag_dns_response_policy_rule" class="even">
<td><code translate="no" dir="ltr">dns_response_policy_rule</code><br />
Cloud DNS Response Policy Rule</td>
<td>A ResponsePolicyRule in the Google Cloud DNS service.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">location</code>: The GCP region where the ResponsePolicyRule is located.<br />
<code translate="no" dir="ltr">response_policy_name</code>: The name of the parent ResponsePolicy.<br />
<code translate="no" dir="ltr">response_policy_rule_name</code>: The name of the ResponsePolicyRule.</td>
</tr>
<tr id="tag_edgecache.googleapis.com/EdgeCacheRouteRule" class="odd">
<td><code translate="no" dir="ltr">edgecache.googleapis.com/EdgeCacheRouteRule</code><br />
Edge Cache Route Rule</td>
<td>An Edge Cache route rule represents an Edge Cache Service's traffic as part of a Media Edge deployment.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: A GCP zone close to the proxy location. Please note that this may change over time.<br />
<code translate="no" dir="ltr">service_name</code>: The name of the EdgeCacheService.<br />
<code translate="no" dir="ltr">path_matcher_name</code>: The name of the PathMatcher that contains this route.<br />
<code translate="no" dir="ltr">matched_path</code>: The matched URL prefix, full URL path, or path template.<br />
<code translate="no" dir="ltr">route_type</code>: The type of the routed matched by the incoming request, one of [ORIGIN, URL_REDIRECT].<br />
<code translate="no" dir="ltr">route_destination</code>: The URL of the origin this request is to be proxied to.</td>
</tr>
<tr id="tag_eventarc.googleapis.com/Enrollment" class="even">
<td><code translate="no" dir="ltr">eventarc.googleapis.com/Enrollment</code><br />
Eventarc Enrollment</td>
<td>An Enrollment represents a subscription for messages on a particular MessageBus.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP container associated with the resource.<br />
<code translate="no" dir="ltr">location</code>: The location of the GCP project associated with the resource.<br />
<code translate="no" dir="ltr">enrollment_id</code>: The ID of the Enrollment.</td>
</tr>
<tr id="tag_eventarc.googleapis.com/GoogleApiSource" class="odd">
<td><code translate="no" dir="ltr">eventarc.googleapis.com/GoogleApiSource</code><br />
Eventarc Google API Source</td>
<td>A GoogleApiSource represents a subscription of 1P events from a MessageBus.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP container associated with the resource.<br />
<code translate="no" dir="ltr">location</code>: The location of the GCP project associated with the resource.<br />
<code translate="no" dir="ltr">google_api_source_id</code>: The ID of the GoogleApiSource.</td>
</tr>
<tr id="tag_eventarc.googleapis.com/MessageBus" class="even">
<td><code translate="no" dir="ltr">eventarc.googleapis.com/MessageBus</code><br />
Eventarc Message Bus</td>
<td>MessageBus for the messages flowing through the system.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP container associated with the resource.<br />
<code translate="no" dir="ltr">location</code>: The location of the GCP project associated with the resource.<br />
<code translate="no" dir="ltr">message_bus_id</code>: The ID of the MessageBus.</td>
</tr>
<tr id="tag_eventarc.googleapis.com/Pipeline" class="odd">
<td><code translate="no" dir="ltr">eventarc.googleapis.com/Pipeline</code><br />
Eventarc Pipeline</td>
<td>A Pipeline represents a destination for messages subscribed by an Enrollment.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP container associated with the resource.<br />
<code translate="no" dir="ltr">location</code>: The location of the GCP project associated with the resource.<br />
<code translate="no" dir="ltr">pipeline_id</code>: The ID of the Pipeline.</td>
</tr>
<tr id="tag_faulttesting.googleapis.com/Experiment" class="even">
<td><code translate="no" dir="ltr">faulttesting.googleapis.com/Experiment</code><br />
Fault Injection Experiment</td>
<td>Experiment associated with a template to inject faults.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP resource container associated with this resource (project_id), such as "my-project" or "organizations/123".<br />
<code translate="no" dir="ltr">location</code>: The location in which the Fault Injection Experiment is present.<br />
<code translate="no" dir="ltr">experiment_id</code>: The ID of the Experiment.</td>
</tr>
<tr id="tag_filestore_instance" class="odd">
<td><code translate="no" dir="ltr">filestore_instance</code><br />
Filestore Instance</td>
<td>A Filestore instance.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">location</code>: The physical location of the instance.<br />
<code translate="no" dir="ltr">instance_name</code>: The name for the Filestore instance.</td>
</tr>
<tr id="tag_financialservices.googleapis.com/BacktestResult" class="even">
<td><code translate="no" dir="ltr">financialservices.googleapis.com/BacktestResult</code><br />
Financial Services Backtest Result</td>
<td>A BacktestResult within the Financial Services API.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP container associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The GCP location associated with this resource (e.g., us-central1).<br />
<code translate="no" dir="ltr">instance_id</code>: The FinServ instance that contains this resource (e.g., test-instance).<br />
<code translate="no" dir="ltr">backtest_result_id</code>: BacktestResult ID (e.g., test-backtest-result).</td>
</tr>
<tr id="tag_financialservices.googleapis.com/EngineConfig" class="odd">
<td><code translate="no" dir="ltr">financialservices.googleapis.com/EngineConfig</code><br />
Financial Services Engine Config</td>
<td>An EngineConfig within the Financial Services API.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP container associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The GCP location associated with this resource (e.g., us-central1).<br />
<code translate="no" dir="ltr">instance_id</code>: The FinServ instance that contains this resource (e.g., test-instance).<br />
<code translate="no" dir="ltr">engine_config_id</code>: EngineConfig ID (e.g., test-engine-config).</td>
</tr>
<tr id="tag_financialservices.googleapis.com/Instance" class="even">
<td><code translate="no" dir="ltr">financialservices.googleapis.com/Instance</code><br />
Financial Services Instance</td>
<td>An Instance within the Financial Services API.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP container associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The GCP location associated with this resource (e.g., us-central1).<br />
<code translate="no" dir="ltr">instance_id</code>: Instance ID (e.g., test-instance).</td>
</tr>
<tr id="tag_financialservices.googleapis.com/PredictionResult" class="odd">
<td><code translate="no" dir="ltr">financialservices.googleapis.com/PredictionResult</code><br />
Financial Services Prediction Result</td>
<td>A PredictionResult within the Financial Services API.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP container associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The GCP location associated with this resource (e.g., us-central1).<br />
<code translate="no" dir="ltr">instance_id</code>: The FinServ instance that contains this resource (e.g., test-instance).<br />
<code translate="no" dir="ltr">prediction_result_id</code>: PredictionResult ID (e.g., test-prediction-result).</td>
</tr>
<tr id="tag_firebase_auth" class="even">
<td><code translate="no" dir="ltr">firebase_auth</code><br />
Firebase Auth Project</td>
<td>A Firebase Auth Project.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".</td>
</tr>
<tr id="tag_firebase_domain" class="odd">
<td><code translate="no" dir="ltr">firebase_domain</code><br />
Firebase Hosting Site Domain</td>
<td>A domain from which a Firebase Hosting site is serving traffic.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as 'my-project'.<br />
<code translate="no" dir="ltr">site_name</code>: The name of a Firebase Hosting site, that is the subdomain in .web.app.<br />
<code translate="no" dir="ltr">domain_name</code>: The default subdomain (on web.app or firebaseapp.com) or custom domain from which content was served.</td>
</tr>
<tr id="tag_firebase_namespace" class="even">
<td><code translate="no" dir="ltr">firebase_namespace</code><br />
Firebase Realtime Database</td>
<td>A Firebase Realtime Database.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">table_name</code>: The name of the database.<br />
<code translate="no" dir="ltr">location</code>: The location of the database.</td>
</tr>
<tr id="tag_firebaseapphosting.googleapis.com/Backend" class="odd">
<td><code translate="no" dir="ltr">firebaseapphosting.googleapis.com/Backend</code><br />
Firebase App Hosting Backend</td>
<td>A Firebase App Hosting Backend.<br />
<code translate="no" dir="ltr">resource_container</code>: The GCP container (usually project ID) for the App Hosting Backend.<br />
<code translate="no" dir="ltr">location</code>: The serving locality of the App Hosting Backend, such as "global" or "us-central1". For v1 backends, this will be "global".<br />
<code translate="no" dir="ltr">backend_id</code>: An identifier for the App Hosting Backend within a project.</td>
</tr>
<tr id="tag_firebasecrashlytics.googleapis.com/App" class="even">
<td><code translate="no" dir="ltr">firebasecrashlytics.googleapis.com/App</code><br />
Firebase Crashlytics App</td>
<td>A Firebase client using Crashlytics.<br />
<code translate="no" dir="ltr">resource_container</code>: The Firebase project for the application.<br />
<code translate="no" dir="ltr">location</code>: Location for Firebase Apps is global.<br />
<code translate="no" dir="ltr">app_id</code>: A Firebase App ID.</td>
</tr>
<tr id="tag_firebaserules_release" class="odd">
<td><code translate="no" dir="ltr">firebaserules_release</code><br />
Releases for Firebase Rules</td>
<td>Mapping of the ruleset to a release name.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">release_name</code>: Name of the release.<br />
<code translate="no" dir="ltr">region</code>: The region in which the ruleset is on.</td>
</tr>
<tr id="tag_firebaserules_ruleset" class="even">
<td><code translate="no" dir="ltr">firebaserules_ruleset</code><br />
Ruleset for Firebase Rules</td>
<td>Definition of the ruleset for firebase rules.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">ruleset_name</code>: Name of the ruleset.<br />
<code translate="no" dir="ltr">region</code>: The region in which the ruleset is on.</td>
</tr>
<tr id="tag_firebasevertexai.googleapis.com/Model" class="odd">
<td><code translate="no" dir="ltr">firebasevertexai.googleapis.com/Model</code><br />
Firebase AI Logic Model</td>
<td>A Model supported by Firebase AI Logic.<br />
<code translate="no" dir="ltr">resource_container</code>: The GCP container associated with the model.<br />
<code translate="no" dir="ltr">location</code>: The zone that served the model.<br />
<code translate="no" dir="ltr">publisher_id</code>: The publisher ID of the model, such as "google".<br />
<code translate="no" dir="ltr">model_id</code>: The model ID, such as "gemini-0.0-flash-002".</td>
</tr>
<tr id="tag_firebasevertexai.googleapis.com/PromptTemplate" class="even">
<td><code translate="no" dir="ltr">firebasevertexai.googleapis.com/PromptTemplate</code><br />
Firebase AI Logic Server Prompt Template</td>
<td>A Firebase AI Logic Server Prompt Template.<br />
<code translate="no" dir="ltr">resource_container</code>: The GCP container associated with the prompt template.<br />
<code translate="no" dir="ltr">location</code>: The region that served the prompt template.<br />
<code translate="no" dir="ltr">template_id</code>: The prompt template ID.</td>
</tr>
<tr id="tag_firestore.googleapis.com/Database" class="odd">
<td><code translate="no" dir="ltr">firestore.googleapis.com/Database</code><br />
Firestore Database</td>
<td>A Firestore Database.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The location of the database.<br />
<code translate="no" dir="ltr">database_id</code>: The database id.</td>
</tr>
<tr id="tag_fleetengine.googleapis.com/DeliveryFleet" class="even">
<td><code translate="no" dir="ltr">fleetengine.googleapis.com/DeliveryFleet</code><br />
Fleet Engine Last Mile Fleet Solution</td>
<td>A top-level resource for Fleet Engine Last Mile Fleet Solution metrics and logs.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP container associated with DeliveryFleet.<br />
<code translate="no" dir="ltr">location</code>: The region in which the Fleet Engine instance is running.</td>
</tr>
<tr id="tag_fleetengine.googleapis.com/Fleet" class="odd">
<td><code translate="no" dir="ltr">fleetengine.googleapis.com/Fleet</code><br />
Fleet Engine On Demand Rides and Deliveries</td>
<td>A top-level resource for Fleet Engine On Demand Rides and Deliveries metrics and logs.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP container associated with Fleet.<br />
<code translate="no" dir="ltr">location</code>: The region in which the Fleet Engine instance is running.</td>
</tr>
<tr id="tag_folder" class="even">
<td><code translate="no" dir="ltr">folder</code><br />
Google Folder</td>
<td>A Google Cloud Platform folder.<br />
<code translate="no" dir="ltr">folder_id</code>: Numeric id of the folder.</td>
</tr>
<tr id="tag_gae_app" class="odd">
<td><code translate="no" dir="ltr">gae_app</code><br />
GAE Application</td>
<td>An application running in Google App Engine (GAE).<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">module_id</code>: The service/module name.<br />
<code translate="no" dir="ltr">version_id</code>: The version name.<br />
<code translate="no" dir="ltr">zone</code>: The GAE zone where the application is running.</td>
</tr>
<tr id="tag_gateway_scope" class="even">
<td><code translate="no" dir="ltr">gateway_scope</code><br />
Gateway Scope</td>
<td>GatewayScope represents a set of Gateways with the same merged configs.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">location</code>: The location of the control plane<br />
<code translate="no" dir="ltr">scope</code>: The name of the gateway_scope</td>
</tr>
<tr id="tag_gce_autoscaler" class="odd">
<td><code translate="no" dir="ltr">gce_autoscaler</code><br />
Autoscaler</td>
<td>A Google Compute Engine autoscaler.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">autoscaler_id</code>: Unique identifier of the autoscaler.<br />
<code translate="no" dir="ltr">location</code>: Compute Engine zone or region where the autoscaler is running.</td>
</tr>
<tr id="tag_gce_backend_bucket" class="even">
<td><code translate="no" dir="ltr">gce_backend_bucket</code><br />
Backend Bucket</td>
<td>A Google Compute Engine backend bucket.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">backend_bucket_id</code>: Unique identifier of the backend bucket.</td>
</tr>
<tr id="tag_gce_backend_service" class="odd">
<td><code translate="no" dir="ltr">gce_backend_service</code><br />
Cloud Load Balancing Backend Service</td>
<td>A Compute Engine backend service.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">backend_service_id</code>: Unique identifier of the backend service.<br />
<code translate="no" dir="ltr">location</code>: Global or Compute Engine region containing the backend service</td>
</tr>
<tr id="tag_gce_client_ssl_policy" class="even">
<td><code translate="no" dir="ltr">gce_client_ssl_policy</code><br />
Client SSL Policy</td>
<td>A Google Compute Engine client SSL policy.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">client_ssl_policy_id</code>: Unique identifier of the client SSL policy.</td>
</tr>
<tr id="tag_gce_commitment" class="odd">
<td><code translate="no" dir="ltr">gce_commitment</code><br />
Committed Use Discount</td>
<td>A Google Compute Engine committed use discount.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">commitment_id</code>: Unique identifier of the committed use discount.<br />
<code translate="no" dir="ltr">location</code>: Compute Engine region where the committed use discount is active.</td>
</tr>
<tr id="tag_gce_disk" class="even">
<td><code translate="no" dir="ltr">gce_disk</code><br />
Disk</td>
<td>A disk belonging to a Compute Engine instance.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">disk_id</code>: Unique identifier of the disk.<br />
<code translate="no" dir="ltr">zone</code>: The Compute Engine zone where the disk resides.</td>
</tr>
<tr id="tag_gce_firewall_rule" class="odd">
<td><code translate="no" dir="ltr">gce_firewall_rule</code><br />
Firewall Rule</td>
<td>A Google Compute Engine firewall rule.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">firewall_rule_id</code>: Unique identifier of the firewall rule.</td>
</tr>
<tr id="tag_gce_forwarding_rule" class="even">
<td><code translate="no" dir="ltr">gce_forwarding_rule</code><br />
Forwarding Rule</td>
<td>A Google Compute Engine Forwarding Rule.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">forwarding_rule_id</code>: Unique identifier of the forewarding rule.<br />
<code translate="no" dir="ltr">region</code>: Compute Engine region where the forwarding rule resides.</td>
</tr>
<tr id="tag_gce_ha_controller" class="odd">
<td><code translate="no" dir="ltr">gce_ha_controller</code><br />
HA Controller</td>
<td>A Google Compute Engine HA controller.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">ha_controller_id</code>: Unique identifier of the HA controller.<br />
<code translate="no" dir="ltr">location</code>: Compute Engine region where the HA controller resides.</td>
</tr>
<tr id="tag_gce_health_check" class="even">
<td><code translate="no" dir="ltr">gce_health_check</code><br />
Health Check</td>
<td>A Google Compute Engine health check.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">health_check_id</code>: Unique identifier of the health check.</td>
</tr>
<tr id="tag_gce_image" class="odd">
<td><code translate="no" dir="ltr">gce_image</code><br />
Image</td>
<td>A Google Compute Engine image resource.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">image_id</code>: Unique numerical identifier of the image.</td>
</tr>
<tr id="tag_gce_instance" class="even">
<td><code translate="no" dir="ltr">gce_instance</code><br />
VM Instance</td>
<td>A virtual machine instance hosted in Compute Engine.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">instance_id</code>: The numeric VM instance identifier assigned by Compute Engine.<br />
<code translate="no" dir="ltr">zone</code>: The Compute Engine zone in which the VM is running.</td>
</tr>
<tr id="tag_gce_instance_group" class="odd">
<td><code translate="no" dir="ltr">gce_instance_group</code><br />
Instance Group</td>
<td>A Google Compute Engine instance group resource.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">instance_group_id</code>: The unique numerical identifier of the instance group.<br />
<code translate="no" dir="ltr">instance_group_name</code>: The unique user provided name of the instance group.<br />
<code translate="no" dir="ltr">location</code>: Compute Engine zone containing the instance group.</td>
</tr>
<tr id="tag_gce_instance_group_manager" class="even">
<td><code translate="no" dir="ltr">gce_instance_group_manager</code><br />
Instance Group Manager</td>
<td>A Google Compute Engine instance group manager resource.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">instance_group_manager_id</code>: The unique numerical identifier of the instance group manager.<br />
<code translate="no" dir="ltr">instance_group_manager_name</code>: The unique user provided name of the instance group manager.<br />
<code translate="no" dir="ltr">location</code>: Compute Engine zone or region where the instance group manager is located.</td>
</tr>
<tr id="tag_gce_instance_template" class="odd">
<td><code translate="no" dir="ltr">gce_instance_template</code><br />
Instance Template</td>
<td>A Google Compute Engine instance template resource.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">instance_template_id</code>: The unique numerical identifier of the instance template.<br />
<code translate="no" dir="ltr">instance_template_name</code>: The unique user provided name of the instance template.</td>
</tr>
<tr id="tag_gce_license" class="even">
<td><code translate="no" dir="ltr">gce_license</code><br />
License</td>
<td>A Google Compute Engine license.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">license_id</code>: Unique identifier of the license.</td>
</tr>
<tr id="tag_gce_network" class="odd">
<td><code translate="no" dir="ltr">gce_network</code><br />
Network</td>
<td>A Google Compute Engine network.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">network_id</code>: Unique identifier of the network.</td>
</tr>
<tr id="tag_gce_network_endpoint_group" class="even">
<td><code translate="no" dir="ltr">gce_network_endpoint_group</code><br />
Network Endpoint Group</td>
<td>A Compute Engine network endpoint group resource.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">zone</code>: The name of the zone where the network endpoint group is located.<br />
<code translate="no" dir="ltr">network_endpoint_group_id</code>: The ID of the network endpoint group.</td>
</tr>
<tr id="tag_gce_network_region" class="odd">
<td><code translate="no" dir="ltr">gce_network_region</code><br />
Network Region</td>
<td>A region of a Compute Engine network.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">network_id</code>: The ID of the Compute Engine network.<br />
<code translate="no" dir="ltr">region</code>: The name of the network region.</td>
</tr>
<tr id="tag_gce_node_group" class="even">
<td><code translate="no" dir="ltr">gce_node_group</code><br />
Node Group</td>
<td>A Compute Engine node group.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">node_group_id</code>: Unique identifier of the node group.<br />
<code translate="no" dir="ltr">zone</code>: Zone of the node group.</td>
</tr>
<tr id="tag_gce_node_template" class="odd">
<td><code translate="no" dir="ltr">gce_node_template</code><br />
Node Template</td>
<td>A Compute Engine node template.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">node_template_id</code>: Unique identifier of the node template.<br />
<code translate="no" dir="ltr">region</code>: Region of the node template.</td>
</tr>
<tr id="tag_gce_operation" class="even">
<td><code translate="no" dir="ltr">gce_operation</code><br />
Operation</td>
<td>A Google Compute Engine operation resource.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">operation_name</code>: The unique user provided name of the operation.<br />
<code translate="no" dir="ltr">location</code>: Location of the resource.</td>
</tr>
<tr id="tag_gce_packet_mirroring" class="odd">
<td><code translate="no" dir="ltr">gce_packet_mirroring</code><br />
Packet Mirroring</td>
<td>A Google Compute Engine packet mirroring.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">packet_mirroring_id</code>: Unique identifier of the packet mirroring.<br />
<code translate="no" dir="ltr">region</code>: Region of the packet mirroring.</td>
</tr>
<tr id="tag_gce_project" class="even">
<td><code translate="no" dir="ltr">gce_project</code><br />
Project</td>
<td>A Google Compute Engine project resource.<br />
<code translate="no" dir="ltr">project_id</code>: Compute Engine specific numeric identifier of the project resource.</td>
</tr>
<tr id="tag_gce_reserved_address" class="odd">
<td><code translate="no" dir="ltr">gce_reserved_address</code><br />
Reserved Address</td>
<td>A Google Compute Engine reserved address.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">reserved_address_id</code>: Unique identifier of the reserved address.<br />
<code translate="no" dir="ltr">location</code>: Global or Compute Engine region containing the reserved address</td>
</tr>
<tr id="tag_gce_resource_policy" class="even">
<td><code translate="no" dir="ltr">gce_resource_policy</code><br />
Resource Policy</td>
<td>A Compute Engine resource policy.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">resource_policy_id</code>: Unique identifier of the resource policy.<br />
<code translate="no" dir="ltr">region</code>: Region of the resource policy.</td>
</tr>
<tr id="tag_gce_route" class="odd">
<td><code translate="no" dir="ltr">gce_route</code><br />
Route</td>
<td>A Google Compute Engine route.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">route_id</code>: Unique identifier of the route.</td>
</tr>
<tr id="tag_gce_router" class="even">
<td><code translate="no" dir="ltr">gce_router</code><br />
Router</td>
<td>A Google Compute Engine router.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">router_id</code>: Unique identifier of the router.<br />
<code translate="no" dir="ltr">region</code>: Region of the router.</td>
</tr>
<tr id="tag_gce_service_attachment" class="odd">
<td><code translate="no" dir="ltr">gce_service_attachment</code><br />
Service Attachment</td>
<td>A Private Service Connect Service Attachment.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">region</code>: The region where the service attachment resides.<br />
<code translate="no" dir="ltr">service_attachment_id</code>: Unique identifier of the service attachment.</td>
</tr>
<tr id="tag_gce_snapshot" class="even">
<td><code translate="no" dir="ltr">gce_snapshot</code><br />
Snapshot</td>
<td>A Google Compute Engine snapshot.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">snapshot_id</code>: Unique identifier of the snapshot.</td>
</tr>
<tr id="tag_gce_ssl_certificate" class="odd">
<td><code translate="no" dir="ltr">gce_ssl_certificate</code><br />
SSL Certificate</td>
<td>A Google Compute Engine SSL certificate.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">ssl_certificate_id</code>: The unique numerical identifier of the SSL certificate.<br />
<code translate="no" dir="ltr">ssl_certificate_name</code>: The unique user provided name of the SSL Certificate.</td>
</tr>
<tr id="tag_gce_subnetwork" class="even">
<td><code translate="no" dir="ltr">gce_subnetwork</code><br />
Subnetwork</td>
<td>A Compute Engine subnetwork.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">subnetwork_id</code>: The unique numerical identifier of the subnetwork.<br />
<code translate="no" dir="ltr">subnetwork_name</code>: The unique user provided name of the subnetwork.<br />
<code translate="no" dir="ltr">location</code>: Location of the resource.</td>
</tr>
<tr id="tag_gce_target_http_instance" class="odd">
<td><code translate="no" dir="ltr">gce_target_http_instance</code><br />
Target HTTP Instance</td>
<td>A Google Compute Engine target http instance.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">target_http_instance_id</code>: Unique identifier of the target http instance.<br />
<code translate="no" dir="ltr">zone</code>: Compute Engine zone where the target http instance resides.</td>
</tr>
<tr id="tag_gce_target_http_proxy" class="even">
<td><code translate="no" dir="ltr">gce_target_http_proxy</code><br />
Target HTTP Proxy</td>
<td>A Google Compute Engine target http proxy.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">target_http_proxy_id</code>: Unique identifier of the target http proxy.</td>
</tr>
<tr id="tag_gce_target_https_proxy" class="odd">
<td><code translate="no" dir="ltr">gce_target_https_proxy</code><br />
Target HTTPS Proxy</td>
<td>A Google Compute Engine target https proxy.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">target_https_proxy_id</code>: Unique identifier of the target https proxy.</td>
</tr>
<tr id="tag_gce_target_pool" class="even">
<td><code translate="no" dir="ltr">gce_target_pool</code><br />
Target Pool</td>
<td>A Google Compute Engine target pool.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">target_pool_id</code>: Unique identifier of the target pool.<br />
<code translate="no" dir="ltr">zone</code>: Compute Engine zone where the pool resides.</td>
</tr>
<tr id="tag_gce_target_ssl_proxy" class="odd">
<td><code translate="no" dir="ltr">gce_target_ssl_proxy</code><br />
Target SSL Proxy</td>
<td>A Google Compute Engine target SSL proxy.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">target_ssl_proxy_id</code>: Unique identifier of the target ssl proxy.</td>
</tr>
<tr id="tag_gce_url_map" class="even">
<td><code translate="no" dir="ltr">gce_url_map</code><br />
URL Map</td>
<td>A Google Compute Engine URL map.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">url_map_id</code>: Unique identifier of the url map.</td>
</tr>
<tr id="tag_gcs_bucket" class="odd">
<td><code translate="no" dir="ltr">gcs_bucket</code><br />
GCS Bucket</td>
<td>A Google Cloud Storage (GCS) bucket.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">bucket_name</code>: An immutable name of the bucket.<br />
<code translate="no" dir="ltr">location</code>: Location of the bucket.</td>
</tr>
<tr id="tag_geminidataanalytics.googleapis.com/Location" class="even">
<td><code translate="no" dir="ltr">geminidataanalytics.googleapis.com/Location</code><br />
Gemini Data Analytics Location</td>
<td>A Gemini Data Analytics Location.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The location of the GCP project associated with this resource.</td>
</tr>
<tr id="tag_generic_node" class="odd">
<td><code translate="no" dir="ltr">generic_node</code><br />
Generic Node</td>
<td>A generic node identifies a machine or other computational resource for which no more specific resource type is applicable. The label values must uniquely identify the node.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">location</code>: The Google Cloud region or zone that determines where data about the resource is stored. For example, "us-east1-a".<br />
<code translate="no" dir="ltr">namespace</code>: A namespace identifier, such as a cluster name.<br />
<code translate="no" dir="ltr">node_id</code>: A unique identifier for the node within the namespace, such as a hostname or IP address.</td>
</tr>
<tr id="tag_generic_task" class="even">
<td><code translate="no" dir="ltr">generic_task</code><br />
Generic Task</td>
<td>A generic task identifies an application process for which no more specific resource is applicable, such as a process scheduled by a custom orchestration system. The label values must uniquely identify the task.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">location</code>: The Google Cloud region or zone that determines where data about the resource is stored. For example, "us-east1-a".<br />
<code translate="no" dir="ltr">namespace</code>: A namespace identifier, such as a cluster name.<br />
<code translate="no" dir="ltr">job</code>: An identifier for a grouping of related tasks, such as the name of a microservice or distributed batch job.<br />
<code translate="no" dir="ltr">task_id</code>: A unique identifier for the task within the namespace and job, such as a replica index identifying the task within the job.</td>
</tr>
<tr id="tag_genomics_dataset" class="odd">
<td><code translate="no" dir="ltr">genomics_dataset</code><br />
Genomics Dataset</td>
<td>A dataset in the Google Genomics service.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">dataset_id</code>: Unique identifier of the dataset.</td>
</tr>
<tr id="tag_genomics_operation" class="even">
<td><code translate="no" dir="ltr">genomics_operation</code><br />
Genomics Operation</td>
<td>A long running operation in the Google Genomics service.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">operation_id</code>: Unique identifier of the long running operation.</td>
</tr>
<tr id="tag_gke_cluster" class="odd">
<td><code translate="no" dir="ltr">gke_cluster</code><br />
GKE Cluster Operations</td>
<td>A Google Kubernetes Engine (GKE) Cluster. It contains events and audit logs about cluster operations.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">cluster_name</code>: The name of the GKE Cluster.<br />
<code translate="no" dir="ltr">location</code>: The location in which the GKE Cluster is running.</td>
</tr>
<tr id="tag_gke_nodepool" class="even">
<td><code translate="no" dir="ltr">gke_nodepool</code><br />
GKE Node Pool Operations</td>
<td>A Google Kubernetes Engine (GKE) Node Pool. It contains audit logs about Node Pool operations.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">nodepool_name</code>: The name of the GKE Node Pool.<br />
<code translate="no" dir="ltr">location</code>: The location in which the GKE Cluster is running.<br />
<code translate="no" dir="ltr">cluster_name</code>: The name of the GKE Cluster to which this Node Pool belongs.</td>
</tr>
<tr id="tag_gkebackup.googleapis.com/BackupPlan" class="odd">
<td><code translate="no" dir="ltr">gkebackup.googleapis.com/BackupPlan</code><br />
GKE Backup Plan</td>
<td>A backup plan provides configuration, location, and management functions for a sequence of backups.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the Google Cloud container associated with the resource.<br />
<code translate="no" dir="ltr">location</code>: The Google Cloud location where this backupPlan resides.<br />
<code translate="no" dir="ltr">backup_plan_id</code>: The name of the backupPlan.</td>
</tr>
<tr id="tag_gkebackup.googleapis.com/RestorePlan" class="even">
<td><code translate="no" dir="ltr">gkebackup.googleapis.com/RestorePlan</code><br />
GKE Restore Plan</td>
<td>A restore plan defines the configuration of a series of restore operations to be performed against backups which belong to the specified backup plan.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the Google Cloud container associated with the resource.<br />
<code translate="no" dir="ltr">location</code>: The Google Cloud location where this restorePlan resides.<br />
<code translate="no" dir="ltr">restore_plan_id</code>: The name of the restorePlan.</td>
</tr>
<tr id="tag_global" class="odd">
<td><code translate="no" dir="ltr">global</code><br />
Global</td>
<td>A resource type used to indicate that a log is not associated with any specific resource.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".</td>
</tr>
<tr id="tag_health.googleapis.com/Subscriber" class="even">
<td><code translate="no" dir="ltr">health.googleapis.com/Subscriber</code><br />
Health API Subscriber</td>
<td>A subscriber of the Google Health API to receive data change notifications.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The location of the resource.<br />
<code translate="no" dir="ltr">subscriber_id</code>: The identifier of the subscriber which is unique per GCP Project.</td>
</tr>
<tr id="tag_healthcare_pipeline_job" class="odd">
<td><code translate="no" dir="ltr">healthcare_pipeline_job</code><br />
Healthcare Pipeline Job</td>
<td>A Cloud Healthcare Pipeline Job.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">location</code>: The Google Cloud location of the dataset that contains the Pipeline Job.<br />
<code translate="no" dir="ltr">dataset_id</code>: The ID of the dataset.<br />
<code translate="no" dir="ltr">pipeline_job_id</code>: The ID of the Pipeline Job.</td>
</tr>
<tr id="tag_http_external_regional_lb_rule" class="even">
<td><code translate="no" dir="ltr">http_external_regional_lb_rule</code><br />
Regional External Application Load Balancer Rule</td>
<td>A resource descriptor for regional external Application Load Balancer behavior.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the Google Cloud project associated with this resource, such as 'my-project'.<br />
<code translate="no" dir="ltr">network_name</code>: The name of the customer network in which the Load Balancer resides.<br />
<code translate="no" dir="ltr">region</code>: The region under which the Load Balancer is defined.<br />
<code translate="no" dir="ltr">url_map_name</code>: The name of the urlmap.<br />
<code translate="no" dir="ltr">forwarding_rule_name</code>: The name of the forwarding rule.<br />
<code translate="no" dir="ltr">target_proxy_name</code>: The name of the target HTTP/S proxy.<br />
<code translate="no" dir="ltr">matched_url_path_rule</code>: The prefix of URL defined in urlmap tree. 'UNMATCHED' for the sink default rule.<br />
<code translate="no" dir="ltr">backend_target_name</code>: The name of the backend target or service.<br />
<code translate="no" dir="ltr">backend_target_type</code>: The type of the backend target. Can be 'BACKEND_SERVICE', or 'UNKNOWN' if the backend wasn't assigned.<br />
<code translate="no" dir="ltr">backend_name</code>: The name of the backend group. Can be '' if the backend wasn't assigned.<br />
<code translate="no" dir="ltr">backend_type</code>: The type of the backend group. Can be 'INSTANCE_GROUP', 'NETWORK_ENDPOINT_GROUP', or 'UNKNOWN' if the backend wasn't assigned.<br />
<code translate="no" dir="ltr">backend_scope</code>: The scope of the backend group. Can be 'UNKNOWN' if the backend wasn't assigned.<br />
<code translate="no" dir="ltr">backend_scope_type</code>: The type of the scope of the backend group. Can be 'ZONE', 'REGION', or 'UNKNOWN' in case the backend wasn't assigned.</td>
</tr>
<tr id="tag_http_load_balancer" class="odd">
<td><code translate="no" dir="ltr">http_load_balancer</code><br />
Application Load Balancer</td>
<td>An Application Load Balancer Instance.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">forwarding_rule_name</code>: The name of the forwarding rule.<br />
<code translate="no" dir="ltr">url_map_name</code>: The name of the urlmap.<br />
<code translate="no" dir="ltr">target_proxy_name</code>: The name of the target proxy.<br />
<code translate="no" dir="ltr">backend_service_name</code>: The name of the backend service.<br />
<code translate="no" dir="ltr">zone</code>: The zone in which the load balancer is running.</td>
</tr>
<tr id="tag_iam.googleapis.com/WorkforcePoolProvider" class="even">
<td><code translate="no" dir="ltr">iam.googleapis.com/WorkforcePoolProvider</code><br />
Workforce Identity Pool Provider</td>
<td>A workforce identity pool provider.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the Google Cloud organization associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The location of the resource.<br />
<code translate="no" dir="ltr">pool_id</code>: The ID of the provider's workforce pool parent resource.<br />
<code translate="no" dir="ltr">provider_id</code>: The ID of the workforce pool provider resource.</td>
</tr>
<tr id="tag_iam_role" class="odd">
<td><code translate="no" dir="ltr">iam_role</code><br />
IAM Role</td>
<td>An IAM role.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">role_name</code>: The name of the IAM custom role; this labelappears only on custom roles.(e.g., roles/[CUSTOM_ROLE],organizations/123456/roles/[CUSTOM_ROLE],projects/myproject/roles/[CUSTOM_ROLE]).</td>
</tr>
<tr id="tag_identitytoolkit_project" class="even">
<td><code translate="no" dir="ltr">identitytoolkit_project</code><br />
Project</td>
<td>An Identity Toolkit project.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource.</td>
</tr>
<tr id="tag_identitytoolkit_tenant" class="odd">
<td><code translate="no" dir="ltr">identitytoolkit_tenant</code><br />
Identity Toolkit Tenant</td>
<td>An Identity Toolkit tenant.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource.<br />
<code translate="no" dir="ltr">tenant_name</code>: The name of the tenant.</td>
</tr>
<tr id="tag_ids.googleapis.com/Endpoint" class="even">
<td><code translate="no" dir="ltr">ids.googleapis.com/Endpoint</code><br />
IDS Endpoint</td>
<td>A Cloud IDS Endpoint.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP project owning the Endpoint.<br />
<code translate="no" dir="ltr">location</code>: The zone of the IDS Endpoint.<br />
<code translate="no" dir="ltr">id</code>: The ID of the Endpoint.</td>
</tr>
<tr id="tag_integrations.googleapis.com/IntegrationVersion" class="odd">
<td><code translate="no" dir="ltr">integrations.googleapis.com/IntegrationVersion</code><br />
Integration Version</td>
<td>An integration version to be executed.<br />
<code translate="no" dir="ltr">resource_container</code>: The project id.<br />
<code translate="no" dir="ltr">location</code>: The location value.<br />
<code translate="no" dir="ltr">product</code>: The product value.<br />
<code translate="no" dir="ltr">integration</code>: The integration name.<br />
<code translate="no" dir="ltr">version</code>: The version id of the integration.</td>
</tr>
<tr id="tag_interconnect" class="even">
<td><code translate="no" dir="ltr">interconnect</code><br />
Interconnect</td>
<td>A physical connection to Google at a datacenter.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">interconnect</code>: The unique identifier of the interconnect.</td>
</tr>
<tr id="tag_interconnect_attachment" class="odd">
<td><code translate="no" dir="ltr">interconnect_attachment</code><br />
Interconnect Attachment</td>
<td>A VLAN attaching a cloud network to an Interconnect.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">attachment</code>: The unique identifier of the attachment.<br />
<code translate="no" dir="ltr">interconnect</code>: The unique identifier of the interconnect that the attachment connects to.<br />
<code translate="no" dir="ltr">region</code>: The cloud region that the attachment connects to.<br />
<code translate="no" dir="ltr">interconnect_project</code>: The name of the project that owns interconnect that the attachment connects to.</td>
</tr>
<tr id="tag_internal_http_lb_rule" class="even">
<td><code translate="no" dir="ltr">internal_http_lb_rule</code><br />
Internal Application Load Balancer Rule</td>
<td>A resource descriptor for internal Application Load Balancer behavior.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the Google Cloud project associated with this resource, such as 'my-project'.<br />
<code translate="no" dir="ltr">network_name</code>: The name of the customer network in which the Load Balancer resides.<br />
<code translate="no" dir="ltr">region</code>: The region under which the Load Balancer is defined.<br />
<code translate="no" dir="ltr">url_map_name</code>: The name of the urlmap.<br />
<code translate="no" dir="ltr">forwarding_rule_name</code>: The name of the forwarding rule.<br />
<code translate="no" dir="ltr">target_proxy_name</code>: The name of the target HTTP(S) proxy.<br />
<code translate="no" dir="ltr">matched_url_path_rule</code>: The prefix of URL defined in urlmap tree. 'UNMATCHED' for the sink default rule.<br />
<code translate="no" dir="ltr">backend_target_name</code>: The name of the backend target or service.<br />
<code translate="no" dir="ltr">backend_target_type</code>: The type of the backend target. Can be 'BACKEND_SERVICE', or 'UNKNOWN' if the backend wasn't assigned.<br />
<code translate="no" dir="ltr">backend_name</code>: The name of the backend group. Can be '' if the backend wasn't assigned.<br />
<code translate="no" dir="ltr">backend_type</code>: The type of the backend group. Can be 'INSTANCE_GROUP', 'NETWORK_ENDPOINT_GROUP', or 'UNKNOWN' if the backend wasn't assigned.<br />
<code translate="no" dir="ltr">backend_scope</code>: The scope of the backend group. Can be 'UNKNOWN' if the backend wasn't assigned.<br />
<code translate="no" dir="ltr">backend_scope_type</code>: The type of the scope of the backend group. Can be 'ZONE', 'REGION', or 'UNKNOWN' in case the backend wasn't assigned.</td>
</tr>
<tr id="tag_istio_control_plane" class="odd">
<td><code translate="no" dir="ltr">istio_control_plane</code><br />
Istio Control Plane</td>
<td>An Istio Control Plane is an instance of a service that provides xDS and related functionality to a set of managed Istio proxies.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">mesh_uid</code>: Unique identifier for an Istio service mesh.<br />
<code translate="no" dir="ltr">location</code>: The physical location in which the workload for the Control Plane is located.<br />
<code translate="no" dir="ltr">revision</code>: Immutable revision of Istio managed by the Control Plane.<br />
<code translate="no" dir="ltr">build_id</code>: Immutable build tag for the instance of the Control Plane.<br />
<code translate="no" dir="ltr">owner</code>: Immutable name of the owner of the Control Plane.</td>
</tr>
<tr id="tag_k8s_cluster" class="even">
<td><code translate="no" dir="ltr">k8s_cluster</code><br />
Kubernetes Cluster</td>
<td>A Kubernetes cluster. It contains Kubernetes audit logs from the cluster.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">location</code>: The physical location of the cluster.<br />
<code translate="no" dir="ltr">cluster_name</code>: The name of the cluster.</td>
</tr>
<tr id="tag_k8s_container" class="odd">
<td><code translate="no" dir="ltr">k8s_container</code><br />
Kubernetes Container</td>
<td>A Kubernetes container instance.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">location</code>: The physical location of the cluster that contains the container.<br />
<code translate="no" dir="ltr">cluster_name</code>: The name of the cluster that the container is running in.<br />
<code translate="no" dir="ltr">namespace_name</code>: The name of the namespace that the container is running in.<br />
<code translate="no" dir="ltr">pod_name</code>: The name of the pod that the container is running in.<br />
<code translate="no" dir="ltr">container_name</code>: The name of the container.</td>
</tr>
<tr id="tag_k8s_control_plane_component" class="even">
<td><code translate="no" dir="ltr">k8s_control_plane_component</code><br />
Kubernetes Control Plane Component</td>
<td>A Kubernetes Control Plane component.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">location</code>: The physical location of the cluster that contains the control plane component.<br />
<code translate="no" dir="ltr">cluster_name</code>: The name of the cluster that the control plane component is running in.<br />
<code translate="no" dir="ltr">component_name</code>: The name of the control plane component.<br />
<code translate="no" dir="ltr">component_location</code>: The physical location where the control plane component is running.</td>
</tr>
<tr id="tag_k8s_node" class="odd">
<td><code translate="no" dir="ltr">k8s_node</code><br />
Kubernetes Node</td>
<td>A Kubernetes node instance.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">location</code>: The physical location of the cluster that contains the node.<br />
<code translate="no" dir="ltr">cluster_name</code>: The name of the cluster that the node is a part of.<br />
<code translate="no" dir="ltr">node_name</code>: The name of the node.</td>
</tr>
<tr id="tag_k8s_pod" class="even">
<td><code translate="no" dir="ltr">k8s_pod</code><br />
Kubernetes Pod</td>
<td>A Kubernetes pod instance.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">location</code>: The physical location of the cluster that contains the pod.<br />
<code translate="no" dir="ltr">cluster_name</code>: The name of the cluster that the pod is running in.<br />
<code translate="no" dir="ltr">namespace_name</code>: The name of the namespace that the pod is running in.<br />
<code translate="no" dir="ltr">pod_name</code>: The name of the pod.</td>
</tr>
<tr id="tag_k8s_service" class="odd">
<td><code translate="no" dir="ltr">k8s_service</code><br />
Kubernetes Service</td>
<td>A Kubernetes Service instance.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">location</code>: The physical location of the cluster that contains the service.<br />
<code translate="no" dir="ltr">cluster_name</code>: The name of the cluster that the service is running in.<br />
<code translate="no" dir="ltr">namespace_name</code>: The name of the namespace that the service is running in.<br />
<code translate="no" dir="ltr">service_name</code>: The name of the service.</td>
</tr>
<tr id="tag_l4_proxy_rule" class="even">
<td><code translate="no" dir="ltr">l4_proxy_rule</code><br />
Proxy Network Load Balancer Rule</td>
<td>A resource descriptor for proxy Network Load Balancer behavior.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the Google Cloud project associated with this resource, such as 'my-project'.<br />
<code translate="no" dir="ltr">network_name</code>: The name of the customer network in which the Load Balancer resides.<br />
<code translate="no" dir="ltr">region</code>: The region under which the Load Balancer is defined.<br />
<code translate="no" dir="ltr">load_balancing_scheme</code>: The load balancing scheme associated with the forwarding rule, one of [INTERNAL_MANAGED, EXTERNAL_MANAGED].<br />
<code translate="no" dir="ltr">protocol</code>: The protocol associated with the traffic processed by the proxy, one of [TCP, UDP, SSL, UNKNOWN].<br />
<code translate="no" dir="ltr">forwarding_rule_name</code>: The name of the forwarding rule.<br />
<code translate="no" dir="ltr">target_proxy_name</code>: The name of the target proxy.<br />
<code translate="no" dir="ltr">backend_target_name</code>: The name of the backend target or service.<br />
<code translate="no" dir="ltr">backend_target_type</code>: The type of the backend target, one of ['BACKEND_SERVICE'; 'UNKNOWN' - if the backend wasn't assigned].<br />
<code translate="no" dir="ltr">backend_name</code>: The name of the backend group. Can be '' if the backend wasn't assigned.<br />
<code translate="no" dir="ltr">backend_type</code>: The type of the backend group, one of ['INSTANCE_GROUP'; 'NETWORK_ENDPOINT_GROUP'; 'UNKNOWN' - if the backend wasn't assigned].<br />
<code translate="no" dir="ltr">backend_scope</code>: The scope of the backend group. Can be 'UNKNOWN' if the backend wasn't assigned.<br />
<code translate="no" dir="ltr">backend_scope_type</code>: The type of the scope of the backend group, one of ['ZONE'; 'REGION'; 'UNKNOWN' - in case the backend wasn't assigned].</td>
</tr>
<tr id="tag_livestream.googleapis.com/Channel" class="odd">
<td><code translate="no" dir="ltr">livestream.googleapis.com/Channel</code><br />
Live Stream API Channel</td>
<td>A Live Stream API Channel.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP project associated with this channel resource.<br />
<code translate="no" dir="ltr">location</code>: The GCP location where the channel resource resides.<br />
<code translate="no" dir="ltr">channel_id</code>: ID of the channel resource.</td>
</tr>
<tr id="tag_loadbalancing.googleapis.com/ExternalNetworkLoadBalancerRule" class="even">
<td><code translate="no" dir="ltr">loadbalancing.googleapis.com/ExternalNetworkLoadBalancerRule</code><br />
External Passthrough Network Load Balancer Rule</td>
<td>A set of definitions for multi protocol network load balancing behavior.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">region</code>: The Google Cloud Platform region of the backend instance that connected to network load balancing forwarding rule.<br />
<code translate="no" dir="ltr">backend_network_name</code>: The network name of the NIC of the instance that received the Net LB flow.<br />
<code translate="no" dir="ltr">backend_target_type</code>: The type of the backend target that handled the connection.<br />
<code translate="no" dir="ltr">backend_service_name</code>: The name of the backend service that handled the connection.<br />
<code translate="no" dir="ltr">primary_target_pool</code>: The name of the primary target pool.<br />
<code translate="no" dir="ltr">target_pool</code>: The name of the target pool.<br />
<code translate="no" dir="ltr">forwarding_rule_name</code>: The name of the forwarding rule.<br />
<code translate="no" dir="ltr">backend_group_name</code>: The name of the backend group that handled the connection.<br />
<code translate="no" dir="ltr">backend_group_type</code>: The type of the backend group that handled the connection.<br />
<code translate="no" dir="ltr">backend_group_scope</code>: The scope (zone or region) of the backend group that handled the connection.<br />
<code translate="no" dir="ltr">backend_subnetwork_name</code>: The name of the subnetwork of the instance that handled the connection.<br />
<code translate="no" dir="ltr">backend_zone</code>: The zone of the endpoint (VM instance) that handled the connection.</td>
</tr>
<tr id="tag_loadbalancing.googleapis.com/InternalNetworkLoadBalancerRule" class="odd">
<td><code translate="no" dir="ltr">loadbalancing.googleapis.com/InternalNetworkLoadBalancerRule</code><br />
Internal Passthrough Network Load Balancer Rule</td>
<td>A set of definitions for multi protocol internal load balancing behavior.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">region</code>: The Google Cloud Platform region of the backend instance that connected to network load balancing forwarding rule.<br />
<code translate="no" dir="ltr">backend_network_name</code>: The network name of the NIC of the instance that received the Net LB flow.<br />
<code translate="no" dir="ltr">backend_service_name</code>: The name of the backend service that handled the connection.<br />
<code translate="no" dir="ltr">forwarding_rule_name</code>: The name of the forwarding rule.<br />
<code translate="no" dir="ltr">backend_group_name</code>: The name of the backend group that handled the connection.<br />
<code translate="no" dir="ltr">backend_group_type</code>: The type of the backend group that handled the connection.<br />
<code translate="no" dir="ltr">backend_group_scope</code>: The scope (zone or region) of the backend group that handled the connection.<br />
<code translate="no" dir="ltr">backend_subnetwork_name</code>: The name of the subnetwork of the instance that handled the connection.</td>
</tr>
<tr id="tag_logging_bucket" class="even">
<td><code translate="no" dir="ltr">logging_bucket</code><br />
Logging Bucket</td>
<td>An export bucket in Cloud Logging.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">bucket_id</code>: The name of the log bucket.<br />
<code translate="no" dir="ltr">location</code>: The location of the log bucket.<br />
<code translate="no" dir="ltr">source_resource_container</code>: The source resource container (e.g. project, folder, organization) of the log entry that is destined for the log bucket. The format is "projects/project_id"<br />
<code translate="no" dir="ltr">monitored_resource_type</code>: The type field of the monitored resource in the log entry that is destined for the log bucket.</td>
</tr>
<tr id="tag_logging_exclusion" class="odd">
<td><code translate="no" dir="ltr">logging_exclusion</code><br />
Log Exclusion</td>
<td>An exclusion in Cloud Logging.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">name</code>: The unique name of the exclusion.</td>
</tr>
<tr id="tag_logging_log" class="even">
<td><code translate="no" dir="ltr">logging_log</code><br />
Log stream</td>
<td>A Google Cloud Logging log.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">name</code>: Unique identifier of the log.</td>
</tr>
<tr id="tag_logging_sink" class="odd">
<td><code translate="no" dir="ltr">logging_sink</code><br />
Logging export sink</td>
<td>An export sink in Cloud Logging.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">name</code>: The unique name of the sink.<br />
<code translate="no" dir="ltr">destination</code>: The destination of the sink.</td>
</tr>
<tr id="tag_lustre.googleapis.com/Instance" class="even">
<td><code translate="no" dir="ltr">lustre.googleapis.com/Instance</code><br />
Lustre instance</td>
<td>A Lustre Instance.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP consumer project associated with this resource, such as 'my-project'.<br />
<code translate="no" dir="ltr">location</code>: The Google Cloud location in which the managed instance is running.<br />
<code translate="no" dir="ltr">instance_id</code>: The ID of the managed instance.</td>
</tr>
<tr id="tag_managed_service" class="odd">
<td><code translate="no" dir="ltr">managed_service</code><br />
Managed Service</td>
<td>A service managed by Google Service Management.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">service_name</code>: The name of the service.<br />
<code translate="no" dir="ltr">producer_project_id</code>: The id of the project which produces and owns this service.</td>
</tr>
<tr id="tag_managedflink.googleapis.com/Deployment" class="even">
<td><code translate="no" dir="ltr">managedflink.googleapis.com/Deployment</code><br />
Managed Flink Deployment</td>
<td>A managed Flink cluster.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The location of the GCP project associated with this resource.<br />
<code translate="no" dir="ltr">deployment_id</code>: The user-specified or system generated deployment identifier.</td>
</tr>
<tr id="tag_managedflink.googleapis.com/Job" class="odd">
<td><code translate="no" dir="ltr">managedflink.googleapis.com/Job</code><br />
Managed Flink Job</td>
<td>A job running on a deployment.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The location of the GCP project associated with this resource.<br />
<code translate="no" dir="ltr">deployment_id</code>: The user-specified or system generated deployment identifier.<br />
<code translate="no" dir="ltr">job_id</code>: The system-generated job identifier.</td>
</tr>
<tr id="tag_managedkafka.googleapis.com/Cluster" class="even">
<td><code translate="no" dir="ltr">managedkafka.googleapis.com/Cluster</code><br />
Apache Kafka Cluster</td>
<td>A Managed Kafka cluster.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the project or container associated with this cluster.<br />
<code translate="no" dir="ltr">location</code>: The region in which the cluster is created.<br />
<code translate="no" dir="ltr">cluster_id</code>: The user-specified cluster id.</td>
</tr>
<tr id="tag_managedkafka.googleapis.com/ConnectCluster" class="odd">
<td><code translate="no" dir="ltr">managedkafka.googleapis.com/ConnectCluster</code><br />
Apache Kafka Connect Cluster</td>
<td>A Managed Kafka Connect cluster.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the project or container associated with this cluster.<br />
<code translate="no" dir="ltr">location</code>: The region in which the cluster is created.<br />
<code translate="no" dir="ltr">cluster_id</code>: The user-specified cluster id.</td>
</tr>
<tr id="tag_managedkafka.googleapis.com/Location" class="even">
<td><code translate="no" dir="ltr">managedkafka.googleapis.com/Location</code><br />
Apache Kafka Location</td>
<td>A Managed Kafka location.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the project or container associated with this location.<br />
<code translate="no" dir="ltr">location</code>: The location in the API.</td>
</tr>
<tr id="tag_managedkafka.googleapis.com/SchemaRegistry" class="odd">
<td><code translate="no" dir="ltr">managedkafka.googleapis.com/SchemaRegistry</code><br />
Apache Kafka Schema Registry</td>
<td>A Managed Kafka Schema Registry.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP project associated with this schema registry.<br />
<code translate="no" dir="ltr">location</code>: The region in which the schema registry is created.<br />
<code translate="no" dir="ltr">schema_registry_id</code>: The user-specified schema registry id.</td>
</tr>
<tr id="tag_memorystore.googleapis.com/Instance" class="even">
<td><code translate="no" dir="ltr">memorystore.googleapis.com/Instance</code><br />
Memorystore Instance</td>
<td>An instance hosted on Google Cloud Memorystore.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP consumer project associated with this resource, such as 'my-project'.<br />
<code translate="no" dir="ltr">location</code>: The Google Cloud region in which the managed instance is running.<br />
<code translate="no" dir="ltr">instance_id</code>: The ID of the managed instance.<br />
<code translate="no" dir="ltr">instance_uid</code>: Identifier assigned by Google to uniquely distinguish an instance.</td>
</tr>
<tr id="tag_mesh" class="odd">
<td><code translate="no" dir="ltr">mesh</code><br />
Mesh</td>
<td>A mesh serves as the "key" to deliver configuration to data plane proxy instances.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">location</code>: The location of the control plane<br />
<code translate="no" dir="ltr">mesh</code>: The name of the mesh</td>
</tr>
<tr id="tag_metastore.googleapis.com/Federation" class="even">
<td><code translate="no" dir="ltr">metastore.googleapis.com/Federation</code><br />
Dataproc Metastore Federation</td>
<td>A Dataproc Metastore Federation.<br />
<code translate="no" dir="ltr">resource_container</code>: The ID of the customer project.<br />
<code translate="no" dir="ltr">location</code>: The region that the federation is hosted in.<br />
<code translate="no" dir="ltr">federation_id</code>: The federation ID.</td>
</tr>
<tr id="tag_metastore.googleapis.com/Service" class="odd">
<td><code translate="no" dir="ltr">metastore.googleapis.com/Service</code><br />
Dataproc Metastore Service</td>
<td>A Dataproc Metastore Service.<br />
<code translate="no" dir="ltr">resource_container</code>: The ID of the customer project.<br />
<code translate="no" dir="ltr">location</code>: The region that the service is hosted in.<br />
<code translate="no" dir="ltr">service_id</code>: The service ID.</td>
</tr>
<tr id="tag_metric" class="even">
<td><code translate="no" dir="ltr">metric</code><br />
Metric Type</td>
<td>A Stackdriver Monitoring metric type.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">name</code>: The name of the metric type, such as "logging.googleapis.com/my-metric-name".</td>
</tr>
<tr id="tag_microsoft_ad_domain" class="odd">
<td><code translate="no" dir="ltr">microsoft_ad_domain</code><br />
Microsoft Active Directory Domain</td>
<td>A Microsoft Active Directory Domain hosted and managed by Google Cloud Platform<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">fqdn</code>: The fully qualified domain name of the Active Directory Domain<br />
<code translate="no" dir="ltr">location</code>: The location where Active Directory Domain resources (like VMs, etc.) are present.</td>
</tr>
<tr id="tag_ml_job" class="even">
<td><code translate="no" dir="ltr">ml_job</code><br />
Cloud ML Job</td>
<td>A Cloud Machine Learning job.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">job_id</code>: The job identifier.<br />
<code translate="no" dir="ltr">task_name</code>: The task name.</td>
</tr>
<tr id="tag_mobilitybilling.googleapis.com/Project" class="odd">
<td><code translate="no" dir="ltr">mobilitybilling.googleapis.com/Project</code><br />
Google Maps Platform - Mobility Billing</td>
<td>A top-level resource for Mobility Billing metrics and logs.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP container associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The region in which the Mobility Billing instance is running.</td>
</tr>
<tr id="tag_modelarmor.googleapis.com/SanitizeOperation" class="even">
<td><code translate="no" dir="ltr">modelarmor.googleapis.com/SanitizeOperation</code><br />
Model Armor Sanitize Operation</td>
<td>A resource that represents the Model Armor sanitize operations.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP resource container associated with this resource, such as "my_project" or "organizations/5678".<br />
<code translate="no" dir="ltr">location</code>: The GCP location.<br />
<code translate="no" dir="ltr">template_id</code>: The template ID.</td>
</tr>
<tr id="tag_modelarmor.googleapis.com/Template" class="odd">
<td><code translate="no" dir="ltr">modelarmor.googleapis.com/Template</code><br />
Model Armor Template</td>
<td>A resource that represents the Model Armor template operations.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP resource container associated with this resource, such as "my_project" or "organizations/5678".<br />
<code translate="no" dir="ltr">location</code>: The GCP location.<br />
<code translate="no" dir="ltr">template_id</code>: The template ID.</td>
</tr>
<tr id="tag_nat_gateway" class="even">
<td><code translate="no" dir="ltr">nat_gateway</code><br />
Cloud NAT Gateway</td>
<td>A Cloud NAT Gateway.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">region</code>: The region where the NAT gateway is located.<br />
<code translate="no" dir="ltr">router_id</code>: Identifier of the router under which the NAT gateway is defined.<br />
<code translate="no" dir="ltr">gateway_name</code>: The name of the NAT gateway.</td>
</tr>
<tr id="tag_netapp.googleapis.com/StoragePool" class="odd">
<td><code translate="no" dir="ltr">netapp.googleapis.com/StoragePool</code><br />
Google Cloud NetApp Volumes StoragePool</td>
<td>Google Cloud NetApp Volumes StoragePool.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: StoragePool region/zone.<br />
<code translate="no" dir="ltr">name</code>: Name of the storage pool.</td>
</tr>
<tr id="tag_netapp_cloud_volume" class="even">
<td><code translate="no" dir="ltr">netapp_cloud_volume</code><br />
NetApp Cloud Volume</td>
<td>A specific volume in the NetApp Cloud Volumes service.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">location</code>: The Google Cloud location in which the NetApp Cloud Volume instance is running.<br />
<code translate="no" dir="ltr">volume_id</code>: The ID of a NetApp Volume.</td>
</tr>
<tr id="tag_network_security_policy" class="odd">
<td><code translate="no" dir="ltr">network_security_policy</code><br />
Network Security Policy</td>
<td>A network security policy.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">location</code>: The region where the security policy resides. For global security policies this is "global".<br />
<code translate="no" dir="ltr">policy_name</code>: The unique user provided name of the security policy.</td>
</tr>
<tr id="tag_networkactions.googleapis.com/WasmPluginVersion" class="even">
<td><code translate="no" dir="ltr">networkactions.googleapis.com/WasmPluginVersion</code><br />
Media CDN Wasm Plugin Version</td>
<td>A single immutable version of a Media CDN WasmPlugin (code + runtime config).<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The location of this service. Only 'global' is allowed.<br />
<code translate="no" dir="ltr">plugin_name</code>: The name of the WasmPlugin.<br />
<code translate="no" dir="ltr">plugin_version</code>: The name of the WasmPluginVersion.</td>
</tr>
<tr id="tag_networking.googleapis.com/Location" class="odd">
<td><code translate="no" dir="ltr">networking.googleapis.com/Location</code><br />
GCP Location</td>
<td>A GCP location: a specific zone or region, or "global".<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">location</code>: Name of a GCP zone/region, or "global".</td>
</tr>
<tr id="tag_networkmanagement.googleapis.com/MonitoringPoint" class="even">
<td><code translate="no" dir="ltr">networkmanagement.googleapis.com/MonitoringPoint</code><br />
Monitoring Point</td>
<td>A Monitoring Point in Cloud Network insights.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP resource container associated with this resource, such as "projects/123456789".<br />
<code translate="no" dir="ltr">location</code>: The location of the Monitoring Point resource.<br />
<code translate="no" dir="ltr">network_monitoring_provider_id</code>: Identifier of the network monitoring provider.<br />
<code translate="no" dir="ltr">monitoring_point_id</code>: Identifier of the Monitoring Point.</td>
</tr>
<tr id="tag_networkmanagement.googleapis.com/NetworkPath" class="odd">
<td><code translate="no" dir="ltr">networkmanagement.googleapis.com/NetworkPath</code><br />
Network Path</td>
<td>A Network Path in Cloud Network insights.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP resource container associated with this resource, such as "projects/123456789".<br />
<code translate="no" dir="ltr">location</code>: The location of the NetworkPath resource.<br />
<code translate="no" dir="ltr">network_monitoring_provider_id</code>: Identifier of the network monitoring provider.<br />
<code translate="no" dir="ltr">path_id</code>: Identifier of the network path.</td>
</tr>
<tr id="tag_networkmanagement.googleapis.com/WebPath" class="even">
<td><code translate="no" dir="ltr">networkmanagement.googleapis.com/WebPath</code><br />
Web Path</td>
<td>A Web Path in Cloud Network insights.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP resource container associated with this resource, such as "projects/123456789".<br />
<code translate="no" dir="ltr">location</code>: The location of the WebPath resource.<br />
<code translate="no" dir="ltr">network_monitoring_provider_id</code>: Identifier of the network monitoring provider.<br />
<code translate="no" dir="ltr">path_id</code>: Identifier of the web path.</td>
</tr>
<tr id="tag_networksecurity.googleapis.com/DnsThreatDetector" class="odd">
<td><code translate="no" dir="ltr">networksecurity.googleapis.com/DnsThreatDetector</code><br />
DNS Threat Detector</td>
<td>A GCP network and Cloud Region indicating the location where a DNS threat was detected.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP project for the threat event.<br />
<code translate="no" dir="ltr">id</code>: ID of the DNS Threat Detector resource.<br />
<code translate="no" dir="ltr">location</code>: The origin Cloud Region of the DNS query analyzed by Protective DNS.</td>
</tr>
<tr id="tag_networksecurity.googleapis.com/FirewallEndpoint" class="even">
<td><code translate="no" dir="ltr">networksecurity.googleapis.com/FirewallEndpoint</code><br />
Firewall Endpoint</td>
<td>A Cloud Firewall Endpoint.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP organization or project owning the Firewall Endpoint.<br />
<code translate="no" dir="ltr">location</code>: The zone of the Firewall Endpoint.<br />
<code translate="no" dir="ltr">id</code>: The ID of the Firewall Endpoint.</td>
</tr>
<tr id="tag_networksecurity.googleapis.com/ProtectedEndpoint" class="odd">
<td><code translate="no" dir="ltr">networksecurity.googleapis.com/ProtectedEndpoint</code><br />
Protected Network Endpoint</td>
<td>An endpoint (identified by IP) protected by Cloud Armor Managed Protection.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">location</code>: The region on which the protected endpoint resides, such as 'global' or 'us-central1'.<br />
<code translate="no" dir="ltr">vip</code>: The virtual IP address of the protected endpoint. When multiple representations are possible, the IETF canonical representation (e.g., RFC 5952) is used.</td>
</tr>
<tr id="tag_networkservices.googleapis.com/Gateway" class="even">
<td><code translate="no" dir="ltr">networkservices.googleapis.com/Gateway</code><br />
Gateway</td>
<td>A Gateway represents a single gateway resource.<br />
<code translate="no" dir="ltr">resource_container</code>: The GCP container associated with the gateway.<br />
<code translate="no" dir="ltr">location</code>: The region name in which the Gateway is defined.<br />
<code translate="no" dir="ltr">network_name</code>: The name of the VPC network in which the Gateway was created.<br />
<code translate="no" dir="ltr">gateway_type</code>: The type enum of the Gateway.<br />
<code translate="no" dir="ltr">gateway_name</code>: The name of the Gateway resource.</td>
</tr>
<tr id="tag_networkservices.googleapis.com/MulticastDomain" class="odd">
<td><code translate="no" dir="ltr">networkservices.googleapis.com/MulticastDomain</code><br />
Multicast Domain</td>
<td>A Cloud Multicast domain.<br />
<code translate="no" dir="ltr">resource_container</code>: The project number of the multicast domain.<br />
<code translate="no" dir="ltr">location</code>: Fixed to "global".<br />
<code translate="no" dir="ltr">multicast_domain_id</code>: The user defined name of the multicast domain.</td>
</tr>
<tr id="tag_networkservices.googleapis.com/MulticastGroup" class="even">
<td><code translate="no" dir="ltr">networkservices.googleapis.com/MulticastGroup</code><br />
Multicast Group</td>
<td>Multicast Group.<br />
<code translate="no" dir="ltr">resource_container</code>: The multicast administrator project number, prefixed by "projects/".<br />
<code translate="no" dir="ltr">location</code>: Fixed to "global".<br />
<code translate="no" dir="ltr">multicast_domain_id</code>: The user defined name of the multicast domain the group range is associated with.<br />
<code translate="no" dir="ltr">multicast_group_range_id</code>: The user defined name of the multicast group range.<br />
<code translate="no" dir="ltr">multicast_ip</code>: The IP address used in this multicast group.</td>
</tr>
<tr id="tag_networkservices.googleapis.com/WasmPluginVersion" class="odd">
<td><code translate="no" dir="ltr">networkservices.googleapis.com/WasmPluginVersion</code><br />
Wasm Plugin Version</td>
<td>A single immutable version of a WasmPlugin (code + runtime config).<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The location of this service.<br />
<code translate="no" dir="ltr">plugin_name</code>: The name of the WasmPlugin.<br />
<code translate="no" dir="ltr">plugin_version</code>: The name of the WasmPluginVersion.</td>
</tr>
<tr id="tag_nodemanagement.googleapis.com/GoldkeyResource" class="even">
<td><code translate="no" dir="ltr">nodemanagement.googleapis.com/GoldkeyResource</code><br />
Goldkey Resource</td>
<td>A Goldkey resource managed by the Builder stack.<br />
<code translate="no" dir="ltr">resource_container</code>: The GCP project number owning the resource.<br />
<code translate="no" dir="ltr">location</code>: The deployment location of the resource.<br />
<code translate="no" dir="ltr">resource_id</code>: The unique ID of the resource.<br />
<code translate="no" dir="ltr">resource_type</code>: Type of the resource.</td>
</tr>
<tr id="tag_oracledatabase.googleapis.com/AutonomousDatabase" class="odd">
<td><code translate="no" dir="ltr">oracledatabase.googleapis.com/AutonomousDatabase</code><br />
Autonomous Database</td>
<td>Monitored resource representing a Autonomous Database.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The Google Cloud region in which the Autonomous database is running.<br />
<code translate="no" dir="ltr">autonomous_database_id</code>: The identifier of the Autonomous database.</td>
</tr>
<tr id="tag_oracledatabase.googleapis.com/CloudExadataInfrastructure" class="even">
<td><code translate="no" dir="ltr">oracledatabase.googleapis.com/CloudExadataInfrastructure</code><br />
Exadata Infrastructure</td>
<td>Monitored resource representing a Oracle Exadata infrastrucure.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The Google Cloud region in which the Exadata infrastrucure is running.<br />
<code translate="no" dir="ltr">cloud_exadata_infrastructure_id</code>: The identifier of the CloudExadataInfrastructure resource.</td>
</tr>
<tr id="tag_oracledatabase.googleapis.com/CloudVmCluster" class="odd">
<td><code translate="no" dir="ltr">oracledatabase.googleapis.com/CloudVmCluster</code><br />
Cloud VM cluster</td>
<td>Monitored resource representing a Cloud VM Cluster in Oracle Exadata infrastrucure.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The Google Cloud region in which the cluster is running.<br />
<code translate="no" dir="ltr">cloud_exadata_infrastructure_id</code>: The Cloud exadata infrastrucure id in which this cluster is hosted.<br />
<code translate="no" dir="ltr">cloud_vm_cluster_id</code>: The identifier of the CloudVmCluster resource.</td>
</tr>
<tr id="tag_oracledatabase.googleapis.com/ContainerDatabase" class="even">
<td><code translate="no" dir="ltr">oracledatabase.googleapis.com/ContainerDatabase</code><br />
Container Database</td>
<td>Monitored resource representing a Container Database in Cloud VM Cluster.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The Google Cloud region in which the cluster is running.<br />
<code translate="no" dir="ltr">cloud_exadata_infrastructure_id</code>: The Cloud exadata infrastrucure id in which this cluster is hosted.<br />
<code translate="no" dir="ltr">cloud_vm_cluster_id</code>: The identifier of the CloudVmCluster resource.<br />
<code translate="no" dir="ltr">container_database_name</code>: Name of the ContainerDatabase.</td>
</tr>
<tr id="tag_oracledatabase.googleapis.com/DbSystem" class="odd">
<td><code translate="no" dir="ltr">oracledatabase.googleapis.com/DbSystem</code><br />
Db System</td>
<td>Monitored resource representing a DbSystem.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The Google Cloud region in which the cluster is running.<br />
<code translate="no" dir="ltr">db_system_id</code>: The identifier of the DbSystem resource.</td>
</tr>
<tr id="tag_oracledatabase.googleapis.com/DbSystemContainerDatabase" class="even">
<td><code translate="no" dir="ltr">oracledatabase.googleapis.com/DbSystemContainerDatabase</code><br />
DbSystem Container Database</td>
<td>Monitored resource representing a DbSystem Container Database.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The Google Cloud region in which the cluster is running.<br />
<code translate="no" dir="ltr">db_system_id</code>: The identifier of the CloudVmCluster resource.<br />
<code translate="no" dir="ltr">container_database_name</code>: Name of the ContainerDatabase.</td>
</tr>
<tr id="tag_oracledatabase.googleapis.com/DbSystemPluggableDatabase" class="odd">
<td><code translate="no" dir="ltr">oracledatabase.googleapis.com/DbSystemPluggableDatabase</code><br />
DbSystem Pluggable Database</td>
<td>Monitored resource representing a DbSystem Pluggable Database in a VM Cluster.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The Google Cloud region in which the cluster is running.<br />
<code translate="no" dir="ltr">db_system_id</code>: The identifier of the CloudVmCluster resource.<br />
<code translate="no" dir="ltr">container_database_name</code>: Name of the ContainerDatabase.<br />
<code translate="no" dir="ltr">pluggable_database_name</code>: Name of the PluggableDatabase.</td>
</tr>
<tr id="tag_oracledatabase.googleapis.com/ExadbContainerDatabase" class="even">
<td><code translate="no" dir="ltr">oracledatabase.googleapis.com/ExadbContainerDatabase</code><br />
Exadb Container Database</td>
<td>Monitored resource representing a ExadbContainer Database in Cloud VM Cluster.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The Google Cloud region in which the cluster is running.<br />
<code translate="no" dir="ltr">exadb_vm_cluster_id</code>: The identifier of the CloudVmCluster resource.<br />
<code translate="no" dir="ltr">container_database_name</code>: Name of the ContainerDatabase.</td>
</tr>
<tr id="tag_oracledatabase.googleapis.com/ExadbPluggableDatabase" class="odd">
<td><code translate="no" dir="ltr">oracledatabase.googleapis.com/ExadbPluggableDatabase</code><br />
Exadb Pluggable Database</td>
<td>Monitored resource representing a Exadb Pluggable Database in a VM Cluster.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The Google Cloud region in which the cluster is running.<br />
<code translate="no" dir="ltr">exadb_vm_cluster_id</code>: The identifier of the CloudVmCluster resource.<br />
<code translate="no" dir="ltr">container_database_name</code>: Name of the ContainerDatabase.<br />
<code translate="no" dir="ltr">pluggable_database_name</code>: Name of the PluggableDatabase.</td>
</tr>
<tr id="tag_oracledatabase.googleapis.com/ExadbVmCluster" class="even">
<td><code translate="no" dir="ltr">oracledatabase.googleapis.com/ExadbVmCluster</code><br />
ExaDB VM Cluster</td>
<td>Monitored resource representing an Exascale DB VM Cluster.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The Google Cloud region in which the cluster is running.<br />
<code translate="no" dir="ltr">exadb_vm_cluster_id</code>: The identifier of the ExadbVmCluster resource.</td>
</tr>
<tr id="tag_oracledatabase.googleapis.com/ExascaleDbStorageVault" class="odd">
<td><code translate="no" dir="ltr">oracledatabase.googleapis.com/ExascaleDbStorageVault</code><br />
ExaDB Storage Vault</td>
<td>Monitored resource representing ExascaleDb Storage Vault.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The Google Cloud region in which the cluster is running.<br />
<code translate="no" dir="ltr">exascale_db_storage_vault_id</code>: The identifier of the ExascaleDbStorageVault resource.</td>
</tr>
<tr id="tag_oracledatabase.googleapis.com/GoldengateDeployment" class="even">
<td><code translate="no" dir="ltr">oracledatabase.googleapis.com/GoldengateDeployment</code><br />
Goldengate Deployment</td>
<td>Monitored resource representing a Goldengate Deployment.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The Google Cloud region in which the deployment is running.<br />
<code translate="no" dir="ltr">gg_deployment_id</code>: The identifier of the Goldengate Deployment resource.</td>
</tr>
<tr id="tag_oracledatabase.googleapis.com/PluggableDatabase" class="odd">
<td><code translate="no" dir="ltr">oracledatabase.googleapis.com/PluggableDatabase</code><br />
Pluggable Database</td>
<td>Monitored resource representing a Pluggable Database in a VM Cluster.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The Google Cloud region in which the cluster is running.<br />
<code translate="no" dir="ltr">cloud_exadata_infrastructure_id</code>: The Cloud exadata infrastrucure id in which this cluster is hosted.<br />
<code translate="no" dir="ltr">cloud_vm_cluster_id</code>: The identifier of the CloudVmCluster resource.<br />
<code translate="no" dir="ltr">container_database_name</code>: Name of the ContainerDatabase.<br />
<code translate="no" dir="ltr">pluggable_database_name</code>: Name of the PluggableDatabase.</td>
</tr>
<tr id="tag_organization" class="even">
<td><code translate="no" dir="ltr">organization</code><br />
Google Organization</td>
<td>A Google Cloud Platform organization.<br />
<code translate="no" dir="ltr">organization_id</code>: Numeric id of the organization.</td>
</tr>
<tr id="tag_produced_api" class="odd">
<td><code translate="no" dir="ltr">produced_api</code><br />
Produced API with consumer dimension</td>
<td>An API provided by the producer with consumer dimension.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as 'my-project'.<br />
<code translate="no" dir="ltr">service</code>: The API service name, such as 'cloudsql.googleapis.com'.<br />
<code translate="no" dir="ltr">method</code>: The API method name, such as 'disks.list'.<br />
<code translate="no" dir="ltr">version</code>: The API version, such as 'v1'.<br />
<code translate="no" dir="ltr">location</code>: The service specific notion of location. This can be a name of a zone or region. If a service does not have any notion of zones then 'global' can be used.<br />
<code translate="no" dir="ltr">consumer_id</code>: This is the ID of a consumer project that's made a request to the API, such as project number '412016889367'.</td>
</tr>
<tr id="tag_project" class="even">
<td><code translate="no" dir="ltr">project</code><br />
Google Project</td>
<td>A Google project.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource (e.g., my-project).</td>
</tr>
<tr id="tag_pubsub_snapshot" class="odd">
<td><code translate="no" dir="ltr">pubsub_snapshot</code><br />
Cloud Pub/Sub Snapshot</td>
<td>A snapshot in Google Cloud Pub/Sub.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">snapshot_id</code>: The identifier of the snapshot, such as "my-snapshot".</td>
</tr>
<tr id="tag_pubsub_subscription" class="even">
<td><code translate="no" dir="ltr">pubsub_subscription</code><br />
Cloud Pub/Sub Subscription</td>
<td>A subscription in Google Cloud Pub/Sub.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">subscription_id</code>: The identifier of the subscription, such as "my-subscription".</td>
</tr>
<tr id="tag_pubsub_topic" class="odd">
<td><code translate="no" dir="ltr">pubsub_topic</code><br />
Cloud Pub/Sub Topic</td>
<td>A topic in Google Cloud Pub/Sub.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">topic_id</code>: The identifier of the topic, such as "my-topic".</td>
</tr>
<tr id="tag_recaptchaenterprise.googleapis.com/Key" class="even">
<td><code translate="no" dir="ltr">recaptchaenterprise.googleapis.com/Key</code><br />
reCAPTCHA Key</td>
<td>Monitoring resource for reCAPTCHA Key.<br />
<code translate="no" dir="ltr">resource_container</code>: The ID of the GCP project associated with this reCAPTCHA Key.<br />
<code translate="no" dir="ltr">location</code>: Location where the reCAPTCHA Key is provisioned.<br />
<code translate="no" dir="ltr">key_id</code>: The ID for this Key.</td>
</tr>
<tr id="tag_recommender" class="odd">
<td><code translate="no" dir="ltr">recommender</code><br />
Recommender</td>
<td>A Recommender represents a grouping of similar recommendations.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">recommender_id</code>: The name of the recommender.<br />
<code translate="no" dir="ltr">location</code>: The location of the recommendation.</td>
</tr>
<tr id="tag_recommender_insight_type" class="even">
<td><code translate="no" dir="ltr">recommender_insight_type</code><br />
InsightType</td>
<td>An InsightType represents a grouping of similar insights.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">insight_type_id</code>: The resource ID of the insight type.<br />
<code translate="no" dir="ltr">location</code>: The location of the insight.</td>
</tr>
<tr id="tag_redis_instance" class="odd">
<td><code translate="no" dir="ltr">redis_instance</code><br />
Cloud Memorystore Redis Instance</td>
<td>A Redis instance hosted on Google Cloud Memorystore.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">region</code>: The Google Cloud region in which the managed instance is running.<br />
<code translate="no" dir="ltr">instance_id</code>: The ID of the managed instance.<br />
<code translate="no" dir="ltr">node_id</code>: The ID of a Redis node within the managed instance.</td>
</tr>
<tr id="tag_remotebuild_instance" class="even">
<td><code translate="no" dir="ltr">remotebuild_instance</code><br />
Remote Build Execution Instance</td>
<td>A specific instance for the Remote Build Execution service.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">location</code>: The Cloud zone of the instance.<br />
<code translate="no" dir="ltr">instance_id</code>: The specific instance within the Remote Build Execution consumer project.</td>
</tr>
<tr id="tag_reported_errors" class="odd">
<td><code translate="no" dir="ltr">reported_errors</code><br />
Reported Errors</td>
<td>Error data and metadata managed by Stackdriver Error Reporting<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".</td>
</tr>
<tr id="tag_saasservicemgmt.googleapis.com/Rollout" class="even">
<td><code translate="no" dir="ltr">saasservicemgmt.googleapis.com/Rollout</code><br />
App Lifecycle Manager Rollout</td>
<td>A Rollout of an App Lifecycle Manager Tenant.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The region in which this rollout occurred.<br />
<code translate="no" dir="ltr">rollout_id</code>: ID associated with this rollout.</td>
</tr>
<tr id="tag_saasservicemgmt.googleapis.com/Unit" class="odd">
<td><code translate="no" dir="ltr">saasservicemgmt.googleapis.com/Unit</code><br />
App Lifecycle Manager Unit</td>
<td>A Unit within an App Lifecycle Manager Tenant.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The location of the GCP project associated with this resource.<br />
<code translate="no" dir="ltr">unit_id</code>: The ID of the Unit.</td>
</tr>
<tr id="tag_secretmanager.googleapis.com/Secret" class="even">
<td><code translate="no" dir="ltr">secretmanager.googleapis.com/Secret</code><br />
Secret Manager Secret</td>
<td>A logical secret whose value and versions can be accessed.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: Location of secret metadata. Always global for v1.<br />
<code translate="no" dir="ltr">secret_id</code>: The name given to this secret.</td>
</tr>
<tr id="tag_sensitiveaction.googleapis.com/Location" class="odd">
<td><code translate="no" dir="ltr">sensitiveaction.googleapis.com/Location</code><br />
Location</td>
<td>A GCP resource container where a sensitive action was observed.<br />
<code translate="no" dir="ltr">resource_container</code>: The GCP resource container where the sensitive action was observed.<br />
<code translate="no" dir="ltr">location</code>: The location where the sensitive action was observed.</td>
</tr>
<tr id="tag_service_account" class="even">
<td><code translate="no" dir="ltr">service_account</code><br />
Service Account</td>
<td>A service account.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource (e.g., my-project).<br />
<code translate="no" dir="ltr">email_id</code>: The service account email id, e.g. "account123@proj123.iam.gserviceaccount.com".<br />
<code translate="no" dir="ltr">unique_id</code>: The unique id of the service account, e.g. "113948692397867021414".</td>
</tr>
<tr id="tag_service_config" class="odd">
<td><code translate="no" dir="ltr">service_config</code><br />
Service Configuration</td>
<td>A specific service configuration.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">service_name</code>: The name of the service.<br />
<code translate="no" dir="ltr">service_config_id</code>: The id of the service configuration.</td>
</tr>
<tr id="tag_service_rollout" class="even">
<td><code translate="no" dir="ltr">service_rollout</code><br />
Service Rollout</td>
<td>A resource type used to describe how a service configuration is deployed to backend systems.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">service_name</code>: The name of the service.<br />
<code translate="no" dir="ltr">rollout_id</code>: The id of the service rollout.</td>
</tr>
<tr id="tag_servicedirectory_namespace" class="odd">
<td><code translate="no" dir="ltr">servicedirectory_namespace</code><br />
Service Directory Namespace</td>
<td>A namespace in the Service Directory service.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">location</code>: The cloud region of the Service Directory namespace.<br />
<code translate="no" dir="ltr">namespace_name</code>: The name of the Service Directory namespace.</td>
</tr>
<tr id="tag_servicedirectory_service" class="even">
<td><code translate="no" dir="ltr">servicedirectory_service</code><br />
Service Directory Service</td>
<td>A Service Directory service.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">location</code>: The cloud region of the Service Directory service.<br />
<code translate="no" dir="ltr">namespace_name</code>: The name of the Service Directory namespace.<br />
<code translate="no" dir="ltr">service_name</code>: The name of the Service Directory service.</td>
</tr>
<tr id="tag_servicehealth.googleapis.com/Artifact" class="odd">
<td><code translate="no" dir="ltr">servicehealth.googleapis.com/Artifact</code><br />
Artifact</td>
<td>An Artifact in service health.<br />
<code translate="no" dir="ltr">resource_container</code>: The GCP project number.<br />
<code translate="no" dir="ltr">location</code>: The GCP location that serves the API for the given artifact.<br />
<code translate="no" dir="ltr">artifact_id</code>: The artifact ID.</td>
</tr>
<tr id="tag_servicehealth.googleapis.com/Event" class="even">
<td><code translate="no" dir="ltr">servicehealth.googleapis.com/Event</code><br />
Event</td>
<td>An Event in service health.<br />
<code translate="no" dir="ltr">resource_container</code>: The GCP project number.<br />
<code translate="no" dir="ltr">location</code>: The GCP location that serves the API for the given event.<br />
<code translate="no" dir="ltr">event_id</code>: The event ID.</td>
</tr>
<tr id="tag_serviceusage_service" class="odd">
<td><code translate="no" dir="ltr">serviceusage_service</code><br />
Service</td>
<td>A service activated or deactivated by a consumer project.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">service_name</code>: The name of the service.</td>
</tr>
<tr id="tag_serviceuser_service" class="even">
<td><code translate="no" dir="ltr">serviceuser_service</code><br />
Service</td>
<td>A service activated or deactivated by a consumer project.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">service_name</code>: The name of the service.</td>
</tr>
<tr id="tag_spanner_instance" class="odd">
<td><code translate="no" dir="ltr">spanner_instance</code><br />
Cloud Spanner Instance</td>
<td>A Cloud Spanner instance.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">instance_id</code>: An immutable identifier for an instance.<br />
<code translate="no" dir="ltr">location</code>: Cloud Spanner region.<br />
<code translate="no" dir="ltr">instance_config</code>: Instance config for the instance.</td>
</tr>
<tr id="tag_storage.googleapis.com/Client" class="even">
<td><code translate="no" dir="ltr">storage.googleapis.com/Client</code><br />
GCS Client</td>
<td>A Google Cloud Storage (GCS) client.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">location</code>: The location parsed from `cloud.region`.<br />
<code translate="no" dir="ltr">cloud_platform</code>: The cloud platform on which the GCS client runs.<br />
<code translate="no" dir="ltr">host_id</code>: The ID of the host (usually a VM) on which the GCS client runs.<br />
<code translate="no" dir="ltr">instance_id</code>: An UUID auto-generated by the client for the identification purpose.<br />
<code translate="no" dir="ltr">api</code>: The API used for communication. The available values are GRPC, JSON, and XML.</td>
</tr>
<tr id="tag_storage_transfer_job" class="odd">
<td><code translate="no" dir="ltr">storage_transfer_job</code><br />
Cloud Storage Transfer Job</td>
<td>A Google Cloud storage transfer job.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">job_id</code>: A unique name of the storage transfer job.</td>
</tr>
<tr id="tag_stream.googleapis.com/StreamInstance" class="even">
<td><code translate="no" dir="ltr">stream.googleapis.com/StreamInstance</code><br />
Stream Instance</td>
<td>A service instance that streams a single source of Content. .<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The region of the runtime.<br />
<code translate="no" dir="ltr">stream_instance_id</code>: The identifier of the stream instance.</td>
</tr>
<tr id="tag_tcp_ssl_proxy_rule" class="odd">
<td><code translate="no" dir="ltr">tcp_ssl_proxy_rule</code><br />
Global External Proxy Network Load Balancer Rule</td>
<td>A set of definitions for TCP/SSL proxy behavior.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">region</code>: The region on which TCP/SSL proxy is applied, such as 'global' or 'us-central1'. Various other objects are defined per that locality.<br />
<code translate="no" dir="ltr">backend_target_name</code>: The name of the backend target ('backend service', equivalent to 'proxy name').<br />
<code translate="no" dir="ltr">backend_target_type</code>: The type of the backend target. Can only be 'BACKEND_SERVICE' currently.<br />
<code translate="no" dir="ltr">forwarding_rule_name</code>: The name of the forwarding rule.<br />
<code translate="no" dir="ltr">target_proxy_name</code>: The name of the target TCP/SSL proxy.<br />
<code translate="no" dir="ltr">backend_name</code>: The name of the backend group.<br />
<code translate="no" dir="ltr">backend_type</code>: The type of the backend group. Can be 'INSTANCE_GROUP' or 'NETWORK_ENDPOINT_GROUP'.<br />
<code translate="no" dir="ltr">backend_scope</code>: The scope (zone or region) of the backend group.<br />
<code translate="no" dir="ltr">backend_scope_type</code>: The type of the scope of the backend group. Can be either 'ZONE' or 'REGION'.</td>
</tr>
<tr id="tag_testservice_matrix" class="even">
<td><code translate="no" dir="ltr">testservice_matrix</code><br />
Test Matrix</td>
<td>A Test Matrix in the Google Cloud Test Lab service.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">matrix_id</code>: Unique identifier of the matrix.</td>
</tr>
<tr id="tag_threat_detector" class="odd">
<td><code translate="no" dir="ltr">threat_detector</code><br />
Threat Detector</td>
<td>A detector in the Threat Detection service.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">detector_name</code>: The specific detector that triggered the alert.</td>
</tr>
<tr id="tag_tpu_worker" class="even">
<td><code translate="no" dir="ltr">tpu_worker</code><br />
TPU Worker</td>
<td>A TPU Worker executing Tensorflow work for a TPU Node.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">zone</code>: The Google Cloud zone in which the TPU Worker is running.<br />
<code translate="no" dir="ltr">node_id</code>: The ID of the TPU Node.<br />
<code translate="no" dir="ltr">worker_id</code>: The ID of a TPU Worker within the TPU Node.</td>
</tr>
<tr id="tag_transferappliance.googleapis.com/Appliance" class="odd">
<td><code translate="no" dir="ltr">transferappliance.googleapis.com/Appliance</code><br />
Transfer Appliance</td>
<td>Transfer Appliance is a way for Google Cloud Customers to transfer data to GCS.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The region in which the appliance was provisioned in (e.g. us-central1).<br />
<code translate="no" dir="ltr">appliance_id</code>: The unique id of the appliance.</td>
</tr>
<tr id="tag_uptime_url" class="even">
<td><code translate="no" dir="ltr">uptime_url</code><br />
Uptime Check URL</td>
<td>An Uptime Monitoring check against a custom URL.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">host</code>: The hostname or IP address of the check.</td>
</tr>
<tr id="tag_videostitcher.googleapis.com/Project" class="odd">
<td><code translate="no" dir="ltr">videostitcher.googleapis.com/Project</code><br />
Video Stitcher API Project</td>
<td>A Video Stitcher API Project.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The GCP location where the project resource resides.</td>
</tr>
<tr id="tag_visionai.googleapis.com/Application" class="even">
<td><code translate="no" dir="ltr">visionai.googleapis.com/Application</code><br />
Application</td>
<td>A Vertex AI Vision application.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP project associated with this resource.<br />
<code translate="no" dir="ltr">location</code>: The GCP location in which this application resides.<br />
<code translate="no" dir="ltr">application_id</code>: The identifier of the application.</td>
</tr>
<tr id="tag_vmmigration.googleapis.com/MigratingVM" class="odd">
<td><code translate="no" dir="ltr">vmmigration.googleapis.com/MigratingVM</code><br />
Migrate to Virtual Machines Migrating VM</td>
<td>A Migrate to Virtual Machines Migrating VM.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP project associated with this VM resource.<br />
<code translate="no" dir="ltr">location</code>: The GCP location where the VM resource resides.<br />
<code translate="no" dir="ltr">source</code>: The source where the VM resource resides.<br />
<code translate="no" dir="ltr">vm</code>: The VM ID.</td>
</tr>
<tr id="tag_vmmigration.googleapis.com/Source" class="even">
<td><code translate="no" dir="ltr">vmmigration.googleapis.com/Source</code><br />
Migrate to Virtual Machines Source</td>
<td>A Migrate to Virtual Machines Source.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP project associated with this source resource.<br />
<code translate="no" dir="ltr">location</code>: The GCP location where the source resource resides.<br />
<code translate="no" dir="ltr">source</code>: The source ID.</td>
</tr>
<tr id="tag_vpc_access_connector" class="odd">
<td><code translate="no" dir="ltr">vpc_access_connector</code><br />
VPC Access Connector</td>
<td>A connector that can communicate with devices within a VPC.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">location</code>: The region the connector is located in.<br />
<code translate="no" dir="ltr">connector_name</code>: The name of the connector.</td>
</tr>
<tr id="tag_vpc_flow_logs_config" class="even">
<td><code translate="no" dir="ltr">vpc_flow_logs_config</code><br />
VPC Flow Logs Config</td>
<td>A VPC Flow Logs configuration.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP resource container associated with this resource, such as \"projects/123\" or \"organizations/123\"<br />
<code translate="no" dir="ltr">name</code>: The unique name of the configuration within a project or organization. This refers to the config name alone, not the entire config path.<br />
<code translate="no" dir="ltr">location</code>: This is a global resource, so this field holds a static value of \"global\".</td>
</tr>
<tr id="tag_vpn_gateway" class="odd">
<td><code translate="no" dir="ltr">vpn_gateway</code><br />
Cloud VPN Gateway</td>
<td>A Cloud VPN gateway.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">gateway_id</code>: The VPN Gateway ID.<br />
<code translate="no" dir="ltr">region</code>: The region in which the VPN Gateway is running.</td>
</tr>
<tr id="tag_vpn_tunnel" class="even">
<td><code translate="no" dir="ltr">vpn_tunnel</code><br />
Cloud VPN Tunnel</td>
<td>A Cloud VPN tunnel.<br />
<code translate="no" dir="ltr">project_id</code>: The identifier of the GCP project associated with this resource, such as "my-project".<br />
<code translate="no" dir="ltr">tunnel_id</code>: The unique numerical identifier of the VPN tunnel.<br />
<code translate="no" dir="ltr">tunnel_name</code>: The unique user provided name of the VPN tunnel.<br />
<code translate="no" dir="ltr">location</code>: Location of the Cloud VPN Tunnel.</td>
</tr>
<tr id="tag_workflows.googleapis.com/Workflow" class="odd">
<td><code translate="no" dir="ltr">workflows.googleapis.com/Workflow</code><br />
Workflow</td>
<td>A Workflows specification of steps to execute.<br />
<code translate="no" dir="ltr">resource_container</code>: The identifier of the GCP container associated with the resource.<br />
<code translate="no" dir="ltr">location</code>: The region in which the workflow is deployed.<br />
<code translate="no" dir="ltr">workflow_id</code>: The ID of the workflow.</td>
</tr>
</tbody>
</table>

This list of monitored-resource types was last generated at 2026-10-22 02:17:28 UTC.

## Mappings for Logging-only resources

For log-based metrics to be ingested by Monitoring, the metrics must be mapped to a monitored-resource type supported by Monitoring. The mappings are also required to view corresponding logs from a Monitoring chart or alert.

In many cases, Logging and Monitoring use the same monitored-resource types. However, for certain monitored-resource types in Logging, there is no corresponding type in Monitoring. In these cases, the Logging resource types are mapped to an existing Monitoring type.

### Mappings to `global`

The following monitored-resource types in Logging map to the [`global`](/monitoring/api/resources#tag_global) type in Monitoring:

**Note:** The `global` monitored-resource type only contains the `project_id` label. Any labels in the Cloud Logging monitored-resource type are not available in the corresponding log-based metric.

- [`bigquery_resource`](#tag_bigquery_resource)
- [`billing_account`](#tag_billing_account)
- [`client_auth_config_brand`](#tag_client_auth_config_brand)
- [`client_auth_config_client`](#tag_client_auth_config_client)
- [`cloud_debugger_resource`](#tag_cloud_debugger_resource)
- [`cloudkms_cryptokey`](#tag_cloudkms_cryptokey)
- [`cloudkms_cryptokeyversion`](#tag_cloudkms_cryptokeyversion)
- [`cloudkms_keyring`](#tag_cloudkms_keyring)
- [`datastore_database`](#tag_datastore_database)
- [`datastore_index`](#tag_datastore_index)
- [`deployment`](#tag_deployment)
- [`deployment_manager_manifest`](#tag_deployment_manager_manifest)
- [`deployment_manager_operation`](#tag_deployment_manager_operation)
- [`deployment_manager_resource`](#tag_deployment_manager_resource)
- [`deployment_manager_type`](#tag_deployment_manager_type)
- [`folder`](#tag_folder)
- [`gce_autoscaler`](#tag_gce_autoscaler)
- [`gce_backend_bucket`](#tag_gce_backend_bucket)
- [`gce_backend_service`](#tag_gce_backend_service)
- [`gce_client_ssl_policy`](#tag_gce_client_ssl_policy)
- [`gce_commitment`](#tag_gce_commitment)
- [`gce_firewall_rule`](#tag_gce_firewall_rule)
- [`gce_forwarding_rule`](#tag_gce_forwarding_rule)
- [`gce_health_check`](#tag_gce_health_check)
- [`gce_image`](#tag_gce_image)
- [`gce_instance_group`](#tag_gce_instance_group)
- [`gce_instance_group_manager`](#tag_gce_instance_group_manager)
- [`gce_instance_template`](#tag_gce_instance_template)
- [`gce_license`](#tag_gce_license)
- [`gce_network`](#tag_gce_network)
- [`gce_operation`](#tag_gce_operation)
- [`gce_packet_mirroring`](#tag_gce_packet_mirroring)
- [`gce_project`](#tag_gce_project)
- [`gce_reserved_address`](#tag_gce_reserved_address)
- [`gce_route`](#tag_gce_route)
- [`gce_router`](#tag_gce_router)
- [`gce_snapshot`](#tag_gce_snapshot)
- [`gce_ssl_certificate`](#tag_gce_ssl_certificate)
- [`gce_target_http_instance`](#tag_gce_target_http_instance)
- [`gce_target_http_proxy`](#tag_gce_target_http_proxy)
- [`gce_target_https_proxy`](#tag_gce_target_https_proxy)
- [`gce_target_pool`](#tag_gce_target_pool)
- [`gce_target_ssl_proxy`](#tag_gce_target_ssl_proxy)
- [`gce_url_map`](#tag_gce_url_map)
- [`genomics_dataset`](#tag_genomics_dataset)
- [`genomics_operation`](#tag_genomics_operation)
- [`gke_cluster`](#tag_gke_cluster)
- [`gke_nodepool`](#tag_gke_nodepool)
- [`iam_role`](#tag_iam_role)
- [`logging_log`](#tag_logging_log)
- [`managed_service`](#tag_managed_service)
- [`ml_job`](#tag_ml_job)
- [`organization`](#tag_organization)
- [`project`](#tag_project)
- [`reported_errors`](#tag_reported_errors)
- [`service_account`](#tag_service_account)
- [`service_config`](#tag_service_config)
- [`service_rollout`](#tag_service_rollout)
- [`serviceusage_service`](#tag_serviceusage_service)
- [`serviceuser_service`](#tag_serviceuser_service)
- [`testservice_matrix`](#tag_testservice_matrix)
- [`vpn_tunnel`](#tag_vpn_tunnel)
- [`firebaserules_ruleset`](#firebaserules_ruleset)
- [`firebaserules_release`](#firebaserules_release)

### Mappings to other Cloud Monitoring resource types

The following monitored-resource types in Logging map to a resource type other than [`global`](/monitoring/api/resources#tag_global) in Monitoring:

<table class="fixed">
<colgroup>
<col style="width: 30%" />
<col style="width: 30%" />
<col style="width: 40%" />
</colgroup>
<thead>
<tr class="header">
<th>Logging monitored-resource type</th>
<th>Monitoring monitored-resource type</th>
<th>Label mappings</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td><a href="/logging/docs/api/v2/resource-list#tag_dataflow_step"><code translate="no" dir="ltr">dataflow_step</code></a></td>
<td><a href="/monitoring/api/resources#tag_dataflow_job"><code translate="no" dir="ltr">dataflow_job</code></a></td>
<td><ul>
<li><code translate="no" dir="ltr">project_id</code> maps to <code translate="no" dir="ltr">project_id</code>.</li>
<li><code translate="no" dir="ltr">job_id</code> does not exist in Monitoring.</li>
<li><code translate="no" dir="ltr">step_id</code> does not exist in Monitoring.</li>
<li><code translate="no" dir="ltr">job_name</code> maps to <code translate="no" dir="ltr">job_name</code>.</li>
<li><code translate="no" dir="ltr">region</code> maps to <code translate="no" dir="ltr">region</code>.</li>
</ul></td>
</tr>
<tr class="even">
<td><a href="/logging/docs/api/v2/resource-list#tag_container"><code translate="no" dir="ltr">container</code></a>
<strong>Note:</strong> Both <code translate="no" dir="ltr">container</code> and its Cloud Monitoring monitored-resource type <code translate="no" dir="ltr">gke_container</code> are deprecated. Newer container logs use <code translate="no" dir="ltr">k8s_container</code>.</td>
<td><a href="/monitoring/api/resources#tag_gke_container"><code translate="no" dir="ltr">gke_container</code></a></td>
<td>Labels match exactly.</td>
</tr>
<tr class="odd">
<td><a href="/logging/docs/api/v2/resource-list#tag_http_load_balancer"><code translate="no" dir="ltr">http_load_balancer</code></a></td>
<td><a href="/monitoring/api/resources#tag_l7_lb_rule"><code translate="no" dir="ltr">l7_lb_rule</code></a>
<strong>Note:</strong> The <code translate="no" dir="ltr">l7_lb_rule</code> monitored-resource type is only used by log-based metrics. Other load balancer system metrics use the monitored-resource type <a href="/monitoring/api/resources#tag_https_lb_rule"><code translate="no" dir="ltr">https_lb_rule</code></a>.</td>
<td><ul>
<li><code translate="no" dir="ltr">project_id</code> maps to <code translate="no" dir="ltr">project_id</code>.</li>
<li><code translate="no" dir="ltr">forwarding_rule_name</code> maps to <code translate="no" dir="ltr">forwarding_rule_name</code>.</li>
<li><code translate="no" dir="ltr">url_map_name</code> maps to <code translate="no" dir="ltr">url_map_name</code>.</li>
<li><code translate="no" dir="ltr">target_proxy_name</code> maps to <code translate="no" dir="ltr">target_proxy_name</code>.</li>
<li><code translate="no" dir="ltr">backend_service_name</code> maps to <code translate="no" dir="ltr">backend_name</code>.</li>
<li><code translate="no" dir="ltr">zone</code> does not exist in Monitoring.</li>
<li>All other labels are empty in Monitoring.</li>
</ul></td>
</tr>
</tbody>
</table>

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
