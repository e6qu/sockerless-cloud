# Quotas and limits

<div class="devsite-article-body clearfix">

This document lists the quotas and system limits that apply to Cloud Tasks.

- *Quotas* have default values, but you can typically request adjustments.
- *System limits* are fixed values that can't be changed.

## Quotas

Google Cloud uses quotas to help ensure fairness and reduce spikes in resource use and availability. A quota restricts how much of a Google Cloud resource your Google Cloud project can use. Quotas apply to a range of resource types, including hardware, software, and network components. For example, quotas can restrict the number of API calls to a service, the number of load balancers used concurrently by your project, or the number of projects that you can create. Quotas protect the community of Google Cloud users by preventing the overloading of services. Quotas also help you to manage your own Google Cloud resources.

The Cloud Quotas system does the following:

- Monitors your consumption of Google Cloud products and services
- Restricts your consumption of those resources
- Provides a way to [request changes to the quota value](/docs/quotas/help/request_increase) and [automate quota adjustments](/docs/quotas/quota-adjuster)

In most cases, when you attempt to consume more of a resource than its quota allows, the system blocks access to the resource, and the task that you're trying to perform fails.

Quotas generally apply at the Google Cloud project level. Your use of a resource in one project doesn't affect your available quota in another project. Within a Google Cloud project, quotas are shared across all applications and IP addresses.

For more information, see the [Cloud Quotas overview](/docs/quotas/overview).

The following table describes the quotas for Cloud Tasks resources.

<table>
<colgroup>
<col style="width: 25%" />
<col style="width: 25%" />
<col style="width: 25%" />
<col style="width: 25%" />
</colgroup>
<thead>
<tr class="header">
<th>Resource</th>
<th width="20%">Console quota name</th>
<th>Default value</th>
<th>Description</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td>Maximum number of queues</td>
<td><strong>Number of queues per region</strong></td>
<td>1,000 per region</td>
<td><p>The total number of queues (for both HTTP and App Engine targets) that can exist in a project per region, including the default queue.</p>
<p>Queues that process tasks for App Engine targets must be in the same region as the App Engine app. This is the quota for queues created using Cloud Tasks API methods. Any queues created using <code translate="no" dir="ltr">queue.yaml</code>, however, are based on the older Task Queues method. These queues continue to have an initial quota of 100.</p></td>
</tr>
<tr class="even">
<td>API requests</td>
<td><strong>Requests per minute per region</strong></td>
<td>6,000,000 per minute</td>
<td><p>The total number of API requests that can be made per minute.</p>
<p>Note that when <a href="/tasks/docs/create-tasks#create-batch-tasks">creating a batch of tasks</a> (<code translate="no" dir="ltr">batchCreate</code>) or <a href="/tasks/docs/manage-queues-and-tasks#delete-batch-tasks">deleting a batch of tasks</a> (<code translate="no" dir="ltr">batchDelete</code>), quota consumption is based on the number of tasks in the batch. Each individual task in the batch counts as one request against the API requests quota limit.</p></td>
</tr>
<tr class="odd">
<td>Force run task requests</td>
<td><strong>Run task requests per minute per region</strong></td>
<td>60 per minute</td>
<td>The total number of <a href="/tasks/docs/reference/rest/v2/projects.locations.queues.tasks/run"><code translate="no" dir="ltr">run task</code></a> requests per minute. This API is intended for manual debugging and is unrelated to normal task execution.</td>
</tr>
<tr class="even">
<td>List requests</td>
<td><strong>List group requests per minute per region</strong></td>
<td>600 per minute</td>
<td>The total number of <a href="/tasks/docs/reference/rest/v2/projects.locations.queues.tasks/list"><code translate="no" dir="ltr">list tasks</code></a>, <a href="/tasks/docs/reference/rest/v2/projects.locations.queues/list"><code translate="no" dir="ltr">list queues</code></a>, and <a href="/tasks/docs/reference/rest/v2/projects.locations/list"><code translate="no" dir="ltr">list locations</code></a> requests per minute.</td>
</tr>
</tbody>
</table>

To adjust most quotas, use the Google Cloud console. For more information, see [Request a quota adjustment](/docs/quotas/help/request_increase).

## System limits

There are also *system limits* on Cloud Tasks resources. System limits can't be changed.

The following table describes the system limits for Cloud Tasks.

| Resource                                   | Value                              | Description                                                                                                                                                                                                                               |
|--------------------------------------------|------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Queue dispatch rate                        | 500 tasks per second per queue     | The maximum rate at which tasks can be dispatched from a queue. To dispatch at higher rates, use multiple queues.                                                                                                                         |
| Maximum task size                          | 1 MiB                              | The maximum size of a task that can be added to a queue.                                                                                                                                                                                  |
| Maximum batch size                         | 10 MiB                             | The maximum size of a batch of tasks that can be added to a queue.                                                                                                                                                                        |
| Maximum number of tasks created in a batch | 100 tasks                          | The maximum number of tasks that can be created in a single `batchCreate` request.                                                                                                                                                        |
| Maximum number of tasks deleted in a batch | 1,000 tasks                        | The maximum number of tasks that can be deleted in a single `batchDelete` request.                                                                                                                                                        |
| Task deduplication window                  | Up to 24 hours                     | The time period during which adding a task with the same name as a recently deleted task will cause the service to reject it with an error. This is the length of time that task deduplication remains in effect after a task is deleted. |
| Batch operation deduplication window       | 7 days                             | The time period during which batch operation IDs and their results are persisted for deduplication.                                                                                                                                       |
| Inactive queues                            | Inactive after 30 days             | A queue is considered `INACTIVE` if no method calls are made to it from any API, and it has had no task dispatches for this period.                                                                                                       |
| Maximum task retention                     | 31 days                            | The time between when a task is added to a queue and when it is automatically deleted.                                                                                                                                                    |
| Maximum schedule time for a task           | 30 days from current date and time | The maximum amount of time in the future that a task can be scheduled.                                                                                                                                                                    |
| Queue re-creation                          | 3 days                             | The time you must wait after deleting a queue to re-create a queue with the same name.                                                                                                                                                    |

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
