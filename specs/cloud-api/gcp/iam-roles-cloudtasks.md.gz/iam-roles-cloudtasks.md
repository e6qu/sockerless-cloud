# Cloud Tasks roles and permissions

<div class="devsite-article-body clearfix">

This page lists the IAM roles and permissions for Cloud Tasks. To search through all roles and permissions, see the [role and permission index](/iam/docs/roles-permissions).

## Cloud Tasks roles

<div results-count-container="">

</div>

<table class="fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="50%">Role</th>
<th>Permissions</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td class="role-description"><h4 id="cloudtasks.admin" class="role-title add-link" data-text="Cloud Tasks Admin " tabindex="-1">Cloud Tasks Admin</h4>
<p>(<code translate="no" dir="ltr">roles/cloudtasks.admin</code>)</p>
<span class="role-description"> </span>
<p>Full access to queues and tasks.</p></td>
<td class="role-permissions"><p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudtasks.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudtasks.cmekConfig.get</code></li>
<li><code translate="no" dir="ltr">cloudtasks.cmekConfig.update</code></li>
<li><code translate="no" dir="ltr">cloudtasks.locations.get</code></li>
<li><code translate="no" dir="ltr">cloudtasks.locations.list</code></li>
<li><code translate="no" dir="ltr">cloudtasks.operations.get</code></li>
<li><code translate="no" dir="ltr">cloudtasks.queues.create</code></li>
<li><code translate="no" dir="ltr">cloudtasks.queues.delete</code></li>
<li><code translate="no" dir="ltr">cloudtasks.queues.get</code></li>
<li><code translate="no" dir="ltr">cloudtasks.queues.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">cloudtasks.queues.list</code></li>
<li><code translate="no" dir="ltr">cloudtasks.queues.pause</code></li>
<li><code translate="no" dir="ltr">cloudtasks.queues.purge</code></li>
<li><code translate="no" dir="ltr">cloudtasks.queues.resume</code></li>
<li><code translate="no" dir="ltr">cloudtasks.queues.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">cloudtasks.queues.update</code></li>
<li><code translate="no" dir="ltr">cloudtasks.tasks.create</code></li>
<li><code translate="no" dir="ltr">cloudtasks.tasks.delete</code></li>
<li><code translate="no" dir="ltr">cloudtasks.tasks.fullView</code></li>
<li><code translate="no" dir="ltr">cloudtasks.tasks.get</code></li>
<li><code translate="no" dir="ltr">cloudtasks.tasks.list</code></li>
<li><code translate="no" dir="ltr">cloudtasks.tasks.run</code></li>
</ul>
<p><code translate="no" dir="ltr">monitoring.timeSeries.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="cloudtasks.editor" class="role-title add-link" data-text="Cloud Tasks Editor " tabindex="-1">Cloud Tasks Editor</h4>
<p>(<code translate="no" dir="ltr">roles/cloudtasks.editor</code>)</p>
<span class="role-description"> </span>
<p>Editor role for cloudtasks</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudtasks.cmekConfig.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudtasks.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudtasks.locations.get</code></li>
<li><code translate="no" dir="ltr">cloudtasks.locations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">cloudtasks.operations.get</code></p>
<p><code translate="no" dir="ltr">cloudtasks.queues.create</code></p>
<p><code translate="no" dir="ltr">cloudtasks.queues.delete</code></p>
<p><code translate="no" dir="ltr">cloudtasks.queues.get</code></p>
<p><code translate="no" dir="ltr">cloudtasks.queues.list</code></p>
<p><code translate="no" dir="ltr">cloudtasks.queues.pause</code></p>
<p><code translate="no" dir="ltr">cloudtasks.queues.purge</code></p>
<p><code translate="no" dir="ltr">cloudtasks.queues.resume</code></p>
<p><code translate="no" dir="ltr">cloudtasks.queues.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudtasks.tasks.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudtasks.tasks.create</code></li>
<li><code translate="no" dir="ltr">cloudtasks.tasks.delete</code></li>
<li><code translate="no" dir="ltr">cloudtasks.tasks.fullView</code></li>
<li><code translate="no" dir="ltr">cloudtasks.tasks.get</code></li>
<li><code translate="no" dir="ltr">cloudtasks.tasks.list</code></li>
<li><code translate="no" dir="ltr">cloudtasks.tasks.run</code></li>
</ul>
<p><code translate="no" dir="ltr">monitoring.timeSeries.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="cloudtasks.viewer" class="role-title add-link" data-text="Cloud Tasks Viewer " tabindex="-1">Cloud Tasks Viewer</h4>
<p>(<code translate="no" dir="ltr">roles/cloudtasks.viewer</code>)</p>
<span class="role-description"> </span>
<p>Get and list access to tasks, queues, and locations.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudtasks.cmekConfig.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudtasks.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudtasks.locations.get</code></li>
<li><code translate="no" dir="ltr">cloudtasks.locations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">cloudtasks.operations.get</code></p>
<p><code translate="no" dir="ltr">cloudtasks.queues.get</code></p>
<p><code translate="no" dir="ltr">cloudtasks.queues.list</code></p>
<p><code translate="no" dir="ltr">cloudtasks.tasks.fullView</code></p>
<p><code translate="no" dir="ltr">cloudtasks.tasks.get</code></p>
<p><code translate="no" dir="ltr">cloudtasks.tasks.list</code></p>
<p><code translate="no" dir="ltr">monitoring.timeSeries.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="cloudtasks.enqueuer" class="role-title add-link" data-text="Cloud Tasks Enqueuer Beta " tabindex="-1">Cloud Tasks Enqueuer <sup>Beta</sup></h4>
<p>(<code translate="no" dir="ltr">roles/cloudtasks.enqueuer</code>)</p>
<span class="role-description"> </span>
<p>Access to create tasks.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudtasks.operations.get</code></p>
<p><code translate="no" dir="ltr">cloudtasks.tasks.create</code></p>
<p><code translate="no" dir="ltr">cloudtasks.tasks.fullView</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="cloudtasks.queueAdmin" class="role-title add-link" data-text="Cloud Tasks Queue Admin " tabindex="-1">Cloud Tasks Queue Admin</h4>
<p>(<code translate="no" dir="ltr">roles/cloudtasks.queueAdmin</code>)</p>
<span class="role-description"> </span>
<p>Admin access to queues.</p></td>
<td class="role-permissions"><p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudtasks.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudtasks.locations.get</code></li>
<li><code translate="no" dir="ltr">cloudtasks.locations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudtasks.queues.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudtasks.queues.create</code></li>
<li><code translate="no" dir="ltr">cloudtasks.queues.delete</code></li>
<li><code translate="no" dir="ltr">cloudtasks.queues.get</code></li>
<li><code translate="no" dir="ltr">cloudtasks.queues.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">cloudtasks.queues.list</code></li>
<li><code translate="no" dir="ltr">cloudtasks.queues.pause</code></li>
<li><code translate="no" dir="ltr">cloudtasks.queues.purge</code></li>
<li><code translate="no" dir="ltr">cloudtasks.queues.resume</code></li>
<li><code translate="no" dir="ltr">cloudtasks.queues.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">cloudtasks.queues.update</code></li>
</ul>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="cloudtasks.taskDeleter" class="role-title add-link" data-text="Cloud Tasks Task Deleter " tabindex="-1">Cloud Tasks Task Deleter</h4>
<p>(<code translate="no" dir="ltr">roles/cloudtasks.taskDeleter</code>)</p>
<span class="role-description"> </span>
<p>Access to delete tasks.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudtasks.tasks.delete</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="cloudtasks.taskRunner" class="role-title add-link" data-text="Cloud Tasks Task Runner Beta " tabindex="-1">Cloud Tasks Task Runner <sup>Beta</sup></h4>
<p>(<code translate="no" dir="ltr">roles/cloudtasks.taskRunner</code>)</p>
<span class="role-description"> </span>
<p>Access to run tasks.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudtasks.tasks.fullView</code></p>
<p><code translate="no" dir="ltr">cloudtasks.tasks.run</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
</tbody>
</table>

### Service agent roles

Service agent roles should only be granted to [service agents](/iam/docs/service-agents).

<div results-count-container="">

</div>

<table class="fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="50%">Role</th>
<th>Permissions</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td class="role-description"><h4 id="cloudtasks.serviceAgent" class="role-title add-link" data-text="Cloud Tasks Service Agent " tabindex="-1">Cloud Tasks Service Agent</h4>
<p>(<code translate="no" dir="ltr">roles/cloudtasks.serviceAgent</code>)</p>
<span class="role-description"> </span>
<p>Grants Cloud Tasks Service Account access to manage resources.</p>
<strong>Warning:</strong> Do not grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.</td>
<td class="role-permissions"><p><code translate="no" dir="ltr">iam.serviceAccounts.getAccessToken</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.getOpenIdToken</code></p>
<p><code translate="no" dir="ltr">logging.logEntries.create</code></p></td>
</tr>
</tbody>
</table>

## Cloud Tasks permissions

<div results-count-container="">

</div>

<table class="permissions-table fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="45%">Permission</th>
<th>Included in roles</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td><h4 id="cloudtasks.cmekConfig.get" class="permission-name add-link" data-text="cloudtasks.cmekConfig.get" tabindex="-1"><code translate="no" dir="ltr">cloudtasks.cmekConfig.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.admin">Cloud Tasks Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.editor">Cloud Tasks Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.viewer">Cloud Tasks Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="cloudtasks.cmekConfig.update" class="permission-name add-link" data-text="cloudtasks.cmekConfig.update" tabindex="-1"><code translate="no" dir="ltr">cloudtasks.cmekConfig.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.admin">Cloud Tasks Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.admin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="cloudtasks.locations.get" class="permission-name add-link" data-text="cloudtasks.locations.get" tabindex="-1"><code translate="no" dir="ltr">cloudtasks.locations.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.admin">Cloud Tasks Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.editor">Cloud Tasks Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.viewer">Cloud Tasks Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.queueAdmin">Cloud Tasks Queue Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.queueAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/firebasemods#firebasemods.serviceAgent">Firebase Extensions API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasemods.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="cloudtasks.locations.list" class="permission-name add-link" data-text="cloudtasks.locations.list" tabindex="-1"><code translate="no" dir="ltr">cloudtasks.locations.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.admin">Cloud Tasks Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.editor">Cloud Tasks Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.viewer">Cloud Tasks Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.queueAdmin">Cloud Tasks Queue Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.queueAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/firebasemods#firebasemods.serviceAgent">Firebase Extensions API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasemods.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="cloudtasks.operations.get" class="permission-name add-link" data-text="cloudtasks.operations.get" tabindex="-1"><code translate="no" dir="ltr">cloudtasks.operations.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.admin">Cloud Tasks Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.editor">Cloud Tasks Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.viewer">Cloud Tasks Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.enqueuer">Cloud Tasks Enqueuer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.enqueuer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="cloudtasks.queues.create" class="permission-name add-link" data-text="cloudtasks.queues.create" tabindex="-1"><code translate="no" dir="ltr">cloudtasks.queues.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.admin">Cloud Tasks Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.editor">Cloud Tasks Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.queueAdmin">Cloud Tasks Queue Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.queueAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasemods#firebasemods.serviceAgent">Firebase Extensions API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasemods.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="cloudtasks.queues.delete" class="permission-name add-link" data-text="cloudtasks.queues.delete" tabindex="-1"><code translate="no" dir="ltr">cloudtasks.queues.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.admin">Cloud Tasks Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.editor">Cloud Tasks Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.queueAdmin">Cloud Tasks Queue Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.queueAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasemods#firebasemods.serviceAgent">Firebase Extensions API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasemods.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="cloudtasks.queues.get" class="permission-name add-link" data-text="cloudtasks.queues.get" tabindex="-1"><code translate="no" dir="ltr">cloudtasks.queues.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.admin">Cloud Tasks Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.editor">Cloud Tasks Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.viewer">Cloud Tasks Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.queueAdmin">Cloud Tasks Queue Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.queueAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasemods#firebasemods.serviceAgent">Firebase Extensions API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasemods.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="cloudtasks.queues.getIamPolicy" class="permission-name add-link" data-text="cloudtasks.queues.getIamPolicy" tabindex="-1"><code translate="no" dir="ltr">cloudtasks.queues.getIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.admin">Cloud Tasks Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.queueAdmin">Cloud Tasks Queue Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.queueAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/firebasemods#firebasemods.serviceAgent">Firebase Extensions API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasemods.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="cloudtasks.queues.list" class="permission-name add-link" data-text="cloudtasks.queues.list" tabindex="-1"><code translate="no" dir="ltr">cloudtasks.queues.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.admin">Cloud Tasks Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.editor">Cloud Tasks Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.viewer">Cloud Tasks Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.queueAdmin">Cloud Tasks Queue Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.queueAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/firebasemods#firebasemods.serviceAgent">Firebase Extensions API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasemods.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="cloudtasks.queues.pause" class="permission-name add-link" data-text="cloudtasks.queues.pause" tabindex="-1"><code translate="no" dir="ltr">cloudtasks.queues.pause</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.admin">Cloud Tasks Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.editor">Cloud Tasks Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.queueAdmin">Cloud Tasks Queue Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.queueAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/firebasemods#firebasemods.serviceAgent">Firebase Extensions API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasemods.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="cloudtasks.queues.purge" class="permission-name add-link" data-text="cloudtasks.queues.purge" tabindex="-1"><code translate="no" dir="ltr">cloudtasks.queues.purge</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.admin">Cloud Tasks Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.editor">Cloud Tasks Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.queueAdmin">Cloud Tasks Queue Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.queueAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/firebasemods#firebasemods.serviceAgent">Firebase Extensions API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasemods.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="cloudtasks.queues.resume" class="permission-name add-link" data-text="cloudtasks.queues.resume" tabindex="-1"><code translate="no" dir="ltr">cloudtasks.queues.resume</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.admin">Cloud Tasks Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.editor">Cloud Tasks Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.queueAdmin">Cloud Tasks Queue Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.queueAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/firebasemods#firebasemods.serviceAgent">Firebase Extensions API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasemods.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="cloudtasks.queues.setIamPolicy" class="permission-name add-link" data-text="cloudtasks.queues.setIamPolicy" tabindex="-1"><code translate="no" dir="ltr">cloudtasks.queues.setIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.admin">Cloud Tasks Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.queueAdmin">Cloud Tasks Queue Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.queueAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/firebasemods#firebasemods.serviceAgent">Firebase Extensions API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasemods.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="cloudtasks.queues.update" class="permission-name add-link" data-text="cloudtasks.queues.update" tabindex="-1"><code translate="no" dir="ltr">cloudtasks.queues.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.admin">Cloud Tasks Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.editor">Cloud Tasks Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.queueAdmin">Cloud Tasks Queue Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.queueAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/firebasemods#firebasemods.serviceAgent">Firebase Extensions API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasemods.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="cloudtasks.tasks.create" class="permission-name add-link" data-text="cloudtasks.tasks.create" tabindex="-1"><code translate="no" dir="ltr">cloudtasks.tasks.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.admin">Cloud Tasks Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.editor">Cloud Tasks Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.enqueuer">Cloud Tasks Enqueuer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.enqueuer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/firebasemods#firebasemods.serviceAgent">Firebase Extensions API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasemods.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="cloudtasks.tasks.delete" class="permission-name add-link" data-text="cloudtasks.tasks.delete" tabindex="-1"><code translate="no" dir="ltr">cloudtasks.tasks.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.admin">Cloud Tasks Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.editor">Cloud Tasks Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.taskDeleter">Cloud Tasks Task Deleter</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.taskDeleter</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="cloudtasks.tasks.fullView" class="permission-name add-link" data-text="cloudtasks.tasks.fullView" tabindex="-1"><code translate="no" dir="ltr">cloudtasks.tasks.fullView</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.admin">Cloud Tasks Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.editor">Cloud Tasks Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.viewer">Cloud Tasks Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.enqueuer">Cloud Tasks Enqueuer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.enqueuer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.taskRunner">Cloud Tasks Task Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.taskRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/firebasemods#firebasemods.serviceAgent">Firebase Extensions API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasemods.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="cloudtasks.tasks.get" class="permission-name add-link" data-text="cloudtasks.tasks.get" tabindex="-1"><code translate="no" dir="ltr">cloudtasks.tasks.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.admin">Cloud Tasks Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.editor">Cloud Tasks Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.viewer">Cloud Tasks Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="cloudtasks.tasks.list" class="permission-name add-link" data-text="cloudtasks.tasks.list" tabindex="-1"><code translate="no" dir="ltr">cloudtasks.tasks.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.admin">Cloud Tasks Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.editor">Cloud Tasks Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.viewer">Cloud Tasks Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="cloudtasks.tasks.run" class="permission-name add-link" data-text="cloudtasks.tasks.run" tabindex="-1"><code translate="no" dir="ltr">cloudtasks.tasks.run</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.admin">Cloud Tasks Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.editor">Cloud Tasks Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.taskRunner">Cloud Tasks Task Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.taskRunner</code>)</p></td>
</tr>
</tbody>
</table>

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
