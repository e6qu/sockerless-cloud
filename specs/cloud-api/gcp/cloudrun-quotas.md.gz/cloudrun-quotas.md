# Cloud Run Quotas and Limits

<div class="devsite-article-body clearfix">

This page contains usage quota and limits that apply when using Cloud Run.

The number of Cloud Run [resources](/run/docs/resource-model) is limited. Quotas for Cloud Run encompass API rate limits, which affect the rate at which you can call the [Cloud Run Admin API](/run/docs/reference/rest).

There is no direct limit for the following:

- The size of container images you can deploy.
- The number of concurrent requests that are served by a [Cloud Run service](/run/docs/resource-model#services).

## Resource limits for Cloud Run

The following limits set the maximum number of resources you can create in a region. However, available quota doesn't guarantee resource availability. If a resource is not available, or if the region you choose is limited on the resource, you may not be able to create or scale resources of that type, even if you have remaining quota in your region or project. For example, you might still have quota to create jobs in `us-central1`, but there might not be available resources in that region.

To go beyond limits that can be increased, [request a quota increase](/run/quotas#increase). To go beyond per project limits that cannot be increased, create new resources in a different Google Cloud project or region.

<table>
<colgroup>
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
</colgroup>
<thead>
<tr class="header">
<th>Resource</th>
<th>Description</th>
<th>Limit</th>
<th>Scope</th>
<th>Can be increased</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td>Service</td>
<td>Maximum number of services</td>
<td>1000</td>
<td>per project and region</td>
<td>Yes</td>
</tr>
<tr class="even">
<td>Job</td>
<td>Maximum number of jobs</td>
<td>1000</td>
<td>per project and region</td>
<td>Yes</td>
</tr>
<tr class="odd">
<td>Worker pool</td>
<td>Maximum number of worker pools</td>
<td>1000</td>
<td>per project and region</td>
<td>Yes</td>
</tr>
<tr class="even">
<td>Instance</td>
<td>Maximum number of instances</td>
<td>100</td>
<td>per project and region</td>
<td>Yes</td>
</tr>
<tr class="odd">
<td>Instance</td>
<td>Maximum continuous execution time before automatic restart (requires <code translate="no" dir="ltr">always</code> or <code translate="no" dir="ltr">on-failure</code> restart policy)</td>
<td>7 days</td>
<td>per instance</td>
<td>No</td>
</tr>
<tr class="even">
<td>Instance</td>
<td>Baseline CPU allocation for shared CPU instances outside of burst budget</td>
<td>6.25%</td>
<td>per instance</td>
<td>No</td>
</tr>
<tr class="odd">
<td>Job execution</td>
<td>Maximum number of running job executions</td>
<td>1000</td>
<td>per project and region</td>
<td>Yes</td>
</tr>
<tr class="even">
<td>Revision</td>
<td>Number of revisions after which any non-addressable revisions are automatically deleted in historical order</td>
<td>1000</td>
<td>per service</td>
<td>No</td>
</tr>
<tr class="odd">
<td>Revision</td>
<td>Maximum number of revisions serving traffic</td>
<td>4000</td>
<td>per project and region</td>
<td>Yes</td>
</tr>
<tr class="even">
<td>Revision tag</td>
<td>Maximum number of <a href="/run/docs/rollouts-rollbacks-traffic-migration#tags">revision tags</a>. When the revision tag limit is exceeded, Cloud Run executes tag cleanup on the service. For the service for which a new tag is being created, tags that don't have a specified traffic percentage are automatically deleted in historical order.</td>
<td>2000</td>
<td>per project and region</td>
<td>Yes</td>
</tr>
<tr class="odd">
<td>Job execution</td>
<td>Retention limit for completed job executions. When the number of completed executions for a job reaches this limit, executions are automatically deleted in historical order</td>
<td>1,000</td>
<td>per job</td>
<td>No</td>
</tr>
<tr class="even">
<td>Job execution task<sup>1</sup></td>
<td>Maximum number of <a href="/run/docs/configuring/parallelism#limit">tasks running in parallel</a></td>
<td>Depends on selected region and <a href="/run/docs/configuring/jobs/cpu">CPU</a> and <a href="/run/docs/configuring/jobs/memory-limits">memory</a> configurations. This limit might be greater in high-capacity regions or lower in recently opened regions. You can view your quota in the <a href="https://console.cloud.google.com/iam-admin/quotas">Quotas and system limits</a> console page.</td>
<td>per job execution</td>
<td>Yes</td>
</tr>
<tr class="odd">
<td>Job execution task</td>
<td>Maximum tasks timeout value</td>
<td>168 hours (7 days), or 12 hours if using GPUs</td>
<td>per job execution</td>
<td>No</td>
</tr>
<tr class="even">
<td>Job execution task</td>
<td>Maximum number of tasks in a single job</td>
<td>10,000</td>
<td>per job execution</td>
<td>No</td>
</tr>
<tr class="odd">
<td>Job execution task</td>
<td>Maximum number of task retries in a job</td>
<td>10</td>
<td>per job execution</td>
<td>No</td>
</tr>
<tr class="even">
<td>Environment variables</td>
<td>Maximum number of environment variables for each container</td>
<td>1000</td>
<td>per job or per service</td>
<td>No</td>
</tr>
<tr class="odd">
<td>Command arguments</td>
<td>Maximum number of command arguments for each container</td>
<td>1000</td>
<td>per job or per service</td>
<td>No</td>
</tr>
<tr class="even">
<td>Container instance<sup>3</sup></td>
<td>Maximum number of container instances using Direct VPC egress</td>
<td>100-200, depending on selected <a href="/run/docs/locations">region</a> configurations.</td>
<td>per revision and region</td>
<td>Yes</td>
</tr>
<tr class="odd">
<td>Container instance</td>
<td><a href="/run/docs/container-contract#startup">Startup</a> timeout, in minutes</td>
<td>4</td>
<td>per container instance</td>
<td>No</td>
</tr>
<tr class="even">
<td>Memory</td>
<td>Maximum memory size, in GiB</td>
<td>32</td>
<td>per container instance</td>
<td>No</td>
</tr>
<tr class="odd">
<td>CPU</td>
<td>Maximum number of vCPU</td>
<td>8</td>
<td>per container instance</td>
<td>No</td>
</tr>
<tr class="even">
<td>CPU<sup>1</sup></td>
<td>Maximum total CPU, in milli vCPU, allocated across all instances over a 1 minute period.</td>
<td>Depends on selected region. This limit might be greater in high-capacity regions or lower in recently opened regions.</td>
<td>per project and region</td>
<td>Yes</td>
</tr>
<tr class="odd">
<td>Memory<sup>1</sup></td>
<td>Maximum total memory, in bytes, allocated across all instances over a 1 minute period.</td>
<td>Depends on selected region. This limit might be greater in high-capacity regions or lower in recently opened regions. You can view your quota in the <a href="https://console.cloud.google.com/iam-admin/quotas">Quotas and system limits</a> console page.</td>
<td>per project and region</td>
<td>Yes</td>
</tr>
<tr class="even">
<td>GPU instance without zonal-redundancy guarantee<sup>1</sup>, <sup>4</sup></td>
<td>Maximum number of container instances with GPU</td>
<td>0<sup>4</sup></td>
<td>per project per region</td>
<td>Yes</td>
</tr>
<tr class="odd">
<td>GPU instance with zonal-redundancy guarantee<sup>1</sup>, <sup>4</sup></td>
<td>Maximum number of container instances with GPU</td>
<td>0<sup>4</sup></td>
<td>per project per region</td>
<td>Yes</td>
</tr>
<tr class="even">
<td>Disk</td>
<td>Maximum <a href="/run/docs/reference/container-contract#filesystem">writable, in-memory filesystem</a>, limited by instance memory, in GiB</td>
<td>32</td>
<td>per container instance</td>
<td>No</td>
</tr>
<tr class="odd">
<td>Environment variable</td>
<td>Maximum variable length, in Kb</td>
<td>32</td>
<td>per variable</td>
<td>No</td>
</tr>
<tr class="even">
<td>Domain mapping</td>
<td>Maximum number of SSL certificates</td>
<td>50</td>
<td>per top domain and per week</td>
<td>No</td>
</tr>
<tr class="odd">
<td>Domain mapping</td>
<td>Maximum number of duplicate SSL certificates</td>
<td>5</td>
<td>per top domain and per week</td>
<td>No</td>
</tr>
<tr class="even">
<td>Access token</td>
<td>Maximum number of unique <a href="/run/docs/securing/service-identity#access_tokens">access token</a> generated</td>
<td>50</td>
<td>per container instance per second</td>
<td>No</td>
</tr>
<tr class="odd">
<td>Identity token</td>
<td>Maximum number of unique <a href="/run/docs/securing/service-identity#identity_tokens">identity token</a> generated</td>
<td>50</td>
<td>per container instance per second</td>
<td>No</td>
</tr>
<tr class="even">
<td>Files opened</td>
<td>Maximum number of files that can be opened at the same time. Corresponds to<br />
<code translate="no" dir="ltr">/proc/sys/fs/file-max</code>.</td>
<td>25000</td>
<td>per container instance</td>
<td>No</td>
</tr>
</tbody>
</table>

<sup>1</sup>These regional [quotas](https://console.cloud.google.com/iam-admin/quotas?pageState=(%22allQuotasTable%22:(%22f%22:%22%255B%257B_22k_22_3A_22Metric_22_2C_22t_22_3A10_2C_22v_22_3A_22_5C_22run.googleapis.com%252Fcpu_allocation_5C_22_22_2C_22s_22_3Atrue_2C_22i_22_3A_22metricName_22%257D_2C%257B_22k_22_3A_22_22_2C_22t_22_3A10_2C_22v_22_3A_22_5C_22OR_5C_22_22_2C_22o_22_3Atrue%257D_2C%257B_22k_22_3A_22Metric_22_2C_22t_22_3A10_2C_22v_22_3A_22_5C_22run.googleapis.com%252Fmem_allocation_5C_22_22_2C_22s_22_3Atrue_2C_22i_22_3A_22metricName_22%257D_2C%257B_22k_22_3A_22_22_2C_22t_22_3A10_2C_22v_22_3A_22_5C_22OR_5C_22_22_2C_22o_22_3Atrue%257D_2C%257B_22k_22_3A_22Metric_22_2C_22t_22_3A10_2C_22v_22_3A_22_5C_22run.googleapis.com%252Fnvidia_l4_gpu_allocation_5C_22_22_2C_22s_22_3Atrue_2C_22i_22_3A_22metricName_22%257D_2C%257B_22k_22_3A_22_22_2C_22t_22_3A10_2C_22v_22_3A_22_5C_22OR_5C_22_22_2C_22o_22_3Atrue%257D_2C%257B_22k_22_3A_22_22_2C_22t_22_3A10_2C_22v_22_3A_22_5C_22run.googleapis.com%252Fnvidia_l4_gpu_allocation_no_zonal_redundancy_5C_22_22_2C_22s_22_3Atrue%257D_2C%257B_22k_22_3A_22_22_2C_22t_22_3A10_2C_22v_22_3A_22_5C_22OR_5C_22_22_2C_22o_22_3Atrue%257D_2C%257B_22k_22_3A_22_22_2C_22t_22_3A10_2C_22v_22_3A_22_5C_22run.googleapis.com%252Frun.googleapis.com%252Finstance_limit_regional_5C_22_22%257D%255D%22))) are used in a few cases where each controls:

1.  The maximum value that can be picked for the [maximum instance](/run/docs/configuring/max-instances) attribute of a revision. Once it is granted in a given region, all revisions in that region can go up to the granted limit.

2.  The maximum [parallelism](/run/docs/configuring/parallelism) of a job. Once it is granted in a given region, all jobs in that region can go up to the granted limit.

3.  The total container instances for running job executions in a region.

<sup>3</sup>This regional [quota](https://console.cloud.google.com/iam-admin/quotas?metric=run.googleapis.com/instance_limit_with_direct_vpc_egress_regional&usage=ALL) is used in a few cases:

1.  It controls the maximum value that can be picked for the [maximum instance](/run/docs/configuring/max-instances) attribute of a revision using Direct VPC egress. Once it is granted in a given region, all revisions in that region can go up to the granted limit.

2.  It controls the maximum [parallelism](/run/docs/configuring/parallelism) of a job using Direct VPC egress. Once it is granted in a given region, all jobs in that region can go up to the granted limit.

<span class="small"><sup>4</sup> New projects creating a service with L4 GPUs will be automatically granted 3 [NvidiaL4GpuAllocNoZonalRedundancyPerProjectRegion](https://console.cloud.google.com/projectselector2/iam-admin/quotas?pageState=%28%22allQuotasTable%22:%28%22f%22:%22%255B%257B_22k_22_3A_22Service_22_2C_22t_22_3A10_2C_22v_22_3A_22_5C_22Cloud%2520Run%2520Admin%2520API_5C_22_22_2C_22s_22_3Atrue_2C_22i_22_3A_22serviceTitle_22%257D_2C%257B_22k_22_3A_22Metric_22_2C_22t_22_3A10_2C_22v_22_3A_22_5C_22run.googleapis.com%252Fnvidia_l4_gpu_allocation_no_zonal_redundancy_5C_22_22_2C_22s_22_3Atrue_2C_22i_22_3A_22metricName_22%257D%255D%22%29%29). You can also request [NvidiaL4GpuAllocPerProjectRegion](https://console.cloud.google.com/projectselector2/iam-admin/quotas?pageState=%28%22allQuotasTable%22:%28%22f%22:%22%255B%257B_22k_22_3A_22Service_22_2C_22t_22_3A10_2C_22v_22_3A_22_5C_22Cloud%2520Run%2520Admin%2520API_5C_22_22_2C_22s_22_3Atrue_2C_22i_22_3A_22serviceTitle_22%257D_2C%257B_22k_22_3A_22Metric_22_2C_22t_22_3A10_2C_22v_22_3A_22_5C_22run.googleapis.com%252Fnvidia_l4_gpu_allocation_5C_22_22_2C_22s_22_3Atrue_2C_22i_22_3A_22metricName_22%257D%255D%22%29%29) or [NvidiaL4GpuAllocNoZonalRedundancyPerProjectRegion](https://console.cloud.google.com/projectselector2/iam-admin/quotas?pageState=%28%22allQuotasTable%22:%28%22f%22:%22%255B%257B_22k_22_3A_22Service_22_2C_22t_22_3A10_2C_22v_22_3A_22_5C_22Cloud%2520Run%2520Admin%2520API_5C_22_22_2C_22s_22_3Atrue_2C_22i_22_3A_22serviceTitle_22%257D_2C%257B_22k_22_3A_22Metric_22_2C_22t_22_3A10_2C_22v_22_3A_22_5C_22run.googleapis.com%252Fnvidia_l4_gpu_allocation_no_zonal_redundancy_5C_22_22_2C_22s_22_3Atrue_2C_22i_22_3A_22metricName_22%257D%255D%22%29%29) quota. If your peak GPU usage is not close to your quota, Google might decrease your quota.</span>

## Networking limits for Cloud Run

### Request limits for Cloud Run

| Resource               | Description                           | Limit      | Scope                                               | Notes                                                                  |
|------------------------|---------------------------------------|------------|-----------------------------------------------------|------------------------------------------------------------------------|
| Services               | Maximum number of concurrent requests | 1,000      | per instance                                        |                                                                        |
| Instances              | Maximum number of concurrent requests | 80         | per instance                                        |                                                                        |
| Services and Instances | Maximum number of concurrent streams  | 100        | per HTTP/2 client connection                        |                                                                        |
| Services               | Maximum time before timeout           | 60 minutes | per request                                         |                                                                        |
| Services and Instances | Maximum HTTP/1 request size           | 32 MiB     | per request                                         | Limit applies if using HTTP/1 server. No limit if using HTTP/2 server. |
| Services and Instances | Maximum HTTP/1 response size          | 32 MiB     | per response                                        | Limit applies if not using `Transfer-Encoding: chunked` or streaming.  |
| Services and Instances | Maximum number of open connections    | 50,000     | per instance per egress type                        | Doesn't apply to Direct VPC egress traffic.                            |
| Services and Instances | Outbound connections                  | 700        | per second per instance                             | Doesn't apply to Direct VPC egress traffic sent to the VPC network.    |
| Services and Instances | Outbound connections                  | 5,000      | per minute per instance                             | Doesn't apply to Direct VPC egress traffic sent to the VPC network.    |
| Services and Instances | Outbound DNS resolutions              | 1,000      | per second per instance                             |                                                                        |
| Services and Instances | Inbound requests                      | 800        | per second to an HTTP/1 container port per instance | Doesn't apply to HTTP/2 container ports.                               |

### Bandwidth limits for Cloud Run

The following bandwidth limits apply to Cloud Run services and instances:

| Resource               | Description                                                                     | Limit                     | Scope        | Notes                                                                                                                               |
|------------------------|---------------------------------------------------------------------------------|---------------------------|--------------|-------------------------------------------------------------------------------------------------------------------------------------|
| Services and Instances | Maximum bits for egress over [Direct VPC](/run/docs/configuring/vpc-direct-vpc) | 1 Gbps                    | per instance | Egress over Direct VPC egress to destinations on the VPC network.                                                                   |
| Services and Instances | Maximum bits, excluding egress over Direct VPC                                  | 600 Mbps                  | per instance | Based on the sum of ingress and egress bits, excluding egress over Direct VPC egress to destinations on the VPC network.            |
| Services and Instances | Maximum total packet rate, excluding egress over Direct VPC                     | 64,000 packets per second | per instance | Based on the sum of ingress packets and egress packets, excluding egress over Direct VPC egress to destinations on the VPC network. |

If any of these limits are reached, the Cloud Run instance will have limited bandwidth.

## Cloud Run Admin API rate Limits

The following rate limits apply to the [Cloud Run Admin API](/run/docs/reference/rest). They do not apply to the requests reaching your deployed Cloud Run services.

| Quota                                                                                                                                      | Description                                                                                                                                        | Limit                | Can be increased | Scope                  |
|--------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------|----------------------|------------------|------------------------|
| [Cloud Run Admin API read requests](https://console.cloud.google.com/iam-admin/quotas?metric=run.googleapis.com/read_regional&usage=ALL)   | The number of *API* reads per 60 seconds per region. This is *not* the number of read requests to your Cloud Run services, which is not limited.   | 3,000 per 60 seconds | Yes              | per project and region |
| [Cloud Run Admin API write requests](https://console.cloud.google.com/iam-admin/quotas?metric=run.googleapis.com/write_regional&usage=ALL) | The number of *API* writes per 60 seconds per region. This is *not* the number of write requests to your Cloud Run services, which is not limited. | 180 per 60 seconds   | Yes              | per project and region |
| [Job Run](https://console.cloud.google.com/iam-admin/quotas?metric=run.googleapis.com/run_job_regional&usage=ALL)                          | Maximum number of times a job can be executed per 60 seconds per region.                                                                           | 180 per 60 seconds   | Yes              | per project and region |

## How to increase quota

Cloud Quotas adjustment requests are subject to review. If your quota adjustment request requires review, you receive an email acknowledging receipt of your request. If you need further assistance, respond to the email. After reviewing your request, you receive an email notification indicating whether your request was approved.

<div>

<div class="section">

### Console

To adjust a quota value, follow these steps:

1.  In the Google Cloud console, go to the **IAM & Admin <span aria-label="and then">\></span> Quotas & System Limits** page:

    <a href="https://console.cloud.google.com/iam-admin/quotas" class="button button-primary" target="console" data-track-name="consoleLink" data-track-type="task" data-track-metadata-position="body" data-track-metadata-event-detail="iam-admin/quotas">Go to Quotas &amp; System Limits</a>

    If prompted to select a project, select the project that you want to adjust.

2.  Find the quota value that you want to update in the **Quota** column and select the checkbox next to the quota that you want to update.

    If needed, use the **Filter** search box to search for your quota.

3.  Click <span class="material-symbols-outlined" style="vertical-align: bottom" aria-hidden="true" translate="no">create</span>**Edit** and the **Quota changes** dialog appears.

4.  Enter the quota value that you want in the **New value** field. Some quota values have a unit of measurement; if this applies, select the unit that you want in the adjacent list. Click **Done**.

    Optional: If you see a checkbox with the text `I understand that this request will remove any overrides`, it means that adjusting the quota value to a number equal to or greater than the default will remove the previous [quota override](/docs/quotas/view-manage#create_override). If this is what you want, select the checkbox and proceed.

5.  To increase your quota value greater than the number indicated on the dialog, select **Apply for higher quota**.

    1.  In the **Quota changes** form, enter the updated quota value that you want in the **New value** field. If a **Request description** field appears, enter a description. Click **Done**.

    2.  If a **Next** button appears, click **Next** and fill out your contact details in the screen that follows.

6.  Click **Submit request**.

If you find that you can't request an adjustment from the console, request the increase from [Cloud Customer Care](/support).

To learn more about how the quota increase process works, see <a href="/docs/quotas/overview#about_increase_requests" data-track-type="quotas" data-track-name="quotaLink">About quota adjustments</a>.

#### Batching requests for higher quota values

You can batch requests for higher quota by selecting the checkbox next to each quota that you want to include. However, batching requests can increase the amount of time it takes for Google Cloud to review your request.

To reduce review time, group quota adjustment requests by product and area. For example, if you want to request adjustments to networking and Compute Engine VM quotas, create one request for the networking quotas and another request for the Compute Engine VM quotas.

</div>

</div>

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
