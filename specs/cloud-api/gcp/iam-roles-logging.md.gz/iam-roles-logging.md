# Cloud Logging roles and permissions

<div class="devsite-article-body clearfix">

This page lists the IAM roles and permissions for Cloud Logging. To search through all roles and permissions, see the [role and permission index](/iam/docs/roles-permissions).

## Cloud Logging roles

<div results-count-container="">

</div>

<table class="fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="50%">Role</th>
<th>Permissions</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td class="role-description"><h4 id="logging.admin" class="role-title add-link" data-text="Logging Admin " tabindex="-1">Logging Admin</h4>
<p>(<code translate="no" dir="ltr">roles/logging.admin</code>)</p>
<span class="role-description custom"> </span>
<p>Provides all permissions necessary to use all features of Cloud Logging.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>View</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">logging.buckets.copyLogEntries</code></p>
<p><code translate="no" dir="ltr">logging.buckets.create</code></p>
<p><code translate="no" dir="ltr">logging.buckets.createTagBinding</code></p>
<p><code translate="no" dir="ltr">logging.buckets.delete</code></p>
<p><code translate="no" dir="ltr">logging.buckets.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">logging.buckets.get</code></p>
<p><code translate="no" dir="ltr">logging.buckets.list</code></p>
<p><code translate="no" dir="ltr">logging.buckets.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">logging.buckets.listTagBindings</code></p>
<p><code translate="no" dir="ltr">logging.buckets.undelete</code></p>
<p><code translate="no" dir="ltr">logging.buckets.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">logging.exclusions.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">logging.exclusions.create</code></li>
<li><code translate="no" dir="ltr">logging.exclusions.delete</code></li>
<li><code translate="no" dir="ltr">logging.exclusions.get</code></li>
<li><code translate="no" dir="ltr">logging.exclusions.list</code></li>
<li><code translate="no" dir="ltr">logging.exclusions.update</code></li>
</ul>
<p><code translate="no" dir="ltr">logging.fields.access</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">logging.links.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">logging.links.create</code></li>
<li><code translate="no" dir="ltr">logging.links.delete</code></li>
<li><code translate="no" dir="ltr">logging.links.get</code></li>
<li><code translate="no" dir="ltr">logging.links.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">logging.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">logging.locations.get</code></li>
<li><code translate="no" dir="ltr">logging.locations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">logging.logEntries.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">logging.logEntries.create</code></li>
<li><code translate="no" dir="ltr">logging.logEntries.download</code></li>
<li><code translate="no" dir="ltr">logging.logEntries.list</code></li>
<li><code translate="no" dir="ltr">logging.logEntries.route</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">logging.logMetrics.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">logging.logMetrics.create</code></li>
<li><code translate="no" dir="ltr">logging.logMetrics.delete</code></li>
<li><code translate="no" dir="ltr">logging.logMetrics.get</code></li>
<li><code translate="no" dir="ltr">logging.logMetrics.list</code></li>
<li><code translate="no" dir="ltr">logging.logMetrics.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">logging.logScopes.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">logging.logScopes.create</code></li>
<li><code translate="no" dir="ltr">logging.logScopes.delete</code></li>
<li><code translate="no" dir="ltr">logging.logScopes.get</code></li>
<li><code translate="no" dir="ltr">logging.logScopes.list</code></li>
<li><code translate="no" dir="ltr">logging.logScopes.update</code></li>
</ul>
<p><code translate="no" dir="ltr">logging.logServiceIndexes.list</code></p>
<p><code translate="no" dir="ltr">logging.logServices.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">logging.logs.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">logging.logs.delete</code></li>
<li><code translate="no" dir="ltr">logging.logs.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">logging.notificationRules.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">logging.notificationRules.create</code></li>
<li><code translate="no" dir="ltr">logging.notificationRules.delete</code></li>
<li><code translate="no" dir="ltr">logging.notificationRules.get</code></li>
<li><code translate="no" dir="ltr">logging.notificationRules.list</code></li>
<li><code translate="no" dir="ltr">logging.notificationRules.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">logging.operations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">logging.operations.cancel</code></li>
<li><code translate="no" dir="ltr">logging.operations.get</code></li>
<li><code translate="no" dir="ltr">logging.operations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">logging.privateLogEntries.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">logging.queries.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">logging.queries.deleteShared</code></li>
<li><code translate="no" dir="ltr">logging.queries.getShared</code></li>
<li><code translate="no" dir="ltr">logging.queries.listShared</code></li>
<li><code translate="no" dir="ltr">logging.queries.share</code></li>
<li><code translate="no" dir="ltr">logging.queries.updateShared</code></li>
<li><code translate="no" dir="ltr">logging.queries.usePrivate</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">logging.settings.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">logging.settings.get</code></li>
<li><code translate="no" dir="ltr">logging.settings.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">logging.sinks.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">logging.sinks.create</code></li>
<li><code translate="no" dir="ltr">logging.sinks.delete</code></li>
<li><code translate="no" dir="ltr">logging.sinks.get</code></li>
<li><code translate="no" dir="ltr">logging.sinks.list</code></li>
<li><code translate="no" dir="ltr">logging.sinks.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">logging.sqlAlerts.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">logging.sqlAlerts.create</code></li>
<li><code translate="no" dir="ltr">logging.sqlAlerts.update</code></li>
</ul>
<p><code translate="no" dir="ltr">logging.usage.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">logging.views.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">logging.views.access</code></li>
<li><code translate="no" dir="ltr">logging.views.create</code></li>
<li><code translate="no" dir="ltr">logging.views.delete</code></li>
<li><code translate="no" dir="ltr">logging.views.get</code></li>
<li><code translate="no" dir="ltr">logging.views.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">logging.views.list</code></li>
<li><code translate="no" dir="ltr">logging.views.listLogs</code></li>
<li><code translate="no" dir="ltr">logging.views.listResourceKeys</code></li>
<li><code translate="no" dir="ltr">logging.views.listResourceValues</code></li>
<li><code translate="no" dir="ltr">logging.views.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">logging.views.update</code></li>
</ul>
<p><code translate="no" dir="ltr">observability.scopes.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="logging.bucketWriter" class="role-title add-link" data-text="Logs Bucket Writer " tabindex="-1">Logs Bucket Writer</h4>
<p>(<code translate="no" dir="ltr">roles/logging.bucketWriter</code>)</p>
<span class="role-description"> </span>
<p>Ability to write logs to a log bucket.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Project</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">logging.buckets.write</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="logging.logWriter" class="role-title add-link" data-text="Logs Writer " tabindex="-1">Logs Writer</h4>
<p>(<code translate="no" dir="ltr">roles/logging.logWriter</code>)</p>
<span class="role-description custom"> </span>
<p>Provides the permissions to write log entries.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Project</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">logging.logEntries.create</code></p>
<p><code translate="no" dir="ltr">logging.logEntries.route</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="logging.privateLogViewer" class="role-title add-link" data-text="Private Logs Viewer " tabindex="-1">Private Logs Viewer</h4>
<p>(<code translate="no" dir="ltr">roles/logging.privateLogViewer</code>)</p>
<span class="role-description custom"> </span>
<p>Provides permissions of the Logs Viewer role and in addition, provides read-only access to log entries in private logs.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>View</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">logging.buckets.get</code></p>
<p><code translate="no" dir="ltr">logging.buckets.list</code></p>
<p><code translate="no" dir="ltr">logging.buckets.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">logging.buckets.listTagBindings</code></p>
<p><code translate="no" dir="ltr">logging.exclusions.get</code></p>
<p><code translate="no" dir="ltr">logging.exclusions.list</code></p>
<p><code translate="no" dir="ltr">logging.links.get</code></p>
<p><code translate="no" dir="ltr">logging.links.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">logging.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">logging.locations.get</code></li>
<li><code translate="no" dir="ltr">logging.locations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">logging.logEntries.list</code></p>
<p><code translate="no" dir="ltr">logging.logMetrics.get</code></p>
<p><code translate="no" dir="ltr">logging.logMetrics.list</code></p>
<p><code translate="no" dir="ltr">logging.logServiceIndexes.list</code></p>
<p><code translate="no" dir="ltr">logging.logServices.list</code></p>
<p><code translate="no" dir="ltr">logging.logs.list</code></p>
<p><code translate="no" dir="ltr">logging.notificationRules.get</code></p>
<p><code translate="no" dir="ltr">logging.notificationRules.list</code></p>
<p><code translate="no" dir="ltr">logging.operations.get</code></p>
<p><code translate="no" dir="ltr">logging.operations.list</code></p>
<p><code translate="no" dir="ltr">logging.privateLogEntries.list</code></p>
<p><code translate="no" dir="ltr">logging.queries.getShared</code></p>
<p><code translate="no" dir="ltr">logging.queries.listShared</code></p>
<p><code translate="no" dir="ltr">logging.queries.usePrivate</code></p>
<p><code translate="no" dir="ltr">logging.settings.get</code></p>
<p><code translate="no" dir="ltr">logging.sinks.get</code></p>
<p><code translate="no" dir="ltr">logging.sinks.list</code></p>
<p><code translate="no" dir="ltr">logging.usage.get</code></p>
<p><code translate="no" dir="ltr">logging.views.access</code></p>
<p><code translate="no" dir="ltr">logging.views.get</code></p>
<p><code translate="no" dir="ltr">logging.views.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">logging.views.list</code></p>
<p><code translate="no" dir="ltr">observability.scopes.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="logging.viewer" class="role-title add-link" data-text="Logs Viewer " tabindex="-1">Logs Viewer</h4>
<p>(<code translate="no" dir="ltr">roles/logging.viewer</code>)</p>
<span class="role-description custom"> </span>
<p>Provides access to view logs.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>View</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">logging.buckets.get</code></p>
<p><code translate="no" dir="ltr">logging.buckets.list</code></p>
<p><code translate="no" dir="ltr">logging.buckets.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">logging.buckets.listTagBindings</code></p>
<p><code translate="no" dir="ltr">logging.exclusions.get</code></p>
<p><code translate="no" dir="ltr">logging.exclusions.list</code></p>
<p><code translate="no" dir="ltr">logging.links.get</code></p>
<p><code translate="no" dir="ltr">logging.links.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">logging.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">logging.locations.get</code></li>
<li><code translate="no" dir="ltr">logging.locations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">logging.logEntries.list</code></p>
<p><code translate="no" dir="ltr">logging.logMetrics.get</code></p>
<p><code translate="no" dir="ltr">logging.logMetrics.list</code></p>
<p><code translate="no" dir="ltr">logging.logScopes.get</code></p>
<p><code translate="no" dir="ltr">logging.logScopes.list</code></p>
<p><code translate="no" dir="ltr">logging.logServiceIndexes.list</code></p>
<p><code translate="no" dir="ltr">logging.logServices.list</code></p>
<p><code translate="no" dir="ltr">logging.logs.list</code></p>
<p><code translate="no" dir="ltr">logging.notificationRules.get</code></p>
<p><code translate="no" dir="ltr">logging.notificationRules.list</code></p>
<p><code translate="no" dir="ltr">logging.operations.get</code></p>
<p><code translate="no" dir="ltr">logging.operations.list</code></p>
<p><code translate="no" dir="ltr">logging.queries.getShared</code></p>
<p><code translate="no" dir="ltr">logging.queries.listShared</code></p>
<p><code translate="no" dir="ltr">logging.queries.usePrivate</code></p>
<p><code translate="no" dir="ltr">logging.settings.get</code></p>
<p><code translate="no" dir="ltr">logging.sinks.get</code></p>
<p><code translate="no" dir="ltr">logging.sinks.list</code></p>
<p><code translate="no" dir="ltr">logging.usage.get</code></p>
<p><code translate="no" dir="ltr">logging.views.get</code></p>
<p><code translate="no" dir="ltr">logging.views.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">logging.views.list</code></p>
<p><code translate="no" dir="ltr">observability.scopes.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="logging.configWriter" class="role-title add-link" data-text="Logs Configuration Writer " tabindex="-1">Logs Configuration Writer</h4>
<p>(<code translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<span class="role-description custom"> </span>
<p>Provides permissions to read and write the configurations of logs-based metrics and sinks for exporting logs.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>View</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">logging.buckets.create</code></p>
<p><code translate="no" dir="ltr">logging.buckets.createTagBinding</code></p>
<p><code translate="no" dir="ltr">logging.buckets.delete</code></p>
<p><code translate="no" dir="ltr">logging.buckets.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">logging.buckets.get</code></p>
<p><code translate="no" dir="ltr">logging.buckets.list</code></p>
<p><code translate="no" dir="ltr">logging.buckets.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">logging.buckets.listTagBindings</code></p>
<p><code translate="no" dir="ltr">logging.buckets.undelete</code></p>
<p><code translate="no" dir="ltr">logging.buckets.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">logging.exclusions.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">logging.exclusions.create</code></li>
<li><code translate="no" dir="ltr">logging.exclusions.delete</code></li>
<li><code translate="no" dir="ltr">logging.exclusions.get</code></li>
<li><code translate="no" dir="ltr">logging.exclusions.list</code></li>
<li><code translate="no" dir="ltr">logging.exclusions.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">logging.links.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">logging.links.create</code></li>
<li><code translate="no" dir="ltr">logging.links.delete</code></li>
<li><code translate="no" dir="ltr">logging.links.get</code></li>
<li><code translate="no" dir="ltr">logging.links.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">logging.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">logging.locations.get</code></li>
<li><code translate="no" dir="ltr">logging.locations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">logging.logMetrics.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">logging.logMetrics.create</code></li>
<li><code translate="no" dir="ltr">logging.logMetrics.delete</code></li>
<li><code translate="no" dir="ltr">logging.logMetrics.get</code></li>
<li><code translate="no" dir="ltr">logging.logMetrics.list</code></li>
<li><code translate="no" dir="ltr">logging.logMetrics.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">logging.logScopes.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">logging.logScopes.create</code></li>
<li><code translate="no" dir="ltr">logging.logScopes.delete</code></li>
<li><code translate="no" dir="ltr">logging.logScopes.get</code></li>
<li><code translate="no" dir="ltr">logging.logScopes.list</code></li>
<li><code translate="no" dir="ltr">logging.logScopes.update</code></li>
</ul>
<p><code translate="no" dir="ltr">logging.logServiceIndexes.list</code></p>
<p><code translate="no" dir="ltr">logging.logServices.list</code></p>
<p><code translate="no" dir="ltr">logging.logs.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">logging.notificationRules.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">logging.notificationRules.create</code></li>
<li><code translate="no" dir="ltr">logging.notificationRules.delete</code></li>
<li><code translate="no" dir="ltr">logging.notificationRules.get</code></li>
<li><code translate="no" dir="ltr">logging.notificationRules.list</code></li>
<li><code translate="no" dir="ltr">logging.notificationRules.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">logging.operations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">logging.operations.cancel</code></li>
<li><code translate="no" dir="ltr">logging.operations.get</code></li>
<li><code translate="no" dir="ltr">logging.operations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">logging.settings.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">logging.settings.get</code></li>
<li><code translate="no" dir="ltr">logging.settings.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">logging.sinks.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">logging.sinks.create</code></li>
<li><code translate="no" dir="ltr">logging.sinks.delete</code></li>
<li><code translate="no" dir="ltr">logging.sinks.get</code></li>
<li><code translate="no" dir="ltr">logging.sinks.list</code></li>
<li><code translate="no" dir="ltr">logging.sinks.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">logging.sqlAlerts.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">logging.sqlAlerts.create</code></li>
<li><code translate="no" dir="ltr">logging.sqlAlerts.update</code></li>
</ul>
<p><code translate="no" dir="ltr">logging.views.create</code></p>
<p><code translate="no" dir="ltr">logging.views.delete</code></p>
<p><code translate="no" dir="ltr">logging.views.get</code></p>
<p><code translate="no" dir="ltr">logging.views.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">logging.views.list</code></p>
<p><code translate="no" dir="ltr">logging.views.update</code></p>
<p><code translate="no" dir="ltr">observability.scopes.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="logging.fieldAccessor" class="role-title add-link" data-text="Log Field Accessor " tabindex="-1">Log Field Accessor</h4>
<p>(<code translate="no" dir="ltr">roles/logging.fieldAccessor</code>)</p>
<span class="role-description"> </span>
<p>Ability to read restricted fields in a log bucket.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Project</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">logging.fields.access</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="logging.linkViewer" class="role-title add-link" data-text="Log Link Accessor " tabindex="-1">Log Link Accessor</h4>
<p>(<code translate="no" dir="ltr">roles/logging.linkViewer</code>)</p>
<span class="role-description"> </span>
<p>Ability to see links for a bucket.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">logging.links.get</code></p>
<p><code translate="no" dir="ltr">logging.links.list</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="logging.sqlAlertWriter" class="role-title add-link" data-text="SQL Alert Writer Beta " tabindex="-1">SQL Alert Writer <sup>Beta</sup></h4>
<p>(<code translate="no" dir="ltr">roles/logging.sqlAlertWriter</code>)</p>
<span class="role-description"> </span>
<p>Ability to write SQL Alerts.</p></td>
<td class="role-permissions"><p><span class="iamperm-wildcard"><code translate="no" dir="ltr">logging.sqlAlerts.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">logging.sqlAlerts.create</code></li>
<li><code translate="no" dir="ltr">logging.sqlAlerts.update</code></li>
</ul></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="logging.viewAccessor" class="role-title add-link" data-text="Logs View Accessor " tabindex="-1">Logs View Accessor</h4>
<p>(<code translate="no" dir="ltr">roles/logging.viewAccessor</code>)</p>
<span class="role-description"> </span>
<p>Ability to read logs in a view.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>View</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">logging.logEntries.download</code></p>
<p><code translate="no" dir="ltr">logging.views.access</code></p>
<p><code translate="no" dir="ltr">logging.views.listLogs</code></p>
<p><code translate="no" dir="ltr">logging.views.listResourceKeys</code></p>
<p><code translate="no" dir="ltr">logging.views.listResourceValues</code></p></td>
</tr>
</tbody>
</table>

### Service agent roles

Service agent roles should only be granted to [service agents](/iam/docs/service-agents).

<div results-count-container="">

</div>

<table class="fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="50%">Role</th>
<th>Permissions</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td class="role-description"><h4 id="logging.serviceAgent" class="role-title add-link" data-text="Cloud Logging Service Agent " tabindex="-1">Cloud Logging Service Agent</h4>
<p>(<code translate="no" dir="ltr">roles/logging.serviceAgent</code>)</p>
<span class="role-description"> </span>
<p>Grants a Cloud Logging Service Account the ability to create and link datasets.</p>
<strong>Warning:</strong> Do not grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.</td>
<td class="role-permissions"><p><code translate="no" dir="ltr">bigquery.datasets.create</code></p>
<p><code translate="no" dir="ltr">bigquery.datasets.get</code></p>
<p><code translate="no" dir="ltr">bigquery.datasets.link</code></p></td>
</tr>
</tbody>
</table>

## Cloud Logging permissions

<div results-count-container="">

</div>

<table class="permissions-table fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="45%">Permission</th>
<th>Included in roles</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td><h4 id="logging.buckets.copyLogEntries" class="permission-name add-link" data-text="logging.buckets.copyLogEntries" tabindex="-1"><code translate="no" dir="ltr">logging.buckets.copyLogEntries</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="logging.buckets.create" class="permission-name add-link" data-text="logging.buckets.create" tabindex="-1"><code translate="no" dir="ltr">logging.buckets.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/apigee#apigee.coreServiceAgent">Apigee Core Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.coreServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/apigee#apigee.serviceAgent">Apigee Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasetelemetry#firebasetelemetry.serviceAgent">Firebase Telemetry Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasetelemetry.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkehub#gkehub.serviceAgent">GKE Hub Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="logging.buckets.createTagBinding" class="permission-name add-link" data-text="logging.buckets.createTagBinding" tabindex="-1"><code translate="no" dir="ltr">logging.buckets.createTagBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="logging.buckets.delete" class="permission-name add-link" data-text="logging.buckets.delete" tabindex="-1"><code translate="no" dir="ltr">logging.buckets.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="logging.buckets.deleteTagBinding" class="permission-name add-link" data-text="logging.buckets.deleteTagBinding" tabindex="-1"><code translate="no" dir="ltr">logging.buckets.deleteTagBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="logging.buckets.get" class="permission-name add-link" data-text="logging.buckets.get" tabindex="-1"><code translate="no" dir="ltr">logging.buckets.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.admin">Discovery Engine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.privateLogViewer">Private Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.privateLogViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.viewer">Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.hubAgent">Dataproc Hub Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.hubAgent</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceAdmin">Gemini Enterprise Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier1">Telco Automation Tier 1 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier1</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier4">Telco Automation Tier 4 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier4</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/apigee#apigee.coreServiceAgent">Apigee Core Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.coreServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/apigee#apigee.serviceAgent">Apigee Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasetelemetry#firebasetelemetry.serviceAgent">Firebase Telemetry Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasetelemetry.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkehub#gkehub.serviceAgent">GKE Hub Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="logging.buckets.list" class="permission-name add-link" data-text="logging.buckets.list" tabindex="-1"><code translate="no" dir="ltr">logging.buckets.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.admin">Discovery Engine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.privateLogViewer">Private Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.privateLogViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.viewer">Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.hubAgent">Dataproc Hub Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.hubAgent</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceAdmin">Gemini Enterprise Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier1">Telco Automation Tier 1 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier1</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier4">Telco Automation Tier 4 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier4</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/apigee#apigee.coreServiceAgent">Apigee Core Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.coreServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/apigee#apigee.serviceAgent">Apigee Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.serviceAgent">Audit Manager Auditing Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.serviceAgent">Cloud Security Compliance Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasetelemetry#firebasetelemetry.serviceAgent">Firebase Telemetry Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasetelemetry.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkehub#gkehub.serviceAgent">GKE Hub Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="logging.buckets.listEffectiveTags" class="permission-name add-link" data-text="logging.buckets.listEffectiveTags" tabindex="-1"><code translate="no" dir="ltr">logging.buckets.listEffectiveTags</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.admin">Discovery Engine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.privateLogViewer">Private Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.privateLogViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.viewer">Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagViewer">Tag Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.hubAgent">Dataproc Hub Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.hubAgent</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceAdmin">Gemini Enterprise Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier1">Telco Automation Tier 1 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier1</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier4">Telco Automation Tier 4 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier4</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="logging.buckets.listTagBindings" class="permission-name add-link" data-text="logging.buckets.listTagBindings" tabindex="-1"><code translate="no" dir="ltr">logging.buckets.listTagBindings</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.admin">Discovery Engine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.privateLogViewer">Private Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.privateLogViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.viewer">Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagViewer">Tag Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.hubAgent">Dataproc Hub Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.hubAgent</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceAdmin">Gemini Enterprise Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier1">Telco Automation Tier 1 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier1</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier4">Telco Automation Tier 4 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier4</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="logging.buckets.undelete" class="permission-name add-link" data-text="logging.buckets.undelete" tabindex="-1"><code translate="no" dir="ltr">logging.buckets.undelete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="logging.buckets.update" class="permission-name add-link" data-text="logging.buckets.update" tabindex="-1"><code translate="no" dir="ltr">logging.buckets.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasetelemetry#firebasetelemetry.serviceAgent">Firebase Telemetry Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasetelemetry.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkehub#gkehub.serviceAgent">GKE Hub Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="logging.buckets.write" class="permission-name add-link" data-text="logging.buckets.write" tabindex="-1"><code translate="no" dir="ltr">logging.buckets.write</code></h4></td>
<td><p><a href="/iam/docs/roles-permissions/logging#logging.bucketWriter">Logs Bucket Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.bucketWriter</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.loggingServiceAgent">Cloud Build Logging Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.loggingServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="logging.exclusions.create" class="permission-name add-link" data-text="logging.exclusions.create" tabindex="-1"><code translate="no" dir="ltr">logging.exclusions.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkehub#gkehub.serviceAgent">GKE Hub Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="logging.exclusions.delete" class="permission-name add-link" data-text="logging.exclusions.delete" tabindex="-1"><code translate="no" dir="ltr">logging.exclusions.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkehub#gkehub.serviceAgent">GKE Hub Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="logging.exclusions.get" class="permission-name add-link" data-text="logging.exclusions.get" tabindex="-1"><code translate="no" dir="ltr">logging.exclusions.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.admin">Discovery Engine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.privateLogViewer">Private Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.privateLogViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.viewer">Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/accesscontextmanager#accesscontextmanager.vpcScTroubleshooterViewer">VPC Service Controls Troubleshooter Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/accesscontextmanager.vpcScTroubleshooterViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.hubAgent">Dataproc Hub Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.hubAgent</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceAdmin">Gemini Enterprise Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier1">Telco Automation Tier 1 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier1</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier4">Telco Automation Tier 4 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier4</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkehub#gkehub.serviceAgent">GKE Hub Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="logging.exclusions.list" class="permission-name add-link" data-text="logging.exclusions.list" tabindex="-1"><code translate="no" dir="ltr">logging.exclusions.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.admin">Discovery Engine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.privateLogViewer">Private Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.privateLogViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.viewer">Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/accesscontextmanager#accesscontextmanager.vpcScTroubleshooterViewer">VPC Service Controls Troubleshooter Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/accesscontextmanager.vpcScTroubleshooterViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.hubAgent">Dataproc Hub Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.hubAgent</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceAdmin">Gemini Enterprise Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier1">Telco Automation Tier 1 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier1</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier4">Telco Automation Tier 4 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier4</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkehub#gkehub.serviceAgent">GKE Hub Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="logging.exclusions.update" class="permission-name add-link" data-text="logging.exclusions.update" tabindex="-1"><code translate="no" dir="ltr">logging.exclusions.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkehub#gkehub.serviceAgent">GKE Hub Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="logging.fields.access" class="permission-name add-link" data-text="logging.fields.access" tabindex="-1"><code translate="no" dir="ltr">logging.fields.access</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.fieldAccessor">Log Field Accessor</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.fieldAccessor</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="logging.links.create" class="permission-name add-link" data-text="logging.links.create" tabindex="-1"><code translate="no" dir="ltr">logging.links.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="logging.links.delete" class="permission-name add-link" data-text="logging.links.delete" tabindex="-1"><code translate="no" dir="ltr">logging.links.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="logging.links.get" class="permission-name add-link" data-text="logging.links.get" tabindex="-1"><code translate="no" dir="ltr">logging.links.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.admin">Discovery Engine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.privateLogViewer">Private Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.privateLogViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.viewer">Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.hubAgent">Dataproc Hub Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.hubAgent</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceAdmin">Gemini Enterprise Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.linkViewer">Log Link Accessor</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.linkViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier1">Telco Automation Tier 1 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier1</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier4">Telco Automation Tier 4 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier4</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="logging.links.list" class="permission-name add-link" data-text="logging.links.list" tabindex="-1"><code translate="no" dir="ltr">logging.links.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.admin">Discovery Engine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.privateLogViewer">Private Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.privateLogViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.viewer">Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.hubAgent">Dataproc Hub Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.hubAgent</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceAdmin">Gemini Enterprise Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.linkViewer">Log Link Accessor</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.linkViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier1">Telco Automation Tier 1 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier1</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier4">Telco Automation Tier 4 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier4</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/monitoring#monitoring.notificationServiceAgent">Monitoring Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/monitoring.notificationServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="logging.locations.get" class="permission-name add-link" data-text="logging.locations.get" tabindex="-1"><code translate="no" dir="ltr">logging.locations.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.admin">Discovery Engine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.privateLogViewer">Private Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.privateLogViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.viewer">Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.hubAgent">Dataproc Hub Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.hubAgent</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceAdmin">Gemini Enterprise Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier1">Telco Automation Tier 1 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier1</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier4">Telco Automation Tier 4 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier4</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="logging.locations.list" class="permission-name add-link" data-text="logging.locations.list" tabindex="-1"><code translate="no" dir="ltr">logging.locations.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.admin">Discovery Engine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.privateLogViewer">Private Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.privateLogViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.viewer">Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.hubAgent">Dataproc Hub Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.hubAgent</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceAdmin">Gemini Enterprise Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier1">Telco Automation Tier 1 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier1</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier4">Telco Automation Tier 4 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier4</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="logging.logEntries.create" class="permission-name add-link" data-text="logging.logEntries.create" tabindex="-1"><code translate="no" dir="ltr">logging.logEntries.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.logWriter">Logs Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.logWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/run#run.builder">Cloud Run Builder</a> (<code class="role-name" translate="no" dir="ltr">roles/run.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/clouddeploy#clouddeploy.jobRunner">Cloud Deploy Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploy.jobRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/confidentialcomputing#confidentialcomputing.gkeWorkloadUser">Confidential GKE Workload User</a> (<code class="role-name" translate="no" dir="ltr">roles/confidentialcomputing.gkeWorkloadUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/confidentialcomputing#confidentialcomputing.workloadUser">Confidential Space Workload User</a> (<code class="role-name" translate="no" dir="ltr">roles/confidentialcomputing.workloadUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/config#config.agent">Cloud Infrastructure Manager Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/config.agent</code>)</p>
<p><a href="/iam/docs/roles-permissions/container#container.defaultNodeServiceAccount">Kubernetes Engine Default Node Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/container.defaultNodeServiceAccount</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.worker">Dataflow Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.hubAgent">Dataproc Hub Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.hubAgent</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.worker">Dataproc Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/developerconnect#developerconnect.insightsAgent">Developer Connect Insights Config Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/developerconnect.insightsAgent</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkemulticloud#gkemulticloud.telemetryWriter">Anthos Multi-cloud Telemetry Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/gkemulticloud.telemetryWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/storagetransfer#storagetransfer.transferAgent">Storage Transfer Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/storagetransfer.transferAgent</code>)</p>
<p><a href="/iam/docs/roles-permissions/telemetry#telemetry.logsWriter">Cloud Telemetry Logs Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/telemetry.logsWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/telemetry#telemetry.writer">Cloud Telemetry Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/telemetry.writer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.agentSandboxServiceAgent">Vertex AI Agent Sandbox Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.agentSandboxServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.customCodeServiceAgent">Vertex AI Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.customCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.extensionCustomCodeServiceAgent">Vertex AI Extension Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.extensionCustomCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.extensionServiceAgent">Vertex AI Extension Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.extensionServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.notebookServiceAgent">Vertex AI Notebook Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.notebookServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.ragServiceAgent">Vertex AI RAG Data Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.ragServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.reasoningEngineServiceAgent">Vertex AI Reasoning Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.reasoningEngineServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.telemetryServiceAgent">Vertex AI Telemetry Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.telemetryServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/flow#aisandbox.serviceAgent">FlowService Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aisandbox.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/anthosservicemesh#anthosservicemesh.serviceAgent">Anthos Service Mesh Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/anthosservicemesh.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/apigee#apigee.coreServiceAgent">Apigee Core Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.coreServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/apigee#apigee.serviceAgent">Apigee Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengineflex#appengineflex.serviceAgent">App Engine flexible environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengineflex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.serviceAgent">Recommendations AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/bigqueryconnection#bigqueryconnection.serviceAgent">BigQuery Connection Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/bigqueryconnection.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/bigquerydatatransfer#bigquerydatatransfer.serviceAgent">BigQuery Data Transfer Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatatransfer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ces#ces.serviceAgent">Customer Engagement Suite Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ces.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.serviceAgent">Chronicle Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudaicompanion#cloudaicompanion.serviceAgent">Gemini for Google Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudaicompanion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudconfig#cloudconfig.serviceAgent">Infrastructure Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudconfig.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/clouddeploy#clouddeploy.serviceAgent">Cloud Deploy Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploy.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudiot#cloudiot.serviceAgent">Cloud IoT Core Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudiot.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.serviceAgent">Cloud Scheduler Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.serviceAgent">Cloud Tasks Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/tpu#cloudtpu.serviceAgent">Cloud TPU V2 API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtpu.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/compute#compute.serviceAgent">Compute Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.defaultNodeServiceAgent">Kubernetes Engine Default Node Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.defaultNodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.nodeServiceAgent">[Deprecated] Kubernetes Engine Node Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.nodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/databaseinsights#databaseinsights.serviceAgent">Database Insights Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/databaseinsights.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprocrm#dataprocrm.nodeServiceAgent">Dataproc Resource Manager Node Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprocrm.nodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dialogflow#dialogflow.serviceAgent">Dialogflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dialogflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.serviceAgent">Discovery Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/edgecontainer#edgecontainer.clusterServiceAgent">Edge Container Cluster Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/edgecontainer.clusterServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebaseml#firebaseml.serviceAgent">Firebase AI Logic Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasetelemetry#firebasetelemetry.serviceAgent">Firebase Telemetry Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasetelemetry.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/flow#flow.serviceAgent">Flow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/flow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkemulticloud#gkemulticloud.containerServiceAgent">Anthos Multi-Cloud Container Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkemulticloud.containerServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.serviceAgent">Cluster Director Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/meshcontrolplane#meshcontrolplane.serviceAgent">Mesh Managed Control Plane Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/meshcontrolplane.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/anthosservicemesh#meshdataplane.serviceAgent">Mesh Data Plane Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/meshdataplane.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/rapidmigrationassessment#rapidmigrationassessment.serviceAgent">RMA Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/rapidmigrationassessment.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/retail#retail.serviceAgent">Retail Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/retail.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/spanner#spanner.serviceAgent">Cloud Spanner API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/spanner.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visionai#visionai.serviceAgent">Cloud Vision AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visionai.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vpcaccess#vpcaccess.serviceAgent">Serverless VPC Access Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vpcaccess.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="logging.logEntries.download" class="permission-name add-link" data-text="logging.logEntries.download" tabindex="-1"><code translate="no" dir="ltr">logging.logEntries.download</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebasecrash#firebasecrashlytics.admin">Firebase Crashlytics Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasecrashlytics.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebasecrash#firebasecrashlytics.viewer">Firebase Crashlytics Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasecrashlytics.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.qualityAdmin">Firebase Quality Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.qualityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.qualityViewer">Firebase Quality Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.qualityViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.viewAccessor">Logs View Accessor</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.viewAccessor</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="logging.logEntries.list" class="permission-name add-link" data-text="logging.logEntries.list" tabindex="-1"><code translate="no" dir="ltr">logging.logEntries.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/billing#billing.admin">Billing Account Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/billing.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.admin">Discovery Engine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.privateLogViewer">Private Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.privateLogViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.viewer">Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/accesscontextmanager#accesscontextmanager.vpcScTroubleshooterViewer">VPC Service Controls Troubleshooter Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/accesscontextmanager.vpcScTroubleshooterViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.hubAgent">Dataproc Hub Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.hubAgent</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceAdmin">Gemini Enterprise Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developAdmin">Firebase Develop Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.developViewer">Firebase Develop Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.developViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier1">Telco Automation Tier 1 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier1</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier4">Telco Automation Tier 4 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier4</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.telemetryServiceAgent">Vertex AI Telemetry Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.telemetryServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/databaseinsights#databaseinsights.serviceAgent">Database Insights Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/databaseinsights.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datamigration#datamigration.serviceAgent">Database Migration Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datamigration.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.serviceAgent">Cluster Director Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securedlandingzone#securedlandingzone.serviceAgent">Secured Landing Zone Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securedlandingzone.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.controlServiceAgent">Security Center Control Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.controlServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.serviceAgent">Security Center Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="logging.logEntries.route" class="permission-name add-link" data-text="logging.logEntries.route" tabindex="-1"><code translate="no" dir="ltr">logging.logEntries.route</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.logWriter">Logs Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.logWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.worker">Dataflow Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.hubAgent">Dataproc Hub Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.hubAgent</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.worker">Dataproc Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.computeRunner">Firebase App Hosting Compute Runner</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.computeRunner</code>)</p>
<p><a href="/iam/docs/roles-permissions/gkemulticloud#gkemulticloud.telemetryWriter">Anthos Multi-cloud Telemetry Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/gkemulticloud.telemetryWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.agentSandboxServiceAgent">Vertex AI Agent Sandbox Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.agentSandboxServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.customCodeServiceAgent">Vertex AI Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.customCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.extensionCustomCodeServiceAgent">Vertex AI Extension Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.extensionCustomCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.extensionServiceAgent">Vertex AI Extension Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.extensionServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.notebookServiceAgent">Vertex AI Notebook Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.notebookServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.ragServiceAgent">Vertex AI RAG Data Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.ragServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.reasoningEngineServiceAgent">Vertex AI Reasoning Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.reasoningEngineServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.telemetryServiceAgent">Vertex AI Telemetry Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.telemetryServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/flow#aisandbox.serviceAgent">FlowService Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aisandbox.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.serviceAgent">Recommendations AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/bigqueryconnection#bigqueryconnection.serviceAgent">BigQuery Connection Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/bigqueryconnection.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/bigquerydatatransfer#bigquerydatatransfer.serviceAgent">BigQuery Data Transfer Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatatransfer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ces#ces.serviceAgent">Customer Engagement Suite Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ces.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.serviceAgent">Chronicle Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudaicompanion#cloudaicompanion.serviceAgent">Gemini for Google Cloud Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudaicompanion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudconfig#cloudconfig.serviceAgent">Infrastructure Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudconfig.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudiot#cloudiot.serviceAgent">Cloud IoT Core Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudiot.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.serviceAgent">Cloud Scheduler Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/tpu#cloudtpu.serviceAgent">Cloud TPU V2 API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtpu.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/databaseinsights#databaseinsights.serviceAgent">Database Insights Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/databaseinsights.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprocrm#dataprocrm.nodeServiceAgent">Dataproc Resource Manager Node Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprocrm.nodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dialogflow#dialogflow.serviceAgent">Dialogflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dialogflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebaseml#firebaseml.serviceAgent">Firebase AI Logic Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasetelemetry#firebasetelemetry.serviceAgent">Firebase Telemetry Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasetelemetry.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/flow#flow.serviceAgent">Flow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/flow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkemulticloud#gkemulticloud.containerServiceAgent">Anthos Multi-Cloud Container Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkemulticloud.containerServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.serviceAgent">Cluster Director Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/meshcontrolplane#meshcontrolplane.serviceAgent">Mesh Managed Control Plane Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/meshcontrolplane.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/anthosservicemesh#meshdataplane.serviceAgent">Mesh Data Plane Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/meshdataplane.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/retail#retail.serviceAgent">Retail Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/retail.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="logging.logMetrics.create" class="permission-name add-link" data-text="logging.logMetrics.create" tabindex="-1"><code translate="no" dir="ltr">logging.logMetrics.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/appengineflex#appengineflex.serviceAgent">App Engine flexible environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengineflex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vpcaccess#vpcaccess.serviceAgent">Serverless VPC Access Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vpcaccess.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="logging.logMetrics.delete" class="permission-name add-link" data-text="logging.logMetrics.delete" tabindex="-1"><code translate="no" dir="ltr">logging.logMetrics.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/appengineflex#appengineflex.serviceAgent">App Engine flexible environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengineflex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vpcaccess#vpcaccess.serviceAgent">Serverless VPC Access Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vpcaccess.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="logging.logMetrics.get" class="permission-name add-link" data-text="logging.logMetrics.get" tabindex="-1"><code translate="no" dir="ltr">logging.logMetrics.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.admin">Discovery Engine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.privateLogViewer">Private Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.privateLogViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.viewer">Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/accesscontextmanager#accesscontextmanager.vpcScTroubleshooterViewer">VPC Service Controls Troubleshooter Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/accesscontextmanager.vpcScTroubleshooterViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.hubAgent">Dataproc Hub Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.hubAgent</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceAdmin">Gemini Enterprise Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier1">Telco Automation Tier 1 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier1</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier4">Telco Automation Tier 4 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier4</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/appengineflex#appengineflex.serviceAgent">App Engine flexible environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengineflex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vpcaccess#vpcaccess.serviceAgent">Serverless VPC Access Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vpcaccess.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="logging.logMetrics.list" class="permission-name add-link" data-text="logging.logMetrics.list" tabindex="-1"><code translate="no" dir="ltr">logging.logMetrics.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.admin">Discovery Engine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.privateLogViewer">Private Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.privateLogViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.viewer">Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/accesscontextmanager#accesscontextmanager.vpcScTroubleshooterViewer">VPC Service Controls Troubleshooter Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/accesscontextmanager.vpcScTroubleshooterViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.hubAgent">Dataproc Hub Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.hubAgent</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceAdmin">Gemini Enterprise Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier1">Telco Automation Tier 1 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier1</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier4">Telco Automation Tier 4 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier4</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="logging.logMetrics.update" class="permission-name add-link" data-text="logging.logMetrics.update" tabindex="-1"><code translate="no" dir="ltr">logging.logMetrics.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/appengineflex#appengineflex.serviceAgent">App Engine flexible environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengineflex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/vpcaccess#vpcaccess.serviceAgent">Serverless VPC Access Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/vpcaccess.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="logging.logScopes.create" class="permission-name add-link" data-text="logging.logScopes.create" tabindex="-1"><code translate="no" dir="ltr">logging.logScopes.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/observability#observability.scopesEditor">Observability Scopes Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/observability.scopesEditor</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="logging.logScopes.delete" class="permission-name add-link" data-text="logging.logScopes.delete" tabindex="-1"><code translate="no" dir="ltr">logging.logScopes.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/observability#observability.scopesEditor">Observability Scopes Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/observability.scopesEditor</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="logging.logScopes.get" class="permission-name add-link" data-text="logging.logScopes.get" tabindex="-1"><code translate="no" dir="ltr">logging.logScopes.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.admin">Discovery Engine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.viewer">Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.hubAgent">Dataproc Hub Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.hubAgent</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceAdmin">Gemini Enterprise Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/observability#observability.scopesEditor">Observability Scopes Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/observability.scopesEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier1">Telco Automation Tier 1 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier1</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier4">Telco Automation Tier 4 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier4</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="logging.logScopes.list" class="permission-name add-link" data-text="logging.logScopes.list" tabindex="-1"><code translate="no" dir="ltr">logging.logScopes.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.admin">Discovery Engine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.viewer">Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.hubAgent">Dataproc Hub Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.hubAgent</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceAdmin">Gemini Enterprise Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/observability#observability.scopesEditor">Observability Scopes Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/observability.scopesEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier1">Telco Automation Tier 1 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier1</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier4">Telco Automation Tier 4 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier4</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="logging.logScopes.update" class="permission-name add-link" data-text="logging.logScopes.update" tabindex="-1"><code translate="no" dir="ltr">logging.logScopes.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/observability#observability.scopesEditor">Observability Scopes Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/observability.scopesEditor</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="logging.logServiceIndexes.list" class="permission-name add-link" data-text="logging.logServiceIndexes.list" tabindex="-1"><code translate="no" dir="ltr">logging.logServiceIndexes.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/billing#billing.admin">Billing Account Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/billing.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.admin">Discovery Engine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.privateLogViewer">Private Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.privateLogViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.viewer">Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/accesscontextmanager#accesscontextmanager.vpcScTroubleshooterViewer">VPC Service Controls Troubleshooter Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/accesscontextmanager.vpcScTroubleshooterViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.hubAgent">Dataproc Hub Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.hubAgent</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceAdmin">Gemini Enterprise Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier1">Telco Automation Tier 1 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier1</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier4">Telco Automation Tier 4 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier4</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datamigration#datamigration.serviceAgent">Database Migration Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datamigration.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="logging.logServices.list" class="permission-name add-link" data-text="logging.logServices.list" tabindex="-1"><code translate="no" dir="ltr">logging.logServices.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/billing#billing.admin">Billing Account Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/billing.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.admin">Discovery Engine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.privateLogViewer">Private Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.privateLogViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.viewer">Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/accesscontextmanager#accesscontextmanager.vpcScTroubleshooterViewer">VPC Service Controls Troubleshooter Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/accesscontextmanager.vpcScTroubleshooterViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.hubAgent">Dataproc Hub Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.hubAgent</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceAdmin">Gemini Enterprise Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier1">Telco Automation Tier 1 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier1</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier4">Telco Automation Tier 4 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier4</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datamigration#datamigration.serviceAgent">Database Migration Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datamigration.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="logging.logs.delete" class="permission-name add-link" data-text="logging.logs.delete" tabindex="-1"><code translate="no" dir="ltr">logging.logs.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="logging.logs.list" class="permission-name add-link" data-text="logging.logs.list" tabindex="-1"><code translate="no" dir="ltr">logging.logs.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/billing#billing.admin">Billing Account Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/billing.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.admin">Discovery Engine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.privateLogViewer">Private Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.privateLogViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.viewer">Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/accesscontextmanager#accesscontextmanager.vpcScTroubleshooterViewer">VPC Service Controls Troubleshooter Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/accesscontextmanager.vpcScTroubleshooterViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.hubAgent">Dataproc Hub Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.hubAgent</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceAdmin">Gemini Enterprise Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier1">Telco Automation Tier 1 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier1</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier4">Telco Automation Tier 4 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier4</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datamigration#datamigration.serviceAgent">Database Migration Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datamigration.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="logging.notificationRules.create" class="permission-name add-link" data-text="logging.notificationRules.create" tabindex="-1"><code translate="no" dir="ltr">logging.notificationRules.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/errorreporting#errorreporting.admin">Error Reporting Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/errorreporting.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/errorreporting#errorreporting.user">Error Reporting User</a> (<code class="role-name" translate="no" dir="ltr">roles/errorreporting.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="logging.notificationRules.delete" class="permission-name add-link" data-text="logging.notificationRules.delete" tabindex="-1"><code translate="no" dir="ltr">logging.notificationRules.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/errorreporting#errorreporting.admin">Error Reporting Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/errorreporting.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/errorreporting#errorreporting.user">Error Reporting User</a> (<code class="role-name" translate="no" dir="ltr">roles/errorreporting.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="logging.notificationRules.get" class="permission-name add-link" data-text="logging.notificationRules.get" tabindex="-1"><code translate="no" dir="ltr">logging.notificationRules.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.admin">Discovery Engine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/errorreporting#errorreporting.admin">Error Reporting Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/errorreporting.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/errorreporting#errorreporting.user">Error Reporting User</a> (<code class="role-name" translate="no" dir="ltr">roles/errorreporting.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/errorreporting#errorreporting.viewer">Error Reporting Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/errorreporting.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.privateLogViewer">Private Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.privateLogViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.viewer">Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.hubAgent">Dataproc Hub Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.hubAgent</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceAdmin">Gemini Enterprise Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier1">Telco Automation Tier 1 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier1</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier4">Telco Automation Tier 4 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier4</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="logging.notificationRules.list" class="permission-name add-link" data-text="logging.notificationRules.list" tabindex="-1"><code translate="no" dir="ltr">logging.notificationRules.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.admin">Discovery Engine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/errorreporting#errorreporting.admin">Error Reporting Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/errorreporting.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/errorreporting#errorreporting.user">Error Reporting User</a> (<code class="role-name" translate="no" dir="ltr">roles/errorreporting.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/errorreporting#errorreporting.viewer">Error Reporting Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/errorreporting.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.privateLogViewer">Private Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.privateLogViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.viewer">Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.hubAgent">Dataproc Hub Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.hubAgent</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceAdmin">Gemini Enterprise Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier1">Telco Automation Tier 1 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier1</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier4">Telco Automation Tier 4 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier4</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="logging.notificationRules.update" class="permission-name add-link" data-text="logging.notificationRules.update" tabindex="-1"><code translate="no" dir="ltr">logging.notificationRules.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/errorreporting#errorreporting.admin">Error Reporting Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/errorreporting.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/errorreporting#errorreporting.user">Error Reporting User</a> (<code class="role-name" translate="no" dir="ltr">roles/errorreporting.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="logging.operations.cancel" class="permission-name add-link" data-text="logging.operations.cancel" tabindex="-1"><code translate="no" dir="ltr">logging.operations.cancel</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="logging.operations.get" class="permission-name add-link" data-text="logging.operations.get" tabindex="-1"><code translate="no" dir="ltr">logging.operations.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.admin">Discovery Engine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.privateLogViewer">Private Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.privateLogViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.viewer">Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.hubAgent">Dataproc Hub Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.hubAgent</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceAdmin">Gemini Enterprise Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier1">Telco Automation Tier 1 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier1</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier4">Telco Automation Tier 4 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier4</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="logging.operations.list" class="permission-name add-link" data-text="logging.operations.list" tabindex="-1"><code translate="no" dir="ltr">logging.operations.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.admin">Discovery Engine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.privateLogViewer">Private Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.privateLogViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.viewer">Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.hubAgent">Dataproc Hub Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.hubAgent</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceAdmin">Gemini Enterprise Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier1">Telco Automation Tier 1 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier1</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier4">Telco Automation Tier 4 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier4</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="logging.privateLogEntries.list" class="permission-name add-link" data-text="logging.privateLogEntries.list" tabindex="-1"><code translate="no" dir="ltr">logging.privateLogEntries.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/billing#billing.admin">Billing Account Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/billing.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.privateLogViewer">Private Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.privateLogViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="logging.queries.deleteShared" class="permission-name add-link" data-text="logging.queries.deleteShared" tabindex="-1"><code translate="no" dir="ltr">logging.queries.deleteShared</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="logging.queries.getShared" class="permission-name add-link" data-text="logging.queries.getShared" tabindex="-1"><code translate="no" dir="ltr">logging.queries.getShared</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.admin">Discovery Engine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.privateLogViewer">Private Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.privateLogViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.viewer">Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.hubAgent">Dataproc Hub Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.hubAgent</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceAdmin">Gemini Enterprise Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/observability#observability.analyticsUser">Observability Analytics User</a> (<code class="role-name" translate="no" dir="ltr">roles/observability.analyticsUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier1">Telco Automation Tier 1 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier1</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier4">Telco Automation Tier 4 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier4</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="logging.queries.listShared" class="permission-name add-link" data-text="logging.queries.listShared" tabindex="-1"><code translate="no" dir="ltr">logging.queries.listShared</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.admin">Discovery Engine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.privateLogViewer">Private Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.privateLogViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.viewer">Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.hubAgent">Dataproc Hub Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.hubAgent</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceAdmin">Gemini Enterprise Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/observability#observability.analyticsUser">Observability Analytics User</a> (<code class="role-name" translate="no" dir="ltr">roles/observability.analyticsUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier1">Telco Automation Tier 1 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier1</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier4">Telco Automation Tier 4 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier4</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="logging.queries.share" class="permission-name add-link" data-text="logging.queries.share" tabindex="-1"><code translate="no" dir="ltr">logging.queries.share</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="logging.queries.updateShared" class="permission-name add-link" data-text="logging.queries.updateShared" tabindex="-1"><code translate="no" dir="ltr">logging.queries.updateShared</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="logging.queries.usePrivate" class="permission-name add-link" data-text="logging.queries.usePrivate" tabindex="-1"><code translate="no" dir="ltr">logging.queries.usePrivate</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.admin">Discovery Engine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.privateLogViewer">Private Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.privateLogViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.viewer">Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.hubAgent">Dataproc Hub Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.hubAgent</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceAdmin">Gemini Enterprise Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/observability#observability.analyticsUser">Observability Analytics User</a> (<code class="role-name" translate="no" dir="ltr">roles/observability.analyticsUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier1">Telco Automation Tier 1 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier1</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier4">Telco Automation Tier 4 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier4</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="logging.settings.get" class="permission-name add-link" data-text="logging.settings.get" tabindex="-1"><code translate="no" dir="ltr">logging.settings.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.admin">Discovery Engine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.privateLogViewer">Private Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.privateLogViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.viewer">Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.hubAgent">Dataproc Hub Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.hubAgent</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceAdmin">Gemini Enterprise Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier1">Telco Automation Tier 1 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier1</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier4">Telco Automation Tier 4 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier4</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="logging.settings.update" class="permission-name add-link" data-text="logging.settings.update" tabindex="-1"><code translate="no" dir="ltr">logging.settings.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredworkloads#assuredworkloads.admin">Assured Workloads Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredworkloads.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredworkloads#assuredworkloads.editor">Assured Workloads Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredworkloads.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.serviceAgent">Cloud Security Compliance Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="logging.sinks.create" class="permission-name add-link" data-text="logging.sinks.create" tabindex="-1"><code translate="no" dir="ltr">logging.sinks.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasetelemetry#firebasetelemetry.serviceAgent">Firebase Telemetry Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasetelemetry.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkehub#gkehub.serviceAgent">GKE Hub Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.serviceAgent">Cluster Director Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/kuberun#kuberun.eventsControlPlaneServiceAgent">KubeRun Events Control Plane Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/kuberun.eventsControlPlaneServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="logging.sinks.delete" class="permission-name add-link" data-text="logging.sinks.delete" tabindex="-1"><code translate="no" dir="ltr">logging.sinks.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasetelemetry#firebasetelemetry.serviceAgent">Firebase Telemetry Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasetelemetry.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkehub#gkehub.serviceAgent">GKE Hub Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.serviceAgent">Cluster Director Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/kuberun#kuberun.eventsControlPlaneServiceAgent">KubeRun Events Control Plane Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/kuberun.eventsControlPlaneServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="logging.sinks.get" class="permission-name add-link" data-text="logging.sinks.get" tabindex="-1"><code translate="no" dir="ltr">logging.sinks.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.admin">Discovery Engine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.privateLogViewer">Private Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.privateLogViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.viewer">Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/accesscontextmanager#accesscontextmanager.vpcScTroubleshooterViewer">VPC Service Controls Troubleshooter Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/accesscontextmanager.vpcScTroubleshooterViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.hubAgent">Dataproc Hub Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.hubAgent</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceAdmin">Gemini Enterprise Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier1">Telco Automation Tier 1 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier1</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier4">Telco Automation Tier 4 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier4</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasetelemetry#firebasetelemetry.serviceAgent">Firebase Telemetry Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasetelemetry.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkehub#gkehub.serviceAgent">GKE Hub Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.serviceAgent">Cluster Director Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/kuberun#kuberun.eventsControlPlaneServiceAgent">KubeRun Events Control Plane Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/kuberun.eventsControlPlaneServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="logging.sinks.list" class="permission-name add-link" data-text="logging.sinks.list" tabindex="-1"><code translate="no" dir="ltr">logging.sinks.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.admin">Discovery Engine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.privateLogViewer">Private Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.privateLogViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.viewer">Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/accesscontextmanager#accesscontextmanager.vpcScTroubleshooterViewer">VPC Service Controls Troubleshooter Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/accesscontextmanager.vpcScTroubleshooterViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.hubAgent">Dataproc Hub Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.hubAgent</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceAdmin">Gemini Enterprise Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier1">Telco Automation Tier 1 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier1</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier4">Telco Automation Tier 4 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier4</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasetelemetry#firebasetelemetry.serviceAgent">Firebase Telemetry Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasetelemetry.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkehub#gkehub.serviceAgent">GKE Hub Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.serviceAgent">Cluster Director Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="logging.sinks.update" class="permission-name add-link" data-text="logging.sinks.update" tabindex="-1"><code translate="no" dir="ltr">logging.sinks.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasetelemetry#firebasetelemetry.serviceAgent">Firebase Telemetry Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasetelemetry.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkehub#gkehub.serviceAgent">GKE Hub Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="logging.sqlAlerts.create" class="permission-name add-link" data-text="logging.sqlAlerts.create" tabindex="-1"><code translate="no" dir="ltr">logging.sqlAlerts.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.sqlAlertWriter">SQL Alert Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.sqlAlertWriter</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="logging.sqlAlerts.update" class="permission-name add-link" data-text="logging.sqlAlerts.update" tabindex="-1"><code translate="no" dir="ltr">logging.sqlAlerts.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.sqlAlertWriter">SQL Alert Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.sqlAlertWriter</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="logging.usage.get" class="permission-name add-link" data-text="logging.usage.get" tabindex="-1"><code translate="no" dir="ltr">logging.usage.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.admin">Discovery Engine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.privateLogViewer">Private Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.privateLogViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.viewer">Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/accesscontextmanager#accesscontextmanager.vpcScTroubleshooterViewer">VPC Service Controls Troubleshooter Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/accesscontextmanager.vpcScTroubleshooterViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.hubAgent">Dataproc Hub Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.hubAgent</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceAdmin">Gemini Enterprise Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier1">Telco Automation Tier 1 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier1</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier4">Telco Automation Tier 4 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier4</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="logging.views.access" class="permission-name add-link" data-text="logging.views.access" tabindex="-1"><code translate="no" dir="ltr">logging.views.access</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.builds.builder">Cloud Build Service Account</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.builds.builder</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebasecrash#firebasecrashlytics.admin">Firebase Crashlytics Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasecrashlytics.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebasecrash#firebasecrashlytics.viewer">Firebase Crashlytics Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasecrashlytics.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.privateLogViewer">Private Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.privateLogViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.worker">Composer Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.qualityAdmin">Firebase Quality Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.qualityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.qualityViewer">Firebase Quality Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.qualityViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.viewAccessor">Logs View Accessor</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.viewAccessor</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.customCodeServiceAgent">Vertex AI Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.customCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="logging.views.create" class="permission-name add-link" data-text="logging.views.create" tabindex="-1"><code translate="no" dir="ltr">logging.views.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/apigee#apigee.coreServiceAgent">Apigee Core Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.coreServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/apigee#apigee.serviceAgent">Apigee Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkehub#gkehub.serviceAgent">GKE Hub Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="logging.views.delete" class="permission-name add-link" data-text="logging.views.delete" tabindex="-1"><code translate="no" dir="ltr">logging.views.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="logging.views.get" class="permission-name add-link" data-text="logging.views.get" tabindex="-1"><code translate="no" dir="ltr">logging.views.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.admin">Discovery Engine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.privateLogViewer">Private Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.privateLogViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.viewer">Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.hubAgent">Dataproc Hub Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.hubAgent</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceAdmin">Gemini Enterprise Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier1">Telco Automation Tier 1 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier1</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier4">Telco Automation Tier 4 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier4</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.customCodeServiceAgent">Vertex AI Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.customCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/apigee#apigee.coreServiceAgent">Apigee Core Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.coreServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/apigee#apigee.serviceAgent">Apigee Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkehub#gkehub.serviceAgent">GKE Hub Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="logging.views.getIamPolicy" class="permission-name add-link" data-text="logging.views.getIamPolicy" tabindex="-1"><code translate="no" dir="ltr">logging.views.getIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.admin">Discovery Engine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.privateLogViewer">Private Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.privateLogViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.viewer">Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.hubAgent">Dataproc Hub Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.hubAgent</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceAdmin">Gemini Enterprise Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier1">Telco Automation Tier 1 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier1</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier4">Telco Automation Tier 4 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier4</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="logging.views.list" class="permission-name add-link" data-text="logging.views.list" tabindex="-1"><code translate="no" dir="ltr">logging.views.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.admin">Discovery Engine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.privateLogViewer">Private Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.privateLogViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.viewer">Logs Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.admin">Telco Automation Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudhub#cloudhub.operator">Cloud Hub Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudhub.operator</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.hubAgent">Dataproc Hub Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.hubAgent</code>)</p>
<p><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.agentspaceAdmin">Gemini Enterprise Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.agentspaceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier1">Telco Automation Tier 1 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier1</code>)</p>
<p><a href="/iam/docs/roles-permissions/telcoautomation#telcoautomation.opsAdminTier4">Telco Automation Tier 4 Operations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/telcoautomation.opsAdminTier4</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/apigee#apigee.coreServiceAgent">Apigee Core Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.coreServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/apigee#apigee.serviceAgent">Apigee Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkehub#gkehub.serviceAgent">GKE Hub Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="logging.views.listLogs" class="permission-name add-link" data-text="logging.views.listLogs" tabindex="-1"><code translate="no" dir="ltr">logging.views.listLogs</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebasecrash#firebasecrashlytics.admin">Firebase Crashlytics Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasecrashlytics.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebasecrash#firebasecrashlytics.viewer">Firebase Crashlytics Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasecrashlytics.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.qualityAdmin">Firebase Quality Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.qualityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.qualityViewer">Firebase Quality Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.qualityViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.viewAccessor">Logs View Accessor</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.viewAccessor</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="logging.views.listResourceKeys" class="permission-name add-link" data-text="logging.views.listResourceKeys" tabindex="-1"><code translate="no" dir="ltr">logging.views.listResourceKeys</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebasecrash#firebasecrashlytics.admin">Firebase Crashlytics Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasecrashlytics.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebasecrash#firebasecrashlytics.viewer">Firebase Crashlytics Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasecrashlytics.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.qualityAdmin">Firebase Quality Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.qualityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.qualityViewer">Firebase Quality Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.qualityViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.viewAccessor">Logs View Accessor</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.viewAccessor</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="logging.views.listResourceValues" class="permission-name add-link" data-text="logging.views.listResourceValues" tabindex="-1"><code translate="no" dir="ltr">logging.views.listResourceValues</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.admin">Firebase Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.editor">Firebase Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.viewer">Firebase Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebasecrash#firebasecrashlytics.admin">Firebase Crashlytics Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasecrashlytics.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebasecrash#firebasecrashlytics.viewer">Firebase Crashlytics Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasecrashlytics.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.qualityAdmin">Firebase Quality Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.qualityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/firebase#firebase.qualityViewer">Firebase Quality Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.qualityViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.viewAccessor">Logs View Accessor</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.viewAccessor</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="logging.views.setIamPolicy" class="permission-name add-link" data-text="logging.views.setIamPolicy" tabindex="-1"><code translate="no" dir="ltr">logging.views.setIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="logging.views.update" class="permission-name add-link" data-text="logging.views.update" tabindex="-1"><code translate="no" dir="ltr">logging.views.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.admin">Logging Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.infrastructureAdmin">Infrastructure Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.infrastructureAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.networkAdmin">Network Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.networkAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/logging#logging.configWriter">Logs Configuration Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.configWriter</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gkehub#gkehub.serviceAgent">GKE Hub Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gkehub.serviceAgent</code>)</li>
</ul></td>
</tr>
</tbody>
</table>

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
