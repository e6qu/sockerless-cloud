# IAM permissions for JSON methods

<div class="devsite-article-body clearfix">

The following table lists the [Identity and Access Management (IAM)](/storage/docs/access-control/iam) permissions required to run each Cloud Storage [JSON method](/storage/docs/json_api/v1) on a given resource. IAM permissions are bundled together to make [roles](/storage/docs/access-control/iam-roles). You [grant roles to users and groups](/storage/docs/access-control/using-iam-permissions).

For additional methods that only apply to buckets with [Uniform bucket-level access](/storage/docs/uniform-bucket-level-access) disabled, see the [ACL methods table](#extended).

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr class="header">
<th>Resource</th>
<th>Method</th>
<th>Required IAM Permissions<sup>1</sup></th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td><code translate="no" dir="ltr">AnywhereCache</code></td>
<td><code translate="no" dir="ltr">create</code></td>
<td><code translate="no" dir="ltr">storage.anywhereCaches.create</code></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">AnywhereCache</code></td>
<td><code translate="no" dir="ltr">disable</code></td>
<td><code translate="no" dir="ltr">storage.anywhereCaches.disable</code></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">AnywhereCache</code></td>
<td><code translate="no" dir="ltr">get</code></td>
<td><code translate="no" dir="ltr">storage.anywhereCaches.get</code></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">AnywhereCache</code></td>
<td><code translate="no" dir="ltr">list</code></td>
<td><code translate="no" dir="ltr">storage.anywhereCaches.list</code></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">AnywhereCache</code></td>
<td><code translate="no" dir="ltr">pause</code></td>
<td><code translate="no" dir="ltr">storage.anywhereCaches.pause</code></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">AnywhereCache</code></td>
<td><code translate="no" dir="ltr">resume</code></td>
<td><code translate="no" dir="ltr">storage.anywhereCaches.resume</code></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">AnywhereCache</code></td>
<td><code translate="no" dir="ltr">update</code></td>
<td><code translate="no" dir="ltr">storage.anywhereCaches.update</code></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">Buckets</code></td>
<td><code translate="no" dir="ltr">delete</code></td>
<td><code translate="no" dir="ltr">storage.buckets.delete</code></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">Buckets</code></td>
<td><code translate="no" dir="ltr">get</code></td>
<td><code translate="no" dir="ltr">storage.buckets.get</code><br />
<code translate="no" dir="ltr">storage.buckets.getIamPolicy</code><sup>2</sup><br />
<code translate="no" dir="ltr">storage.buckets.getIpFilter</code><sup>13</sup><br />
<code translate="no" dir="ltr">storage.anywhereCaches.get</code><sup>18</sup></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">Buckets</code></td>
<td><code translate="no" dir="ltr">getIamPolicy</code></td>
<td><code translate="no" dir="ltr">storage.buckets.getIamPolicy</code></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">Buckets</code></td>
<td><code translate="no" dir="ltr">insert</code></td>
<td><code translate="no" dir="ltr">storage.buckets.create</code><br />
<code translate="no" dir="ltr">storage.buckets.enableObjectRetention</code><sup>3</sup><br />
<code translate="no" dir="ltr">storage.buckets.setIpFilter</code><sup>14</sup></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">Buckets</code></td>
<td><code translate="no" dir="ltr">list</code></td>
<td><code translate="no" dir="ltr">storage.buckets.list</code><br />
<code translate="no" dir="ltr">storage.buckets.getIamPolicy</code><sup>2</sup><br />
<code translate="no" dir="ltr">storage.buckets.getIpFilter</code><sup>13</sup><br />
<code translate="no" dir="ltr">storage.anywhereCaches.list</code></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">Buckets</code></td>
<td><code translate="no" dir="ltr">lockRetentionPolicy</code></td>
<td><code translate="no" dir="ltr">storage.buckets.update</code></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">Buckets</code></td>
<td><code translate="no" dir="ltr">patch</code></td>
<td><code translate="no" dir="ltr">storage.buckets.update</code><br />
<code translate="no" dir="ltr">storage.buckets.getIamPolicy</code><sup>4</sup><br />
<code translate="no" dir="ltr">storage.buckets.setIamPolicy</code><sup>5</sup><br />
<code translate="no" dir="ltr">storage.buckets.setIpFilter</code><sup>14</sup><br />
<code translate="no" dir="ltr">storage.buckets.getIpFilter</code><sup>13</sup></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">Buckets</code></td>
<td><code translate="no" dir="ltr">relocate</code></td>
<td><code translate="no" dir="ltr">storage.buckets.relocate</code></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">Buckets</code></td>
<td><code translate="no" dir="ltr">setIamPolicy</code></td>
<td><code translate="no" dir="ltr">storage.buckets.setIamPolicy</code></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">Buckets</code></td>
<td><code translate="no" dir="ltr">testIamPermissions</code></td>
<td>None</td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">Buckets</code></td>
<td><code translate="no" dir="ltr">update</code></td>
<td><code translate="no" dir="ltr">storage.buckets.update</code><br />
<code translate="no" dir="ltr">storage.buckets.getIamPolicy</code><sup>4</sup><br />
<code translate="no" dir="ltr">storage.buckets.setIamPolicy</code><sup>5</sup><br />
<code translate="no" dir="ltr">storage.buckets.setIpFilter</code><sup>14</sup><br />
<code translate="no" dir="ltr">storage.buckets.getIpFilter</code><sup>13</sup><br />
<code translate="no" dir="ltr">storage.anywhereCaches.update</code></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">DatasetConfigs</code></td>
<td><code translate="no" dir="ltr">delete</code></td>
<td><code translate="no" dir="ltr">storageinsights.datasetConfigs.delete</code></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">DatasetConfigs</code></td>
<td><code translate="no" dir="ltr">get</code></td>
<td><code translate="no" dir="ltr">storageinsights.datasetConfigs.get</code></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">DatasetConfigs</code></td>
<td><code translate="no" dir="ltr">insert</code></td>
<td><code translate="no" dir="ltr">storageinsights.datasetConfigs.create</code></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">DatasetConfigs</code></td>
<td><code translate="no" dir="ltr">list</code></td>
<td><code translate="no" dir="ltr">storageinsights.datasetConfigs.list</code></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">DatasetConfigs</code></td>
<td><code translate="no" dir="ltr">linkDataset</code></td>
<td><code translate="no" dir="ltr">storageinsights.datasetConfigs.linkDataset</code></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">DatasetConfigs</code></td>
<td><code translate="no" dir="ltr">unlinkDataset</code></td>
<td><code translate="no" dir="ltr">storageinsights.datasetConfigs.unlinkDataset</code></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">DatasetConfigs</code></td>
<td><code translate="no" dir="ltr">patch</code></td>
<td><code translate="no" dir="ltr">storageinsights.datasetConfigs.update</code></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">FeatureConfigs</code></td>
<td><code translate="no" dir="ltr">create</code></td>
<td><code translate="no" dir="ltr">storage.featureConfigs.create</code></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">FeatureConfigs</code></td>
<td><code translate="no" dir="ltr">delete</code></td>
<td><code translate="no" dir="ltr">storage.featureConfigs.delete</code></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">FeatureConfigs</code></td>
<td><code translate="no" dir="ltr">get</code></td>
<td><code translate="no" dir="ltr">storage.featureConfigs.get</code></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">FeatureConfigs</code></td>
<td><code translate="no" dir="ltr">list</code></td>
<td><code translate="no" dir="ltr">storage.featureConfigs.list</code></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">FeatureConfigs</code></td>
<td><code translate="no" dir="ltr">update</code></td>
<td><code translate="no" dir="ltr">storage.featureConfigs.update</code></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">Folders</code></td>
<td><code translate="no" dir="ltr">get</code></td>
<td><code translate="no" dir="ltr">storage.folders.get</code></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">Folders</code></td>
<td><code translate="no" dir="ltr">insert</code></td>
<td><code translate="no" dir="ltr">storage.folders.create</code></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">Folders</code></td>
<td><code translate="no" dir="ltr">list</code></td>
<td><code translate="no" dir="ltr">storage.folders.list</code></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">Folders</code></td>
<td><code translate="no" dir="ltr">rename</code></td>
<td><code translate="no" dir="ltr">storage.folders.rename</code> (for the source folder)<br />
<code translate="no" dir="ltr">storage.folders.create</code> (for the destination folder)</td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">Folders</code></td>
<td><code translate="no" dir="ltr">delete</code></td>
<td><code translate="no" dir="ltr">storage.folders.delete</code></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">IntelligenceConfig</code></td>
<td><code translate="no" dir="ltr">getIntelligenceConfig</code></td>
<td><code translate="no" dir="ltr">storage.intelligenceConfigs.get</code></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">IntelligenceConfig</code></td>
<td><code translate="no" dir="ltr">updateIntelligenceConfig</code></td>
<td><code translate="no" dir="ltr">storage.intelligenceConfigs.update</code></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">IntelligenceFindings</code></td>
<td><code translate="no" dir="ltr">get</code></td>
<td><code translate="no" dir="ltr">storage.buckets.viewIntelligenceDetails</code></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">IntelligenceFindings</code></td>
<td><code translate="no" dir="ltr">list</code></td>
<td><code translate="no" dir="ltr">storage.buckets.viewIntelligenceDetails</code></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">IntelligenceFindings</code></td>
<td><code translate="no" dir="ltr">summarize</code></td>
<td><code translate="no" dir="ltr">storage.buckets.viewIntelligenceDetails</code></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">IntelligenceFindings.revisions</code></td>
<td><code translate="no" dir="ltr">get</code></td>
<td><code translate="no" dir="ltr">storage.buckets.viewIntelligenceDetails</code></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">IntelligenceFindings.revisions</code></td>
<td><code translate="no" dir="ltr">list</code></td>
<td><code translate="no" dir="ltr">storage.buckets.viewIntelligenceDetails</code></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">Jobs</code></td>
<td><code translate="no" dir="ltr">create</code></td>
<td><code translate="no" dir="ltr">storagebatchoperations.jobs.create</code></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">Jobs</code></td>
<td><code translate="no" dir="ltr">get</code></td>
<td><code translate="no" dir="ltr">storagebatchoperations.jobs.get</code><br />
<code translate="no" dir="ltr">storagebatchoperations.operations.get</code></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">Jobs</code></td>
<td><code translate="no" dir="ltr">list</code></td>
<td><code translate="no" dir="ltr">storagebatchoperations.jobs.list</code><br />
<code translate="no" dir="ltr">storagebatchoperations.operations.list</code></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">Jobs</code></td>
<td><code translate="no" dir="ltr">cancel</code></td>
<td><code translate="no" dir="ltr">storagebatchoperations.jobs.cancel</code><br />
<code translate="no" dir="ltr">storagebatchoperations.operations.cancel</code></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">Jobs</code></td>
<td><code translate="no" dir="ltr">delete</code></td>
<td><code translate="no" dir="ltr">storagebatchoperations.jobs.delete</code></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">ManagedFolders</code></td>
<td><code translate="no" dir="ltr">delete</code></td>
<td><code translate="no" dir="ltr">storage.managedfolders.delete</code><br />
<code translate="no" dir="ltr">storage.managedfolders.setIamPolicy</code><sup>10</sup></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">ManagedFolders</code></td>
<td><code translate="no" dir="ltr">get</code></td>
<td><code translate="no" dir="ltr">storage.managedfolders.get</code></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">ManagedFolders</code></td>
<td><code translate="no" dir="ltr">getIamPolicy</code></td>
<td><code translate="no" dir="ltr">storage.managedfolders.getIamPolicy</code></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">ManagedFolders</code></td>
<td><code translate="no" dir="ltr">insert</code></td>
<td><code translate="no" dir="ltr">storage.managedfolders.create</code></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">ManagedFolders</code></td>
<td><code translate="no" dir="ltr">list</code></td>
<td><code translate="no" dir="ltr">storage.managedfolders.list</code></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">ManagedFolders</code></td>
<td><code translate="no" dir="ltr">update</code></td>
<td><code translate="no" dir="ltr">storage.managedfolders.update</code></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">ManagedFolders</code></td>
<td><code translate="no" dir="ltr">setIamPolicy</code></td>
<td><code translate="no" dir="ltr">storage.managedfolders.setIamPolicy</code></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">Notifications</code></td>
<td><code translate="no" dir="ltr">delete</code></td>
<td><code translate="no" dir="ltr">storage.buckets.update</code></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">Notifications</code></td>
<td><code translate="no" dir="ltr">get</code></td>
<td><code translate="no" dir="ltr">storage.buckets.get</code></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">Notifications</code></td>
<td><code translate="no" dir="ltr">insert</code></td>
<td><code translate="no" dir="ltr">storage.buckets.update</code></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">Notifications</code></td>
<td><code translate="no" dir="ltr">list</code></td>
<td><code translate="no" dir="ltr">storage.buckets.get</code></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">Objects</code></td>
<td><code translate="no" dir="ltr">bulkRestore</code></td>
<td><code translate="no" dir="ltr">storage.buckets.restore</code><br />
<code translate="no" dir="ltr">storage.objects.create</code><br />
<code translate="no" dir="ltr">storage.objects.delete</code><sup>11</sup><br />
<code translate="no" dir="ltr">storage.objects.restore</code><br />
<code translate="no" dir="ltr">storage.objects.setIamPolicy</code><sup>6,12</sup></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">Objects</code></td>
<td><code translate="no" dir="ltr">compose</code></td>
<td><code translate="no" dir="ltr">storage.objects.get</code><br />
<code translate="no" dir="ltr">storage.objects.create</code><br />
<code translate="no" dir="ltr">storage.objects.delete</code><sup>7</sup><br />
<code translate="no" dir="ltr">storage.objects.getIamPolicy</code><sup>2,6</sup><br />
<code translate="no" dir="ltr">storage.objects.setRetention</code><sup>8</sup><br />
<code translate="no" dir="ltr">storage.objects.createContext</code><sup>19</sup></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">Objects</code></td>
<td><code translate="no" dir="ltr">copy</code></td>
<td><code translate="no" dir="ltr">storage.objects.get</code> (for the source bucket)<br />
<code translate="no" dir="ltr">storage.objects.create</code> (for the destination bucket)<br />
<code translate="no" dir="ltr">storage.objects.delete</code> (for the destination bucket)<sup>7</sup><br />
<code translate="no" dir="ltr">storage.objects.setRetention</code> (for the destination bucket)<sup>8</sup><br />
<code translate="no" dir="ltr">storage.objects.createContext</code><sup>19</sup></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">Objects</code></td>
<td><code translate="no" dir="ltr">delete</code></td>
<td><code translate="no" dir="ltr">storage.objects.delete</code></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">Objects</code></td>
<td><code translate="no" dir="ltr">get</code></td>
<td><code translate="no" dir="ltr">storage.objects.get</code><br />
<code translate="no" dir="ltr">storage.objects.getIamPolicy</code><sup>2,6</sup></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">Objects</code></td>
<td><code translate="no" dir="ltr">insert</code></td>
<td><code translate="no" dir="ltr">storage.objects.create</code><br />
<code translate="no" dir="ltr">storage.objects.delete</code><sup>7</sup><br />
<code translate="no" dir="ltr">storage.objects.setRetention</code><sup>8</sup><br />
<code translate="no" dir="ltr">storage.objects.createContext</code><sup>19</sup></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">Objects</code></td>
<td><code translate="no" dir="ltr">list</code></td>
<td><code translate="no" dir="ltr">storage.objects.list</code><br />
<code translate="no" dir="ltr">storage.objects.getIamPolicy</code><sup>2,6</sup></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">Objects</code></td>
<td><code translate="no" dir="ltr">move</code></td>
<td><code translate="no" dir="ltr">storage.objects.move</code><sup>15</sup> (for the source object)<br />
<code translate="no" dir="ltr">storage.objects.delete</code><sup>15</sup> (for the source object)<br />
<code translate="no" dir="ltr">storage.objects.get</code><sup>15</sup> (for the source object)<br />
<code translate="no" dir="ltr">storage.objects.create</code> (for the destination object)<br />
<code translate="no" dir="ltr">storage.objects.delete</code><sup>16</sup> (for the destination object)<br />
<code translate="no" dir="ltr">storage.folders.create</code><sup>17</sup> (for the destination object)</td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">Objects</code></td>
<td><code translate="no" dir="ltr">patch</code></td>
<td><code translate="no" dir="ltr">storage.objects.update</code><br />
<code translate="no" dir="ltr">storage.objects.setRetention</code><sup>8</sup><br />
<code translate="no" dir="ltr">storage.objects.overrideUnlockedRetention</code><sup>9</sup><br />
<code translate="no" dir="ltr">storage.objects.getIamPolicy</code><sup>4,6</sup><br />
<code translate="no" dir="ltr">storage.objects.setIamPolicy</code><sup>5,6</sup><br />
<code translate="no" dir="ltr">storage.objects.createContext</code><sup>20</sup><br />
<code translate="no" dir="ltr">storage.objects.updateContext</code><sup>21</sup><br />
<code translate="no" dir="ltr">storage.objects.deleteContext</code><sup>22</sup></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">Objects</code></td>
<td><code translate="no" dir="ltr">restore</code></td>
<td><code translate="no" dir="ltr">storage.objects.create</code><br />
<code translate="no" dir="ltr">storage.objects.delete</code><sup>7</sup><br />
<code translate="no" dir="ltr">storage.objects.restore</code><br />
<code translate="no" dir="ltr">storage.objects.getIamPolicy</code><sup>2,6</sup><br />
<code translate="no" dir="ltr">storage.objects.setIamPolicy</code><sup>6,12</sup></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">Objects</code></td>
<td><code translate="no" dir="ltr">rewrite</code></td>
<td><code translate="no" dir="ltr">storage.objects.get</code> (for the source bucket)<br />
<code translate="no" dir="ltr">storage.objects.create</code> (for the destination bucket)<br />
<code translate="no" dir="ltr">storage.objects.delete</code> (for the destination bucket)<sup>7</sup><br />
<code translate="no" dir="ltr">storage.objects.setRetention</code> (for the destination bucket)<sup>8</sup><br />
<code translate="no" dir="ltr">storage.objects.createContext</code><sup>19</sup></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">Objects</code></td>
<td><code translate="no" dir="ltr">update</code></td>
<td><code translate="no" dir="ltr">storage.objects.update</code><br />
<code translate="no" dir="ltr">storage.objects.setRetention</code><sup>8</sup><br />
<code translate="no" dir="ltr">storage.objects.overrideUnlockedRetention</code><sup>9</sup><br />
<code translate="no" dir="ltr">storage.objects.getIamPolicy</code><sup>4,6</sup><br />
<code translate="no" dir="ltr">storage.objects.setIamPolicy</code><sup>5,6</sup><br />
<code translate="no" dir="ltr">storage.objects.createContext</code><sup>20</sup><br />
<code translate="no" dir="ltr">storage.objects.updateContext</code><sup>21</sup><br />
<code translate="no" dir="ltr">storage.objects.deleteContext</code><sup>22</sup></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">Objects</code></td>
<td><code translate="no" dir="ltr">viewFullContext</code></td>
<td><code translate="no" dir="ltr">storage.objects.viewFullContext</code></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">Objects</code></td>
<td><code translate="no" dir="ltr">watchAll</code></td>
<td><code translate="no" dir="ltr">storage.buckets.update</code></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">Projects.hmacKeys</code></td>
<td><code translate="no" dir="ltr">create</code></td>
<td><code translate="no" dir="ltr">storage.hmacKeys.create</code></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">Projects.hmacKeys</code></td>
<td><code translate="no" dir="ltr">delete</code></td>
<td><code translate="no" dir="ltr">storage.hmacKeys.delete</code></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">Projects.hmacKeys</code></td>
<td><code translate="no" dir="ltr">get</code></td>
<td><code translate="no" dir="ltr">storage.hmacKeys.get</code></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">Projects.hmacKeys</code></td>
<td><code translate="no" dir="ltr">list</code></td>
<td><code translate="no" dir="ltr">storage.hmacKeys.list</code></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">Projects.hmacKeys</code></td>
<td><code translate="no" dir="ltr">update</code></td>
<td><code translate="no" dir="ltr">storage.hmacKeys.update</code></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">Projects.serviceAccount</code></td>
<td><code translate="no" dir="ltr">get</code></td>
<td><code translate="no" dir="ltr">resourceManager.projects.get</code></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">ReportConfigs</code></td>
<td><code translate="no" dir="ltr">delete</code></td>
<td><code translate="no" dir="ltr">storageinsights.reportConfigs.delete</code></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">ReportConfigs</code></td>
<td><code translate="no" dir="ltr">get</code></td>
<td><code translate="no" dir="ltr">storageinsights.reportConfigs.get</code></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">ReportConfigs</code></td>
<td><code translate="no" dir="ltr">list</code></td>
<td><code translate="no" dir="ltr">storageinsights.reportConfigs.list</code></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">ReportConfigs</code></td>
<td><code translate="no" dir="ltr">insert</code></td>
<td><code translate="no" dir="ltr">storageinsights.reportConfigs.create</code></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">ReportConfigs</code></td>
<td><code translate="no" dir="ltr">update</code></td>
<td><code translate="no" dir="ltr">storageinsights.reportConfigs.update</code></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">ReportDetails</code></td>
<td><code translate="no" dir="ltr">get</code></td>
<td><code translate="no" dir="ltr">storageinsights.reportDetails.get</code></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">ReportDetails</code></td>
<td><code translate="no" dir="ltr">list</code></td>
<td><code translate="no" dir="ltr">storageinsights.reportDetails.list</code></td>
</tr>
</tbody>
</table>

<sup>1</sup> If you use the `userProject` parameter or the [`x-goog-user-project` header](/storage/docs/xml-api/reference-headers#xgooguserproject) in your request, you must have `serviceusage.services.use` permission for the project ID that you specify, in addition to the normal IAM permissions required to make the request.

<sup>2</sup> This permission is only required if you want to include ACLs or IAM policies as part of a `full` projection. If you don't have this permission and request a `full` projection, you receive only a partial projection.

<sup>3</sup> This permission is only required when the request includes the `enableObjectRetention` query parameter.

<sup>4</sup> This permission is only required if you want to include ACLs as part of the response.

<sup>5</sup> This permission is required if you want to include ACLs or changes to the [public access prevention](/storage/docs/public-access-prevention) setting as part of the request.

<sup>6</sup> This permission does not apply to buckets with [uniform bucket-level access](/storage/docs/uniform-bucket-level-access) enabled.

<sup>7</sup> This permission is only required if the request causes an object with the same name to be overwritten.

<sup>8</sup> This permission is required when the request body includes the `retention` property or when making an [`UPDATE`](/storage/docs/json_api/v1/objects/update) request for an object that has an existing retention configuration.

<sup>9</sup> This permission is only required when the request includes the query parameter `overrideUnlockedRetention=true`.

<sup>10</sup> This permission is only required when the request includes the query parameter `allowNonEmpty=true`.

<sup>11</sup> This permission is only required when the request includes the query parameter `allowOverwrite=true` and the request causes an object with the same name to be overwritten.

<sup>12</sup> This permission is only required when the request includes the query parameter `copySourceAcl=true`.

<sup>13</sup> This permission is only required if you want to include [bucket IP filtering rules](/storage/docs/ip-filtering-overview) as part of the [Buckets: get](/storage/docs/json_api/v1/buckets/get) request. If you don't have this permission, you receive only a partial projection.

<sup>14</sup> This permission is only required if you want to create, list, delete, and update [bucket IP filtering rules](/storage/docs/ip-filtering-overview).

<sup>15</sup> To move an object within a bucket with [hierarchical namespace](/storage/docs/hns-overview) enabled, you either need `storage.objects.delete` and `storage.objects.get` permissions, or `storage.objects.move` permission if you want to move it without granting read or delete access to the object.

<sup>16</sup> This permission is required only if you want to replace an object.

<sup>17</sup> This permission is required only if you want to automatically create any missing parent folders.

<sup>18</sup> This permission is only required if you want to return caches created with Rapid Cache.

<sup>19</sup> This permission is required only if the request includes either a non-empty `destination.contexts.custom` property to compose an object, or a non-empty `contexts.custom` property to copy, insert or rewrite an object.

<sup>20</sup> This permission is only required if you want to add contexts to an object.

<sup>21</sup> This permission is only required if you want to update contexts of an object.

<sup>22</sup> This permission is only required if you want to delete contexts of an object.

#### ACL-related methods

The following table lists the IAM permissions required to run JSON methods that apply specifically to the management of ACLs. These methods only apply to buckets that have [Uniform bucket-level access](/storage/docs/uniform-bucket-level-access) disabled.

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr class="header">
<th>Resource</th>
<th>Method</th>
<th>Required IAM Permissions<sup>1</sup></th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td><code translate="no" dir="ltr">BucketAccessControls</code></td>
<td><code translate="no" dir="ltr">delete</code></td>
<td><code translate="no" dir="ltr">storage.buckets.get</code><br />
<code translate="no" dir="ltr">storage.buckets.getIamPolicy</code><br />
<code translate="no" dir="ltr">storage.buckets.setIamPolicy</code><br />
<code translate="no" dir="ltr">storage.buckets.update</code></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">BucketAccessControls</code></td>
<td><code translate="no" dir="ltr">get</code></td>
<td><code translate="no" dir="ltr">storage.buckets.get</code><br />
<code translate="no" dir="ltr">storage.buckets.getIamPolicy</code></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">BucketAccessControls</code></td>
<td><code translate="no" dir="ltr">insert</code></td>
<td><code translate="no" dir="ltr">storage.buckets.get</code><br />
<code translate="no" dir="ltr">storage.buckets.getIamPolicy</code><br />
<code translate="no" dir="ltr">storage.buckets.setIamPolicy</code><br />
<code translate="no" dir="ltr">storage.buckets.update</code></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">BucketAccessControls</code></td>
<td><code translate="no" dir="ltr">list</code></td>
<td><code translate="no" dir="ltr">storage.buckets.get</code><br />
<code translate="no" dir="ltr">storage.buckets.getIamPolicy</code></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">BucketAccessControls</code></td>
<td><code translate="no" dir="ltr">patch</code></td>
<td><code translate="no" dir="ltr">storage.buckets.get</code><br />
<code translate="no" dir="ltr">storage.buckets.getIamPolicy</code><br />
<code translate="no" dir="ltr">storage.buckets.setIamPolicy</code><br />
<code translate="no" dir="ltr">storage.buckets.update</code></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">BucketAccessControls</code></td>
<td><code translate="no" dir="ltr">update</code></td>
<td><code translate="no" dir="ltr">storage.buckets.get</code><br />
<code translate="no" dir="ltr">storage.buckets.getIamPolicy</code><br />
<code translate="no" dir="ltr">storage.buckets.setIamPolicy</code><br />
<code translate="no" dir="ltr">storage.buckets.update</code></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">DefaultObjectAccessControls</code></td>
<td><code translate="no" dir="ltr">delete</code></td>
<td><code translate="no" dir="ltr">storage.buckets.get</code><br />
<code translate="no" dir="ltr">storage.buckets.getIamPolicy</code><br />
<code translate="no" dir="ltr">storage.buckets.setIamPolicy</code><br />
<code translate="no" dir="ltr">storage.buckets.update</code></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">DefaultObjectAccessControls</code></td>
<td><code translate="no" dir="ltr">get</code></td>
<td><code translate="no" dir="ltr">storage.buckets.get</code><br />
<code translate="no" dir="ltr">storage.buckets.getIamPolicy</code></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">DefaultObjectAccessControls</code></td>
<td><code translate="no" dir="ltr">insert</code></td>
<td><code translate="no" dir="ltr">storage.buckets.get</code><br />
<code translate="no" dir="ltr">storage.buckets.getIamPolicy</code><br />
<code translate="no" dir="ltr">storage.buckets.setIamPolicy</code><br />
<code translate="no" dir="ltr">storage.buckets.update</code></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">DefaultObjectAccessControls</code></td>
<td><code translate="no" dir="ltr">list</code></td>
<td><code translate="no" dir="ltr">storage.buckets.get</code><br />
<code translate="no" dir="ltr">storage.buckets.getIamPolicy</code></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">DefaultObjectAccessControls</code></td>
<td><code translate="no" dir="ltr">patch</code></td>
<td><code translate="no" dir="ltr">storage.buckets.get</code><br />
<code translate="no" dir="ltr">storage.buckets.getIamPolicy</code><br />
<code translate="no" dir="ltr">storage.buckets.setIamPolicy</code><br />
<code translate="no" dir="ltr">storage.buckets.update</code></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">DefaultObjectAccessControls</code></td>
<td><code translate="no" dir="ltr">update</code></td>
<td><code translate="no" dir="ltr">storage.buckets.get</code><br />
<code translate="no" dir="ltr">storage.buckets.getIamPolicy</code><br />
<code translate="no" dir="ltr">storage.buckets.setIamPolicy</code><br />
<code translate="no" dir="ltr">storage.buckets.update</code></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">ObjectAccessControls</code></td>
<td><code translate="no" dir="ltr">delete</code></td>
<td><code translate="no" dir="ltr">storage.objects.get</code><br />
<code translate="no" dir="ltr">storage.objects.getIamPolicy</code><br />
<code translate="no" dir="ltr">storage.objects.setIamPolicy</code><br />
<code translate="no" dir="ltr">storage.objects.update</code></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">ObjectAccessControls</code></td>
<td><code translate="no" dir="ltr">get</code></td>
<td><code translate="no" dir="ltr">storage.objects.get</code><br />
<code translate="no" dir="ltr">storage.objects.getIamPolicy</code></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">ObjectAccessControls</code></td>
<td><code translate="no" dir="ltr">insert</code></td>
<td><code translate="no" dir="ltr">storage.objects.get</code><br />
<code translate="no" dir="ltr">storage.objects.getIamPolicy</code><br />
<code translate="no" dir="ltr">storage.objects.setIamPolicy</code><br />
<code translate="no" dir="ltr">storage.objects.update</code></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">ObjectAccessControls</code></td>
<td><code translate="no" dir="ltr">list</code></td>
<td><code translate="no" dir="ltr">storage.objects.get</code><br />
<code translate="no" dir="ltr">storage.objects.getIamPolicy</code></td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">ObjectAccessControls</code></td>
<td><code translate="no" dir="ltr">patch</code></td>
<td><code translate="no" dir="ltr">storage.objects.get</code><br />
<code translate="no" dir="ltr">storage.objects.getIamPolicy</code><br />
<code translate="no" dir="ltr">storage.objects.setIamPolicy</code><br />
<code translate="no" dir="ltr">storage.objects.update</code></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">ObjectAccessControls</code></td>
<td><code translate="no" dir="ltr">update</code></td>
<td><code translate="no" dir="ltr">storage.objects.get</code><br />
<code translate="no" dir="ltr">storage.objects.getIamPolicy</code><br />
<code translate="no" dir="ltr">storage.objects.setIamPolicy</code><br />
<code translate="no" dir="ltr">storage.objects.update</code></td>
</tr>
</tbody>
</table>

<sup>1</sup> If you use the `userProject` parameter or the [`x-goog-user-project` header](/storage/docs/xml-api/reference-headers#xgooguserproject) in your request, you must have `serviceusage.services.use` permission for the project ID that you specify, in addition to the normal IAM permissions required to make the request.

## What's next

- For a list of roles and the permissions they contain, see [IAM Roles for Cloud Storage](/storage/docs/access-control/iam-roles).

- [Assign IAM roles](/storage/docs/access-control/using-iam-permissions) at the project and bucket level.

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
