# BigQuery roles and permissions

<div class="devsite-article-body clearfix">

This page lists the IAM roles and permissions for BigQuery. To search through all roles and permissions, see the [role and permission index](/iam/docs/roles-permissions).

## BigQuery roles

<div results-count-container="">

</div>

<table class="fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="50%">Role</th>
<th>Permissions</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td class="role-description"><h4 id="bigquery.admin" class="role-title add-link" data-text="BigQuery Admin " tabindex="-1">BigQuery Admin</h4>
<p>(<code translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<span class="role-description custom"> </span>
<p>Provides permissions to manage all resources within the project. Can manage all data within the project, and can cancel jobs from other users running within the project.</p>
<p>It is possible to grant this role to the following lowest-level resources, but it is not recommended. Other predefined roles grant full permissions over these resources and are less permissive. BigQuery Admin is typically granted at the project level.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Dataset</li>
<li>These resources within a dataset:</li>
<li><ul>
<li>Table</li>
<li>View</li>
<li>Routine</li>
</ul></li>
<li>Connection</li>
<li>Saved query</li>
<li>Data canvas</li>
<li>Pipeline</li>
<li>Data preparation</li>
<li>Repository</li>
</ul>
<p>This role can also be granted on Resource Manager resources (projects, folders, and organizations).</p></td>
<td class="role-permissions"><p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.bireservations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.bireservations.get</code></li>
<li><code translate="no" dir="ltr">bigquery.bireservations.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.capacityCommitments.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.capacityCommitments.create</code></li>
<li><code translate="no" dir="ltr">bigquery.capacityCommitments.delete</code></li>
<li><code translate="no" dir="ltr">bigquery.capacityCommitments.get</code></li>
<li><code translate="no" dir="ltr">bigquery.capacityCommitments.list</code></li>
<li><code translate="no" dir="ltr">bigquery.capacityCommitments.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.config.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.config.get</code></li>
<li><code translate="no" dir="ltr">bigquery.config.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.connections.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.connections.create</code></li>
<li><code translate="no" dir="ltr">bigquery.connections.delegate</code></li>
<li><code translate="no" dir="ltr">bigquery.connections.delete</code></li>
<li><code translate="no" dir="ltr">bigquery.connections.get</code></li>
<li><code translate="no" dir="ltr">bigquery.connections.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">bigquery.connections.list</code></li>
<li><code translate="no" dir="ltr">bigquery.connections.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">bigquery.connections.update</code></li>
<li><code translate="no" dir="ltr">bigquery.connections.updateTag</code></li>
<li><code translate="no" dir="ltr">bigquery.connections.use</code></li>
</ul>
<p><code translate="no" dir="ltr">bigquery.dataPolicies.attach</code></p>
<p><code translate="no" dir="ltr">bigquery.dataPolicies.create</code></p>
<p><code translate="no" dir="ltr">bigquery.dataPolicies.delete</code></p>
<p><code translate="no" dir="ltr">bigquery.dataPolicies.get</code></p>
<p><code translate="no" dir="ltr">bigquery.dataPolicies.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigquery.dataPolicies.list</code></p>
<p><code translate="no" dir="ltr">bigquery.dataPolicies.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigquery.dataPolicies.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.datasets.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.datasets.create</code></li>
<li><code translate="no" dir="ltr">bigquery.datasets.createTagBinding</code></li>
<li><code translate="no" dir="ltr">bigquery.datasets.delete</code></li>
<li><code translate="no" dir="ltr">bigquery.datasets.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">bigquery.datasets.get</code></li>
<li><code translate="no" dir="ltr">bigquery.datasets.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">bigquery.datasets.link</code></li>
<li><code translate="no" dir="ltr">bigquery.datasets.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">bigquery.datasets.listSharedDatasetUsage</code></li>
<li><code translate="no" dir="ltr">bigquery.datasets.listTagBindings</code></li>
<li><code translate="no" dir="ltr">bigquery.datasets.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">bigquery.datasets.update</code></li>
<li><code translate="no" dir="ltr">bigquery.datasets.updateTag</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.jobs.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.jobs.create</code></li>
<li><code translate="no" dir="ltr">bigquery.jobs.createGlobalQuery</code></li>
<li><code translate="no" dir="ltr">bigquery.jobs.delete</code></li>
<li><code translate="no" dir="ltr">bigquery.jobs.get</code></li>
<li><code translate="no" dir="ltr">bigquery.jobs.list</code></li>
<li><code translate="no" dir="ltr">bigquery.jobs.listAll</code></li>
<li><code translate="no" dir="ltr">bigquery.jobs.listExecutionMetadata</code></li>
<li><code translate="no" dir="ltr">bigquery.jobs.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.models.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.models.create</code></li>
<li><code translate="no" dir="ltr">bigquery.models.delete</code></li>
<li><code translate="no" dir="ltr">bigquery.models.export</code></li>
<li><code translate="no" dir="ltr">bigquery.models.getData</code></li>
<li><code translate="no" dir="ltr">bigquery.models.getMetadata</code></li>
<li><code translate="no" dir="ltr">bigquery.models.list</code></li>
<li><code translate="no" dir="ltr">bigquery.models.updateData</code></li>
<li><code translate="no" dir="ltr">bigquery.models.updateMetadata</code></li>
<li><code translate="no" dir="ltr">bigquery.models.updateTag</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.objectRefs.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.objectRefs.read</code></li>
<li><code translate="no" dir="ltr">bigquery.objectRefs.write</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.propertyGraphs.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.propertyGraphs.create</code></li>
<li><code translate="no" dir="ltr">bigquery.propertyGraphs.delete</code></li>
<li><code translate="no" dir="ltr">bigquery.propertyGraphs.get</code></li>
<li><code translate="no" dir="ltr">bigquery.propertyGraphs.list</code></li>
<li><code translate="no" dir="ltr">bigquery.propertyGraphs.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.readsessions.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.readsessions.create</code></li>
<li><code translate="no" dir="ltr">bigquery.readsessions.getData</code></li>
<li><code translate="no" dir="ltr">bigquery.readsessions.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.reservationAssignments.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.reservationAssignments.create</code></li>
<li><code translate="no" dir="ltr">bigquery.reservationAssignments.delete</code></li>
<li><code translate="no" dir="ltr">bigquery.reservationAssignments.list</code></li>
<li><code translate="no" dir="ltr">bigquery.reservationAssignments.search</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.reservationGroups.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.reservationGroups.create</code></li>
<li><code translate="no" dir="ltr">bigquery.reservationGroups.delete</code></li>
<li><code translate="no" dir="ltr">bigquery.reservationGroups.get</code></li>
<li><code translate="no" dir="ltr">bigquery.reservationGroups.list</code></li>
<li><code translate="no" dir="ltr">bigquery.reservationGroups.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.reservations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.reservations.create</code></li>
<li><code translate="no" dir="ltr">bigquery.reservations.delete</code></li>
<li><code translate="no" dir="ltr">bigquery.reservations.get</code></li>
<li><code translate="no" dir="ltr">bigquery.reservations.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">bigquery.reservations.list</code></li>
<li><code translate="no" dir="ltr">bigquery.reservations.listFailoverDatasets</code></li>
<li><code translate="no" dir="ltr">bigquery.reservations.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">bigquery.reservations.update</code></li>
<li><code translate="no" dir="ltr">bigquery.reservations.use</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.routines.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.routines.create</code></li>
<li><code translate="no" dir="ltr">bigquery.routines.delete</code></li>
<li><code translate="no" dir="ltr">bigquery.routines.get</code></li>
<li><code translate="no" dir="ltr">bigquery.routines.list</code></li>
<li><code translate="no" dir="ltr">bigquery.routines.update</code></li>
<li><code translate="no" dir="ltr">bigquery.routines.updateTag</code></li>
</ul>
<p><code translate="no" dir="ltr">bigquery.rowAccessPolicies.create</code></p>
<p><code translate="no" dir="ltr">bigquery.rowAccessPolicies.delete</code></p>
<p><code translate="no" dir="ltr">bigquery.rowAccessPolicies.get</code></p>
<p><code translate="no" dir="ltr">bigquery.rowAccessPolicies.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigquery.rowAccessPolicies.list</code></p>
<p><code translate="no" dir="ltr">bigquery.rowAccessPolicies.overrideTimeTravelRestrictions</code></p>
<p><code translate="no" dir="ltr">bigquery.rowAccessPolicies.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigquery.rowAccessPolicies.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.savedqueries.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.savedqueries.create</code></li>
<li><code translate="no" dir="ltr">bigquery.savedqueries.delete</code></li>
<li><code translate="no" dir="ltr">bigquery.savedqueries.get</code></li>
<li><code translate="no" dir="ltr">bigquery.savedqueries.list</code></li>
<li><code translate="no" dir="ltr">bigquery.savedqueries.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.tables.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.tables.create</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.createIndex</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.createSnapshot</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.createTagBinding</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.delete</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.deleteIndex</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.deleteSnapshot</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.export</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.get</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.getData</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.list</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.listTagBindings</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.replicateData</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.restoreSnapshot</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.setCategory</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.setColumnDataPolicy</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.update</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.updateData</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.updateIndex</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.updateTag</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.transfers.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.transfers.get</code></li>
<li><code translate="no" dir="ltr">bigquery.transfers.update</code></li>
</ul>
<p><code translate="no" dir="ltr">bigquerymigration.translation.translate</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudkms.keyHandles.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudkms.keyHandles.create</code></li>
<li><code translate="no" dir="ltr">cloudkms.keyHandles.get</code></li>
<li><code translate="no" dir="ltr">cloudkms.keyHandles.list</code></li>
</ul>
<p><code translate="no" dir="ltr">cloudkms.operations.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.projects.showEffectiveAutokeyConfig</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">dataform.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">dataform.commentThreads.create</code></li>
<li><code translate="no" dir="ltr">dataform.commentThreads.delete</code></li>
<li><code translate="no" dir="ltr">dataform.commentThreads.get</code></li>
<li><code translate="no" dir="ltr">dataform.commentThreads.list</code></li>
<li><code translate="no" dir="ltr">dataform.commentThreads.update</code></li>
<li><code translate="no" dir="ltr">dataform.comments.create</code></li>
<li><code translate="no" dir="ltr">dataform.comments.delete</code></li>
<li><code translate="no" dir="ltr">dataform.comments.get</code></li>
<li><code translate="no" dir="ltr">dataform.comments.list</code></li>
<li><code translate="no" dir="ltr">dataform.comments.update</code></li>
<li><code translate="no" dir="ltr">dataform.compilationResults.create</code></li>
<li><code translate="no" dir="ltr">dataform.compilationResults.get</code></li>
<li><code translate="no" dir="ltr">dataform.compilationResults.list</code></li>
<li><code translate="no" dir="ltr">dataform.compilationResults.query</code></li>
<li><code translate="no" dir="ltr">dataform.config.get</code></li>
<li><code translate="no" dir="ltr">dataform.config.update</code></li>
<li><code translate="no" dir="ltr">dataform.folders.addContents</code></li>
<li><code translate="no" dir="ltr">dataform.folders.create</code></li>
<li><code translate="no" dir="ltr">dataform.folders.delete</code></li>
<li><code translate="no" dir="ltr">dataform.folders.deleteTree</code></li>
<li><code translate="no" dir="ltr">dataform.folders.get</code></li>
<li><code translate="no" dir="ltr">dataform.folders.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">dataform.folders.move</code></li>
<li><code translate="no" dir="ltr">dataform.folders.queryContents</code></li>
<li><code translate="no" dir="ltr">dataform.folders.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">dataform.folders.update</code></li>
<li><code translate="no" dir="ltr">dataform.locations.get</code></li>
<li><code translate="no" dir="ltr">dataform.locations.list</code></li>
<li><code translate="no" dir="ltr">dataform.operations.cancel</code></li>
<li><code translate="no" dir="ltr">dataform.operations.delete</code></li>
<li><code translate="no" dir="ltr">dataform.operations.get</code></li>
<li><code translate="no" dir="ltr">dataform.operations.list</code></li>
<li><code translate="no" dir="ltr">dataform.releaseConfigs.create</code></li>
<li><code translate="no" dir="ltr">dataform.releaseConfigs.delete</code></li>
<li><code translate="no" dir="ltr">dataform.releaseConfigs.get</code></li>
<li><code translate="no" dir="ltr">dataform.releaseConfigs.list</code></li>
<li><code translate="no" dir="ltr">dataform.releaseConfigs.update</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.commit</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.computeAccessTokenStatus</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.create</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.createTagBinding</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.delete</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.fetchHistory</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.fetchRemoteBranches</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.get</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.list</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.listTagBindings</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.move</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.queryDirectoryContents</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.readFile</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.scheduleRelease</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.scheduleWorkflow</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.update</code></li>
<li><code translate="no" dir="ltr">dataform.teamFolders.create</code></li>
<li><code translate="no" dir="ltr">dataform.teamFolders.delete</code></li>
<li><code translate="no" dir="ltr">dataform.teamFolders.deleteTree</code></li>
<li><code translate="no" dir="ltr">dataform.teamFolders.get</code></li>
<li><code translate="no" dir="ltr">dataform.teamFolders.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">dataform.teamFolders.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">dataform.teamFolders.update</code></li>
<li><code translate="no" dir="ltr">dataform.workflowConfigs.create</code></li>
<li><code translate="no" dir="ltr">dataform.workflowConfigs.delete</code></li>
<li><code translate="no" dir="ltr">dataform.workflowConfigs.get</code></li>
<li><code translate="no" dir="ltr">dataform.workflowConfigs.list</code></li>
<li><code translate="no" dir="ltr">dataform.workflowConfigs.update</code></li>
<li><code translate="no" dir="ltr">dataform.workflowInvocations.cancel</code></li>
<li><code translate="no" dir="ltr">dataform.workflowInvocations.create</code></li>
<li><code translate="no" dir="ltr">dataform.workflowInvocations.delete</code></li>
<li><code translate="no" dir="ltr">dataform.workflowInvocations.get</code></li>
<li><code translate="no" dir="ltr">dataform.workflowInvocations.list</code></li>
<li><code translate="no" dir="ltr">dataform.workflowInvocations.query</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.commit</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.create</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.delete</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.fetchFileDiff</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.fetchFileGitStatuses</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.fetchGitAheadBehind</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.get</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.installNpmPackages</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.list</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.makeDirectory</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.moveDirectory</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.moveFile</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.pull</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.push</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.queryDirectoryContents</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.readFile</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.removeDirectory</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.removeFile</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.reset</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.searchFiles</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.writeFile</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">dataplex.agentTasks.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">dataplex.agentTasks.create</code></li>
<li><code translate="no" dir="ltr">dataplex.agentTasks.delete</code></li>
<li><code translate="no" dir="ltr">dataplex.agentTasks.get</code></li>
<li><code translate="no" dir="ltr">dataplex.agentTasks.getData</code></li>
<li><code translate="no" dir="ltr">dataplex.agentTasks.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">dataplex.agentTasks.list</code></li>
<li><code translate="no" dir="ltr">dataplex.agentTasks.run</code></li>
<li><code translate="no" dir="ltr">dataplex.agentTasks.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">dataplex.agentTasks.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">dataplex.datascans.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">dataplex.datascans.cancel</code></li>
<li><code translate="no" dir="ltr">dataplex.datascans.create</code></li>
<li><code translate="no" dir="ltr">dataplex.datascans.delete</code></li>
<li><code translate="no" dir="ltr">dataplex.datascans.get</code></li>
<li><code translate="no" dir="ltr">dataplex.datascans.getData</code></li>
<li><code translate="no" dir="ltr">dataplex.datascans.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">dataplex.datascans.list</code></li>
<li><code translate="no" dir="ltr">dataplex.datascans.run</code></li>
<li><code translate="no" dir="ltr">dataplex.datascans.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">dataplex.datascans.update</code></li>
</ul>
<p><code translate="no" dir="ltr">dataplex.operations.get</code></p>
<p><code translate="no" dir="ltr">dataplex.operations.list</code></p>
<p><code translate="no" dir="ltr">dataplex.projects.search</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">developerconnect.accountConnectors.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">developerconnect.accountConnectors.create</code></li>
<li><code translate="no" dir="ltr">developerconnect.accountConnectors.delete</code></li>
<li><code translate="no" dir="ltr">developerconnect.accountConnectors.fetchUserRepositories</code></li>
<li><code translate="no" dir="ltr">developerconnect.accountConnectors.get</code></li>
<li><code translate="no" dir="ltr">developerconnect.accountConnectors.gitProxyRead</code></li>
<li><code translate="no" dir="ltr">developerconnect.accountConnectors.gitProxyWrite</code></li>
<li><code translate="no" dir="ltr">developerconnect.accountConnectors.httpProxyRead</code></li>
<li><code translate="no" dir="ltr">developerconnect.accountConnectors.httpProxyWrite</code></li>
<li><code translate="no" dir="ltr">developerconnect.accountConnectors.list</code></li>
<li><code translate="no" dir="ltr">developerconnect.accountConnectors.update</code></li>
</ul>
<p><code translate="no" dir="ltr">developerconnect.connections.constructGitHubAppManifest</code></p>
<p><code translate="no" dir="ltr">developerconnect.connections.create</code></p>
<p><code translate="no" dir="ltr">developerconnect.connections.delete</code></p>
<p><code translate="no" dir="ltr">developerconnect.connections.fetchGitHubInstallations</code></p>
<p><code translate="no" dir="ltr">developerconnect.connections.fetchLinkableGitRepositories</code></p>
<p><code translate="no" dir="ltr">developerconnect.connections.generateGitHubStateToken</code></p>
<p><code translate="no" dir="ltr">developerconnect.connections.get</code></p>
<p><code translate="no" dir="ltr">developerconnect.connections.list</code></p>
<p><code translate="no" dir="ltr">developerconnect.connections.processGitHubAppCreationCallback</code></p>
<p><code translate="no" dir="ltr">developerconnect.connections.processGitHubOAuthCallback</code></p>
<p><code translate="no" dir="ltr">developerconnect.connections.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">developerconnect.gitRepositoryLinks.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">developerconnect.gitRepositoryLinks.create</code></li>
<li><code translate="no" dir="ltr">developerconnect.gitRepositoryLinks.delete</code></li>
<li><code translate="no" dir="ltr">developerconnect.gitRepositoryLinks.fetchGitRefs</code></li>
<li><code translate="no" dir="ltr">developerconnect.gitRepositoryLinks.fetchReadToken</code></li>
<li><code translate="no" dir="ltr">developerconnect.gitRepositoryLinks.fetchReadWriteToken</code></li>
<li><code translate="no" dir="ltr">developerconnect.gitRepositoryLinks.get</code></li>
<li><code translate="no" dir="ltr">developerconnect.gitRepositoryLinks.gitProxyRead</code></li>
<li><code translate="no" dir="ltr">developerconnect.gitRepositoryLinks.gitProxyWrite</code></li>
<li><code translate="no" dir="ltr">developerconnect.gitRepositoryLinks.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">developerconnect.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">developerconnect.locations.get</code></li>
<li><code translate="no" dir="ltr">developerconnect.locations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">developerconnect.operations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">developerconnect.operations.cancel</code></li>
<li><code translate="no" dir="ltr">developerconnect.operations.delete</code></li>
<li><code translate="no" dir="ltr">developerconnect.operations.get</code></li>
<li><code translate="no" dir="ltr">developerconnect.operations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">developerconnect.providers.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">developerconnect.users.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">developerconnect.users.delete</code></li>
<li><code translate="no" dir="ltr">developerconnect.users.deleteSelf</code></li>
<li><code translate="no" dir="ltr">developerconnect.users.fetchAccessToken</code></li>
<li><code translate="no" dir="ltr">developerconnect.users.finishOAuth</code></li>
<li><code translate="no" dir="ltr">developerconnect.users.getSelf</code></li>
<li><code translate="no" dir="ltr">developerconnect.users.list</code></li>
<li><code translate="no" dir="ltr">developerconnect.users.startOAuth</code></li>
</ul>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="bigquery.connectionAdmin" class="role-title add-link" data-text="BigQuery Connection Admin " tabindex="-1">BigQuery Connection Admin</h4>
<p>(<code translate="no" dir="ltr">roles/bigquery.connectionAdmin</code>)</p>
<span class="role-description custom"> </span>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Connection</li>
</ul>
<p>This role can also be granted on Resource Manager resources (projects, folders, and organizations).</p></td>
<td class="role-permissions"><p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.connections.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.connections.create</code></li>
<li><code translate="no" dir="ltr">bigquery.connections.delegate</code></li>
<li><code translate="no" dir="ltr">bigquery.connections.delete</code></li>
<li><code translate="no" dir="ltr">bigquery.connections.get</code></li>
<li><code translate="no" dir="ltr">bigquery.connections.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">bigquery.connections.list</code></li>
<li><code translate="no" dir="ltr">bigquery.connections.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">bigquery.connections.update</code></li>
<li><code translate="no" dir="ltr">bigquery.connections.updateTag</code></li>
<li><code translate="no" dir="ltr">bigquery.connections.use</code></li>
</ul></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="bigquery.connectionUser" class="role-title add-link" data-text="BigQuery Connection User " tabindex="-1">BigQuery Connection User</h4>
<p>(<code translate="no" dir="ltr">roles/bigquery.connectionUser</code>)</p>
<span class="role-description custom"> </span>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Connection</li>
</ul>
<p>This role can also be granted on Resource Manager resources (projects, folders, and organizations).</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">bigquery.connections.get</code></p>
<p><code translate="no" dir="ltr">bigquery.connections.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigquery.connections.list</code></p>
<p><code translate="no" dir="ltr">bigquery.connections.use</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="bigquery.dataEditor" class="role-title add-link" data-text="BigQuery Data Editor " tabindex="-1">BigQuery Data Editor</h4>
<p>(<code translate="no" dir="ltr">roles/bigquery.dataEditor</code>)</p>
<span class="role-description custom"> </span>
<p>When granted on a dataset, this role grants these permissions:</p>
<ul>
<li>Get metadata and permissions for the dataset.</li>
<li>For tables and views:</li>
<li><ul>
<li>Create, update, get, list, and delete the dataset's tables and views.</li>
<li>Read (query), export, replicate, and update table data.</li>
<li>Create, update, and delete indexes.</li>
<li>Create and restore snapshots.</li>
</ul></li>
<li>All permissions for the dataset's routines and models.</li>
</ul>
<strong>Note:</strong> Principals that are granted the Data Editor role at the project level can also create new datasets and list datasets in the project that they have access to.
<p>When granted on a table or view, this role grants these permissions:</p>
<ul>
<li>Get metadata, update metadata, get access controls, and delete the table or view.</li>
<li>Get (query), export, replicate, and update table data.</li>
<li>Create, update, and delete indexes.</li>
<li>Create and restore snapshots.</li>
</ul>
<ul>
<li>All permissions for the routine.</li>
</ul>
<p>The Data Editor role cannot be granted to individual models.</p>
<strong>Note:</strong> The BigQuery Data Editor role is mapped to the <a href="/bigquery/docs/access-control-basic-roles#dataset-basic-roles"><code translate="no" dir="ltr">WRITER</code></a> BigQuery basic role. When you grant the BigQuery Data Editor role to a principal at the dataset level, the principal is granted <code translate="no" dir="ltr">WRITER</code> access to the dataset.
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Dataset</li>
<li>These resources within a dataset:</li>
<li><ul>
<li>Table</li>
<li>View</li>
<li>Routine</li>
</ul></li>
</ul>
<p>This role can also be granted on Resource Manager resources (projects, folders, and organizations).</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">bigquery.config.get</code></p>
<p><code translate="no" dir="ltr">bigquery.datasets.create</code></p>
<p><code translate="no" dir="ltr">bigquery.datasets.get</code></p>
<p><code translate="no" dir="ltr">bigquery.datasets.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigquery.datasets.updateTag</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.models.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.models.create</code></li>
<li><code translate="no" dir="ltr">bigquery.models.delete</code></li>
<li><code translate="no" dir="ltr">bigquery.models.export</code></li>
<li><code translate="no" dir="ltr">bigquery.models.getData</code></li>
<li><code translate="no" dir="ltr">bigquery.models.getMetadata</code></li>
<li><code translate="no" dir="ltr">bigquery.models.list</code></li>
<li><code translate="no" dir="ltr">bigquery.models.updateData</code></li>
<li><code translate="no" dir="ltr">bigquery.models.updateMetadata</code></li>
<li><code translate="no" dir="ltr">bigquery.models.updateTag</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.propertyGraphs.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.propertyGraphs.create</code></li>
<li><code translate="no" dir="ltr">bigquery.propertyGraphs.delete</code></li>
<li><code translate="no" dir="ltr">bigquery.propertyGraphs.get</code></li>
<li><code translate="no" dir="ltr">bigquery.propertyGraphs.list</code></li>
<li><code translate="no" dir="ltr">bigquery.propertyGraphs.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.routines.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.routines.create</code></li>
<li><code translate="no" dir="ltr">bigquery.routines.delete</code></li>
<li><code translate="no" dir="ltr">bigquery.routines.get</code></li>
<li><code translate="no" dir="ltr">bigquery.routines.list</code></li>
<li><code translate="no" dir="ltr">bigquery.routines.update</code></li>
<li><code translate="no" dir="ltr">bigquery.routines.updateTag</code></li>
</ul>
<p><code translate="no" dir="ltr">bigquery.tables.create</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.createIndex</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.createSnapshot</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.delete</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.deleteIndex</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.export</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.get</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.getData</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.list</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.replicateData</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.restoreSnapshot</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.update</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.updateData</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.updateIndex</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.updateTag</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudkms.keyHandles.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudkms.keyHandles.create</code></li>
<li><code translate="no" dir="ltr">cloudkms.keyHandles.get</code></li>
<li><code translate="no" dir="ltr">cloudkms.keyHandles.list</code></li>
</ul>
<p><code translate="no" dir="ltr">cloudkms.operations.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.projects.showEffectiveAutokeyConfig</code></p>
<p><code translate="no" dir="ltr">dataplex.agentTasks.create</code></p>
<p><code translate="no" dir="ltr">dataplex.agentTasks.delete</code></p>
<p><code translate="no" dir="ltr">dataplex.agentTasks.get</code></p>
<p><code translate="no" dir="ltr">dataplex.agentTasks.getData</code></p>
<p><code translate="no" dir="ltr">dataplex.agentTasks.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.agentTasks.list</code></p>
<p><code translate="no" dir="ltr">dataplex.agentTasks.run</code></p>
<p><code translate="no" dir="ltr">dataplex.agentTasks.update</code></p>
<p><code translate="no" dir="ltr">dataplex.datascans.cancel</code></p>
<p><code translate="no" dir="ltr">dataplex.datascans.create</code></p>
<p><code translate="no" dir="ltr">dataplex.datascans.delete</code></p>
<p><code translate="no" dir="ltr">dataplex.datascans.get</code></p>
<p><code translate="no" dir="ltr">dataplex.datascans.getData</code></p>
<p><code translate="no" dir="ltr">dataplex.datascans.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.datascans.list</code></p>
<p><code translate="no" dir="ltr">dataplex.datascans.run</code></p>
<p><code translate="no" dir="ltr">dataplex.datascans.update</code></p>
<p><code translate="no" dir="ltr">dataplex.operations.get</code></p>
<p><code translate="no" dir="ltr">dataplex.operations.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="bigquery.dataOwner" class="role-title add-link" data-text="BigQuery Data Owner " tabindex="-1">BigQuery Data Owner</h4>
<p>(<code translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<span class="role-description custom"> </span>
<p>When granted on a dataset, this role grants these permissions:</p>
<ul>
<li>All permissions for the dataset and for all of the resources within the dataset: tables and views, models, and routines.</li>
</ul>
<strong>Note:</strong> Principals that are granted the Data Owner role at the project level can also create new datasets and list datasets in the project that they have access to.
<p>When granted on a table or view, this role grants these permissions:</p>
<ul>
<li>All permissions for the table or view.</li>
<li>All permissions for row access policies except permission to override time travel restrictions.</li>
<li>Set categories and column-level data policies.</li>
</ul>
<p>When granted on a routine, this role grants these permissions:</p>
<ul>
<li>All permissions for the routine.</li>
</ul>
<p>You shouldn't grant the Data Owner role at the routine level. Data Editor also grants all permissions for the routine and is a less permissive role.</p>
<p>This role cannot be granted to individual models.</p>
<strong>Note:</strong> The BigQuery Data Owner role is mapped to the <a href="/bigquery/docs/access-control-basic-roles#dataset-basic-roles"><code translate="no" dir="ltr">OWNER</code></a> BigQuery basic role. When you grant the BigQuery Data Owner role to a principal at the dataset level, the principal is granted <code translate="no" dir="ltr">OWNER</code> access to the dataset.
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Dataset</li>
<li>These resources within a dataset:</li>
<li><ul>
<li>Table</li>
<li>View</li>
<li>Routine</li>
</ul></li>
</ul>
<p>This role can also be granted on Resource Manager resources (projects, folders, and organizations).</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">bigquery.config.get</code></p>
<p><code translate="no" dir="ltr">bigquery.dataPolicies.attach</code></p>
<p><code translate="no" dir="ltr">bigquery.dataPolicies.create</code></p>
<p><code translate="no" dir="ltr">bigquery.dataPolicies.delete</code></p>
<p><code translate="no" dir="ltr">bigquery.dataPolicies.get</code></p>
<p><code translate="no" dir="ltr">bigquery.dataPolicies.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigquery.dataPolicies.list</code></p>
<p><code translate="no" dir="ltr">bigquery.dataPolicies.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigquery.dataPolicies.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.datasets.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.datasets.create</code></li>
<li><code translate="no" dir="ltr">bigquery.datasets.createTagBinding</code></li>
<li><code translate="no" dir="ltr">bigquery.datasets.delete</code></li>
<li><code translate="no" dir="ltr">bigquery.datasets.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">bigquery.datasets.get</code></li>
<li><code translate="no" dir="ltr">bigquery.datasets.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">bigquery.datasets.link</code></li>
<li><code translate="no" dir="ltr">bigquery.datasets.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">bigquery.datasets.listSharedDatasetUsage</code></li>
<li><code translate="no" dir="ltr">bigquery.datasets.listTagBindings</code></li>
<li><code translate="no" dir="ltr">bigquery.datasets.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">bigquery.datasets.update</code></li>
<li><code translate="no" dir="ltr">bigquery.datasets.updateTag</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.models.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.models.create</code></li>
<li><code translate="no" dir="ltr">bigquery.models.delete</code></li>
<li><code translate="no" dir="ltr">bigquery.models.export</code></li>
<li><code translate="no" dir="ltr">bigquery.models.getData</code></li>
<li><code translate="no" dir="ltr">bigquery.models.getMetadata</code></li>
<li><code translate="no" dir="ltr">bigquery.models.list</code></li>
<li><code translate="no" dir="ltr">bigquery.models.updateData</code></li>
<li><code translate="no" dir="ltr">bigquery.models.updateMetadata</code></li>
<li><code translate="no" dir="ltr">bigquery.models.updateTag</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.propertyGraphs.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.propertyGraphs.create</code></li>
<li><code translate="no" dir="ltr">bigquery.propertyGraphs.delete</code></li>
<li><code translate="no" dir="ltr">bigquery.propertyGraphs.get</code></li>
<li><code translate="no" dir="ltr">bigquery.propertyGraphs.list</code></li>
<li><code translate="no" dir="ltr">bigquery.propertyGraphs.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.routines.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.routines.create</code></li>
<li><code translate="no" dir="ltr">bigquery.routines.delete</code></li>
<li><code translate="no" dir="ltr">bigquery.routines.get</code></li>
<li><code translate="no" dir="ltr">bigquery.routines.list</code></li>
<li><code translate="no" dir="ltr">bigquery.routines.update</code></li>
<li><code translate="no" dir="ltr">bigquery.routines.updateTag</code></li>
</ul>
<p><code translate="no" dir="ltr">bigquery.rowAccessPolicies.create</code></p>
<p><code translate="no" dir="ltr">bigquery.rowAccessPolicies.delete</code></p>
<p><code translate="no" dir="ltr">bigquery.rowAccessPolicies.get</code></p>
<p><code translate="no" dir="ltr">bigquery.rowAccessPolicies.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigquery.rowAccessPolicies.list</code></p>
<p><code translate="no" dir="ltr">bigquery.rowAccessPolicies.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigquery.rowAccessPolicies.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.tables.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.tables.create</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.createIndex</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.createSnapshot</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.createTagBinding</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.delete</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.deleteIndex</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.deleteSnapshot</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.export</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.get</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.getData</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.list</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.listTagBindings</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.replicateData</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.restoreSnapshot</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.setCategory</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.setColumnDataPolicy</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.update</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.updateData</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.updateIndex</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.updateTag</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudkms.keyHandles.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudkms.keyHandles.create</code></li>
<li><code translate="no" dir="ltr">cloudkms.keyHandles.get</code></li>
<li><code translate="no" dir="ltr">cloudkms.keyHandles.list</code></li>
</ul>
<p><code translate="no" dir="ltr">cloudkms.operations.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.projects.showEffectiveAutokeyConfig</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">dataplex.agentTasks.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">dataplex.agentTasks.create</code></li>
<li><code translate="no" dir="ltr">dataplex.agentTasks.delete</code></li>
<li><code translate="no" dir="ltr">dataplex.agentTasks.get</code></li>
<li><code translate="no" dir="ltr">dataplex.agentTasks.getData</code></li>
<li><code translate="no" dir="ltr">dataplex.agentTasks.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">dataplex.agentTasks.list</code></li>
<li><code translate="no" dir="ltr">dataplex.agentTasks.run</code></li>
<li><code translate="no" dir="ltr">dataplex.agentTasks.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">dataplex.agentTasks.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">dataplex.datascans.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">dataplex.datascans.cancel</code></li>
<li><code translate="no" dir="ltr">dataplex.datascans.create</code></li>
<li><code translate="no" dir="ltr">dataplex.datascans.delete</code></li>
<li><code translate="no" dir="ltr">dataplex.datascans.get</code></li>
<li><code translate="no" dir="ltr">dataplex.datascans.getData</code></li>
<li><code translate="no" dir="ltr">dataplex.datascans.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">dataplex.datascans.list</code></li>
<li><code translate="no" dir="ltr">dataplex.datascans.run</code></li>
<li><code translate="no" dir="ltr">dataplex.datascans.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">dataplex.datascans.update</code></li>
</ul>
<p><code translate="no" dir="ltr">dataplex.operations.get</code></p>
<p><code translate="no" dir="ltr">dataplex.operations.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="bigquery.dataViewer" class="role-title add-link" data-text="BigQuery Data Viewer " tabindex="-1">BigQuery Data Viewer</h4>
<p>(<code translate="no" dir="ltr">roles/bigquery.dataViewer</code>)</p>
<span class="role-description custom"> </span>
<p>When granted on a dataset, this role grants these permissions:</p>
<ul>
<li>Get metadata and permissions for the dataset.</li>
<li>List a dataset's tables, views, and models.</li>
<li>Get metadata and access controls for the dataset's tables and views.</li>
<li>Get (query), replicate, and export table data and create snapshots.</li>
<li>List and invoke the dataset's routines.</li>
</ul>
<p>When granted on a table or view, this role provides these permissions:</p>
<ul>
<li>Get metadata and access controls for the table or view.</li>
<li>Get (query), export, and replicate table data.</li>
<li>Create snapshots.</li>
</ul>
<p>When granted on a routine, this role grants these permissions:</p>
<ul>
<li>In a query, reference a routine created by someone else.</li>
</ul>
<p>This role cannot be granted to individual models.</p>
<strong>Note:</strong> The BigQuery Data Viewer role is mapped to the <a href="/bigquery/docs/access-control-basic-roles#dataset-basic-roles"><code translate="no" dir="ltr">READER</code></a> BigQuery basic role. When you grant the BigQuery Data Viewer role to a principal at the dataset level, the principal is granted <code translate="no" dir="ltr">READER</code> access to the dataset.
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Dataset</li>
<li>These resources within a dataset:</li>
<li><ul>
<li>Table</li>
<li>View</li>
<li>Routine</li>
</ul></li>
</ul>
<p>This role can also be granted on Resource Manager resources (projects, folders, and organizations).</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">bigquery.datasets.get</code></p>
<p><code translate="no" dir="ltr">bigquery.datasets.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigquery.models.export</code></p>
<p><code translate="no" dir="ltr">bigquery.models.getData</code></p>
<p><code translate="no" dir="ltr">bigquery.models.getMetadata</code></p>
<p><code translate="no" dir="ltr">bigquery.models.list</code></p>
<p><code translate="no" dir="ltr">bigquery.propertyGraphs.get</code></p>
<p><code translate="no" dir="ltr">bigquery.propertyGraphs.list</code></p>
<p><code translate="no" dir="ltr">bigquery.routines.get</code></p>
<p><code translate="no" dir="ltr">bigquery.routines.list</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.createSnapshot</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.export</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.get</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.getData</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.list</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.replicateData</code></p>
<p><code translate="no" dir="ltr">dataplex.agentTasks.get</code></p>
<p><code translate="no" dir="ltr">dataplex.agentTasks.getData</code></p>
<p><code translate="no" dir="ltr">dataplex.agentTasks.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.agentTasks.list</code></p>
<p><code translate="no" dir="ltr">dataplex.datascans.get</code></p>
<p><code translate="no" dir="ltr">dataplex.datascans.getData</code></p>
<p><code translate="no" dir="ltr">dataplex.datascans.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.datascans.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="bigquery.jobUser" class="role-title add-link" data-text="BigQuery Job User " tabindex="-1">BigQuery Job User</h4>
<p>(<code translate="no" dir="ltr">roles/bigquery.jobUser</code>)</p>
<span class="role-description custom"> </span>
<p>Provides permissions to run jobs, including queries, within the project.</p>
<p>This role can only be granted on Resource Manager resources (projects, folders, and organizations).</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">bigquery.config.get</code></p>
<p><code translate="no" dir="ltr">bigquery.jobs.create</code></p>
<p><code translate="no" dir="ltr">cloudaicompanion.topics.create</code></p>
<p><code translate="no" dir="ltr">dataform.folders.create</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">dataform.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">dataform.locations.get</code></li>
<li><code translate="no" dir="ltr">dataform.locations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">dataform.repositories.create</code></p>
<p><code translate="no" dir="ltr">dataform.repositories.list</code></p>
<p><code translate="no" dir="ltr">geminidataanalytics.locations.chat</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="bigquery.metadataViewer" class="role-title add-link" data-text="BigQuery Metadata Viewer " tabindex="-1">BigQuery Metadata Viewer</h4>
<p>(<code translate="no" dir="ltr">roles/bigquery.metadataViewer</code>)</p>
<span class="role-description custom"> </span>
<p>When granted on a dataset, this role grants these permissions:</p>
<ul>
<li>Get metadata and access controls for the dataset.</li>
<li>Get metadata and access controls for tables and views.</li>
<li>Get metadata from the dataset's models and routines.</li>
<li>List tables, views, models, and routines in the dataset.</li>
</ul>
<p>When granted on a table or view, this role provides these permissions:</p>
<ul>
<li>Get metadata and access controls for the table or view.</li>
</ul>
<p>When granted on a routine, this role grants these permissions:</p>
<ul>
<li>In a query, reference a routine created by someone else.</li>
</ul>
<p>This role cannot be granted to individual models.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Dataset</li>
<li>These resources within a dataset:</li>
<li><ul>
<li>Table</li>
<li>View</li>
<li>Routine</li>
</ul></li>
</ul>
<p>This role can also be granted on Resource Manager resources (projects, folders, and organizations).</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">bigquery.datasets.get</code></p>
<p><code translate="no" dir="ltr">bigquery.datasets.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigquery.models.getMetadata</code></p>
<p><code translate="no" dir="ltr">bigquery.models.list</code></p>
<p><code translate="no" dir="ltr">bigquery.propertyGraphs.get</code></p>
<p><code translate="no" dir="ltr">bigquery.propertyGraphs.list</code></p>
<p><code translate="no" dir="ltr">bigquery.routines.get</code></p>
<p><code translate="no" dir="ltr">bigquery.routines.list</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.get</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.list</code></p>
<p><code translate="no" dir="ltr">dataplex.projects.search</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="bigquery.readSessionUser" class="role-title add-link" data-text="BigQuery Read Session User " tabindex="-1">BigQuery Read Session User</h4>
<p>(<code translate="no" dir="ltr">roles/bigquery.readSessionUser</code>)</p>
<span class="role-description custom"> </span>
<p>Provides the ability to create and use read sessions.</p>
<p>This role can only be granted on Resource Manager resources (projects, folders, and organizations).</p></td>
<td class="role-permissions"><p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.readsessions.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.readsessions.create</code></li>
<li><code translate="no" dir="ltr">bigquery.readsessions.getData</code></li>
<li><code translate="no" dir="ltr">bigquery.readsessions.update</code></li>
</ul>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="bigquery.resourceAdmin" class="role-title add-link" data-text="BigQuery Resource Admin " tabindex="-1">BigQuery Resource Admin</h4>
<p>(<code translate="no" dir="ltr">roles/bigquery.resourceAdmin</code>)</p>
<span class="role-description custom"> </span>
<p>Administers BigQuery workloads, including slot assignments, commitments, and reservations.</p>
<p>This role can only be granted on Resource Manager resources (projects, folders, and organizations).</p></td>
<td class="role-permissions"><p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.bireservations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.bireservations.get</code></li>
<li><code translate="no" dir="ltr">bigquery.bireservations.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.capacityCommitments.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.capacityCommitments.create</code></li>
<li><code translate="no" dir="ltr">bigquery.capacityCommitments.delete</code></li>
<li><code translate="no" dir="ltr">bigquery.capacityCommitments.get</code></li>
<li><code translate="no" dir="ltr">bigquery.capacityCommitments.list</code></li>
<li><code translate="no" dir="ltr">bigquery.capacityCommitments.update</code></li>
</ul>
<p><code translate="no" dir="ltr">bigquery.jobs.get</code></p>
<p><code translate="no" dir="ltr">bigquery.jobs.list</code></p>
<p><code translate="no" dir="ltr">bigquery.jobs.listAll</code></p>
<p><code translate="no" dir="ltr">bigquery.jobs.listExecutionMetadata</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.reservationAssignments.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.reservationAssignments.create</code></li>
<li><code translate="no" dir="ltr">bigquery.reservationAssignments.delete</code></li>
<li><code translate="no" dir="ltr">bigquery.reservationAssignments.list</code></li>
<li><code translate="no" dir="ltr">bigquery.reservationAssignments.search</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.reservationGroups.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.reservationGroups.create</code></li>
<li><code translate="no" dir="ltr">bigquery.reservationGroups.delete</code></li>
<li><code translate="no" dir="ltr">bigquery.reservationGroups.get</code></li>
<li><code translate="no" dir="ltr">bigquery.reservationGroups.list</code></li>
<li><code translate="no" dir="ltr">bigquery.reservationGroups.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.reservations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.reservations.create</code></li>
<li><code translate="no" dir="ltr">bigquery.reservations.delete</code></li>
<li><code translate="no" dir="ltr">bigquery.reservations.get</code></li>
<li><code translate="no" dir="ltr">bigquery.reservations.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">bigquery.reservations.list</code></li>
<li><code translate="no" dir="ltr">bigquery.reservations.listFailoverDatasets</code></li>
<li><code translate="no" dir="ltr">bigquery.reservations.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">bigquery.reservations.update</code></li>
<li><code translate="no" dir="ltr">bigquery.reservations.use</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.bigqueryCapacityCommitmentsInsights.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.bigqueryCapacityCommitmentsInsights.get</code></li>
<li><code translate="no" dir="ltr">recommender.bigqueryCapacityCommitmentsInsights.list</code></li>
<li><code translate="no" dir="ltr">recommender.bigqueryCapacityCommitmentsInsights.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.bigqueryCapacityCommitmentsRecommendations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.bigqueryCapacityCommitmentsRecommendations.get</code></li>
<li><code translate="no" dir="ltr">recommender.bigqueryCapacityCommitmentsRecommendations.list</code></li>
<li><code translate="no" dir="ltr">recommender.bigqueryCapacityCommitmentsRecommendations.update</code></li>
</ul>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="bigquery.resourceEditor" class="role-title add-link" data-text="BigQuery Resource Editor " tabindex="-1">BigQuery Resource Editor</h4>
<p>(<code translate="no" dir="ltr">roles/bigquery.resourceEditor</code>)</p>
<span class="role-description custom"> </span>
<p>Manages BigQuery workloads, but is unable to create or modify slot commitments.</p>
<p>This role can only be granted on Resource Manager resources (projects, folders, and organizations).</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">bigquery.bireservations.get</code></p>
<p><code translate="no" dir="ltr">bigquery.capacityCommitments.get</code></p>
<p><code translate="no" dir="ltr">bigquery.capacityCommitments.list</code></p>
<p><code translate="no" dir="ltr">bigquery.jobs.get</code></p>
<p><code translate="no" dir="ltr">bigquery.jobs.list</code></p>
<p><code translate="no" dir="ltr">bigquery.jobs.listAll</code></p>
<p><code translate="no" dir="ltr">bigquery.jobs.listExecutionMetadata</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.reservationAssignments.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.reservationAssignments.create</code></li>
<li><code translate="no" dir="ltr">bigquery.reservationAssignments.delete</code></li>
<li><code translate="no" dir="ltr">bigquery.reservationAssignments.list</code></li>
<li><code translate="no" dir="ltr">bigquery.reservationAssignments.search</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.reservationGroups.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.reservationGroups.create</code></li>
<li><code translate="no" dir="ltr">bigquery.reservationGroups.delete</code></li>
<li><code translate="no" dir="ltr">bigquery.reservationGroups.get</code></li>
<li><code translate="no" dir="ltr">bigquery.reservationGroups.list</code></li>
<li><code translate="no" dir="ltr">bigquery.reservationGroups.update</code></li>
</ul>
<p><code translate="no" dir="ltr">bigquery.reservations.create</code></p>
<p><code translate="no" dir="ltr">bigquery.reservations.delete</code></p>
<p><code translate="no" dir="ltr">bigquery.reservations.get</code></p>
<p><code translate="no" dir="ltr">bigquery.reservations.list</code></p>
<p><code translate="no" dir="ltr">bigquery.reservations.listFailoverDatasets</code></p>
<p><code translate="no" dir="ltr">bigquery.reservations.update</code></p>
<p><code translate="no" dir="ltr">bigquery.reservations.use</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="bigquery.resourceViewer" class="role-title add-link" data-text="BigQuery Resource Viewer " tabindex="-1">BigQuery Resource Viewer</h4>
<p>(<code translate="no" dir="ltr">roles/bigquery.resourceViewer</code>)</p>
<span class="role-description custom"> </span>
<p>Can view BigQuery workloads, but cannot create or modify slot reservations or commitments.</p>
<p>This role can only be granted on Resource Manager resources (projects, folders, and organizations).</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">bigquery.bireservations.get</code></p>
<p><code translate="no" dir="ltr">bigquery.capacityCommitments.get</code></p>
<p><code translate="no" dir="ltr">bigquery.capacityCommitments.list</code></p>
<p><code translate="no" dir="ltr">bigquery.jobs.get</code></p>
<p><code translate="no" dir="ltr">bigquery.jobs.list</code></p>
<p><code translate="no" dir="ltr">bigquery.jobs.listAll</code></p>
<p><code translate="no" dir="ltr">bigquery.jobs.listExecutionMetadata</code></p>
<p><code translate="no" dir="ltr">bigquery.reservationAssignments.list</code></p>
<p><code translate="no" dir="ltr">bigquery.reservationAssignments.search</code></p>
<p><code translate="no" dir="ltr">bigquery.reservationGroups.get</code></p>
<p><code translate="no" dir="ltr">bigquery.reservationGroups.list</code></p>
<p><code translate="no" dir="ltr">bigquery.reservations.get</code></p>
<p><code translate="no" dir="ltr">bigquery.reservations.list</code></p>
<p><code translate="no" dir="ltr">bigquery.reservations.listFailoverDatasets</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="bigquery.studioAdmin" class="role-title add-link" data-text="BigQuery Studio Admin " tabindex="-1">BigQuery Studio Admin</h4>
<p>(<code translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<span class="role-description custom"> </span>
<p>Combination role of BigQuery Admin, Dataform Admin, Notebook Runtime Admin and Dataproc Serverless Editor.</p>
<p>It is possible to grant this role to the following lowest-level resources, but it is not recommended. Other predefined roles grant full permissions over these resources and are less permissive. BigQuery Studio Admin is typically granted at the project level.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Dataset</li>
<li>These resources within a dataset:</li>
<li><ul>
<li>Table</li>
<li>View</li>
<li>Routine</li>
</ul></li>
<li>Connection</li>
<li>Saved query</li>
<li>Data canvas</li>
<li>Data preparation</li>
<li>Pipeline</li>
<li>Repository</li>
</ul>
<p>This role can also be granted on Resource Manager resources (projects, folders, and organizations).</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">aiplatform.locations.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">aiplatform.notebookRuntimeTemplates.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">aiplatform.notebookRuntimeTemplates.apply</code></li>
<li><code translate="no" dir="ltr">aiplatform.notebookRuntimeTemplates.create</code></li>
<li><code translate="no" dir="ltr">aiplatform.notebookRuntimeTemplates.delete</code></li>
<li><code translate="no" dir="ltr">aiplatform.notebookRuntimeTemplates.get</code></li>
<li><code translate="no" dir="ltr">aiplatform.notebookRuntimeTemplates.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">aiplatform.notebookRuntimeTemplates.list</code></li>
<li><code translate="no" dir="ltr">aiplatform.notebookRuntimeTemplates.setDefault</code></li>
<li><code translate="no" dir="ltr">aiplatform.notebookRuntimeTemplates.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">aiplatform.notebookRuntimeTemplates.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">aiplatform.notebookRuntimes.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">aiplatform.notebookRuntimes.assign</code></li>
<li><code translate="no" dir="ltr">aiplatform.notebookRuntimes.delete</code></li>
<li><code translate="no" dir="ltr">aiplatform.notebookRuntimes.get</code></li>
<li><code translate="no" dir="ltr">aiplatform.notebookRuntimes.list</code></li>
<li><code translate="no" dir="ltr">aiplatform.notebookRuntimes.start</code></li>
<li><code translate="no" dir="ltr">aiplatform.notebookRuntimes.update</code></li>
<li><code translate="no" dir="ltr">aiplatform.notebookRuntimes.upgrade</code></li>
</ul>
<p><code translate="no" dir="ltr">aiplatform.operations.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.bireservations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.bireservations.get</code></li>
<li><code translate="no" dir="ltr">bigquery.bireservations.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.capacityCommitments.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.capacityCommitments.create</code></li>
<li><code translate="no" dir="ltr">bigquery.capacityCommitments.delete</code></li>
<li><code translate="no" dir="ltr">bigquery.capacityCommitments.get</code></li>
<li><code translate="no" dir="ltr">bigquery.capacityCommitments.list</code></li>
<li><code translate="no" dir="ltr">bigquery.capacityCommitments.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.config.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.config.get</code></li>
<li><code translate="no" dir="ltr">bigquery.config.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.connections.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.connections.create</code></li>
<li><code translate="no" dir="ltr">bigquery.connections.delegate</code></li>
<li><code translate="no" dir="ltr">bigquery.connections.delete</code></li>
<li><code translate="no" dir="ltr">bigquery.connections.get</code></li>
<li><code translate="no" dir="ltr">bigquery.connections.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">bigquery.connections.list</code></li>
<li><code translate="no" dir="ltr">bigquery.connections.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">bigquery.connections.update</code></li>
<li><code translate="no" dir="ltr">bigquery.connections.updateTag</code></li>
<li><code translate="no" dir="ltr">bigquery.connections.use</code></li>
</ul>
<p><code translate="no" dir="ltr">bigquery.dataPolicies.attach</code></p>
<p><code translate="no" dir="ltr">bigquery.dataPolicies.create</code></p>
<p><code translate="no" dir="ltr">bigquery.dataPolicies.delete</code></p>
<p><code translate="no" dir="ltr">bigquery.dataPolicies.get</code></p>
<p><code translate="no" dir="ltr">bigquery.dataPolicies.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigquery.dataPolicies.list</code></p>
<p><code translate="no" dir="ltr">bigquery.dataPolicies.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigquery.dataPolicies.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.datasets.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.datasets.create</code></li>
<li><code translate="no" dir="ltr">bigquery.datasets.createTagBinding</code></li>
<li><code translate="no" dir="ltr">bigquery.datasets.delete</code></li>
<li><code translate="no" dir="ltr">bigquery.datasets.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">bigquery.datasets.get</code></li>
<li><code translate="no" dir="ltr">bigquery.datasets.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">bigquery.datasets.link</code></li>
<li><code translate="no" dir="ltr">bigquery.datasets.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">bigquery.datasets.listSharedDatasetUsage</code></li>
<li><code translate="no" dir="ltr">bigquery.datasets.listTagBindings</code></li>
<li><code translate="no" dir="ltr">bigquery.datasets.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">bigquery.datasets.update</code></li>
<li><code translate="no" dir="ltr">bigquery.datasets.updateTag</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.jobs.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.jobs.create</code></li>
<li><code translate="no" dir="ltr">bigquery.jobs.createGlobalQuery</code></li>
<li><code translate="no" dir="ltr">bigquery.jobs.delete</code></li>
<li><code translate="no" dir="ltr">bigquery.jobs.get</code></li>
<li><code translate="no" dir="ltr">bigquery.jobs.list</code></li>
<li><code translate="no" dir="ltr">bigquery.jobs.listAll</code></li>
<li><code translate="no" dir="ltr">bigquery.jobs.listExecutionMetadata</code></li>
<li><code translate="no" dir="ltr">bigquery.jobs.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.models.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.models.create</code></li>
<li><code translate="no" dir="ltr">bigquery.models.delete</code></li>
<li><code translate="no" dir="ltr">bigquery.models.export</code></li>
<li><code translate="no" dir="ltr">bigquery.models.getData</code></li>
<li><code translate="no" dir="ltr">bigquery.models.getMetadata</code></li>
<li><code translate="no" dir="ltr">bigquery.models.list</code></li>
<li><code translate="no" dir="ltr">bigquery.models.updateData</code></li>
<li><code translate="no" dir="ltr">bigquery.models.updateMetadata</code></li>
<li><code translate="no" dir="ltr">bigquery.models.updateTag</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.objectRefs.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.objectRefs.read</code></li>
<li><code translate="no" dir="ltr">bigquery.objectRefs.write</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.propertyGraphs.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.propertyGraphs.create</code></li>
<li><code translate="no" dir="ltr">bigquery.propertyGraphs.delete</code></li>
<li><code translate="no" dir="ltr">bigquery.propertyGraphs.get</code></li>
<li><code translate="no" dir="ltr">bigquery.propertyGraphs.list</code></li>
<li><code translate="no" dir="ltr">bigquery.propertyGraphs.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.readsessions.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.readsessions.create</code></li>
<li><code translate="no" dir="ltr">bigquery.readsessions.getData</code></li>
<li><code translate="no" dir="ltr">bigquery.readsessions.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.reservationAssignments.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.reservationAssignments.create</code></li>
<li><code translate="no" dir="ltr">bigquery.reservationAssignments.delete</code></li>
<li><code translate="no" dir="ltr">bigquery.reservationAssignments.list</code></li>
<li><code translate="no" dir="ltr">bigquery.reservationAssignments.search</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.reservationGroups.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.reservationGroups.create</code></li>
<li><code translate="no" dir="ltr">bigquery.reservationGroups.delete</code></li>
<li><code translate="no" dir="ltr">bigquery.reservationGroups.get</code></li>
<li><code translate="no" dir="ltr">bigquery.reservationGroups.list</code></li>
<li><code translate="no" dir="ltr">bigquery.reservationGroups.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.reservations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.reservations.create</code></li>
<li><code translate="no" dir="ltr">bigquery.reservations.delete</code></li>
<li><code translate="no" dir="ltr">bigquery.reservations.get</code></li>
<li><code translate="no" dir="ltr">bigquery.reservations.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">bigquery.reservations.list</code></li>
<li><code translate="no" dir="ltr">bigquery.reservations.listFailoverDatasets</code></li>
<li><code translate="no" dir="ltr">bigquery.reservations.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">bigquery.reservations.update</code></li>
<li><code translate="no" dir="ltr">bigquery.reservations.use</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.routines.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.routines.create</code></li>
<li><code translate="no" dir="ltr">bigquery.routines.delete</code></li>
<li><code translate="no" dir="ltr">bigquery.routines.get</code></li>
<li><code translate="no" dir="ltr">bigquery.routines.list</code></li>
<li><code translate="no" dir="ltr">bigquery.routines.update</code></li>
<li><code translate="no" dir="ltr">bigquery.routines.updateTag</code></li>
</ul>
<p><code translate="no" dir="ltr">bigquery.rowAccessPolicies.create</code></p>
<p><code translate="no" dir="ltr">bigquery.rowAccessPolicies.delete</code></p>
<p><code translate="no" dir="ltr">bigquery.rowAccessPolicies.get</code></p>
<p><code translate="no" dir="ltr">bigquery.rowAccessPolicies.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigquery.rowAccessPolicies.list</code></p>
<p><code translate="no" dir="ltr">bigquery.rowAccessPolicies.overrideTimeTravelRestrictions</code></p>
<p><code translate="no" dir="ltr">bigquery.rowAccessPolicies.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigquery.rowAccessPolicies.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.savedqueries.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.savedqueries.create</code></li>
<li><code translate="no" dir="ltr">bigquery.savedqueries.delete</code></li>
<li><code translate="no" dir="ltr">bigquery.savedqueries.get</code></li>
<li><code translate="no" dir="ltr">bigquery.savedqueries.list</code></li>
<li><code translate="no" dir="ltr">bigquery.savedqueries.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.tables.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.tables.create</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.createIndex</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.createSnapshot</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.createTagBinding</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.delete</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.deleteIndex</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.deleteSnapshot</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.export</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.get</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.getData</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.list</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.listTagBindings</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.replicateData</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.restoreSnapshot</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.setCategory</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.setColumnDataPolicy</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.update</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.updateData</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.updateIndex</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.updateTag</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.transfers.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.transfers.get</code></li>
<li><code translate="no" dir="ltr">bigquery.transfers.update</code></li>
</ul>
<p><code translate="no" dir="ltr">bigquerymigration.translation.translate</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudaicompanion.aiDevToolsSettings.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudaicompanion.aiDevToolsSettings.create</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.aiDevToolsSettings.delete</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.aiDevToolsSettings.get</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.aiDevToolsSettings.list</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.aiDevToolsSettings.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudaicompanion.codeToolsSettings.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudaicompanion.codeToolsSettings.create</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.codeToolsSettings.delete</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.codeToolsSettings.get</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.codeToolsSettings.list</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.codeToolsSettings.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudaicompanion.companions.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudaicompanion.companions.generateChat</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.companions.generateCode</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudaicompanion.dataSharingWithGoogleSettings.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudaicompanion.dataSharingWithGoogleSettings.create</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.dataSharingWithGoogleSettings.delete</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.dataSharingWithGoogleSettings.get</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.dataSharingWithGoogleSettings.list</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.dataSharingWithGoogleSettings.update</code></li>
</ul>
<p><code translate="no" dir="ltr">cloudaicompanion.entitlements.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudaicompanion.geminiGcpEnablementSettings.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudaicompanion.geminiGcpEnablementSettings.create</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.geminiGcpEnablementSettings.delete</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.geminiGcpEnablementSettings.get</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.geminiGcpEnablementSettings.list</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.geminiGcpEnablementSettings.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudaicompanion.gibqObservabilitySettings.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudaicompanion.gibqObservabilitySettings.create</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.gibqObservabilitySettings.delete</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.gibqObservabilitySettings.get</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.gibqObservabilitySettings.list</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.gibqObservabilitySettings.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudaicompanion.instances.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudaicompanion.instances.completeCode</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.instances.completeTask</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.instances.exportMetrics</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.instances.generateCode</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.instances.generateText</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.instances.queryEffectiveSetting</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.instances.queryEffectiveSettingBindings</code></li>
</ul>
<p><code translate="no" dir="ltr">cloudaicompanion.licenses.selfAssign</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudaicompanion.loggingSettings.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudaicompanion.loggingSettings.create</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.loggingSettings.delete</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.loggingSettings.get</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.loggingSettings.list</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.loggingSettings.update</code></li>
</ul>
<p><code translate="no" dir="ltr">cloudaicompanion.operations.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudaicompanion.releaseChannelSettings.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudaicompanion.releaseChannelSettings.create</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.releaseChannelSettings.delete</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.releaseChannelSettings.get</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.releaseChannelSettings.list</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.releaseChannelSettings.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudaicompanion.settingBindings.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudaicompanion.settingBindings.aiDevToolsSettingsCreate</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.settingBindings.aiDevToolsSettingsDelete</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.settingBindings.aiDevToolsSettingsGet</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.settingBindings.aiDevToolsSettingsList</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.settingBindings.aiDevToolsSettingsUpdate</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.settingBindings.aiDevToolsSettingsUse</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.settingBindings.codeToolsSettingsCreate</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.settingBindings.codeToolsSettingsDelete</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.settingBindings.codeToolsSettingsGet</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.settingBindings.codeToolsSettingsList</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.settingBindings.codeToolsSettingsUpdate</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.settingBindings.codeToolsSettingsUse</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.settingBindings.dataSharingWithGoogleSettingsCreate</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.settingBindings.dataSharingWithGoogleSettingsDelete</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.settingBindings.dataSharingWithGoogleSettingsGet</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.settingBindings.dataSharingWithGoogleSettingsList</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.settingBindings.dataSharingWithGoogleSettingsUpdate</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.settingBindings.dataSharingWithGoogleSettingsUse</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.settingBindings.geminiGcpEnablementSettingsCreate</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.settingBindings.geminiGcpEnablementSettingsDelete</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.settingBindings.geminiGcpEnablementSettingsGet</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.settingBindings.geminiGcpEnablementSettingsList</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.settingBindings.geminiGcpEnablementSettingsUpdate</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.settingBindings.geminiGcpEnablementSettingsUse</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.settingBindings.gibqObservabilitySettingsCreate</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.settingBindings.gibqObservabilitySettingsDelete</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.settingBindings.gibqObservabilitySettingsGet</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.settingBindings.gibqObservabilitySettingsList</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.settingBindings.gibqObservabilitySettingsUpdate</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.settingBindings.gibqObservabilitySettingsUse</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.settingBindings.loggingSettingsCreate</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.settingBindings.loggingSettingsDelete</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.settingBindings.loggingSettingsGet</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.settingBindings.loggingSettingsList</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.settingBindings.loggingSettingsUpdate</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.settingBindings.loggingSettingsUse</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.settingBindings.releaseChannelSettingsCreate</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.settingBindings.releaseChannelSettingsDelete</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.settingBindings.releaseChannelSettingsGet</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.settingBindings.releaseChannelSettingsList</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.settingBindings.releaseChannelSettingsUpdate</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.settingBindings.releaseChannelSettingsUse</code></li>
</ul>
<p><code translate="no" dir="ltr">cloudaicompanion.topics.create</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudkms.keyHandles.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudkms.keyHandles.create</code></li>
<li><code translate="no" dir="ltr">cloudkms.keyHandles.get</code></li>
<li><code translate="no" dir="ltr">cloudkms.keyHandles.list</code></li>
</ul>
<p><code translate="no" dir="ltr">cloudkms.operations.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.projects.showEffectiveAutokeyConfig</code></p>
<p><code translate="no" dir="ltr">compute.projects.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.regions.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.regions.get</code></li>
<li><code translate="no" dir="ltr">compute.regions.list</code></li>
</ul>
<p><code translate="no" dir="ltr">compute.reservations.get</code></p>
<p><code translate="no" dir="ltr">compute.reservations.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.zones.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.zones.get</code></li>
<li><code translate="no" dir="ltr">compute.zones.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">dataform.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">dataform.commentThreads.create</code></li>
<li><code translate="no" dir="ltr">dataform.commentThreads.delete</code></li>
<li><code translate="no" dir="ltr">dataform.commentThreads.get</code></li>
<li><code translate="no" dir="ltr">dataform.commentThreads.list</code></li>
<li><code translate="no" dir="ltr">dataform.commentThreads.update</code></li>
<li><code translate="no" dir="ltr">dataform.comments.create</code></li>
<li><code translate="no" dir="ltr">dataform.comments.delete</code></li>
<li><code translate="no" dir="ltr">dataform.comments.get</code></li>
<li><code translate="no" dir="ltr">dataform.comments.list</code></li>
<li><code translate="no" dir="ltr">dataform.comments.update</code></li>
<li><code translate="no" dir="ltr">dataform.compilationResults.create</code></li>
<li><code translate="no" dir="ltr">dataform.compilationResults.get</code></li>
<li><code translate="no" dir="ltr">dataform.compilationResults.list</code></li>
<li><code translate="no" dir="ltr">dataform.compilationResults.query</code></li>
<li><code translate="no" dir="ltr">dataform.config.get</code></li>
<li><code translate="no" dir="ltr">dataform.config.update</code></li>
<li><code translate="no" dir="ltr">dataform.folders.addContents</code></li>
<li><code translate="no" dir="ltr">dataform.folders.create</code></li>
<li><code translate="no" dir="ltr">dataform.folders.delete</code></li>
<li><code translate="no" dir="ltr">dataform.folders.deleteTree</code></li>
<li><code translate="no" dir="ltr">dataform.folders.get</code></li>
<li><code translate="no" dir="ltr">dataform.folders.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">dataform.folders.move</code></li>
<li><code translate="no" dir="ltr">dataform.folders.queryContents</code></li>
<li><code translate="no" dir="ltr">dataform.folders.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">dataform.folders.update</code></li>
<li><code translate="no" dir="ltr">dataform.locations.get</code></li>
<li><code translate="no" dir="ltr">dataform.locations.list</code></li>
<li><code translate="no" dir="ltr">dataform.operations.cancel</code></li>
<li><code translate="no" dir="ltr">dataform.operations.delete</code></li>
<li><code translate="no" dir="ltr">dataform.operations.get</code></li>
<li><code translate="no" dir="ltr">dataform.operations.list</code></li>
<li><code translate="no" dir="ltr">dataform.releaseConfigs.create</code></li>
<li><code translate="no" dir="ltr">dataform.releaseConfigs.delete</code></li>
<li><code translate="no" dir="ltr">dataform.releaseConfigs.get</code></li>
<li><code translate="no" dir="ltr">dataform.releaseConfigs.list</code></li>
<li><code translate="no" dir="ltr">dataform.releaseConfigs.update</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.commit</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.computeAccessTokenStatus</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.create</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.createTagBinding</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.delete</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.fetchHistory</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.fetchRemoteBranches</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.get</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.list</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.listTagBindings</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.move</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.queryDirectoryContents</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.readFile</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.scheduleRelease</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.scheduleWorkflow</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.update</code></li>
<li><code translate="no" dir="ltr">dataform.teamFolders.create</code></li>
<li><code translate="no" dir="ltr">dataform.teamFolders.delete</code></li>
<li><code translate="no" dir="ltr">dataform.teamFolders.deleteTree</code></li>
<li><code translate="no" dir="ltr">dataform.teamFolders.get</code></li>
<li><code translate="no" dir="ltr">dataform.teamFolders.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">dataform.teamFolders.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">dataform.teamFolders.update</code></li>
<li><code translate="no" dir="ltr">dataform.workflowConfigs.create</code></li>
<li><code translate="no" dir="ltr">dataform.workflowConfigs.delete</code></li>
<li><code translate="no" dir="ltr">dataform.workflowConfigs.get</code></li>
<li><code translate="no" dir="ltr">dataform.workflowConfigs.list</code></li>
<li><code translate="no" dir="ltr">dataform.workflowConfigs.update</code></li>
<li><code translate="no" dir="ltr">dataform.workflowInvocations.cancel</code></li>
<li><code translate="no" dir="ltr">dataform.workflowInvocations.create</code></li>
<li><code translate="no" dir="ltr">dataform.workflowInvocations.delete</code></li>
<li><code translate="no" dir="ltr">dataform.workflowInvocations.get</code></li>
<li><code translate="no" dir="ltr">dataform.workflowInvocations.list</code></li>
<li><code translate="no" dir="ltr">dataform.workflowInvocations.query</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.commit</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.create</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.delete</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.fetchFileDiff</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.fetchFileGitStatuses</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.fetchGitAheadBehind</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.get</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.installNpmPackages</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.list</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.makeDirectory</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.moveDirectory</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.moveFile</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.pull</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.push</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.queryDirectoryContents</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.readFile</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.removeDirectory</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.removeFile</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.reset</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.searchFiles</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.writeFile</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">dataplex.agentTasks.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">dataplex.agentTasks.create</code></li>
<li><code translate="no" dir="ltr">dataplex.agentTasks.delete</code></li>
<li><code translate="no" dir="ltr">dataplex.agentTasks.get</code></li>
<li><code translate="no" dir="ltr">dataplex.agentTasks.getData</code></li>
<li><code translate="no" dir="ltr">dataplex.agentTasks.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">dataplex.agentTasks.list</code></li>
<li><code translate="no" dir="ltr">dataplex.agentTasks.run</code></li>
<li><code translate="no" dir="ltr">dataplex.agentTasks.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">dataplex.agentTasks.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">dataplex.datascans.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">dataplex.datascans.cancel</code></li>
<li><code translate="no" dir="ltr">dataplex.datascans.create</code></li>
<li><code translate="no" dir="ltr">dataplex.datascans.delete</code></li>
<li><code translate="no" dir="ltr">dataplex.datascans.get</code></li>
<li><code translate="no" dir="ltr">dataplex.datascans.getData</code></li>
<li><code translate="no" dir="ltr">dataplex.datascans.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">dataplex.datascans.list</code></li>
<li><code translate="no" dir="ltr">dataplex.datascans.run</code></li>
<li><code translate="no" dir="ltr">dataplex.datascans.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">dataplex.datascans.update</code></li>
</ul>
<p><code translate="no" dir="ltr">dataplex.operations.get</code></p>
<p><code translate="no" dir="ltr">dataplex.operations.list</code></p>
<p><code translate="no" dir="ltr">dataplex.projects.search</code></p>
<p><code translate="no" dir="ltr">dataproc.batches.analyze</code></p>
<p><code translate="no" dir="ltr">dataproc.batches.cancel</code></p>
<p><code translate="no" dir="ltr">dataproc.batches.create</code></p>
<p><code translate="no" dir="ltr">dataproc.batches.delete</code></p>
<p><code translate="no" dir="ltr">dataproc.batches.get</code></p>
<p><code translate="no" dir="ltr">dataproc.batches.list</code></p>
<p><code translate="no" dir="ltr">dataproc.batches.sparkApplicationRead</code></p>
<p><code translate="no" dir="ltr">dataproc.batches.sparkApplicationWrite</code></p>
<p><code translate="no" dir="ltr">dataproc.operations.cancel</code></p>
<p><code translate="no" dir="ltr">dataproc.operations.delete</code></p>
<p><code translate="no" dir="ltr">dataproc.operations.get</code></p>
<p><code translate="no" dir="ltr">dataproc.operations.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">dataproc.sessionTemplates.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">dataproc.sessionTemplates.create</code></li>
<li><code translate="no" dir="ltr">dataproc.sessionTemplates.delete</code></li>
<li><code translate="no" dir="ltr">dataproc.sessionTemplates.get</code></li>
<li><code translate="no" dir="ltr">dataproc.sessionTemplates.list</code></li>
<li><code translate="no" dir="ltr">dataproc.sessionTemplates.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">dataproc.sessions.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">dataproc.sessions.create</code></li>
<li><code translate="no" dir="ltr">dataproc.sessions.delete</code></li>
<li><code translate="no" dir="ltr">dataproc.sessions.get</code></li>
<li><code translate="no" dir="ltr">dataproc.sessions.list</code></li>
<li><code translate="no" dir="ltr">dataproc.sessions.sparkApplicationRead</code></li>
<li><code translate="no" dir="ltr">dataproc.sessions.sparkApplicationWrite</code></li>
<li><code translate="no" dir="ltr">dataproc.sessions.terminate</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">dataprocrm.nodePools.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">dataprocrm.nodePools.create</code></li>
<li><code translate="no" dir="ltr">dataprocrm.nodePools.delete</code></li>
<li><code translate="no" dir="ltr">dataprocrm.nodePools.deleteNodes</code></li>
<li><code translate="no" dir="ltr">dataprocrm.nodePools.get</code></li>
<li><code translate="no" dir="ltr">dataprocrm.nodePools.list</code></li>
<li><code translate="no" dir="ltr">dataprocrm.nodePools.resize</code></li>
</ul>
<p><code translate="no" dir="ltr">dataprocrm.nodes.get</code></p>
<p><code translate="no" dir="ltr">dataprocrm.nodes.heartbeat</code></p>
<p><code translate="no" dir="ltr">dataprocrm.nodes.list</code></p>
<p><code translate="no" dir="ltr">dataprocrm.nodes.update</code></p>
<p><code translate="no" dir="ltr">dataprocrm.operations.get</code></p>
<p><code translate="no" dir="ltr">dataprocrm.operations.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">dataprocrm.workloads.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">dataprocrm.workloads.cancel</code></li>
<li><code translate="no" dir="ltr">dataprocrm.workloads.create</code></li>
<li><code translate="no" dir="ltr">dataprocrm.workloads.delete</code></li>
<li><code translate="no" dir="ltr">dataprocrm.workloads.get</code></li>
<li><code translate="no" dir="ltr">dataprocrm.workloads.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">developerconnect.accountConnectors.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">developerconnect.accountConnectors.create</code></li>
<li><code translate="no" dir="ltr">developerconnect.accountConnectors.delete</code></li>
<li><code translate="no" dir="ltr">developerconnect.accountConnectors.fetchUserRepositories</code></li>
<li><code translate="no" dir="ltr">developerconnect.accountConnectors.get</code></li>
<li><code translate="no" dir="ltr">developerconnect.accountConnectors.gitProxyRead</code></li>
<li><code translate="no" dir="ltr">developerconnect.accountConnectors.gitProxyWrite</code></li>
<li><code translate="no" dir="ltr">developerconnect.accountConnectors.httpProxyRead</code></li>
<li><code translate="no" dir="ltr">developerconnect.accountConnectors.httpProxyWrite</code></li>
<li><code translate="no" dir="ltr">developerconnect.accountConnectors.list</code></li>
<li><code translate="no" dir="ltr">developerconnect.accountConnectors.update</code></li>
</ul>
<p><code translate="no" dir="ltr">developerconnect.connections.constructGitHubAppManifest</code></p>
<p><code translate="no" dir="ltr">developerconnect.connections.create</code></p>
<p><code translate="no" dir="ltr">developerconnect.connections.delete</code></p>
<p><code translate="no" dir="ltr">developerconnect.connections.fetchGitHubInstallations</code></p>
<p><code translate="no" dir="ltr">developerconnect.connections.fetchLinkableGitRepositories</code></p>
<p><code translate="no" dir="ltr">developerconnect.connections.generateGitHubStateToken</code></p>
<p><code translate="no" dir="ltr">developerconnect.connections.get</code></p>
<p><code translate="no" dir="ltr">developerconnect.connections.list</code></p>
<p><code translate="no" dir="ltr">developerconnect.connections.processGitHubAppCreationCallback</code></p>
<p><code translate="no" dir="ltr">developerconnect.connections.processGitHubOAuthCallback</code></p>
<p><code translate="no" dir="ltr">developerconnect.connections.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">developerconnect.gitRepositoryLinks.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">developerconnect.gitRepositoryLinks.create</code></li>
<li><code translate="no" dir="ltr">developerconnect.gitRepositoryLinks.delete</code></li>
<li><code translate="no" dir="ltr">developerconnect.gitRepositoryLinks.fetchGitRefs</code></li>
<li><code translate="no" dir="ltr">developerconnect.gitRepositoryLinks.fetchReadToken</code></li>
<li><code translate="no" dir="ltr">developerconnect.gitRepositoryLinks.fetchReadWriteToken</code></li>
<li><code translate="no" dir="ltr">developerconnect.gitRepositoryLinks.get</code></li>
<li><code translate="no" dir="ltr">developerconnect.gitRepositoryLinks.gitProxyRead</code></li>
<li><code translate="no" dir="ltr">developerconnect.gitRepositoryLinks.gitProxyWrite</code></li>
<li><code translate="no" dir="ltr">developerconnect.gitRepositoryLinks.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">developerconnect.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">developerconnect.locations.get</code></li>
<li><code translate="no" dir="ltr">developerconnect.locations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">developerconnect.operations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">developerconnect.operations.cancel</code></li>
<li><code translate="no" dir="ltr">developerconnect.operations.delete</code></li>
<li><code translate="no" dir="ltr">developerconnect.operations.get</code></li>
<li><code translate="no" dir="ltr">developerconnect.operations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">developerconnect.providers.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">developerconnect.users.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">developerconnect.users.delete</code></li>
<li><code translate="no" dir="ltr">developerconnect.users.deleteSelf</code></li>
<li><code translate="no" dir="ltr">developerconnect.users.fetchAccessToken</code></li>
<li><code translate="no" dir="ltr">developerconnect.users.finishOAuth</code></li>
<li><code translate="no" dir="ltr">developerconnect.users.getSelf</code></li>
<li><code translate="no" dir="ltr">developerconnect.users.list</code></li>
<li><code translate="no" dir="ltr">developerconnect.users.startOAuth</code></li>
</ul>
<p><code translate="no" dir="ltr">geminicloudassist.agents.invoke</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">geminidataanalytics.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">geminidataanalytics.dataAgents.chat</code></li>
<li><code translate="no" dir="ltr">geminidataanalytics.dataAgents.create</code></li>
<li><code translate="no" dir="ltr">geminidataanalytics.dataAgents.delete</code></li>
<li><code translate="no" dir="ltr">geminidataanalytics.dataAgents.get</code></li>
<li><code translate="no" dir="ltr">geminidataanalytics.dataAgents.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">geminidataanalytics.dataAgents.list</code></li>
<li><code translate="no" dir="ltr">geminidataanalytics.dataAgents.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">geminidataanalytics.dataAgents.update</code></li>
<li><code translate="no" dir="ltr">geminidataanalytics.locations.chat</code></li>
<li><code translate="no" dir="ltr">geminidataanalytics.locations.get</code></li>
<li><code translate="no" dir="ltr">geminidataanalytics.locations.list</code></li>
<li><code translate="no" dir="ltr">geminidataanalytics.locations.useDataEngineeringAgent</code></li>
<li><code translate="no" dir="ltr">geminidataanalytics.operations.cancel</code></li>
<li><code translate="no" dir="ltr">geminidataanalytics.operations.delete</code></li>
<li><code translate="no" dir="ltr">geminidataanalytics.operations.get</code></li>
<li><code translate="no" dir="ltr">geminidataanalytics.operations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.list</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="bigquery.studioUser" class="role-title add-link" data-text="BigQuery Studio User " tabindex="-1">BigQuery Studio User</h4>
<p>(<code translate="no" dir="ltr">roles/bigquery.studioUser</code>)</p>
<span class="role-description custom"> </span>
<p>Combination role of BigQuery Job User, BigQuery Read Session User, Dataform Code Creator, Notebook Runtime User and Dataproc Serverless Editor.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Saved query</li>
<li>Data canvas</li>
<li>Data preparation</li>
<li>Pipeline</li>
<li>Repository</li>
</ul>
<p>This role can also be granted on Resource Manager resources (projects, folders, and organizations).</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">aiplatform.locations.get</code></p>
<p><code translate="no" dir="ltr">aiplatform.notebookRuntimeTemplates.apply</code></p>
<p><code translate="no" dir="ltr">aiplatform.notebookRuntimeTemplates.get</code></p>
<p><code translate="no" dir="ltr">aiplatform.notebookRuntimeTemplates.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">aiplatform.notebookRuntimeTemplates.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.notebookRuntimes.assign</code></p>
<p><code translate="no" dir="ltr">aiplatform.notebookRuntimes.get</code></p>
<p><code translate="no" dir="ltr">aiplatform.notebookRuntimes.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.operations.list</code></p>
<p><code translate="no" dir="ltr">bigquery.config.get</code></p>
<p><code translate="no" dir="ltr">bigquery.jobs.create</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.readsessions.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.readsessions.create</code></li>
<li><code translate="no" dir="ltr">bigquery.readsessions.getData</code></li>
<li><code translate="no" dir="ltr">bigquery.readsessions.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudaicompanion.companions.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudaicompanion.companions.generateChat</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.companions.generateCode</code></li>
</ul>
<p><code translate="no" dir="ltr">cloudaicompanion.entitlements.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudaicompanion.instances.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudaicompanion.instances.completeCode</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.instances.completeTask</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.instances.exportMetrics</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.instances.generateCode</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.instances.generateText</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.instances.queryEffectiveSetting</code></li>
<li><code translate="no" dir="ltr">cloudaicompanion.instances.queryEffectiveSettingBindings</code></li>
</ul>
<p><code translate="no" dir="ltr">cloudaicompanion.licenses.selfAssign</code></p>
<p><code translate="no" dir="ltr">cloudaicompanion.operations.get</code></p>
<p><code translate="no" dir="ltr">cloudaicompanion.topics.create</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudkms.keyHandles.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudkms.keyHandles.create</code></li>
<li><code translate="no" dir="ltr">cloudkms.keyHandles.get</code></li>
<li><code translate="no" dir="ltr">cloudkms.keyHandles.list</code></li>
</ul>
<p><code translate="no" dir="ltr">cloudkms.operations.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.projects.showEffectiveAutokeyConfig</code></p>
<p><code translate="no" dir="ltr">compute.projects.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.regions.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.regions.get</code></li>
<li><code translate="no" dir="ltr">compute.regions.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.zones.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.zones.get</code></li>
<li><code translate="no" dir="ltr">compute.zones.list</code></li>
</ul>
<p><code translate="no" dir="ltr">dataform.commentThreads.get</code></p>
<p><code translate="no" dir="ltr">dataform.commentThreads.list</code></p>
<p><code translate="no" dir="ltr">dataform.comments.get</code></p>
<p><code translate="no" dir="ltr">dataform.comments.list</code></p>
<p><code translate="no" dir="ltr">dataform.folders.create</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">dataform.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">dataform.locations.get</code></li>
<li><code translate="no" dir="ltr">dataform.locations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">dataform.repositories.create</code></p>
<p><code translate="no" dir="ltr">dataform.repositories.list</code></p>
<p><code translate="no" dir="ltr">dataplex.projects.search</code></p>
<p><code translate="no" dir="ltr">dataproc.batches.analyze</code></p>
<p><code translate="no" dir="ltr">dataproc.batches.cancel</code></p>
<p><code translate="no" dir="ltr">dataproc.batches.create</code></p>
<p><code translate="no" dir="ltr">dataproc.batches.delete</code></p>
<p><code translate="no" dir="ltr">dataproc.batches.get</code></p>
<p><code translate="no" dir="ltr">dataproc.batches.list</code></p>
<p><code translate="no" dir="ltr">dataproc.batches.sparkApplicationRead</code></p>
<p><code translate="no" dir="ltr">dataproc.batches.sparkApplicationWrite</code></p>
<p><code translate="no" dir="ltr">dataproc.operations.cancel</code></p>
<p><code translate="no" dir="ltr">dataproc.operations.delete</code></p>
<p><code translate="no" dir="ltr">dataproc.operations.get</code></p>
<p><code translate="no" dir="ltr">dataproc.operations.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">dataproc.sessionTemplates.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">dataproc.sessionTemplates.create</code></li>
<li><code translate="no" dir="ltr">dataproc.sessionTemplates.delete</code></li>
<li><code translate="no" dir="ltr">dataproc.sessionTemplates.get</code></li>
<li><code translate="no" dir="ltr">dataproc.sessionTemplates.list</code></li>
<li><code translate="no" dir="ltr">dataproc.sessionTemplates.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">dataproc.sessions.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">dataproc.sessions.create</code></li>
<li><code translate="no" dir="ltr">dataproc.sessions.delete</code></li>
<li><code translate="no" dir="ltr">dataproc.sessions.get</code></li>
<li><code translate="no" dir="ltr">dataproc.sessions.list</code></li>
<li><code translate="no" dir="ltr">dataproc.sessions.sparkApplicationRead</code></li>
<li><code translate="no" dir="ltr">dataproc.sessions.sparkApplicationWrite</code></li>
<li><code translate="no" dir="ltr">dataproc.sessions.terminate</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">dataprocrm.nodePools.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">dataprocrm.nodePools.create</code></li>
<li><code translate="no" dir="ltr">dataprocrm.nodePools.delete</code></li>
<li><code translate="no" dir="ltr">dataprocrm.nodePools.deleteNodes</code></li>
<li><code translate="no" dir="ltr">dataprocrm.nodePools.get</code></li>
<li><code translate="no" dir="ltr">dataprocrm.nodePools.list</code></li>
<li><code translate="no" dir="ltr">dataprocrm.nodePools.resize</code></li>
</ul>
<p><code translate="no" dir="ltr">dataprocrm.nodes.get</code></p>
<p><code translate="no" dir="ltr">dataprocrm.nodes.heartbeat</code></p>
<p><code translate="no" dir="ltr">dataprocrm.nodes.list</code></p>
<p><code translate="no" dir="ltr">dataprocrm.nodes.update</code></p>
<p><code translate="no" dir="ltr">dataprocrm.operations.get</code></p>
<p><code translate="no" dir="ltr">dataprocrm.operations.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">dataprocrm.workloads.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">dataprocrm.workloads.cancel</code></li>
<li><code translate="no" dir="ltr">dataprocrm.workloads.create</code></li>
<li><code translate="no" dir="ltr">dataprocrm.workloads.delete</code></li>
<li><code translate="no" dir="ltr">dataprocrm.workloads.get</code></li>
<li><code translate="no" dir="ltr">dataprocrm.workloads.list</code></li>
</ul>
<p><code translate="no" dir="ltr">developerconnect.accountConnectors.fetchUserRepositories</code></p>
<p><code translate="no" dir="ltr">developerconnect.accountConnectors.get</code></p>
<p><code translate="no" dir="ltr">developerconnect.accountConnectors.gitProxyRead</code></p>
<p><code translate="no" dir="ltr">developerconnect.accountConnectors.gitProxyWrite</code></p>
<p><code translate="no" dir="ltr">developerconnect.accountConnectors.httpProxyRead</code></p>
<p><code translate="no" dir="ltr">developerconnect.accountConnectors.httpProxyWrite</code></p>
<p><code translate="no" dir="ltr">developerconnect.accountConnectors.list</code></p>
<p><code translate="no" dir="ltr">developerconnect.connections.fetchGitHubInstallations</code></p>
<p><code translate="no" dir="ltr">developerconnect.connections.fetchLinkableGitRepositories</code></p>
<p><code translate="no" dir="ltr">developerconnect.connections.get</code></p>
<p><code translate="no" dir="ltr">developerconnect.connections.list</code></p>
<p><code translate="no" dir="ltr">developerconnect.gitRepositoryLinks.fetchGitRefs</code></p>
<p><code translate="no" dir="ltr">developerconnect.gitRepositoryLinks.get</code></p>
<p><code translate="no" dir="ltr">developerconnect.gitRepositoryLinks.gitProxyRead</code></p>
<p><code translate="no" dir="ltr">developerconnect.gitRepositoryLinks.gitProxyWrite</code></p>
<p><code translate="no" dir="ltr">developerconnect.gitRepositoryLinks.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">developerconnect.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">developerconnect.locations.get</code></li>
<li><code translate="no" dir="ltr">developerconnect.locations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">developerconnect.operations.get</code></p>
<p><code translate="no" dir="ltr">developerconnect.operations.list</code></p>
<p><code translate="no" dir="ltr">developerconnect.users.deleteSelf</code></p>
<p><code translate="no" dir="ltr">developerconnect.users.fetchAccessToken</code></p>
<p><code translate="no" dir="ltr">developerconnect.users.finishOAuth</code></p>
<p><code translate="no" dir="ltr">developerconnect.users.getSelf</code></p>
<p><code translate="no" dir="ltr">developerconnect.users.startOAuth</code></p>
<p><code translate="no" dir="ltr">geminicloudassist.agents.invoke</code></p>
<p><code translate="no" dir="ltr">geminidataanalytics.dataAgents.get</code></p>
<p><code translate="no" dir="ltr">geminidataanalytics.dataAgents.list</code></p>
<p><code translate="no" dir="ltr">geminidataanalytics.locations.chat</code></p>
<p><code translate="no" dir="ltr">geminidataanalytics.locations.useDataEngineeringAgent</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.get</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="bigquery.user" class="role-title add-link" data-text="BigQuery User " tabindex="-1">BigQuery User</h4>
<p>(<code translate="no" dir="ltr">roles/bigquery.user</code>)</p>
<span class="role-description custom"> </span>
<p>When granted on a dataset, this role provides the ability to read the dataset's metadata and list tables in the dataset.</p>
<p>When granted on a project, this role also provides the ability to run jobs, including queries, within the project. A principal with this role can enumerate their own jobs, cancel their own jobs, and enumerate datasets within a project. Additionally, allows the creation of new datasets within the project; the creator is granted the BigQuery Data Owner role (<code translate="no" dir="ltr">roles/bigquery.dataOwner</code>) on these new datasets.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Dataset</li>
<li>These resources within a dataset:</li>
<li><ul>
<li>Routine</li>
</ul></li>
</ul>
<p>This role can also be granted on Resource Manager resources (projects, folders, and organizations).</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">bigquery.bireservations.get</code></p>
<p><code translate="no" dir="ltr">bigquery.capacityCommitments.get</code></p>
<p><code translate="no" dir="ltr">bigquery.capacityCommitments.list</code></p>
<p><code translate="no" dir="ltr">bigquery.config.get</code></p>
<p><code translate="no" dir="ltr">bigquery.datasets.create</code></p>
<p><code translate="no" dir="ltr">bigquery.datasets.get</code></p>
<p><code translate="no" dir="ltr">bigquery.datasets.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigquery.jobs.create</code></p>
<p><code translate="no" dir="ltr">bigquery.jobs.list</code></p>
<p><code translate="no" dir="ltr">bigquery.models.list</code></p>
<p><code translate="no" dir="ltr">bigquery.propertyGraphs.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.readsessions.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.readsessions.create</code></li>
<li><code translate="no" dir="ltr">bigquery.readsessions.getData</code></li>
<li><code translate="no" dir="ltr">bigquery.readsessions.update</code></li>
</ul>
<p><code translate="no" dir="ltr">bigquery.reservationAssignments.list</code></p>
<p><code translate="no" dir="ltr">bigquery.reservationAssignments.search</code></p>
<p><code translate="no" dir="ltr">bigquery.reservationGroups.get</code></p>
<p><code translate="no" dir="ltr">bigquery.reservationGroups.list</code></p>
<p><code translate="no" dir="ltr">bigquery.reservations.get</code></p>
<p><code translate="no" dir="ltr">bigquery.reservations.list</code></p>
<p><code translate="no" dir="ltr">bigquery.reservations.listFailoverDatasets</code></p>
<p><code translate="no" dir="ltr">bigquery.reservations.use</code></p>
<p><code translate="no" dir="ltr">bigquery.routines.list</code></p>
<p><code translate="no" dir="ltr">bigquery.savedqueries.get</code></p>
<p><code translate="no" dir="ltr">bigquery.savedqueries.list</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.list</code></p>
<p><code translate="no" dir="ltr">bigquery.transfers.get</code></p>
<p><code translate="no" dir="ltr">bigquerymigration.translation.translate</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudkms.keyHandles.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudkms.keyHandles.create</code></li>
<li><code translate="no" dir="ltr">cloudkms.keyHandles.get</code></li>
<li><code translate="no" dir="ltr">cloudkms.keyHandles.list</code></li>
</ul>
<p><code translate="no" dir="ltr">cloudkms.operations.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.projects.showEffectiveAutokeyConfig</code></p>
<p><code translate="no" dir="ltr">dataform.folders.create</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">dataform.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">dataform.locations.get</code></li>
<li><code translate="no" dir="ltr">dataform.locations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">dataform.repositories.create</code></p>
<p><code translate="no" dir="ltr">dataform.repositories.list</code></p>
<p><code translate="no" dir="ltr">dataplex.projects.search</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="bigquery.filteredDataViewer" class="role-title add-link" data-text="BigQuery Filtered Data Viewer " tabindex="-1">BigQuery Filtered Data Viewer</h4>
<p>(<code translate="no" dir="ltr">roles/bigquery.filteredDataViewer</code>)</p>
<span class="role-description custom"> </span>
<p>Access to view filtered table data defined by a row access policy. <code translate="no" dir="ltr">bigquery.filteredDataViewer</code> is a system-managed role. Grant the role by using row-level access policies. Don't apply the role directly to a resource through Identity and Access Management (IAM).</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">bigquery.rowAccessPolicies.getFilteredData</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="bigquery.objectRefAdmin" class="role-title add-link" data-text="BigQuery ObjectRef Admin " tabindex="-1">BigQuery ObjectRef Admin</h4>
<p>(<code translate="no" dir="ltr">roles/bigquery.objectRefAdmin</code>)</p>
<span class="role-description custom"> </span>
<p>Administer ObjectRef resources that includes read and write permissions</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Connection</li>
</ul>
<p>This role can also be granted on Resource Manager resources (projects, folders, and organizations).</p></td>
<td class="role-permissions"><p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.objectRefs.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.objectRefs.read</code></li>
<li><code translate="no" dir="ltr">bigquery.objectRefs.write</code></li>
</ul></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="bigquery.objectRefReader" class="role-title add-link" data-text="BigQuery ObjectRef Reader " tabindex="-1">BigQuery ObjectRef Reader</h4>
<p>(<code translate="no" dir="ltr">roles/bigquery.objectRefReader</code>)</p>
<span class="role-description custom"> </span>
<p>Role for reading referenced objects via ObjectRefs in BigQuery</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Connection</li>
</ul>
<p>This role can also be granted on Resource Manager resources (projects, folders, and organizations).</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">bigquery.objectRefs.read</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="bigquery.routineAdmin" class="role-title add-link" data-text="BigQuery Authorized Routine Admin Beta " tabindex="-1">BigQuery Authorized Routine Admin <sup>Beta</sup></h4>
<p>(<code translate="no" dir="ltr">roles/bigquery.routineAdmin</code>)</p>
<span class="role-description"> </span>
<p>Role for Authorized Routine to administer supported resources</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">bigquery.connections.use</code></p>
<p><code translate="no" dir="ltr">bigquery.datasets.get</code></p>
<p><code translate="no" dir="ltr">bigquery.models.getData</code></p>
<p><code translate="no" dir="ltr">bigquery.models.getMetadata</code></p>
<p><code translate="no" dir="ltr">bigquery.routines.get</code></p>
<p><code translate="no" dir="ltr">bigquery.routines.list</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.create</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.delete</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.get</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.getData</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.list</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.update</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.updateData</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="bigquery.routineDataEditor" class="role-title add-link" data-text="BigQuery Authorized Routine Data Editor Beta " tabindex="-1">BigQuery Authorized Routine Data Editor <sup>Beta</sup></h4>
<p>(<code translate="no" dir="ltr">roles/bigquery.routineDataEditor</code>)</p>
<span class="role-description"> </span>
<p>Role for Authorized Routine to edit contents of supported resources</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">bigquery.datasets.get</code></p>
<p><code translate="no" dir="ltr">bigquery.models.getData</code></p>
<p><code translate="no" dir="ltr">bigquery.models.getMetadata</code></p>
<p><code translate="no" dir="ltr">bigquery.routines.get</code></p>
<p><code translate="no" dir="ltr">bigquery.routines.list</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.create</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.delete</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.get</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.getData</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.list</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.update</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.updateData</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="bigquery.routineDataViewer" class="role-title add-link" data-text="BigQuery Authorized Routine Data Viewer Beta " tabindex="-1">BigQuery Authorized Routine Data Viewer <sup>Beta</sup></h4>
<p>(<code translate="no" dir="ltr">roles/bigquery.routineDataViewer</code>)</p>
<span class="role-description"> </span>
<p>Role for Authorized Routine to view data and contents of supported resources</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">bigquery.datasets.get</code></p>
<p><code translate="no" dir="ltr">bigquery.models.getData</code></p>
<p><code translate="no" dir="ltr">bigquery.models.getMetadata</code></p>
<p><code translate="no" dir="ltr">bigquery.routines.get</code></p>
<p><code translate="no" dir="ltr">bigquery.routines.list</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.get</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.getData</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.list</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="bigquery.routineMetadataViewer" class="role-title add-link" data-text="BigQuery Authorized Routine Metadata Viewer Beta " tabindex="-1">BigQuery Authorized Routine Metadata Viewer <sup>Beta</sup></h4>
<p>(<code translate="no" dir="ltr">roles/bigquery.routineMetadataViewer</code>)</p>
<span class="role-description"> </span>
<p>Role for Authorized Routine to view metadata of supported resources</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">bigquery.datasets.get</code></p>
<p><code translate="no" dir="ltr">bigquery.models.getMetadata</code></p>
<p><code translate="no" dir="ltr">bigquery.routines.get</code></p>
<p><code translate="no" dir="ltr">bigquery.routines.list</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.get</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.list</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="bigquery.securityAdmin" class="role-title add-link" data-text="BigQuery Security Admin Beta " tabindex="-1">BigQuery Security Admin <sup>Beta</sup></h4>
<p>(<code translate="no" dir="ltr">roles/bigquery.securityAdmin</code>)</p>
<span class="role-description"> </span>
<p>Administer all BigQuery security controls</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">bigquery.dataPolicies.attach</code></p>
<p><code translate="no" dir="ltr">bigquery.dataPolicies.create</code></p>
<p><code translate="no" dir="ltr">bigquery.dataPolicies.delete</code></p>
<p><code translate="no" dir="ltr">bigquery.dataPolicies.get</code></p>
<p><code translate="no" dir="ltr">bigquery.dataPolicies.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigquery.dataPolicies.list</code></p>
<p><code translate="no" dir="ltr">bigquery.dataPolicies.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigquery.dataPolicies.update</code></p>
<p><code translate="no" dir="ltr">bigquery.datasets.createTagBinding</code></p>
<p><code translate="no" dir="ltr">bigquery.datasets.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">bigquery.datasets.get</code></p>
<p><code translate="no" dir="ltr">bigquery.datasets.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigquery.datasets.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">bigquery.datasets.listSharedDatasetUsage</code></p>
<p><code translate="no" dir="ltr">bigquery.datasets.listTagBindings</code></p>
<p><code translate="no" dir="ltr">bigquery.datasets.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigquery.datasets.update</code></p>
<p><code translate="no" dir="ltr">bigquery.datasets.updateTag</code></p>
<p><code translate="no" dir="ltr">bigquery.jobs.create</code></p>
<p><code translate="no" dir="ltr">bigquery.routines.get</code></p>
<p><code translate="no" dir="ltr">bigquery.routines.list</code></p>
<p><code translate="no" dir="ltr">bigquery.rowAccessPolicies.create</code></p>
<p><code translate="no" dir="ltr">bigquery.rowAccessPolicies.delete</code></p>
<p><code translate="no" dir="ltr">bigquery.rowAccessPolicies.get</code></p>
<p><code translate="no" dir="ltr">bigquery.rowAccessPolicies.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigquery.rowAccessPolicies.list</code></p>
<p><code translate="no" dir="ltr">bigquery.rowAccessPolicies.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigquery.rowAccessPolicies.update</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.createTagBinding</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.get</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.list</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.listTagBindings</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.setColumnDataPolicy</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.update</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.updateTag</code></p>
<p><code translate="no" dir="ltr">dataplex.projects.search</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
</tbody>
</table>

### Service agent roles

Service agent roles should only be granted to [service agents](/iam/docs/service-agents).

<div results-count-container="">

</div>

<table class="fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="50%">Role</th>
<th>Permissions</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td class="role-description"><h4 id="bigquery.connectedSheetsServiceAgent" class="role-title add-link" data-text="Connected Sheets Service Agent " tabindex="-1">Connected Sheets Service Agent</h4>
<p>(<code translate="no" dir="ltr">roles/bigquery.connectedSheetsServiceAgent</code>)</p>
<span class="role-description"> </span>
<p>Grants Connected Sheets Service Account access to create and manage BigQuery jobs on the customers resources.</p>
<strong>Warning:</strong> Do not grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.</td>
<td class="role-permissions"><p><code translate="no" dir="ltr">bigquery.datasets.get</code></p>
<p><code translate="no" dir="ltr">bigquery.jobs.create</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.create</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.update</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.updateData</code></p></td>
</tr>
</tbody>
</table>

## BigQuery permissions

<div results-count-container="">

</div>

<table class="permissions-table fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="45%">Permission</th>
<th>Included in roles</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td><h4 id="bigquery.bireservations.get" class="permission-name add-link" data-text="bigquery.bireservations.get" tabindex="-1"><code translate="no" dir="ltr">bigquery.bireservations.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceAdmin">BigQuery Resource Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceEditor">BigQuery Resource Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceViewer">BigQuery Resource Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.user">BigQuery User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.bireservations.update" class="permission-name add-link" data-text="bigquery.bireservations.update" tabindex="-1"><code translate="no" dir="ltr">bigquery.bireservations.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceAdmin">BigQuery Resource Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.capacityCommitments.create" class="permission-name add-link" data-text="bigquery.capacityCommitments.create" tabindex="-1"><code translate="no" dir="ltr">bigquery.capacityCommitments.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceAdmin">BigQuery Resource Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.capacityCommitments.delete" class="permission-name add-link" data-text="bigquery.capacityCommitments.delete" tabindex="-1"><code translate="no" dir="ltr">bigquery.capacityCommitments.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceAdmin">BigQuery Resource Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.capacityCommitments.get" class="permission-name add-link" data-text="bigquery.capacityCommitments.get" tabindex="-1"><code translate="no" dir="ltr">bigquery.capacityCommitments.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceAdmin">BigQuery Resource Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceEditor">BigQuery Resource Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceViewer">BigQuery Resource Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.user">BigQuery User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.capacityCommitments.list" class="permission-name add-link" data-text="bigquery.capacityCommitments.list" tabindex="-1"><code translate="no" dir="ltr">bigquery.capacityCommitments.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceAdmin">BigQuery Resource Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceEditor">BigQuery Resource Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceViewer">BigQuery Resource Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.user">BigQuery User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.capacityCommitments.update" class="permission-name add-link" data-text="bigquery.capacityCommitments.update" tabindex="-1"><code translate="no" dir="ltr">bigquery.capacityCommitments.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceAdmin">BigQuery Resource Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.config.get" class="permission-name add-link" data-text="bigquery.config.get" tabindex="-1"><code translate="no" dir="ltr">bigquery.config.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataEditor">BigQuery Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.jobUser">BigQuery Job User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.jobUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioUser">BigQuery Studio User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.user">BigQuery User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/bigquerydatatransfer#bigquerydatatransfer.serviceAgent">BigQuery Data Transfer Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatatransfer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/enterpriseknowledgegraph#enterpriseknowledgegraph.serviceAgent">Enterprise Knowledge Graph Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/enterpriseknowledgegraph.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/fleetengine#fleetengine.serviceAgent">FleetEngine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/fleetengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/looker#looker.serviceAgent">(Legacy) Looker Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/looker.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.config.update" class="permission-name add-link" data-text="bigquery.config.update" tabindex="-1"><code translate="no" dir="ltr">bigquery.config.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredworkloads#assuredworkloads.admin">Assured Workloads Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredworkloads.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredworkloads#assuredworkloads.editor">Assured Workloads Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredworkloads.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.connections.create" class="permission-name add-link" data-text="bigquery.connections.create" tabindex="-1"><code translate="no" dir="ltr">bigquery.connections.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.connectionAdmin">BigQuery Connection Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.connectionAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.serviceAgent">Chronicle Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.connections.delegate" class="permission-name add-link" data-text="bigquery.connections.delegate" tabindex="-1"><code translate="no" dir="ltr">bigquery.connections.delegate</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.connectionAdmin">BigQuery Connection Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.connectionAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/datastream#datastream.bigqueryWriter">Datastream Bigquery Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/datastream.bigqueryWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/bigquerydatatransfer#bigquerydatatransfer.serviceAgent">BigQuery Data Transfer Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatatransfer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.serviceAgent">Chronicle Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.discoveryBigLakePublishingServiceAgent">Dataplex Discovery BigLake Publishing Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.discoveryBigLakePublishingServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datastream#datastream.serviceAgent">Datastream Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datastream.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.connections.delete" class="permission-name add-link" data-text="bigquery.connections.delete" tabindex="-1"><code translate="no" dir="ltr">bigquery.connections.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.connectionAdmin">BigQuery Connection Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.connectionAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.serviceAgent">Chronicle Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.connections.get" class="permission-name add-link" data-text="bigquery.connections.get" tabindex="-1"><code translate="no" dir="ltr">bigquery.connections.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.connectionAdmin">BigQuery Connection Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.connectionAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.connectionUser">BigQuery Connection User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.connectionUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.admin">Data Catalog Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.editor">Data Catalog Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.viewer">Data Catalog Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/datastream#datastream.bigqueryWriter">Datastream Bigquery Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/datastream.bigqueryWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.serviceAgent">Chronicle Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datastream#datastream.serviceAgent">Datastream Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datastream.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.connections.getIamPolicy" class="permission-name add-link" data-text="bigquery.connections.getIamPolicy" tabindex="-1"><code translate="no" dir="ltr">bigquery.connections.getIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.connectionAdmin">BigQuery Connection Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.connectionAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.connectionUser">BigQuery Connection User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.connectionUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.serviceAgent">Chronicle Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.connections.list" class="permission-name add-link" data-text="bigquery.connections.list" tabindex="-1"><code translate="no" dir="ltr">bigquery.connections.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.connectionAdmin">BigQuery Connection Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.connectionAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.connectionUser">BigQuery Connection User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.connectionUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.serviceAgent">Chronicle Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.connections.setIamPolicy" class="permission-name add-link" data-text="bigquery.connections.setIamPolicy" tabindex="-1"><code translate="no" dir="ltr">bigquery.connections.setIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.connectionAdmin">BigQuery Connection Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.connectionAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.connections.update" class="permission-name add-link" data-text="bigquery.connections.update" tabindex="-1"><code translate="no" dir="ltr">bigquery.connections.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.connectionAdmin">BigQuery Connection Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.connectionAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.serviceAgent">Chronicle Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.connections.updateTag" class="permission-name add-link" data-text="bigquery.connections.updateTag" tabindex="-1"><code translate="no" dir="ltr">bigquery.connections.updateTag</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.connectionAdmin">BigQuery Connection Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.connectionAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.admin">Data Catalog Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.tagEditor">Data Catalog Tag Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.tagEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.serviceAgent">Chronicle Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.connections.use" class="permission-name add-link" data-text="bigquery.connections.use" tabindex="-1"><code translate="no" dir="ltr">bigquery.connections.use</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.connectionAdmin">BigQuery Connection Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.connectionAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.connectionUser">BigQuery Connection User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.connectionUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.routineAdmin">BigQuery Authorized Routine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.routineAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.serviceAgent">Chronicle Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.discoveryBigLakePublishingServiceAgent">Dataplex Discovery BigLake Publishing Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.discoveryBigLakePublishingServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.dataPolicies.attach" class="permission-name add-link" data-text="bigquery.dataPolicies.attach" tabindex="-1"><code translate="no" dir="ltr">bigquery.dataPolicies.attach</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.admin">BigQuery Data Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.securityAdmin">BigQuery Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.dataPolicies.create" class="permission-name add-link" data-text="bigquery.dataPolicies.create" tabindex="-1"><code translate="no" dir="ltr">bigquery.dataPolicies.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.admin">BigQuery Data Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.securityAdmin">BigQuery Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.dataPolicies.delete" class="permission-name add-link" data-text="bigquery.dataPolicies.delete" tabindex="-1"><code translate="no" dir="ltr">bigquery.dataPolicies.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.admin">BigQuery Data Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.securityAdmin">BigQuery Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.dataPolicies.get" class="permission-name add-link" data-text="bigquery.dataPolicies.get" tabindex="-1"><code translate="no" dir="ltr">bigquery.dataPolicies.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.admin">BigQuery Data Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.viewer">BigQuery Data Policy Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.securityAdmin">BigQuery Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.dataPolicies.getIamPolicy" class="permission-name add-link" data-text="bigquery.dataPolicies.getIamPolicy" tabindex="-1"><code translate="no" dir="ltr">bigquery.dataPolicies.getIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.admin">BigQuery Data Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.securityAdmin">BigQuery Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.dataPolicies.getRawData" class="permission-name add-link" data-text="bigquery.dataPolicies.getRawData" tabindex="-1"><code translate="no" dir="ltr">bigquery.dataPolicies.getRawData</code></h4></td>
<td><p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.rawDataReader">Raw Data Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.rawDataReader</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.dataPolicies.list" class="permission-name add-link" data-text="bigquery.dataPolicies.list" tabindex="-1"><code translate="no" dir="ltr">bigquery.dataPolicies.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.admin">BigQuery Data Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.viewer">BigQuery Data Policy Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.securityAdmin">BigQuery Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.dataPolicies.maskedGet" class="permission-name add-link" data-text="bigquery.dataPolicies.maskedGet" tabindex="-1"><code translate="no" dir="ltr">bigquery.dataPolicies.maskedGet</code></h4></td>
<td><p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.maskedReader">Masked Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.maskedReader</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.dataPolicies.setIamPolicy" class="permission-name add-link" data-text="bigquery.dataPolicies.setIamPolicy" tabindex="-1"><code translate="no" dir="ltr">bigquery.dataPolicies.setIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.admin">BigQuery Data Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.securityAdmin">BigQuery Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.dataPolicies.update" class="permission-name add-link" data-text="bigquery.dataPolicies.update" tabindex="-1"><code translate="no" dir="ltr">bigquery.dataPolicies.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.admin">BigQuery Data Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.securityAdmin">BigQuery Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.datasets.create" class="permission-name add-link" data-text="bigquery.datasets.create" tabindex="-1"><code translate="no" dir="ltr">bigquery.datasets.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataEditor">BigQuery Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.user">BigQuery User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercebusinessenablement#commercebusinessenablement.admin">Commerce Business Enablement Configuration Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/commercebusinessenablement.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/datastream#datastream.bigqueryWriter">Datastream Bigquery Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/datastream.bigqueryWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.batchPredictionServiceAgent">Vertex AI Batch Prediction Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.batchPredictionServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.customCodeServiceAgent">Vertex AI Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.customCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.modelMonitoringServiceAgent">Vertex AI Model Monitoring Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.modelMonitoringServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.ragServiceAgent">Vertex AI RAG Data Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.ragServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.tuningServiceAgent">Vertex AI Tuning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.tuningServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/automl#automl.serviceAgent">AutoML Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.serviceAgent">Recommendations AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ces#ces.serviceAgent">Customer Engagement Suite Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ces.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.serviceAgent">Chronicle Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/contactcenterinsights#contactcenterinsights.serviceAgent">Contact Center AI Insights Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/contactcenterinsights.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datalabeling#datalabeling.serviceAgent">Data Labeling Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datalabeling.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.discoveryPublishingServiceAgent">Dataplex Discovery Publishing Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.discoveryPublishingServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datastream#datastream.serviceAgent">Datastream Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datastream.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dialogflow#dialogflow.serviceAgent">Dialogflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dialogflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.serviceAgent">Discovery Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/enterpriseknowledgegraph#enterpriseknowledgegraph.serviceAgent">Enterprise Knowledge Graph Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/enterpriseknowledgegraph.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.managementServiceAgent">Firebase Service Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.managementServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasecrash#firebasecrashlytics.serviceAgent">Firebase Crashlytics Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasecrashlytics.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/fleetengine#fleetengine.serviceAgent">FleetEngine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/fleetengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/logging#logging.serviceAgent">Cloud Logging Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/observability#observability.serviceAgent">Observability Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/observability.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/retail#retail.serviceAgent">Retail Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/retail.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/spectrumsas#spectrumsas.serviceAgent">Spectrum SAS Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/spectrumsas.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/storageinsights#storageinsights.serviceAgent">StorageInsights Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/storageinsights.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visionai#visionai.serviceAgent">Cloud Vision AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visionai.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.datasets.createTagBinding" class="permission-name add-link" data-text="bigquery.datasets.createTagBinding" tabindex="-1"><code translate="no" dir="ltr">bigquery.datasets.createTagBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.securityAdmin">BigQuery Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dspm#dspm.serviceAgent">DSPM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.datasets.delete" class="permission-name add-link" data-text="bigquery.datasets.delete" tabindex="-1"><code translate="no" dir="ltr">bigquery.datasets.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.datasets.deleteTagBinding" class="permission-name add-link" data-text="bigquery.datasets.deleteTagBinding" tabindex="-1"><code translate="no" dir="ltr">bigquery.datasets.deleteTagBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.securityAdmin">BigQuery Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dspm#dspm.serviceAgent">DSPM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.datasets.get" class="permission-name add-link" data-text="bigquery.datasets.get" tabindex="-1"><code translate="no" dir="ltr">bigquery.datasets.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataEditor">BigQuery Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataViewer">BigQuery Data Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.metadataViewer">BigQuery Metadata Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.metadataViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.user">BigQuery User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercebusinessenablement#commercebusinessenablement.admin">Commerce Business Enablement Configuration Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/commercebusinessenablement.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.admin">Data Catalog Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.editor">Data Catalog Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.viewer">Data Catalog Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.routineAdmin">BigQuery Authorized Routine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.routineAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.routineDataEditor">BigQuery Authorized Routine Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.routineDataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.routineDataViewer">BigQuery Authorized Routine Data Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.routineDataViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.routineMetadataViewer">BigQuery Authorized Routine Metadata Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.routineMetadataViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.securityAdmin">BigQuery Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.storageDataOwner">Dataplex Storage Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.storageDataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.storageDataReader">Dataplex Storage Data Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.storageDataReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/datastream#datastream.bigqueryWriter">Datastream Bigquery Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/datastream.bigqueryWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/securedlandingzone#securedlandingzone.bqdwProjectRemediator">SLZ BQDW Blueprint Project Level Remediator</a> (<code class="role-name" translate="no" dir="ltr">roles/securedlandingzone.bqdwProjectRemediator</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.batchPredictionServiceAgent">Vertex AI Batch Prediction Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.batchPredictionServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.customCodeServiceAgent">Vertex AI Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.customCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.modelMonitoringServiceAgent">Vertex AI Model Monitoring Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.modelMonitoringServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.ragServiceAgent">Vertex AI RAG Data Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.ragServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.tuningServiceAgent">Vertex AI Tuning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.tuningServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.serviceAgent">Audit Manager Auditing Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/automl#automl.serviceAgent">AutoML Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.serviceAgent">Recommendations AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/bigquery#bigquery.connectedSheetsServiceAgent">Connected Sheets Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.connectedSheetsServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ces#ces.serviceAgent">Customer Engagement Suite Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ces.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudasset#cloudasset.serviceAgent">Cloud Asset Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudasset.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.serviceAgent">Cloud Security Compliance Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/contactcenterinsights#contactcenterinsights.serviceAgent">Contact Center AI Insights Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/contactcenterinsights.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datalabeling#datalabeling.serviceAgent">Data Labeling Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datalabeling.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.discoveryPublishingServiceAgent">Dataplex Discovery Publishing Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.discoveryPublishingServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datastream#datastream.serviceAgent">Datastream Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datastream.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datastudio#datastudio.managedStorageServiceAgent">Data Studio Managed Storage Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datastudio.managedStorageServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.serviceAgent">Discovery Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/enterpriseknowledgegraph#enterpriseknowledgegraph.serviceAgent">Enterprise Knowledge Graph Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/enterpriseknowledgegraph.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.managementServiceAgent">Firebase Service Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.managementServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasecrash#firebasecrashlytics.serviceAgent">Firebase Crashlytics Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasecrashlytics.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/fleetengine#fleetengine.serviceAgent">FleetEngine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/fleetengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/logging#logging.serviceAgent">Cloud Logging Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/looker#looker.serviceAgent">(Legacy) Looker Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/looker.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/observability#observability.serviceAgent">Observability Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/observability.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/retail#retail.serviceAgent">Retail Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/retail.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.controlServiceAgent">Security Center Control Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.controlServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.securityHealthAnalyticsServiceAgent">Security Health Analytics Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.securityHealthAnalyticsServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.serviceAgent">Security Center Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visionai#visionai.serviceAgent">Cloud Vision AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visionai.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.datasets.getIamPolicy" class="permission-name add-link" data-text="bigquery.datasets.getIamPolicy" tabindex="-1"><code translate="no" dir="ltr">bigquery.datasets.getIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataEditor">BigQuery Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataViewer">BigQuery Data Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.metadataViewer">BigQuery Metadata Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.metadataViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.user">BigQuery User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.securityAdmin">BigQuery Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/securedlandingzone#securedlandingzone.bqdwProjectRemediator">SLZ BQDW Blueprint Project Level Remediator</a> (<code class="role-name" translate="no" dir="ltr">roles/securedlandingzone.bqdwProjectRemediator</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.managementServiceAgent">Firebase Service Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.managementServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.datasets.link" class="permission-name add-link" data-text="bigquery.datasets.link" tabindex="-1"><code translate="no" dir="ltr">bigquery.datasets.link</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/logging#logging.serviceAgent">Cloud Logging Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/logging.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/observability#observability.serviceAgent">Observability Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/observability.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.datasets.listEffectiveTags" class="permission-name add-link" data-text="bigquery.datasets.listEffectiveTags" tabindex="-1"><code translate="no" dir="ltr">bigquery.datasets.listEffectiveTags</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagViewer">Tag Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.securityAdmin">BigQuery Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dspm#dspm.serviceAgent">DSPM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.datasets.listSharedDatasetUsage" class="permission-name add-link" data-text="bigquery.datasets.listSharedDatasetUsage" tabindex="-1"><code translate="no" dir="ltr">bigquery.datasets.listSharedDatasetUsage</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.securityAdmin">BigQuery Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.datasets.listTagBindings" class="permission-name add-link" data-text="bigquery.datasets.listTagBindings" tabindex="-1"><code translate="no" dir="ltr">bigquery.datasets.listTagBindings</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagViewer">Tag Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.securityAdmin">BigQuery Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dspm#dspm.serviceAgent">DSPM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.datasets.setIamPolicy" class="permission-name add-link" data-text="bigquery.datasets.setIamPolicy" tabindex="-1"><code translate="no" dir="ltr">bigquery.datasets.setIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.securityAdmin">BigQuery Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securedlandingzone#securedlandingzone.bqdwProjectRemediator">SLZ BQDW Blueprint Project Level Remediator</a> (<code class="role-name" translate="no" dir="ltr">roles/securedlandingzone.bqdwProjectRemediator</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.managementServiceAgent">Firebase Service Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.managementServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.datasets.update" class="permission-name add-link" data-text="bigquery.datasets.update" tabindex="-1"><code translate="no" dir="ltr">bigquery.datasets.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/commercebusinessenablement#commercebusinessenablement.admin">Commerce Business Enablement Configuration Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/commercebusinessenablement.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.securityAdmin">BigQuery Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/securedlandingzone#securedlandingzone.bqdwProjectRemediator">SLZ BQDW Blueprint Project Level Remediator</a> (<code class="role-name" translate="no" dir="ltr">roles/securedlandingzone.bqdwProjectRemediator</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.managementServiceAgent">Firebase Service Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.managementServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.datasets.updateTag" class="permission-name add-link" data-text="bigquery.datasets.updateTag" tabindex="-1"><code translate="no" dir="ltr">bigquery.datasets.updateTag</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataEditor">BigQuery Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.admin">Data Catalog Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.securityAdmin">BigQuery Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.tagEditor">Data Catalog Tag Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.tagEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/ces#ces.serviceAgent">Customer Engagement Suite Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ces.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.jobs.create" class="permission-name add-link" data-text="bigquery.jobs.create" tabindex="-1"><code translate="no" dir="ltr">bigquery.jobs.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.jobUser">BigQuery Job User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.jobUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioUser">BigQuery Studio User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.user">BigQuery User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.securityAdmin">BigQuery Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/datastream#datastream.bigqueryWriter">Datastream Bigquery Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/datastream.bigqueryWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.dataSecurityScanner">Wiz Data Security Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.dataSecurityScanner</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.batchPredictionServiceAgent">Vertex AI Batch Prediction Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.batchPredictionServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.customCodeServiceAgent">Vertex AI Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.customCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.modelMonitoringServiceAgent">Vertex AI Model Monitoring Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.modelMonitoringServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.ragServiceAgent">Vertex AI RAG Data Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.ragServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.tuningServiceAgent">Vertex AI Tuning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.tuningServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/automl#automl.serviceAgent">AutoML Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.serviceAgent">Recommendations AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/bigquery#bigquery.connectedSheetsServiceAgent">Connected Sheets Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.connectedSheetsServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/bigquerydatatransfer#bigquerydatatransfer.serviceAgent">BigQuery Data Transfer Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatatransfer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/bigqueryomni#bigqueryomni.serviceAgent">BigQuery Omni Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/bigqueryomni.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ces#ces.serviceAgent">Customer Engagement Suite Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ces.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.serviceAgent">Chronicle Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudasset#cloudasset.serviceAgent">Cloud Asset Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudasset.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/contactcenterinsights#contactcenterinsights.serviceAgent">Contact Center AI Insights Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/contactcenterinsights.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datalabeling#datalabeling.serviceAgent">Data Labeling Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datalabeling.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datastream#datastream.serviceAgent">Datastream Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datastream.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datastudio#datastudio.serviceAgent">Data Studio Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datastudio.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dialogflow#dialogflow.serviceAgent">Dialogflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dialogflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.serviceAgent">Discovery Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dspm#dspm.serviceAgent">DSPM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/enterpriseknowledgegraph#enterpriseknowledgegraph.serviceAgent">Enterprise Knowledge Graph Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/enterpriseknowledgegraph.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/fleetengine#fleetengine.serviceAgent">FleetEngine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/fleetengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/looker#looker.serviceAgent">(Legacy) Looker Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/looker.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/monitoring#monitoring.notificationServiceAgent">Monitoring Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/monitoring.notificationServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/retail#retail.serviceAgent">Retail Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/retail.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/spectrumsas#spectrumsas.serviceAgent">Spectrum SAS Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/spectrumsas.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visionai#visionai.serviceAgent">Cloud Vision AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visionai.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.jobs.createGlobalQuery" class="permission-name add-link" data-text="bigquery.jobs.createGlobalQuery" tabindex="-1"><code translate="no" dir="ltr">bigquery.jobs.createGlobalQuery</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.jobs.delete" class="permission-name add-link" data-text="bigquery.jobs.delete" tabindex="-1"><code translate="no" dir="ltr">bigquery.jobs.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/datastream#datastream.bigqueryWriter">Datastream Bigquery Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/datastream.bigqueryWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datastream#datastream.serviceAgent">Datastream Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datastream.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.jobs.get" class="permission-name add-link" data-text="bigquery.jobs.get" tabindex="-1"><code translate="no" dir="ltr">bigquery.jobs.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceAdmin">BigQuery Resource Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceEditor">BigQuery Resource Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceViewer">BigQuery Resource Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/datastream#datastream.bigqueryWriter">Datastream Bigquery Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/datastream.bigqueryWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.batchPredictionServiceAgent">Vertex AI Batch Prediction Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.batchPredictionServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.customCodeServiceAgent">Vertex AI Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.customCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.modelMonitoringServiceAgent">Vertex AI Model Monitoring Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.modelMonitoringServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.ragServiceAgent">Vertex AI RAG Data Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.ragServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.tuningServiceAgent">Vertex AI Tuning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.tuningServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.serviceAgent">Recommendations AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.serviceAgent">Chronicle Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudasset#cloudasset.serviceAgent">Cloud Asset Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudasset.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/contactcenterinsights#contactcenterinsights.serviceAgent">Contact Center AI Insights Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/contactcenterinsights.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datalabeling#datalabeling.serviceAgent">Data Labeling Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datalabeling.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datastream#datastream.serviceAgent">Datastream Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datastream.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.serviceAgent">Discovery Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/retail#retail.serviceAgent">Retail Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/retail.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visionai#visionai.serviceAgent">Cloud Vision AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visionai.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.jobs.list" class="permission-name add-link" data-text="bigquery.jobs.list" tabindex="-1"><code translate="no" dir="ltr">bigquery.jobs.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceAdmin">BigQuery Resource Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceEditor">BigQuery Resource Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceViewer">BigQuery Resource Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.user">BigQuery User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/datastream#datastream.bigqueryWriter">Datastream Bigquery Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/datastream.bigqueryWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.serviceAgent">Recommendations AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datastream#datastream.serviceAgent">Datastream Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datastream.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.serviceAgent">Discovery Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/retail#retail.serviceAgent">Retail Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/retail.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.jobs.listAll" class="permission-name add-link" data-text="bigquery.jobs.listAll" tabindex="-1"><code translate="no" dir="ltr">bigquery.jobs.listAll</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceAdmin">BigQuery Resource Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceEditor">BigQuery Resource Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceViewer">BigQuery Resource Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.jobs.listExecutionMetadata" class="permission-name add-link" data-text="bigquery.jobs.listExecutionMetadata" tabindex="-1"><code translate="no" dir="ltr">bigquery.jobs.listExecutionMetadata</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceAdmin">BigQuery Resource Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceEditor">BigQuery Resource Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceViewer">BigQuery Resource Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.jobs.update" class="permission-name add-link" data-text="bigquery.jobs.update" tabindex="-1"><code translate="no" dir="ltr">bigquery.jobs.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/datastream#datastream.bigqueryWriter">Datastream Bigquery Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/datastream.bigqueryWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.serviceAgent">Recommendations AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datastream#datastream.serviceAgent">Datastream Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datastream.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.serviceAgent">Discovery Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/retail#retail.serviceAgent">Retail Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/retail.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.models.create" class="permission-name add-link" data-text="bigquery.models.create" tabindex="-1"><code translate="no" dir="ltr">bigquery.models.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataEditor">BigQuery Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.storageDataOwner">Dataplex Storage Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.storageDataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.batchPredictionServiceAgent">Vertex AI Batch Prediction Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.batchPredictionServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.models.delete" class="permission-name add-link" data-text="bigquery.models.delete" tabindex="-1"><code translate="no" dir="ltr">bigquery.models.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataEditor">BigQuery Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.storageDataOwner">Dataplex Storage Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.storageDataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.models.export" class="permission-name add-link" data-text="bigquery.models.export" tabindex="-1"><code translate="no" dir="ltr">bigquery.models.export</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataEditor">BigQuery Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataViewer">BigQuery Data Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.storageDataOwner">Dataplex Storage Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.storageDataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.storageDataReader">Dataplex Storage Data Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.storageDataReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.batchPredictionServiceAgent">Vertex AI Batch Prediction Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.batchPredictionServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/looker#looker.serviceAgent">(Legacy) Looker Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/looker.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visionai#visionai.serviceAgent">Cloud Vision AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visionai.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.models.getData" class="permission-name add-link" data-text="bigquery.models.getData" tabindex="-1"><code translate="no" dir="ltr">bigquery.models.getData</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataEditor">BigQuery Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataViewer">BigQuery Data Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.routineAdmin">BigQuery Authorized Routine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.routineAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.routineDataEditor">BigQuery Authorized Routine Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.routineDataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.routineDataViewer">BigQuery Authorized Routine Data Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.routineDataViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.storageDataOwner">Dataplex Storage Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.storageDataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.storageDataReader">Dataplex Storage Data Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.storageDataReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.batchPredictionServiceAgent">Vertex AI Batch Prediction Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.batchPredictionServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/looker#looker.serviceAgent">(Legacy) Looker Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/looker.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.models.getMetadata" class="permission-name add-link" data-text="bigquery.models.getMetadata" tabindex="-1"><code translate="no" dir="ltr">bigquery.models.getMetadata</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataEditor">BigQuery Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataViewer">BigQuery Data Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.metadataViewer">BigQuery Metadata Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.metadataViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.admin">Data Catalog Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.editor">Data Catalog Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.viewer">Data Catalog Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.routineAdmin">BigQuery Authorized Routine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.routineAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.routineDataEditor">BigQuery Authorized Routine Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.routineDataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.routineDataViewer">BigQuery Authorized Routine Data Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.routineDataViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.routineMetadataViewer">BigQuery Authorized Routine Metadata Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.routineMetadataViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.storageDataOwner">Dataplex Storage Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.storageDataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.storageDataReader">Dataplex Storage Data Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.storageDataReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/looker#looker.serviceAgent">(Legacy) Looker Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/looker.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.models.list" class="permission-name add-link" data-text="bigquery.models.list" tabindex="-1"><code translate="no" dir="ltr">bigquery.models.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataEditor">BigQuery Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataViewer">BigQuery Data Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.metadataViewer">BigQuery Metadata Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.metadataViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.user">BigQuery User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.storageDataOwner">Dataplex Storage Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.storageDataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.storageDataReader">Dataplex Storage Data Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.storageDataReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/looker#looker.serviceAgent">(Legacy) Looker Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/looker.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.models.updateData" class="permission-name add-link" data-text="bigquery.models.updateData" tabindex="-1"><code translate="no" dir="ltr">bigquery.models.updateData</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataEditor">BigQuery Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.storageDataOwner">Dataplex Storage Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.storageDataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.models.updateMetadata" class="permission-name add-link" data-text="bigquery.models.updateMetadata" tabindex="-1"><code translate="no" dir="ltr">bigquery.models.updateMetadata</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataEditor">BigQuery Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.storageDataOwner">Dataplex Storage Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.storageDataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.models.updateTag" class="permission-name add-link" data-text="bigquery.models.updateTag" tabindex="-1"><code translate="no" dir="ltr">bigquery.models.updateTag</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataEditor">BigQuery Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.admin">Data Catalog Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.tagEditor">Data Catalog Tag Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.tagEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.objectRefs.read" class="permission-name add-link" data-text="bigquery.objectRefs.read" tabindex="-1"><code translate="no" dir="ltr">bigquery.objectRefs.read</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.objectRefAdmin">BigQuery ObjectRef Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.objectRefAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.objectRefReader">BigQuery ObjectRef Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.objectRefReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.objectRefs.write" class="permission-name add-link" data-text="bigquery.objectRefs.write" tabindex="-1"><code translate="no" dir="ltr">bigquery.objectRefs.write</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.objectRefAdmin">BigQuery ObjectRef Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.objectRefAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.propertyGraphs.create" class="permission-name add-link" data-text="bigquery.propertyGraphs.create" tabindex="-1"><code translate="no" dir="ltr">bigquery.propertyGraphs.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataEditor">BigQuery Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.propertyGraphs.delete" class="permission-name add-link" data-text="bigquery.propertyGraphs.delete" tabindex="-1"><code translate="no" dir="ltr">bigquery.propertyGraphs.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataEditor">BigQuery Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.propertyGraphs.get" class="permission-name add-link" data-text="bigquery.propertyGraphs.get" tabindex="-1"><code translate="no" dir="ltr">bigquery.propertyGraphs.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataEditor">BigQuery Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataViewer">BigQuery Data Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.metadataViewer">BigQuery Metadata Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.metadataViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.propertyGraphs.list" class="permission-name add-link" data-text="bigquery.propertyGraphs.list" tabindex="-1"><code translate="no" dir="ltr">bigquery.propertyGraphs.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataEditor">BigQuery Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataViewer">BigQuery Data Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.metadataViewer">BigQuery Metadata Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.metadataViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.user">BigQuery User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.propertyGraphs.update" class="permission-name add-link" data-text="bigquery.propertyGraphs.update" tabindex="-1"><code translate="no" dir="ltr">bigquery.propertyGraphs.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataEditor">BigQuery Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.readsessions.create" class="permission-name add-link" data-text="bigquery.readsessions.create" tabindex="-1"><code translate="no" dir="ltr">bigquery.readsessions.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.readSessionUser">BigQuery Read Session User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.readSessionUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioUser">BigQuery Studio User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.user">BigQuery User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.batchPredictionServiceAgent">Vertex AI Batch Prediction Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.batchPredictionServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.customCodeServiceAgent">Vertex AI Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.customCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.ragServiceAgent">Vertex AI RAG Data Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.ragServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/enterpriseknowledgegraph#enterpriseknowledgegraph.serviceAgent">Enterprise Knowledge Graph Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/enterpriseknowledgegraph.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visionai#visionai.serviceAgent">Cloud Vision AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visionai.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.readsessions.getData" class="permission-name add-link" data-text="bigquery.readsessions.getData" tabindex="-1"><code translate="no" dir="ltr">bigquery.readsessions.getData</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.readSessionUser">BigQuery Read Session User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.readSessionUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioUser">BigQuery Studio User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.user">BigQuery User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.batchPredictionServiceAgent">Vertex AI Batch Prediction Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.batchPredictionServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.customCodeServiceAgent">Vertex AI Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.customCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.ragServiceAgent">Vertex AI RAG Data Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.ragServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/enterpriseknowledgegraph#enterpriseknowledgegraph.serviceAgent">Enterprise Knowledge Graph Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/enterpriseknowledgegraph.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.readsessions.update" class="permission-name add-link" data-text="bigquery.readsessions.update" tabindex="-1"><code translate="no" dir="ltr">bigquery.readsessions.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.readSessionUser">BigQuery Read Session User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.readSessionUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioUser">BigQuery Studio User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.user">BigQuery User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.reservationAssignments.create" class="permission-name add-link" data-text="bigquery.reservationAssignments.create" tabindex="-1"><code translate="no" dir="ltr">bigquery.reservationAssignments.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceAdmin">BigQuery Resource Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceEditor">BigQuery Resource Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.reservationAssignments.delete" class="permission-name add-link" data-text="bigquery.reservationAssignments.delete" tabindex="-1"><code translate="no" dir="ltr">bigquery.reservationAssignments.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceAdmin">BigQuery Resource Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceEditor">BigQuery Resource Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.reservationAssignments.list" class="permission-name add-link" data-text="bigquery.reservationAssignments.list" tabindex="-1"><code translate="no" dir="ltr">bigquery.reservationAssignments.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceAdmin">BigQuery Resource Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceEditor">BigQuery Resource Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceViewer">BigQuery Resource Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.user">BigQuery User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.reservationAssignments.search" class="permission-name add-link" data-text="bigquery.reservationAssignments.search" tabindex="-1"><code translate="no" dir="ltr">bigquery.reservationAssignments.search</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceAdmin">BigQuery Resource Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceEditor">BigQuery Resource Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceViewer">BigQuery Resource Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.user">BigQuery User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.reservationGroups.create" class="permission-name add-link" data-text="bigquery.reservationGroups.create" tabindex="-1"><code translate="no" dir="ltr">bigquery.reservationGroups.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceAdmin">BigQuery Resource Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceEditor">BigQuery Resource Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.reservationGroups.delete" class="permission-name add-link" data-text="bigquery.reservationGroups.delete" tabindex="-1"><code translate="no" dir="ltr">bigquery.reservationGroups.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceAdmin">BigQuery Resource Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceEditor">BigQuery Resource Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.reservationGroups.get" class="permission-name add-link" data-text="bigquery.reservationGroups.get" tabindex="-1"><code translate="no" dir="ltr">bigquery.reservationGroups.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceAdmin">BigQuery Resource Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceEditor">BigQuery Resource Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceViewer">BigQuery Resource Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.user">BigQuery User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.reservationGroups.list" class="permission-name add-link" data-text="bigquery.reservationGroups.list" tabindex="-1"><code translate="no" dir="ltr">bigquery.reservationGroups.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceAdmin">BigQuery Resource Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceEditor">BigQuery Resource Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceViewer">BigQuery Resource Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.user">BigQuery User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.reservationGroups.update" class="permission-name add-link" data-text="bigquery.reservationGroups.update" tabindex="-1"><code translate="no" dir="ltr">bigquery.reservationGroups.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceAdmin">BigQuery Resource Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceEditor">BigQuery Resource Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.reservations.create" class="permission-name add-link" data-text="bigquery.reservations.create" tabindex="-1"><code translate="no" dir="ltr">bigquery.reservations.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceAdmin">BigQuery Resource Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceEditor">BigQuery Resource Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.reservations.delete" class="permission-name add-link" data-text="bigquery.reservations.delete" tabindex="-1"><code translate="no" dir="ltr">bigquery.reservations.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceAdmin">BigQuery Resource Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceEditor">BigQuery Resource Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.reservations.get" class="permission-name add-link" data-text="bigquery.reservations.get" tabindex="-1"><code translate="no" dir="ltr">bigquery.reservations.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceAdmin">BigQuery Resource Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceEditor">BigQuery Resource Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceViewer">BigQuery Resource Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.user">BigQuery User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.reservations.getIamPolicy" class="permission-name add-link" data-text="bigquery.reservations.getIamPolicy" tabindex="-1"><code translate="no" dir="ltr">bigquery.reservations.getIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceAdmin">BigQuery Resource Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.reservations.list" class="permission-name add-link" data-text="bigquery.reservations.list" tabindex="-1"><code translate="no" dir="ltr">bigquery.reservations.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceAdmin">BigQuery Resource Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceEditor">BigQuery Resource Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceViewer">BigQuery Resource Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.user">BigQuery User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.reservations.listFailoverDatasets" class="permission-name add-link" data-text="bigquery.reservations.listFailoverDatasets" tabindex="-1"><code translate="no" dir="ltr">bigquery.reservations.listFailoverDatasets</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceAdmin">BigQuery Resource Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceEditor">BigQuery Resource Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceViewer">BigQuery Resource Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.user">BigQuery User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.reservations.setIamPolicy" class="permission-name add-link" data-text="bigquery.reservations.setIamPolicy" tabindex="-1"><code translate="no" dir="ltr">bigquery.reservations.setIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceAdmin">BigQuery Resource Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.reservations.update" class="permission-name add-link" data-text="bigquery.reservations.update" tabindex="-1"><code translate="no" dir="ltr">bigquery.reservations.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceAdmin">BigQuery Resource Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceEditor">BigQuery Resource Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.reservations.use" class="permission-name add-link" data-text="bigquery.reservations.use" tabindex="-1"><code translate="no" dir="ltr">bigquery.reservations.use</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceAdmin">BigQuery Resource Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.resourceEditor">BigQuery Resource Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.resourceEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.user">BigQuery User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.routines.create" class="permission-name add-link" data-text="bigquery.routines.create" tabindex="-1"><code translate="no" dir="ltr">bigquery.routines.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataEditor">BigQuery Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.storageDataOwner">Dataplex Storage Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.storageDataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.routines.delete" class="permission-name add-link" data-text="bigquery.routines.delete" tabindex="-1"><code translate="no" dir="ltr">bigquery.routines.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataEditor">BigQuery Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.storageDataOwner">Dataplex Storage Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.storageDataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.routines.get" class="permission-name add-link" data-text="bigquery.routines.get" tabindex="-1"><code translate="no" dir="ltr">bigquery.routines.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataEditor">BigQuery Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataViewer">BigQuery Data Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.metadataViewer">BigQuery Metadata Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.metadataViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.admin">Data Catalog Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.editor">Data Catalog Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.viewer">Data Catalog Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.routineAdmin">BigQuery Authorized Routine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.routineAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.routineDataEditor">BigQuery Authorized Routine Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.routineDataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.routineDataViewer">BigQuery Authorized Routine Data Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.routineDataViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.routineMetadataViewer">BigQuery Authorized Routine Metadata Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.routineMetadataViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.securityAdmin">BigQuery Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.storageDataOwner">Dataplex Storage Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.storageDataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.storageDataReader">Dataplex Storage Data Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.storageDataReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datastream#datastream.serviceAgent">Datastream Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datastream.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.routines.list" class="permission-name add-link" data-text="bigquery.routines.list" tabindex="-1"><code translate="no" dir="ltr">bigquery.routines.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataEditor">BigQuery Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataViewer">BigQuery Data Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.metadataViewer">BigQuery Metadata Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.metadataViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.user">BigQuery User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.routineAdmin">BigQuery Authorized Routine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.routineAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.routineDataEditor">BigQuery Authorized Routine Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.routineDataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.routineDataViewer">BigQuery Authorized Routine Data Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.routineDataViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.routineMetadataViewer">BigQuery Authorized Routine Metadata Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.routineMetadataViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.securityAdmin">BigQuery Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.storageDataOwner">Dataplex Storage Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.storageDataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.storageDataReader">Dataplex Storage Data Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.storageDataReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datastream#datastream.serviceAgent">Datastream Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datastream.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.routines.update" class="permission-name add-link" data-text="bigquery.routines.update" tabindex="-1"><code translate="no" dir="ltr">bigquery.routines.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataEditor">BigQuery Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.storageDataOwner">Dataplex Storage Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.storageDataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.routines.updateTag" class="permission-name add-link" data-text="bigquery.routines.updateTag" tabindex="-1"><code translate="no" dir="ltr">bigquery.routines.updateTag</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataEditor">BigQuery Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.admin">Data Catalog Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.tagEditor">Data Catalog Tag Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.tagEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.rowAccessPolicies.create" class="permission-name add-link" data-text="bigquery.rowAccessPolicies.create" tabindex="-1"><code translate="no" dir="ltr">bigquery.rowAccessPolicies.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.securityAdmin">BigQuery Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.rowAccessPolicies.delete" class="permission-name add-link" data-text="bigquery.rowAccessPolicies.delete" tabindex="-1"><code translate="no" dir="ltr">bigquery.rowAccessPolicies.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.securityAdmin">BigQuery Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.rowAccessPolicies.get" class="permission-name add-link" data-text="bigquery.rowAccessPolicies.get" tabindex="-1"><code translate="no" dir="ltr">bigquery.rowAccessPolicies.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.securityAdmin">BigQuery Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.rowAccessPolicies.getFilteredData" class="permission-name add-link" data-text="bigquery.rowAccessPolicies.getFilteredData" tabindex="-1"><code translate="no" dir="ltr">bigquery.rowAccessPolicies.getFilteredData</code></h4></td>
<td><p><a href="/iam/docs/roles-permissions/bigquery#bigquery.filteredDataViewer">BigQuery Filtered Data Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.filteredDataViewer</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.rowAccessPolicies.getIamPolicy" class="permission-name add-link" data-text="bigquery.rowAccessPolicies.getIamPolicy" tabindex="-1"><code translate="no" dir="ltr">bigquery.rowAccessPolicies.getIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.securityAdmin">BigQuery Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.rowAccessPolicies.list" class="permission-name add-link" data-text="bigquery.rowAccessPolicies.list" tabindex="-1"><code translate="no" dir="ltr">bigquery.rowAccessPolicies.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.securityAdmin">BigQuery Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.rowAccessPolicies.overrideTimeTravelRestrictions" class="permission-name add-link" data-text="bigquery.rowAccessPolicies.overrideTimeTravelRestrictions" tabindex="-1"><code translate="no" dir="ltr">bigquery.rowAccessPolicies.overrideTimeTravelRestrictions</code></h4></td>
<td><p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.rowAccessPolicies.setIamPolicy" class="permission-name add-link" data-text="bigquery.rowAccessPolicies.setIamPolicy" tabindex="-1"><code translate="no" dir="ltr">bigquery.rowAccessPolicies.setIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.securityAdmin">BigQuery Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.rowAccessPolicies.update" class="permission-name add-link" data-text="bigquery.rowAccessPolicies.update" tabindex="-1"><code translate="no" dir="ltr">bigquery.rowAccessPolicies.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.securityAdmin">BigQuery Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.savedqueries.create" class="permission-name add-link" data-text="bigquery.savedqueries.create" tabindex="-1"><code translate="no" dir="ltr">bigquery.savedqueries.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.savedqueries.delete" class="permission-name add-link" data-text="bigquery.savedqueries.delete" tabindex="-1"><code translate="no" dir="ltr">bigquery.savedqueries.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.savedqueries.get" class="permission-name add-link" data-text="bigquery.savedqueries.get" tabindex="-1"><code translate="no" dir="ltr">bigquery.savedqueries.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.user">BigQuery User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.savedqueries.list" class="permission-name add-link" data-text="bigquery.savedqueries.list" tabindex="-1"><code translate="no" dir="ltr">bigquery.savedqueries.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.user">BigQuery User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.savedqueries.update" class="permission-name add-link" data-text="bigquery.savedqueries.update" tabindex="-1"><code translate="no" dir="ltr">bigquery.savedqueries.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.tables.create" class="permission-name add-link" data-text="bigquery.tables.create" tabindex="-1"><code translate="no" dir="ltr">bigquery.tables.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataEditor">BigQuery Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.routineAdmin">BigQuery Authorized Routine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.routineAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.routineDataEditor">BigQuery Authorized Routine Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.routineDataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.storageDataOwner">Dataplex Storage Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.storageDataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/datastream#datastream.bigqueryWriter">Datastream Bigquery Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/datastream.bigqueryWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.batchPredictionServiceAgent">Vertex AI Batch Prediction Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.batchPredictionServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.customCodeServiceAgent">Vertex AI Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.customCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.modelMonitoringServiceAgent">Vertex AI Model Monitoring Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.modelMonitoringServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.ragServiceAgent">Vertex AI RAG Data Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.ragServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.tuningServiceAgent">Vertex AI Tuning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.tuningServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/automl#automl.serviceAgent">AutoML Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.serviceAgent">Recommendations AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/bigquery#bigquery.connectedSheetsServiceAgent">Connected Sheets Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.connectedSheetsServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ces#ces.serviceAgent">Customer Engagement Suite Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ces.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.serviceAgent">Chronicle Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudasset#cloudasset.serviceAgent">Cloud Asset Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudasset.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/contactcenterinsights#contactcenterinsights.serviceAgent">Contact Center AI Insights Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/contactcenterinsights.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datalabeling#datalabeling.serviceAgent">Data Labeling Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datalabeling.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datastream#datastream.serviceAgent">Datastream Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datastream.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datastudio#datastudio.managedStorageServiceAgent">Data Studio Managed Storage Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datastudio.managedStorageServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dialogflow#dialogflow.serviceAgent">Dialogflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dialogflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.serviceAgent">Discovery Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/enterpriseknowledgegraph#enterpriseknowledgegraph.serviceAgent">Enterprise Knowledge Graph Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/enterpriseknowledgegraph.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasecrash#firebasecrashlytics.serviceAgent">Firebase Crashlytics Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasecrashlytics.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/looker#looker.serviceAgent">(Legacy) Looker Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/looker.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/retail#retail.serviceAgent">Retail Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/retail.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/spectrumsas#spectrumsas.serviceAgent">Spectrum SAS Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/spectrumsas.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visionai#visionai.serviceAgent">Cloud Vision AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visionai.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.tables.createIndex" class="permission-name add-link" data-text="bigquery.tables.createIndex" tabindex="-1"><code translate="no" dir="ltr">bigquery.tables.createIndex</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataEditor">BigQuery Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.tables.createSnapshot" class="permission-name add-link" data-text="bigquery.tables.createSnapshot" tabindex="-1"><code translate="no" dir="ltr">bigquery.tables.createSnapshot</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataEditor">BigQuery Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataViewer">BigQuery Data Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.storageDataOwner">Dataplex Storage Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.storageDataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.batchPredictionServiceAgent">Vertex AI Batch Prediction Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.batchPredictionServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.ragServiceAgent">Vertex AI RAG Data Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.ragServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/looker#looker.serviceAgent">(Legacy) Looker Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/looker.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.tables.createTagBinding" class="permission-name add-link" data-text="bigquery.tables.createTagBinding" tabindex="-1"><code translate="no" dir="ltr">bigquery.tables.createTagBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.securityAdmin">BigQuery Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dspm#dspm.serviceAgent">DSPM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.tables.delete" class="permission-name add-link" data-text="bigquery.tables.delete" tabindex="-1"><code translate="no" dir="ltr">bigquery.tables.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataEditor">BigQuery Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.routineAdmin">BigQuery Authorized Routine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.routineAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.routineDataEditor">BigQuery Authorized Routine Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.routineDataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.storageDataOwner">Dataplex Storage Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.storageDataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.tuningServiceAgent">Vertex AI Tuning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.tuningServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.serviceAgent">Chronicle Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudasset#cloudasset.serviceAgent">Cloud Asset Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudasset.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datastudio#datastudio.managedStorageServiceAgent">Data Studio Managed Storage Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datastudio.managedStorageServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.tables.deleteIndex" class="permission-name add-link" data-text="bigquery.tables.deleteIndex" tabindex="-1"><code translate="no" dir="ltr">bigquery.tables.deleteIndex</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataEditor">BigQuery Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.tables.deleteSnapshot" class="permission-name add-link" data-text="bigquery.tables.deleteSnapshot" tabindex="-1"><code translate="no" dir="ltr">bigquery.tables.deleteSnapshot</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.storageDataOwner">Dataplex Storage Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.storageDataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.batchPredictionServiceAgent">Vertex AI Batch Prediction Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.batchPredictionServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.ragServiceAgent">Vertex AI RAG Data Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.ragServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.tables.deleteTagBinding" class="permission-name add-link" data-text="bigquery.tables.deleteTagBinding" tabindex="-1"><code translate="no" dir="ltr">bigquery.tables.deleteTagBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.securityAdmin">BigQuery Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dspm#dspm.serviceAgent">DSPM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.tables.export" class="permission-name add-link" data-text="bigquery.tables.export" tabindex="-1"><code translate="no" dir="ltr">bigquery.tables.export</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataEditor">BigQuery Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataViewer">BigQuery Data Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.storageDataOwner">Dataplex Storage Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.storageDataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.storageDataReader">Dataplex Storage Data Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.storageDataReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.batchPredictionServiceAgent">Vertex AI Batch Prediction Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.batchPredictionServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.customCodeServiceAgent">Vertex AI Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.customCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.modelMonitoringServiceAgent">Vertex AI Model Monitoring Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.modelMonitoringServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.ragServiceAgent">Vertex AI RAG Data Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.ragServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/automl#automl.serviceAgent">AutoML Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.serviceAgent">Recommendations AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.serviceAgent">Discovery Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/looker#looker.serviceAgent">(Legacy) Looker Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/looker.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/retail#retail.serviceAgent">Retail Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/retail.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visionai#visionai.serviceAgent">Cloud Vision AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visionai.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.tables.get" class="permission-name add-link" data-text="bigquery.tables.get" tabindex="-1"><code translate="no" dir="ltr">bigquery.tables.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataEditor">BigQuery Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataViewer">BigQuery Data Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.metadataViewer">BigQuery Metadata Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.metadataViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.admin">Data Catalog Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.editor">Data Catalog Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.viewer">Data Catalog Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.routineAdmin">BigQuery Authorized Routine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.routineAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.routineDataEditor">BigQuery Authorized Routine Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.routineDataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.routineDataViewer">BigQuery Authorized Routine Data Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.routineDataViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.routineMetadataViewer">BigQuery Authorized Routine Metadata Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.routineMetadataViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.securityAdmin">BigQuery Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.storageDataOwner">Dataplex Storage Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.storageDataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.storageDataReader">Dataplex Storage Data Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.storageDataReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/datastream#datastream.bigqueryWriter">Datastream Bigquery Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/datastream.bigqueryWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.dataSecurityScanner">Wiz Data Security Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.dataSecurityScanner</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.batchPredictionServiceAgent">Vertex AI Batch Prediction Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.batchPredictionServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.customCodeServiceAgent">Vertex AI Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.customCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.modelMonitoringServiceAgent">Vertex AI Model Monitoring Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.modelMonitoringServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.ragServiceAgent">Vertex AI RAG Data Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.ragServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.tuningServiceAgent">Vertex AI Tuning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.tuningServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/automl#automl.serviceAgent">AutoML Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.serviceAgent">Recommendations AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ces#ces.serviceAgent">Customer Engagement Suite Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ces.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.serviceAgent">Chronicle Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudasset#cloudasset.serviceAgent">Cloud Asset Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudasset.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/contactcenterinsights#contactcenterinsights.serviceAgent">Contact Center AI Insights Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/contactcenterinsights.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datalabeling#datalabeling.serviceAgent">Data Labeling Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datalabeling.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datastream#datastream.serviceAgent">Datastream Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datastream.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dialogflow#dialogflow.serviceAgent">Dialogflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dialogflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.serviceAgent">Discovery Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/enterpriseknowledgegraph#enterpriseknowledgegraph.serviceAgent">Enterprise Knowledge Graph Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/enterpriseknowledgegraph.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasecrash#firebasecrashlytics.serviceAgent">Firebase Crashlytics Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasecrashlytics.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/looker#looker.serviceAgent">(Legacy) Looker Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/looker.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/retail#retail.serviceAgent">Retail Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/retail.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visionai#visionai.serviceAgent">Cloud Vision AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visionai.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.tables.getData" class="permission-name add-link" data-text="bigquery.tables.getData" tabindex="-1"><code translate="no" dir="ltr">bigquery.tables.getData</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataEditor">BigQuery Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataViewer">BigQuery Data Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.routineAdmin">BigQuery Authorized Routine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.routineAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.routineDataEditor">BigQuery Authorized Routine Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.routineDataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.routineDataViewer">BigQuery Authorized Routine Data Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.routineDataViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.storageDataOwner">Dataplex Storage Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.storageDataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.storageDataReader">Dataplex Storage Data Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.storageDataReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/datastream#datastream.bigqueryWriter">Datastream Bigquery Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/datastream.bigqueryWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.dataSecurityScanner">Wiz Data Security Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.dataSecurityScanner</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.batchPredictionServiceAgent">Vertex AI Batch Prediction Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.batchPredictionServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.customCodeServiceAgent">Vertex AI Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.customCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.modelMonitoringServiceAgent">Vertex AI Model Monitoring Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.modelMonitoringServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.ragServiceAgent">Vertex AI RAG Data Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.ragServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.tuningServiceAgent">Vertex AI Tuning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.tuningServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/automl#automl.serviceAgent">AutoML Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.serviceAgent">Recommendations AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ces#ces.serviceAgent">Customer Engagement Suite Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ces.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datalabeling#datalabeling.serviceAgent">Data Labeling Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datalabeling.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datastream#datastream.serviceAgent">Datastream Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datastream.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datastudio#datastudio.managedStorageServiceAgent">Data Studio Managed Storage Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datastudio.managedStorageServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dialogflow#dialogflow.serviceAgent">Dialogflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dialogflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.serviceAgent">Discovery Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dspm#dspm.serviceAgent">DSPM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/enterpriseknowledgegraph#enterpriseknowledgegraph.serviceAgent">Enterprise Knowledge Graph Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/enterpriseknowledgegraph.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasecrash#firebasecrashlytics.serviceAgent">Firebase Crashlytics Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasecrashlytics.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/fleetengine#fleetengine.serviceAgent">FleetEngine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/fleetengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/looker#looker.serviceAgent">(Legacy) Looker Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/looker.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/retail#retail.serviceAgent">Retail Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/retail.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visionai#visionai.serviceAgent">Cloud Vision AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visionai.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.tables.getIamPolicy" class="permission-name add-link" data-text="bigquery.tables.getIamPolicy" tabindex="-1"><code translate="no" dir="ltr">bigquery.tables.getIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataEditor">BigQuery Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataViewer">BigQuery Data Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.metadataViewer">BigQuery Metadata Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.metadataViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.securityAdmin">BigQuery Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.tables.list" class="permission-name add-link" data-text="bigquery.tables.list" tabindex="-1"><code translate="no" dir="ltr">bigquery.tables.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataEditor">BigQuery Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataViewer">BigQuery Data Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.metadataViewer">BigQuery Metadata Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.metadataViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.user">BigQuery User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.routineAdmin">BigQuery Authorized Routine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.routineAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.routineDataEditor">BigQuery Authorized Routine Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.routineDataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.routineDataViewer">BigQuery Authorized Routine Data Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.routineDataViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.routineMetadataViewer">BigQuery Authorized Routine Metadata Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.routineMetadataViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.securityAdmin">BigQuery Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.storageDataOwner">Dataplex Storage Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.storageDataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.storageDataReader">Dataplex Storage Data Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.storageDataReader</code>)</p>
<p><a href="/iam/docs/roles-permissions/datastream#datastream.bigqueryWriter">Datastream Bigquery Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/datastream.bigqueryWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.dataSecurityScanner">Wiz Data Security Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.dataSecurityScanner</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.tuningServiceAgent">Vertex AI Tuning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.tuningServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.serviceAgent">Recommendations AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datastream#datastream.serviceAgent">Datastream Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datastream.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datastudio#datastudio.managedStorageServiceAgent">Data Studio Managed Storage Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datastudio.managedStorageServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.serviceAgent">Discovery Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dspm#dspm.serviceAgent">DSPM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/enterpriseknowledgegraph#enterpriseknowledgegraph.serviceAgent">Enterprise Knowledge Graph Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/enterpriseknowledgegraph.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/looker#looker.serviceAgent">(Legacy) Looker Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/looker.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/retail#retail.serviceAgent">Retail Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/retail.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.tables.listEffectiveTags" class="permission-name add-link" data-text="bigquery.tables.listEffectiveTags" tabindex="-1"><code translate="no" dir="ltr">bigquery.tables.listEffectiveTags</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagViewer">Tag Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.securityAdmin">BigQuery Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dspm#dspm.serviceAgent">DSPM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.tables.listTagBindings" class="permission-name add-link" data-text="bigquery.tables.listTagBindings" tabindex="-1"><code translate="no" dir="ltr">bigquery.tables.listTagBindings</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagViewer">Tag Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.securityAdmin">BigQuery Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dspm#dspm.serviceAgent">DSPM Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dspm.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.tables.replicateData" class="permission-name add-link" data-text="bigquery.tables.replicateData" tabindex="-1"><code translate="no" dir="ltr">bigquery.tables.replicateData</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataEditor">BigQuery Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataViewer">BigQuery Data Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.siteReliabilityEngineer">Site Reliability Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.siteReliabilityEngineer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.tables.restoreSnapshot" class="permission-name add-link" data-text="bigquery.tables.restoreSnapshot" tabindex="-1"><code translate="no" dir="ltr">bigquery.tables.restoreSnapshot</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataEditor">BigQuery Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.storageDataOwner">Dataplex Storage Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.storageDataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.batchPredictionServiceAgent">Vertex AI Batch Prediction Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.batchPredictionServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.ragServiceAgent">Vertex AI RAG Data Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.ragServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.tables.setCategory" class="permission-name add-link" data-text="bigquery.tables.setCategory" tabindex="-1"><code translate="no" dir="ltr">bigquery.tables.setCategory</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.tables.setColumnDataPolicy" class="permission-name add-link" data-text="bigquery.tables.setColumnDataPolicy" tabindex="-1"><code translate="no" dir="ltr">bigquery.tables.setColumnDataPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.securityAdmin">BigQuery Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.tables.setIamPolicy" class="permission-name add-link" data-text="bigquery.tables.setIamPolicy" tabindex="-1"><code translate="no" dir="ltr">bigquery.tables.setIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.securityAdmin">BigQuery Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.tables.update" class="permission-name add-link" data-text="bigquery.tables.update" tabindex="-1"><code translate="no" dir="ltr">bigquery.tables.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataEditor">BigQuery Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.routineAdmin">BigQuery Authorized Routine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.routineAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.routineDataEditor">BigQuery Authorized Routine Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.routineDataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.securityAdmin">BigQuery Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.storageDataOwner">Dataplex Storage Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.storageDataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/datastream#datastream.bigqueryWriter">Datastream Bigquery Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/datastream.bigqueryWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.batchPredictionServiceAgent">Vertex AI Batch Prediction Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.batchPredictionServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.customCodeServiceAgent">Vertex AI Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.customCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.modelMonitoringServiceAgent">Vertex AI Model Monitoring Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.modelMonitoringServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.ragServiceAgent">Vertex AI RAG Data Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.ragServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.tuningServiceAgent">Vertex AI Tuning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.tuningServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/automl#automl.serviceAgent">AutoML Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.serviceAgent">Recommendations AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/bigquery#bigquery.connectedSheetsServiceAgent">Connected Sheets Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.connectedSheetsServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ces#ces.serviceAgent">Customer Engagement Suite Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ces.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.serviceAgent">Chronicle Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudasset#cloudasset.serviceAgent">Cloud Asset Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudasset.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/contactcenterinsights#contactcenterinsights.serviceAgent">Contact Center AI Insights Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/contactcenterinsights.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datastream#datastream.serviceAgent">Datastream Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datastream.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datastudio#datastudio.managedStorageServiceAgent">Data Studio Managed Storage Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datastudio.managedStorageServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.serviceAgent">Discovery Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/enterpriseknowledgegraph#enterpriseknowledgegraph.serviceAgent">Enterprise Knowledge Graph Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/enterpriseknowledgegraph.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasecrash#firebasecrashlytics.serviceAgent">Firebase Crashlytics Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasecrashlytics.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/retail#retail.serviceAgent">Retail Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/retail.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visionai#visionai.serviceAgent">Cloud Vision AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visionai.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.tables.updateData" class="permission-name add-link" data-text="bigquery.tables.updateData" tabindex="-1"><code translate="no" dir="ltr">bigquery.tables.updateData</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataEditor">BigQuery Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.routineAdmin">BigQuery Authorized Routine Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.routineAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.routineDataEditor">BigQuery Authorized Routine Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.routineDataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.storageDataOwner">Dataplex Storage Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.storageDataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataplex#dataplex.storageDataWriter">Dataplex Storage Data Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.storageDataWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/datastream#datastream.bigqueryWriter">Datastream Bigquery Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/datastream.bigqueryWriter</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.batchPredictionServiceAgent">Vertex AI Batch Prediction Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.batchPredictionServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.customCodeServiceAgent">Vertex AI Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.customCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.modelMonitoringServiceAgent">Vertex AI Model Monitoring Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.modelMonitoringServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.ragServiceAgent">Vertex AI RAG Data Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.ragServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.tuningServiceAgent">Vertex AI Tuning Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.tuningServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/automl#automl.serviceAgent">AutoML Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/automl.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.serviceAgent">Recommendations AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/bigquery#bigquery.connectedSheetsServiceAgent">Connected Sheets Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.connectedSheetsServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/bigqueryomni#bigqueryomni.serviceAgent">BigQuery Omni Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/bigqueryomni.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ces#ces.serviceAgent">Customer Engagement Suite Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ces.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.serviceAgent">Chronicle Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudasset#cloudasset.serviceAgent">Cloud Asset Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudasset.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/contactcenterinsights#contactcenterinsights.serviceAgent">Contact Center AI Insights Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/contactcenterinsights.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datastream#datastream.serviceAgent">Datastream Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datastream.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datastudio#datastudio.managedStorageServiceAgent">Data Studio Managed Storage Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datastudio.managedStorageServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dialogflow#dialogflow.serviceAgent">Dialogflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dialogflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/discoveryengine#discoveryengine.serviceAgent">Discovery Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/discoveryengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/enterpriseknowledgegraph#enterpriseknowledgegraph.serviceAgent">Enterprise Knowledge Graph Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/enterpriseknowledgegraph.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasecrash#firebasecrashlytics.serviceAgent">Firebase Crashlytics Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasecrashlytics.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/retail#retail.serviceAgent">Retail Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/retail.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/spectrumsas#spectrumsas.serviceAgent">Spectrum SAS Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/spectrumsas.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/visionai#visionai.serviceAgent">Cloud Vision AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/visionai.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.tables.updateIndex" class="permission-name add-link" data-text="bigquery.tables.updateIndex" tabindex="-1"><code translate="no" dir="ltr">bigquery.tables.updateIndex</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataEditor">BigQuery Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.tables.updateTag" class="permission-name add-link" data-text="bigquery.tables.updateTag" tabindex="-1"><code translate="no" dir="ltr">bigquery.tables.updateTag</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataEditor">BigQuery Data Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.dataOwner">BigQuery Data Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.dataOwner</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.admin">Data Catalog Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.securityAdmin">BigQuery Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/datacatalog#datacatalog.tagEditor">Data Catalog Tag Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/datacatalog.tagEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.mlEngineer">ML Engineer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.mlEngineer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datafusion#datafusion.serviceAgent">Cloud Data Fusion API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datafusion.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dlp#dlp.serviceAgent">DLP API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="bigquery.transfers.get" class="permission-name add-link" data-text="bigquery.transfers.get" tabindex="-1"><code translate="no" dir="ltr">bigquery.transfers.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.user">BigQuery User</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.user</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.managementServiceAgent">Firebase Service Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.managementServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="bigquery.transfers.update" class="permission-name add-link" data-text="bigquery.transfers.update" tabindex="-1"><code translate="no" dir="ltr">bigquery.transfers.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.admin">BigQuery Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquery#bigquery.studioAdmin">BigQuery Studio Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquery.studioAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/bigquerydatapolicy#bigquerydatapolicy.editor">BigQuery Data Policy Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatapolicy.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.managementServiceAgent">Firebase Service Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.managementServiceAgent</code>)</li>
</ul></td>
</tr>
</tbody>
</table>

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
