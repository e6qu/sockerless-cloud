# Set maximum retries for jobs

<div class="devsite-article-body clearfix">

A Cloud Run job consists of one or more tasks. The maximum retries setting specifies the number of times a task is allowed to restart in case of failure before being failed permanently. The default is 3.

This setting applies per-task, not per-job. If you set this to 0, tasks only run once and are not retried on failure.

## Required roles

To get the permissions that you need to configure Cloud Run jobs, ask your administrator to grant you the following IAM roles:

- [Cloud Run Developer](/iam/docs/roles-permissions/run#run.developer) (`roles/run.developer`) on the Cloud Run job
- [Service Account User](/iam/docs/roles-permissions/iam#iam.serviceAccountUser) (`roles/iam.serviceAccountUser`) on the service identity

For a list of IAM roles and permissions that are associated with Cloud Run, see [Cloud Run IAM roles](/run/docs/reference/iam/roles) and [Cloud Run IAM permissions](/run/docs/reference/iam/permissions). If your Cloud Run job interfaces with Google Cloud APIs, such as Cloud Client Libraries, see the [service identity configuration guide](/run/docs/configuring/jobs/service-identity). For more information about granting roles, see [deployment permissions](/run/docs/reference/iam/roles#additional-configuration) and [manage access](/iam/docs/granting-changing-revoking-access).

## Configure maximum retries

You can configure maximum retries for a Cloud Run job using the Google Cloud console, the gcloud CLI, YAML, or Terraform:

<div>

<div class="section">

### Console

1.  In the Google Cloud console, go to the Cloud Run page:

    <a href="https://console.cloud.google.com/run" class="button button-primary" target="console" data-track-type="howto" data-track-name="consoleLink" data-track-metadata-end-goal="configureCloudRun">Go to Cloud Run</a>

2.  Select **Jobs** from the Cloud Run navigation menu:

    1.  If you are creating a new job, click **Deploy container** to fill out the initial job settings page.

    2.  If you are configuring an existing job, select the job, then click **View and edit job configuration**.

3.  Click **Containers, Connections, Security** to expand the job properties page.

4.  In the **Task capacity** section, specify the number of retries using an integer from `0` to `10`.

5.  Click **Create** or **Update**.

</div>

<div class="section">

### gcloud

- To [set maximum retries](/sdk/gcloud/reference/run/jobs/create) when you create a new job, run the following command:

  <div>

  </div>

  ``` devsite-click-to-copy
  gcloud run jobs create JOB --image IMAGE_URL --max-retries RETRY
  ```

  Replace the following:

  - `JOB`: the name of your Cloud Run job.
  - `IMAGE_URL`: a reference to the [container image](/run/docs/building/containers)—for example, `us-docker.pkg.dev/cloudrun/container/job:latest`.
  - `RETRY`: the number of retries. Specify an integer from `0` to `10`.

- To [update maximum retries](/sdk/gcloud/reference/run/jobs/update) for an existing job, run the following command:

  <div>

  </div>

  ``` devsite-click-to-copy
  gcloud run jobs update JOB --max-retries RETRY
  ```

</div>

<div class="section">

### YAML

1.  If you are creating a new job, skip this step. If you are updating an existing job, download its [YAML configuration](/run/docs/reference/yaml/v1#job):

    <div>

    </div>

    ``` devsite-click-to-copy
    gcloud run jobs describe JOB --format export > job.yaml
    ```

2.  Update the `maxRetries:` attribute:

    <div>

    </div>

    ``` devsite-click-to-copy
    apiVersion: run.googleapis.com/v1
    kind: Job
    metadata:
      name: JOB
    spec:
      template:
        spec:
          template:
            spec:
              containers:
              - image: IMAGE_URL
              maxRetries: RETRY
    ```

    Replace the following:

    - `JOB`: the name of your Cloud Run job.
    - `IMAGE_URL`: a reference to the [container image](/run/docs/building/containers)—for example, `us-docker.pkg.dev/cloudrun/container/job:latest`.
    - `RETRY`: the number of retries. Specify an integer from `0` to `10`.

3.  Create or update the job using the following command:

    <div>

    </div>

    ``` devsite-click-to-copy
    gcloud run jobs replace job.yaml
    ```

    The `gcloud run jobs replace` command defaults to using `job.yaml` file if present.

</div>

<div class="section">

### Terraform

To learn how to apply or remove a Terraform configuration, see [Basic Terraform commands](/docs/terraform/basic-commands).

Add the following to a [`google_cloud_run_v2_job`](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/cloud_run_v2_job) resource in your Terraform configuration:  

<div class="github-docwidget-gitinclude-code">

<div>

</div>

``` devsite-click-to-copy
resource "google_cloud_run_v2_job" "default" {
  name     = "cloud-run-job-retries"
  location = "us-central1"

  deletion_protection = false # set to "true" in production

  template {
    template {
      max_retries = 3

      containers {
        image = "us-docker.pkg.dev/cloudrun/container/job:latest"
      }
    }
  }
}
```

</div>

</div>

</div>

## View maximum retries settings

To view the current maximum retries settings for your Cloud Run job, use the Google Cloud console or the Google Cloud CLI:

<div>

<div class="section">

### Console

1.  In the Google Cloud console, go to the Cloud Run jobs page:

    <a href="https://console.cloud.google.com/run/jobs" class="button button-primary" target="console" data-track-type="howto" data-track-name="consoleLink" data-track-metadata-end-goal="configureCloudRun">Go to Cloud Run jobs</a>

2.  Click the job to open the **Job details** page.

3.  Click **View and edit job configuration**.

4.  Locate the maximum retries setting in the configuration details.

</div>

<div class="section">

### gcloud

1.  Run the following command:

    <div>

    </div>

    ``` devsite-click-to-copy
    gcloud run jobs describe JOB
    ```

2.  Locate the maximum retries setting in the returned configuration.

</div>

</div>

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
