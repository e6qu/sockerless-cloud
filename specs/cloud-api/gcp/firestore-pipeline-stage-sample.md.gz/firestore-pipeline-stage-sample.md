# Sample (Transformation Stage)

<div class="devsite-article-body clearfix devsite-no-page-title">

# Sample (Transformation Stage)

## Description

Returns a non-deterministic sample from the results of the previous stage.

There are two supported modes:

- `documents`: pick `n` documents randomly.
- `percent`: pick `n` percent of documents randomly.

## Examples

<div class="ds-selector-tabs" ds-scope="lang">

<div class="section">

### <span class="two-line-tab"><span tab-label="modular API"></span>Web</span>

<div>

</div>

``` devsite-click-to-copy
let results;

// Get a sample of 100 documents in a database
results = await execute(db.pipeline()
  .database()
  .sample(100)
);

// Randomly shuffle a list of 3 documents
results = await execute(db.pipeline()
  .documents([
    doc(db, "cities", "SF"),
    doc(db, "cities", "NY"),
    doc(db, "cities", "DC"),
  ])
  .sample(3)
);test.firestore.js
```

</div>

<div class="section">

##### Swift

<div>

</div>

``` devsite-click-to-copy
var results: Pipeline.Snapshot

// Get a sample of 100 documents in a database
results = try await db.pipeline()
  .database()
  .sample(count: 100)
  .execute()

// Randomly shuffle a list of 3 documents
results = try await db.pipeline()
  .documents([
    db.collection("cities").document("SF"),
    db.collection("cities").document("NY"),
    db.collection("cities").document("DC"),
  ])
  .sample(count: 3)
  .execute()PipelineSnippets.swift
```

</div>

<div class="section">

##### <span class="two-line-tab">Kotlin <span class="firebase-platform-label">Android</span></span>

<div>

</div>

``` devsite-click-to-copy
var results: Task<Pipeline.Snapshot>

// Get a sample of 100 documents in a database
results = db.pipeline()
    .database()
    .sample(100)
    .execute()

// Randomly shuffle a list of 3 documents
results = db.pipeline()
    .documents(
        db.collection("cities").document("SF"),
        db.collection("cities").document("NY"),
        db.collection("cities").document("DC")
    )
    .sample(3)
    .execute()DocSnippets.kt
```

</div>

<div class="section">

##### <span class="two-line-tab">Java <span class="firebase-platform-label">Android</span></span>

<div>

</div>

``` devsite-click-to-copy
Task<Pipeline.Snapshot> results;

// Get a sample of 100 documents in a database
results = db.pipeline()
    .database()
    .sample(100)
    .execute();

// Randomly shuffle a list of 3 documents
results = db.pipeline()
    .documents(
        db.collection("cities").document("SF"),
        db.collection("cities").document("NY"),
        db.collection("cities").document("DC")
    )
    .sample(3)
    .execute();DocSnippets.java
```

</div>

<div class="section">

##### Python

<div>

</div>

``` devsite-click-to-copy
# Get a sample of 100 documents in a database
results = client.pipeline().database().sample(100).execute()

# Randomly shuffle a list of 3 documents
results = (
    client.pipeline()
    .documents(
        client.collection("cities").document("SF"),
        client.collection("cities").document("NY"),
        client.collection("cities").document("DC"),
    )
    .sample(3)
    .execute()
)firestore_pipelines.py
```

</div>

<div class="section">

##### Java

<div>

</div>

``` devsite-click-to-copy
// Get a sample of 100 documents in a database
Pipeline.Snapshot results1 = firestore.pipeline().database().sample(100).execute().get();

// Randomly shuffle a list of 3 documents
Pipeline.Snapshot results2 =
    firestore
        .pipeline()
        .documents(
            firestore.collection("cities").document("SF"),
            firestore.collection("cities").document("NY"),
            firestore.collection("cities").document("DC"))
        .sample(3)
        .execute()
        .get();PipelineSnippets.java
```

</div>

<div class="section">

##### Go

<div>

</div>

``` devsite-click-to-copy
// Get a sample of 100 documents in a database
results1, err := client.Pipeline().Database().Sample(firestore.WithDocLimit(100)).Execute(ctx).Results().GetAll()
if err != nil {
 fmt.Fprintf(w, "GetAll failed: %v", err)
 return err
}

// Randomly shuffle a list of 3 documents
results2, err := client.Pipeline().
 Documents([]*firestore.DocumentRef{
     client.Collection("cities").Doc("SF"),
     client.Collection("cities").Doc("NY"),
     client.Collection("cities").Doc("DC"),
 }).
 Sample(firestore.WithDocLimit(3)).
 Execute(ctx).Results().GetAll()
if err != nil {
 fmt.Fprintf(w, "GetAll failed: %v", err)
 return err
}pipeline_snippets_general.go
```

</div>

</div>

## Modes

### Documents Mode

The `documents` mode picks up to `n` documents randomly from its input, where each document (along with the order of documents) is equally as likely to be chosen. To achieve this, Firestore needs to still scan and process all documents so this can still end up being an expensive operation.

For example, for the following collection:

<div>

<div class="section">

### Node.js

<div>

</div>

``` devsite-click-to-copy
await db.collection("cities").doc("SF").set({name: "San Francsico", state: "California"});
await db.collection("cities").doc("NYC").set({name: "New York City", state: "New York"});
await db.collection("cities").doc("CHI").set({name: "Chicago", state: "Illinois"});
```

</div>

</div>

The sample stage in document mode can be used to retrieve a non-deterministic subset of results from this collection.

<div>

<div class="section">

### Node.js

<div>

</div>

``` devsite-click-to-copy
const sampled = await db.pipeline()
    .collection("/cities")
    .sample(1)
    .execute();
```

</div>

</div>

In this example, only 1 document at random would be returned at random.

<div>

</div>

``` devsite-click-to-copy
  { name: "New York City", state: "New York" }
```

If the supplied number is greater than the total number of documents returned, all documents are returned in a random order.

<div>

<div class="section">

### Node.js

<div>

</div>

``` devsite-click-to-copy
const sampled = await db.pipeline()
    .collection("/cities")
    .sample(5)
    .execute();
```

</div>

</div>

This will result in the following documents:

<div>

</div>

``` devsite-click-to-copy
  { name: "New York City", state: "New York" }
  { name: "Chicago", state: "Illinois" }
  { name: "San Francisco", state: "California" }
```

### Percent Mode

The `percent` mode attempts to pick `n` percent of all documents from its input. This results in the stage producing approximately `# documents * percent / 100` documents. Just like in `documents` mode, Firestore ensures that each document is equally as likely to be returned. This does require that Firestore needs to scan and process all documents so this can still end up being an expensive operation, even when the result set is small.

Unlike `documents` mode, the order here is not random and instead preserves the pre-existing document order. This percent input must be a double value between `0.0` and `1.0`.

For example, for the following collection:

<div>

<div class="section">

### Node.js

<div>

</div>

``` devsite-click-to-copy
await db.collection("cities").doc("SF").set({name: "San Francsico", state: "California"});
await db.collection("cities").doc("NYC").set({name: "New York City", state: "New York"});
await db.collection("cities").doc("CHI").set({name: "Chicago", state: "Illinois"});
await db.collection("cities").doc("ATL").set({name: "Atlanta", state: "Georgia"});
```

</div>

</div>

The sample stage in percent mode can be used to retrieve (on average) 50% of the documents from the [`collection(...)`](/firestore/native/docs/pipeline/stages/input/collection) stage.

<div>

<div class="section">

### Node.js

<div>

</div>

``` devsite-click-to-copy
  const sampled = await db.pipeline()
    .collection("/cities")
    .sample({ percent: 0.5 })
    .execute();
```

</div>

</div>

This will result in a non-deterministic sample of (on average) 50% of documents from the `cities` collection. The following is one possible output.

<div>

</div>

``` devsite-click-to-copy
  { name: "New York City", state: "New York" }
  { name: "Chicago", state: "Illinois" }
```

In percent mode, because each document has the same probability of being selected, it is possible for no documents or all documents to be returned.

#### Client examples

<div class="ds-selector-tabs" ds-scope="lang">

<div class="section">

### <span class="two-line-tab"><span tab-label="modular API"></span>Web</span>

<div>

</div>

``` devsite-click-to-copy
// Get a sample of on average 50% of the documents in the database
const results = await execute(db.pipeline()
  .database()
  .sample({ percentage: 0.5 })
);test.firestore.js
```

</div>

<div class="section">

##### Swift

<div>

</div>

``` devsite-click-to-copy
// Get a sample of on average 50% of the documents in the database
let results = try await db.pipeline()
  .database()
  .sample(percentage: 0.5)
  .execute()PipelineSnippets.swift
```

</div>

<div class="section">

##### <span class="two-line-tab">Kotlin <span class="firebase-platform-label">Android</span></span>

<div>

</div>

``` devsite-click-to-copy
// Get a sample of on average 50% of the documents in the database
val results = db.pipeline()
    .database()
    .sample(SampleStage.withPercentage(0.5))
    .execute()DocSnippets.kt
```

</div>

<div class="section">

##### <span class="two-line-tab">Java <span class="firebase-platform-label">Android</span></span>

<div>

</div>

``` devsite-click-to-copy
// Get a sample of on average 50% of the documents in the database
Task<Pipeline.Snapshot> results = db.pipeline()
    .database()
    .sample(SampleStage.withPercentage(0.5))
    .execute();DocSnippets.java
```

</div>

<div class="section">

##### Python

<div>

</div>

``` devsite-click-to-copy
from google.cloud.firestore_v1.pipeline_stages import SampleOptions

# Get a sample of on average 50% of the documents in the database
results = (
    client.pipeline().database().sample(SampleOptions.percentage(0.5)).execute()
)firestore_pipelines.py
```

</div>

<div class="section">

##### Java

<div>

</div>

``` devsite-click-to-copy
// Get a sample of on average 50% of the documents in the database
Pipeline.Snapshot results =
    firestore.pipeline().database().sample(Sample.withPercentage(0.5)).execute().get();PipelineSnippets.java
```

</div>

<div class="section">

##### Go

<div>

</div>

``` devsite-click-to-copy
// Get a sample of on average 50% of the documents in the database
snapshot := client.Pipeline().
 Database().
 Sample(firestore.WithPercentage(0.5)).
 Execute(ctx)pipeline_snippets_general.go
```

</div>

</div>

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
