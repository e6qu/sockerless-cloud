# Union (Transformation Stage)

<div class="devsite-article-body clearfix devsite-no-page-title">

# Union (Transformation Stage)

## Description

Merges the documents from another pipeline with those in the current pipeline.

## Examples

<div class="ds-selector-tabs" ds-scope="lang">

<div class="section">

##### Node.js

<div>

</div>

``` devsite-click-to-copy
  const results = await db.pipeline()
    .collection("cities/SF/restaurants")
    .where(eq("type", "chinese"))
    .union(db.pipeline()
      .collection("cities/NYC/restaurants")
      .where(eq("type", "italian")))
    .where(gte("rating", 4.5))
    .execute();
    
```

</div>

<div class="section">

### <span class="two-line-tab"><span tab-label="modular API"></span>Web</span>

<div>

</div>

``` devsite-click-to-copy
const results = await execute(db.pipeline()
  .collection("cities/SF/restaurants")
  .where(field("type").equal("Chinese"))
  .union(db.pipeline()
    .collection("cities/NY/restaurants")
    .where(field("type").equal("Italian")))
  .where(field("rating").greaterThanOrEqual(4.5))
  .sort(field("__name__").descending())
);test.firestore.js
```

</div>

<div class="section">

##### Swift

<div>

</div>

``` devsite-click-to-copy
let results = try await db.pipeline()
  .collection("cities/SF/restaurants")
  .where(Field("type").equal("Chinese"))
  .union(with: db.pipeline()
    .collection("cities/NY/restaurants")
    .where(Field("type").equal("Italian")))
  .where(Field("rating").greaterThanOrEqual(4.5))
  .sort([Field("__name__").descending()])
  .execute()PipelineSnippets.swift
```

</div>

<div class="section">

##### <span class="two-line-tab">Kotlin <span class="firebase-platform-label">Android</span></span>

<div>

</div>

``` devsite-click-to-copy
val results = db.pipeline()
    .collection("cities/SF/restaurants")
    .where(field("type").equal("Chinese"))
    .union(db.pipeline()
        .collection("cities/NY/restaurants")
        .where(field("type").equal("Italian")))
    .where(field("rating").greaterThanOrEqual(4.5))
    .sort(field("__name__").descending())
    .execute()DocSnippets.kt
```

</div>

<div class="section">

##### <span class="two-line-tab">Java <span class="firebase-platform-label">Android</span></span>

<div>

</div>

``` devsite-click-to-copy
Task<Pipeline.Snapshot> results = db.pipeline()
    .collection("cities/SF/restaurants")
    .where(field("type").equal("Chinese"))
    .union(db.pipeline()
        .collection("cities/NY/restaurants")
        .where(field("type").equal("Italian")))
    .where(field("rating").greaterThanOrEqual(4.5))
    .sort(field("__name__").descending())
    .execute();DocSnippets.java
```

</div>

<div class="section">

##### Python

<div>

</div>

``` devsite-click-to-copy
from google.cloud.firestore_v1.pipeline_expressions import Field

results = (
    client.pipeline()
    .collection("cities/SF/restaurants")
    .where(Field.of("type").equal("Chinese"))
    .union(
        client.pipeline()
        .collection("cities/NY/restaurants")
        .where(Field.of("type").equal("Italian"))
    )
    .where(Field.of("rating").greater_than_or_equal(4.5))
    .sort(Field.of("__name__").descending())
    .execute()
)firestore_pipelines.py
```

</div>

<div class="section">

##### Java

<div>

</div>

``` devsite-click-to-copy
Pipeline.Snapshot results =
    firestore
        .pipeline()
        .collection("cities/SF/restaurants")
        .where(field("type").equal("Chinese"))
        .union(
            firestore
                .pipeline()
                .collection("cities/NY/restaurants")
                .where(field("type").equal("Italian")))
        .where(field("rating").greaterThanOrEqual(4.5))
        .sort(descending(field("__name__")))
        .execute()
        .get();PipelineSnippets.java
```

</div>

<div class="section">

##### Go

<div>

</div>

``` devsite-click-to-copy
snapshot := client.Pipeline().
 Collection("cities/SF/restaurants").
 Where(firestore.FieldOf("type").Equal("Chinese")).
 Union(
     client.Pipeline().
         Collection("cities/NY/restaurants").
         Where(firestore.FieldOf("type").Equal("Italian")),
 ).
 Where(firestore.FieldOf("rating").GreaterThanOrEqual(4.5)).
 Sort(firestore.Orders(firestore.Descending(firestore.FieldOf("__name__")))).
 Execute(ctx)pipeline_snippets_general.go
```

</div>

</div>

## Behavior

This stage runs multiple pipelines in parallel and concatenates the results together.

### Non-Deterministic Order of Results

The order in which results are combined between the two pipelines is non-deterministic. Any perceived order is unstable and shouldn't be relied upon. A following [`sort(...)`](/firestore/native/docs/pipeline/stages/transformation/sort) stage can be added if a stable order is required.

<div class="ds-selector-tabs" ds-scope="lang">

<div class="section">

##### Node.js

<div>

</div>

``` devsite-click-to-copy
  const results = await db.pipeline()
    .collection("cities/SF/restaurants")
    .where(eq("type", "chinese"))
    .union(db.pipeline()
      .collection("cities/NYC/restaurants")
      .where(eq("type", "italian")))
    .where(gte("rating", 4.5))
    .sort(Field.of("__name__"))
    .execute();
    
```

</div>

<div class="section">

##### <span class="two-line-tab">Kotlin <span class="firebase-platform-label">Android</span></span>

<div>

</div>

``` devsite-click-to-copy
val results = db.pipeline()
    .collection("cities/SF/restaurants")
    .where(field("type").equal("Chinese"))
    .union(db.pipeline()
        .collection("cities/NY/restaurants")
        .where(field("type").equal("Italian")))
    .where(field("rating").greaterThanOrEqual(4.5))
    .sort(field("__name__").descending())
    .execute()DocSnippets.kt
```

</div>

<div class="section">

##### <span class="two-line-tab">Java <span class="firebase-platform-label">Android</span></span>

<div>

</div>

``` devsite-click-to-copy
Task<Pipeline.Snapshot> results = db.pipeline()
    .collection("cities/SF/restaurants")
    .where(field("type").equal("Chinese"))
    .union(db.pipeline()
        .collection("cities/NY/restaurants")
        .where(field("type").equal("Italian")))
    .where(field("rating").greaterThanOrEqual(4.5))
    .sort(field("__name__").descending())
    .execute();DocSnippets.java
```

</div>

<div class="section">

##### Python

<div>

</div>

``` devsite-click-to-copy
from google.cloud.firestore_v1.pipeline_expressions import Field

results = (
    client.pipeline()
    .collection("cities/SF/restaurants")
    .where(Field.of("type").equal("Chinese"))
    .union(
        client.pipeline()
        .collection("cities/NY/restaurants")
        .where(Field.of("type").equal("Italian"))
    )
    .where(Field.of("rating").greater_than_or_equal(4.5))
    .sort(Field.of("__name__").descending())
    .execute()
)firestore_pipelines.py
```

</div>

<div class="section">

##### Java

<div>

</div>

``` devsite-click-to-copy
Pipeline.Snapshot results =
    firestore
        .pipeline()
        .collection("cities/SF/restaurants")
        .where(field("type").equal("Chinese"))
        .union(
            firestore
                .pipeline()
                .collection("cities/NY/restaurants")
                .where(field("type").equal("Italian")))
        .where(field("rating").greaterThanOrEqual(4.5))
        .sort(descending(field("__name__")))
        .execute()
        .get();PipelineSnippets.java
```

</div>

<div class="section">

##### Go

<div>

</div>

``` devsite-click-to-copy
snapshot := client.Pipeline().
 Collection("cities/SF/restaurants").
 Where(firestore.FieldOf("type").Equal("Chinese")).
 Union(
     client.Pipeline().
         Collection("cities/NY/restaurants").
         Where(firestore.FieldOf("type").Equal("Italian")),
 ).
 Where(firestore.FieldOf("rating").GreaterThanOrEqual(4.5)).
 Sort(firestore.Orders(firestore.Descending(firestore.FieldOf("__name__")))).
 Execute(ctx)pipeline_snippets_general.go
```

</div>

</div>

### Duplicate Results

The `union(...)` stage does not deduplicate results. A following [`distinct(...)`](/firestore/native/docs/pipeline/stages/transformation/distinct) or [`aggregate(...)`](/firestore/native/docs/pipeline/stages/transformation/aggregate) stage can be added if duplicate results need to be removed.

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
