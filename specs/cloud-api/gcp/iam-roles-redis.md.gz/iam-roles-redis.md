# Memorystore for Redis roles and permissions

<div class="devsite-article-body clearfix">

This page lists the IAM roles and permissions for Memorystore for Redis. To search through all roles and permissions, see the [role and permission index](/iam/docs/roles-permissions).

## Memorystore for Redis roles

<div results-count-container="">

</div>

<table class="fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="50%">Role</th>
<th>Permissions</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td class="role-description"><h4 id="redis.admin" class="role-title add-link" data-text="Cloud Memorystore Redis Admin " tabindex="-1">Cloud Memorystore Redis Admin</h4>
<p>(<code translate="no" dir="ltr">roles/redis.admin</code>)</p>
<span class="role-description"> </span>
<p>Full access to Redis instances and related resources.</p></td>
<td class="role-permissions"><p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudkms.keyHandles.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudkms.keyHandles.create</code></li>
<li><code translate="no" dir="ltr">cloudkms.keyHandles.get</code></li>
<li><code translate="no" dir="ltr">cloudkms.keyHandles.list</code></li>
</ul>
<p><code translate="no" dir="ltr">cloudkms.operations.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.projects.showEffectiveAutokeyConfig</code></p>
<p><code translate="no" dir="ltr">compute.networks.list</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.serviceConnectionPolicies.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">redis.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">redis.aclPolicies.create</code></li>
<li><code translate="no" dir="ltr">redis.aclPolicies.delete</code></li>
<li><code translate="no" dir="ltr">redis.aclPolicies.get</code></li>
<li><code translate="no" dir="ltr">redis.aclPolicies.list</code></li>
<li><code translate="no" dir="ltr">redis.aclPolicies.update</code></li>
<li><code translate="no" dir="ltr">redis.backupCollections.create</code></li>
<li><code translate="no" dir="ltr">redis.backupCollections.delete</code></li>
<li><code translate="no" dir="ltr">redis.backupCollections.get</code></li>
<li><code translate="no" dir="ltr">redis.backupCollections.list</code></li>
<li><code translate="no" dir="ltr">redis.backups.create</code></li>
<li><code translate="no" dir="ltr">redis.backups.delete</code></li>
<li><code translate="no" dir="ltr">redis.backups.export</code></li>
<li><code translate="no" dir="ltr">redis.backups.get</code></li>
<li><code translate="no" dir="ltr">redis.backups.list</code></li>
<li><code translate="no" dir="ltr">redis.clusters.backup</code></li>
<li><code translate="no" dir="ltr">redis.clusters.connect</code></li>
<li><code translate="no" dir="ltr">redis.clusters.create</code></li>
<li><code translate="no" dir="ltr">redis.clusters.createTagBinding</code></li>
<li><code translate="no" dir="ltr">redis.clusters.delete</code></li>
<li><code translate="no" dir="ltr">redis.clusters.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">redis.clusters.get</code></li>
<li><code translate="no" dir="ltr">redis.clusters.list</code></li>
<li><code translate="no" dir="ltr">redis.clusters.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">redis.clusters.listTagBindings</code></li>
<li><code translate="no" dir="ltr">redis.clusters.rescheduleMaintenance</code></li>
<li><code translate="no" dir="ltr">redis.clusters.update</code></li>
<li><code translate="no" dir="ltr">redis.instances.create</code></li>
<li><code translate="no" dir="ltr">redis.instances.createTagBinding</code></li>
<li><code translate="no" dir="ltr">redis.instances.delete</code></li>
<li><code translate="no" dir="ltr">redis.instances.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">redis.instances.export</code></li>
<li><code translate="no" dir="ltr">redis.instances.failover</code></li>
<li><code translate="no" dir="ltr">redis.instances.get</code></li>
<li><code translate="no" dir="ltr">redis.instances.getAuthString</code></li>
<li><code translate="no" dir="ltr">redis.instances.import</code></li>
<li><code translate="no" dir="ltr">redis.instances.list</code></li>
<li><code translate="no" dir="ltr">redis.instances.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">redis.instances.listTagBindings</code></li>
<li><code translate="no" dir="ltr">redis.instances.rescheduleMaintenance</code></li>
<li><code translate="no" dir="ltr">redis.instances.update</code></li>
<li><code translate="no" dir="ltr">redis.instances.updateAuth</code></li>
<li><code translate="no" dir="ltr">redis.instances.upgrade</code></li>
<li><code translate="no" dir="ltr">redis.locations.get</code></li>
<li><code translate="no" dir="ltr">redis.locations.list</code></li>
<li><code translate="no" dir="ltr">redis.operations.cancel</code></li>
<li><code translate="no" dir="ltr">redis.operations.delete</code></li>
<li><code translate="no" dir="ltr">redis.operations.get</code></li>
<li><code translate="no" dir="ltr">redis.operations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.use</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="redis.editor" class="role-title add-link" data-text="Cloud Memorystore Redis Editor " tabindex="-1">Cloud Memorystore Redis Editor</h4>
<p>(<code translate="no" dir="ltr">roles/redis.editor</code>)</p>
<span class="role-description"> </span>
<p>Read-Write access to Redis instances and related resources.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">compute.networks.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">redis.aclPolicies.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">redis.aclPolicies.create</code></li>
<li><code translate="no" dir="ltr">redis.aclPolicies.delete</code></li>
<li><code translate="no" dir="ltr">redis.aclPolicies.get</code></li>
<li><code translate="no" dir="ltr">redis.aclPolicies.list</code></li>
<li><code translate="no" dir="ltr">redis.aclPolicies.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">redis.backupCollections.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">redis.backupCollections.create</code></li>
<li><code translate="no" dir="ltr">redis.backupCollections.delete</code></li>
<li><code translate="no" dir="ltr">redis.backupCollections.get</code></li>
<li><code translate="no" dir="ltr">redis.backupCollections.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">redis.backups.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">redis.backups.create</code></li>
<li><code translate="no" dir="ltr">redis.backups.delete</code></li>
<li><code translate="no" dir="ltr">redis.backups.export</code></li>
<li><code translate="no" dir="ltr">redis.backups.get</code></li>
<li><code translate="no" dir="ltr">redis.backups.list</code></li>
</ul>
<p><code translate="no" dir="ltr">redis.clusters.backup</code></p>
<p><code translate="no" dir="ltr">redis.clusters.connect</code></p>
<p><code translate="no" dir="ltr">redis.clusters.create</code></p>
<p><code translate="no" dir="ltr">redis.clusters.delete</code></p>
<p><code translate="no" dir="ltr">redis.clusters.get</code></p>
<p><code translate="no" dir="ltr">redis.clusters.list</code></p>
<p><code translate="no" dir="ltr">redis.clusters.rescheduleMaintenance</code></p>
<p><code translate="no" dir="ltr">redis.clusters.update</code></p>
<p><code translate="no" dir="ltr">redis.instances.create</code></p>
<p><code translate="no" dir="ltr">redis.instances.delete</code></p>
<p><code translate="no" dir="ltr">redis.instances.export</code></p>
<p><code translate="no" dir="ltr">redis.instances.failover</code></p>
<p><code translate="no" dir="ltr">redis.instances.get</code></p>
<p><code translate="no" dir="ltr">redis.instances.import</code></p>
<p><code translate="no" dir="ltr">redis.instances.list</code></p>
<p><code translate="no" dir="ltr">redis.instances.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">redis.instances.listTagBindings</code></p>
<p><code translate="no" dir="ltr">redis.instances.rescheduleMaintenance</code></p>
<p><code translate="no" dir="ltr">redis.instances.update</code></p>
<p><code translate="no" dir="ltr">redis.instances.updateAuth</code></p>
<p><code translate="no" dir="ltr">redis.instances.upgrade</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">redis.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">redis.locations.get</code></li>
<li><code translate="no" dir="ltr">redis.locations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">redis.operations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">redis.operations.cancel</code></li>
<li><code translate="no" dir="ltr">redis.operations.delete</code></li>
<li><code translate="no" dir="ltr">redis.operations.get</code></li>
<li><code translate="no" dir="ltr">redis.operations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.use</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="redis.viewer" class="role-title add-link" data-text="Cloud Memorystore Redis Viewer " tabindex="-1">Cloud Memorystore Redis Viewer</h4>
<p>(<code translate="no" dir="ltr">roles/redis.viewer</code>)</p>
<span class="role-description"> </span>
<p>Read-only access to Redis instances and related resources.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">redis.aclPolicies.get</code></p>
<p><code translate="no" dir="ltr">redis.aclPolicies.list</code></p>
<p><code translate="no" dir="ltr">redis.backupCollections.get</code></p>
<p><code translate="no" dir="ltr">redis.backupCollections.list</code></p>
<p><code translate="no" dir="ltr">redis.backups.get</code></p>
<p><code translate="no" dir="ltr">redis.backups.list</code></p>
<p><code translate="no" dir="ltr">redis.clusters.get</code></p>
<p><code translate="no" dir="ltr">redis.clusters.list</code></p>
<p><code translate="no" dir="ltr">redis.clusters.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">redis.clusters.listTagBindings</code></p>
<p><code translate="no" dir="ltr">redis.instances.get</code></p>
<p><code translate="no" dir="ltr">redis.instances.list</code></p>
<p><code translate="no" dir="ltr">redis.instances.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">redis.instances.listTagBindings</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">redis.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">redis.locations.get</code></li>
<li><code translate="no" dir="ltr">redis.locations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">redis.operations.get</code></p>
<p><code translate="no" dir="ltr">redis.operations.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.use</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="redis.dbConnectionUser" class="role-title add-link" data-text="Cloud Memorystore Redis Db Connection User Beta " tabindex="-1">Cloud Memorystore Redis Db Connection User <sup>Beta</sup></h4>
<p>(<code translate="no" dir="ltr">roles/redis.dbConnectionUser</code>)</p>
<span class="role-description"> </span>
<p>Access to connecting to Redis Server db.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">redis.clusters.connect</code></p></td>
</tr>
</tbody>
</table>

### Service agent roles

Service agent roles should only be granted to [service agents](/iam/docs/service-agents).

<div results-count-container="">

</div>

<table class="fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="50%">Role</th>
<th>Permissions</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td class="role-description"><h4 id="redis.serviceAgent" class="role-title add-link" data-text="Cloud Memorystore Redis Service Agent " tabindex="-1">Cloud Memorystore Redis Service Agent</h4>
<p>(<code translate="no" dir="ltr">roles/redis.serviceAgent</code>)</p>
<span class="role-description"> </span>
<p>Gives Cloud Memorystore Redis service account access to managed resource</p>
<strong>Warning:</strong> Do not grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.</td>
<td class="role-permissions"><p><code translate="no" dir="ltr">compute.globalOperations.get</code></p>
<p><code translate="no" dir="ltr">compute.networks.addPeering</code></p>
<p><code translate="no" dir="ltr">compute.networks.get</code></p>
<p><code translate="no" dir="ltr">compute.networks.removePeering</code></p>
<p><code translate="no" dir="ltr">compute.networks.update</code></p>
<p><code translate="no" dir="ltr">compute.projects.get</code></p>
<p><code translate="no" dir="ltr">compute.routes.get</code></p>
<p><code translate="no" dir="ltr">compute.routes.list</code></p>
<p><code translate="no" dir="ltr">compute.subnetworks.get</code></p>
<p><code translate="no" dir="ltr">compute.subnetworks.list</code></p>
<p><code translate="no" dir="ltr">monitoring.metricDescriptors.create</code></p>
<p><code translate="no" dir="ltr">monitoring.metricDescriptors.get</code></p>
<p><code translate="no" dir="ltr">monitoring.metricDescriptors.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">monitoring.monitoredResourceDescriptors.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">monitoring.monitoredResourceDescriptors.get</code></li>
<li><code translate="no" dir="ltr">monitoring.monitoredResourceDescriptors.list</code></li>
</ul>
<p><code translate="no" dir="ltr">monitoring.timeSeries.create</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
</tbody>
</table>

## Memorystore for Redis permissions

<div results-count-container="">

</div>

<table class="permissions-table fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="45%">Permission</th>
<th>Included in roles</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td><h4 id="redis.aclPolicies.create" class="permission-name add-link" data-text="redis.aclPolicies.create" tabindex="-1"><code translate="no" dir="ltr">redis.aclPolicies.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.editor">Cloud Memorystore Redis Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="redis.aclPolicies.delete" class="permission-name add-link" data-text="redis.aclPolicies.delete" tabindex="-1"><code translate="no" dir="ltr">redis.aclPolicies.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.editor">Cloud Memorystore Redis Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="redis.aclPolicies.get" class="permission-name add-link" data-text="redis.aclPolicies.get" tabindex="-1"><code translate="no" dir="ltr">redis.aclPolicies.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.editor">Cloud Memorystore Redis Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.viewer">Cloud Memorystore Redis Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="redis.aclPolicies.list" class="permission-name add-link" data-text="redis.aclPolicies.list" tabindex="-1"><code translate="no" dir="ltr">redis.aclPolicies.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.editor">Cloud Memorystore Redis Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.viewer">Cloud Memorystore Redis Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="redis.aclPolicies.update" class="permission-name add-link" data-text="redis.aclPolicies.update" tabindex="-1"><code translate="no" dir="ltr">redis.aclPolicies.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.editor">Cloud Memorystore Redis Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="redis.backupCollections.create" class="permission-name add-link" data-text="redis.backupCollections.create" tabindex="-1"><code translate="no" dir="ltr">redis.backupCollections.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.editor">Cloud Memorystore Redis Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="redis.backupCollections.delete" class="permission-name add-link" data-text="redis.backupCollections.delete" tabindex="-1"><code translate="no" dir="ltr">redis.backupCollections.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.editor">Cloud Memorystore Redis Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="redis.backupCollections.get" class="permission-name add-link" data-text="redis.backupCollections.get" tabindex="-1"><code translate="no" dir="ltr">redis.backupCollections.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.editor">Cloud Memorystore Redis Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.viewer">Cloud Memorystore Redis Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="redis.backupCollections.list" class="permission-name add-link" data-text="redis.backupCollections.list" tabindex="-1"><code translate="no" dir="ltr">redis.backupCollections.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.editor">Cloud Memorystore Redis Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.viewer">Cloud Memorystore Redis Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="redis.backups.create" class="permission-name add-link" data-text="redis.backups.create" tabindex="-1"><code translate="no" dir="ltr">redis.backups.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.editor">Cloud Memorystore Redis Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="redis.backups.delete" class="permission-name add-link" data-text="redis.backups.delete" tabindex="-1"><code translate="no" dir="ltr">redis.backups.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.editor">Cloud Memorystore Redis Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="redis.backups.export" class="permission-name add-link" data-text="redis.backups.export" tabindex="-1"><code translate="no" dir="ltr">redis.backups.export</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.editor">Cloud Memorystore Redis Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="redis.backups.get" class="permission-name add-link" data-text="redis.backups.get" tabindex="-1"><code translate="no" dir="ltr">redis.backups.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.editor">Cloud Memorystore Redis Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.viewer">Cloud Memorystore Redis Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="redis.backups.list" class="permission-name add-link" data-text="redis.backups.list" tabindex="-1"><code translate="no" dir="ltr">redis.backups.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.editor">Cloud Memorystore Redis Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.viewer">Cloud Memorystore Redis Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="redis.clusters.backup" class="permission-name add-link" data-text="redis.clusters.backup" tabindex="-1"><code translate="no" dir="ltr">redis.clusters.backup</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.editor">Cloud Memorystore Redis Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="redis.clusters.connect" class="permission-name add-link" data-text="redis.clusters.connect" tabindex="-1"><code translate="no" dir="ltr">redis.clusters.connect</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.editor">Cloud Memorystore Redis Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.dbConnectionUser">Cloud Memorystore Redis Db Connection User</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.dbConnectionUser</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="redis.clusters.create" class="permission-name add-link" data-text="redis.clusters.create" tabindex="-1"><code translate="no" dir="ltr">redis.clusters.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.editor">Cloud Memorystore Redis Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="redis.clusters.createTagBinding" class="permission-name add-link" data-text="redis.clusters.createTagBinding" tabindex="-1"><code translate="no" dir="ltr">redis.clusters.createTagBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="redis.clusters.delete" class="permission-name add-link" data-text="redis.clusters.delete" tabindex="-1"><code translate="no" dir="ltr">redis.clusters.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.editor">Cloud Memorystore Redis Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="redis.clusters.deleteTagBinding" class="permission-name add-link" data-text="redis.clusters.deleteTagBinding" tabindex="-1"><code translate="no" dir="ltr">redis.clusters.deleteTagBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="redis.clusters.get" class="permission-name add-link" data-text="redis.clusters.get" tabindex="-1"><code translate="no" dir="ltr">redis.clusters.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.editor">Cloud Memorystore Redis Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.viewer">Cloud Memorystore Redis Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="redis.clusters.list" class="permission-name add-link" data-text="redis.clusters.list" tabindex="-1"><code translate="no" dir="ltr">redis.clusters.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.editor">Cloud Memorystore Redis Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.viewer">Cloud Memorystore Redis Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="redis.clusters.listEffectiveTags" class="permission-name add-link" data-text="redis.clusters.listEffectiveTags" tabindex="-1"><code translate="no" dir="ltr">redis.clusters.listEffectiveTags</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.viewer">Cloud Memorystore Redis Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagViewer">Tag Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="redis.clusters.listTagBindings" class="permission-name add-link" data-text="redis.clusters.listTagBindings" tabindex="-1"><code translate="no" dir="ltr">redis.clusters.listTagBindings</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.viewer">Cloud Memorystore Redis Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagViewer">Tag Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="redis.clusters.rescheduleMaintenance" class="permission-name add-link" data-text="redis.clusters.rescheduleMaintenance" tabindex="-1"><code translate="no" dir="ltr">redis.clusters.rescheduleMaintenance</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.editor">Cloud Memorystore Redis Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="redis.clusters.update" class="permission-name add-link" data-text="redis.clusters.update" tabindex="-1"><code translate="no" dir="ltr">redis.clusters.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.editor">Cloud Memorystore Redis Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="redis.instances.create" class="permission-name add-link" data-text="redis.instances.create" tabindex="-1"><code translate="no" dir="ltr">redis.instances.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.editor">Cloud Memorystore Redis Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="redis.instances.createTagBinding" class="permission-name add-link" data-text="redis.instances.createTagBinding" tabindex="-1"><code translate="no" dir="ltr">redis.instances.createTagBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="redis.instances.delete" class="permission-name add-link" data-text="redis.instances.delete" tabindex="-1"><code translate="no" dir="ltr">redis.instances.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.editor">Cloud Memorystore Redis Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="redis.instances.deleteTagBinding" class="permission-name add-link" data-text="redis.instances.deleteTagBinding" tabindex="-1"><code translate="no" dir="ltr">redis.instances.deleteTagBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="redis.instances.export" class="permission-name add-link" data-text="redis.instances.export" tabindex="-1"><code translate="no" dir="ltr">redis.instances.export</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.editor">Cloud Memorystore Redis Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="redis.instances.failover" class="permission-name add-link" data-text="redis.instances.failover" tabindex="-1"><code translate="no" dir="ltr">redis.instances.failover</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.editor">Cloud Memorystore Redis Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="redis.instances.get" class="permission-name add-link" data-text="redis.instances.get" tabindex="-1"><code translate="no" dir="ltr">redis.instances.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.editor">Cloud Memorystore Redis Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.viewer">Cloud Memorystore Redis Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/runapps#runapps.serviceAgent">Serverless Integrations Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/runapps.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="redis.instances.getAuthString" class="permission-name add-link" data-text="redis.instances.getAuthString" tabindex="-1"><code translate="no" dir="ltr">redis.instances.getAuthString</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="redis.instances.import" class="permission-name add-link" data-text="redis.instances.import" tabindex="-1"><code translate="no" dir="ltr">redis.instances.import</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.editor">Cloud Memorystore Redis Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="redis.instances.list" class="permission-name add-link" data-text="redis.instances.list" tabindex="-1"><code translate="no" dir="ltr">redis.instances.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.editor">Cloud Memorystore Redis Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.viewer">Cloud Memorystore Redis Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/runapps#runapps.serviceAgent">Serverless Integrations Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/runapps.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="redis.instances.listEffectiveTags" class="permission-name add-link" data-text="redis.instances.listEffectiveTags" tabindex="-1"><code translate="no" dir="ltr">redis.instances.listEffectiveTags</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.editor">Cloud Memorystore Redis Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.viewer">Cloud Memorystore Redis Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagViewer">Tag Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="redis.instances.listTagBindings" class="permission-name add-link" data-text="redis.instances.listTagBindings" tabindex="-1"><code translate="no" dir="ltr">redis.instances.listTagBindings</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.editor">Cloud Memorystore Redis Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.viewer">Cloud Memorystore Redis Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagViewer">Tag Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="redis.instances.rescheduleMaintenance" class="permission-name add-link" data-text="redis.instances.rescheduleMaintenance" tabindex="-1"><code translate="no" dir="ltr">redis.instances.rescheduleMaintenance</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.editor">Cloud Memorystore Redis Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="redis.instances.update" class="permission-name add-link" data-text="redis.instances.update" tabindex="-1"><code translate="no" dir="ltr">redis.instances.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.editor">Cloud Memorystore Redis Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="redis.instances.updateAuth" class="permission-name add-link" data-text="redis.instances.updateAuth" tabindex="-1"><code translate="no" dir="ltr">redis.instances.updateAuth</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.editor">Cloud Memorystore Redis Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="redis.instances.upgrade" class="permission-name add-link" data-text="redis.instances.upgrade" tabindex="-1"><code translate="no" dir="ltr">redis.instances.upgrade</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.editor">Cloud Memorystore Redis Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="redis.locations.get" class="permission-name add-link" data-text="redis.locations.get" tabindex="-1"><code translate="no" dir="ltr">redis.locations.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.editor">Cloud Memorystore Redis Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.viewer">Cloud Memorystore Redis Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="redis.locations.list" class="permission-name add-link" data-text="redis.locations.list" tabindex="-1"><code translate="no" dir="ltr">redis.locations.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.editor">Cloud Memorystore Redis Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.viewer">Cloud Memorystore Redis Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="redis.operations.cancel" class="permission-name add-link" data-text="redis.operations.cancel" tabindex="-1"><code translate="no" dir="ltr">redis.operations.cancel</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.editor">Cloud Memorystore Redis Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="redis.operations.delete" class="permission-name add-link" data-text="redis.operations.delete" tabindex="-1"><code translate="no" dir="ltr">redis.operations.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.editor">Cloud Memorystore Redis Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="redis.operations.get" class="permission-name add-link" data-text="redis.operations.get" tabindex="-1"><code translate="no" dir="ltr">redis.operations.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.editor">Cloud Memorystore Redis Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.viewer">Cloud Memorystore Redis Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="redis.operations.list" class="permission-name add-link" data-text="redis.operations.list" tabindex="-1"><code translate="no" dir="ltr">redis.operations.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.admin">Cloud Memorystore Redis Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.editor">Cloud Memorystore Redis Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/redis#redis.viewer">Cloud Memorystore Redis Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/redis.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
</tbody>
</table>

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
