# Export and import using CSV files

<div class="devsite-article-body clearfix">

<div class="nocontent" style="font-size:medium; margin-bottom:40px; border-top:1px solid black;">

<div style="float:right">

<span style="font-weight:bold">MySQL</span> <span style="color:light-gray">  \|  </span><a href="/sql/docs/postgres/import-export/import-export-csv" data-track-type="sqlSwitcher" data-track-name="postgresLink" title="View this page for the PostgreSQL database engine">PostgreSQL</a> <span style="color:light-gray">  \|  </span><span style="color:lightgray" title="This page is not available for the SQL Server database engine">SQL Server</span>

</div>

</div>

This page describes exporting and importing data into Cloud SQL instances using CSV files.

**Note:** If you're migrating an entire database from a supported database server (on-premises, in AWS, or Cloud SQL) to a new Cloud SQL instance, you can use the [Database Migration Service](/database-migration/docs) instead of exporting and then importing files. If you're exporting because you want to create a new instance from the exported file, consider [restoring from a backup to a different instance](/sql/docs/mysql/backup-recovery/restoring#restorebackups-another-instance) or [cloning the instance](/sql/docs/mysql/clone-instance).

You can cancel the import of data into Cloud SQL instances and the export of data from the instances. This data is contained in CSV files. For more information about cancelling an import or export operation, see [Cancel the import and export of data](/sql/docs/mysql/import-export/cancel-import-export).

## Before you begin

Before you begin an export or import operation:

- Ensure that your database has adequate free space.
- [Verify](/sql/docs/mysql/import-export#verify) that the CSV file has the expected data and that it's in the correct format. CSV files must have one line for each row of data fields.
- Follow the [best practices for exporting and importing data.](/sql/docs/mysql/import-export)

## Export data from Cloud SQL for MySQL

### Required roles and permissions for exporting from Cloud SQL for MySQL

To export data from Cloud SQL into Cloud Storage, the user initiating the export must have one of the following roles:

- The [Cloud SQL Editor](/sql/docs/mysql/iam-roles) role
- A [custom role](/iam/docs/understanding-custom-roles), including the following permissions:
  - `cloudsql.instances.get`
  - `cloudsql.instances.export`

Additionally, the service account for the Cloud SQL instance must have one of the following roles:

- The `storage.objectAdmin` Identity and Access Management (IAM) role
- A custom role, including the following permissions:
  - `storage.objects.create`
  - `storage.objects.list` (for exporting files in parallel only)
  - `storage.objects.delete` (for exporting files in parallel only)

For help with IAM roles, see <a href="/storage/docs/access-control/iam" target="_blank">Identity and Access Management</a>.

**Note**: The changes that you make to the IAM permissions and roles might take a few minutes to take effect. For more information, see [Access change propagation](/iam/docs/access-change-propagation).

### Export data to a CSV file from Cloud SQL for MySQL

You can export your data in CSV format, which is usable by other tools and environments. Exports happen at the database level. During a CSV export, you can specify the schemas to export. All schemas at the database level are eligible for export.

**Note:** Cloud SQL uses double quotes (hex value "22") as the default escape character. This can be a problem for databases where values for `NULL` are entered as string literals. When importing a file that was exported using the default escape character, the file doesn't treat the value as `NULL` but as `"NULL"`. We recommend that you use `--escape="5C"` to override the default when you export the file.

To export data from a database on a Cloud SQL instance to a CSV file in a Cloud Storage bucket:

<div id="export-database-dump" class="ds-selector-tabs" ds-scope="code-sample">

<div class="section">

### Console

1.  In the Google Cloud console, go to the **Cloud SQL Instances** page.

    <a href="https://console.cloud.google.com/sql" class="button button-primary" target="console">Go to Cloud SQL Instances</a>

2.  To open the **Overview** page of an instance, click the instance name.

3.  Click **Export**.

4.  In the **File format** section, click **CSV**.

5.  For **SQL query**, enter a SQL query to specify the table to export data from.

    For example, to export the entire contents of the `entries` table in the `guestbook` database, you enter

    <div>

    </div>

    ``` devsite-click-to-copy
    SELECT * FROM guestbook.entries;
    ```

    Your query must specify a table in the specified database. You can't export an entire database in CSV format.

    **Note:** While in-transit, the query might be processed in intermediate locations other than the location of the target instance

6.  Optional: Select **Offload export to a temporary instance** to allow other operations to occur while the export is ongoing.

7.  Optional: Click **Show database options**, and then select the name of the database from the **Database** drop-down menu.

8.  In the **Destination** section, add the name of the bucket, folder, and file that you want to export to, or click **Browse** to find or create a bucket, folder, or file.

    If you click **Browse**:

    1.  In the **Location** section, select a Cloud Storage bucket or folder for your export.
        **Note:** If you need to create a new storage bucket, click the bucket with the **+** sign in the **Location** section. This opens **Create a bucket**, where you can add a name and other configurations for the bucket. Select a **standard** storage class for your bucket.

    2.  In the **Name** box, add a name for the `CSV` file, or select an existing file from the list in the **Location** section.

        You can use a file extension of `.gz` (the complete extension would be `.csv.gz`) to compress your export file.

    3.  Click **Select**.

9.  Click **Export** to start the export.

</div>

<div class="section">

### gcloud

1.  <a href="/storage/docs/creating-buckets" target="_blank">Create a Cloud Storage bucket.</a>

2.  Upload the file to your bucket.

    For help with uploading files to buckets, see <a href="/storage/docs/uploading-objects" target="_blank">Uploading objects</a>.

3.  Find the service account for the Cloud SQL instance you're exporting from. You can do this running the [`gcloud sql instances describe`](/sdk/gcloud/reference/sql/instances/describe) command. Look for the `serviceAccountEmailAddress` field in the output.

    <div>

    </div>

    ``` devsite-click-to-copy
    gcloud sql instances describe INSTANCE_NAME
    ```

4.  Use ` `[`gcloud storage buckets add-iam-policy-binding`](/sdk/gcloud/reference/storage/buckets/add-iam-policy-binding) to grant the `storage.objectAdmin` <a href="/storage/docs/access-control/iam-roles" target="_blank">IAM role</a> to the Cloud SQL instance service account. For help with setting IAM permissions, see <a href="/storage/docs/access-control/using-iam-permissions" target="_blank">Using IAM permissions</a>.

5.  Export the database:

    **Note:** Use the `--offload` flag if you want to use serverless export. Otherwise, remove it from the following command.

    <div>

    </div>

    ``` devsite-click-to-copy
    gcloud sql export csv INSTANCE_NAME gs://BUCKET_NAME/FILE_NAME \
    --database=DATABASE_NAME \
    --offload \
    --query=SELECT_QUERY
    ```

    For information about using the `export csv` command, see the <a href="/sdk/gcloud/reference/sql/export/csv" target="_blank"><code translate="no" dir="ltr">sql export csv</code></a> command reference page.

    **Note:** While in-transit, the SELECT_QUERY might be processed in intermediate locations other than the location of the target instance.

6.  If you do not need to retain the IAM role you set previously, [revoke](/iam/docs/granting-changing-revoking-access#revoking-console) it now.

</div>

<div class="section">

### REST v1

1.  Create a bucket for the export:

    <div>

    </div>

    ``` devsite-click-to-copy
    gcloud storage buckets create gs://BUCKET_NAME --location=LOCATION_NAME --project=PROJECT_NAME
    ```

    This step is not required, but strongly recommended, so you do not open up access to any other data.

2.  Provide your instance with the `storage.objectAdmin` [IAM role](/storage/docs/access-control/iam-roles) for your bucket. For help with setting IAM permissions, see [Using IAM permissions](/storage/docs/access-control/using-iam-permissions).

3.  Export your database:

    Before using any of the request data, make the following replacements:

    - `project-id`: The project ID
    - `instance-id`: The instance ID
    - `bucket_name`: The Cloud Storage bucket name
    - `path_to_csv_file`: The path to the CSV file
    - `database_name`: The name of a database inside the Cloud SQL instance
    - `offload`: Enables serverless export. Set to `true` to use serverless export.
      **Note:** Serverless export costs extra. See the [pricing page](https://cloud.google.com/sql/pricing#storage-networking-prices).
    - `select_query`: SQL query for export (optional)
      **Note:** While in-transit, the query might be processed in intermediate locations other than the location of the target instance.
    - `escape_character`: The character that should appear before a data character that needs to be escaped. The value of this argument has to be a character in Hex ASCII Code. For example, "22" represents double quotes. (optional)
    - `quote_character`:The character that encloses values from columns that have a string data type. The value of this argument has to be a character in Hex ASCII Code. For example, "22" represents double quotes. (optional)
    - `fields_terminated_by`: The character that split column values. The value of this argument has to be a character in Hex ASCII Code. For example, "2C" represents a comma. (optional)
    - `lines_terminated_by`: The character that split line records. The value of this argument has to be a character in Hex ASCII Code. For example, "0A" represents a new line. (optional)

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    POST https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-id/export
    ```

    </div>

    Request JSON body:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    {
     "exportContext":
       {
          "fileType": "CSV",
          "uri": "gs://bucket_name/path_to_csv_file",
          "databases": "database_name",
          "offload": true | false
          "csvExportOptions":
           {
               "selectQuery":"select_query",
               "escapeCharacter":"escape_character",
               "quoteCharacter":"quote_character",
               "fieldsTerminatedBy":"fields_terminated_by",
               "linesTerminatedBy":"lines_terminated_by"
           }
       }
    }
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Save the request body in a file named `request.json`, and execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X POST \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         -H "Content-Type: application/json; charset=utf-8" \
         -d @request.json \
         "https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-id/export"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Save the request body in a file named `request.json`, and execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method POST `
        -Headers $headers `
        -ContentType: "application/json; charset=utf-8" `
        -InFile request.json `
        -Uri "https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-id/export" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a JSON response similar to the following:

    <div class="section expandable">

    #### Response

    <div>

    </div>

    ``` readonly
    {
      "kind": "sql#operation",
      "targetLink": "https://sqladmin.googleapis.com/v1/projects/project-id/instances/target-instance-id",
      "status": "PENDING",
      "user": "user@example.com",
      "insertTime": "2020-01-21T22:43:37.981Z",
      "operationType": "UPDATE",
      "name": "operation-id",
      "targetId": "instance-id",
      "selfLink": "https://sqladmin.googleapis.com/v1/projects/project-id/operations/operation-id",
      "targetProject": "project-id"
    }
    ```

    </div>

    If your select query specifies a database, it overrides the `databases` property.

4.  If you do not need to retain the IAM permissions you set previously, remove them now.

For the complete list of parameters for the request, see the [instances:export](/sql/docs/mysql/admin-api/rest/v1beta4/instances/export) page.

</div>

<div class="section">

### REST v1beta4

1.  Create a bucket for the export:

    <div>

    </div>

    ``` devsite-click-to-copy
    gcloud storage buckets create gs://BUCKET_NAME --location=LOCATION_NAME --project=PROJECT_NAME
    ```

    This step is not required, but strongly recommended, so you do not open up access to any other data.

2.  Provide your instance with the `storage.objectAdmin` [IAM role](/storage/docs/access-control/iam-roles) for your bucket. For help with setting IAM permissions, see [Using IAM permissions](/storage/docs/access-control/using-iam-permissions).

3.  Export your database:

    Before using any of the request data, make the following replacements:

    - `project-id`: The project ID
    - `instance-id`: The instance ID
    - `bucket_name`: The Cloud Storage bucket name
    - `path_to_csv_file`: The path to the CSV file
    - `database_name`: The name of a database inside the Cloud SQL instance
    - `offload`: Enables serverless export. Set to `true` to use serverless export.
      **Note:** Serverless export costs extra. See the [pricing page](https://cloud.google.com/sql/pricing#storage-networking-prices).
    - `select_query`: SQL query for export (optional)
      **Note:** While in-transit, the query might be processed in intermediate locations other than the location of the target instance.
    - `escape_character`: The character that should appear before a data character that needs to be escaped. The value of this argument must be in [ASCII hex format](https://ascii.cl/). For example, "22" represents double quotes. (optional)
    - `quote_character`: The character that encloses values from columns that have a string data type. The value of this argument must be in [ASCII hex format](https://ascii.cl/). For example, "22" represents double quotes. (optional)
    - `fields_terminated_by`: The character that splits column values. The value of this argument must be in [ASCII hex format](https://ascii.cl/). For example, "2C" represents a comma. (optional)
    - `lines_terminated_by`: The character that split line records. The value of this argument must be in [ASCII hex format](https://ascii.cl/). For example, "0A" represents a new line. (optional)

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    POST https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id/export
    ```

    </div>

    Request JSON body:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    {
     "exportContext":
       {
          "fileType": "CSV",
          "uri": "gs://bucket_name/path_to_csv_file",
          "databases": "database_name",
          "offload": true | false
          "csvExportOptions":
           {
               "selectQuery": "select_query",
               "escapeCharacter":  "escape_character",
               "quoteCharacter": "quote_character",
               "fieldsTerminatedBy": "fields_terminated_by",
               "linesTerminatedBy": "lines_terminated_by"
           }
       }
    }
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Save the request body in a file named `request.json`, and execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X POST \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         -H "Content-Type: application/json; charset=utf-8" \
         -d @request.json \
         "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id/export"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Save the request body in a file named `request.json`, and execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method POST `
        -Headers $headers `
        -ContentType: "application/json; charset=utf-8" `
        -InFile request.json `
        -Uri "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id/export" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a JSON response similar to the following:

    <div class="section expandable">

    #### Response

    <div>

    </div>

    ``` readonly
    {
      "kind": "sql#operation",
      "targetLink": "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/target-instance-id",
      "status": "PENDING",
      "user": "user@example.com",
      "insertTime": "2020-01-21T22:43:37.981Z",
      "operationType": "UPDATE",
      "name": "operation-id",
      "targetId": "instance-id",
      "selfLink": "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/operations/operation-id",
      "targetProject": "project-id"
    }
    ```

    </div>

    If your select query specifies a database, it overrides the `databases` property.

4.  If you do not need to retain the IAM role you set previously, [revoke](/iam/docs/granting-changing-revoking-access#revoking-console) it now.

For the complete list of parameters for the request, see the [instances:export](/sql/docs/mysql/admin-api/rest/v1beta4/instances/export) page.

</div>

</div>

### Customize the format of a CSV export file

You can use `gcloud` or the REST API to customize your CSV file format. When you perform an export, you can specify the following formatting options:

<table class="style0">
<colgroup>
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
</colgroup>
<thead>
<tr class="header">
<th class="style1">CSV option</th>
<th class="style1">Default value</th>
<th class="style1">gcloud flag</th>
<th class="style1">REST API property</th>
<th class="style1">Description</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td>Escape</td>
<td><p><code translate="no" dir="ltr">"5C"</code></p>
<p>ASCII hex code for file separator.</p></td>
<td><code translate="no" dir="ltr">--escape</code></td>
<td><code translate="no" dir="ltr">escapeCharacter</code></td>
<td><p>Character that appears before a data character that needs to be escaped.</p>
<p>Available only for MySQL and PostgreSQL.</p></td>
</tr>
<tr class="even">
<td>Quote</td>
<td><p><code translate="no" dir="ltr">"22"</code></p>
<p>ASCII hex code for double quotes.</p></td>
<td><code translate="no" dir="ltr">--quote</code></td>
<td><code translate="no" dir="ltr">quoteCharacter</code></td>
<td><p>Character that encloses values from columns that have a string data type.</p>
<p>Available only for MySQL and PostgreSQL.</p></td>
</tr>
<tr class="odd">
<td>Field delimiter</td>
<td><p><code translate="no" dir="ltr">"2C"</code></p>
<p>ASCII hex code for comma.</p></td>
<td><code translate="no" dir="ltr">--fields-terminated-by</code></td>
<td><code translate="no" dir="ltr">fieldsTerminatedBy</code></td>
<td><p>Character that splits column values.</p>
<p>Available only for MySQL and PostgreSQL.</p></td>
</tr>
<tr class="even">
<td>Newline character</td>
<td><p><code translate="no" dir="ltr">"0A"</code></p>
<p>ASCII hex code for newline.</p></td>
<td><code translate="no" dir="ltr">--lines-terminated-by</code></td>
<td><code translate="no" dir="ltr">linesTerminatedBy</code></td>
<td><p>Character that splits line records.</p>
<p>Available only for MySQL.</p></td>
</tr>
</tbody>
</table>

For example, a `gcloud` command using all of these arguments could be like the following:

<div>

</div>

``` devsite-click-to-copy
gcloud sql export csv INSTANCE_NAME gs://BUCKET_NAME/FILE_NAME \
--database=DATABASE_NAME \
--offload \
--query=SELECT_QUERY \
--quote="22" \
--escape="5C" \
--fields-terminated-by="2C" \
--lines-terminated-by="0A"
```

The equivalent REST API request body would look like this:

<div>

</div>

``` devsite-click-to-copy
{
 "exportContext":
   {
      "fileType": "CSV",
      "uri": "gs://bucket_name/path_to_csv_file",
      "databases": ["DATABASE_NAME"],
      "offload": true,
      "csvExportOptions":
       {
           "selectQuery": "SELECT_QUERY",
           "escapeCharacter":  "5C",
           "quoteCharacter": "22",
           "fieldsTerminatedBy": "2C",
           "linesTerminatedBy": "0A"
       }
   }
}
```

The preceding `gcloud` and API examples are equivalent to running the following SQL statement:

<div>

</div>

``` devsite-click-to-copy
SELECT [QUERY] INTO OUTFILE ... CHARACTER SET 'utf8mb4'
            FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '\"'
            ESCAPED BY '\\' LINES TERMINATED BY '\n'
```

## Import data to Cloud SQL for MySQL

### Required roles and permissions for importing to Cloud SQL for MySQL

To import data from Cloud Storage into Cloud SQL, the user initiating the import must have one of the following roles:

- The [Cloud SQL Admin](/sql/docs/mysql/iam-roles) role
- A [custom role](/iam/docs/understanding-custom-roles), including the following permissions:
  - `cloudsql.instances.get`
  - `cloudsql.instances.import`

Additionally, the service account for the Cloud SQL instance must have one of the following roles:

- The `storage.objectAdmin` IAM role
- A custom role, including the following permissions:
  - `storage.objects.get`
  - `storage.objects.list` (for importing files in parallel only)

For help with IAM roles, see <a href="/storage/docs/access-control/iam" target="_blank">Identity and Access Management</a>.

**Note**: The changes that you make to the IAM permissions and roles might take a few minutes to take effect. For more information, see [Access change propagation](/iam/docs/access-change-propagation).

### Export data from your local MySQL server to a CSV file

To export a MySQL table for import into Cloud SQL, we recommend that you format the file using the following command:

<div>

</div>

``` devsite-click-to-copy
mysql --host=INSTANCE_IP --user=USER_NAME --password DATABASE \
-e " SELECT * FROM TABLE INTO OUTFILE 'FILE_NAME' CHARACTER SET 'utf8mb4'
     FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '\"' ESCAPED BY '\"' "
```

You can [customize the format](#customize-csv-format) of your CSV export file.

### Import data from a CSV file to Cloud SQL for MySQL

- The database and table you are importing into must exist on your Cloud SQL instance. For help with creating a database, see <a href="/sql/docs/mysql/create-manage-databases#create" target="_blank">Creating a database</a>.

  To create a table, use the <a href="https://dev.mysql.com/doc/refman/8.4/en/creating-tables.html" target="_blank"><code translate="no" dir="ltr">CREATE TABLE</code></a> SQL statement in the `mysql` client.

- Your CSV file must conform to the <a href="#csv-reqs" target="_blank">CSV file format requirements</a>.

- If you are importing data that you exported from an on-premises MySQL server:
  1.  [Create a bucket in Cloud Storage](/storage/docs/creating-buckets).
  2.  [Upload the SQL dump file](/storage/docs/uploading-objects) to the Cloud Storage bucket.

**Note:** The default behavior for Cloud SQL is to import columns in your CSV file in the same order as the table schema. If the order is different in your CSV file or if some columns are skipped, use <a href="/sdk/gcloud/reference/sql/import/csv#--columns" target="_blank">importContext.csvImportOptions.columns[]</a> to import data from the CSV file.

**Note:** You cannot import a CSV file that was created using one database engine into an instance created using another database engine.

<a href="#" id="csv-reqs"></a>

### CSV file format requirements

CSV files must have one line for each row of data and use comma-separated fields.

To import data to a Cloud SQL instance using a CSV file:

<div id="import-database-csv" class="ds-selector-tabs" ds-scope="code-sample">

<div class="section">

### Console

1.  In the Google Cloud console, go to the **Cloud SQL Instances** page.

    <a href="https://console.cloud.google.com/sql" class="button button-primary" target="console">Go to Cloud SQL Instances</a>

2.  To open the **Overview** page of an instance, click the instance name.

3.  Click **Import**.

4.  In the **File format** section, select **CSV**.

5.  In the **Select source file** section, enter the path to the bucket and CSV file or upload a local CSV file to use for the import. To browse to the file:

    1.  Click **Browse**.
    2.  In the **Location** section, double-click the name of the bucket in the list.
    3.  Select the file in the list.
    4.  Click **Select**.

    You can import a compressed (`.gz`) or an uncompressed (`.csv`) file.

6.  In the **Destination** section, specify the **Database** and **Table** in your Cloud SQL instance where you want to import the CSV file.

7.  Click **Import** to start the import.

</div>

<div class="section">

### gcloud

1.  <a href="/storage/docs/creating-buckets" target="_blank">Create a Cloud Storage bucket.</a>

2.  Upload the file to your bucket.

    For help with uploading files to buckets, see <a href="/storage/docs/uploading-objects" target="_blank">Uploading objects</a>.

3.  Upload data from the CSV file to the bucket.

4.  Identify the service account for the Cloud SQL instance you're exporting from. You can do this running the [`gcloud sql instances describe`](/sdk/gcloud/reference/sql/instances/describe) command with the instance name. Look for the `serviceAccountEmailAddress` field in the output.

    <div>

    </div>

    ``` devsite-click-to-copy
    gcloud sql instances describe INSTANCE_NAME
    ```

5.  Copy the serviceAccountEmailAddress field.

6.  Use ` `[`gcloud storage buckets add-iam-policy-binding`](/sdk/gcloud/reference/storage/buckets/add-iam-policy-binding) to grant the `storage.objectAdmin` <a href="/storage/docs/access-control/iam-roles" target="_blank">IAM role</a> to the Cloud SQL instance service account for the bucket. For help with setting IAM permissions, see <a href="/storage/docs/access-control/using-iam-permissions" target="_blank">Using IAM permissions</a>.

7.  Import the file:

    <div>

    </div>

    ``` devsite-click-to-copy
    gcloud sql import csv INSTANCE_NAME gs://BUCKET_NAME/FILE_NAME \
    --database=DATABASE_NAME \
    --table=TABLE_NAME
    ```

    For information about using the `import csv` command, see the <a href="/sdk/gcloud/reference/sql/import/csv" target="_blank"><code translate="no" dir="ltr">sql import csv</code></a> command reference page.

8.  If you do not need to retain the IAM permissions you set previously, remove them using [`gcloud storage buckets remove-iam-policy-binding`](/sdk/gcloud/reference/storage/buckets/remove-iam-policy-binding).

</div>

<div class="section">

### REST v1

1.  <a href="/storage/docs/creating-buckets" target="_blank">Create a Cloud Storage bucket.</a>

2.  Upload the file to your bucket.

    For help with uploading files to buckets, see <a href="/storage/docs/uploading-objects" target="_blank">Uploading objects</a>.

3.  Provide your instance with the `storage.objectAdmin` and `objectViewer` [IAM roles](/storage/docs/access-control/iam-roles) for your bucket. For help with setting IAM permissions, see [Using IAM permissions](/storage/docs/access-control/using-iam-permissions).

4.  Import the file:

    Before using any of the request data, make the following replacements:

    - `project-id`: The project ID
    - `instance-id`: The instance ID
    - `bucket_name`: The Cloud Storage bucket name
    - `path_to_csv_file`: The path to the CSV file
    - `database_name`: The name of a database inside the Cloud SQL instance
    - `table_name`: The name of the database table
    - `escape_character`: The character that should appear before a data character that needs to be escaped. The value of this argument has to be a character in Hex ASCII Code. For example, "22" represents double quotes. (optional)
    - `quote_character`: The character that encloses values from columns that have a string data type. The value of this argument has to be a character in Hex ASCII Code. For example, "22" represents double quotes. (optional)
    - `fields_terminated_by`: The character that split column values. The value of this argument has to be a character in Hex ASCII Code. For example, "2C" represents a comma. (optional)
    - `lines_terminated_by`: The character that split line records. The value of this argument has to be a character in Hex ASCII Code. For example, "0A" represents a new line. (optional)

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    POST https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-id/import
    ```

    </div>

    Request JSON body:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    {
     "importContext":
       {
          "fileType": "CSV",
          "uri": "gs://bucket_name/path_to_csv_file",
          "database": "database_name",
          "csvImportOptions":
           {
             "table": "table_name",
             "escapeCharacter": "escape_character",
             "quoteCharacter": "quote_character",
             "fieldsTerminatedBy": "fields_terminated_by",
             "linesTerminatedBy": "lines_terminated_by"
           }
       }
    }
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Save the request body in a file named `request.json`, and execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X POST \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         -H "Content-Type: application/json; charset=utf-8" \
         -d @request.json \
         "https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-id/import"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Save the request body in a file named `request.json`, and execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method POST `
        -Headers $headers `
        -ContentType: "application/json; charset=utf-8" `
        -InFile request.json `
        -Uri "https://sqladmin.googleapis.com/v1/projects/project-id/instances/instance-id/import" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a JSON response similar to the following:

    <div class="section expandable">

    #### Response

    <div>

    </div>

    ``` readonly
    {
      "kind": "sql#operation",
      "targetLink": "https://sqladmin.googleapis.com/v1/projects/project-id/instances/target-instance-id",
      "status": "PENDING",
      "user": "user@example.com",
      "insertTime": "2020-01-21T22:43:37.981Z",
      "operationType": "UPDATE",
      "name": "operation-id",
      "targetId": "instance-id",
      "selfLink": "https://sqladmin.googleapis.com/v1/projects/project-id/operations/operation-id",
      "targetProject": "project-id"
    }
    ```

    </div>

    For the complete list of parameters for the request, see the [instances:import](/sql/docs/mysql/admin-api/rest/v1beta4/instances/import) page.

5.  If you do not need to retain the IAM permissions you set previously, remove the permissions.

</div>

<div class="section">

### REST v1beta4

1.  <a href="/storage/docs/creating-buckets" target="_blank">Create a Cloud Storage bucket.</a>

2.  Upload the file to your bucket.

    For help with uploading files to buckets, see <a href="/storage/docs/uploading-objects" target="_blank">Uploading objects</a>.

3.  Provide your instance with the `storage.objectAdmin` <a href="/storage/docs/access-control/iam-roles" target="_blank">IAM role</a> for your bucket. For help with setting IAM permissions, see <a href="/storage/docs/access-control/using-iam-permissions" target="_blank">Using IAM permissions</a>.

4.  Import the file:

    Before using any of the request data, make the following replacements:

    - `project-id`: The project ID
    - `instance-id`: The instance ID
    - `bucket_name`: The Cloud Storage bucket name
    - `path_to_csv_file`: The path to the CSV file
    - `database_name`: The name of a database inside the Cloud SQL instance
    - `table_name`: The name of the database table
    - `escape_character`: The character that should appear before a data character that needs to be escaped. The value of this argument must be in [ASCII hex format](https://ascii.cl/). For example,"22" represents double quotes. (optional)
    - `quote_character`: The character that encloses values from columns that have a string data type. The value of this argument must be in [ASCII hex format](https://ascii.cl/). For example, "22" represents double quotes. (optional)
    - `fields_terminated_by`: The character that split column values. The value of this argument must be in [ASCII hex format](https://ascii.cl/). For example, "2C" represents a comma. (optional)
    - `lines_terminated_by`: The character that split line records. The value of this argument must be in [ASCII hex format](https://ascii.cl/). For example, "0A" represents a new line. (optional)

    HTTP method and URL:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    POST https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id/import
    ```

    </div>

    Request JSON body:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    {
     "importContext":
       {
          "fileType": "CSV",
          "uri": "gs://bucket_name/path_to_csv_file",
          "database": "database_name",
          "csvImportOptions":
           {
             "table": "table_name",
             "escapeCharacter": "escape_character",
             "quoteCharacter": "quote_character",
             "fieldsTerminatedBy": "fields_terminated_by",
             "linesTerminatedBy": "lines_terminated_by"
           }
       }
    }
    ```

    </div>

    To send your request, expand one of these options:

    <div class="section expandable">

    #### curl (Linux, macOS, or Cloud Shell)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) , or by using [Cloud Shell](/shell/docs), which automatically logs you into the `gcloud` CLI . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Save the request body in a file named `request.json`, and execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    curl -X POST \
         -H "Authorization: Bearer $(gcloud auth print-access-token)" \
         -H "Content-Type: application/json; charset=utf-8" \
         -d @request.json \
         "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id/import"
    ```

    </div>

    </div>

    <div class="section expandable">

    #### PowerShell (Windows)

    **Note:** The following command assumes that you have logged in to the `gcloud` CLI with your user account by running [`gcloud init`](/sdk/gcloud/reference/init) or [`gcloud auth login`](/sdk/gcloud/reference/auth/login) . You can check the currently active account by running [`gcloud auth list`](/sdk/gcloud/reference/auth/list).
    Save the request body in a file named `request.json`, and execute the following command:

    <div class="section">

    <div>

    </div>

    ``` devsite-click-to-copy
    $cred = gcloud auth print-access-token
    $headers = @{ "Authorization" = "Bearer $cred" }

    Invoke-WebRequest `
        -Method POST `
        -Headers $headers `
        -ContentType: "application/json; charset=utf-8" `
        -InFile request.json `
        -Uri "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/instance-id/import" | Select-Object -Expand Content
    ```

    </div>

    </div>

    You should receive a JSON response similar to the following:

    <div class="section expandable">

    #### Response

    <div>

    </div>

    ``` readonly
    {
      "kind": "sql#operation",
      "targetLink": "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/instances/target-instance-id",
      "status": "PENDING",
      "user": "user@example.com",
      "insertTime": "2020-01-21T22:43:37.981Z",
      "operationType": "UPDATE",
      "name": "operation-id",
      "targetId": "instance-id",
      "selfLink": "https://sqladmin.googleapis.com/sql/v1beta4/projects/project-id/operations/operation-id",
      "targetProject": "project-id"
    }
    ```

    </div>

    For the complete list of parameters for the request, see the [instances:import](/sql/docs/mysql/admin-api/rest/v1beta4/instances/import) page.

5.  If you do not need to retain the IAM permissions you set previously, remove the permissions.

</div>

</div>

### Customize the format of a CSV file for Cloud SQL for MySQL

You can use `gcloud` or the REST API to customize your CSV file format.

A sample `gcloud` command follows:

<div>

</div>

``` devsite-click-to-copy
gcloud sql import csv INSTANCE_NAME gs://BUCKET_NAME/FILE_NAME \
--database=DATABASE_NAME \
--table=TABLE_NAME \
--quote="22" \
--escape="5C" \
--fields-terminated-by="2C" \
--lines-terminated-by="0A"
```

The equivalent REST API request body would look like this:

<div>

</div>

``` devsite-click-to-copy
{
 "importContext":
   {
      "fileType": "CSV",
      "uri": "gs://bucket_name/path_to_csv_file",
      "database": ["DATABASE_NAME"],
      "csvImportOptions":
       {
           "table": "TABLE_NAME",
           "escapeCharacter":  "5C",
           "quoteCharacter": "22",
           "fieldsTerminatedBy": "2C",
           "linesTerminatedBy": "0A"
       }
   }
}
```

The preceding `gcloud` and API examples are equivalent to running the following SQL statement:

<div>

</div>

``` devsite-click-to-copy
LOAD DATA LOCAL INFILE ... CHARACTER SET 'utf8mb4'
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '\"' ESCAPED BY '\\'.
```

**Note:** If you use custom format options in your import commands, make sure the exported file was created with the same options.

If you get an error such as `ERROR_RDBMS`, ensure the table exists. If the table exists, confirm that you have the correct permissions on the bucket. For help configuring access control in Cloud Storage, see <a href="/storage/docs/access-control/create-manage-lists" target="_blank">Create and Manage Access Control Lists</a>.

To see how the [underlying REST API request](/sql/docs/mysql/admin-api/rest/v1beta4/instances/import) is constructed for this task, see the [APIs Explorer on the instances:import page](/sql/docs/mysql/admin-api/rest/v1beta4/instances/import).

## What's next

- Learn how to <a href="/sql/docs/mysql/import-export/checking-status-import-export" target="_blank">check the status of import and export operations</a>.
- Learn more about <a href="/sql/docs/mysql/import-export" target="_blank">best practices for importing and exporting data</a>.
- [Known issues for imports and exports](/sql/docs/mysql/known-issues#import-export).

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
