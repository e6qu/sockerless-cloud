# IAM roles for Cloud Storage

<div class="devsite-article-body clearfix">

This document provides information about Identity and Access Management (IAM) roles and permissions for Cloud Storage.

## Predefined roles

The following table describes [Identity and Access Management (IAM)](/storage/docs/access-control/iam) roles that are associated with Cloud Storage and lists the permissions that are contained in each role. Unless otherwise noted, these roles can be applied either to projects, buckets, or managed folders. However, you can [grant legacy roles only to individual buckets](/storage/docs/access-control/using-iam-permissions#bucket-add).

To learn how to control access to buckets, see [use IAM permissions](/storage/docs/access-control/using-iam-permissions). To learn how to control access to managed folders, see [use IAM for managed folders](/storage/docs/access-control/using-iam-for-managed-folders).

<div results-count-container="">

</div>

<table class="fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="50%">Role</th>
<th>Permissions</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td class="role-description"><h4 id="storage.admin" class="role-title add-link" data-text="Storage Admin " tabindex="-1">Storage Admin</h4>
<p>(<code translate="no" dir="ltr">roles/storage.admin</code>)</p>
<span class="role-description custom"> </span>
<p>Grants full control of objects and buckets.</p>
<p>When applied to an individual <strong>bucket</strong>, control applies only to the specified bucket and objects within the bucket.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Bucket</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudaicompanion.instances.completeTask</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudkms.keyHandles.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudkms.keyHandles.create</code></li>
<li><code translate="no" dir="ltr">cloudkms.keyHandles.get</code></li>
<li><code translate="no" dir="ltr">cloudkms.keyHandles.list</code></li>
</ul>
<p><code translate="no" dir="ltr">cloudkms.operations.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.projects.showEffectiveAutokeyConfig</code></p>
<p><code translate="no" dir="ltr">firebase.projects.get</code></p>
<p><code translate="no" dir="ltr">monitoring.dashboards.get</code></p>
<p><code translate="no" dir="ltr">monitoring.dashboards.list</code></p>
<p><code translate="no" dir="ltr">monitoring.groups.get</code></p>
<p><code translate="no" dir="ltr">monitoring.groups.list</code></p>
<p><code translate="no" dir="ltr">monitoring.metricDescriptors.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">monitoring.monitoredResourceDescriptors.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">monitoring.monitoredResourceDescriptors.get</code></li>
<li><code translate="no" dir="ltr">monitoring.monitoredResourceDescriptors.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">monitoring.timeSeries.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">monitoring.timeSeries.create</code></li>
<li><code translate="no" dir="ltr">monitoring.timeSeries.list</code></li>
</ul>
<p><code translate="no" dir="ltr">orgpolicy.policy.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.iamPolicyInsights.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.iamPolicyInsights.get</code></li>
<li><code translate="no" dir="ltr">recommender.iamPolicyInsights.list</code></li>
<li><code translate="no" dir="ltr">recommender.iamPolicyInsights.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.iamPolicyRecommendations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.iamPolicyRecommendations.get</code></li>
<li><code translate="no" dir="ltr">recommender.iamPolicyRecommendations.list</code></li>
<li><code translate="no" dir="ltr">recommender.iamPolicyRecommendations.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.storageBucketSoftDeleteInsights.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.storageBucketSoftDeleteInsights.get</code></li>
<li><code translate="no" dir="ltr">recommender.storageBucketSoftDeleteInsights.list</code></li>
<li><code translate="no" dir="ltr">recommender.storageBucketSoftDeleteInsights.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.storageBucketSoftDeleteRecommendations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.storageBucketSoftDeleteRecommendations.get</code></li>
<li><code translate="no" dir="ltr">recommender.storageBucketSoftDeleteRecommendations.list</code></li>
<li><code translate="no" dir="ltr">recommender.storageBucketSoftDeleteRecommendations.update</code></li>
</ul>
<p><code translate="no" dir="ltr">resourcemanager.hierarchyNodes.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><code translate="no" dir="ltr">stackdriver.projects.get</code></p>
<p><code translate="no" dir="ltr">stackdriver.resourceMetadata.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.anywhereCaches.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.anywhereCaches.create</code></li>
<li><code translate="no" dir="ltr">storage.anywhereCaches.disable</code></li>
<li><code translate="no" dir="ltr">storage.anywhereCaches.get</code></li>
<li><code translate="no" dir="ltr">storage.anywhereCaches.list</code></li>
<li><code translate="no" dir="ltr">storage.anywhereCaches.pause</code></li>
<li><code translate="no" dir="ltr">storage.anywhereCaches.resume</code></li>
<li><code translate="no" dir="ltr">storage.anywhereCaches.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.bucketOperations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.bucketOperations.cancel</code></li>
<li><code translate="no" dir="ltr">storage.bucketOperations.get</code></li>
<li><code translate="no" dir="ltr">storage.bucketOperations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.buckets.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.buckets.create</code></li>
<li><code translate="no" dir="ltr">storage.buckets.createTagBinding</code></li>
<li><code translate="no" dir="ltr">storage.buckets.delete</code></li>
<li><code translate="no" dir="ltr">storage.buckets.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">storage.buckets.enableObjectRetention</code></li>
<li><code translate="no" dir="ltr">storage.buckets.get</code></li>
<li><code translate="no" dir="ltr">storage.buckets.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">storage.buckets.getIpFilter</code></li>
<li><code translate="no" dir="ltr">storage.buckets.getObjectInsights</code></li>
<li><code translate="no" dir="ltr">storage.buckets.list</code></li>
<li><code translate="no" dir="ltr">storage.buckets.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">storage.buckets.listTagBindings</code></li>
<li><code translate="no" dir="ltr">storage.buckets.relocate</code></li>
<li><code translate="no" dir="ltr">storage.buckets.restore</code></li>
<li><code translate="no" dir="ltr">storage.buckets.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">storage.buckets.setIpFilter</code></li>
<li><code translate="no" dir="ltr">storage.buckets.update</code></li>
<li><code translate="no" dir="ltr">storage.buckets.viewIntelligenceDetails</code></li>
<li><code translate="no" dir="ltr">storage.buckets.viewSecurityIntelligenceDetails</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.featureConfigs.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.featureConfigs.create</code></li>
<li><code translate="no" dir="ltr">storage.featureConfigs.delete</code></li>
<li><code translate="no" dir="ltr">storage.featureConfigs.get</code></li>
<li><code translate="no" dir="ltr">storage.featureConfigs.list</code></li>
<li><code translate="no" dir="ltr">storage.featureConfigs.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.folders.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.folders.create</code></li>
<li><code translate="no" dir="ltr">storage.folders.delete</code></li>
<li><code translate="no" dir="ltr">storage.folders.get</code></li>
<li><code translate="no" dir="ltr">storage.folders.list</code></li>
<li><code translate="no" dir="ltr">storage.folders.rename</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.intelligenceConfigs.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.intelligenceConfigs.get</code></li>
<li><code translate="no" dir="ltr">storage.intelligenceConfigs.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.managedFolders.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.managedFolders.create</code></li>
<li><code translate="no" dir="ltr">storage.managedFolders.delete</code></li>
<li><code translate="no" dir="ltr">storage.managedFolders.get</code></li>
<li><code translate="no" dir="ltr">storage.managedFolders.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">storage.managedFolders.list</code></li>
<li><code translate="no" dir="ltr">storage.managedFolders.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">storage.managedFolders.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.multipartUploads.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.multipartUploads.abort</code></li>
<li><code translate="no" dir="ltr">storage.multipartUploads.create</code></li>
<li><code translate="no" dir="ltr">storage.multipartUploads.list</code></li>
<li><code translate="no" dir="ltr">storage.multipartUploads.listParts</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.objects.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.objects.create</code></li>
<li><code translate="no" dir="ltr">storage.objects.createContext</code></li>
<li><code translate="no" dir="ltr">storage.objects.delete</code></li>
<li><code translate="no" dir="ltr">storage.objects.deleteContext</code></li>
<li><code translate="no" dir="ltr">storage.objects.get</code></li>
<li><code translate="no" dir="ltr">storage.objects.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">storage.objects.list</code></li>
<li><code translate="no" dir="ltr">storage.objects.move</code></li>
<li><code translate="no" dir="ltr">storage.objects.overrideUnlockedRetention</code></li>
<li><code translate="no" dir="ltr">storage.objects.restore</code></li>
<li><code translate="no" dir="ltr">storage.objects.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">storage.objects.setRetention</code></li>
<li><code translate="no" dir="ltr">storage.objects.update</code></li>
<li><code translate="no" dir="ltr">storage.objects.updateContext</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storagebatchoperations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storagebatchoperations.bucketOperations.get</code></li>
<li><code translate="no" dir="ltr">storagebatchoperations.bucketOperations.list</code></li>
<li><code translate="no" dir="ltr">storagebatchoperations.jobs.cancel</code></li>
<li><code translate="no" dir="ltr">storagebatchoperations.jobs.create</code></li>
<li><code translate="no" dir="ltr">storagebatchoperations.jobs.delete</code></li>
<li><code translate="no" dir="ltr">storagebatchoperations.jobs.get</code></li>
<li><code translate="no" dir="ltr">storagebatchoperations.jobs.list</code></li>
<li><code translate="no" dir="ltr">storagebatchoperations.locations.get</code></li>
<li><code translate="no" dir="ltr">storagebatchoperations.locations.list</code></li>
<li><code translate="no" dir="ltr">storagebatchoperations.operations.cancel</code></li>
<li><code translate="no" dir="ltr">storagebatchoperations.operations.delete</code></li>
<li><code translate="no" dir="ltr">storagebatchoperations.operations.get</code></li>
<li><code translate="no" dir="ltr">storagebatchoperations.operations.list</code></li>
</ul></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="storage.bucketViewer" class="role-title add-link" data-text="Storage Bucket Viewer Beta " tabindex="-1">Storage Bucket Viewer <sup>Beta</sup></h4>
<p>(<code translate="no" dir="ltr">roles/storage.bucketViewer</code>)</p>
<span class="role-description"> </span>
<p>Grants permission to view buckets and their metadata, excluding IAM policies.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Bucket</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">storage.buckets.get</code></p>
<p><code translate="no" dir="ltr">storage.buckets.list</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="storage.editor" class="role-title add-link" data-text="Storage Editor " tabindex="-1">Storage Editor</h4>
<p>(<code translate="no" dir="ltr">roles/storage.editor</code>)</p>
<span class="role-description"> </span>
<p>Editor role for storage</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Managed folder</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><code translate="no" dir="ltr">storage.buckets.create</code></p>
<p><code translate="no" dir="ltr">storage.buckets.delete</code></p>
<p><code translate="no" dir="ltr">storage.buckets.list</code></p>
<p><code translate="no" dir="ltr">storage.buckets.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">storage.buckets.listTagBindings</code></p>
<p><code translate="no" dir="ltr">storage.buckets.viewIntelligenceDetails</code></p>
<p><code translate="no" dir="ltr">storage.buckets.viewSecurityIntelligenceDetails</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.featureConfigs.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.featureConfigs.create</code></li>
<li><code translate="no" dir="ltr">storage.featureConfigs.delete</code></li>
<li><code translate="no" dir="ltr">storage.featureConfigs.get</code></li>
<li><code translate="no" dir="ltr">storage.featureConfigs.list</code></li>
<li><code translate="no" dir="ltr">storage.featureConfigs.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.folders.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.folders.create</code></li>
<li><code translate="no" dir="ltr">storage.folders.delete</code></li>
<li><code translate="no" dir="ltr">storage.folders.get</code></li>
<li><code translate="no" dir="ltr">storage.folders.list</code></li>
<li><code translate="no" dir="ltr">storage.folders.rename</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.hmacKeys.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.hmacKeys.create</code></li>
<li><code translate="no" dir="ltr">storage.hmacKeys.delete</code></li>
<li><code translate="no" dir="ltr">storage.hmacKeys.get</code></li>
<li><code translate="no" dir="ltr">storage.hmacKeys.list</code></li>
<li><code translate="no" dir="ltr">storage.hmacKeys.update</code></li>
</ul>
<p><code translate="no" dir="ltr">storage.intelligenceConfigs.get</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="storage.folderAdmin" class="role-title add-link" data-text="Storage Folder Admin " tabindex="-1">Storage Folder Admin</h4>
<p>(<code translate="no" dir="ltr">roles/storage.folderAdmin</code>)</p>
<span class="role-description"> </span>
<p>Grants full control over folders and objects, including listing, creating, viewing, and deleting objects.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Managed folder</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">orgpolicy.policy.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.folders.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.folders.create</code></li>
<li><code translate="no" dir="ltr">storage.folders.delete</code></li>
<li><code translate="no" dir="ltr">storage.folders.get</code></li>
<li><code translate="no" dir="ltr">storage.folders.list</code></li>
<li><code translate="no" dir="ltr">storage.folders.rename</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.managedFolders.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.managedFolders.create</code></li>
<li><code translate="no" dir="ltr">storage.managedFolders.delete</code></li>
<li><code translate="no" dir="ltr">storage.managedFolders.get</code></li>
<li><code translate="no" dir="ltr">storage.managedFolders.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">storage.managedFolders.list</code></li>
<li><code translate="no" dir="ltr">storage.managedFolders.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">storage.managedFolders.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.multipartUploads.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.multipartUploads.abort</code></li>
<li><code translate="no" dir="ltr">storage.multipartUploads.create</code></li>
<li><code translate="no" dir="ltr">storage.multipartUploads.list</code></li>
<li><code translate="no" dir="ltr">storage.multipartUploads.listParts</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.objects.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.objects.create</code></li>
<li><code translate="no" dir="ltr">storage.objects.createContext</code></li>
<li><code translate="no" dir="ltr">storage.objects.delete</code></li>
<li><code translate="no" dir="ltr">storage.objects.deleteContext</code></li>
<li><code translate="no" dir="ltr">storage.objects.get</code></li>
<li><code translate="no" dir="ltr">storage.objects.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">storage.objects.list</code></li>
<li><code translate="no" dir="ltr">storage.objects.move</code></li>
<li><code translate="no" dir="ltr">storage.objects.overrideUnlockedRetention</code></li>
<li><code translate="no" dir="ltr">storage.objects.restore</code></li>
<li><code translate="no" dir="ltr">storage.objects.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">storage.objects.setRetention</code></li>
<li><code translate="no" dir="ltr">storage.objects.update</code></li>
<li><code translate="no" dir="ltr">storage.objects.updateContext</code></li>
</ul></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="storage.legacyBucketOwner" class="role-title add-link" data-text="Storage Legacy Bucket Owner " tabindex="-1">Storage Legacy Bucket Owner</h4>
<p>(<code translate="no" dir="ltr">roles/storage.legacyBucketOwner</code>)</p>
<span class="role-description custom"> </span>
<p>Grants permission to create, overwrite, and delete objects; list objects in a bucket and read object metadata, excluding allow policies, when listing; and read and edit bucket metadata, including allow policies.</p>
<p>Use of this role is also reflected in the bucket's ACLs. For more information, see <a href="/storage/docs/access-control/iam#acls">IAM relation to ACLs</a>.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Bucket</li>
</ul></td>
<td class="role-permissions"><p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.anywhereCaches.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.anywhereCaches.create</code></li>
<li><code translate="no" dir="ltr">storage.anywhereCaches.disable</code></li>
<li><code translate="no" dir="ltr">storage.anywhereCaches.get</code></li>
<li><code translate="no" dir="ltr">storage.anywhereCaches.list</code></li>
<li><code translate="no" dir="ltr">storage.anywhereCaches.pause</code></li>
<li><code translate="no" dir="ltr">storage.anywhereCaches.resume</code></li>
<li><code translate="no" dir="ltr">storage.anywhereCaches.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.bucketOperations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.bucketOperations.cancel</code></li>
<li><code translate="no" dir="ltr">storage.bucketOperations.get</code></li>
<li><code translate="no" dir="ltr">storage.bucketOperations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">storage.buckets.createTagBinding</code></p>
<p><code translate="no" dir="ltr">storage.buckets.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">storage.buckets.enableObjectRetention</code></p>
<p><code translate="no" dir="ltr">storage.buckets.get</code></p>
<p><code translate="no" dir="ltr">storage.buckets.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">storage.buckets.getIpFilter</code></p>
<p><code translate="no" dir="ltr">storage.buckets.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">storage.buckets.listTagBindings</code></p>
<p><code translate="no" dir="ltr">storage.buckets.relocate</code></p>
<p><code translate="no" dir="ltr">storage.buckets.restore</code></p>
<p><code translate="no" dir="ltr">storage.buckets.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">storage.buckets.setIpFilter</code></p>
<p><code translate="no" dir="ltr">storage.buckets.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.folders.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.folders.create</code></li>
<li><code translate="no" dir="ltr">storage.folders.delete</code></li>
<li><code translate="no" dir="ltr">storage.folders.get</code></li>
<li><code translate="no" dir="ltr">storage.folders.list</code></li>
<li><code translate="no" dir="ltr">storage.folders.rename</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.managedFolders.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.managedFolders.create</code></li>
<li><code translate="no" dir="ltr">storage.managedFolders.delete</code></li>
<li><code translate="no" dir="ltr">storage.managedFolders.get</code></li>
<li><code translate="no" dir="ltr">storage.managedFolders.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">storage.managedFolders.list</code></li>
<li><code translate="no" dir="ltr">storage.managedFolders.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">storage.managedFolders.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.multipartUploads.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.multipartUploads.abort</code></li>
<li><code translate="no" dir="ltr">storage.multipartUploads.create</code></li>
<li><code translate="no" dir="ltr">storage.multipartUploads.list</code></li>
<li><code translate="no" dir="ltr">storage.multipartUploads.listParts</code></li>
</ul>
<p><code translate="no" dir="ltr">storage.objects.create</code></p>
<p><code translate="no" dir="ltr">storage.objects.createContext</code></p>
<p><code translate="no" dir="ltr">storage.objects.delete</code></p>
<p><code translate="no" dir="ltr">storage.objects.deleteContext</code></p>
<p><code translate="no" dir="ltr">storage.objects.list</code></p>
<p><code translate="no" dir="ltr">storage.objects.restore</code></p>
<p><code translate="no" dir="ltr">storage.objects.setRetention</code></p>
<p><code translate="no" dir="ltr">storage.objects.updateContext</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="storage.legacyBucketReader" class="role-title add-link" data-text="Storage Legacy Bucket Reader " tabindex="-1">Storage Legacy Bucket Reader</h4>
<p>(<code translate="no" dir="ltr">roles/storage.legacyBucketReader</code>)</p>
<span class="role-description custom"> </span>
<p>Grants permission to list a bucket's contents and read bucket metadata, excluding allow policies. Also grants permission to read object metadata, excluding allow policies, when listing objects.</p>
<p>Use of this role is also reflected in the bucket's ACLs. For more information, see <a href="/storage/docs/access-control/iam#acls">IAM relation to ACLs</a>.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Bucket</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">storage.buckets.get</code></p>
<p><code translate="no" dir="ltr">storage.folders.get</code></p>
<p><code translate="no" dir="ltr">storage.folders.list</code></p>
<p><code translate="no" dir="ltr">storage.managedFolders.get</code></p>
<p><code translate="no" dir="ltr">storage.managedFolders.list</code></p>
<p><code translate="no" dir="ltr">storage.multipartUploads.list</code></p>
<p><code translate="no" dir="ltr">storage.objects.list</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="storage.legacyBucketWriter" class="role-title add-link" data-text="Storage Legacy Bucket Writer " tabindex="-1">Storage Legacy Bucket Writer</h4>
<p>(<code translate="no" dir="ltr">roles/storage.legacyBucketWriter</code>)</p>
<span class="role-description custom"> </span>
<p>Grants permission to create, overwrite, and delete objects; list objects in a bucket and read object metadata, excluding allow policies, when listing; and read bucket metadata, excluding allow policies.</p>
<p>Use of this role is also reflected in the bucket's ACLs. For more information, see <a href="/storage/docs/access-control/iam#acls">IAM relation to ACLs</a>.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Bucket</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">storage.buckets.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.folders.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.folders.create</code></li>
<li><code translate="no" dir="ltr">storage.folders.delete</code></li>
<li><code translate="no" dir="ltr">storage.folders.get</code></li>
<li><code translate="no" dir="ltr">storage.folders.list</code></li>
<li><code translate="no" dir="ltr">storage.folders.rename</code></li>
</ul>
<p><code translate="no" dir="ltr">storage.managedFolders.create</code></p>
<p><code translate="no" dir="ltr">storage.managedFolders.delete</code></p>
<p><code translate="no" dir="ltr">storage.managedFolders.get</code></p>
<p><code translate="no" dir="ltr">storage.managedFolders.list</code></p>
<p><code translate="no" dir="ltr">storage.managedFolders.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.multipartUploads.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.multipartUploads.abort</code></li>
<li><code translate="no" dir="ltr">storage.multipartUploads.create</code></li>
<li><code translate="no" dir="ltr">storage.multipartUploads.list</code></li>
<li><code translate="no" dir="ltr">storage.multipartUploads.listParts</code></li>
</ul>
<p><code translate="no" dir="ltr">storage.objects.create</code></p>
<p><code translate="no" dir="ltr">storage.objects.createContext</code></p>
<p><code translate="no" dir="ltr">storage.objects.delete</code></p>
<p><code translate="no" dir="ltr">storage.objects.list</code></p>
<p><code translate="no" dir="ltr">storage.objects.restore</code></p>
<p><code translate="no" dir="ltr">storage.objects.setRetention</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="storage.legacyObjectOwner" class="role-title add-link" data-text="Storage Legacy Object Owner " tabindex="-1">Storage Legacy Object Owner</h4>
<p>(<code translate="no" dir="ltr">roles/storage.legacyObjectOwner</code>)</p>
<span class="role-description custom"> </span>
<p>Grants permission to view and edit objects and their metadata, including ACLs.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Managed folder</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">storage.objects.createContext</code></p>
<p><code translate="no" dir="ltr">storage.objects.deleteContext</code></p>
<p><code translate="no" dir="ltr">storage.objects.get</code></p>
<p><code translate="no" dir="ltr">storage.objects.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">storage.objects.overrideUnlockedRetention</code></p>
<p><code translate="no" dir="ltr">storage.objects.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">storage.objects.setRetention</code></p>
<p><code translate="no" dir="ltr">storage.objects.update</code></p>
<p><code translate="no" dir="ltr">storage.objects.updateContext</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="storage.legacyObjectReader" class="role-title add-link" data-text="Storage Legacy Object Reader " tabindex="-1">Storage Legacy Object Reader</h4>
<p>(<code translate="no" dir="ltr">roles/storage.legacyObjectReader</code>)</p>
<span class="role-description custom"> </span>
<p>Grants permission to view objects and their metadata, excluding ACLs.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Managed folder</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">storage.objects.get</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="storage.objectAdmin" class="role-title add-link" data-text="Storage Object Admin " tabindex="-1">Storage Object Admin</h4>
<p>(<code translate="no" dir="ltr">roles/storage.objectAdmin</code>)</p>
<span class="role-description custom"> </span>
<p>Grants full control of objects, including listing, creating, viewing, and deleting objects.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Managed folder</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">monitoring.timeSeries.create</code></p>
<p><code translate="no" dir="ltr">orgpolicy.policy.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.folders.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.folders.create</code></li>
<li><code translate="no" dir="ltr">storage.folders.delete</code></li>
<li><code translate="no" dir="ltr">storage.folders.get</code></li>
<li><code translate="no" dir="ltr">storage.folders.list</code></li>
<li><code translate="no" dir="ltr">storage.folders.rename</code></li>
</ul>
<p><code translate="no" dir="ltr">storage.managedFolders.create</code></p>
<p><code translate="no" dir="ltr">storage.managedFolders.delete</code></p>
<p><code translate="no" dir="ltr">storage.managedFolders.get</code></p>
<p><code translate="no" dir="ltr">storage.managedFolders.list</code></p>
<p><code translate="no" dir="ltr">storage.managedFolders.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.multipartUploads.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.multipartUploads.abort</code></li>
<li><code translate="no" dir="ltr">storage.multipartUploads.create</code></li>
<li><code translate="no" dir="ltr">storage.multipartUploads.list</code></li>
<li><code translate="no" dir="ltr">storage.multipartUploads.listParts</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.objects.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.objects.create</code></li>
<li><code translate="no" dir="ltr">storage.objects.createContext</code></li>
<li><code translate="no" dir="ltr">storage.objects.delete</code></li>
<li><code translate="no" dir="ltr">storage.objects.deleteContext</code></li>
<li><code translate="no" dir="ltr">storage.objects.get</code></li>
<li><code translate="no" dir="ltr">storage.objects.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">storage.objects.list</code></li>
<li><code translate="no" dir="ltr">storage.objects.move</code></li>
<li><code translate="no" dir="ltr">storage.objects.overrideUnlockedRetention</code></li>
<li><code translate="no" dir="ltr">storage.objects.restore</code></li>
<li><code translate="no" dir="ltr">storage.objects.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">storage.objects.setRetention</code></li>
<li><code translate="no" dir="ltr">storage.objects.update</code></li>
<li><code translate="no" dir="ltr">storage.objects.updateContext</code></li>
</ul></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="storage.objectCreator" class="role-title add-link" data-text="Storage Object Creator " tabindex="-1">Storage Object Creator</h4>
<p>(<code translate="no" dir="ltr">roles/storage.objectCreator</code>)</p>
<span class="role-description custom"> </span>
<p>Allows users to create objects. Does not give permission to view, delete, or overwrite objects.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Managed folder</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">orgpolicy.policy.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><code translate="no" dir="ltr">storage.folders.create</code></p>
<p><code translate="no" dir="ltr">storage.managedFolders.create</code></p>
<p><code translate="no" dir="ltr">storage.multipartUploads.abort</code></p>
<p><code translate="no" dir="ltr">storage.multipartUploads.create</code></p>
<p><code translate="no" dir="ltr">storage.multipartUploads.listParts</code></p>
<p><code translate="no" dir="ltr">storage.objects.create</code></p>
<p><code translate="no" dir="ltr">storage.objects.createContext</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="storage.objectUser" class="role-title add-link" data-text="Storage Object User " tabindex="-1">Storage Object User</h4>
<p>(<code translate="no" dir="ltr">roles/storage.objectUser</code>)</p>
<span class="role-description"> </span>
<p>Access to create, read, update and delete objects and multipart uploads in GCS.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Managed folder</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">monitoring.timeSeries.create</code></p>
<p><code translate="no" dir="ltr">orgpolicy.policy.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.folders.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.folders.create</code></li>
<li><code translate="no" dir="ltr">storage.folders.delete</code></li>
<li><code translate="no" dir="ltr">storage.folders.get</code></li>
<li><code translate="no" dir="ltr">storage.folders.list</code></li>
<li><code translate="no" dir="ltr">storage.folders.rename</code></li>
</ul>
<p><code translate="no" dir="ltr">storage.managedFolders.create</code></p>
<p><code translate="no" dir="ltr">storage.managedFolders.delete</code></p>
<p><code translate="no" dir="ltr">storage.managedFolders.get</code></p>
<p><code translate="no" dir="ltr">storage.managedFolders.list</code></p>
<p><code translate="no" dir="ltr">storage.managedFolders.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.multipartUploads.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.multipartUploads.abort</code></li>
<li><code translate="no" dir="ltr">storage.multipartUploads.create</code></li>
<li><code translate="no" dir="ltr">storage.multipartUploads.list</code></li>
<li><code translate="no" dir="ltr">storage.multipartUploads.listParts</code></li>
</ul>
<p><code translate="no" dir="ltr">storage.objects.create</code></p>
<p><code translate="no" dir="ltr">storage.objects.createContext</code></p>
<p><code translate="no" dir="ltr">storage.objects.delete</code></p>
<p><code translate="no" dir="ltr">storage.objects.deleteContext</code></p>
<p><code translate="no" dir="ltr">storage.objects.get</code></p>
<p><code translate="no" dir="ltr">storage.objects.list</code></p>
<p><code translate="no" dir="ltr">storage.objects.move</code></p>
<p><code translate="no" dir="ltr">storage.objects.restore</code></p>
<p><code translate="no" dir="ltr">storage.objects.update</code></p>
<p><code translate="no" dir="ltr">storage.objects.updateContext</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="storage.objectViewer" class="role-title add-link" data-text="Storage Object Viewer " tabindex="-1">Storage Object Viewer</h4>
<p>(<code translate="no" dir="ltr">roles/storage.objectViewer</code>)</p>
<span class="role-description custom"> </span>
<p>Grants access to view objects and their metadata, excluding ACLs. Can also list the objects in a bucket.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Managed folder</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><code translate="no" dir="ltr">storage.folders.get</code></p>
<p><code translate="no" dir="ltr">storage.folders.list</code></p>
<p><code translate="no" dir="ltr">storage.managedFolders.get</code></p>
<p><code translate="no" dir="ltr">storage.managedFolders.list</code></p>
<p><code translate="no" dir="ltr">storage.objects.get</code></p>
<p><code translate="no" dir="ltr">storage.objects.list</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="storage.viewer" class="role-title add-link" data-text="Storage Viewer " tabindex="-1">Storage Viewer</h4>
<p>(<code translate="no" dir="ltr">roles/storage.viewer</code>)</p>
<span class="role-description"> </span>
<p>Viewer role for storage</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Managed folder</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><code translate="no" dir="ltr">storage.buckets.list</code></p>
<p><code translate="no" dir="ltr">storage.buckets.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">storage.buckets.listTagBindings</code></p>
<p><code translate="no" dir="ltr">storage.buckets.viewIntelligenceDetails</code></p>
<p><code translate="no" dir="ltr">storage.buckets.viewSecurityIntelligenceDetails</code></p>
<p><code translate="no" dir="ltr">storage.featureConfigs.get</code></p>
<p><code translate="no" dir="ltr">storage.featureConfigs.list</code></p>
<p><code translate="no" dir="ltr">storage.folders.get</code></p>
<p><code translate="no" dir="ltr">storage.folders.list</code></p>
<p><code translate="no" dir="ltr">storage.hmacKeys.get</code></p>
<p><code translate="no" dir="ltr">storage.hmacKeys.list</code></p>
<p><code translate="no" dir="ltr">storage.intelligenceConfigs.get</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="storage.annotationGeneratorService" class="role-title add-link" data-text="Storage Annotation Generator Service Beta " tabindex="-1">Storage Annotation Generator Service <sup>Beta</sup></h4>
<p>(<code translate="no" dir="ltr">roles/storage.annotationGeneratorService</code>)</p>
<span class="role-description"> </span>
<p>Grants all permissions needed to generate annotations for objects in a bucket.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Managed folder</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">storage.objects.createContext</code></p>
<p><code translate="no" dir="ltr">storage.objects.deleteContext</code></p>
<p><code translate="no" dir="ltr">storage.objects.get</code></p>
<p><code translate="no" dir="ltr">storage.objects.list</code></p>
<p><code translate="no" dir="ltr">storage.objects.update</code></p>
<p><code translate="no" dir="ltr">storage.objects.updateContext</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="storage.expressModeServiceInput" class="role-title add-link" data-text="Storage Express Mode Service Input Beta " tabindex="-1">Storage Express Mode Service Input <sup>Beta</sup></h4>
<p>(<code translate="no" dir="ltr">roles/storage.expressModeServiceInput</code>)</p>
<span class="role-description"> </span>
<p>Grants permission to Express Mode service accounts at a managed folder so they can create objects but not read them on input folders.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Managed folder</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">storage.objects.create</code></p>
<p><code translate="no" dir="ltr">storage.objects.delete</code></p>
<p><code translate="no" dir="ltr">storage.objects.list</code></p>
<p><code translate="no" dir="ltr">storage.objects.update</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="storage.expressModeServiceOutput" class="role-title add-link" data-text="Storage Express Mode Service Output Beta " tabindex="-1">Storage Express Mode Service Output <sup>Beta</sup></h4>
<p>(<code translate="no" dir="ltr">roles/storage.expressModeServiceOutput</code>)</p>
<span class="role-description"> </span>
<p>Grants permission to Express Mode service accounts at a managed folder so they can read objects but not write them on output folders.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Managed folder</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">storage.objects.delete</code></p>
<p><code translate="no" dir="ltr">storage.objects.get</code></p>
<p><code translate="no" dir="ltr">storage.objects.list</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="storage.expressModeUserAccess" class="role-title add-link" data-text="Storage Express Mode User Access Beta " tabindex="-1">Storage Express Mode User Access <sup>Beta</sup></h4>
<p>(<code translate="no" dir="ltr">roles/storage.expressModeUserAccess</code>)</p>
<span class="role-description"> </span>
<p>Grants permission to Express Mode accounts at the project level so they can read, list, create and delete any object in any of their buckets in Express Mode.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Project</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">orgpolicy.policy.get</code></p>
<p><code translate="no" dir="ltr">storage.buckets.get</code></p>
<p><code translate="no" dir="ltr">storage.buckets.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.multipartUploads.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.multipartUploads.abort</code></li>
<li><code translate="no" dir="ltr">storage.multipartUploads.create</code></li>
<li><code translate="no" dir="ltr">storage.multipartUploads.list</code></li>
<li><code translate="no" dir="ltr">storage.multipartUploads.listParts</code></li>
</ul>
<p><code translate="no" dir="ltr">storage.objects.create</code></p>
<p><code translate="no" dir="ltr">storage.objects.delete</code></p>
<p><code translate="no" dir="ltr">storage.objects.get</code></p>
<p><code translate="no" dir="ltr">storage.objects.list</code></p>
<p><code translate="no" dir="ltr">storage.objects.restore</code></p>
<p><code translate="no" dir="ltr">storage.objects.update</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="storage.hmacKeyAdmin" class="role-title add-link" data-text="Storage HMAC Key Admin " tabindex="-1">Storage HMAC Key Admin</h4>
<p>(<code translate="no" dir="ltr">roles/storage.hmacKeyAdmin</code>)</p>
<span class="role-description custom"> </span>
<p>Full control of Cloud Storage HMAC keys.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Project</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">firebase.projects.get</code></p>
<p><code translate="no" dir="ltr">orgpolicy.policy.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.hmacKeys.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.hmacKeys.create</code></li>
<li><code translate="no" dir="ltr">storage.hmacKeys.delete</code></li>
<li><code translate="no" dir="ltr">storage.hmacKeys.get</code></li>
<li><code translate="no" dir="ltr">storage.hmacKeys.list</code></li>
<li><code translate="no" dir="ltr">storage.hmacKeys.update</code></li>
</ul></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="storage.insightsCollectorService" class="role-title add-link" data-text="Storage Insights Collector Service " tabindex="-1">Storage Insights Collector Service</h4>
<p>(<code translate="no" dir="ltr">roles/storage.insightsCollectorService</code>)</p>
<span class="role-description custom"> </span>
<p>Read-only access to Cloud Storage Inventory metadata for Storage Insights.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Bucket</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><code translate="no" dir="ltr">storage.buckets.get</code></p>
<p><code translate="no" dir="ltr">storage.buckets.getObjectInsights</code></p></td>
</tr>
</tbody>
</table>

### Service agent roles

Service agent roles should only be granted to [service agents](/iam/docs/service-agents).

<div results-count-container="">

</div>

<table class="fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="50%">Role</th>
<th>Permissions</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td class="role-description"><h4 id="storage.malwareScannerServiceAgent" class="role-title add-link" data-text="GCS Malware Scanner Service Agent " tabindex="-1">GCS Malware Scanner Service Agent</h4>
<p>(<code translate="no" dir="ltr">roles/storage.malwareScannerServiceAgent</code>)</p>
<span class="role-description"> </span>
<p>Gives Google Cloud Storage Malware Scanner Service Agent access to read object contents and write scan verdicts to object contexts.</p>
<strong>Warning:</strong> Do not grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.</td>
<td class="role-permissions"><p><code translate="no" dir="ltr">storage.objects.createContext</code></p>
<p><code translate="no" dir="ltr">storage.objects.get</code></p>
<p><code translate="no" dir="ltr">storage.objects.updateContext</code></p></td>
</tr>
</tbody>
</table>

**Note:** Consider the following for permissions:

- The `orgpolicy.policy.get` permission allows principals to know the [organization policy constraints](/storage/docs/org-policy-constraints) that a project is subject to. This permission is only effective if the role is [granted at the project level](/iam/docs/granting-changing-revoking-access#grant-single-role) or above.
- For more information about the `resourcemanager.projects.*` permissions, see [Access control for projects with IAM](/resource-manager/docs/access-control-proj).
- The `storagebatchoperations.jobs.*` and `storagebatchoperations.operations.*` permissions allow you to [create and manage storage batch operations jobs](/storage/docs/batch-operations/create-manage-batch-operation-jobs). These permissions are effective only if the role is [granted at the project level](/iam/docs/granting-changing-revoking-access#grant-single-role).

### Predefined Storage Insights roles

The following table describes [IAM](/storage/docs/access-control/iam) roles that are associated with Storage Insights and lists the permissions that are contained in each role.

<div results-count-container="">

</div>

<table class="fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="50%">Role</th>
<th>Permissions</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td class="role-description"><h4 id="storageinsights.admin" class="role-title add-link" data-text="Storage Insights Admin " tabindex="-1">Storage Insights Admin</h4>
<p>(<code translate="no" dir="ltr">roles/storageinsights.admin</code>)</p>
<span class="role-description"> </span>
<p>Full access to Storage Insights resources.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storageinsights.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storageinsights.datasetConfigs.create</code></li>
<li><code translate="no" dir="ltr">storageinsights.datasetConfigs.delete</code></li>
<li><code translate="no" dir="ltr">storageinsights.datasetConfigs.get</code></li>
<li><code translate="no" dir="ltr">storageinsights.datasetConfigs.linkDataset</code></li>
<li><code translate="no" dir="ltr">storageinsights.datasetConfigs.list</code></li>
<li><code translate="no" dir="ltr">storageinsights.datasetConfigs.unlinkDataset</code></li>
<li><code translate="no" dir="ltr">storageinsights.datasetConfigs.update</code></li>
<li><code translate="no" dir="ltr">storageinsights.locations.get</code></li>
<li><code translate="no" dir="ltr">storageinsights.locations.list</code></li>
<li><code translate="no" dir="ltr">storageinsights.operations.cancel</code></li>
<li><code translate="no" dir="ltr">storageinsights.operations.delete</code></li>
<li><code translate="no" dir="ltr">storageinsights.operations.get</code></li>
<li><code translate="no" dir="ltr">storageinsights.operations.list</code></li>
<li><code translate="no" dir="ltr">storageinsights.reportConfigs.create</code></li>
<li><code translate="no" dir="ltr">storageinsights.reportConfigs.delete</code></li>
<li><code translate="no" dir="ltr">storageinsights.reportConfigs.get</code></li>
<li><code translate="no" dir="ltr">storageinsights.reportConfigs.list</code></li>
<li><code translate="no" dir="ltr">storageinsights.reportConfigs.update</code></li>
<li><code translate="no" dir="ltr">storageinsights.reportDetails.get</code></li>
<li><code translate="no" dir="ltr">storageinsights.reportDetails.list</code></li>
</ul></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="storageinsights.viewer" class="role-title add-link" data-text="Storage Insights Viewer " tabindex="-1">Storage Insights Viewer</h4>
<p>(<code translate="no" dir="ltr">roles/storageinsights.viewer</code>)</p>
<span class="role-description custom"> </span>
<p>Read-only access to Storage Insights resources.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><code translate="no" dir="ltr">storageinsights.datasetConfigs.get</code></p>
<p><code translate="no" dir="ltr">storageinsights.datasetConfigs.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storageinsights.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storageinsights.locations.get</code></li>
<li><code translate="no" dir="ltr">storageinsights.locations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">storageinsights.operations.get</code></p>
<p><code translate="no" dir="ltr">storageinsights.operations.list</code></p>
<p><code translate="no" dir="ltr">storageinsights.reportConfigs.get</code></p>
<p><code translate="no" dir="ltr">storageinsights.reportConfigs.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storageinsights.reportDetails.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storageinsights.reportDetails.get</code></li>
<li><code translate="no" dir="ltr">storageinsights.reportDetails.list</code></li>
</ul></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="storageinsights.analyst" class="role-title add-link" data-text="Storage Insights Analyst " tabindex="-1">Storage Insights Analyst</h4>
<p>(<code translate="no" dir="ltr">roles/storageinsights.analyst</code>)</p>
<span class="role-description"> </span>
<p>Data access to Storage Insights.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><code translate="no" dir="ltr">storageinsights.datasetConfigs.get</code></p>
<p><code translate="no" dir="ltr">storageinsights.datasetConfigs.linkDataset</code></p>
<p><code translate="no" dir="ltr">storageinsights.datasetConfigs.list</code></p>
<p><code translate="no" dir="ltr">storageinsights.datasetConfigs.unlinkDataset</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storageinsights.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storageinsights.locations.get</code></li>
<li><code translate="no" dir="ltr">storageinsights.locations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">storageinsights.operations.get</code></p>
<p><code translate="no" dir="ltr">storageinsights.operations.list</code></p>
<p><code translate="no" dir="ltr">storageinsights.reportConfigs.get</code></p>
<p><code translate="no" dir="ltr">storageinsights.reportConfigs.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storageinsights.reportDetails.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storageinsights.reportDetails.get</code></li>
<li><code translate="no" dir="ltr">storageinsights.reportDetails.list</code></li>
</ul></td>
</tr>
</tbody>
</table>

### Service agent roles

Service agent roles should only be granted to [service agents](/iam/docs/service-agents).

<div results-count-container="">

</div>

<table class="fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="50%">Role</th>
<th>Permissions</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td class="role-description"><h4 id="storageinsights.serviceAgent" class="role-title add-link" data-text="StorageInsights Service Agent " tabindex="-1">StorageInsights Service Agent</h4>
<p>(<code translate="no" dir="ltr">roles/storageinsights.serviceAgent</code>)</p>
<span class="role-description"> </span>
<p>Permissions for Insights to write reports into customer project</p>
<strong>Warning:</strong> Do not grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.</td>
<td class="role-permissions"><p><code translate="no" dir="ltr">bigquery.datasets.create</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.use</code></p>
<p><code translate="no" dir="ltr">storageinsights.reportDetails.list</code></p></td>
</tr>
</tbody>
</table>

## Basic roles

**Note:** You should minimize the use of basic roles if possible, and in production environments, don't grant basic roles unless there is no alternative. Basic roles contain a wide range of permissions across all Google Cloud services and have potentially surprising behavior in Cloud Storage as described in this section.

Basic roles are roles that existed prior to IAM. These roles have unique characteristics:

- Basic roles can only be granted for an entire project, not for individual buckets within the project. Like other roles that you grant for a project, basic roles apply to all buckets and objects in the project.

- Basic roles contain additional permissions for other Google Cloud services that are not covered in this section. See [basic roles](/iam/docs/roles-overview#basic) for a general discussion of the permissions that basic roles grant.

- Each basic role has a [*convenience value*](/storage/docs/access-control/iam#convenience-values) that lets you use the basic role as if it were a group. When used in this way, any principal that has the basic role is considered to be part of the group. Everyone in the group gets additional access for resources based on the access the convenience value has.

  - Convenience values can be used when granting roles for buckets.

  - Convenience values can be used when setting ACLs on objects.

- Basic roles don't intrinsically give all of the access to Cloud Storage resources that their names imply. Instead, they give a portion of the expected access intrinsically and the rest of the expected access through the use of convenience values. Because convenience values can be manually added or removed like any other IAM principal, it is possible to revoke access that principals might otherwise expect to have.

  For a discussion of additional access that principals with basic roles typically gain due to convenience values, see [modifiable behavior](#basic-roles-modifiable).

### Intrinsic permissions

The following table describes the Cloud Storage permissions that are always associated with each basic role.

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr class="header">
<th>Role</th>
<th>Description</th>
<th>Cloud Storage Permissions</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td><strong>Viewer</strong> (<code translate="no" dir="ltr">roles/viewer</code>)</td>
<td>Grants permission to list buckets in the project; view bucket metadata when listing (excluding ACLs); and list and get HMAC keys in the project.</td>
<td><code translate="no" dir="ltr">storage.buckets.getIpFilter</code><br />
<code translate="no" dir="ltr">storage.buckets.list</code><br />
<code translate="no" dir="ltr">storage.hmacKeys.get</code><br />
<code translate="no" dir="ltr">storage.hmacKeys.list</code></td>
</tr>
<tr class="even">
<td><strong>Editor</strong> (<code translate="no" dir="ltr">roles/editor</code>)</td>
<td>Grants permission to create, list, and delete buckets in the project; view bucket metadata when listing (excluding ACLs); and control HMAC keys in the project.</td>
<td><code translate="no" dir="ltr">storage.buckets.create</code><br />
<code translate="no" dir="ltr">storage.buckets.delete</code><br />
<code translate="no" dir="ltr">storage.buckets.getIpFilter</code><br />
<code translate="no" dir="ltr">storage.buckets.list</code><br />
<code translate="no" dir="ltr">storage.hmacKeys.*</code></td>
</tr>
<tr class="odd">
<td><strong>Owner</strong> (<code translate="no" dir="ltr">roles/owner</code>)</td>
<td><p>Grants permission to create, list, and delete buckets in the project; view bucket metadata when listing (excluding ACLs); create, delete, and list tag bindings; and control HMAC keys in the project; Enable, disable, update, and get the Storage Intelligence configuration on a project, a folder, or an organization.</p>
<p>Within Google Cloud more generally, principals with this role can perform administrative tasks such as changing principals' roles for the project or changing billing.</p></td>
<td><code translate="no" dir="ltr">storage.buckets.create</code><br />
<code translate="no" dir="ltr">storage.buckets.delete</code><br />
<code translate="no" dir="ltr">storage.buckets.list</code><br />
<code translate="no" dir="ltr">storage.buckets.createTagBinding</code><br />
<code translate="no" dir="ltr">storage.buckets.deleteTagBinding</code><br />
<code translate="no" dir="ltr">storage.buckets.getIpFilter</code><br />
<code translate="no" dir="ltr">storage.buckets.listEffectiveTags</code><br />
<code translate="no" dir="ltr">storage.buckets.listTagBindings</code><br />
<code translate="no" dir="ltr">storage.buckets.setIpFilter</code><br />
<code translate="no" dir="ltr">storage.hmacKeys.*</code><br />
<code translate="no" dir="ltr">storage.intelligenceConfigs.get</code><br />
<code translate="no" dir="ltr">storage.intelligenceConfigs.update</code></td>
</tr>
</tbody>
</table>

### Modifiable behavior

Principals granted basic roles often have additional access to a project's buckets and objects due to [*convenience values*](/storage/docs/access-control/iam#convenience-values). When a bucket is created, convenience values are granted certain bucket-level access, but you can later edit your bucket IAM policies and your object ACLs to remove or change the access.

When you create a bucket that has [uniform bucket-level access](/storage/docs/uniform-bucket-level-access) enabled, the following access is granted via convenience values:

- Principals granted `roles/viewer` gain the `roles/storage.legacyBucketReader` and `roles/storage.legacyObjectReader` roles for the bucket.

- Principals granted `roles/editor` gain the `roles/storage.legacyBucketOwner` and `roles/storage.legacyObjectOwner` roles for the bucket.

- Principals granted `roles/owner` gain the `roles/storage.legacyBucketOwner` and `roles/storage.legacyObjectOwner` roles for the bucket.

When you create a bucket that does not have uniform bucket-level access enabled, the following access is granted using convenience values:

- Principals granted `roles/viewer` gain the `roles/storage.legacyBucketReader` role for the bucket.

- Principals granted `roles/editor` gain the `roles/storage.legacyBucketOwner` role for the bucket.

- Principals granted `roles/owner` gain the `roles/storage.legacyBucketOwner` role for the bucket.

- Additionally, the bucket has a [default object Access Control List (ACL)](/storage/docs/access-control/lists#defaultobjects). This default ACL is often applied to new objects in the bucket and often grants additional access to convenience values.

## Custom roles

You might want to define your own roles which contain bundles of permissions that you specify. To support this, IAM offers [custom roles](/iam/docs/creating-custom-roles).

## What's next

- [Use IAM permissions](/storage/docs/access-control/using-iam-permissions) to control access to buckets and objects.

- Learn about each [IAM permission for Cloud Storage](/storage/docs/access-control/iam-permissions).

- See available [IAM references for Cloud Storage](/storage/docs/access-control/iam-reference), such as which IAM permissions allow users to perform actions with various tools and APIs.

- For a reference of other Google Cloud roles, see [Understanding Roles](/iam/docs/roles-permissions).

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
