# HTTP status and error codes for JSON

<div class="devsite-article-body clearfix">

This page describes the HTTP status codes and error messages returned by the Cloud Storage JSON API. You can use these codes to troubleshoot and resolve request failures, and verify API behavior. For the XML API version of this page, see [HTTP status and error codes for XML](/storage/docs/xml-api/reference-status).

## Error Response Format

Cloud Storage uses the standard HTTP error reporting format for the JSON API. Successful requests return HTTP status codes in the 2xx range. Failed requests return status codes in the 4xx and 5xx ranges. Requests that require a redirect return status codes in the 3xx range. Error responses usually include a JSON document in the response body, which contains information about the error.

The following examples show some common errors. Note that the header information in the responses is omitted.

<div>

<div class="section">

### `401 Unauthorized`

The following is an example of an error response you receive if you try to list the buckets for a project but do not provide an authorization header.

<div>

</div>

```
401 Unauthorized

{
"error": {
 "errors": [
  {
   "domain": "global",
   "reason": "required",
   "message": "Login Required",
   "locationType": "header",
   "location": "Authorization"
  }
 ],
 "code": 401,
 "message": "Login Required"
 }
}
```

</div>

<div class="section">

### `403 Forbidden`

This is an example of an error response you receive if you try to list the buckets of a non-existent project or one in which you don't have permission to list buckets.

<div>

</div>

```
403 Forbidden

{
 "error": {
  "errors": [
   {
    "domain": "global",
    "reason": "forbidden",
    "message": "Forbidden"
    }
  ],
  "code": 403,
  "message": "Forbidden"
 }
}
```

</div>

<div class="section">

### `404 Not Found`

The following is an example of an error response you receive if you try to retrieve an object that does not exist.

<div>

</div>

```
404 Not Found

{
"error": {
 "errors": [
  {
   "domain": "global",
   "reason": "notFound",
   "message": "Not Found"
  }
 ],
 "code": 404,
 "message": "Not Found"
 }
}
```

</div>

<div class="section">

### `409 Conflict`

The following is an example of an error response you receive if you try to create a bucket using the name of a bucket you already own.

<div>

</div>

```
409 Conflict

{
"error": {
 "errors": [
  {
   "domain": "global",
   "reason": "conflict",
   "message": "You already own this bucket. Please select another name."
  }
 ],
 "code": 409,
 "message": "You already own this bucket. Please select another name."
 }
}
```

</div>

</div>

The following table describes the elements that can appear in the response body of an error. Fields should be used together to help determine the problem. Also, the example values given below are meant for illustration and are not an exhaustive list of all possible values.

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th>Element</th>
<th>Description</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td><code translate="no" dir="ltr">code</code></td>
<td>An <a href="https://datatracker.ietf.org/doc/html/rfc7231#section-6" class="external">HTTP status code</a> value, without the textual description.<br />
<br />
Example values include: <code translate="no" dir="ltr">400</code> (Bad Request), <code translate="no" dir="ltr">401</code> (Unauthorized), and <code translate="no" dir="ltr">404</code> (Not Found).</td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">error</code></td>
<td>A container for the error information.</td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">errors</code></td>
<td>A container for the error details.</td>
</tr>
<tr class="even">
<td>errors.<code translate="no" dir="ltr">domain</code></td>
<td>The scope of the error. Example values include: <code translate="no" dir="ltr">global</code> and <code translate="no" dir="ltr">push</code>.</td>
</tr>
<tr class="odd">
<td>errors.<code translate="no" dir="ltr">location</code></td>
<td>The specific item within the <code translate="no" dir="ltr">locationType</code> that caused the error. For example, if you specify an invalid value for a parameter, the <code translate="no" dir="ltr">location</code> will be the name of the parameter.<br />
<br />
Example values include: <code translate="no" dir="ltr">Authorization</code>, <code translate="no" dir="ltr">project</code>, and <code translate="no" dir="ltr">projection</code>.</td>
</tr>
<tr class="even">
<td>errors.<code translate="no" dir="ltr">locationType</code></td>
<td>The location or part of the request that caused the error. Use with <code translate="no" dir="ltr">location</code> to pinpoint the error. For example, if you specify an invalid value for a parameter, the <code translate="no" dir="ltr">locationType</code> will be <code translate="no" dir="ltr">parameter</code> and the <code translate="no" dir="ltr">location</code> will be the name of the parameter.<br />
<br />
Example values include <code translate="no" dir="ltr">header</code> and <code translate="no" dir="ltr">parameter</code>.</td>
</tr>
<tr class="odd">
<td>errors.<code translate="no" dir="ltr">message</code></td>
<td>Description of the error.<br />
<br />
Example values include <code translate="no" dir="ltr">Invalid argument</code>, <code translate="no" dir="ltr">Login required</code>, and <code translate="no" dir="ltr">Required parameter: project</code>.</td>
</tr>
<tr class="even">
<td>errors.<code translate="no" dir="ltr">reason</code></td>
<td>Example values include <code translate="no" dir="ltr">invalid</code>, <code translate="no" dir="ltr">invalidParameter</code>, and <code translate="no" dir="ltr">required</code>.</td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">message</code></td>
<td>Description of the error. Same as errors.<code translate="no" dir="ltr">message</code>.</td>
</tr>
</tbody>
</table>

## HTTP Status and Error Codes

This section provides a non-exhaustive list of HTTP status and error codes that the Cloud Storage JSON API uses. The `1xx` Informational and `2xx` Success codes are not discussed here. For more information, see Response Status Codes in <a href="https://datatracker.ietf.org/doc/html/rfc7231#section-6" class="external">RFC 7231 §6</a>, <a href="https://datatracker.ietf.org/doc/html/rfc7232#section-4" class="external">RFC 7232 §4</a>, <a href="https://datatracker.ietf.org/doc/html/rfc7233#section-4" class="external">RFC 7233 §4</a>, <a href="https://datatracker.ietf.org/doc/html/rfc7235#section-3" class="external">RFC 7235 §3</a>, and <a href="https://datatracker.ietf.org/doc/html/rfc6585" class="external">RFC 6585</a>.

### 302—<a href="https://datatracker.ietf.org/doc/html/rfc7231#section-6.4.3" class="external">Found</a>

| Reason | Description                                                                |
|--------|----------------------------------------------------------------------------|
| found  | Resource temporarily located elsewhere according to the `Location` header. |

### 303—<a href="https://datatracker.ietf.org/doc/html/rfc7231#section-6.4.4" class="external">See Other</a>

| Reason                | Description                                                                                                                                                                                                                                    |
|-----------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| mediaDownloadRedirect | When requesting a download using `alt=media` URL parameter, the direct URL path to use is prefixed by `/download`. If this is omitted, the service will issue this redirect with the appropriate media download path in the `Location` header. |

### 304—<a href="https://datatracker.ietf.org/doc/html/rfc7232#section-4.1" class="external">Not Modified</a>

| Reason      | Description                                                                                           |
|-------------|-------------------------------------------------------------------------------------------------------|
| notModified | The conditional request would have been successful, but the condition was false, so no body was sent. |

### 307—<a href="https://datatracker.ietf.org/doc/html/rfc7231#section-6.4.7" class="external">Temporary Redirect</a>

| Reason            | Description                                                                                                                                                                                                                                                                                                                         |
|-------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| temporaryRedirect | Resource temporarily located elsewhere according to the `Location` header. Among other reasons, this can occur when cookie-based authentication is being used, e.g., when using the <a href="https://console.cloud.google.com/storage/browser" class="external">Storage Browser</a>, and it receives a request to download content. |

### 308—Resume Incomplete

| Description                                                                                                                                                   |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Indicates an incomplete resumable upload and provides the range of bytes already received by Cloud Storage. Responses with this status do not contain a body. |

### 400—<a href="https://datatracker.ietf.org/doc/html/rfc7231#section-6.5.1" class="external">Bad Request</a>

| \[Domain.\]Reason                             | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
|-----------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| badRequest                                    | The request cannot be completed based on your current Cloud Storage settings. For example, you cannot lock a retention policy if the requested bucket doesn't have a retention policy, and you cannot set ACLs if the requested bucket has uniform bucket-level access enabled.                                                                                                                                                                                                                                                                                                                                          |
| badRequestException                           | The retention period on a locked bucket cannot be reduced.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
| cloudKmsBadKey                                | Bad Cloud KMS key.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| cloudKmsCannotChangeKeyName                   | Cloud KMS key name cannot be changed.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
| cloudKmsDecryptionKeyNotFound                 | Resource's Cloud KMS decryption key not found.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| cloudKmsDisabledKey                           | Cloud KMS key is disabled, destroyed, or scheduled to be destroyed.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |
| cloudKmsEncryptionKeyNotFound                 | Cloud KMS encryption key not found.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |
| cloudKmsKeyLocationNotAllowed                 | Cloud KMS key location not allowed.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |
| corsRequestWithXOrigin                        | CORS request contains an XD3 X-Origin header.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |
| customerEncryptionAlgorithmIsInvalid          | Missing an encryption algorithm, or the provided algorithm is not "AE256."                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
| customerEncryptionKeyFormatIsInvalid          | Missing an encryption key, or it is not Base64 encoded, or it does not meet the required length of the encryption algorithm.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
| customerEncryptionKeyIsIncorrect              | The provided encryption key is incorrect.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| customerEncryptionKeySha256IsInvalid          | Missing a SHA256 hash of the encryption key, or it is not Base64 encoded, or it does not match the encryption key.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| invalid                                       | This error can occur for several reasons: The request is attempting to set a [retention configuration](/storage/docs/object-lock) for an object such that the `mode` or `retainUntilTime` is not defined; or the request is attempting to set the properties of an object such that it would have a retention configuration and be subject to an [event-based hold](/storage/docs/object-holds) at the same time; or the request is attempting to set an invalid retain-until date; or the request is attempting to set a retention configuration on an object stored in a bucket that doesn't have the feature enabled. |
| invalidAltValue                               | The value for the `alt` URL parameter was not recognized.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| invalidArgument                               | The value for one of fields in the request body was invalid.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
| invalidParameter                              | The value for one of the URL parameters was invalid. In addition to normal URL parameter validation, any URL parameters that have a corresponding value in provided JSON request bodies must match if they are both specified. If using JSONP, you will get this error if you provide an `alt` parameter that is not `json`.                                                                                                                                                                                                                                                                                             |
| notDownload                                   | Uploads or normal API request was sent to a `/download/*` path. Use the same path, but without the `/download` prefix.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| notUpload                                     | Downloads or normal API request was sent to a `/upload/*` path. Use the same path, but without the `/upload` prefix.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| parseError                                    | Couldn't parse the body of the request according to the provided Content-Type.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| required                                      | A required URL parameter or required request body JSON property is missing.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
| resourceIsEncryptedWithCustomerEncryptionKey  | The resource is encrypted with a customer-supplied encryption key, but the request did not provide one.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| resourceNotEncryptedWithCustomerEncryptionKey | The resource is not encrypted with a customer-supplied encryption key, but the request provided one.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| turnedDown                                    | A request was made to an API version that has been turned down. Clients will need to update to a supported version.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |
| userProjectInvalid                            | The user project specified in the request is invalid, either because it is a malformed project id or because it refers to a non-existent project.                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
| userProjectMissing                            | The requested bucket has Requester Pays enabled, the requester is not an owner of the bucket, and no user project was present in the request.                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |
| wrongUrlForUpload                             | [`storage.objects.insert`](/storage/docs/json_api/v1/objects/insert) must be invoked as an upload rather than a metadata.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |

### 401—<a href="https://datatracker.ietf.org/doc/html/rfc7235#section-3.1" class="external">Unauthorized</a>

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th>[Domain.]Reason</th>
<th>Description</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td>AuthenticationRequiredRequesterPays</td>
<td>Access to a Requester Pays bucket requires authentication.</td>
</tr>
<tr class="even">
<td>authError</td>
<td>This error indicates a problem with the authorization provided in the request to Cloud Storage. The following are some situations where that will occur:
<ul>
<li>The OAuth access token has expired and needs to be refreshed. This can be avoided by refreshing the access token early, but code can also catch this error, refresh the token and retry automatically.</li>
<li>Multiple non-matching authorizations were provided; choose one mode only.</li>
<li>The OAuth access token's bound project does not match the project associated with the provided developer key.</li>
<li>The Authorization header was of an unrecognized format or uses an unsupported credential type.</li>
</ul></td>
</tr>
<tr class="odd">
<td>lockedDomainExpired</td>
<td>When downloading content from a cookie-authenticated site, e.g., using the <a href="https://console.cloud.google.com/storage/browser" class="external">Storage Browser</a>, the response will redirect to a temporary domain. This error will occur if access to said domain occurs after the domain expires. Issue the original request again, and receive a new redirect.</td>
</tr>
<tr class="even">
<td>required</td>
<td>Access to a non-public method that requires authorization was made, but none was provided in the Authorization header or through other means.</td>
</tr>
</tbody>
</table>

### 403—<a href="https://datatracker.ietf.org/doc/html/rfc7231#section-6.5.3" class="external">Forbidden</a>

| \[Domain.\]Reason         | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |
|---------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| accountDisabled           | The account associated with the project that owns the bucket or object has been disabled. Check the [Google Cloud console](https://console.cloud.google.com/) to see if there is a problem with billing, and if not, contact account support.                                                                                                                                                                                                                                                                                                                                       |
| countryBlocked            | The Cloud Storage JSON API is restricted by law from operating with certain countries.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
| forbidden                 | This error can occur for several reasons: According to access control policy, the current user does not have access to perform the requested action, and this can occur even if the resource being acted on doesn't exist; or the request is missing the `overrideUnlockedRetention` query parameter but is attempting to change an object's existing [retention configuration](/storage/docs/object-lock) in a way that requires the parameter; or the request is attempting to change a locked object's retention configuration in a way that requires the object to be unlocked. |
| insufficientPermissions   | According to access control policy, the current user does not have access to perform the requested action. This code applies even if the resource being acted on doesn't exist.                                                                                                                                                                                                                                                                                                                                                                                                     |
| objectUnderActiveHold     | Object replacement or deletion is not allowed due to an [active hold](/storage/docs/object-holds#hold-types) on the object.                                                                                                                                                                                                                                                                                                                                                                                                                                                         |
| retentionPolicyNotMet     | The object is under retention and cannot be replaced or deleted until the date and time indicated. The retention might be due to a [retention configuration](/storage/docs/object-lock) on the object, a [retention policy](/storage/docs/bucket-lock#retention-policy) on the bucket, or both.                                                                                                                                                                                                                                                                                     |
| sslRequired               | Requests to this API require SSL.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| UserProjectAccessDenied   | The requester is not authorized to use the project specified in the `userProject` portion of the request. The requester must have the `serviceusage.services.use` permission for the specified project.                                                                                                                                                                                                                                                                                                                                                                             |
| UserProjectAccountProblem | There is a problem with the project used in the request that prevents the operation from completing successfully. One issue could be billing. Check [the billing page](https://console.cloud.google.com/billing) to see if you have a past due balance or if the credit card (or other payment mechanism) on your account is expired. For project creation, [see the Projects page](https://console.cloud.google.com/project) in the Google Cloud console.                                                                                                                          |

### 404—<a href="https://datatracker.ietf.org/doc/html/rfc7231#section-6.5.4" class="external">Not Found</a>

| Reason   | Description                                                                                                                                    |
|----------|------------------------------------------------------------------------------------------------------------------------------------------------|
| notFound | Either there is no API method associated with the URL path of the request, or the request refers to one or more resources that were not found. |

### 405—<a href="https://datatracker.ietf.org/doc/html/rfc7231#section-6.5.5" class="external">Method Not Allowed</a>

| Reason           | Description                                                                                                                                                             |
|------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| methodNotAllowed | The HTTP verb is not supported by the URL endpoint used in the request. This can happen, for example, when using the wrong verb with the `/upload` or `/download` URLs. |

### 408—<a href="https://datatracker.ietf.org/doc/html/rfc7231#section-6.5.7" class="external">Request Timeout</a>

| Reason                 | Description                                                                                                                                                                                                                             |
|------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| uploadBrokenConnection | The request timed out. You should [retry the request](/storage/docs/retry-strategy) using <a href="https://en.wikipedia.org/wiki/Exponential_backoff#Truncated_exponential_backoff" class="external">truncated exponential backoff</a>. |

### 409—<a href="https://datatracker.ietf.org/doc/html/rfc7231#section-6.5.8" class="external">Conflict</a>

| Reason   | Description                                                                                                                                                                                                                                                                                                                                 |
|----------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| conflict | A request to change a resource, usually a `storage.*.update` or `storage.*.patch` method, failed to commit the change due to a conflicting concurrent change to the same resource. The request can be retried, though care should be taken to consider the new state of the resource to avoid blind replacement of another agent's changes. |

### 410—<a href="https://datatracker.ietf.org/doc/html/rfc7231#section-6.5.9" class="external">Gone</a>

| Description                                                                                                                                                                                                                                                                                                           |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| You have attempted to use a [resumable upload session](/storage/docs/resumable-uploads) or [rewrite token](/storage/docs/json_api/v1/objects/rewrite) that is no longer available. If the reported status code was not successful and you still wish to complete the upload or rewrite, you must start a new session. |

### 411—<a href="https://datatracker.ietf.org/doc/html/rfc7231#section-6.5.10" class="external">Length Required</a>

| Description                                                                       |
|-----------------------------------------------------------------------------------|
| You must provide the Content-Length HTTP header. This error has no response body. |

### 412—<a href="https://datatracker.ietf.org/doc/html/rfc7232#section-4.2" class="external">Precondition Failed</a>

| Reason                    | Description                                                    |
|---------------------------|----------------------------------------------------------------|
| conditionNotMet           | At least one of the pre-conditions you specified did not hold. |
| orgPolicyConstraintFailed | Request violates an OrgPolicy constraint.                      |
| softDeletePolicyNotSet    | Bucket does not have a soft delete policy.                     |
| objectNotSoftDeleted      | Object is not soft deleted and is either live or noncurrent.   |

### 413—<a href="https://datatracker.ietf.org/doc/html/rfc7231#section-6.5.11" class="external">Payload Too Large</a>

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th>Reason</th>
<th>Description</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td>uploadTooLarge</td>
<td>This error arises if you:<br />
&#10;<ul>
<li>Attempt to upload an object larger than 5 TiB.</li>
<li>Attempt a <a href="/storage/docs/json_api/v1/objects/copy">Copy request</a> that does not complete within 30 seconds and involves an object larger than 2.5 GiB. In this case, use the <a href="/storage/docs/json_api/v1/objects/rewrite">Rewrite method</a> instead.</li>
</ul></td>
</tr>
</tbody>
</table>

### 416—<a href="https://datatracker.ietf.org/doc/html/rfc7233#section-4.4" class="external">Requested Range Not Satisfiable</a>

| Reason                       | Description                              |
|------------------------------|------------------------------------------|
| requestedRangeNotSatisfiable | The requested Range cannot be satisfied. |

### 429—<a href="https://datatracker.ietf.org/doc/html/rfc6585#section-4" class="external">Too Many Requests</a>

| \[Domain.\]Reason             | Description                                                                                                                                                                                                                                                                                                                                                                                           |
|-------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| usageLimits.rateLimitExceeded | A [Cloud Storage JSON API usage limit](/storage/quotas) was exceeded. If your application tries to use more than its limit, additional requests will fail. Throttle your client's requests, and/or [retry requests](/storage/docs/retry-strategy) using <a href="https://en.wikipedia.org/wiki/Exponential_backoff#Truncated_exponential_backoff" class="external">truncated exponential backoff</a>. |

### 499—Client Closed Request

| Description                                                                                                                                         |
|-----------------------------------------------------------------------------------------------------------------------------------------------------|
| The [resumable upload](/storage/docs/resumable-uploads) was cancelled at the client's request prior to completion. This error has no response body. |

### 500—<a href="https://datatracker.ietf.org/doc/html/rfc7231#section-6.6.1" class="external">Internal Server Error</a>

| Reason        | Description                                                                                                                                                                                                                                        |
|---------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| backendError  | We encountered an internal error. You should [retry the request](/storage/docs/retry-strategy) using <a href="https://en.wikipedia.org/wiki/Exponential_backoff#Truncated_exponential_backoff" class="external">truncated exponential backoff</a>. |
| internalError | We encountered an internal error. You should [retry the request](/storage/docs/retry-strategy) using <a href="https://en.wikipedia.org/wiki/Exponential_backoff#Truncated_exponential_backoff" class="external">truncated exponential backoff</a>. |

### 502—<a href="https://datatracker.ietf.org/doc/html/rfc7231#section-6.6.3" class="external">Bad Gateway</a>

This error is generated when there was difficulty reaching an internal service. It is not formatted with a JSON document. You should [retry the request](/storage/docs/retry-strategy) using <a href="https://en.wikipedia.org/wiki/Exponential_backoff#Truncated_exponential_backoff" class="external">truncated exponential backoff</a>.

### 503—<a href="https://datatracker.ietf.org/doc/html/rfc7231#section-6.6.4" class="external">Service Unavailable</a>

| Reason       | Description                                                                                                                                                                                                                                        |
|--------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| backendError | We encountered an internal error. You should [retry the request](/storage/docs/retry-strategy) using <a href="https://en.wikipedia.org/wiki/Exponential_backoff#Truncated_exponential_backoff" class="external">truncated exponential backoff</a>. |

### 504—<a href="https://datatracker.ietf.org/doc/html/rfc7231#section-6.6.5" class="external">Gateway Timeout</a>

This error is generated when there was difficulty reaching an internal service. It is not formatted with a JSON document. You should [retry the request](/storage/docs/retry-strategy) using <a href="https://en.wikipedia.org/wiki/Exponential_backoff#Truncated_exponential_backoff" class="external">truncated exponential backoff</a>.

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
