# Supported data types

<div class="devsite-article-body clearfix devsite-no-page-title">

# Supported data types

This page describes the data types that Firestore supports.

## Data types

The following table lists the data types supported by Firestore. It also describes the sort order used when comparing values of the same type:

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr class="header">
<th>Data type</th>
<th>Sort order</th>
<th>Notes</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td>32-bit integer</td>
<td>Numeric</td>
<td><p>32-bit, signed</p>
<p><strong>Note:</strong> Supported only in Enterprise edition.</p></td>
</tr>
<tr class="even">
<td>64-bit integer</td>
<td>Numeric</td>
<td>64-bit, signed</td>
</tr>
<tr class="odd">
<td>Array</td>
<td>By element values</td>
<td><p>In Standard edition databases, an array cannot contain another array value as one of its elements. In Enterprise edition databases, an array can contain an array value as one if its elements.</p>
<p>Within an array, elements maintain the position assigned to them. When sorting two or more arrays, arrays are ordered based on their element values.</p>
<p>When comparing two arrays, the first elements of each array are compared. If the first elements are equal, then the second elements are compared, continuing until a difference is found. If an array runs out of elements to compare but is equal up to that point, then the shorter array is ordered before the longer array.</p>
<p>For example, <code translate="no" dir="ltr">[1, 2, 3] &lt; [1, 2, 3, 1] &lt; [2]</code>. The array <code translate="no" dir="ltr">[2]</code> has the greatest first element value. The array <code translate="no" dir="ltr">[1, 2, 3]</code> has elements equal to the first three elements of <code translate="no" dir="ltr">[1, 2, 3, 1]</code> but is shorter in length.</p></td>
</tr>
<tr class="even">
<td>Boolean</td>
<td><code translate="no" dir="ltr">false</code> &lt; <code translate="no" dir="ltr">true</code></td>
<td>—</td>
</tr>
<tr class="odd">
<td>BSON timestamp</td>
<td>Chronological</td>
<td><p>A 64-bit timestamp value comprising Unix seconds and an increment counter.</p>
<p><strong>Note:</strong> Supported only in Enterprise edition.</p></td>
</tr>
<tr class="even">
<td>Bytes</td>
<td>Byte order</td>
<td>In Standard edition databases, the value must not exceed 1,048,487 bytes (1 MiB - 89 bytes) and only the first 1,500 bytes are considered by queries. In Enterprise edition databases, there is no limit on the size of the value (other than document and index entry size limits) and the full value is considered by queries.</td>
</tr>
<tr class="odd">
<td>Bytes with subtype</td>
<td>Byte order (subtype, then value)</td>
<td><p>Binary byte sequence with a BSON subtype indicator.</p>
<p><strong>Note:</strong> Supported only in Enterprise edition.</p></td>
</tr>
<tr class="even">
<td>Date and time</td>
<td>Chronological</td>
<td>When stored in Firestore, precise only to microseconds; any additional precision is rounded down.</td>
</tr>
<tr class="odd">
<td>Decimal128</td>
<td>Numeric</td>
<td><p>128-bit decimal floating-point number for high-precision arithmetic.</p>
<p><strong>Note:</strong> Supported only in Enterprise edition.</p></td>
</tr>
<tr class="even">
<td>Floating-point number</td>
<td>Numeric</td>
<td>64-bit double precision according to <a href="https://en.wikipedia.org/wiki/IEEE_754">IEEE 754</a>, including (normalized) <code translate="no" dir="ltr">NaN</code> &amp; <code translate="no" dir="ltr">+/-Infinity</code>.</td>
</tr>
<tr class="odd">
<td>Geographical point</td>
<td>By latitude, then longitude</td>
<td>To search based on distance, see <a href="/firestore/native/docs/geospatial-search">Geospatial search</a>.</td>
</tr>
<tr class="even">
<td>Map</td>
<td>By keys, then by value</td>
<td><p>Represents an object embedded within a document. When indexed, you can query on subfields. If you exclude this value from indexing, then all subfields are also excluded from indexing.</p>
<p>Key ordering is always sorted. For example, if you write <code translate="no" dir="ltr">{c: "foo", a: "bar", b: "qux"}</code> the map is sorted by key and saved as <code translate="no" dir="ltr">{a: "bar", b: "qux", c: "foo"}</code>.</p>
<p>Map fields are sorted by key and compared by key-value pairs, first comparing the keys and then the values. If the first key-value pairs are equal, the next key-value pairs are compared, continuing until a difference is found. If two maps have all of the same key-value pairs, then map length is considered. For example, the following maps are in ascending order:</p>
<p><code translate="no" dir="ltr">{a: "aaa", b: "baz"}</code><br />
<code translate="no" dir="ltr">{a: "foo", b: "bar"}</code><br />
<code translate="no" dir="ltr">{a: "foo", b: "bar", c: "qux"}</code><br />
<code translate="no" dir="ltr">{a: "foo", b: "baz"}</code><br />
<code translate="no" dir="ltr">{b: "aaa", c: "baz"}</code><br />
<code translate="no" dir="ltr">{c: "aaa"}</code><br />
</p></td>
</tr>
<tr class="odd">
<td>Max key</td>
<td>None</td>
<td><p>Special value that compares higher than all other values.</p>
<p><strong>Note:</strong> Supported only in Enterprise edition.</p></td>
</tr>
<tr class="even">
<td>Min key</td>
<td>None</td>
<td><p>Special value that compares lower than all other values (except null).</p>
<p><strong>Note:</strong> Supported only in Enterprise edition.</p></td>
</tr>
<tr class="odd">
<td>Null</td>
<td>None</td>
<td>—</td>
</tr>
<tr class="even">
<td>ObjectId</td>
<td>Byte order</td>
<td><p>A 12-byte object identifier.</p>
<p><strong>Note:</strong> Supported only in Enterprise edition.</p></td>
</tr>
<tr class="odd">
<td>Reference</td>
<td>By path elements (collection, document ID, collection, document ID...)</td>
<td>For example, <code translate="no" dir="ltr">projects/[PROJECT_ID]/databases/[DATABASE_ID]/documents/[DOCUMENT_PATH]</code>.</td>
</tr>
<tr class="even">
<td>Regular expression</td>
<td>By pattern, then by options</td>
<td><p>A regular expression pattern and options.</p>
<p><strong>Note:</strong> Supported only in Enterprise edition.</p></td>
</tr>
<tr class="odd">
<td>Text string</td>
<td>UTF-8 encoded byte order</td>
<td>In Standard edition databases, the value must not exceed 1,048,487 bytes (1 MiB - 89 bytes) and only the first 1,500 bytes are considered by queries. In Enterprise edition databases, there is no limit on the size of the value (other than document and index entry size limits) and the full value is considered by queries.</td>
</tr>
<tr class="even">
<td>Vector</td>
<td>By dimension and then by individual element values</td>
<td>The max supported embedding dimension is 2048. To store vectors with larger dimensions, use <a href="https://en.wikipedia.org/wiki/Dimensionality_reduction">dimensionality reduction</a>.</td>
</tr>
</tbody>
</table>

## Value type ordering

When a query involves a field with values of mixed types, Firestore uses a deterministic ordering based on the internal representations. The following list shows the order:

1.  Null values
2.  Min key values (Enterprise edition only)
3.  Boolean values
4.  64-bit integer and floating-point values, sorted in numerical order. In Enterprise edition databases, 32-bit integer and Decimal128 values are also included.
5.  Date values
6.  Text string values
7.  Byte values. In Enterprise edition, bytes with subtype values are also included.
8.  Firestore references
9.  ObjectId values (Enterprise edition only)
10. Geographical point values
11. Regular Expression (Enterprise edition only)
12. Array values
13. Vector embeddings
14. Map values
15. Max key values (Enterprise edition only)

## Numeric ordering

Firestore sorts all numeric values (`Integer` & `Floating point`) interleaved with each other. Floating point comparison follows the total ordering of [IEEE 754](https://en.wikipedia.org/wiki/IEEE_754) with the notable exception being that Firestore normalizes all `NaN` values, and considers it less than `-Infinity`.

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
