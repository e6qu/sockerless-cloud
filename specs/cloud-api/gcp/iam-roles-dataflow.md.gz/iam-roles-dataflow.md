# Dataflow roles and permissions

<div class="devsite-article-body clearfix">

This page lists the IAM roles and permissions for Dataflow. To search through all roles and permissions, see the [role and permission index](/iam/docs/roles-permissions).

## Dataflow roles

<div results-count-container="">

</div>

<table class="fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="50%">Role</th>
<th>Permissions</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td class="role-description"><h4 id="dataflow.admin" class="role-title add-link" data-text="Dataflow Admin " tabindex="-1">Dataflow Admin</h4>
<p>(<code translate="no" dir="ltr">roles/dataflow.admin</code>)</p>
<span class="role-description"> </span>
<p>Minimal role for creating and managing dataflow jobs.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudbuild.builds.create</code></p>
<p><code translate="no" dir="ltr">cloudbuild.builds.get</code></p>
<p><code translate="no" dir="ltr">cloudbuild.builds.list</code></p>
<p><code translate="no" dir="ltr">cloudbuild.builds.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudbuild.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudbuild.locations.get</code></li>
<li><code translate="no" dir="ltr">cloudbuild.locations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudbuild.operations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudbuild.operations.get</code></li>
<li><code translate="no" dir="ltr">cloudbuild.operations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudkms.keyHandles.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudkms.keyHandles.create</code></li>
<li><code translate="no" dir="ltr">cloudkms.keyHandles.get</code></li>
<li><code translate="no" dir="ltr">cloudkms.keyHandles.list</code></li>
</ul>
<p><code translate="no" dir="ltr">cloudkms.operations.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.projects.showEffectiveAutokeyConfig</code></p>
<p><code translate="no" dir="ltr">compute.machineTypes.get</code></p>
<p><code translate="no" dir="ltr">compute.projects.get</code></p>
<p><code translate="no" dir="ltr">compute.regions.list</code></p>
<p><code translate="no" dir="ltr">compute.zones.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">dataflow.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">dataflow.jobs.cancel</code></li>
<li><code translate="no" dir="ltr">dataflow.jobs.create</code></li>
<li><code translate="no" dir="ltr">dataflow.jobs.createTagBinding</code></li>
<li><code translate="no" dir="ltr">dataflow.jobs.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">dataflow.jobs.get</code></li>
<li><code translate="no" dir="ltr">dataflow.jobs.list</code></li>
<li><code translate="no" dir="ltr">dataflow.jobs.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">dataflow.jobs.listTagBindings</code></li>
<li><code translate="no" dir="ltr">dataflow.jobs.snapshot</code></li>
<li><code translate="no" dir="ltr">dataflow.jobs.updateContents</code></li>
<li><code translate="no" dir="ltr">dataflow.messages.list</code></li>
<li><code translate="no" dir="ltr">dataflow.metrics.get</code></li>
<li><code translate="no" dir="ltr">dataflow.shuffle.read</code></li>
<li><code translate="no" dir="ltr">dataflow.shuffle.write</code></li>
<li><code translate="no" dir="ltr">dataflow.snapshots.createTagBinding</code></li>
<li><code translate="no" dir="ltr">dataflow.snapshots.delete</code></li>
<li><code translate="no" dir="ltr">dataflow.snapshots.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">dataflow.snapshots.get</code></li>
<li><code translate="no" dir="ltr">dataflow.snapshots.list</code></li>
<li><code translate="no" dir="ltr">dataflow.snapshots.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">dataflow.snapshots.listTagBindings</code></li>
<li><code translate="no" dir="ltr">dataflow.streamingWorkItems.ImportState</code></li>
<li><code translate="no" dir="ltr">dataflow.streamingWorkItems.commitWork</code></li>
<li><code translate="no" dir="ltr">dataflow.streamingWorkItems.getData</code></li>
<li><code translate="no" dir="ltr">dataflow.streamingWorkItems.getWork</code></li>
<li><code translate="no" dir="ltr">dataflow.streamingWorkItems.getWorkerMetadata</code></li>
<li><code translate="no" dir="ltr">dataflow.workItems.lease</code></li>
<li><code translate="no" dir="ltr">dataflow.workItems.sendMessage</code></li>
<li><code translate="no" dir="ltr">dataflow.workItems.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.dataflowDiagnosticsInsights.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.dataflowDiagnosticsInsights.get</code></li>
<li><code translate="no" dir="ltr">recommender.dataflowDiagnosticsInsights.list</code></li>
<li><code translate="no" dir="ltr">recommender.dataflowDiagnosticsInsights.update</code></li>
</ul>
<p><code translate="no" dir="ltr">remotebuildexecution.blobs.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><code translate="no" dir="ltr">storage.buckets.get</code></p>
<p><code translate="no" dir="ltr">storage.objects.create</code></p>
<p><code translate="no" dir="ltr">storage.objects.get</code></p>
<p><code translate="no" dir="ltr">storage.objects.list</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="dataflow.viewer" class="role-title add-link" data-text="Dataflow Viewer " tabindex="-1">Dataflow Viewer</h4>
<p>(<code translate="no" dir="ltr">roles/dataflow.viewer</code>)</p>
<span class="role-description custom"> </span>
<p>Provides read-only access to all Dataflow-related resources.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Project</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">dataflow.jobs.get</code></p>
<p><code translate="no" dir="ltr">dataflow.jobs.list</code></p>
<p><code translate="no" dir="ltr">dataflow.jobs.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">dataflow.jobs.listTagBindings</code></p>
<p><code translate="no" dir="ltr">dataflow.messages.list</code></p>
<p><code translate="no" dir="ltr">dataflow.metrics.get</code></p>
<p><code translate="no" dir="ltr">dataflow.snapshots.get</code></p>
<p><code translate="no" dir="ltr">dataflow.snapshots.list</code></p>
<p><code translate="no" dir="ltr">dataflow.snapshots.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">dataflow.snapshots.listTagBindings</code></p>
<p><code translate="no" dir="ltr">recommender.dataflowDiagnosticsInsights.get</code></p>
<p><code translate="no" dir="ltr">recommender.dataflowDiagnosticsInsights.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="dataflow.developer" class="role-title add-link" data-text="Dataflow Developer " tabindex="-1">Dataflow Developer</h4>
<p>(<code translate="no" dir="ltr">roles/dataflow.developer</code>)</p>
<span class="role-description custom"> </span>
<p>Provides the permissions necessary to execute and manipulate Dataflow jobs.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Project</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudbuild.builds.create</code></p>
<p><code translate="no" dir="ltr">cloudbuild.builds.get</code></p>
<p><code translate="no" dir="ltr">cloudbuild.builds.list</code></p>
<p><code translate="no" dir="ltr">cloudbuild.builds.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudbuild.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudbuild.locations.get</code></li>
<li><code translate="no" dir="ltr">cloudbuild.locations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudbuild.operations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudbuild.operations.get</code></li>
<li><code translate="no" dir="ltr">cloudbuild.operations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">cloudkms.keyHandles.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">cloudkms.keyHandles.create</code></li>
<li><code translate="no" dir="ltr">cloudkms.keyHandles.get</code></li>
<li><code translate="no" dir="ltr">cloudkms.keyHandles.list</code></li>
</ul>
<p><code translate="no" dir="ltr">cloudkms.operations.get</code></p>
<p><code translate="no" dir="ltr">cloudkms.projects.showEffectiveAutokeyConfig</code></p>
<p><code translate="no" dir="ltr">compute.projects.get</code></p>
<p><code translate="no" dir="ltr">compute.regions.list</code></p>
<p><code translate="no" dir="ltr">compute.zones.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">dataflow.jobs.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">dataflow.jobs.cancel</code></li>
<li><code translate="no" dir="ltr">dataflow.jobs.create</code></li>
<li><code translate="no" dir="ltr">dataflow.jobs.createTagBinding</code></li>
<li><code translate="no" dir="ltr">dataflow.jobs.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">dataflow.jobs.get</code></li>
<li><code translate="no" dir="ltr">dataflow.jobs.list</code></li>
<li><code translate="no" dir="ltr">dataflow.jobs.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">dataflow.jobs.listTagBindings</code></li>
<li><code translate="no" dir="ltr">dataflow.jobs.snapshot</code></li>
<li><code translate="no" dir="ltr">dataflow.jobs.updateContents</code></li>
</ul>
<p><code translate="no" dir="ltr">dataflow.messages.list</code></p>
<p><code translate="no" dir="ltr">dataflow.metrics.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">dataflow.snapshots.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">dataflow.snapshots.createTagBinding</code></li>
<li><code translate="no" dir="ltr">dataflow.snapshots.delete</code></li>
<li><code translate="no" dir="ltr">dataflow.snapshots.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">dataflow.snapshots.get</code></li>
<li><code translate="no" dir="ltr">dataflow.snapshots.list</code></li>
<li><code translate="no" dir="ltr">dataflow.snapshots.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">dataflow.snapshots.listTagBindings</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.dataflowDiagnosticsInsights.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.dataflowDiagnosticsInsights.get</code></li>
<li><code translate="no" dir="ltr">recommender.dataflowDiagnosticsInsights.list</code></li>
<li><code translate="no" dir="ltr">recommender.dataflowDiagnosticsInsights.update</code></li>
</ul>
<p><code translate="no" dir="ltr">remotebuildexecution.blobs.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="dataflow.worker" class="role-title add-link" data-text="Dataflow Worker " tabindex="-1">Dataflow Worker</h4>
<p>(<code translate="no" dir="ltr">roles/dataflow.worker</code>)</p>
<span class="role-description custom"> </span>
<p>Provides the permissions necessary for a Compute Engine service account to execute work units for a Dataflow pipeline.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Project</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">autoscaling.sites.readRecommendations</code></p>
<p><code translate="no" dir="ltr">autoscaling.sites.writeMetrics</code></p>
<p><code translate="no" dir="ltr">autoscaling.sites.writeState</code></p>
<p><code translate="no" dir="ltr">compute.instanceGroupManagers.update</code></p>
<p><code translate="no" dir="ltr">compute.instances.delete</code></p>
<p><code translate="no" dir="ltr">compute.instances.setDiskAutoDelete</code></p>
<p><code translate="no" dir="ltr">dataflow.jobs.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">dataflow.shuffle.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">dataflow.shuffle.read</code></li>
<li><code translate="no" dir="ltr">dataflow.shuffle.write</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">dataflow.streamingWorkItems.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">dataflow.streamingWorkItems.ImportState</code></li>
<li><code translate="no" dir="ltr">dataflow.streamingWorkItems.commitWork</code></li>
<li><code translate="no" dir="ltr">dataflow.streamingWorkItems.getData</code></li>
<li><code translate="no" dir="ltr">dataflow.streamingWorkItems.getWork</code></li>
<li><code translate="no" dir="ltr">dataflow.streamingWorkItems.getWorkerMetadata</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">dataflow.workItems.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">dataflow.workItems.lease</code></li>
<li><code translate="no" dir="ltr">dataflow.workItems.sendMessage</code></li>
<li><code translate="no" dir="ltr">dataflow.workItems.update</code></li>
</ul>
<p><code translate="no" dir="ltr">logging.logEntries.create</code></p>
<p><code translate="no" dir="ltr">logging.logEntries.route</code></p>
<p><code translate="no" dir="ltr">monitoring.timeSeries.create</code></p>
<p><code translate="no" dir="ltr">storage.buckets.get</code></p>
<p><code translate="no" dir="ltr">storage.objects.create</code></p>
<p><code translate="no" dir="ltr">storage.objects.get</code></p></td>
</tr>
</tbody>
</table>

### Service agent roles

Service agent roles should only be granted to [service agents](/iam/docs/service-agents).

<div results-count-container="">

</div>

<table class="fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="50%">Role</th>
<th>Permissions</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td class="role-description"><h4 id="dataflow.serviceAgent" class="role-title add-link" data-text="Cloud Dataflow Service Agent " tabindex="-1">Cloud Dataflow Service Agent</h4>
<p>(<code translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</p>
<span class="role-description"> </span>
<p>Gives Cloud Dataflow service account access to managed resources. Includes access to service accounts.</p>
<strong>Warning:</strong> Do not grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.</td>
<td class="role-permissions"><p><code translate="no" dir="ltr">backupdr.backupPlanAssociations.createForComputeDisk</code></p>
<p><code translate="no" dir="ltr">backupdr.backupPlanAssociations.createForComputeInstance</code></p>
<p><code translate="no" dir="ltr">backupdr.backupPlanAssociations.deleteForComputeDisk</code></p>
<p><code translate="no" dir="ltr">backupdr.backupPlanAssociations.deleteForComputeInstance</code></p>
<p><code translate="no" dir="ltr">backupdr.backupPlanAssociations.fetchForComputeDisk</code></p>
<p><code translate="no" dir="ltr">backupdr.backupPlanAssociations.getForComputeDisk</code></p>
<p><code translate="no" dir="ltr">backupdr.backupPlanAssociations.list</code></p>
<p><code translate="no" dir="ltr">backupdr.backupPlanAssociations.triggerBackupForComputeDisk</code></p>
<p><code translate="no" dir="ltr">backupdr.backupPlanAssociations.triggerBackupForComputeInstance</code></p>
<p><code translate="no" dir="ltr">backupdr.backupPlanAssociations.updateForComputeDisk</code></p>
<p><code translate="no" dir="ltr">backupdr.backupPlanAssociations.updateForComputeInstance</code></p>
<p><code translate="no" dir="ltr">backupdr.backupPlans.get</code></p>
<p><code translate="no" dir="ltr">backupdr.backupPlans.list</code></p>
<p><code translate="no" dir="ltr">backupdr.backupPlans.useForComputeDisk</code></p>
<p><code translate="no" dir="ltr">backupdr.backupPlans.useForComputeInstance</code></p>
<p><code translate="no" dir="ltr">backupdr.backupVaults.get</code></p>
<p><code translate="no" dir="ltr">backupdr.backupVaults.list</code></p>
<p><code translate="no" dir="ltr">backupdr.locations.list</code></p>
<p><code translate="no" dir="ltr">backupdr.operations.get</code></p>
<p><code translate="no" dir="ltr">backupdr.operations.list</code></p>
<p><code translate="no" dir="ltr">backupdr.serviceConfig.initialize</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.bireservations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.bireservations.get</code></li>
<li><code translate="no" dir="ltr">bigquery.bireservations.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.capacityCommitments.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.capacityCommitments.create</code></li>
<li><code translate="no" dir="ltr">bigquery.capacityCommitments.delete</code></li>
<li><code translate="no" dir="ltr">bigquery.capacityCommitments.get</code></li>
<li><code translate="no" dir="ltr">bigquery.capacityCommitments.list</code></li>
<li><code translate="no" dir="ltr">bigquery.capacityCommitments.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.config.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.config.get</code></li>
<li><code translate="no" dir="ltr">bigquery.config.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.connections.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.connections.create</code></li>
<li><code translate="no" dir="ltr">bigquery.connections.delegate</code></li>
<li><code translate="no" dir="ltr">bigquery.connections.delete</code></li>
<li><code translate="no" dir="ltr">bigquery.connections.get</code></li>
<li><code translate="no" dir="ltr">bigquery.connections.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">bigquery.connections.list</code></li>
<li><code translate="no" dir="ltr">bigquery.connections.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">bigquery.connections.update</code></li>
<li><code translate="no" dir="ltr">bigquery.connections.updateTag</code></li>
<li><code translate="no" dir="ltr">bigquery.connections.use</code></li>
</ul>
<p><code translate="no" dir="ltr">bigquery.dataPolicies.attach</code></p>
<p><code translate="no" dir="ltr">bigquery.dataPolicies.create</code></p>
<p><code translate="no" dir="ltr">bigquery.dataPolicies.delete</code></p>
<p><code translate="no" dir="ltr">bigquery.dataPolicies.get</code></p>
<p><code translate="no" dir="ltr">bigquery.dataPolicies.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigquery.dataPolicies.list</code></p>
<p><code translate="no" dir="ltr">bigquery.dataPolicies.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigquery.dataPolicies.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.datasets.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.datasets.create</code></li>
<li><code translate="no" dir="ltr">bigquery.datasets.createTagBinding</code></li>
<li><code translate="no" dir="ltr">bigquery.datasets.delete</code></li>
<li><code translate="no" dir="ltr">bigquery.datasets.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">bigquery.datasets.get</code></li>
<li><code translate="no" dir="ltr">bigquery.datasets.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">bigquery.datasets.link</code></li>
<li><code translate="no" dir="ltr">bigquery.datasets.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">bigquery.datasets.listSharedDatasetUsage</code></li>
<li><code translate="no" dir="ltr">bigquery.datasets.listTagBindings</code></li>
<li><code translate="no" dir="ltr">bigquery.datasets.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">bigquery.datasets.update</code></li>
<li><code translate="no" dir="ltr">bigquery.datasets.updateTag</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.jobs.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.jobs.create</code></li>
<li><code translate="no" dir="ltr">bigquery.jobs.createGlobalQuery</code></li>
<li><code translate="no" dir="ltr">bigquery.jobs.delete</code></li>
<li><code translate="no" dir="ltr">bigquery.jobs.get</code></li>
<li><code translate="no" dir="ltr">bigquery.jobs.list</code></li>
<li><code translate="no" dir="ltr">bigquery.jobs.listAll</code></li>
<li><code translate="no" dir="ltr">bigquery.jobs.listExecutionMetadata</code></li>
<li><code translate="no" dir="ltr">bigquery.jobs.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.models.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.models.create</code></li>
<li><code translate="no" dir="ltr">bigquery.models.delete</code></li>
<li><code translate="no" dir="ltr">bigquery.models.export</code></li>
<li><code translate="no" dir="ltr">bigquery.models.getData</code></li>
<li><code translate="no" dir="ltr">bigquery.models.getMetadata</code></li>
<li><code translate="no" dir="ltr">bigquery.models.list</code></li>
<li><code translate="no" dir="ltr">bigquery.models.updateData</code></li>
<li><code translate="no" dir="ltr">bigquery.models.updateMetadata</code></li>
<li><code translate="no" dir="ltr">bigquery.models.updateTag</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.objectRefs.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.objectRefs.read</code></li>
<li><code translate="no" dir="ltr">bigquery.objectRefs.write</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.propertyGraphs.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.propertyGraphs.create</code></li>
<li><code translate="no" dir="ltr">bigquery.propertyGraphs.delete</code></li>
<li><code translate="no" dir="ltr">bigquery.propertyGraphs.get</code></li>
<li><code translate="no" dir="ltr">bigquery.propertyGraphs.list</code></li>
<li><code translate="no" dir="ltr">bigquery.propertyGraphs.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.readsessions.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.readsessions.create</code></li>
<li><code translate="no" dir="ltr">bigquery.readsessions.getData</code></li>
<li><code translate="no" dir="ltr">bigquery.readsessions.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.reservationAssignments.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.reservationAssignments.create</code></li>
<li><code translate="no" dir="ltr">bigquery.reservationAssignments.delete</code></li>
<li><code translate="no" dir="ltr">bigquery.reservationAssignments.list</code></li>
<li><code translate="no" dir="ltr">bigquery.reservationAssignments.search</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.reservationGroups.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.reservationGroups.create</code></li>
<li><code translate="no" dir="ltr">bigquery.reservationGroups.delete</code></li>
<li><code translate="no" dir="ltr">bigquery.reservationGroups.get</code></li>
<li><code translate="no" dir="ltr">bigquery.reservationGroups.list</code></li>
<li><code translate="no" dir="ltr">bigquery.reservationGroups.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.reservations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.reservations.create</code></li>
<li><code translate="no" dir="ltr">bigquery.reservations.delete</code></li>
<li><code translate="no" dir="ltr">bigquery.reservations.get</code></li>
<li><code translate="no" dir="ltr">bigquery.reservations.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">bigquery.reservations.list</code></li>
<li><code translate="no" dir="ltr">bigquery.reservations.listFailoverDatasets</code></li>
<li><code translate="no" dir="ltr">bigquery.reservations.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">bigquery.reservations.update</code></li>
<li><code translate="no" dir="ltr">bigquery.reservations.use</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.routines.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.routines.create</code></li>
<li><code translate="no" dir="ltr">bigquery.routines.delete</code></li>
<li><code translate="no" dir="ltr">bigquery.routines.get</code></li>
<li><code translate="no" dir="ltr">bigquery.routines.list</code></li>
<li><code translate="no" dir="ltr">bigquery.routines.update</code></li>
<li><code translate="no" dir="ltr">bigquery.routines.updateTag</code></li>
</ul>
<p><code translate="no" dir="ltr">bigquery.rowAccessPolicies.create</code></p>
<p><code translate="no" dir="ltr">bigquery.rowAccessPolicies.delete</code></p>
<p><code translate="no" dir="ltr">bigquery.rowAccessPolicies.get</code></p>
<p><code translate="no" dir="ltr">bigquery.rowAccessPolicies.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigquery.rowAccessPolicies.list</code></p>
<p><code translate="no" dir="ltr">bigquery.rowAccessPolicies.overrideTimeTravelRestrictions</code></p>
<p><code translate="no" dir="ltr">bigquery.rowAccessPolicies.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigquery.rowAccessPolicies.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.savedqueries.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.savedqueries.create</code></li>
<li><code translate="no" dir="ltr">bigquery.savedqueries.delete</code></li>
<li><code translate="no" dir="ltr">bigquery.savedqueries.get</code></li>
<li><code translate="no" dir="ltr">bigquery.savedqueries.list</code></li>
<li><code translate="no" dir="ltr">bigquery.savedqueries.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.tables.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.tables.create</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.createIndex</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.createSnapshot</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.createTagBinding</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.delete</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.deleteIndex</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.deleteSnapshot</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.export</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.get</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.getData</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.list</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.listTagBindings</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.replicateData</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.restoreSnapshot</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.setCategory</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.setColumnDataPolicy</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.update</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.updateData</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.updateIndex</code></li>
<li><code translate="no" dir="ltr">bigquery.tables.updateTag</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">bigquery.transfers.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">bigquery.transfers.get</code></li>
<li><code translate="no" dir="ltr">bigquery.transfers.update</code></li>
</ul>
<p><code translate="no" dir="ltr">bigquerymigration.translation.translate</code></p>
<p><code translate="no" dir="ltr">cloudaicompanion.instances.completeTask</code></p>
<p><code translate="no" dir="ltr">clouddebugger.breakpoints.list</code></p>
<p><code translate="no" dir="ltr">clouddebugger.breakpoints.listActive</code></p>
<p><code translate="no" dir="ltr">clouddebugger.breakpoints.update</code></p>
<p><code translate="no" dir="ltr">clouddebugger.debuggees.create</code></p>
<p><code translate="no" dir="ltr">cloudnotifications.activities.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.acceleratorTypes.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.acceleratorTypes.get</code></li>
<li><code translate="no" dir="ltr">compute.acceleratorTypes.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.addresses.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.addresses.create</code></li>
<li><code translate="no" dir="ltr">compute.addresses.createInternal</code></li>
<li><code translate="no" dir="ltr">compute.addresses.createTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.addresses.delete</code></li>
<li><code translate="no" dir="ltr">compute.addresses.deleteInternal</code></li>
<li><code translate="no" dir="ltr">compute.addresses.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.addresses.get</code></li>
<li><code translate="no" dir="ltr">compute.addresses.list</code></li>
<li><code translate="no" dir="ltr">compute.addresses.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">compute.addresses.listTagBindings</code></li>
<li><code translate="no" dir="ltr">compute.addresses.setLabels</code></li>
<li><code translate="no" dir="ltr">compute.addresses.use</code></li>
<li><code translate="no" dir="ltr">compute.addresses.useInternal</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.autoscalers.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.autoscalers.create</code></li>
<li><code translate="no" dir="ltr">compute.autoscalers.delete</code></li>
<li><code translate="no" dir="ltr">compute.autoscalers.get</code></li>
<li><code translate="no" dir="ltr">compute.autoscalers.list</code></li>
<li><code translate="no" dir="ltr">compute.autoscalers.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.backendBuckets.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.backendBuckets.addSignedUrlKey</code></li>
<li><code translate="no" dir="ltr">compute.backendBuckets.create</code></li>
<li><code translate="no" dir="ltr">compute.backendBuckets.createTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.backendBuckets.delete</code></li>
<li><code translate="no" dir="ltr">compute.backendBuckets.deleteSignedUrlKey</code></li>
<li><code translate="no" dir="ltr">compute.backendBuckets.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.backendBuckets.get</code></li>
<li><code translate="no" dir="ltr">compute.backendBuckets.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">compute.backendBuckets.list</code></li>
<li><code translate="no" dir="ltr">compute.backendBuckets.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">compute.backendBuckets.listTagBindings</code></li>
<li><code translate="no" dir="ltr">compute.backendBuckets.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">compute.backendBuckets.setSecurityPolicy</code></li>
<li><code translate="no" dir="ltr">compute.backendBuckets.update</code></li>
<li><code translate="no" dir="ltr">compute.backendBuckets.use</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.backendServices.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.backendServices.addSignedUrlKey</code></li>
<li><code translate="no" dir="ltr">compute.backendServices.create</code></li>
<li><code translate="no" dir="ltr">compute.backendServices.createTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.backendServices.delete</code></li>
<li><code translate="no" dir="ltr">compute.backendServices.deleteSignedUrlKey</code></li>
<li><code translate="no" dir="ltr">compute.backendServices.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.backendServices.get</code></li>
<li><code translate="no" dir="ltr">compute.backendServices.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">compute.backendServices.list</code></li>
<li><code translate="no" dir="ltr">compute.backendServices.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">compute.backendServices.listTagBindings</code></li>
<li><code translate="no" dir="ltr">compute.backendServices.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">compute.backendServices.setSecurityPolicy</code></li>
<li><code translate="no" dir="ltr">compute.backendServices.update</code></li>
<li><code translate="no" dir="ltr">compute.backendServices.use</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.crossSiteNetworks.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.crossSiteNetworks.create</code></li>
<li><code translate="no" dir="ltr">compute.crossSiteNetworks.delete</code></li>
<li><code translate="no" dir="ltr">compute.crossSiteNetworks.get</code></li>
<li><code translate="no" dir="ltr">compute.crossSiteNetworks.list</code></li>
<li><code translate="no" dir="ltr">compute.crossSiteNetworks.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.dhcpOptionsConfigs.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.dhcpOptionsConfigs.create</code></li>
<li><code translate="no" dir="ltr">compute.dhcpOptionsConfigs.delete</code></li>
<li><code translate="no" dir="ltr">compute.dhcpOptionsConfigs.get</code></li>
<li><code translate="no" dir="ltr">compute.dhcpOptionsConfigs.list</code></li>
<li><code translate="no" dir="ltr">compute.dhcpOptionsConfigs.update</code></li>
<li><code translate="no" dir="ltr">compute.dhcpOptionsConfigs.use</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.diskSettings.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.diskSettings.get</code></li>
<li><code translate="no" dir="ltr">compute.diskSettings.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.diskTypes.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.diskTypes.get</code></li>
<li><code translate="no" dir="ltr">compute.diskTypes.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.disks.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.disks.addResourcePolicies</code></li>
<li><code translate="no" dir="ltr">compute.disks.create</code></li>
<li><code translate="no" dir="ltr">compute.disks.createSnapshot</code></li>
<li><code translate="no" dir="ltr">compute.disks.createTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.disks.delete</code></li>
<li><code translate="no" dir="ltr">compute.disks.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.disks.get</code></li>
<li><code translate="no" dir="ltr">compute.disks.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">compute.disks.list</code></li>
<li><code translate="no" dir="ltr">compute.disks.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">compute.disks.listTagBindings</code></li>
<li><code translate="no" dir="ltr">compute.disks.removeResourcePolicies</code></li>
<li><code translate="no" dir="ltr">compute.disks.resize</code></li>
<li><code translate="no" dir="ltr">compute.disks.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">compute.disks.setLabels</code></li>
<li><code translate="no" dir="ltr">compute.disks.startAsyncReplication</code></li>
<li><code translate="no" dir="ltr">compute.disks.stopAsyncReplication</code></li>
<li><code translate="no" dir="ltr">compute.disks.stopGroupAsyncReplication</code></li>
<li><code translate="no" dir="ltr">compute.disks.update</code></li>
<li><code translate="no" dir="ltr">compute.disks.updateKmsKey</code></li>
<li><code translate="no" dir="ltr">compute.disks.use</code></li>
<li><code translate="no" dir="ltr">compute.disks.useReadOnly</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.externalVpnGateways.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.externalVpnGateways.create</code></li>
<li><code translate="no" dir="ltr">compute.externalVpnGateways.createTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.externalVpnGateways.delete</code></li>
<li><code translate="no" dir="ltr">compute.externalVpnGateways.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.externalVpnGateways.get</code></li>
<li><code translate="no" dir="ltr">compute.externalVpnGateways.list</code></li>
<li><code translate="no" dir="ltr">compute.externalVpnGateways.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">compute.externalVpnGateways.listTagBindings</code></li>
<li><code translate="no" dir="ltr">compute.externalVpnGateways.setLabels</code></li>
<li><code translate="no" dir="ltr">compute.externalVpnGateways.use</code></li>
</ul>
<p><code translate="no" dir="ltr">compute.firewallPolicies.get</code></p>
<p><code translate="no" dir="ltr">compute.firewallPolicies.list</code></p>
<p><code translate="no" dir="ltr">compute.firewallPolicies.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.firewallPolicies.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.firewallPolicies.use</code></p>
<p><code translate="no" dir="ltr">compute.firewalls.get</code></p>
<p><code translate="no" dir="ltr">compute.firewalls.list</code></p>
<p><code translate="no" dir="ltr">compute.firewalls.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.firewalls.listTagBindings</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.forwardingRules.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.forwardingRules.create</code></li>
<li><code translate="no" dir="ltr">compute.forwardingRules.createTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.forwardingRules.delete</code></li>
<li><code translate="no" dir="ltr">compute.forwardingRules.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.forwardingRules.get</code></li>
<li><code translate="no" dir="ltr">compute.forwardingRules.list</code></li>
<li><code translate="no" dir="ltr">compute.forwardingRules.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">compute.forwardingRules.listTagBindings</code></li>
<li><code translate="no" dir="ltr">compute.forwardingRules.pscCreate</code></li>
<li><code translate="no" dir="ltr">compute.forwardingRules.pscDelete</code></li>
<li><code translate="no" dir="ltr">compute.forwardingRules.pscSetLabels</code></li>
<li><code translate="no" dir="ltr">compute.forwardingRules.pscUpdate</code></li>
<li><code translate="no" dir="ltr">compute.forwardingRules.setLabels</code></li>
<li><code translate="no" dir="ltr">compute.forwardingRules.setTarget</code></li>
<li><code translate="no" dir="ltr">compute.forwardingRules.update</code></li>
<li><code translate="no" dir="ltr">compute.forwardingRules.use</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.globalAddresses.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.globalAddresses.create</code></li>
<li><code translate="no" dir="ltr">compute.globalAddresses.createInternal</code></li>
<li><code translate="no" dir="ltr">compute.globalAddresses.createTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.globalAddresses.delete</code></li>
<li><code translate="no" dir="ltr">compute.globalAddresses.deleteInternal</code></li>
<li><code translate="no" dir="ltr">compute.globalAddresses.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.globalAddresses.get</code></li>
<li><code translate="no" dir="ltr">compute.globalAddresses.list</code></li>
<li><code translate="no" dir="ltr">compute.globalAddresses.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">compute.globalAddresses.listTagBindings</code></li>
<li><code translate="no" dir="ltr">compute.globalAddresses.setLabels</code></li>
<li><code translate="no" dir="ltr">compute.globalAddresses.use</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.globalForwardingRules.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.globalForwardingRules.create</code></li>
<li><code translate="no" dir="ltr">compute.globalForwardingRules.createTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.globalForwardingRules.delete</code></li>
<li><code translate="no" dir="ltr">compute.globalForwardingRules.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.globalForwardingRules.get</code></li>
<li><code translate="no" dir="ltr">compute.globalForwardingRules.list</code></li>
<li><code translate="no" dir="ltr">compute.globalForwardingRules.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">compute.globalForwardingRules.listTagBindings</code></li>
<li><code translate="no" dir="ltr">compute.globalForwardingRules.pscCreate</code></li>
<li><code translate="no" dir="ltr">compute.globalForwardingRules.pscDelete</code></li>
<li><code translate="no" dir="ltr">compute.globalForwardingRules.pscSetLabels</code></li>
<li><code translate="no" dir="ltr">compute.globalForwardingRules.pscUpdate</code></li>
<li><code translate="no" dir="ltr">compute.globalForwardingRules.setLabels</code></li>
<li><code translate="no" dir="ltr">compute.globalForwardingRules.setTarget</code></li>
<li><code translate="no" dir="ltr">compute.globalForwardingRules.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.globalFrontendSettings.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.globalFrontendSettings.get</code></li>
<li><code translate="no" dir="ltr">compute.globalFrontendSettings.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.globalNetworkEndpointGroups.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.globalNetworkEndpointGroups.attachNetworkEndpoints</code></li>
<li><code translate="no" dir="ltr">compute.globalNetworkEndpointGroups.create</code></li>
<li><code translate="no" dir="ltr">compute.globalNetworkEndpointGroups.createTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.globalNetworkEndpointGroups.delete</code></li>
<li><code translate="no" dir="ltr">compute.globalNetworkEndpointGroups.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.globalNetworkEndpointGroups.detachNetworkEndpoints</code></li>
<li><code translate="no" dir="ltr">compute.globalNetworkEndpointGroups.get</code></li>
<li><code translate="no" dir="ltr">compute.globalNetworkEndpointGroups.list</code></li>
<li><code translate="no" dir="ltr">compute.globalNetworkEndpointGroups.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">compute.globalNetworkEndpointGroups.listTagBindings</code></li>
<li><code translate="no" dir="ltr">compute.globalNetworkEndpointGroups.use</code></li>
</ul>
<p><code translate="no" dir="ltr">compute.globalOperations.get</code></p>
<p><code translate="no" dir="ltr">compute.globalOperations.list</code></p>
<p><code translate="no" dir="ltr">compute.globalPublicDelegatedPrefixes.delete</code></p>
<p><code translate="no" dir="ltr">compute.globalPublicDelegatedPrefixes.get</code></p>
<p><code translate="no" dir="ltr">compute.globalPublicDelegatedPrefixes.list</code></p>
<p><code translate="no" dir="ltr">compute.globalPublicDelegatedPrefixes.updatePolicy</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.healthChecks.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.healthChecks.create</code></li>
<li><code translate="no" dir="ltr">compute.healthChecks.createTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.healthChecks.delete</code></li>
<li><code translate="no" dir="ltr">compute.healthChecks.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.healthChecks.get</code></li>
<li><code translate="no" dir="ltr">compute.healthChecks.list</code></li>
<li><code translate="no" dir="ltr">compute.healthChecks.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">compute.healthChecks.listTagBindings</code></li>
<li><code translate="no" dir="ltr">compute.healthChecks.update</code></li>
<li><code translate="no" dir="ltr">compute.healthChecks.use</code></li>
<li><code translate="no" dir="ltr">compute.healthChecks.useReadOnly</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.hosts.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.hosts.get</code></li>
<li><code translate="no" dir="ltr">compute.hosts.getVersion</code></li>
<li><code translate="no" dir="ltr">compute.hosts.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.httpHealthChecks.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.httpHealthChecks.create</code></li>
<li><code translate="no" dir="ltr">compute.httpHealthChecks.createTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.httpHealthChecks.delete</code></li>
<li><code translate="no" dir="ltr">compute.httpHealthChecks.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.httpHealthChecks.get</code></li>
<li><code translate="no" dir="ltr">compute.httpHealthChecks.list</code></li>
<li><code translate="no" dir="ltr">compute.httpHealthChecks.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">compute.httpHealthChecks.listTagBindings</code></li>
<li><code translate="no" dir="ltr">compute.httpHealthChecks.update</code></li>
<li><code translate="no" dir="ltr">compute.httpHealthChecks.use</code></li>
<li><code translate="no" dir="ltr">compute.httpHealthChecks.useReadOnly</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.httpsHealthChecks.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.httpsHealthChecks.create</code></li>
<li><code translate="no" dir="ltr">compute.httpsHealthChecks.createTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.httpsHealthChecks.delete</code></li>
<li><code translate="no" dir="ltr">compute.httpsHealthChecks.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.httpsHealthChecks.get</code></li>
<li><code translate="no" dir="ltr">compute.httpsHealthChecks.list</code></li>
<li><code translate="no" dir="ltr">compute.httpsHealthChecks.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">compute.httpsHealthChecks.listTagBindings</code></li>
<li><code translate="no" dir="ltr">compute.httpsHealthChecks.update</code></li>
<li><code translate="no" dir="ltr">compute.httpsHealthChecks.use</code></li>
<li><code translate="no" dir="ltr">compute.httpsHealthChecks.useReadOnly</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.images.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.images.create</code></li>
<li><code translate="no" dir="ltr">compute.images.createTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.images.delete</code></li>
<li><code translate="no" dir="ltr">compute.images.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.images.deprecate</code></li>
<li><code translate="no" dir="ltr">compute.images.get</code></li>
<li><code translate="no" dir="ltr">compute.images.getFromFamily</code></li>
<li><code translate="no" dir="ltr">compute.images.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">compute.images.list</code></li>
<li><code translate="no" dir="ltr">compute.images.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">compute.images.listTagBindings</code></li>
<li><code translate="no" dir="ltr">compute.images.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">compute.images.setLabels</code></li>
<li><code translate="no" dir="ltr">compute.images.update</code></li>
<li><code translate="no" dir="ltr">compute.images.useReadOnly</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.instanceGroupManagers.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.instanceGroupManagers.create</code></li>
<li><code translate="no" dir="ltr">compute.instanceGroupManagers.createTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.instanceGroupManagers.delete</code></li>
<li><code translate="no" dir="ltr">compute.instanceGroupManagers.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.instanceGroupManagers.get</code></li>
<li><code translate="no" dir="ltr">compute.instanceGroupManagers.list</code></li>
<li><code translate="no" dir="ltr">compute.instanceGroupManagers.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">compute.instanceGroupManagers.listTagBindings</code></li>
<li><code translate="no" dir="ltr">compute.instanceGroupManagers.update</code></li>
<li><code translate="no" dir="ltr">compute.instanceGroupManagers.use</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.instanceGroups.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.instanceGroups.create</code></li>
<li><code translate="no" dir="ltr">compute.instanceGroups.createTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.instanceGroups.delete</code></li>
<li><code translate="no" dir="ltr">compute.instanceGroups.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.instanceGroups.get</code></li>
<li><code translate="no" dir="ltr">compute.instanceGroups.list</code></li>
<li><code translate="no" dir="ltr">compute.instanceGroups.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">compute.instanceGroups.listTagBindings</code></li>
<li><code translate="no" dir="ltr">compute.instanceGroups.update</code></li>
<li><code translate="no" dir="ltr">compute.instanceGroups.use</code></li>
</ul>
<p><code translate="no" dir="ltr">compute.instanceSettings.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.instanceTemplates.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.instanceTemplates.create</code></li>
<li><code translate="no" dir="ltr">compute.instanceTemplates.delete</code></li>
<li><code translate="no" dir="ltr">compute.instanceTemplates.get</code></li>
<li><code translate="no" dir="ltr">compute.instanceTemplates.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">compute.instanceTemplates.list</code></li>
<li><code translate="no" dir="ltr">compute.instanceTemplates.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">compute.instanceTemplates.useReadOnly</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.instances.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.instances.addAccessConfig</code></li>
<li><code translate="no" dir="ltr">compute.instances.addNetworkInterface</code></li>
<li><code translate="no" dir="ltr">compute.instances.addResourcePolicies</code></li>
<li><code translate="no" dir="ltr">compute.instances.attachDisk</code></li>
<li><code translate="no" dir="ltr">compute.instances.create</code></li>
<li><code translate="no" dir="ltr">compute.instances.createTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.instances.delete</code></li>
<li><code translate="no" dir="ltr">compute.instances.deleteAccessConfig</code></li>
<li><code translate="no" dir="ltr">compute.instances.deleteNetworkInterface</code></li>
<li><code translate="no" dir="ltr">compute.instances.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.instances.detachDisk</code></li>
<li><code translate="no" dir="ltr">compute.instances.get</code></li>
<li><code translate="no" dir="ltr">compute.instances.getEffectiveFirewalls</code></li>
<li><code translate="no" dir="ltr">compute.instances.getGuestAttributes</code></li>
<li><code translate="no" dir="ltr">compute.instances.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">compute.instances.getScreenshot</code></li>
<li><code translate="no" dir="ltr">compute.instances.getSerialPortOutput</code></li>
<li><code translate="no" dir="ltr">compute.instances.getShieldedInstanceIdentity</code></li>
<li><code translate="no" dir="ltr">compute.instances.getShieldedVmIdentity</code></li>
<li><code translate="no" dir="ltr">compute.instances.getVmExtensionState</code></li>
<li><code translate="no" dir="ltr">compute.instances.list</code></li>
<li><code translate="no" dir="ltr">compute.instances.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">compute.instances.listReferrers</code></li>
<li><code translate="no" dir="ltr">compute.instances.listTagBindings</code></li>
<li><code translate="no" dir="ltr">compute.instances.listVmExtensionStates</code></li>
<li><code translate="no" dir="ltr">compute.instances.osAdminLogin</code></li>
<li><code translate="no" dir="ltr">compute.instances.osLogin</code></li>
<li><code translate="no" dir="ltr">compute.instances.performMaintenance</code></li>
<li><code translate="no" dir="ltr">compute.instances.pscInterfaceCreate</code></li>
<li><code translate="no" dir="ltr">compute.instances.removeResourcePolicies</code></li>
<li><code translate="no" dir="ltr">compute.instances.reset</code></li>
<li><code translate="no" dir="ltr">compute.instances.resume</code></li>
<li><code translate="no" dir="ltr">compute.instances.sendDiagnosticInterrupt</code></li>
<li><code translate="no" dir="ltr">compute.instances.setDeletionProtection</code></li>
<li><code translate="no" dir="ltr">compute.instances.setDiskAutoDelete</code></li>
<li><code translate="no" dir="ltr">compute.instances.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">compute.instances.setLabels</code></li>
<li><code translate="no" dir="ltr">compute.instances.setMachineResources</code></li>
<li><code translate="no" dir="ltr">compute.instances.setMachineType</code></li>
<li><code translate="no" dir="ltr">compute.instances.setMetadata</code></li>
<li><code translate="no" dir="ltr">compute.instances.setMinCpuPlatform</code></li>
<li><code translate="no" dir="ltr">compute.instances.setName</code></li>
<li><code translate="no" dir="ltr">compute.instances.setScheduling</code></li>
<li><code translate="no" dir="ltr">compute.instances.setSecurityPolicy</code></li>
<li><code translate="no" dir="ltr">compute.instances.setServiceAccount</code></li>
<li><code translate="no" dir="ltr">compute.instances.setShieldedInstanceIntegrityPolicy</code></li>
<li><code translate="no" dir="ltr">compute.instances.setShieldedVmIntegrityPolicy</code></li>
<li><code translate="no" dir="ltr">compute.instances.setTags</code></li>
<li><code translate="no" dir="ltr">compute.instances.simulateMaintenanceEvent</code></li>
<li><code translate="no" dir="ltr">compute.instances.start</code></li>
<li><code translate="no" dir="ltr">compute.instances.startWithEncryptionKey</code></li>
<li><code translate="no" dir="ltr">compute.instances.stop</code></li>
<li><code translate="no" dir="ltr">compute.instances.suspend</code></li>
<li><code translate="no" dir="ltr">compute.instances.troubleshoot</code></li>
<li><code translate="no" dir="ltr">compute.instances.update</code></li>
<li><code translate="no" dir="ltr">compute.instances.updateAccessConfig</code></li>
<li><code translate="no" dir="ltr">compute.instances.updateDisplayDevice</code></li>
<li><code translate="no" dir="ltr">compute.instances.updateNetworkInterface</code></li>
<li><code translate="no" dir="ltr">compute.instances.updateSecurity</code></li>
<li><code translate="no" dir="ltr">compute.instances.updateShieldedInstanceConfig</code></li>
<li><code translate="no" dir="ltr">compute.instances.updateShieldedVmConfig</code></li>
<li><code translate="no" dir="ltr">compute.instances.use</code></li>
<li><code translate="no" dir="ltr">compute.instances.useReadOnly</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.instantSnapshotGroups.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.instantSnapshotGroups.create</code></li>
<li><code translate="no" dir="ltr">compute.instantSnapshotGroups.delete</code></li>
<li><code translate="no" dir="ltr">compute.instantSnapshotGroups.get</code></li>
<li><code translate="no" dir="ltr">compute.instantSnapshotGroups.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">compute.instantSnapshotGroups.list</code></li>
<li><code translate="no" dir="ltr">compute.instantSnapshotGroups.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">compute.instantSnapshotGroups.useReadOnly</code></li>
</ul>
<p><code translate="no" dir="ltr">compute.instantSnapshots.create</code></p>
<p><code translate="no" dir="ltr">compute.instantSnapshots.delete</code></p>
<p><code translate="no" dir="ltr">compute.instantSnapshots.export</code></p>
<p><code translate="no" dir="ltr">compute.instantSnapshots.get</code></p>
<p><code translate="no" dir="ltr">compute.instantSnapshots.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.instantSnapshots.list</code></p>
<p><code translate="no" dir="ltr">compute.instantSnapshots.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.instantSnapshots.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.instantSnapshots.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.instantSnapshots.setLabels</code></p>
<p><code translate="no" dir="ltr">compute.instantSnapshots.useReadOnly</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.interconnectAttachmentGroups.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.interconnectAttachmentGroups.create</code></li>
<li><code translate="no" dir="ltr">compute.interconnectAttachmentGroups.delete</code></li>
<li><code translate="no" dir="ltr">compute.interconnectAttachmentGroups.get</code></li>
<li><code translate="no" dir="ltr">compute.interconnectAttachmentGroups.list</code></li>
<li><code translate="no" dir="ltr">compute.interconnectAttachmentGroups.patch</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.interconnectAttachments.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.interconnectAttachments.create</code></li>
<li><code translate="no" dir="ltr">compute.interconnectAttachments.createTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.interconnectAttachments.delete</code></li>
<li><code translate="no" dir="ltr">compute.interconnectAttachments.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.interconnectAttachments.get</code></li>
<li><code translate="no" dir="ltr">compute.interconnectAttachments.list</code></li>
<li><code translate="no" dir="ltr">compute.interconnectAttachments.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">compute.interconnectAttachments.listTagBindings</code></li>
<li><code translate="no" dir="ltr">compute.interconnectAttachments.setLabels</code></li>
<li><code translate="no" dir="ltr">compute.interconnectAttachments.update</code></li>
<li><code translate="no" dir="ltr">compute.interconnectAttachments.use</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.interconnectGroups.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.interconnectGroups.create</code></li>
<li><code translate="no" dir="ltr">compute.interconnectGroups.delete</code></li>
<li><code translate="no" dir="ltr">compute.interconnectGroups.get</code></li>
<li><code translate="no" dir="ltr">compute.interconnectGroups.list</code></li>
<li><code translate="no" dir="ltr">compute.interconnectGroups.patch</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.interconnectLocations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.interconnectLocations.get</code></li>
<li><code translate="no" dir="ltr">compute.interconnectLocations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.interconnectRemoteLocations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.interconnectRemoteLocations.get</code></li>
<li><code translate="no" dir="ltr">compute.interconnectRemoteLocations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.interconnects.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.interconnects.create</code></li>
<li><code translate="no" dir="ltr">compute.interconnects.createTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.interconnects.delete</code></li>
<li><code translate="no" dir="ltr">compute.interconnects.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.interconnects.get</code></li>
<li><code translate="no" dir="ltr">compute.interconnects.getMacsecConfig</code></li>
<li><code translate="no" dir="ltr">compute.interconnects.list</code></li>
<li><code translate="no" dir="ltr">compute.interconnects.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">compute.interconnects.listTagBindings</code></li>
<li><code translate="no" dir="ltr">compute.interconnects.setLabels</code></li>
<li><code translate="no" dir="ltr">compute.interconnects.setName</code></li>
<li><code translate="no" dir="ltr">compute.interconnects.update</code></li>
<li><code translate="no" dir="ltr">compute.interconnects.use</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.licenseCodes.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.licenseCodes.get</code></li>
<li><code translate="no" dir="ltr">compute.licenseCodes.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">compute.licenseCodes.list</code></li>
<li><code translate="no" dir="ltr">compute.licenseCodes.setIamPolicy</code></li>
</ul>
<p><code translate="no" dir="ltr">compute.licenses.create</code></p>
<p><code translate="no" dir="ltr">compute.licenses.delete</code></p>
<p><code translate="no" dir="ltr">compute.licenses.get</code></p>
<p><code translate="no" dir="ltr">compute.licenses.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.licenses.list</code></p>
<p><code translate="no" dir="ltr">compute.licenses.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.licenses.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.licenses.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.licenses.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.machineImages.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.machineImages.create</code></li>
<li><code translate="no" dir="ltr">compute.machineImages.createTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.machineImages.delete</code></li>
<li><code translate="no" dir="ltr">compute.machineImages.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.machineImages.get</code></li>
<li><code translate="no" dir="ltr">compute.machineImages.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">compute.machineImages.list</code></li>
<li><code translate="no" dir="ltr">compute.machineImages.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">compute.machineImages.listTagBindings</code></li>
<li><code translate="no" dir="ltr">compute.machineImages.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">compute.machineImages.setLabels</code></li>
<li><code translate="no" dir="ltr">compute.machineImages.useReadOnly</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.machineTypes.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.machineTypes.get</code></li>
<li><code translate="no" dir="ltr">compute.machineTypes.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.managedRulesets.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.managedRulesets.get</code></li>
<li><code translate="no" dir="ltr">compute.managedRulesets.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.multiMig.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.multiMig.create</code></li>
<li><code translate="no" dir="ltr">compute.multiMig.delete</code></li>
<li><code translate="no" dir="ltr">compute.multiMig.get</code></li>
<li><code translate="no" dir="ltr">compute.multiMig.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.multiMigMembers.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.multiMigMembers.get</code></li>
<li><code translate="no" dir="ltr">compute.multiMigMembers.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.networkAttachments.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.networkAttachments.create</code></li>
<li><code translate="no" dir="ltr">compute.networkAttachments.createTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.networkAttachments.delete</code></li>
<li><code translate="no" dir="ltr">compute.networkAttachments.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.networkAttachments.get</code></li>
<li><code translate="no" dir="ltr">compute.networkAttachments.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">compute.networkAttachments.list</code></li>
<li><code translate="no" dir="ltr">compute.networkAttachments.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">compute.networkAttachments.listTagBindings</code></li>
<li><code translate="no" dir="ltr">compute.networkAttachments.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">compute.networkAttachments.update</code></li>
<li><code translate="no" dir="ltr">compute.networkAttachments.use</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.networkEndpointGroups.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.networkEndpointGroups.attachNetworkEndpoints</code></li>
<li><code translate="no" dir="ltr">compute.networkEndpointGroups.create</code></li>
<li><code translate="no" dir="ltr">compute.networkEndpointGroups.createTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.networkEndpointGroups.delete</code></li>
<li><code translate="no" dir="ltr">compute.networkEndpointGroups.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.networkEndpointGroups.detachNetworkEndpoints</code></li>
<li><code translate="no" dir="ltr">compute.networkEndpointGroups.get</code></li>
<li><code translate="no" dir="ltr">compute.networkEndpointGroups.list</code></li>
<li><code translate="no" dir="ltr">compute.networkEndpointGroups.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">compute.networkEndpointGroups.listTagBindings</code></li>
<li><code translate="no" dir="ltr">compute.networkEndpointGroups.use</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.networkProfiles.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.networkProfiles.get</code></li>
<li><code translate="no" dir="ltr">compute.networkProfiles.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.networks.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.networks.access</code></li>
<li><code translate="no" dir="ltr">compute.networks.addPeering</code></li>
<li><code translate="no" dir="ltr">compute.networks.create</code></li>
<li><code translate="no" dir="ltr">compute.networks.createTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.networks.delete</code></li>
<li><code translate="no" dir="ltr">compute.networks.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.networks.get</code></li>
<li><code translate="no" dir="ltr">compute.networks.getEffectiveFirewalls</code></li>
<li><code translate="no" dir="ltr">compute.networks.getRegionEffectiveFirewalls</code></li>
<li><code translate="no" dir="ltr">compute.networks.list</code></li>
<li><code translate="no" dir="ltr">compute.networks.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">compute.networks.listPeeringRoutes</code></li>
<li><code translate="no" dir="ltr">compute.networks.listTagBindings</code></li>
<li><code translate="no" dir="ltr">compute.networks.mirror</code></li>
<li><code translate="no" dir="ltr">compute.networks.removePeering</code></li>
<li><code translate="no" dir="ltr">compute.networks.setFirewallPolicy</code></li>
<li><code translate="no" dir="ltr">compute.networks.setNetworkPolicy</code></li>
<li><code translate="no" dir="ltr">compute.networks.switchToCustomMode</code></li>
<li><code translate="no" dir="ltr">compute.networks.update</code></li>
<li><code translate="no" dir="ltr">compute.networks.updatePeering</code></li>
<li><code translate="no" dir="ltr">compute.networks.updatePolicy</code></li>
<li><code translate="no" dir="ltr">compute.networks.use</code></li>
<li><code translate="no" dir="ltr">compute.networks.useExternalIp</code></li>
</ul>
<p><code translate="no" dir="ltr">compute.packetMirrorings.get</code></p>
<p><code translate="no" dir="ltr">compute.packetMirrorings.list</code></p>
<p><code translate="no" dir="ltr">compute.packetMirrorings.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.packetMirrorings.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.projects.get</code></p>
<p><code translate="no" dir="ltr">compute.publicDelegatedPrefixes.delete</code></p>
<p><code translate="no" dir="ltr">compute.publicDelegatedPrefixes.get</code></p>
<p><code translate="no" dir="ltr">compute.publicDelegatedPrefixes.list</code></p>
<p><code translate="no" dir="ltr">compute.publicDelegatedPrefixes.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.publicDelegatedPrefixes.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.publicDelegatedPrefixes.update</code></p>
<p><code translate="no" dir="ltr">compute.publicDelegatedPrefixes.updatePolicy</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.recoverableSnapshots.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.recoverableSnapshots.delete</code></li>
<li><code translate="no" dir="ltr">compute.recoverableSnapshots.get</code></li>
<li><code translate="no" dir="ltr">compute.recoverableSnapshots.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">compute.recoverableSnapshots.list</code></li>
<li><code translate="no" dir="ltr">compute.recoverableSnapshots.recover</code></li>
<li><code translate="no" dir="ltr">compute.recoverableSnapshots.setIamPolicy</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.regionBackendBuckets.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.regionBackendBuckets.create</code></li>
<li><code translate="no" dir="ltr">compute.regionBackendBuckets.createTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.regionBackendBuckets.delete</code></li>
<li><code translate="no" dir="ltr">compute.regionBackendBuckets.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.regionBackendBuckets.get</code></li>
<li><code translate="no" dir="ltr">compute.regionBackendBuckets.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">compute.regionBackendBuckets.list</code></li>
<li><code translate="no" dir="ltr">compute.regionBackendBuckets.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">compute.regionBackendBuckets.listTagBindings</code></li>
<li><code translate="no" dir="ltr">compute.regionBackendBuckets.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">compute.regionBackendBuckets.update</code></li>
<li><code translate="no" dir="ltr">compute.regionBackendBuckets.use</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.regionBackendServices.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.regionBackendServices.create</code></li>
<li><code translate="no" dir="ltr">compute.regionBackendServices.createTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.regionBackendServices.delete</code></li>
<li><code translate="no" dir="ltr">compute.regionBackendServices.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.regionBackendServices.get</code></li>
<li><code translate="no" dir="ltr">compute.regionBackendServices.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">compute.regionBackendServices.list</code></li>
<li><code translate="no" dir="ltr">compute.regionBackendServices.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">compute.regionBackendServices.listTagBindings</code></li>
<li><code translate="no" dir="ltr">compute.regionBackendServices.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">compute.regionBackendServices.setSecurityPolicy</code></li>
<li><code translate="no" dir="ltr">compute.regionBackendServices.update</code></li>
<li><code translate="no" dir="ltr">compute.regionBackendServices.use</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.regionCompositeHealthChecks.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.regionCompositeHealthChecks.create</code></li>
<li><code translate="no" dir="ltr">compute.regionCompositeHealthChecks.delete</code></li>
<li><code translate="no" dir="ltr">compute.regionCompositeHealthChecks.get</code></li>
<li><code translate="no" dir="ltr">compute.regionCompositeHealthChecks.list</code></li>
<li><code translate="no" dir="ltr">compute.regionCompositeHealthChecks.update</code></li>
</ul>
<p><code translate="no" dir="ltr">compute.regionFirewallPolicies.get</code></p>
<p><code translate="no" dir="ltr">compute.regionFirewallPolicies.list</code></p>
<p><code translate="no" dir="ltr">compute.regionFirewallPolicies.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.regionFirewallPolicies.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.regionFirewallPolicies.use</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.regionHealthAggregationPolicies.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.regionHealthAggregationPolicies.create</code></li>
<li><code translate="no" dir="ltr">compute.regionHealthAggregationPolicies.delete</code></li>
<li><code translate="no" dir="ltr">compute.regionHealthAggregationPolicies.get</code></li>
<li><code translate="no" dir="ltr">compute.regionHealthAggregationPolicies.list</code></li>
<li><code translate="no" dir="ltr">compute.regionHealthAggregationPolicies.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.regionHealthCheckServices.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.regionHealthCheckServices.create</code></li>
<li><code translate="no" dir="ltr">compute.regionHealthCheckServices.delete</code></li>
<li><code translate="no" dir="ltr">compute.regionHealthCheckServices.get</code></li>
<li><code translate="no" dir="ltr">compute.regionHealthCheckServices.list</code></li>
<li><code translate="no" dir="ltr">compute.regionHealthCheckServices.update</code></li>
<li><code translate="no" dir="ltr">compute.regionHealthCheckServices.use</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.regionHealthChecks.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.regionHealthChecks.create</code></li>
<li><code translate="no" dir="ltr">compute.regionHealthChecks.createTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.regionHealthChecks.delete</code></li>
<li><code translate="no" dir="ltr">compute.regionHealthChecks.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.regionHealthChecks.get</code></li>
<li><code translate="no" dir="ltr">compute.regionHealthChecks.list</code></li>
<li><code translate="no" dir="ltr">compute.regionHealthChecks.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">compute.regionHealthChecks.listTagBindings</code></li>
<li><code translate="no" dir="ltr">compute.regionHealthChecks.update</code></li>
<li><code translate="no" dir="ltr">compute.regionHealthChecks.use</code></li>
<li><code translate="no" dir="ltr">compute.regionHealthChecks.useReadOnly</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.regionHealthSources.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.regionHealthSources.create</code></li>
<li><code translate="no" dir="ltr">compute.regionHealthSources.delete</code></li>
<li><code translate="no" dir="ltr">compute.regionHealthSources.get</code></li>
<li><code translate="no" dir="ltr">compute.regionHealthSources.list</code></li>
<li><code translate="no" dir="ltr">compute.regionHealthSources.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.regionNetworkEndpointGroups.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.regionNetworkEndpointGroups.attachNetworkEndpoints</code></li>
<li><code translate="no" dir="ltr">compute.regionNetworkEndpointGroups.create</code></li>
<li><code translate="no" dir="ltr">compute.regionNetworkEndpointGroups.createTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.regionNetworkEndpointGroups.delete</code></li>
<li><code translate="no" dir="ltr">compute.regionNetworkEndpointGroups.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.regionNetworkEndpointGroups.detachNetworkEndpoints</code></li>
<li><code translate="no" dir="ltr">compute.regionNetworkEndpointGroups.get</code></li>
<li><code translate="no" dir="ltr">compute.regionNetworkEndpointGroups.list</code></li>
<li><code translate="no" dir="ltr">compute.regionNetworkEndpointGroups.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">compute.regionNetworkEndpointGroups.listTagBindings</code></li>
<li><code translate="no" dir="ltr">compute.regionNetworkEndpointGroups.use</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.regionNetworkPolicies.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.regionNetworkPolicies.create</code></li>
<li><code translate="no" dir="ltr">compute.regionNetworkPolicies.delete</code></li>
<li><code translate="no" dir="ltr">compute.regionNetworkPolicies.get</code></li>
<li><code translate="no" dir="ltr">compute.regionNetworkPolicies.list</code></li>
<li><code translate="no" dir="ltr">compute.regionNetworkPolicies.update</code></li>
<li><code translate="no" dir="ltr">compute.regionNetworkPolicies.use</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.regionNotificationEndpoints.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.regionNotificationEndpoints.create</code></li>
<li><code translate="no" dir="ltr">compute.regionNotificationEndpoints.delete</code></li>
<li><code translate="no" dir="ltr">compute.regionNotificationEndpoints.get</code></li>
<li><code translate="no" dir="ltr">compute.regionNotificationEndpoints.list</code></li>
<li><code translate="no" dir="ltr">compute.regionNotificationEndpoints.update</code></li>
<li><code translate="no" dir="ltr">compute.regionNotificationEndpoints.use</code></li>
</ul>
<p><code translate="no" dir="ltr">compute.regionOperations.get</code></p>
<p><code translate="no" dir="ltr">compute.regionOperations.list</code></p>
<p><code translate="no" dir="ltr">compute.regionSecurityPolicies.get</code></p>
<p><code translate="no" dir="ltr">compute.regionSecurityPolicies.list</code></p>
<p><code translate="no" dir="ltr">compute.regionSecurityPolicies.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.regionSecurityPolicies.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.regionSecurityPolicies.use</code></p>
<p><code translate="no" dir="ltr">compute.regionSslCertificates.get</code></p>
<p><code translate="no" dir="ltr">compute.regionSslCertificates.list</code></p>
<p><code translate="no" dir="ltr">compute.regionSslCertificates.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.regionSslCertificates.listTagBindings</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.regionSslPolicies.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.regionSslPolicies.create</code></li>
<li><code translate="no" dir="ltr">compute.regionSslPolicies.createTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.regionSslPolicies.delete</code></li>
<li><code translate="no" dir="ltr">compute.regionSslPolicies.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.regionSslPolicies.get</code></li>
<li><code translate="no" dir="ltr">compute.regionSslPolicies.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">compute.regionSslPolicies.list</code></li>
<li><code translate="no" dir="ltr">compute.regionSslPolicies.listAvailableFeatures</code></li>
<li><code translate="no" dir="ltr">compute.regionSslPolicies.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">compute.regionSslPolicies.listTagBindings</code></li>
<li><code translate="no" dir="ltr">compute.regionSslPolicies.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">compute.regionSslPolicies.update</code></li>
<li><code translate="no" dir="ltr">compute.regionSslPolicies.use</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.regionTargetHttpProxies.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.regionTargetHttpProxies.create</code></li>
<li><code translate="no" dir="ltr">compute.regionTargetHttpProxies.createTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.regionTargetHttpProxies.delete</code></li>
<li><code translate="no" dir="ltr">compute.regionTargetHttpProxies.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.regionTargetHttpProxies.get</code></li>
<li><code translate="no" dir="ltr">compute.regionTargetHttpProxies.list</code></li>
<li><code translate="no" dir="ltr">compute.regionTargetHttpProxies.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">compute.regionTargetHttpProxies.listTagBindings</code></li>
<li><code translate="no" dir="ltr">compute.regionTargetHttpProxies.setUrlMap</code></li>
<li><code translate="no" dir="ltr">compute.regionTargetHttpProxies.use</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.regionTargetHttpsProxies.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.regionTargetHttpsProxies.create</code></li>
<li><code translate="no" dir="ltr">compute.regionTargetHttpsProxies.createTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.regionTargetHttpsProxies.delete</code></li>
<li><code translate="no" dir="ltr">compute.regionTargetHttpsProxies.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.regionTargetHttpsProxies.get</code></li>
<li><code translate="no" dir="ltr">compute.regionTargetHttpsProxies.list</code></li>
<li><code translate="no" dir="ltr">compute.regionTargetHttpsProxies.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">compute.regionTargetHttpsProxies.listTagBindings</code></li>
<li><code translate="no" dir="ltr">compute.regionTargetHttpsProxies.setSslCertificates</code></li>
<li><code translate="no" dir="ltr">compute.regionTargetHttpsProxies.setUrlMap</code></li>
<li><code translate="no" dir="ltr">compute.regionTargetHttpsProxies.update</code></li>
<li><code translate="no" dir="ltr">compute.regionTargetHttpsProxies.use</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.regionTargetTcpProxies.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.regionTargetTcpProxies.attach</code></li>
<li><code translate="no" dir="ltr">compute.regionTargetTcpProxies.create</code></li>
<li><code translate="no" dir="ltr">compute.regionTargetTcpProxies.createTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.regionTargetTcpProxies.delete</code></li>
<li><code translate="no" dir="ltr">compute.regionTargetTcpProxies.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.regionTargetTcpProxies.get</code></li>
<li><code translate="no" dir="ltr">compute.regionTargetTcpProxies.list</code></li>
<li><code translate="no" dir="ltr">compute.regionTargetTcpProxies.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">compute.regionTargetTcpProxies.listTagBindings</code></li>
<li><code translate="no" dir="ltr">compute.regionTargetTcpProxies.use</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.regionUrlMaps.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.regionUrlMaps.create</code></li>
<li><code translate="no" dir="ltr">compute.regionUrlMaps.createTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.regionUrlMaps.delete</code></li>
<li><code translate="no" dir="ltr">compute.regionUrlMaps.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.regionUrlMaps.get</code></li>
<li><code translate="no" dir="ltr">compute.regionUrlMaps.invalidateCache</code></li>
<li><code translate="no" dir="ltr">compute.regionUrlMaps.list</code></li>
<li><code translate="no" dir="ltr">compute.regionUrlMaps.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">compute.regionUrlMaps.listTagBindings</code></li>
<li><code translate="no" dir="ltr">compute.regionUrlMaps.update</code></li>
<li><code translate="no" dir="ltr">compute.regionUrlMaps.use</code></li>
<li><code translate="no" dir="ltr">compute.regionUrlMaps.validate</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.regions.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.regions.get</code></li>
<li><code translate="no" dir="ltr">compute.regions.list</code></li>
</ul>
<p><code translate="no" dir="ltr">compute.reservationBlocks.get</code></p>
<p><code translate="no" dir="ltr">compute.reservationBlocks.list</code></p>
<p><code translate="no" dir="ltr">compute.reservationConsumedInstances.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.reservationSlots.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.reservationSlots.get</code></li>
<li><code translate="no" dir="ltr">compute.reservationSlots.list</code></li>
<li><code translate="no" dir="ltr">compute.reservationSlots.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.reservationSubBlocks.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.reservationSubBlocks.get</code></li>
<li><code translate="no" dir="ltr">compute.reservationSubBlocks.list</code></li>
<li><code translate="no" dir="ltr">compute.reservationSubBlocks.performMaintenance</code></li>
<li><code translate="no" dir="ltr">compute.reservationSubBlocks.reportFaulty</code></li>
</ul>
<p><code translate="no" dir="ltr">compute.reservations.get</code></p>
<p><code translate="no" dir="ltr">compute.reservations.list</code></p>
<p><code translate="no" dir="ltr">compute.reservations.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.reservations.listTagBindings</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.resourcePolicies.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.resourcePolicies.create</code></li>
<li><code translate="no" dir="ltr">compute.resourcePolicies.delete</code></li>
<li><code translate="no" dir="ltr">compute.resourcePolicies.get</code></li>
<li><code translate="no" dir="ltr">compute.resourcePolicies.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">compute.resourcePolicies.list</code></li>
<li><code translate="no" dir="ltr">compute.resourcePolicies.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">compute.resourcePolicies.update</code></li>
<li><code translate="no" dir="ltr">compute.resourcePolicies.use</code></li>
<li><code translate="no" dir="ltr">compute.resourcePolicies.useReadOnly</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.routers.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.routers.create</code></li>
<li><code translate="no" dir="ltr">compute.routers.createTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.routers.delete</code></li>
<li><code translate="no" dir="ltr">compute.routers.deleteRoutePolicy</code></li>
<li><code translate="no" dir="ltr">compute.routers.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.routers.get</code></li>
<li><code translate="no" dir="ltr">compute.routers.getRoutePolicy</code></li>
<li><code translate="no" dir="ltr">compute.routers.list</code></li>
<li><code translate="no" dir="ltr">compute.routers.listBgpRoutes</code></li>
<li><code translate="no" dir="ltr">compute.routers.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">compute.routers.listRoutePolicies</code></li>
<li><code translate="no" dir="ltr">compute.routers.listTagBindings</code></li>
<li><code translate="no" dir="ltr">compute.routers.update</code></li>
<li><code translate="no" dir="ltr">compute.routers.updateRoutePolicy</code></li>
<li><code translate="no" dir="ltr">compute.routers.use</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.routes.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.routes.create</code></li>
<li><code translate="no" dir="ltr">compute.routes.createTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.routes.delete</code></li>
<li><code translate="no" dir="ltr">compute.routes.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.routes.get</code></li>
<li><code translate="no" dir="ltr">compute.routes.list</code></li>
<li><code translate="no" dir="ltr">compute.routes.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">compute.routes.listTagBindings</code></li>
</ul>
<p><code translate="no" dir="ltr">compute.securityPolicies.get</code></p>
<p><code translate="no" dir="ltr">compute.securityPolicies.list</code></p>
<p><code translate="no" dir="ltr">compute.securityPolicies.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.securityPolicies.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.securityPolicies.use</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.serviceAttachments.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.serviceAttachments.create</code></li>
<li><code translate="no" dir="ltr">compute.serviceAttachments.createTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.serviceAttachments.delete</code></li>
<li><code translate="no" dir="ltr">compute.serviceAttachments.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.serviceAttachments.get</code></li>
<li><code translate="no" dir="ltr">compute.serviceAttachments.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">compute.serviceAttachments.list</code></li>
<li><code translate="no" dir="ltr">compute.serviceAttachments.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">compute.serviceAttachments.listTagBindings</code></li>
<li><code translate="no" dir="ltr">compute.serviceAttachments.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">compute.serviceAttachments.update</code></li>
<li><code translate="no" dir="ltr">compute.serviceAttachments.use</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.snapshotGroups.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.snapshotGroups.create</code></li>
<li><code translate="no" dir="ltr">compute.snapshotGroups.delete</code></li>
<li><code translate="no" dir="ltr">compute.snapshotGroups.get</code></li>
<li><code translate="no" dir="ltr">compute.snapshotGroups.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">compute.snapshotGroups.list</code></li>
<li><code translate="no" dir="ltr">compute.snapshotGroups.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">compute.snapshotGroups.useReadOnly</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.snapshots.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.snapshots.create</code></li>
<li><code translate="no" dir="ltr">compute.snapshots.createTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.snapshots.delete</code></li>
<li><code translate="no" dir="ltr">compute.snapshots.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.snapshots.get</code></li>
<li><code translate="no" dir="ltr">compute.snapshots.getEffectiveRecycleBinRule</code></li>
<li><code translate="no" dir="ltr">compute.snapshots.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">compute.snapshots.list</code></li>
<li><code translate="no" dir="ltr">compute.snapshots.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">compute.snapshots.listTagBindings</code></li>
<li><code translate="no" dir="ltr">compute.snapshots.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">compute.snapshots.setLabels</code></li>
<li><code translate="no" dir="ltr">compute.snapshots.updateKmsKey</code></li>
<li><code translate="no" dir="ltr">compute.snapshots.useReadOnly</code></li>
</ul>
<p><code translate="no" dir="ltr">compute.sslCertificates.get</code></p>
<p><code translate="no" dir="ltr">compute.sslCertificates.list</code></p>
<p><code translate="no" dir="ltr">compute.sslCertificates.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.sslCertificates.listTagBindings</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.sslPolicies.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.sslPolicies.create</code></li>
<li><code translate="no" dir="ltr">compute.sslPolicies.createTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.sslPolicies.delete</code></li>
<li><code translate="no" dir="ltr">compute.sslPolicies.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.sslPolicies.get</code></li>
<li><code translate="no" dir="ltr">compute.sslPolicies.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">compute.sslPolicies.list</code></li>
<li><code translate="no" dir="ltr">compute.sslPolicies.listAvailableFeatures</code></li>
<li><code translate="no" dir="ltr">compute.sslPolicies.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">compute.sslPolicies.listTagBindings</code></li>
<li><code translate="no" dir="ltr">compute.sslPolicies.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">compute.sslPolicies.update</code></li>
<li><code translate="no" dir="ltr">compute.sslPolicies.use</code></li>
</ul>
<p><code translate="no" dir="ltr">compute.storagePools.create</code></p>
<p><code translate="no" dir="ltr">compute.storagePools.delete</code></p>
<p><code translate="no" dir="ltr">compute.storagePools.get</code></p>
<p><code translate="no" dir="ltr">compute.storagePools.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.storagePools.list</code></p>
<p><code translate="no" dir="ltr">compute.storagePools.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">compute.storagePools.listTagBindings</code></p>
<p><code translate="no" dir="ltr">compute.storagePools.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.storagePools.update</code></p>
<p><code translate="no" dir="ltr">compute.storagePools.use</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.subnetworks.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.subnetworks.create</code></li>
<li><code translate="no" dir="ltr">compute.subnetworks.createTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.subnetworks.delete</code></li>
<li><code translate="no" dir="ltr">compute.subnetworks.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.subnetworks.expandIpCidrRange</code></li>
<li><code translate="no" dir="ltr">compute.subnetworks.get</code></li>
<li><code translate="no" dir="ltr">compute.subnetworks.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">compute.subnetworks.list</code></li>
<li><code translate="no" dir="ltr">compute.subnetworks.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">compute.subnetworks.listTagBindings</code></li>
<li><code translate="no" dir="ltr">compute.subnetworks.mirror</code></li>
<li><code translate="no" dir="ltr">compute.subnetworks.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">compute.subnetworks.setPrivateIpGoogleAccess</code></li>
<li><code translate="no" dir="ltr">compute.subnetworks.update</code></li>
<li><code translate="no" dir="ltr">compute.subnetworks.use</code></li>
<li><code translate="no" dir="ltr">compute.subnetworks.useExternalIp</code></li>
<li><code translate="no" dir="ltr">compute.subnetworks.usePeerMigration</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.targetGrpcProxies.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.targetGrpcProxies.create</code></li>
<li><code translate="no" dir="ltr">compute.targetGrpcProxies.createTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.targetGrpcProxies.delete</code></li>
<li><code translate="no" dir="ltr">compute.targetGrpcProxies.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.targetGrpcProxies.get</code></li>
<li><code translate="no" dir="ltr">compute.targetGrpcProxies.list</code></li>
<li><code translate="no" dir="ltr">compute.targetGrpcProxies.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">compute.targetGrpcProxies.listTagBindings</code></li>
<li><code translate="no" dir="ltr">compute.targetGrpcProxies.update</code></li>
<li><code translate="no" dir="ltr">compute.targetGrpcProxies.use</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.targetHttpProxies.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.targetHttpProxies.create</code></li>
<li><code translate="no" dir="ltr">compute.targetHttpProxies.createTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.targetHttpProxies.delete</code></li>
<li><code translate="no" dir="ltr">compute.targetHttpProxies.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.targetHttpProxies.get</code></li>
<li><code translate="no" dir="ltr">compute.targetHttpProxies.list</code></li>
<li><code translate="no" dir="ltr">compute.targetHttpProxies.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">compute.targetHttpProxies.listTagBindings</code></li>
<li><code translate="no" dir="ltr">compute.targetHttpProxies.setUrlMap</code></li>
<li><code translate="no" dir="ltr">compute.targetHttpProxies.update</code></li>
<li><code translate="no" dir="ltr">compute.targetHttpProxies.use</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.targetHttpsProxies.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.targetHttpsProxies.create</code></li>
<li><code translate="no" dir="ltr">compute.targetHttpsProxies.createTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.targetHttpsProxies.delete</code></li>
<li><code translate="no" dir="ltr">compute.targetHttpsProxies.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.targetHttpsProxies.get</code></li>
<li><code translate="no" dir="ltr">compute.targetHttpsProxies.list</code></li>
<li><code translate="no" dir="ltr">compute.targetHttpsProxies.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">compute.targetHttpsProxies.listTagBindings</code></li>
<li><code translate="no" dir="ltr">compute.targetHttpsProxies.setCertificateMap</code></li>
<li><code translate="no" dir="ltr">compute.targetHttpsProxies.setQuicOverride</code></li>
<li><code translate="no" dir="ltr">compute.targetHttpsProxies.setSslCertificates</code></li>
<li><code translate="no" dir="ltr">compute.targetHttpsProxies.setSslPolicy</code></li>
<li><code translate="no" dir="ltr">compute.targetHttpsProxies.setUrlMap</code></li>
<li><code translate="no" dir="ltr">compute.targetHttpsProxies.update</code></li>
<li><code translate="no" dir="ltr">compute.targetHttpsProxies.use</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.targetInstances.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.targetInstances.create</code></li>
<li><code translate="no" dir="ltr">compute.targetInstances.createTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.targetInstances.delete</code></li>
<li><code translate="no" dir="ltr">compute.targetInstances.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.targetInstances.get</code></li>
<li><code translate="no" dir="ltr">compute.targetInstances.list</code></li>
<li><code translate="no" dir="ltr">compute.targetInstances.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">compute.targetInstances.listTagBindings</code></li>
<li><code translate="no" dir="ltr">compute.targetInstances.setSecurityPolicy</code></li>
<li><code translate="no" dir="ltr">compute.targetInstances.use</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.targetPools.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.targetPools.addHealthCheck</code></li>
<li><code translate="no" dir="ltr">compute.targetPools.addInstance</code></li>
<li><code translate="no" dir="ltr">compute.targetPools.create</code></li>
<li><code translate="no" dir="ltr">compute.targetPools.createTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.targetPools.delete</code></li>
<li><code translate="no" dir="ltr">compute.targetPools.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.targetPools.get</code></li>
<li><code translate="no" dir="ltr">compute.targetPools.list</code></li>
<li><code translate="no" dir="ltr">compute.targetPools.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">compute.targetPools.listTagBindings</code></li>
<li><code translate="no" dir="ltr">compute.targetPools.removeHealthCheck</code></li>
<li><code translate="no" dir="ltr">compute.targetPools.removeInstance</code></li>
<li><code translate="no" dir="ltr">compute.targetPools.setSecurityPolicy</code></li>
<li><code translate="no" dir="ltr">compute.targetPools.update</code></li>
<li><code translate="no" dir="ltr">compute.targetPools.use</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.targetSslProxies.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.targetSslProxies.create</code></li>
<li><code translate="no" dir="ltr">compute.targetSslProxies.createTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.targetSslProxies.delete</code></li>
<li><code translate="no" dir="ltr">compute.targetSslProxies.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.targetSslProxies.get</code></li>
<li><code translate="no" dir="ltr">compute.targetSslProxies.list</code></li>
<li><code translate="no" dir="ltr">compute.targetSslProxies.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">compute.targetSslProxies.listTagBindings</code></li>
<li><code translate="no" dir="ltr">compute.targetSslProxies.setBackendService</code></li>
<li><code translate="no" dir="ltr">compute.targetSslProxies.setCertificateMap</code></li>
<li><code translate="no" dir="ltr">compute.targetSslProxies.setProxyHeader</code></li>
<li><code translate="no" dir="ltr">compute.targetSslProxies.setSslCertificates</code></li>
<li><code translate="no" dir="ltr">compute.targetSslProxies.setSslPolicy</code></li>
<li><code translate="no" dir="ltr">compute.targetSslProxies.update</code></li>
<li><code translate="no" dir="ltr">compute.targetSslProxies.use</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.targetTcpProxies.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.targetTcpProxies.attach</code></li>
<li><code translate="no" dir="ltr">compute.targetTcpProxies.create</code></li>
<li><code translate="no" dir="ltr">compute.targetTcpProxies.createTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.targetTcpProxies.delete</code></li>
<li><code translate="no" dir="ltr">compute.targetTcpProxies.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.targetTcpProxies.get</code></li>
<li><code translate="no" dir="ltr">compute.targetTcpProxies.list</code></li>
<li><code translate="no" dir="ltr">compute.targetTcpProxies.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">compute.targetTcpProxies.listTagBindings</code></li>
<li><code translate="no" dir="ltr">compute.targetTcpProxies.update</code></li>
<li><code translate="no" dir="ltr">compute.targetTcpProxies.use</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.targetVpnGateways.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.targetVpnGateways.create</code></li>
<li><code translate="no" dir="ltr">compute.targetVpnGateways.createTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.targetVpnGateways.delete</code></li>
<li><code translate="no" dir="ltr">compute.targetVpnGateways.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.targetVpnGateways.get</code></li>
<li><code translate="no" dir="ltr">compute.targetVpnGateways.list</code></li>
<li><code translate="no" dir="ltr">compute.targetVpnGateways.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">compute.targetVpnGateways.listTagBindings</code></li>
<li><code translate="no" dir="ltr">compute.targetVpnGateways.setLabels</code></li>
<li><code translate="no" dir="ltr">compute.targetVpnGateways.use</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.urlMaps.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.urlMaps.create</code></li>
<li><code translate="no" dir="ltr">compute.urlMaps.createTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.urlMaps.delete</code></li>
<li><code translate="no" dir="ltr">compute.urlMaps.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.urlMaps.get</code></li>
<li><code translate="no" dir="ltr">compute.urlMaps.invalidateCache</code></li>
<li><code translate="no" dir="ltr">compute.urlMaps.list</code></li>
<li><code translate="no" dir="ltr">compute.urlMaps.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">compute.urlMaps.listTagBindings</code></li>
<li><code translate="no" dir="ltr">compute.urlMaps.update</code></li>
<li><code translate="no" dir="ltr">compute.urlMaps.use</code></li>
<li><code translate="no" dir="ltr">compute.urlMaps.validate</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.vpnGateways.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.vpnGateways.create</code></li>
<li><code translate="no" dir="ltr">compute.vpnGateways.createTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.vpnGateways.delete</code></li>
<li><code translate="no" dir="ltr">compute.vpnGateways.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.vpnGateways.get</code></li>
<li><code translate="no" dir="ltr">compute.vpnGateways.list</code></li>
<li><code translate="no" dir="ltr">compute.vpnGateways.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">compute.vpnGateways.listTagBindings</code></li>
<li><code translate="no" dir="ltr">compute.vpnGateways.setLabels</code></li>
<li><code translate="no" dir="ltr">compute.vpnGateways.use</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.vpnTunnels.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.vpnTunnels.create</code></li>
<li><code translate="no" dir="ltr">compute.vpnTunnels.createTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.vpnTunnels.delete</code></li>
<li><code translate="no" dir="ltr">compute.vpnTunnels.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">compute.vpnTunnels.get</code></li>
<li><code translate="no" dir="ltr">compute.vpnTunnels.list</code></li>
<li><code translate="no" dir="ltr">compute.vpnTunnels.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">compute.vpnTunnels.listTagBindings</code></li>
<li><code translate="no" dir="ltr">compute.vpnTunnels.setLabels</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.wireGroups.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.wireGroups.create</code></li>
<li><code translate="no" dir="ltr">compute.wireGroups.delete</code></li>
<li><code translate="no" dir="ltr">compute.wireGroups.get</code></li>
<li><code translate="no" dir="ltr">compute.wireGroups.list</code></li>
<li><code translate="no" dir="ltr">compute.wireGroups.update</code></li>
</ul>
<p><code translate="no" dir="ltr">compute.zoneOperations.get</code></p>
<p><code translate="no" dir="ltr">compute.zoneOperations.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">compute.zones.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">compute.zones.get</code></li>
<li><code translate="no" dir="ltr">compute.zones.list</code></li>
</ul>
<p><code translate="no" dir="ltr">dataflow.jobs.cancel</code></p>
<p><code translate="no" dir="ltr">dataflow.jobs.create</code></p>
<p><code translate="no" dir="ltr">dataflow.jobs.get</code></p>
<p><code translate="no" dir="ltr">dataflow.jobs.list</code></p>
<p><code translate="no" dir="ltr">dataflow.jobs.snapshot</code></p>
<p><code translate="no" dir="ltr">dataflow.jobs.updateContents</code></p>
<p><code translate="no" dir="ltr">dataflow.messages.list</code></p>
<p><code translate="no" dir="ltr">dataflow.metrics.get</code></p>
<p><code translate="no" dir="ltr">dataflow.snapshots.delete</code></p>
<p><code translate="no" dir="ltr">dataflow.snapshots.get</code></p>
<p><code translate="no" dir="ltr">dataflow.snapshots.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">dataform.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">dataform.commentThreads.create</code></li>
<li><code translate="no" dir="ltr">dataform.commentThreads.delete</code></li>
<li><code translate="no" dir="ltr">dataform.commentThreads.get</code></li>
<li><code translate="no" dir="ltr">dataform.commentThreads.list</code></li>
<li><code translate="no" dir="ltr">dataform.commentThreads.update</code></li>
<li><code translate="no" dir="ltr">dataform.comments.create</code></li>
<li><code translate="no" dir="ltr">dataform.comments.delete</code></li>
<li><code translate="no" dir="ltr">dataform.comments.get</code></li>
<li><code translate="no" dir="ltr">dataform.comments.list</code></li>
<li><code translate="no" dir="ltr">dataform.comments.update</code></li>
<li><code translate="no" dir="ltr">dataform.compilationResults.create</code></li>
<li><code translate="no" dir="ltr">dataform.compilationResults.get</code></li>
<li><code translate="no" dir="ltr">dataform.compilationResults.list</code></li>
<li><code translate="no" dir="ltr">dataform.compilationResults.query</code></li>
<li><code translate="no" dir="ltr">dataform.config.get</code></li>
<li><code translate="no" dir="ltr">dataform.config.update</code></li>
<li><code translate="no" dir="ltr">dataform.folders.addContents</code></li>
<li><code translate="no" dir="ltr">dataform.folders.create</code></li>
<li><code translate="no" dir="ltr">dataform.folders.delete</code></li>
<li><code translate="no" dir="ltr">dataform.folders.deleteTree</code></li>
<li><code translate="no" dir="ltr">dataform.folders.get</code></li>
<li><code translate="no" dir="ltr">dataform.folders.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">dataform.folders.move</code></li>
<li><code translate="no" dir="ltr">dataform.folders.queryContents</code></li>
<li><code translate="no" dir="ltr">dataform.folders.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">dataform.folders.update</code></li>
<li><code translate="no" dir="ltr">dataform.locations.get</code></li>
<li><code translate="no" dir="ltr">dataform.locations.list</code></li>
<li><code translate="no" dir="ltr">dataform.operations.cancel</code></li>
<li><code translate="no" dir="ltr">dataform.operations.delete</code></li>
<li><code translate="no" dir="ltr">dataform.operations.get</code></li>
<li><code translate="no" dir="ltr">dataform.operations.list</code></li>
<li><code translate="no" dir="ltr">dataform.releaseConfigs.create</code></li>
<li><code translate="no" dir="ltr">dataform.releaseConfigs.delete</code></li>
<li><code translate="no" dir="ltr">dataform.releaseConfigs.get</code></li>
<li><code translate="no" dir="ltr">dataform.releaseConfigs.list</code></li>
<li><code translate="no" dir="ltr">dataform.releaseConfigs.update</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.commit</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.computeAccessTokenStatus</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.create</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.createTagBinding</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.delete</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.fetchHistory</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.fetchRemoteBranches</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.get</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.list</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.listTagBindings</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.move</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.queryDirectoryContents</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.readFile</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.scheduleRelease</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.scheduleWorkflow</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">dataform.repositories.update</code></li>
<li><code translate="no" dir="ltr">dataform.teamFolders.create</code></li>
<li><code translate="no" dir="ltr">dataform.teamFolders.delete</code></li>
<li><code translate="no" dir="ltr">dataform.teamFolders.deleteTree</code></li>
<li><code translate="no" dir="ltr">dataform.teamFolders.get</code></li>
<li><code translate="no" dir="ltr">dataform.teamFolders.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">dataform.teamFolders.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">dataform.teamFolders.update</code></li>
<li><code translate="no" dir="ltr">dataform.workflowConfigs.create</code></li>
<li><code translate="no" dir="ltr">dataform.workflowConfigs.delete</code></li>
<li><code translate="no" dir="ltr">dataform.workflowConfigs.get</code></li>
<li><code translate="no" dir="ltr">dataform.workflowConfigs.list</code></li>
<li><code translate="no" dir="ltr">dataform.workflowConfigs.update</code></li>
<li><code translate="no" dir="ltr">dataform.workflowInvocations.cancel</code></li>
<li><code translate="no" dir="ltr">dataform.workflowInvocations.create</code></li>
<li><code translate="no" dir="ltr">dataform.workflowInvocations.delete</code></li>
<li><code translate="no" dir="ltr">dataform.workflowInvocations.get</code></li>
<li><code translate="no" dir="ltr">dataform.workflowInvocations.list</code></li>
<li><code translate="no" dir="ltr">dataform.workflowInvocations.query</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.commit</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.create</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.delete</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.fetchFileDiff</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.fetchFileGitStatuses</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.fetchGitAheadBehind</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.get</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.installNpmPackages</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.list</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.makeDirectory</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.moveDirectory</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.moveFile</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.pull</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.push</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.queryDirectoryContents</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.readFile</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.removeDirectory</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.removeFile</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.reset</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.searchFiles</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">dataform.workspaces.writeFile</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">dataplex.agentTasks.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">dataplex.agentTasks.create</code></li>
<li><code translate="no" dir="ltr">dataplex.agentTasks.delete</code></li>
<li><code translate="no" dir="ltr">dataplex.agentTasks.get</code></li>
<li><code translate="no" dir="ltr">dataplex.agentTasks.getData</code></li>
<li><code translate="no" dir="ltr">dataplex.agentTasks.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">dataplex.agentTasks.list</code></li>
<li><code translate="no" dir="ltr">dataplex.agentTasks.run</code></li>
<li><code translate="no" dir="ltr">dataplex.agentTasks.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">dataplex.agentTasks.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">dataplex.datascans.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">dataplex.datascans.cancel</code></li>
<li><code translate="no" dir="ltr">dataplex.datascans.create</code></li>
<li><code translate="no" dir="ltr">dataplex.datascans.delete</code></li>
<li><code translate="no" dir="ltr">dataplex.datascans.get</code></li>
<li><code translate="no" dir="ltr">dataplex.datascans.getData</code></li>
<li><code translate="no" dir="ltr">dataplex.datascans.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">dataplex.datascans.list</code></li>
<li><code translate="no" dir="ltr">dataplex.datascans.run</code></li>
<li><code translate="no" dir="ltr">dataplex.datascans.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">dataplex.datascans.update</code></li>
</ul>
<p><code translate="no" dir="ltr">dataplex.operations.get</code></p>
<p><code translate="no" dir="ltr">dataplex.operations.list</code></p>
<p><code translate="no" dir="ltr">dataplex.projects.search</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">developerconnect.accountConnectors.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">developerconnect.accountConnectors.create</code></li>
<li><code translate="no" dir="ltr">developerconnect.accountConnectors.delete</code></li>
<li><code translate="no" dir="ltr">developerconnect.accountConnectors.fetchUserRepositories</code></li>
<li><code translate="no" dir="ltr">developerconnect.accountConnectors.get</code></li>
<li><code translate="no" dir="ltr">developerconnect.accountConnectors.gitProxyRead</code></li>
<li><code translate="no" dir="ltr">developerconnect.accountConnectors.gitProxyWrite</code></li>
<li><code translate="no" dir="ltr">developerconnect.accountConnectors.httpProxyRead</code></li>
<li><code translate="no" dir="ltr">developerconnect.accountConnectors.httpProxyWrite</code></li>
<li><code translate="no" dir="ltr">developerconnect.accountConnectors.list</code></li>
<li><code translate="no" dir="ltr">developerconnect.accountConnectors.update</code></li>
</ul>
<p><code translate="no" dir="ltr">developerconnect.connections.constructGitHubAppManifest</code></p>
<p><code translate="no" dir="ltr">developerconnect.connections.create</code></p>
<p><code translate="no" dir="ltr">developerconnect.connections.delete</code></p>
<p><code translate="no" dir="ltr">developerconnect.connections.fetchGitHubInstallations</code></p>
<p><code translate="no" dir="ltr">developerconnect.connections.fetchLinkableGitRepositories</code></p>
<p><code translate="no" dir="ltr">developerconnect.connections.generateGitHubStateToken</code></p>
<p><code translate="no" dir="ltr">developerconnect.connections.get</code></p>
<p><code translate="no" dir="ltr">developerconnect.connections.list</code></p>
<p><code translate="no" dir="ltr">developerconnect.connections.processGitHubAppCreationCallback</code></p>
<p><code translate="no" dir="ltr">developerconnect.connections.processGitHubOAuthCallback</code></p>
<p><code translate="no" dir="ltr">developerconnect.connections.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">developerconnect.gitRepositoryLinks.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">developerconnect.gitRepositoryLinks.create</code></li>
<li><code translate="no" dir="ltr">developerconnect.gitRepositoryLinks.delete</code></li>
<li><code translate="no" dir="ltr">developerconnect.gitRepositoryLinks.fetchGitRefs</code></li>
<li><code translate="no" dir="ltr">developerconnect.gitRepositoryLinks.fetchReadToken</code></li>
<li><code translate="no" dir="ltr">developerconnect.gitRepositoryLinks.fetchReadWriteToken</code></li>
<li><code translate="no" dir="ltr">developerconnect.gitRepositoryLinks.get</code></li>
<li><code translate="no" dir="ltr">developerconnect.gitRepositoryLinks.gitProxyRead</code></li>
<li><code translate="no" dir="ltr">developerconnect.gitRepositoryLinks.gitProxyWrite</code></li>
<li><code translate="no" dir="ltr">developerconnect.gitRepositoryLinks.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">developerconnect.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">developerconnect.locations.get</code></li>
<li><code translate="no" dir="ltr">developerconnect.locations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">developerconnect.operations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">developerconnect.operations.cancel</code></li>
<li><code translate="no" dir="ltr">developerconnect.operations.delete</code></li>
<li><code translate="no" dir="ltr">developerconnect.operations.get</code></li>
<li><code translate="no" dir="ltr">developerconnect.operations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">developerconnect.providers.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">developerconnect.users.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">developerconnect.users.delete</code></li>
<li><code translate="no" dir="ltr">developerconnect.users.deleteSelf</code></li>
<li><code translate="no" dir="ltr">developerconnect.users.fetchAccessToken</code></li>
<li><code translate="no" dir="ltr">developerconnect.users.finishOAuth</code></li>
<li><code translate="no" dir="ltr">developerconnect.users.getSelf</code></li>
<li><code translate="no" dir="ltr">developerconnect.users.list</code></li>
<li><code translate="no" dir="ltr">developerconnect.users.startOAuth</code></li>
</ul>
<p><code translate="no" dir="ltr">dns.networks.targetWithPeeringZone</code></p>
<p><code translate="no" dir="ltr">firebase.projects.get</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.actAs</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.get</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.getAccessToken</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.implicitDelegation</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.list</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.signBlob</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.signJwt</code></p>
<p><code translate="no" dir="ltr">logging.buckets.create</code></p>
<p><code translate="no" dir="ltr">logging.buckets.createTagBinding</code></p>
<p><code translate="no" dir="ltr">logging.buckets.delete</code></p>
<p><code translate="no" dir="ltr">logging.buckets.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">logging.buckets.get</code></p>
<p><code translate="no" dir="ltr">logging.buckets.list</code></p>
<p><code translate="no" dir="ltr">logging.buckets.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">logging.buckets.listTagBindings</code></p>
<p><code translate="no" dir="ltr">logging.buckets.undelete</code></p>
<p><code translate="no" dir="ltr">logging.buckets.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">logging.exclusions.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">logging.exclusions.create</code></li>
<li><code translate="no" dir="ltr">logging.exclusions.delete</code></li>
<li><code translate="no" dir="ltr">logging.exclusions.get</code></li>
<li><code translate="no" dir="ltr">logging.exclusions.list</code></li>
<li><code translate="no" dir="ltr">logging.exclusions.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">logging.links.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">logging.links.create</code></li>
<li><code translate="no" dir="ltr">logging.links.delete</code></li>
<li><code translate="no" dir="ltr">logging.links.get</code></li>
<li><code translate="no" dir="ltr">logging.links.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">logging.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">logging.locations.get</code></li>
<li><code translate="no" dir="ltr">logging.locations.list</code></li>
</ul>
<p><code translate="no" dir="ltr">logging.logEntries.create</code></p>
<p><code translate="no" dir="ltr">logging.logEntries.route</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">logging.logMetrics.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">logging.logMetrics.create</code></li>
<li><code translate="no" dir="ltr">logging.logMetrics.delete</code></li>
<li><code translate="no" dir="ltr">logging.logMetrics.get</code></li>
<li><code translate="no" dir="ltr">logging.logMetrics.list</code></li>
<li><code translate="no" dir="ltr">logging.logMetrics.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">logging.logScopes.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">logging.logScopes.create</code></li>
<li><code translate="no" dir="ltr">logging.logScopes.delete</code></li>
<li><code translate="no" dir="ltr">logging.logScopes.get</code></li>
<li><code translate="no" dir="ltr">logging.logScopes.list</code></li>
<li><code translate="no" dir="ltr">logging.logScopes.update</code></li>
</ul>
<p><code translate="no" dir="ltr">logging.logServiceIndexes.list</code></p>
<p><code translate="no" dir="ltr">logging.logServices.list</code></p>
<p><code translate="no" dir="ltr">logging.logs.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">logging.notificationRules.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">logging.notificationRules.create</code></li>
<li><code translate="no" dir="ltr">logging.notificationRules.delete</code></li>
<li><code translate="no" dir="ltr">logging.notificationRules.get</code></li>
<li><code translate="no" dir="ltr">logging.notificationRules.list</code></li>
<li><code translate="no" dir="ltr">logging.notificationRules.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">logging.operations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">logging.operations.cancel</code></li>
<li><code translate="no" dir="ltr">logging.operations.get</code></li>
<li><code translate="no" dir="ltr">logging.operations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">logging.settings.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">logging.settings.get</code></li>
<li><code translate="no" dir="ltr">logging.settings.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">logging.sinks.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">logging.sinks.create</code></li>
<li><code translate="no" dir="ltr">logging.sinks.delete</code></li>
<li><code translate="no" dir="ltr">logging.sinks.get</code></li>
<li><code translate="no" dir="ltr">logging.sinks.list</code></li>
<li><code translate="no" dir="ltr">logging.sinks.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">logging.sqlAlerts.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">logging.sqlAlerts.create</code></li>
<li><code translate="no" dir="ltr">logging.sqlAlerts.update</code></li>
</ul>
<p><code translate="no" dir="ltr">logging.views.create</code></p>
<p><code translate="no" dir="ltr">logging.views.delete</code></p>
<p><code translate="no" dir="ltr">logging.views.get</code></p>
<p><code translate="no" dir="ltr">logging.views.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">logging.views.list</code></p>
<p><code translate="no" dir="ltr">logging.views.update</code></p>
<p><code translate="no" dir="ltr">monitoring.alertPolicies.create</code></p>
<p><code translate="no" dir="ltr">monitoring.alertPolicies.delete</code></p>
<p><code translate="no" dir="ltr">monitoring.alertPolicies.get</code></p>
<p><code translate="no" dir="ltr">monitoring.alertPolicies.list</code></p>
<p><code translate="no" dir="ltr">monitoring.alertPolicies.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">monitoring.alertPolicies.listTagBindings</code></p>
<p><code translate="no" dir="ltr">monitoring.alertPolicies.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">monitoring.alerts.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">monitoring.alerts.get</code></li>
<li><code translate="no" dir="ltr">monitoring.alerts.list</code></li>
</ul>
<p><code translate="no" dir="ltr">monitoring.dashboards.get</code></p>
<p><code translate="no" dir="ltr">monitoring.dashboards.list</code></p>
<p><code translate="no" dir="ltr">monitoring.dashboards.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">monitoring.dashboards.listTagBindings</code></p>
<p><code translate="no" dir="ltr">monitoring.groups.get</code></p>
<p><code translate="no" dir="ltr">monitoring.groups.list</code></p>
<p><code translate="no" dir="ltr">monitoring.metricDescriptors.create</code></p>
<p><code translate="no" dir="ltr">monitoring.metricDescriptors.get</code></p>
<p><code translate="no" dir="ltr">monitoring.metricDescriptors.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">monitoring.monitoredResourceDescriptors.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">monitoring.monitoredResourceDescriptors.get</code></li>
<li><code translate="no" dir="ltr">monitoring.monitoredResourceDescriptors.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">monitoring.notificationChannelDescriptors.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">monitoring.notificationChannelDescriptors.get</code></li>
<li><code translate="no" dir="ltr">monitoring.notificationChannelDescriptors.list</code></li>
</ul>
<p><code translate="no" dir="ltr">monitoring.notificationChannels.get</code></p>
<p><code translate="no" dir="ltr">monitoring.notificationChannels.list</code></p>
<p><code translate="no" dir="ltr">monitoring.services.get</code></p>
<p><code translate="no" dir="ltr">monitoring.services.list</code></p>
<p><code translate="no" dir="ltr">monitoring.slos.get</code></p>
<p><code translate="no" dir="ltr">monitoring.slos.list</code></p>
<p><code translate="no" dir="ltr">monitoring.snoozes.get</code></p>
<p><code translate="no" dir="ltr">monitoring.snoozes.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">monitoring.timeSeries.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">monitoring.timeSeries.create</code></li>
<li><code translate="no" dir="ltr">monitoring.timeSeries.list</code></li>
</ul>
<p><code translate="no" dir="ltr">monitoring.uptimeCheckConfigs.get</code></p>
<p><code translate="no" dir="ltr">monitoring.uptimeCheckConfigs.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">networkconnectivity.internalRanges.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">networkconnectivity.internalRanges.create</code></li>
<li><code translate="no" dir="ltr">networkconnectivity.internalRanges.delete</code></li>
<li><code translate="no" dir="ltr">networkconnectivity.internalRanges.get</code></li>
<li><code translate="no" dir="ltr">networkconnectivity.internalRanges.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">networkconnectivity.internalRanges.list</code></li>
<li><code translate="no" dir="ltr">networkconnectivity.internalRanges.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">networkconnectivity.internalRanges.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">networkconnectivity.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">networkconnectivity.locations.get</code></li>
<li><code translate="no" dir="ltr">networkconnectivity.locations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">networkconnectivity.operations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">networkconnectivity.operations.cancel</code></li>
<li><code translate="no" dir="ltr">networkconnectivity.operations.delete</code></li>
<li><code translate="no" dir="ltr">networkconnectivity.operations.get</code></li>
<li><code translate="no" dir="ltr">networkconnectivity.operations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">networkconnectivity.policyBasedRoutes.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">networkconnectivity.policyBasedRoutes.create</code></li>
<li><code translate="no" dir="ltr">networkconnectivity.policyBasedRoutes.delete</code></li>
<li><code translate="no" dir="ltr">networkconnectivity.policyBasedRoutes.get</code></li>
<li><code translate="no" dir="ltr">networkconnectivity.policyBasedRoutes.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">networkconnectivity.policyBasedRoutes.list</code></li>
<li><code translate="no" dir="ltr">networkconnectivity.policyBasedRoutes.setIamPolicy</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">networkconnectivity.regionalEndpoints.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">networkconnectivity.regionalEndpoints.create</code></li>
<li><code translate="no" dir="ltr">networkconnectivity.regionalEndpoints.delete</code></li>
<li><code translate="no" dir="ltr">networkconnectivity.regionalEndpoints.get</code></li>
<li><code translate="no" dir="ltr">networkconnectivity.regionalEndpoints.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">networkconnectivity.serviceClasses.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">networkconnectivity.serviceClasses.create</code></li>
<li><code translate="no" dir="ltr">networkconnectivity.serviceClasses.delete</code></li>
<li><code translate="no" dir="ltr">networkconnectivity.serviceClasses.get</code></li>
<li><code translate="no" dir="ltr">networkconnectivity.serviceClasses.list</code></li>
<li><code translate="no" dir="ltr">networkconnectivity.serviceClasses.update</code></li>
<li><code translate="no" dir="ltr">networkconnectivity.serviceClasses.use</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">networkconnectivity.serviceConnectionMaps.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">networkconnectivity.serviceConnectionMaps.create</code></li>
<li><code translate="no" dir="ltr">networkconnectivity.serviceConnectionMaps.delete</code></li>
<li><code translate="no" dir="ltr">networkconnectivity.serviceConnectionMaps.get</code></li>
<li><code translate="no" dir="ltr">networkconnectivity.serviceConnectionMaps.list</code></li>
<li><code translate="no" dir="ltr">networkconnectivity.serviceConnectionMaps.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">networkconnectivity.serviceConnectionPolicies.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">networkconnectivity.serviceConnectionPolicies.create</code></li>
<li><code translate="no" dir="ltr">networkconnectivity.serviceConnectionPolicies.delete</code></li>
<li><code translate="no" dir="ltr">networkconnectivity.serviceConnectionPolicies.get</code></li>
<li><code translate="no" dir="ltr">networkconnectivity.serviceConnectionPolicies.list</code></li>
<li><code translate="no" dir="ltr">networkconnectivity.serviceConnectionPolicies.update</code></li>
</ul>
<p><code translate="no" dir="ltr">networkmanagement.connectivitytests.get</code></p>
<p><code translate="no" dir="ltr">networkmanagement.connectivitytests.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">networksecurity.addressGroups.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">networksecurity.addressGroups.create</code></li>
<li><code translate="no" dir="ltr">networksecurity.addressGroups.delete</code></li>
<li><code translate="no" dir="ltr">networksecurity.addressGroups.get</code></li>
<li><code translate="no" dir="ltr">networksecurity.addressGroups.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">networksecurity.addressGroups.list</code></li>
<li><code translate="no" dir="ltr">networksecurity.addressGroups.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">networksecurity.addressGroups.update</code></li>
<li><code translate="no" dir="ltr">networksecurity.addressGroups.use</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">networksecurity.authorizationPolicies.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">networksecurity.authorizationPolicies.create</code></li>
<li><code translate="no" dir="ltr">networksecurity.authorizationPolicies.createTagBinding</code></li>
<li><code translate="no" dir="ltr">networksecurity.authorizationPolicies.delete</code></li>
<li><code translate="no" dir="ltr">networksecurity.authorizationPolicies.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">networksecurity.authorizationPolicies.get</code></li>
<li><code translate="no" dir="ltr">networksecurity.authorizationPolicies.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">networksecurity.authorizationPolicies.list</code></li>
<li><code translate="no" dir="ltr">networksecurity.authorizationPolicies.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">networksecurity.authorizationPolicies.listTagBindings</code></li>
<li><code translate="no" dir="ltr">networksecurity.authorizationPolicies.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">networksecurity.authorizationPolicies.update</code></li>
<li><code translate="no" dir="ltr">networksecurity.authorizationPolicies.use</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">networksecurity.authzPolicies.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">networksecurity.authzPolicies.create</code></li>
<li><code translate="no" dir="ltr">networksecurity.authzPolicies.delete</code></li>
<li><code translate="no" dir="ltr">networksecurity.authzPolicies.get</code></li>
<li><code translate="no" dir="ltr">networksecurity.authzPolicies.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">networksecurity.authzPolicies.list</code></li>
<li><code translate="no" dir="ltr">networksecurity.authzPolicies.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">networksecurity.authzPolicies.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">networksecurity.backendAuthenticationConfigs.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">networksecurity.backendAuthenticationConfigs.create</code></li>
<li><code translate="no" dir="ltr">networksecurity.backendAuthenticationConfigs.delete</code></li>
<li><code translate="no" dir="ltr">networksecurity.backendAuthenticationConfigs.get</code></li>
<li><code translate="no" dir="ltr">networksecurity.backendAuthenticationConfigs.list</code></li>
<li><code translate="no" dir="ltr">networksecurity.backendAuthenticationConfigs.update</code></li>
<li><code translate="no" dir="ltr">networksecurity.backendAuthenticationConfigs.use</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">networksecurity.clientTlsPolicies.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">networksecurity.clientTlsPolicies.create</code></li>
<li><code translate="no" dir="ltr">networksecurity.clientTlsPolicies.createTagBinding</code></li>
<li><code translate="no" dir="ltr">networksecurity.clientTlsPolicies.delete</code></li>
<li><code translate="no" dir="ltr">networksecurity.clientTlsPolicies.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">networksecurity.clientTlsPolicies.get</code></li>
<li><code translate="no" dir="ltr">networksecurity.clientTlsPolicies.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">networksecurity.clientTlsPolicies.list</code></li>
<li><code translate="no" dir="ltr">networksecurity.clientTlsPolicies.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">networksecurity.clientTlsPolicies.listTagBindings</code></li>
<li><code translate="no" dir="ltr">networksecurity.clientTlsPolicies.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">networksecurity.clientTlsPolicies.update</code></li>
<li><code translate="no" dir="ltr">networksecurity.clientTlsPolicies.use</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">networksecurity.firewallEndpointAssociations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">networksecurity.firewallEndpointAssociations.create</code></li>
<li><code translate="no" dir="ltr">networksecurity.firewallEndpointAssociations.delete</code></li>
<li><code translate="no" dir="ltr">networksecurity.firewallEndpointAssociations.get</code></li>
<li><code translate="no" dir="ltr">networksecurity.firewallEndpointAssociations.list</code></li>
<li><code translate="no" dir="ltr">networksecurity.firewallEndpointAssociations.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">networksecurity.firewallEndpoints.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">networksecurity.firewallEndpoints.create</code></li>
<li><code translate="no" dir="ltr">networksecurity.firewallEndpoints.createVerdictChangeRequest</code></li>
<li><code translate="no" dir="ltr">networksecurity.firewallEndpoints.delete</code></li>
<li><code translate="no" dir="ltr">networksecurity.firewallEndpoints.get</code></li>
<li><code translate="no" dir="ltr">networksecurity.firewallEndpoints.getVerdictChangeRequest</code></li>
<li><code translate="no" dir="ltr">networksecurity.firewallEndpoints.getWildfireReport</code></li>
<li><code translate="no" dir="ltr">networksecurity.firewallEndpoints.getWildfireSample</code></li>
<li><code translate="no" dir="ltr">networksecurity.firewallEndpoints.list</code></li>
<li><code translate="no" dir="ltr">networksecurity.firewallEndpoints.listVerdictChangeRequests</code></li>
<li><code translate="no" dir="ltr">networksecurity.firewallEndpoints.submitVerdictChangeRequest</code></li>
<li><code translate="no" dir="ltr">networksecurity.firewallEndpoints.update</code></li>
<li><code translate="no" dir="ltr">networksecurity.firewallEndpoints.use</code></li>
<li><code translate="no" dir="ltr">networksecurity.firewallEndpoints.useWildfire</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">networksecurity.gatewaySecurityPolicies.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">networksecurity.gatewaySecurityPolicies.create</code></li>
<li><code translate="no" dir="ltr">networksecurity.gatewaySecurityPolicies.delete</code></li>
<li><code translate="no" dir="ltr">networksecurity.gatewaySecurityPolicies.get</code></li>
<li><code translate="no" dir="ltr">networksecurity.gatewaySecurityPolicies.list</code></li>
<li><code translate="no" dir="ltr">networksecurity.gatewaySecurityPolicies.update</code></li>
<li><code translate="no" dir="ltr">networksecurity.gatewaySecurityPolicies.use</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">networksecurity.gatewaySecurityPolicyRules.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">networksecurity.gatewaySecurityPolicyRules.create</code></li>
<li><code translate="no" dir="ltr">networksecurity.gatewaySecurityPolicyRules.delete</code></li>
<li><code translate="no" dir="ltr">networksecurity.gatewaySecurityPolicyRules.get</code></li>
<li><code translate="no" dir="ltr">networksecurity.gatewaySecurityPolicyRules.list</code></li>
<li><code translate="no" dir="ltr">networksecurity.gatewaySecurityPolicyRules.update</code></li>
<li><code translate="no" dir="ltr">networksecurity.gatewaySecurityPolicyRules.use</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">networksecurity.locations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">networksecurity.locations.get</code></li>
<li><code translate="no" dir="ltr">networksecurity.locations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">networksecurity.operations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">networksecurity.operations.cancel</code></li>
<li><code translate="no" dir="ltr">networksecurity.operations.delete</code></li>
<li><code translate="no" dir="ltr">networksecurity.operations.get</code></li>
<li><code translate="no" dir="ltr">networksecurity.operations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">networksecurity.sacAttachments.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">networksecurity.sacAttachments.create</code></li>
<li><code translate="no" dir="ltr">networksecurity.sacAttachments.delete</code></li>
<li><code translate="no" dir="ltr">networksecurity.sacAttachments.get</code></li>
<li><code translate="no" dir="ltr">networksecurity.sacAttachments.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">networksecurity.sacRealms.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">networksecurity.sacRealms.create</code></li>
<li><code translate="no" dir="ltr">networksecurity.sacRealms.delete</code></li>
<li><code translate="no" dir="ltr">networksecurity.sacRealms.get</code></li>
<li><code translate="no" dir="ltr">networksecurity.sacRealms.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">networksecurity.securityProfileGroups.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">networksecurity.securityProfileGroups.create</code></li>
<li><code translate="no" dir="ltr">networksecurity.securityProfileGroups.delete</code></li>
<li><code translate="no" dir="ltr">networksecurity.securityProfileGroups.get</code></li>
<li><code translate="no" dir="ltr">networksecurity.securityProfileGroups.list</code></li>
<li><code translate="no" dir="ltr">networksecurity.securityProfileGroups.update</code></li>
<li><code translate="no" dir="ltr">networksecurity.securityProfileGroups.use</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">networksecurity.securityProfiles.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">networksecurity.securityProfiles.create</code></li>
<li><code translate="no" dir="ltr">networksecurity.securityProfiles.delete</code></li>
<li><code translate="no" dir="ltr">networksecurity.securityProfiles.get</code></li>
<li><code translate="no" dir="ltr">networksecurity.securityProfiles.list</code></li>
<li><code translate="no" dir="ltr">networksecurity.securityProfiles.update</code></li>
<li><code translate="no" dir="ltr">networksecurity.securityProfiles.use</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">networksecurity.serverTlsPolicies.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">networksecurity.serverTlsPolicies.create</code></li>
<li><code translate="no" dir="ltr">networksecurity.serverTlsPolicies.createTagBinding</code></li>
<li><code translate="no" dir="ltr">networksecurity.serverTlsPolicies.delete</code></li>
<li><code translate="no" dir="ltr">networksecurity.serverTlsPolicies.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">networksecurity.serverTlsPolicies.get</code></li>
<li><code translate="no" dir="ltr">networksecurity.serverTlsPolicies.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">networksecurity.serverTlsPolicies.list</code></li>
<li><code translate="no" dir="ltr">networksecurity.serverTlsPolicies.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">networksecurity.serverTlsPolicies.listTagBindings</code></li>
<li><code translate="no" dir="ltr">networksecurity.serverTlsPolicies.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">networksecurity.serverTlsPolicies.update</code></li>
<li><code translate="no" dir="ltr">networksecurity.serverTlsPolicies.use</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">networksecurity.tlsInspectionPolicies.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">networksecurity.tlsInspectionPolicies.create</code></li>
<li><code translate="no" dir="ltr">networksecurity.tlsInspectionPolicies.delete</code></li>
<li><code translate="no" dir="ltr">networksecurity.tlsInspectionPolicies.get</code></li>
<li><code translate="no" dir="ltr">networksecurity.tlsInspectionPolicies.list</code></li>
<li><code translate="no" dir="ltr">networksecurity.tlsInspectionPolicies.update</code></li>
<li><code translate="no" dir="ltr">networksecurity.tlsInspectionPolicies.use</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">networksecurity.urlLists.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">networksecurity.urlLists.create</code></li>
<li><code translate="no" dir="ltr">networksecurity.urlLists.delete</code></li>
<li><code translate="no" dir="ltr">networksecurity.urlLists.get</code></li>
<li><code translate="no" dir="ltr">networksecurity.urlLists.list</code></li>
<li><code translate="no" dir="ltr">networksecurity.urlLists.update</code></li>
<li><code translate="no" dir="ltr">networksecurity.urlLists.use</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">networkservices.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">networkservices.agentGateways.create</code></li>
<li><code translate="no" dir="ltr">networkservices.agentGateways.delete</code></li>
<li><code translate="no" dir="ltr">networkservices.agentGateways.get</code></li>
<li><code translate="no" dir="ltr">networkservices.agentGateways.list</code></li>
<li><code translate="no" dir="ltr">networkservices.agentGateways.update</code></li>
<li><code translate="no" dir="ltr">networkservices.agentGateways.use</code></li>
<li><code translate="no" dir="ltr">networkservices.authzExtensions.create</code></li>
<li><code translate="no" dir="ltr">networkservices.authzExtensions.delete</code></li>
<li><code translate="no" dir="ltr">networkservices.authzExtensions.get</code></li>
<li><code translate="no" dir="ltr">networkservices.authzExtensions.list</code></li>
<li><code translate="no" dir="ltr">networkservices.authzExtensions.update</code></li>
<li><code translate="no" dir="ltr">networkservices.authzExtensions.use</code></li>
<li><code translate="no" dir="ltr">networkservices.endpointConfigSelectors.createTagBinding</code></li>
<li><code translate="no" dir="ltr">networkservices.endpointConfigSelectors.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">networkservices.endpointConfigSelectors.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">networkservices.endpointConfigSelectors.listTagBindings</code></li>
<li><code translate="no" dir="ltr">networkservices.endpointPolicies.create</code></li>
<li><code translate="no" dir="ltr">networkservices.endpointPolicies.delete</code></li>
<li><code translate="no" dir="ltr">networkservices.endpointPolicies.get</code></li>
<li><code translate="no" dir="ltr">networkservices.endpointPolicies.list</code></li>
<li><code translate="no" dir="ltr">networkservices.endpointPolicies.update</code></li>
<li><code translate="no" dir="ltr">networkservices.gateways.create</code></li>
<li><code translate="no" dir="ltr">networkservices.gateways.createTagBinding</code></li>
<li><code translate="no" dir="ltr">networkservices.gateways.delete</code></li>
<li><code translate="no" dir="ltr">networkservices.gateways.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">networkservices.gateways.get</code></li>
<li><code translate="no" dir="ltr">networkservices.gateways.list</code></li>
<li><code translate="no" dir="ltr">networkservices.gateways.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">networkservices.gateways.listTagBindings</code></li>
<li><code translate="no" dir="ltr">networkservices.gateways.update</code></li>
<li><code translate="no" dir="ltr">networkservices.gateways.use</code></li>
<li><code translate="no" dir="ltr">networkservices.googleTagGatewayPolicies.create</code></li>
<li><code translate="no" dir="ltr">networkservices.googleTagGatewayPolicies.delete</code></li>
<li><code translate="no" dir="ltr">networkservices.googleTagGatewayPolicies.get</code></li>
<li><code translate="no" dir="ltr">networkservices.googleTagGatewayPolicies.list</code></li>
<li><code translate="no" dir="ltr">networkservices.googleTagGatewayPolicies.update</code></li>
<li><code translate="no" dir="ltr">networkservices.grpcRoutes.create</code></li>
<li><code translate="no" dir="ltr">networkservices.grpcRoutes.delete</code></li>
<li><code translate="no" dir="ltr">networkservices.grpcRoutes.get</code></li>
<li><code translate="no" dir="ltr">networkservices.grpcRoutes.list</code></li>
<li><code translate="no" dir="ltr">networkservices.grpcRoutes.update</code></li>
<li><code translate="no" dir="ltr">networkservices.httpFilters.create</code></li>
<li><code translate="no" dir="ltr">networkservices.httpFilters.createTagBinding</code></li>
<li><code translate="no" dir="ltr">networkservices.httpFilters.delete</code></li>
<li><code translate="no" dir="ltr">networkservices.httpFilters.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">networkservices.httpFilters.get</code></li>
<li><code translate="no" dir="ltr">networkservices.httpFilters.list</code></li>
<li><code translate="no" dir="ltr">networkservices.httpFilters.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">networkservices.httpFilters.listTagBindings</code></li>
<li><code translate="no" dir="ltr">networkservices.httpFilters.update</code></li>
<li><code translate="no" dir="ltr">networkservices.httpRoutes.create</code></li>
<li><code translate="no" dir="ltr">networkservices.httpRoutes.delete</code></li>
<li><code translate="no" dir="ltr">networkservices.httpRoutes.get</code></li>
<li><code translate="no" dir="ltr">networkservices.httpRoutes.list</code></li>
<li><code translate="no" dir="ltr">networkservices.httpRoutes.update</code></li>
<li><code translate="no" dir="ltr">networkservices.httpfilters.create</code></li>
<li><code translate="no" dir="ltr">networkservices.httpfilters.delete</code></li>
<li><code translate="no" dir="ltr">networkservices.httpfilters.get</code></li>
<li><code translate="no" dir="ltr">networkservices.httpfilters.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">networkservices.httpfilters.list</code></li>
<li><code translate="no" dir="ltr">networkservices.httpfilters.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">networkservices.httpfilters.update</code></li>
<li><code translate="no" dir="ltr">networkservices.httpfilters.use</code></li>
<li><code translate="no" dir="ltr">networkservices.lbEdgeExtensions.create</code></li>
<li><code translate="no" dir="ltr">networkservices.lbEdgeExtensions.delete</code></li>
<li><code translate="no" dir="ltr">networkservices.lbEdgeExtensions.get</code></li>
<li><code translate="no" dir="ltr">networkservices.lbEdgeExtensions.list</code></li>
<li><code translate="no" dir="ltr">networkservices.lbEdgeExtensions.update</code></li>
<li><code translate="no" dir="ltr">networkservices.lbRouteExtensions.create</code></li>
<li><code translate="no" dir="ltr">networkservices.lbRouteExtensions.delete</code></li>
<li><code translate="no" dir="ltr">networkservices.lbRouteExtensions.get</code></li>
<li><code translate="no" dir="ltr">networkservices.lbRouteExtensions.list</code></li>
<li><code translate="no" dir="ltr">networkservices.lbRouteExtensions.update</code></li>
<li><code translate="no" dir="ltr">networkservices.lbTcpExtensions.createForNetwork</code></li>
<li><code translate="no" dir="ltr">networkservices.lbTcpExtensions.deleteForNetwork</code></li>
<li><code translate="no" dir="ltr">networkservices.lbTcpExtensions.getForNetwork</code></li>
<li><code translate="no" dir="ltr">networkservices.lbTcpExtensions.listForNetwork</code></li>
<li><code translate="no" dir="ltr">networkservices.lbTcpExtensions.updateForNetwork</code></li>
<li><code translate="no" dir="ltr">networkservices.lbTrafficExtensions.create</code></li>
<li><code translate="no" dir="ltr">networkservices.lbTrafficExtensions.delete</code></li>
<li><code translate="no" dir="ltr">networkservices.lbTrafficExtensions.get</code></li>
<li><code translate="no" dir="ltr">networkservices.lbTrafficExtensions.list</code></li>
<li><code translate="no" dir="ltr">networkservices.lbTrafficExtensions.update</code></li>
<li><code translate="no" dir="ltr">networkservices.locations.get</code></li>
<li><code translate="no" dir="ltr">networkservices.locations.list</code></li>
<li><code translate="no" dir="ltr">networkservices.meshes.create</code></li>
<li><code translate="no" dir="ltr">networkservices.meshes.createTagBinding</code></li>
<li><code translate="no" dir="ltr">networkservices.meshes.delete</code></li>
<li><code translate="no" dir="ltr">networkservices.meshes.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">networkservices.meshes.get</code></li>
<li><code translate="no" dir="ltr">networkservices.meshes.list</code></li>
<li><code translate="no" dir="ltr">networkservices.meshes.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">networkservices.meshes.listTagBindings</code></li>
<li><code translate="no" dir="ltr">networkservices.meshes.update</code></li>
<li><code translate="no" dir="ltr">networkservices.meshes.use</code></li>
<li><code translate="no" dir="ltr">networkservices.operations.cancel</code></li>
<li><code translate="no" dir="ltr">networkservices.operations.delete</code></li>
<li><code translate="no" dir="ltr">networkservices.operations.get</code></li>
<li><code translate="no" dir="ltr">networkservices.operations.list</code></li>
<li><code translate="no" dir="ltr">networkservices.route_views.get</code></li>
<li><code translate="no" dir="ltr">networkservices.route_views.list</code></li>
<li><code translate="no" dir="ltr">networkservices.serviceBindings.create</code></li>
<li><code translate="no" dir="ltr">networkservices.serviceBindings.delete</code></li>
<li><code translate="no" dir="ltr">networkservices.serviceBindings.get</code></li>
<li><code translate="no" dir="ltr">networkservices.serviceBindings.list</code></li>
<li><code translate="no" dir="ltr">networkservices.serviceBindings.update</code></li>
<li><code translate="no" dir="ltr">networkservices.serviceLbPolicies.create</code></li>
<li><code translate="no" dir="ltr">networkservices.serviceLbPolicies.delete</code></li>
<li><code translate="no" dir="ltr">networkservices.serviceLbPolicies.get</code></li>
<li><code translate="no" dir="ltr">networkservices.serviceLbPolicies.list</code></li>
<li><code translate="no" dir="ltr">networkservices.serviceLbPolicies.update</code></li>
<li><code translate="no" dir="ltr">networkservices.swpSecurityExtensions.create</code></li>
<li><code translate="no" dir="ltr">networkservices.swpSecurityExtensions.delete</code></li>
<li><code translate="no" dir="ltr">networkservices.swpSecurityExtensions.get</code></li>
<li><code translate="no" dir="ltr">networkservices.swpSecurityExtensions.list</code></li>
<li><code translate="no" dir="ltr">networkservices.swpSecurityExtensions.update</code></li>
<li><code translate="no" dir="ltr">networkservices.tcpRoutes.create</code></li>
<li><code translate="no" dir="ltr">networkservices.tcpRoutes.delete</code></li>
<li><code translate="no" dir="ltr">networkservices.tcpRoutes.get</code></li>
<li><code translate="no" dir="ltr">networkservices.tcpRoutes.list</code></li>
<li><code translate="no" dir="ltr">networkservices.tcpRoutes.update</code></li>
<li><code translate="no" dir="ltr">networkservices.tlsRoutes.create</code></li>
<li><code translate="no" dir="ltr">networkservices.tlsRoutes.delete</code></li>
<li><code translate="no" dir="ltr">networkservices.tlsRoutes.get</code></li>
<li><code translate="no" dir="ltr">networkservices.tlsRoutes.list</code></li>
<li><code translate="no" dir="ltr">networkservices.tlsRoutes.update</code></li>
<li><code translate="no" dir="ltr">networkservices.wasmPlugins.create</code></li>
<li><code translate="no" dir="ltr">networkservices.wasmPlugins.delete</code></li>
<li><code translate="no" dir="ltr">networkservices.wasmPlugins.get</code></li>
<li><code translate="no" dir="ltr">networkservices.wasmPlugins.list</code></li>
<li><code translate="no" dir="ltr">networkservices.wasmPlugins.update</code></li>
<li><code translate="no" dir="ltr">networkservices.wasmPlugins.use</code></li>
</ul>
<p><code translate="no" dir="ltr">observability.scopes.get</code></p>
<p><code translate="no" dir="ltr">opsconfigmonitoring.resourceMetadata.list</code></p>
<p><code translate="no" dir="ltr">orgpolicy.policy.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">pubsub.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">pubsub.messageTransforms.validate</code></li>
<li><code translate="no" dir="ltr">pubsub.schemas.attach</code></li>
<li><code translate="no" dir="ltr">pubsub.schemas.commit</code></li>
<li><code translate="no" dir="ltr">pubsub.schemas.create</code></li>
<li><code translate="no" dir="ltr">pubsub.schemas.delete</code></li>
<li><code translate="no" dir="ltr">pubsub.schemas.get</code></li>
<li><code translate="no" dir="ltr">pubsub.schemas.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">pubsub.schemas.list</code></li>
<li><code translate="no" dir="ltr">pubsub.schemas.listRevisions</code></li>
<li><code translate="no" dir="ltr">pubsub.schemas.rollback</code></li>
<li><code translate="no" dir="ltr">pubsub.schemas.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">pubsub.schemas.validate</code></li>
<li><code translate="no" dir="ltr">pubsub.snapshots.create</code></li>
<li><code translate="no" dir="ltr">pubsub.snapshots.createTagBinding</code></li>
<li><code translate="no" dir="ltr">pubsub.snapshots.delete</code></li>
<li><code translate="no" dir="ltr">pubsub.snapshots.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">pubsub.snapshots.get</code></li>
<li><code translate="no" dir="ltr">pubsub.snapshots.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">pubsub.snapshots.list</code></li>
<li><code translate="no" dir="ltr">pubsub.snapshots.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">pubsub.snapshots.listTagBindings</code></li>
<li><code translate="no" dir="ltr">pubsub.snapshots.seek</code></li>
<li><code translate="no" dir="ltr">pubsub.snapshots.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">pubsub.snapshots.update</code></li>
<li><code translate="no" dir="ltr">pubsub.subscriptions.consume</code></li>
<li><code translate="no" dir="ltr">pubsub.subscriptions.create</code></li>
<li><code translate="no" dir="ltr">pubsub.subscriptions.createTagBinding</code></li>
<li><code translate="no" dir="ltr">pubsub.subscriptions.delete</code></li>
<li><code translate="no" dir="ltr">pubsub.subscriptions.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">pubsub.subscriptions.get</code></li>
<li><code translate="no" dir="ltr">pubsub.subscriptions.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">pubsub.subscriptions.list</code></li>
<li><code translate="no" dir="ltr">pubsub.subscriptions.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">pubsub.subscriptions.listTagBindings</code></li>
<li><code translate="no" dir="ltr">pubsub.subscriptions.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">pubsub.subscriptions.update</code></li>
<li><code translate="no" dir="ltr">pubsub.topics.attachSubscription</code></li>
<li><code translate="no" dir="ltr">pubsub.topics.create</code></li>
<li><code translate="no" dir="ltr">pubsub.topics.createTagBinding</code></li>
<li><code translate="no" dir="ltr">pubsub.topics.delete</code></li>
<li><code translate="no" dir="ltr">pubsub.topics.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">pubsub.topics.detachSubscription</code></li>
<li><code translate="no" dir="ltr">pubsub.topics.get</code></li>
<li><code translate="no" dir="ltr">pubsub.topics.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">pubsub.topics.list</code></li>
<li><code translate="no" dir="ltr">pubsub.topics.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">pubsub.topics.listTagBindings</code></li>
<li><code translate="no" dir="ltr">pubsub.topics.publish</code></li>
<li><code translate="no" dir="ltr">pubsub.topics.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">pubsub.topics.update</code></li>
<li><code translate="no" dir="ltr">pubsub.topics.updateTag</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.dataflowDiagnosticsInsights.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.dataflowDiagnosticsInsights.get</code></li>
<li><code translate="no" dir="ltr">recommender.dataflowDiagnosticsInsights.list</code></li>
<li><code translate="no" dir="ltr">recommender.dataflowDiagnosticsInsights.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.iamPolicyInsights.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.iamPolicyInsights.get</code></li>
<li><code translate="no" dir="ltr">recommender.iamPolicyInsights.list</code></li>
<li><code translate="no" dir="ltr">recommender.iamPolicyInsights.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.iamPolicyRecommendations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.iamPolicyRecommendations.get</code></li>
<li><code translate="no" dir="ltr">recommender.iamPolicyRecommendations.list</code></li>
<li><code translate="no" dir="ltr">recommender.iamPolicyRecommendations.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.storageBucketSoftDeleteInsights.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.storageBucketSoftDeleteInsights.get</code></li>
<li><code translate="no" dir="ltr">recommender.storageBucketSoftDeleteInsights.list</code></li>
<li><code translate="no" dir="ltr">recommender.storageBucketSoftDeleteInsights.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">recommender.storageBucketSoftDeleteRecommendations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">recommender.storageBucketSoftDeleteRecommendations.get</code></li>
<li><code translate="no" dir="ltr">recommender.storageBucketSoftDeleteRecommendations.list</code></li>
<li><code translate="no" dir="ltr">recommender.storageBucketSoftDeleteRecommendations.update</code></li>
</ul>
<p><code translate="no" dir="ltr">resourcemanager.hierarchyNodes.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><code translate="no" dir="ltr">servicedirectory.namespaces.create</code></p>
<p><code translate="no" dir="ltr">servicedirectory.namespaces.delete</code></p>
<p><code translate="no" dir="ltr">servicedirectory.services.create</code></p>
<p><code translate="no" dir="ltr">servicedirectory.services.delete</code></p>
<p><code translate="no" dir="ltr">servicenetworking.operations.get</code></p>
<p><code translate="no" dir="ltr">servicenetworking.services.addPeering</code></p>
<p><code translate="no" dir="ltr">servicenetworking.services.createPeeredDnsDomain</code></p>
<p><code translate="no" dir="ltr">servicenetworking.services.deleteConnection</code></p>
<p><code translate="no" dir="ltr">servicenetworking.services.deletePeeredDnsDomain</code></p>
<p><code translate="no" dir="ltr">servicenetworking.services.disableVpcServiceControls</code></p>
<p><code translate="no" dir="ltr">servicenetworking.services.enableVpcServiceControls</code></p>
<p><code translate="no" dir="ltr">servicenetworking.services.get</code></p>
<p><code translate="no" dir="ltr">servicenetworking.services.getVpcServiceControls</code></p>
<p><code translate="no" dir="ltr">servicenetworking.services.listPeeredDnsDomains</code></p>
<p><code translate="no" dir="ltr">serviceusage.catalogs.listMembers</code></p>
<p><code translate="no" dir="ltr">serviceusage.consumerpolicy.analyze</code></p>
<p><code translate="no" dir="ltr">serviceusage.consumerpolicy.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.effectivepolicy.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">serviceusage.groups.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">serviceusage.groups.list</code></li>
<li><code translate="no" dir="ltr">serviceusage.groups.listExpandedMembers</code></li>
<li><code translate="no" dir="ltr">serviceusage.groups.listMembers</code></li>
</ul>
<p><code translate="no" dir="ltr">serviceusage.quotas.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.get</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.list</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.listApis</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.listDependentServices</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.use</code></p>
<p><code translate="no" dir="ltr">serviceusage.values.test</code></p>
<p><code translate="no" dir="ltr">stackdriver.projects.get</code></p>
<p><code translate="no" dir="ltr">stackdriver.resourceMetadata.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.anywhereCaches.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.anywhereCaches.create</code></li>
<li><code translate="no" dir="ltr">storage.anywhereCaches.disable</code></li>
<li><code translate="no" dir="ltr">storage.anywhereCaches.get</code></li>
<li><code translate="no" dir="ltr">storage.anywhereCaches.list</code></li>
<li><code translate="no" dir="ltr">storage.anywhereCaches.pause</code></li>
<li><code translate="no" dir="ltr">storage.anywhereCaches.resume</code></li>
<li><code translate="no" dir="ltr">storage.anywhereCaches.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.bucketOperations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.bucketOperations.cancel</code></li>
<li><code translate="no" dir="ltr">storage.bucketOperations.get</code></li>
<li><code translate="no" dir="ltr">storage.bucketOperations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.buckets.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.buckets.create</code></li>
<li><code translate="no" dir="ltr">storage.buckets.createTagBinding</code></li>
<li><code translate="no" dir="ltr">storage.buckets.delete</code></li>
<li><code translate="no" dir="ltr">storage.buckets.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">storage.buckets.enableObjectRetention</code></li>
<li><code translate="no" dir="ltr">storage.buckets.get</code></li>
<li><code translate="no" dir="ltr">storage.buckets.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">storage.buckets.getIpFilter</code></li>
<li><code translate="no" dir="ltr">storage.buckets.getObjectInsights</code></li>
<li><code translate="no" dir="ltr">storage.buckets.list</code></li>
<li><code translate="no" dir="ltr">storage.buckets.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">storage.buckets.listTagBindings</code></li>
<li><code translate="no" dir="ltr">storage.buckets.relocate</code></li>
<li><code translate="no" dir="ltr">storage.buckets.restore</code></li>
<li><code translate="no" dir="ltr">storage.buckets.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">storage.buckets.setIpFilter</code></li>
<li><code translate="no" dir="ltr">storage.buckets.update</code></li>
<li><code translate="no" dir="ltr">storage.buckets.viewIntelligenceDetails</code></li>
<li><code translate="no" dir="ltr">storage.buckets.viewSecurityIntelligenceDetails</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.featureConfigs.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.featureConfigs.create</code></li>
<li><code translate="no" dir="ltr">storage.featureConfigs.delete</code></li>
<li><code translate="no" dir="ltr">storage.featureConfigs.get</code></li>
<li><code translate="no" dir="ltr">storage.featureConfigs.list</code></li>
<li><code translate="no" dir="ltr">storage.featureConfigs.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.folders.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.folders.create</code></li>
<li><code translate="no" dir="ltr">storage.folders.delete</code></li>
<li><code translate="no" dir="ltr">storage.folders.get</code></li>
<li><code translate="no" dir="ltr">storage.folders.list</code></li>
<li><code translate="no" dir="ltr">storage.folders.rename</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.intelligenceConfigs.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.intelligenceConfigs.get</code></li>
<li><code translate="no" dir="ltr">storage.intelligenceConfigs.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.managedFolders.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.managedFolders.create</code></li>
<li><code translate="no" dir="ltr">storage.managedFolders.delete</code></li>
<li><code translate="no" dir="ltr">storage.managedFolders.get</code></li>
<li><code translate="no" dir="ltr">storage.managedFolders.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">storage.managedFolders.list</code></li>
<li><code translate="no" dir="ltr">storage.managedFolders.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">storage.managedFolders.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.multipartUploads.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.multipartUploads.abort</code></li>
<li><code translate="no" dir="ltr">storage.multipartUploads.create</code></li>
<li><code translate="no" dir="ltr">storage.multipartUploads.list</code></li>
<li><code translate="no" dir="ltr">storage.multipartUploads.listParts</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storage.objects.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storage.objects.create</code></li>
<li><code translate="no" dir="ltr">storage.objects.createContext</code></li>
<li><code translate="no" dir="ltr">storage.objects.delete</code></li>
<li><code translate="no" dir="ltr">storage.objects.deleteContext</code></li>
<li><code translate="no" dir="ltr">storage.objects.get</code></li>
<li><code translate="no" dir="ltr">storage.objects.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">storage.objects.list</code></li>
<li><code translate="no" dir="ltr">storage.objects.move</code></li>
<li><code translate="no" dir="ltr">storage.objects.overrideUnlockedRetention</code></li>
<li><code translate="no" dir="ltr">storage.objects.restore</code></li>
<li><code translate="no" dir="ltr">storage.objects.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">storage.objects.setRetention</code></li>
<li><code translate="no" dir="ltr">storage.objects.update</code></li>
<li><code translate="no" dir="ltr">storage.objects.updateContext</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">storagebatchoperations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">storagebatchoperations.bucketOperations.get</code></li>
<li><code translate="no" dir="ltr">storagebatchoperations.bucketOperations.list</code></li>
<li><code translate="no" dir="ltr">storagebatchoperations.jobs.cancel</code></li>
<li><code translate="no" dir="ltr">storagebatchoperations.jobs.create</code></li>
<li><code translate="no" dir="ltr">storagebatchoperations.jobs.delete</code></li>
<li><code translate="no" dir="ltr">storagebatchoperations.jobs.get</code></li>
<li><code translate="no" dir="ltr">storagebatchoperations.jobs.list</code></li>
<li><code translate="no" dir="ltr">storagebatchoperations.locations.get</code></li>
<li><code translate="no" dir="ltr">storagebatchoperations.locations.list</code></li>
<li><code translate="no" dir="ltr">storagebatchoperations.operations.cancel</code></li>
<li><code translate="no" dir="ltr">storagebatchoperations.operations.delete</code></li>
<li><code translate="no" dir="ltr">storagebatchoperations.operations.get</code></li>
<li><code translate="no" dir="ltr">storagebatchoperations.operations.list</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">trafficdirector.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">trafficdirector.networks.getConfigs</code></li>
<li><code translate="no" dir="ltr">trafficdirector.networks.reportMetrics</code></li>
</ul></td>
</tr>
</tbody>
</table>

## Dataflow permissions

<div results-count-container="">

</div>

<table class="permissions-table fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="45%">Permission</th>
<th>Included in roles</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td><h4 id="dataflow.jobs.cancel" class="permission-name add-link" data-text="dataflow.jobs.cancel" tabindex="-1"><code translate="no" dir="ltr">dataflow.jobs.cancel</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.admin">Dataflow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.developer">Dataflow Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.developer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.serviceAgent">Recommendations AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/retail#retail.serviceAgent">Retail Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/retail.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="dataflow.jobs.create" class="permission-name add-link" data-text="dataflow.jobs.create" tabindex="-1"><code translate="no" dir="ltr">dataflow.jobs.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.admin">Dataflow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.developer">Dataflow Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.developer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.serviceAgent">Recommendations AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/retail#retail.serviceAgent">Retail Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/retail.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="dataflow.jobs.createTagBinding" class="permission-name add-link" data-text="dataflow.jobs.createTagBinding" tabindex="-1"><code translate="no" dir="ltr">dataflow.jobs.createTagBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.admin">Dataflow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.developer">Dataflow Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="dataflow.jobs.deleteTagBinding" class="permission-name add-link" data-text="dataflow.jobs.deleteTagBinding" tabindex="-1"><code translate="no" dir="ltr">dataflow.jobs.deleteTagBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.admin">Dataflow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.developer">Dataflow Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="dataflow.jobs.get" class="permission-name add-link" data-text="dataflow.jobs.get" tabindex="-1"><code translate="no" dir="ltr">dataflow.jobs.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.admin">Dataflow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.viewer">Dataflow Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.developer">Dataflow Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.worker">Dataflow Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.worker</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.serviceAgent">Recommendations AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/retail#retail.serviceAgent">Retail Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/retail.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="dataflow.jobs.list" class="permission-name add-link" data-text="dataflow.jobs.list" tabindex="-1"><code translate="no" dir="ltr">dataflow.jobs.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.admin">Dataflow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.viewer">Dataflow Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.developer">Dataflow Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.serviceAgent">Recommendations AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/retail#retail.serviceAgent">Retail Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/retail.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="dataflow.jobs.listEffectiveTags" class="permission-name add-link" data-text="dataflow.jobs.listEffectiveTags" tabindex="-1"><code translate="no" dir="ltr">dataflow.jobs.listEffectiveTags</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.admin">Dataflow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.viewer">Dataflow Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagViewer">Tag Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.developer">Dataflow Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="dataflow.jobs.listTagBindings" class="permission-name add-link" data-text="dataflow.jobs.listTagBindings" tabindex="-1"><code translate="no" dir="ltr">dataflow.jobs.listTagBindings</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.admin">Dataflow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.viewer">Dataflow Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagViewer">Tag Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.developer">Dataflow Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="dataflow.jobs.snapshot" class="permission-name add-link" data-text="dataflow.jobs.snapshot" tabindex="-1"><code translate="no" dir="ltr">dataflow.jobs.snapshot</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.admin">Dataflow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.developer">Dataflow Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.developer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.serviceAgent">Recommendations AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/retail#retail.serviceAgent">Retail Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/retail.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="dataflow.jobs.updateContents" class="permission-name add-link" data-text="dataflow.jobs.updateContents" tabindex="-1"><code translate="no" dir="ltr">dataflow.jobs.updateContents</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.admin">Dataflow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.developer">Dataflow Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.developer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.serviceAgent">Recommendations AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/retail#retail.serviceAgent">Retail Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/retail.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="dataflow.messages.list" class="permission-name add-link" data-text="dataflow.messages.list" tabindex="-1"><code translate="no" dir="ltr">dataflow.messages.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.admin">Dataflow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.viewer">Dataflow Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.developer">Dataflow Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.serviceAgent">Recommendations AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/retail#retail.serviceAgent">Retail Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/retail.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="dataflow.metrics.get" class="permission-name add-link" data-text="dataflow.metrics.get" tabindex="-1"><code translate="no" dir="ltr">dataflow.metrics.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.admin">Dataflow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.viewer">Dataflow Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.developer">Dataflow Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/automlrecommendations#automlrecommendations.serviceAgent">Recommendations AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/automlrecommendations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/retail#retail.serviceAgent">Retail Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/retail.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="dataflow.shuffle.read" class="permission-name add-link" data-text="dataflow.shuffle.read" tabindex="-1"><code translate="no" dir="ltr">dataflow.shuffle.read</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.admin">Dataflow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.worker">Dataflow Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.worker</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="dataflow.shuffle.write" class="permission-name add-link" data-text="dataflow.shuffle.write" tabindex="-1"><code translate="no" dir="ltr">dataflow.shuffle.write</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.admin">Dataflow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.worker">Dataflow Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.worker</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="dataflow.snapshots.createTagBinding" class="permission-name add-link" data-text="dataflow.snapshots.createTagBinding" tabindex="-1"><code translate="no" dir="ltr">dataflow.snapshots.createTagBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.admin">Dataflow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.developer">Dataflow Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="dataflow.snapshots.delete" class="permission-name add-link" data-text="dataflow.snapshots.delete" tabindex="-1"><code translate="no" dir="ltr">dataflow.snapshots.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.admin">Dataflow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.developer">Dataflow Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.developer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="dataflow.snapshots.deleteTagBinding" class="permission-name add-link" data-text="dataflow.snapshots.deleteTagBinding" tabindex="-1"><code translate="no" dir="ltr">dataflow.snapshots.deleteTagBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.admin">Dataflow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.developer">Dataflow Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="dataflow.snapshots.get" class="permission-name add-link" data-text="dataflow.snapshots.get" tabindex="-1"><code translate="no" dir="ltr">dataflow.snapshots.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.admin">Dataflow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.viewer">Dataflow Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.developer">Dataflow Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="dataflow.snapshots.list" class="permission-name add-link" data-text="dataflow.snapshots.list" tabindex="-1"><code translate="no" dir="ltr">dataflow.snapshots.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.admin">Dataflow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.viewer">Dataflow Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.developer">Dataflow Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="dataflow.snapshots.listEffectiveTags" class="permission-name add-link" data-text="dataflow.snapshots.listEffectiveTags" tabindex="-1"><code translate="no" dir="ltr">dataflow.snapshots.listEffectiveTags</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.admin">Dataflow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.viewer">Dataflow Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagViewer">Tag Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.developer">Dataflow Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="dataflow.snapshots.listTagBindings" class="permission-name add-link" data-text="dataflow.snapshots.listTagBindings" tabindex="-1"><code translate="no" dir="ltr">dataflow.snapshots.listTagBindings</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.admin">Dataflow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.viewer">Dataflow Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagViewer">Tag Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.developer">Dataflow Developer</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.developer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="dataflow.streamingWorkItems.ImportState" class="permission-name add-link" data-text="dataflow.streamingWorkItems.ImportState" tabindex="-1"><code translate="no" dir="ltr">dataflow.streamingWorkItems.ImportState</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.admin">Dataflow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.worker">Dataflow Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.worker</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="dataflow.streamingWorkItems.commitWork" class="permission-name add-link" data-text="dataflow.streamingWorkItems.commitWork" tabindex="-1"><code translate="no" dir="ltr">dataflow.streamingWorkItems.commitWork</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.admin">Dataflow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.worker">Dataflow Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.worker</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="dataflow.streamingWorkItems.getData" class="permission-name add-link" data-text="dataflow.streamingWorkItems.getData" tabindex="-1"><code translate="no" dir="ltr">dataflow.streamingWorkItems.getData</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.admin">Dataflow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.worker">Dataflow Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.worker</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="dataflow.streamingWorkItems.getWork" class="permission-name add-link" data-text="dataflow.streamingWorkItems.getWork" tabindex="-1"><code translate="no" dir="ltr">dataflow.streamingWorkItems.getWork</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.admin">Dataflow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.worker">Dataflow Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.worker</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="dataflow.streamingWorkItems.getWorkerMetadata" class="permission-name add-link" data-text="dataflow.streamingWorkItems.getWorkerMetadata" tabindex="-1"><code translate="no" dir="ltr">dataflow.streamingWorkItems.getWorkerMetadata</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.admin">Dataflow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.worker">Dataflow Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.worker</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="dataflow.workItems.lease" class="permission-name add-link" data-text="dataflow.workItems.lease" tabindex="-1"><code translate="no" dir="ltr">dataflow.workItems.lease</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.admin">Dataflow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.worker">Dataflow Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.worker</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="dataflow.workItems.sendMessage" class="permission-name add-link" data-text="dataflow.workItems.sendMessage" tabindex="-1"><code translate="no" dir="ltr">dataflow.workItems.sendMessage</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.admin">Dataflow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.worker">Dataflow Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.worker</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="dataflow.workItems.update" class="permission-name add-link" data-text="dataflow.workItems.update" tabindex="-1"><code translate="no" dir="ltr">dataflow.workItems.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor (Legacy)</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.admin">Dataflow Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataflow#dataflow.worker">Dataflow Worker</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.worker</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
</ul></td>
</tr>
</tbody>
</table>

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
