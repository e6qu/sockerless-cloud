<div class="devsite-article-meta nocontent" role="navigation" nosnippet="">

- <a href="https://docs.cloud.google.com/" class="devsite-breadcrumb-link gc-analytics-event" data-category="Site-Wide Custom Events" data-label="Breadcrumbs" data-value="1" data-track-type="globalNav" data-track-name="breadcrumb" data-track-metadata-position="1" data-track-metadata-eventdetail="Google Cloud Documentation">Home</a>

- <div class="devsite-breadcrumb-guillemet material-icons" aria-hidden="true">

  </div>

  <a href="https://docs.cloud.google.com/docs" class="devsite-breadcrumb-link gc-analytics-event" data-category="Site-Wide Custom Events" data-label="Breadcrumbs" data-value="2" data-track-type="globalNav" data-track-name="breadcrumb" data-track-metadata-position="2" data-track-metadata-eventdetail="Documentation">Documentation</a>

- <div class="devsite-breadcrumb-guillemet material-icons" aria-hidden="true">

  </div>

  <a href="https://docs.cloud.google.com/docs/databases" class="devsite-breadcrumb-link gc-analytics-event" data-category="Site-Wide Custom Events" data-label="Breadcrumbs" data-value="3" data-track-type="globalNav" data-track-name="breadcrumb" data-track-metadata-position="3" data-track-metadata-eventdetail="Databases">Databases</a>

- <div class="devsite-breadcrumb-guillemet material-icons" aria-hidden="true">

  </div>

  <a href="https://docs.cloud.google.com/sql/docs" class="devsite-breadcrumb-link gc-analytics-event" data-category="Site-Wide Custom Events" data-label="Breadcrumbs" data-value="4" data-track-type="globalNav" data-track-name="breadcrumb" data-track-metadata-position="4" data-track-metadata-eventdetail="Cloud SQL">Cloud SQL</a>

- <div class="devsite-breadcrumb-guillemet material-icons" aria-hidden="true">

  </div>

  <a href="https://docs.cloud.google.com/sql/docs/mysql" class="devsite-breadcrumb-link gc-analytics-event" data-category="Site-Wide Custom Events" data-label="Breadcrumbs" data-value="5" data-track-type="globalNav" data-track-name="breadcrumb" data-track-metadata-position="5" data-track-metadata-eventdetail="Cloud SQL for MySQL">MySQL</a>

- <div class="devsite-breadcrumb-guillemet material-icons" aria-hidden="true">

  </div>

  <a href="https://docs.cloud.google.com/sql/docs/mysql/features" class="devsite-breadcrumb-link gc-analytics-event" data-category="Site-Wide Custom Events" data-label="Breadcrumbs" data-value="6" data-track-type="globalNav" data-track-name="breadcrumb" data-track-metadata-position="6" data-track-metadata-eventdetail="">Guides</a>

</div>

Send feedback

# Cloud SQL for MySQL audit logging <span slot="popout-heading"> Stay organized with collections </span> <span slot="popout-contents"> Save and categorize content based on your preferences. </span>

<div class="devsite-article-body clearfix">

<div class="nocontent" style="font-size:medium; margin-bottom:40px; border-top:1px solid black;">

<div style="float:right">

<span style="font-weight:bold">MySQL</span> <span style="color:light-gray">  \|  </span><a href="/sql/docs/postgres/audit-logging" data-track-type="sqlSwitcher" data-track-name="postgresLink" title="View this page for the PostgreSQL database engine">PostgreSQL</a> <span style="color:light-gray">  \|  </span><a href="/sql/docs/sqlserver/audit-logging" data-track-type="sqlSwitcher" data-track-name="sqlServerLink" title="View this page for the SQL Server database engine">SQL Server</a>

</div>

</div>

This document lists the audited methods for Cloud SQL. Google Cloud services generate audit logs that record administrative and access activities within your Google Cloud resources. For more information about Cloud Audit Logs, see the following:

- [Types of audit logs](/logging/docs/audit#types)
- [Audit log entry structure](/logging/docs/audit#audit_log_entry_structure)
- [Storing and routing audit logs](/logging/docs/audit#storing_and_routing_audit_logs)
- [Cloud Logging pricing summary](/stackdriver/pricing#logs-pricing-summary)
- [Enable Data Access audit logs](/logging/docs/audit/configure-data-access)

## Service name

To view the Cloud SQL audit logs, do the following:

1.  In the Google Cloud console, go to the Logs Explorer page:

    <a href="https://console.cloud.google.com/logs/query" class="button button-primary" target="console" data-track-name="consoleLink" data-track-type="reference" data-track-metadata-position="body">Go to Logs Explorer</a>

2.  Copy and paste the following query into the **Query** field of the Logs Explorer, and then click **Run query**.

    <div>

    </div>

    ``` devsite-click-to-copy
        protoPayload.serviceName="cloudsql.googleapis.com"
      
    ```

## Methods by permission type

Each IAM permission has a `type` property, whose value is an enum that can be one of four values: `ADMIN_READ`, `ADMIN_WRITE`, `DATA_READ`, or `DATA_WRITE`. When you call a method, Cloud SQL generates an audit log whose category is dependent on the `type` property of the permission required to perform the method. Methods that require an IAM permission with the `type` property value of `DATA_READ`, `DATA_WRITE`, or `ADMIN_READ` generate [Data Access](/logging/docs/audit#data-access) audit logs. Methods that require an IAM permission with the `type` property value of `ADMIN_WRITE` generate [Admin Activity](/logging/docs/audit#admin-activity) audit logs.

API methods in the following list that are marked with (LRO) are long-running operations (LROs). These methods usually generate two audit log entries: one when the operation starts and another when it ends. For more information see [Audit logs for long-running operations](/logging/docs/audit/understanding-audit-logs#lro).

<table class="fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="15%">Permission type</th>
<th>Methods</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td><code translate="no" dir="ltr">ADMIN_READ</code></td>
<td><code translate="no" dir="ltr">cloudsql.backupRuns.get</code><br />
<code translate="no" dir="ltr">cloudsql.backupRuns.list</code><br />
<code translate="no" dir="ltr">cloudsql.backups.list</code><br />
<code translate="no" dir="ltr">cloudsql.instances.get</code> (LRO)<br />
<code translate="no" dir="ltr">cloudsql.instances.list</code><br />
<code translate="no" dir="ltr">cloudsql.instances.listServerCas</code><br />
<code translate="no" dir="ltr">cloudsql.operations.get</code><br />
<code translate="no" dir="ltr">cloudsql.operations.list</code><br />
<code translate="no" dir="ltr">cloudsql.sslCerts.get</code><br />
<code translate="no" dir="ltr">cloudsql.sslCerts.list</code></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">ADMIN_WRITE</code></td>
<td><code translate="no" dir="ltr">cloudsql.backupRuns.create</code> (LRO)<br />
<code translate="no" dir="ltr">cloudsql.backupRuns.delete</code> (LRO)<br />
<code translate="no" dir="ltr">cloudsql.backups.create</code> (LRO)<br />
<code translate="no" dir="ltr">cloudsql.backups.delete</code> (LRO)<br />
<code translate="no" dir="ltr">cloudsql.backups.update</code> (LRO)<br />
<code translate="no" dir="ltr">cloudsql.instances.addServerCa</code> (LRO)<br />
<code translate="no" dir="ltr">cloudsql.instances.clone</code> (LRO)<br />
<code translate="no" dir="ltr">cloudsql.instances.connect</code><br />
<code translate="no" dir="ltr">cloudsql.instances.create</code> (LRO)<br />
<code translate="no" dir="ltr">cloudsql.instances.delete</code> (LRO)<br />
<code translate="no" dir="ltr">cloudsql.instances.demoteMaster</code> (LRO)<br />
<code translate="no" dir="ltr">cloudsql.instances.failover</code> (LRO)<br />
<code translate="no" dir="ltr">cloudsql.instances.migrate</code> (LRO)<br />
<code translate="no" dir="ltr">cloudsql.instances.promoteReplica</code> (LRO)<br />
<code translate="no" dir="ltr">cloudsql.instances.reencrypt</code> (LRO)<br />
<code translate="no" dir="ltr">cloudsql.instances.resetSslConfig</code> (LRO)<br />
<code translate="no" dir="ltr">cloudsql.instances.restart</code> (LRO)<br />
<code translate="no" dir="ltr">cloudsql.instances.restoreBackup</code> (LRO)<br />
<code translate="no" dir="ltr">cloudsql.instances.rotateServerCa</code> (LRO)<br />
<code translate="no" dir="ltr">cloudsql.instances.startReplica</code> (LRO)<br />
<code translate="no" dir="ltr">cloudsql.instances.stopReplica</code> (LRO)<br />
<code translate="no" dir="ltr">cloudsql.instances.truncateLog</code> (LRO)<br />
<code translate="no" dir="ltr">cloudsql.instances.update</code> (LRO)<br />
<code translate="no" dir="ltr">cloudsql.sslCerts.create</code> (LRO)<br />
<code translate="no" dir="ltr">cloudsql.sslCerts.delete</code> (LRO)</td>
</tr>
<tr class="odd">
<td><code translate="no" dir="ltr">DATA_READ</code></td>
<td><code translate="no" dir="ltr">cloudsql.databases.get</code><br />
<code translate="no" dir="ltr">cloudsql.databases.list</code><br />
<code translate="no" dir="ltr">cloudsql.instances.export</code> (LRO)<br />
<code translate="no" dir="ltr">cloudsql.users.get</code><br />
<code translate="no" dir="ltr">cloudsql.users.list</code></td>
</tr>
<tr class="even">
<td><code translate="no" dir="ltr">DATA_WRITE</code></td>
<td><code translate="no" dir="ltr">cloudsql.databases.create</code> (LRO)<br />
<code translate="no" dir="ltr">cloudsql.databases.delete</code> (LRO)<br />
<code translate="no" dir="ltr">cloudsql.databases.update</code> (LRO)<br />
<code translate="no" dir="ltr">cloudsql.instances.executeSql</code> (LRO)<br />
<code translate="no" dir="ltr">cloudsql.instances.import</code> (LRO)<br />
<code translate="no" dir="ltr">cloudsql.instances.login</code><br />
<code translate="no" dir="ltr">cloudsql.users.create</code> (LRO)<br />
<code translate="no" dir="ltr">cloudsql.users.delete</code> (LRO)<br />
<code translate="no" dir="ltr">cloudsql.users.update</code> (LRO)</td>
</tr>
</tbody>
</table>

## API interface audit logs

For information about how and which permissions are evaluated for each method, see the Identity and Access Management documentation for Cloud SQL.

### `cloudsql.backupRuns`

The following audit logs are associated with methods belonging to `cloudsql.backupRuns`.

#### `create`

- **Method**: `cloudsql.backupRuns.create`  
- **Audit log type**: [Admin activity](/logging/docs/audit#admin-activity)  
- **Permissions**:
  - `cloudsql.backupRuns.create - ADMIN_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="cloudsql.backupRuns.create" `  

#### `delete`

- **Method**: `cloudsql.backupRuns.delete`  
- **Audit log type**: [Admin activity](/logging/docs/audit#admin-activity)  
- **Permissions**:
  - `cloudsql.backupRuns.delete - ADMIN_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="cloudsql.backupRuns.delete" `  

#### `get`

- **Method**: `cloudsql.backupRuns.get`  
- **Audit log type**: [Data access](/logging/docs/audit#data-access)  
- **Permissions**:
  - `cloudsql.backupRuns.get - ADMIN_READ`
- **Method is a long-running or streaming operation**: No.  
- **Filter for this method**: ` protoPayload.methodName="cloudsql.backupRuns.get" `  

#### `list`

- **Method**: `cloudsql.backupRuns.list`  
- **Audit log type**: [Data access](/logging/docs/audit#data-access)  
- **Permissions**:
  - `cloudsql.backupRuns.list - ADMIN_READ`
- **Method is a long-running or streaming operation**: No.  
- **Filter for this method**: ` protoPayload.methodName="cloudsql.backupRuns.list" `  

### `cloudsql.backups`

The following audit logs are associated with methods belonging to `cloudsql.backups`.

#### `create`

- **Method**: `cloudsql.backups.create`  
- **Audit log type**: [Admin activity](/logging/docs/audit#admin-activity)  
- **Permissions**:
  - `cloudsql.backupRuns.create - ADMIN_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="cloudsql.backups.create" `  

#### `delete`

- **Method**: `cloudsql.backups.delete`  
- **Audit log type**: [Admin activity](/logging/docs/audit#admin-activity)  
- **Permissions**:
  - `cloudsql.backupRuns.delete - ADMIN_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="cloudsql.backups.delete" `  

#### `list`

- **Method**: `cloudsql.backups.list`  
- **Audit log type**: [Data access](/logging/docs/audit#data-access)  
- **Permissions**:
  - `cloudsql.backupRuns.list - ADMIN_READ`
  - `cloudsql.instances.list - ADMIN_READ`
- **Method is a long-running or streaming operation**: No.  
- **Filter for this method**: ` protoPayload.methodName="cloudsql.backups.list" `  

#### `update`

- **Method**: `cloudsql.backups.update`  
- **Audit log type**: [Admin activity](/logging/docs/audit#admin-activity)  
- **Permissions**:
  - `cloudsql.backupRuns.update - ADMIN_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="cloudsql.backups.update" `  

### `cloudsql.databases`

The following audit logs are associated with methods belonging to `cloudsql.databases`.

#### `create`

- **Method**: `cloudsql.databases.create`  
- **Audit log type**: [Data access](/logging/docs/audit#data-access)  
- **Permissions**:
  - `cloudsql.databases.create - DATA_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="cloudsql.databases.create" `  

#### `delete`

- **Method**: `cloudsql.databases.delete`  
- **Audit log type**: [Data access](/logging/docs/audit#data-access)  
- **Permissions**:
  - `cloudsql.databases.delete - DATA_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="cloudsql.databases.delete" `  

#### `get`

- **Method**: `cloudsql.databases.get`  
- **Audit log type**: [Data access](/logging/docs/audit#data-access)  
- **Permissions**:
  - `cloudsql.databases.get - DATA_READ`
- **Method is a long-running or streaming operation**: No.  
- **Filter for this method**: ` protoPayload.methodName="cloudsql.databases.get" `  

#### `list`

- **Method**: `cloudsql.databases.list`  
- **Audit log type**: [Data access](/logging/docs/audit#data-access)  
- **Permissions**:
  - `cloudsql.databases.list - DATA_READ`
- **Method is a long-running or streaming operation**: No.  
- **Filter for this method**: ` protoPayload.methodName="cloudsql.databases.list" `  

#### `update`

- **Method**: `cloudsql.databases.update`  
- **Audit log type**: [Data access](/logging/docs/audit#data-access)  
- **Permissions**:
  - `cloudsql.databases.update - DATA_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="cloudsql.databases.update" `  

### `cloudsql.instances`

The following audit logs are associated with methods belonging to `cloudsql.instances`.

#### `addServerCa`

- **Method**: `cloudsql.instances.addServerCa`  
- **Audit log type**: [Admin activity](/logging/docs/audit#admin-activity)  
- **Permissions**:
  - `cloudsql.instances.addServerCa - ADMIN_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="cloudsql.instances.addServerCa" `  

#### `clone`

- **Method**: `cloudsql.instances.clone`  
- **Audit log type**: [Admin activity](/logging/docs/audit#admin-activity)  
- **Permissions**:
  - `cloudsql.instances.clone - ADMIN_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="cloudsql.instances.clone" `  

#### `connect`

- **Method**: `cloudsql.instances.connect`  
- **Audit log type**: [Admin activity](/logging/docs/audit#admin-activity)  
- **Permissions**:
  - `cloudsql.instances.connect - ADMIN_WRITE`
- **Method is a long-running or streaming operation**: No.  
- **Filter for this method**: ` protoPayload.methodName="cloudsql.instances.connect" `  

#### `create`

- **Method**: `cloudsql.instances.create`  
- **Audit log type**: [Admin activity](/logging/docs/audit#admin-activity)  
- **Permissions**:
  - `cloudsql.instances.create - ADMIN_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="cloudsql.instances.create" `  

#### `delete`

- **Method**: `cloudsql.instances.delete`  
- **Audit log type**: [Admin activity](/logging/docs/audit#admin-activity)  
- **Permissions**:
  - `cloudsql.instances.delete - ADMIN_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="cloudsql.instances.delete" `  

#### `demoteMaster`

- **Method**: `cloudsql.instances.demoteMaster`  
- **Audit log type**: [Admin activity](/logging/docs/audit#admin-activity)  
- **Permissions**:
  - `cloudsql.instances.demoteMaster - ADMIN_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="cloudsql.instances.demoteMaster" `  

#### `executeSql`

- **Method**: `cloudsql.instances.executeSql`  
- **Audit log type**: [Data access](/logging/docs/audit#data-access)  
- **Permissions**:
  - `cloudsql.instances.executeSql - DATA_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="cloudsql.instances.executeSql" `  

#### `export`

- **Method**: `cloudsql.instances.export`  
- **Audit log type**: [Data access](/logging/docs/audit#data-access)  
- **Permissions**:
  - `cloudsql.instances.export - DATA_READ`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="cloudsql.instances.export" `  

#### `failover`

- **Method**: `cloudsql.instances.failover`  
- **Audit log type**: [Admin activity](/logging/docs/audit#admin-activity)  
- **Permissions**:
  - `cloudsql.instances.failover - ADMIN_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="cloudsql.instances.failover" `  

#### `get`

- **Method**: `cloudsql.instances.get`  
- **Audit log type**: [Data access](/logging/docs/audit#data-access)  
- **Permissions**:
  - `cloudsql.instances.get - ADMIN_READ`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="cloudsql.instances.get" `  

#### `import`

- **Method**: `cloudsql.instances.import`  
- **Audit log type**: [Data access](/logging/docs/audit#data-access)  
- **Permissions**:
  - `cloudsql.instances.import - DATA_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="cloudsql.instances.import" `  

#### `list`

- **Method**: `cloudsql.instances.list`  
- **Audit log type**: [Data access](/logging/docs/audit#data-access)  
- **Permissions**:
  - `cloudsql.instances.list - ADMIN_READ`
- **Method is a long-running or streaming operation**: No.  
- **Filter for this method**: ` protoPayload.methodName="cloudsql.instances.list" `  

#### `listServerCas`

- **Method**: `cloudsql.instances.listServerCas`  
- **Audit log type**: [Data access](/logging/docs/audit#data-access)  
- **Permissions**:
  - `cloudsql.instances.listServerCas - ADMIN_READ`
- **Method is a long-running or streaming operation**: No.  
- **Filter for this method**: ` protoPayload.methodName="cloudsql.instances.listServerCas" `  

#### `login`

- **Method**: `cloudsql.instances.login`  
- **Audit log type**: [Data access](/logging/docs/audit#data-access)  
- **Permissions**:
  - `cloudsql.instances.login - DATA_WRITE`
- **Method is a long-running or streaming operation**: No.  
- **Filter for this method**: ` protoPayload.methodName="cloudsql.instances.login" `  

#### `migrate`

- **Method**: `cloudsql.instances.migrate`  
- **Audit log type**: [Admin activity](/logging/docs/audit#admin-activity)  
- **Permissions**:
  - `cloudsql.instances.migrate - ADMIN_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="cloudsql.instances.migrate" `  

#### `promoteReplica`

- **Method**: `cloudsql.instances.promoteReplica`  
- **Audit log type**: [Admin activity](/logging/docs/audit#admin-activity)  
- **Permissions**:
  - `cloudsql.instances.promoteReplica - ADMIN_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="cloudsql.instances.promoteReplica" `  

#### `query`

- **Method**: `cloudsql.instances.query`  
- **Audit log type**: [Data access](/logging/docs/audit#data-access)  
- **Permissions**:
- **Method is a long-running or streaming operation**: No.  
- **Filter for this method**: ` protoPayload.methodName="cloudsql.instances.query" `  

#### `reencrypt`

- **Method**: `cloudsql.instances.reencrypt`  
- **Audit log type**: [Admin activity](/logging/docs/audit#admin-activity)  
- **Permissions**:
  - `cloudsql.instances.reencrypt - ADMIN_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="cloudsql.instances.reencrypt" `  

#### `resetSslConfig`

- **Method**: `cloudsql.instances.resetSslConfig`  
- **Audit log type**: [Admin activity](/logging/docs/audit#admin-activity)  
- **Permissions**:
  - `cloudsql.instances.resetSslConfig - ADMIN_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="cloudsql.instances.resetSslConfig" `  

#### `restart`

- **Method**: `cloudsql.instances.restart`  
- **Audit log type**: [Admin activity](/logging/docs/audit#admin-activity)  
- **Permissions**:
  - `cloudsql.instances.restart - ADMIN_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="cloudsql.instances.restart" `  

#### `restoreBackup`

- **Method**: `cloudsql.instances.restoreBackup`  
- **Audit log type**: [Admin activity](/logging/docs/audit#admin-activity)  
- **Permissions**:
  - `cloudsql.instances.restoreBackup - ADMIN_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="cloudsql.instances.restoreBackup" `  

#### `rotateServerCa`

- **Method**: `cloudsql.instances.rotateServerCa`  
- **Audit log type**: [Admin activity](/logging/docs/audit#admin-activity)  
- **Permissions**:
  - `cloudsql.instances.rotateServerCa - ADMIN_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="cloudsql.instances.rotateServerCa" `  

#### `startReplica`

- **Method**: `cloudsql.instances.startReplica`  
- **Audit log type**: [Admin activity](/logging/docs/audit#admin-activity)  
- **Permissions**:
  - `cloudsql.instances.startReplica - ADMIN_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="cloudsql.instances.startReplica" `  

#### `stopReplica`

- **Method**: `cloudsql.instances.stopReplica`  
- **Audit log type**: [Admin activity](/logging/docs/audit#admin-activity)  
- **Permissions**:
  - `cloudsql.instances.stopReplica - ADMIN_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="cloudsql.instances.stopReplica" `  

#### `truncateLog`

- **Method**: `cloudsql.instances.truncateLog`  
- **Audit log type**: [Admin activity](/logging/docs/audit#admin-activity)  
- **Permissions**:
  - `cloudsql.instances.truncateLog - ADMIN_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="cloudsql.instances.truncateLog" `  

#### `update`

- **Method**: `cloudsql.instances.update`  
- **Audit log type**: [Admin activity](/logging/docs/audit#admin-activity)  
- **Permissions**:
  - `cloudsql.instances.update - ADMIN_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="cloudsql.instances.update" `  

### `cloudsql.operations`

The following audit logs are associated with methods belonging to `cloudsql.operations`.

#### `get`

- **Method**: `cloudsql.operations.get`  
- **Audit log type**: [Data access](/logging/docs/audit#data-access)  
- **Permissions**:
  - `cloudsql.instances.get - ADMIN_READ`
- **Method is a long-running or streaming operation**: No.  
- **Filter for this method**: ` protoPayload.methodName="cloudsql.operations.get" `  

#### `list`

- **Method**: `cloudsql.operations.list`  
- **Audit log type**: [Data access](/logging/docs/audit#data-access)  
- **Permissions**:
  - `cloudsql.instances.get - ADMIN_READ`
- **Method is a long-running or streaming operation**: No.  
- **Filter for this method**: ` protoPayload.methodName="cloudsql.operations.list" `  

### `cloudsql.sslCerts`

The following audit logs are associated with methods belonging to `cloudsql.sslCerts`.

#### `create`

- **Method**: `cloudsql.sslCerts.create`  
- **Audit log type**: [Admin activity](/logging/docs/audit#admin-activity)  
- **Permissions**:
  - `cloudsql.sslCerts.create - ADMIN_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="cloudsql.sslCerts.create" `  

#### `delete`

- **Method**: `cloudsql.sslCerts.delete`  
- **Audit log type**: [Admin activity](/logging/docs/audit#admin-activity)  
- **Permissions**:
  - `cloudsql.sslCerts.delete - ADMIN_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="cloudsql.sslCerts.delete" `  

#### `get`

- **Method**: `cloudsql.sslCerts.get`  
- **Audit log type**: [Data access](/logging/docs/audit#data-access)  
- **Permissions**:
  - `cloudsql.sslCerts.get - ADMIN_READ`
- **Method is a long-running or streaming operation**: No.  
- **Filter for this method**: ` protoPayload.methodName="cloudsql.sslCerts.get" `  

#### `list`

- **Method**: `cloudsql.sslCerts.list`  
- **Audit log type**: [Data access](/logging/docs/audit#data-access)  
- **Permissions**:
  - `cloudsql.sslCerts.list - ADMIN_READ`
- **Method is a long-running or streaming operation**: No.  
- **Filter for this method**: ` protoPayload.methodName="cloudsql.sslCerts.list" `  

### `cloudsql.users`

The following audit logs are associated with methods belonging to `cloudsql.users`.

#### `create`

- **Method**: `cloudsql.users.create`  
- **Audit log type**: [Data access](/logging/docs/audit#data-access)  
- **Permissions**:
  - `cloudsql.users.create - DATA_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="cloudsql.users.create" `  

#### `delete`

- **Method**: `cloudsql.users.delete`  
- **Audit log type**: [Data access](/logging/docs/audit#data-access)  
- **Permissions**:
  - `cloudsql.users.delete - DATA_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="cloudsql.users.delete" `  

#### `get`

- **Method**: `cloudsql.users.get`  
- **Audit log type**: [Data access](/logging/docs/audit#data-access)  
- **Permissions**:
  - `cloudsql.users.get - DATA_READ`
- **Method is a long-running or streaming operation**: No.  
- **Filter for this method**: ` protoPayload.methodName="cloudsql.users.get" `  

#### `list`

- **Method**: `cloudsql.users.list`  
- **Audit log type**: [Data access](/logging/docs/audit#data-access)  
- **Permissions**:
  - `cloudsql.users.list - DATA_READ`
- **Method is a long-running or streaming operation**: No.  
- **Filter for this method**: ` protoPayload.methodName="cloudsql.users.list" `  

#### `update`

- **Method**: `cloudsql.users.update`  
- **Audit log type**: [Data access](/logging/docs/audit#data-access)  
- **Permissions**:
  - `cloudsql.users.update - DATA_WRITE`
- **Method is a long-running or streaming operation**: [**Long-running operation**](/logging/docs/audit/understanding-audit-logs#lro)  
- **Filter for this method**: ` protoPayload.methodName="cloudsql.users.update" `  

## System events

System Event audit logs are generated by GCP systems, not direct user action. For more information, see [System Event audit logs](/logging/docs/audit#system-event).

| Method Name                                 | Filter For This Event                                                     | Notes |
|---------------------------------------------|---------------------------------------------------------------------------|-------|
| cloudsql.instances.autoFailover             | ` protoPayload.methodName="cloudsql.instances.autoFailover" `             |       |
| cloudsql.instances.automatedBackup          | ` protoPayload.methodName="cloudsql.instances.automatedBackup" `          |       |
| cloudsql.instances.automaticStorageIncrease | ` protoPayload.methodName="cloudsql.instances.automaticStorageIncrease" ` |       |
| cloudsql.instances.readPoolAutoScale        | ` protoPayload.methodName="cloudsql.instances.readPoolAutoScale" `        |       |

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
