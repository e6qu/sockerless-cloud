# Encapsulate and decapsulate using KEMs

<div class="devsite-article-body clearfix">

This document describes using key encapsulation mechanisms (KEMs) with Cloud KMS keys to establish shared secrets.

Encapsulation uses the public key of the KEM key pair, and decapsulation uses the private key of the key pair. Cloud KMS lets you retrieve the public key, which you can then use with standard libraries to encapsulate your shared secret. To decapsulate the shared secret, use Cloud KMS decapsulation methods. You can't use the private key material outside of Cloud KMS.

## Before you begin

- This document provides examples that run at the command line. To simplify using the examples, use [Cloud Shell](/shell). The encryption example uses [OpenSSL](https://www.openssl.org/), which is pre-installed on Cloud Shell. Otherwise, install OpenSSL on your machine.
- [Create a KEM key](/kms/docs/creating-asymmetric-keys) with [key purpose](/kms/docs/algorithms#key_purposes) of `KEY_ENCAPSULATION`. To see which algorithms are supported for key purpose `KEY_ENCAPSULATION`, see [key encapsulation algorithms](/kms/docs/algorithms#key_encapsulation_algorithms).

## Grant permissions on the key

- Grant the [`roles/cloudkms.publicKeyViewer`](/iam/docs/roles-permissions/cloudkms#cloudkms.publicKeyViewer) role on the key to each user or principal that must retrieve the public key to encapsulate the secret.
- Grant the ['roles/cloudkms.decapsulator'](/iam/docs/roles-permissions/cloudkms#cloudkms.decapsulator) role on the key to each user or principal that must decapsulate secrets with this key.

For more information about permissions and roles in Cloud KMS, see [Permissions and Roles](/kms/docs/reference/permissions-and-roles).

## Encapsulation

To encapsulate using a KEM key, retrieve the public key and use the public key to encapsulate.

<div id="kms-encapsulation-code-sample" class="ds-selector-tabs" ds-scope="code-sample">

<div class="section">

### <span class="notranslate">gcloud</span>

This sample requires [OpenSSL](https://www.openssl.org) to be installed on your local system.

### Download the public key

<div>

</div>

``` devsite-click-to-copy
gcloud kms keys versions get-public-key KEY_VERSION \
    --key KEY_NAME \
    --keyring KEY_RING \
    --location LOCATION  \
    --output-file PUBLIC_KEY_FILE \
    --public-key-format PUBLIC_KEY_FORMAT
```

Replace the following:

- `KEY_VERSION`: The version number of the key that you want to use for encapsulation—for example, `2`.
- `KEY_NAME`: The name of the key that you want to use for encapsulation.
- `KEY_RING`: the name of the key ring that contains the key.
- `LOCATION`: the Cloud KMS location of the key ring.
- `PUBLIC_KEY_FILE`: The local file path where the public key will be saved.
- `PUBLIC_KEY_FORMAT`: The target format for the public key—for example, `nist-pqc`. The default format is `pem`.

### Reformat the public key

The encapsulate command requires the public key to be in PEM format. If you have downloaded the public key in another format, like `nist-pqc`, then you must convert the key to PEM format. If your public key is already in the PEM format, continue from [Encapsulate](#encapsulate).

Use the following command to convert the public key for a `ML-KEM-768` key:

<div>

</div>

``` devsite-click-to-copy
{ echo -n "MIIEsjALBglghkgBZQMEBAIDggShAA==" | base64 -d ; cat PUBLIC_KEY_FILE; } | \
openssl pkey -inform DER -pubin -pubout -out PEM_PUBLIC_KEY_FILE
```

Use the following command to convert the public key for a `ML-KEM-1024` key:

<div>

</div>

``` devsite-click-to-copy
{ echo -n "MIIGMjALBglghkgBZQMEBAMDggYhAA==" | base64 -d ; cat PUBLIC_KEY_FILE; } | \
openssl pkey -inform DER -pubin -pubout -out PEM_PUBLIC_KEY_FILE
```

Replace the following:

- `PUBLIC_KEY_FILE`: The path to the downloaded public key file in raw format.
- `PEM_PUBLIC_KEY_FILE`: The path and file name to save the public key in PEM format.

### Encapsulate

To create a shared secret and ciphertext, you can use the following command:

<div>

</div>

``` devsite-click-to-copy
openssl pkeyutl \
    -encap \
    -pubin \
    -inkey PEM_PUBLIC_KEY_FILE \
    -out CIPHERTEXT_FILE \
    -secret SHARED_SECRET_FILE
```

Replace the following:

- `PEM_PUBLIC_KEY_FILE`: The path to the downloaded public key file in PEM format.
- `CIPHERTEXT_FILE`: The path where you want to save the resulting ciphertext.
- `SHARED_SECRET_FILE`: The path where you want to save the resulting shared secret.

</div>

<div class="section">

### <span class="notranslate">Go</span>

To run this code, first [set up a Go development environment](/go/docs/setup) and [install the Cloud KMS Go SDK](/kms/docs/reference/libraries#client-libraries-install-go).

<div class="github-docwidget-gitinclude-code">

<div>

</div>

``` devsite-click-to-copy
import (
 "context"
 "crypto/mlkem"
 "fmt"
 "hash/crc32"
 "io"

 kms "cloud.google.com/go/kms/apiv1"
 "cloud.google.com/go/kms/apiv1/kmspb"
)

// encapsulateMLKEM demonstrates how to encapsulate a shared secret using an ML-KEM-768 public key
// from Cloud KMS.
func encapsulateMLKEM(w io.Writer, keyVersionName string) error {
 // keyVersionName := "projects/my-project/locations/us-east1/keyRings/my-key-ring/cryptoKeys/my-key/cryptoKeyVersions/1"

 // Create the client.
 ctx := context.Background()
 client, err := kms.NewKeyManagementClient(ctx)
 if err != nil {
     return fmt.Errorf("failed to create kms client: %w", err)
 }
 defer client.Close()

 // crc32c calculates the CRC32C checksum of the given data.
 crc32c := func(data []byte) uint32 {
     t := crc32.MakeTable(crc32.Castagnoli)
     return crc32.Checksum(data, t)
 }

 // Build the request to get the public key in NIST PQC format.
 req := &kmspb.GetPublicKeyRequest{
     Name:            keyVersionName,
     PublicKeyFormat: kmspb.PublicKey_NIST_PQC,
 }

 // Call the API to get the public key.
 response, err := client.GetPublicKey(ctx, req)
 if err != nil {
     return fmt.Errorf("failed to get public key: %w", err)
 }

 // Optional, but recommended: perform integrity verification on the response.
 // For more details on ensuring E2E in-transit integrity to and from Cloud KMS visit:
 // https://cloud.google.com/kms/docs/data-integrity-guidelines
 if response.GetName() != req.GetName() {
     return fmt.Errorf("GetPublicKey: request corrupted in-transit")
 }
 if response.GetPublicKeyFormat() != req.GetPublicKeyFormat() {
     return fmt.Errorf("GetPublicKey: request corrupted in-transit")
 }
 if int64(crc32c(response.GetPublicKey().GetData())) != response.GetPublicKey().GetCrc32CChecksum().GetValue() {
     return fmt.Errorf("GetPublicKey: response corrupted in-transit")
 }

 // Use the public key with crypto/mlkem to encapsulate a shared secret.
 ek, err := mlkem.NewEncapsulationKey768(response.GetPublicKey().GetData())
 if err != nil {
     return fmt.Errorf("NewEncapsulationKey768: %w", err)
 }
 sharedSecret, ciphertext := ek.Encapsulate()

 fmt.Fprintf(w, "Encapsulated ciphertext: %x\n", ciphertext)
 fmt.Fprintf(w, "Shared secret: %x\n", sharedSecret)
 return nil
}
```

</div>

</div>

</div>

## Decapsulation

Use Cloud KMS to decapsulate a ciphertext.

<div id="kms-decapsulate-code-sample" class="ds-selector-tabs" ds-scope="code-sample">

<div class="section">

### <span class="notranslate">gcloud</span>

To use Cloud KMS on the command line, first [Install or upgrade to the latest version of Google Cloud CLI](/sdk/install).

<div>

</div>

``` devsite-click-to-copy
gcloud kms decapsulate \
    --version KEY_VERSION \
    --key KEY_NAME \
    --keyring KEY_RING \
    --location LOCATION  \
    --ciphertext-file CIPHERTEXT_FILE \
    --shared-secret-file SHARED_SECRET_FILE
```

Replace the following:

- `KEY_VERSION`: the key version to use for decapsulation—for example, `3`.
- `KEY_NAME`: the name of the key to use for decapsulation.
- `KEY_RING`: the name of the key ring where the key is located.
- `LOCATION`: the Cloud KMS location for the key ring.
- `CIPHERTEXT_FILE`: the local file path for the input ciphertext.
- `SHARED_SECRET_FILE`: the local file path for saving the output shared secret.

</div>

<div class="section">

### <span class="notranslate">Go</span>

To run this code, first [set up a Go development environment](/go/docs/setup) and [install the Cloud KMS Go SDK](/kms/docs/reference/libraries#client-libraries-install-go).

<div class="github-docwidget-gitinclude-code">

<div>

</div>

``` devsite-click-to-copy
import (
 "context"
 "fmt"
 "hash/crc32"
 "io"

 kms "cloud.google.com/go/kms/apiv1"
 "cloud.google.com/go/kms/apiv1/kmspb"
 "google.golang.org/protobuf/types/known/wrapperspb"
)

// decapsulate decapsulates the given ciphertext using a saved private key of purpose
// KEY_ENCAPSULATION stored in KMS.
func decapsulate(w io.Writer, keyVersionName string, ciphertext []byte) error {
 // keyVersionName := "projects/my-project/locations/us-east1/keyRings/my-key-ring/cryptoKeys/my-key/cryptoKeyVersions/1"
 // ciphertext := []byte("...")

 // Create the client.
 ctx := context.Background()
 client, err := kms.NewKeyManagementClient(ctx)
 if err != nil {
     return fmt.Errorf("failed to create kms client: %w", err)
 }
 defer client.Close()

 // crc32c calculates the CRC32C checksum of the given data.
 crc32c := func(data []byte) uint32 {
     t := crc32.MakeTable(crc32.Castagnoli)
     return crc32.Checksum(data, t)
 }

 // Optional but recommended: Compute ciphertext's CRC32C.
 ciphertextCRC32C := crc32c(ciphertext)

 // Build the request.
 req := &kmspb.DecapsulateRequest{
     Name:             keyVersionName,
     Ciphertext:       ciphertext,
     CiphertextCrc32C: wrapperspb.Int64(int64(ciphertextCRC32C)),
 }

 // Call the API.
 result, err := client.Decapsulate(ctx, req)
 if err != nil {
     return fmt.Errorf("failed to decapsulate: %w", err)
 }

 // Optional, but recommended: perform integrity verification on the response.
 // For more details on ensuring E2E in-transit integrity to and from Cloud KMS visit:
 // https://cloud.google.com/kms/docs/data-integrity-guidelines
 if !result.GetVerifiedCiphertextCrc32C() {
     return fmt.Errorf("Decapsulate: request corrupted in-transit")
 }
 if result.GetName() != req.GetName() {
     return fmt.Errorf("Decapsulate: request corrupted in-transit")
 }
 if int64(crc32c(result.GetSharedSecret())) != result.GetSharedSecretCrc32C() {
     return fmt.Errorf("Decapsulate: response corrupted in-transit")
 }

 fmt.Fprintf(w, "Decapsulated plaintext: %x", result.GetSharedSecret())
 return nil
}
```

</div>

</div>

<div class="section">

### API

These examples use <a href="https://curl.haxx.se/" class="external">curl</a> as an HTTP client to demonstrate using the API. For more information about access control, see [Accessing the Cloud KMS API](/kms/docs/accessing-the-api).

Use the [`CryptoKeyVersions.decapsulate`](/kms/docs/reference/rest/v1/projects.locations.keyRings.cryptoKeys.cryptoKeyVersions/decapsulate) method.

<div>

</div>

``` devsite-click-to-copy
curl "https://cloudkms.googleapis.com/v1/projects/PROJECT_ID/locations/LOCATION/keyRings/KEY_RING/cryptoKeys/KEY_NAME/cryptoKeyVersions/KEY_VERSION:decapsulate" \
  --request "POST" \
  --header "authorization: Bearer TOKEN" \
  --header "content-type: application/json" \
  --data '{"ciphertext": "CIPHERTEXT"}'
```

Replace the following:

`PROJECT_ID`: the ID of the project that contains the key ring.

`LOCATION`: the Cloud KMS location of the key ring.

`KEY_RING`: the name of the key ring that contains the key.

`KEY_NAME`: the name of the key to use for encryption.

`KEY_VERSION`: the ID of the key version to use for encryption

`CIPHERTEXT`: the base64-encoded ciphertext that you want to decapsulate.

</div>

</div>

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
