# Database (Input Stage)

<div class="devsite-article-body clearfix devsite-no-page-title">

# Database (Input Stage)

## Description

Returns all the documents within a database across different collections and nested levels.

## Examples

<div class="ds-selector-tabs" ds-scope="lang">

<div class="section">

### <span class="two-line-tab"><span tab-label="modular API"></span>Web</span>

<div>

</div>

``` devsite-click-to-copy
// Count all documents in the database
const results = await execute(db.pipeline()
  .database()
  .aggregate(countAll().as("total"))
  );test.firestore.js
```

</div>

<div class="section">

##### Swift

<div>

</div>

``` devsite-click-to-copy
// Count all documents in the database
let results = try await db.pipeline()
  .database()
  .aggregate([CountAll().as("total")])
  .execute()PipelineSnippets.swift
```

</div>

<div class="section">

##### <span class="two-line-tab">Kotlin <span class="firebase-platform-label">Android</span></span>

<div>

</div>

``` devsite-click-to-copy
// Count all documents in the database
val results = db.pipeline()
    .database()
    .aggregate(AggregateFunction.countAll().alias("total"))
    .execute()DocSnippets.kt
```

</div>

<div class="section">

##### <span class="two-line-tab">Java <span class="firebase-platform-label">Android</span></span>

<div>

</div>

``` devsite-click-to-copy
      // Count all documents in the database
Task<Pipeline.Snapshot> results = db.pipeline()
    .database()
    .aggregate(AggregateFunction.countAll().alias("total"))
    .execute();DocSnippets.java
    
```

</div>

<div class="section">

##### Python

<div>

</div>

``` devsite-click-to-copy
from google.cloud.firestore_v1.pipeline_expressions import Count

# Count all documents in the database
results = client.pipeline().database().aggregate(Count().as_("total")).execute()firestore_pipelines.py
```

</div>

<div class="section">

##### Java

<div>

</div>

``` devsite-click-to-copy
// Count all documents in the database
Pipeline.Snapshot results =
    firestore.pipeline().database().aggregate(countAll().as("total")).execute().get();PipelineSnippets.java
```

</div>

<div class="section">

##### Go

<div>

</div>

``` devsite-click-to-copy
// Count all documents in the database
snapshot := client.Pipeline().
 Database().
 Aggregate(firestore.Accumulators(firestore.CountAll().As("total"))).
 Execute(ctx)pipeline_snippets_general.go
```

</div>

</div>

## Behavior

In order to use the `database(...)` stage, it must appear as the first stage in the pipeline.

The order of documents returned from the `database(...)` stage is unstable and cannot be relied upon. A subsequent [`sort(...)`](/firestore/native/docs/pipeline/stages/transformation/sort) stage can be used to obtain a deterministic ordering.

For example, for the following documents:

<div>

<div class="section">

### Node.js

<div>

</div>

``` devsite-click-to-copy
await db.collection("cities").doc("SF").set({name: "San Francsico", state: "California", population: 800000});
await db.collection("states").doc("CA").set({name: "California", population: 39000000});
await db.collection("countries").doc("USA").set({name: "United States of America", population: 340000000});
```

</div>

</div>

The `database(...)` stage can be used to retrieve all the documents in the database.

<div>

<div class="section">

### Node.js

<div>

</div>

``` devsite-click-to-copy
const results = await db.pipeline()
  .database()
  .sort(field("population").ascending())
  .execute();
```

</div>

</div>

This query produces the following documents:

<div>

</div>

``` devsite-click-to-copy
  { name: "San Francsico", state: "California", population: 800000 }
  { name: "California", population: 39000000 }
  { name: "United States of America", population: 340000000 }
```

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
