# Identity and Access Management roles and permissions

<div class="devsite-article-body clearfix">

This page lists the IAM roles and permissions for Identity and Access Management. To search through all roles and permissions, see the [role and permission index](/iam/docs/roles-permissions).

## Identity and Access Management roles

<div results-count-container="">

</div>

<table class="fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="50%">Role</th>
<th>Permissions</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td class="role-description"><h4 id="iam.accessPolicyAdmin" class="role-title add-link" data-text="Access Policy Admin Beta " tabindex="-1">Access Policy Admin <sup>Beta</sup></h4>
<p>(<code translate="no" dir="ltr">roles/iam.accessPolicyAdmin</code>)</p>
<span class="role-description custom"> </span>
<p>Access Policy admin role, with permissions to read and modify access policies, and to bind and unbind access policies to targets.</p></td>
<td class="role-permissions"><p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iam.accesspolicies.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iam.accesspolicies.bind</code></li>
<li><code translate="no" dir="ltr">iam.accesspolicies.create</code></li>
<li><code translate="no" dir="ltr">iam.accesspolicies.delete</code></li>
<li><code translate="no" dir="ltr">iam.accesspolicies.get</code></li>
<li><code translate="no" dir="ltr">iam.accesspolicies.list</code></li>
<li><code translate="no" dir="ltr">iam.accesspolicies.searchPolicyBindings</code></li>
<li><code translate="no" dir="ltr">iam.accesspolicies.unbind</code></li>
<li><code translate="no" dir="ltr">iam.accesspolicies.update</code></li>
</ul></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="iam.admin" class="role-title add-link" data-text="Iam Admin " tabindex="-1">Iam Admin</h4>
<p>(<code translate="no" dir="ltr">roles/iam.admin</code>)</p>
<span class="role-description"> </span>
<p>Admin role for iam</p></td>
<td class="role-permissions"><p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iam.accesspolicies.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iam.accesspolicies.bind</code></li>
<li><code translate="no" dir="ltr">iam.accesspolicies.create</code></li>
<li><code translate="no" dir="ltr">iam.accesspolicies.delete</code></li>
<li><code translate="no" dir="ltr">iam.accesspolicies.get</code></li>
<li><code translate="no" dir="ltr">iam.accesspolicies.list</code></li>
<li><code translate="no" dir="ltr">iam.accesspolicies.searchPolicyBindings</code></li>
<li><code translate="no" dir="ltr">iam.accesspolicies.unbind</code></li>
<li><code translate="no" dir="ltr">iam.accesspolicies.update</code></li>
</ul>
<p><code translate="no" dir="ltr">iam.denypolicies.get</code></p>
<p><code translate="no" dir="ltr">iam.denypolicies.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iam.oauthClientCredentials.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iam.googleapis.com/oauthClientCredentials.create</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/oauthClientCredentials.delete</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/oauthClientCredentials.get</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/oauthClientCredentials.list</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/oauthClientCredentials.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iam.oauthClients.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iam.googleapis.com/oauthClients.create</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/oauthClients.delete</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/oauthClients.get</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/oauthClients.list</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/oauthClients.undelete</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/oauthClients.update</code></li>
</ul>
<p><code translate="no" dir="ltr">iam.operations.get</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iam.policybindings.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iam.policybindings.get</code></li>
<li><code translate="no" dir="ltr">iam.policybindings.list</code></li>
</ul>
<p><code translate="no" dir="ltr">iam.principalaccessboundarypolicies.get</code></p>
<p><code translate="no" dir="ltr">iam.principalaccessboundarypolicies.list</code></p>
<p><code translate="no" dir="ltr">iam.principalaccessboundarypolicies.searchPolicyBindings</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iam.roles.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iam.roles.create</code></li>
<li><code translate="no" dir="ltr">iam.roles.createTagBinding</code></li>
<li><code translate="no" dir="ltr">iam.roles.delete</code></li>
<li><code translate="no" dir="ltr">iam.roles.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">iam.roles.get</code></li>
<li><code translate="no" dir="ltr">iam.roles.list</code></li>
<li><code translate="no" dir="ltr">iam.roles.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">iam.roles.listTagBindings</code></li>
<li><code translate="no" dir="ltr">iam.roles.undelete</code></li>
<li><code translate="no" dir="ltr">iam.roles.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iam.serviceAccountApiKeyBindings.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iam.serviceAccountApiKeyBindings.create</code></li>
<li><code translate="no" dir="ltr">iam.serviceAccountApiKeyBindings.delete</code></li>
<li><code translate="no" dir="ltr">iam.serviceAccountApiKeyBindings.undelete</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iam.serviceAccountKeys.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iam.serviceAccountKeys.create</code></li>
<li><code translate="no" dir="ltr">iam.serviceAccountKeys.delete</code></li>
<li><code translate="no" dir="ltr">iam.serviceAccountKeys.disable</code></li>
<li><code translate="no" dir="ltr">iam.serviceAccountKeys.enable</code></li>
<li><code translate="no" dir="ltr">iam.serviceAccountKeys.get</code></li>
<li><code translate="no" dir="ltr">iam.serviceAccountKeys.list</code></li>
</ul>
<p><code translate="no" dir="ltr">iam.serviceAccounts.actAs</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.create</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.createTagBinding</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.delete</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.disable</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.enable</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.get</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.list</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.listTagBindings</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.undelete</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iam.workforcePoolProviderKeys.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderKeys.create</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderKeys.delete</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderKeys.get</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderKeys.list</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderKeys.undelete</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iam.workforcePoolProviderScimGroups.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimGroups.create</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimGroups.delete</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimGroups.get</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimGroups.list</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimGroups.patch</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimGroups.put</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iam.workforcePoolProviderScimUsers.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimUsers.create</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimUsers.delete</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimUsers.get</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimUsers.list</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimUsers.patch</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimUsers.put</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iam.workforcePoolProviders.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviders.computeUserAttributes</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviders.create</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviders.delete</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviders.get</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviders.list</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviders.undelete</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviders.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iam.workforcePoolSubjects.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolSubjects.delete</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolSubjects.revokeSessions</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolSubjects.undelete</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iam.workforcePools.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.create</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.createPolicyBinding</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.delete</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.deletePolicyBinding</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.get</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.list</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.searchPolicyBindings</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.undelete</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.update</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.updatePolicyBinding</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iam.workloadIdentityPoolManagedIdentities.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolManagedIdentities.create</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolManagedIdentities.delete</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolManagedIdentities.get</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolManagedIdentities.getAttestationRules</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolManagedIdentities.list</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolManagedIdentities.setAttestationRules</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolManagedIdentities.undelete</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolManagedIdentities.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iam.workloadIdentityPoolNamespaces.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolNamespaces.create</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolNamespaces.delete</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolNamespaces.get</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolNamespaces.list</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolNamespaces.undelete</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolNamespaces.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iam.workloadIdentityPoolProviderKeys.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolProviderKeys.create</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolProviderKeys.delete</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolProviderKeys.get</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolProviderKeys.list</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolProviderKeys.undelete</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iam.workloadIdentityPoolProviders.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolProviders.create</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolProviders.delete</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolProviders.get</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolProviders.list</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolProviders.undelete</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolProviders.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iam.workloadIdentityPools.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPools.create</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPools.delete</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPools.get</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPools.getAttestationRules</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPools.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPools.list</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPools.setAttestationRules</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPools.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPools.undelete</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPools.update</code></li>
<li><code translate="no" dir="ltr">iam.workloadIdentityPools.createPolicyBinding</code></li>
<li><code translate="no" dir="ltr">iam.workloadIdentityPools.deletePolicyBinding</code></li>
<li><code translate="no" dir="ltr">iam.workloadIdentityPools.searchPolicyBindings</code></li>
<li><code translate="no" dir="ltr">iam.workloadIdentityPools.updatePolicyBinding</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iam.workspacePools.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iam.googleapis.com/workspacePools.createPolicyBinding</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workspacePools.deletePolicyBinding</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workspacePools.searchPolicyBindings</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workspacePools.updatePolicyBinding</code></li>
</ul>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="iam.editor" class="role-title add-link" data-text="Iam Editor " tabindex="-1">Iam Editor</h4>
<p>(<code translate="no" dir="ltr">roles/iam.editor</code>)</p>
<span class="role-description"> </span>
<p>Editor role for iam</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">iam.accesspolicies.get</code></p>
<p><code translate="no" dir="ltr">iam.accesspolicies.list</code></p>
<p><code translate="no" dir="ltr">iam.accesspolicies.searchPolicyBindings</code></p>
<p><code translate="no" dir="ltr">iam.denypolicies.get</code></p>
<p><code translate="no" dir="ltr">iam.denypolicies.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/oauthClientCredentials.get</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/oauthClientCredentials.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/oauthClients.get</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/oauthClients.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderKeys.get</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderKeys.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimGroups.get</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimGroups.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimUsers.get</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimUsers.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviders.computeUserAttributes</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviders.get</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviders.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.get</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.searchPolicyBindings</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolManagedIdentities.get</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolManagedIdentities.getAttestationRules</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolManagedIdentities.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolNamespaces.get</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolNamespaces.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolProviderKeys.get</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolProviderKeys.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolProviders.get</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolProviders.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPools.get</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPools.getAttestationRules</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPools.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPools.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workspacePools.searchPolicyBindings</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iam.policybindings.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iam.policybindings.get</code></li>
<li><code translate="no" dir="ltr">iam.policybindings.list</code></li>
</ul>
<p><code translate="no" dir="ltr">iam.principalaccessboundarypolicies.get</code></p>
<p><code translate="no" dir="ltr">iam.principalaccessboundarypolicies.list</code></p>
<p><code translate="no" dir="ltr">iam.principalaccessboundarypolicies.searchPolicyBindings</code></p>
<p><code translate="no" dir="ltr">iam.roles.get</code></p>
<p><code translate="no" dir="ltr">iam.roles.list</code></p>
<p><code translate="no" dir="ltr">iam.roles.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">iam.roles.listTagBindings</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iam.serviceAccountApiKeyBindings.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iam.serviceAccountApiKeyBindings.create</code></li>
<li><code translate="no" dir="ltr">iam.serviceAccountApiKeyBindings.delete</code></li>
<li><code translate="no" dir="ltr">iam.serviceAccountApiKeyBindings.undelete</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iam.serviceAccountKeys.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iam.serviceAccountKeys.create</code></li>
<li><code translate="no" dir="ltr">iam.serviceAccountKeys.delete</code></li>
<li><code translate="no" dir="ltr">iam.serviceAccountKeys.disable</code></li>
<li><code translate="no" dir="ltr">iam.serviceAccountKeys.enable</code></li>
<li><code translate="no" dir="ltr">iam.serviceAccountKeys.get</code></li>
<li><code translate="no" dir="ltr">iam.serviceAccountKeys.list</code></li>
</ul>
<p><code translate="no" dir="ltr">iam.serviceAccounts.actAs</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.create</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.delete</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.disable</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.enable</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.get</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.list</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.listTagBindings</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.update</code></p>
<p><code translate="no" dir="ltr">iam.workloadIdentityPools.searchPolicyBindings</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="iam.principalAccessBoundaryViewer" class="role-title add-link" data-text="Principal Access Boundary Policy Viewer " tabindex="-1">Principal Access Boundary Policy Viewer</h4>
<p>(<code translate="no" dir="ltr">roles/iam.principalAccessBoundaryViewer</code>)</p>
<span class="role-description"> </span>
<p>Read-only access to Principal Access Boundary policies and their associated bindings.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">iam.principalaccessboundarypolicies.get</code></p>
<p><code translate="no" dir="ltr">iam.principalaccessboundarypolicies.list</code></p>
<p><code translate="no" dir="ltr">iam.principalaccessboundarypolicies.searchPolicyBindings</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="iam.roleAdmin" class="role-title add-link" data-text="Role Administrator " tabindex="-1">Role Administrator</h4>
<p>(<code translate="no" dir="ltr">roles/iam.roleAdmin</code>)</p>
<span class="role-description custom"> </span>
<p>Provides access to all custom roles in the project. This role can only be granted at the project level.</p></td>
<td class="role-permissions"><p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iam.roles.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iam.roles.create</code></li>
<li><code translate="no" dir="ltr">iam.roles.createTagBinding</code></li>
<li><code translate="no" dir="ltr">iam.roles.delete</code></li>
<li><code translate="no" dir="ltr">iam.roles.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">iam.roles.get</code></li>
<li><code translate="no" dir="ltr">iam.roles.list</code></li>
<li><code translate="no" dir="ltr">iam.roles.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">iam.roles.listTagBindings</code></li>
<li><code translate="no" dir="ltr">iam.roles.undelete</code></li>
<li><code translate="no" dir="ltr">iam.roles.update</code></li>
</ul>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.getIamPolicy</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="iam.roleViewer" class="role-title add-link" data-text="Role Viewer " tabindex="-1">Role Viewer</h4>
<p>(<code translate="no" dir="ltr">roles/iam.roleViewer</code>)</p>
<span class="role-description custom"> </span>
<p>Provides read access to all custom roles in the project.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Project</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">iam.roles.get</code></p>
<p><code translate="no" dir="ltr">iam.roles.list</code></p>
<p><code translate="no" dir="ltr">iam.roles.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">iam.roles.listTagBindings</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.getIamPolicy</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="iam.securityAdmin" class="role-title add-link" data-text="Security Admin " tabindex="-1">Security Admin</h4>
<p>(<code translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<span class="role-description"> </span>
<p>Security admin role, with permissions to get and set any IAM policy.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">accessapproval.requests.list</code></p>
<p><code translate="no" dir="ltr">accesscontextmanager.accessLevels.list</code></p>
<p><code translate="no" dir="ltr">accesscontextmanager.authorizedOrgsDescs.list</code></p>
<p><code translate="no" dir="ltr">accesscontextmanager.gcpUserAccessBindings.list</code></p>
<p><code translate="no" dir="ltr">accesscontextmanager.policies.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">accesscontextmanager.policies.list</code></p>
<p><code translate="no" dir="ltr">accesscontextmanager.policies.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">accesscontextmanager.servicePerimeters.list</code></p>
<p><code translate="no" dir="ltr">actions.agentVersions.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">advisorynotifications.notifications.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">advisorynotifications.notifications.get</code></li>
<li><code translate="no" dir="ltr">advisorynotifications.notifications.list</code></li>
</ul>
<p><code translate="no" dir="ltr">agentidentity.accessSummaries.list</code></p>
<p><code translate="no" dir="ltr">agentidentity.authProviders.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">agentidentity.authProviders.list</code></p>
<p><code translate="no" dir="ltr">agentidentity.authProviders.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">agentidentity.authorizations.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">agentidentity.authorizations.list</code></p>
<p><code translate="no" dir="ltr">agentidentity.authorizations.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">agentidentity.locations.list</code></p>
<p><code translate="no" dir="ltr">agentregistry.agents.list</code></p>
<p><code translate="no" dir="ltr">agentregistry.bindings.list</code></p>
<p><code translate="no" dir="ltr">agentregistry.endpoints.list</code></p>
<p><code translate="no" dir="ltr">agentregistry.locations.list</code></p>
<p><code translate="no" dir="ltr">agentregistry.mcpServers.list</code></p>
<p><code translate="no" dir="ltr">agentregistry.operations.list</code></p>
<p><code translate="no" dir="ltr">agentregistry.publishers.list</code></p>
<p><code translate="no" dir="ltr">agentregistry.services.list</code></p>
<p><code translate="no" dir="ltr">agentregistry.skillRevisions.list</code></p>
<p><code translate="no" dir="ltr">agentregistry.skills.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">agentregistry.skills.list</code></p>
<p><code translate="no" dir="ltr">agentregistry.skills.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">aiplatform.agentAnomalyDetectionScopes.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.agentExamples.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.agentMemories.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.agents.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">aiplatform.agents.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.analyzedInvocations.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.analyzedSessions.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.annotationSpecs.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.annotations.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.apps.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.artifacts.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.batchPredictionJobs.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.cachedContents.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.contexts.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.customJobs.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.dataItems.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.dataLabelingJobs.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.datasetVersions.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.datasets.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.deploymentResourcePools.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.edgeDeploymentJobs.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.edgeDevices.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.endpoints.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">aiplatform.endpoints.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.endpoints.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">aiplatform.entityTypes.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">aiplatform.entityTypes.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.entityTypes.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">aiplatform.evaluationExperiments.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.evaluationItems.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.evaluationMetrics.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.evaluationRuns.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.evaluationSets.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.exampleStores.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.executions.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.extensions.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.featureGroups.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">aiplatform.featureGroups.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.featureGroups.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">aiplatform.featureMonitorJobs.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.featureMonitors.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.featureOnlineStores.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">aiplatform.featureOnlineStores.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.featureOnlineStores.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">aiplatform.featureViewSyncs.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.featureViews.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">aiplatform.featureViews.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.featureViews.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">aiplatform.features.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.featurestores.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">aiplatform.featurestores.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.featurestores.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">aiplatform.humanInTheLoops.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.hyperparameterTuningJobs.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.indexEndpoints.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.indexes.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.interactions.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.locations.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.memories.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.memoryRevisions.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.metadataSchemas.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.metadataStores.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.modelDeploymentMonitoringJobs.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.modelEvaluationSlices.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.modelEvaluations.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.modelMonitoringJobs.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.modelMonitors.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.models.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.monitoredAgents.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.nasJobs.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.nasTrialDetails.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.notebookExecutionJobs.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.notebookRuntimeTemplates.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">aiplatform.notebookRuntimeTemplates.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.notebookRuntimeTemplates.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">aiplatform.notebookRuntimes.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.onlineEvaluators.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.operations.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.persistentResources.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.pipelineJobs.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.provisionedThroughputRevisions.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.provisionedThroughputs.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.ragCorpora.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.ragFiles.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.reasoningEngineRuntimeRevisions.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.reasoningEngines.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">aiplatform.reasoningEngines.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.reasoningEngines.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">aiplatform.sandboxEnvironments.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.schedules.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.semanticGovernancePolicies.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.sessionEvents.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.sessions.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.specialistPools.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.studies.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.tasks.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.tensorboardExperiments.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.tensorboardRuns.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.tensorboardTimeSeries.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.tensorboards.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.trainingPipelines.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.trials.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.tuningJobs.list</code></p>
<p><code translate="no" dir="ltr">alloydb.backups.list</code></p>
<p><code translate="no" dir="ltr">alloydb.clusters.list</code></p>
<p><code translate="no" dir="ltr">alloydb.databases.list</code></p>
<p><code translate="no" dir="ltr">alloydb.instances.list</code></p>
<p><code translate="no" dir="ltr">alloydb.locations.list</code></p>
<p><code translate="no" dir="ltr">alloydb.operations.list</code></p>
<p><code translate="no" dir="ltr">alloydb.supportedDatabaseFlags.list</code></p>
<p><code translate="no" dir="ltr">alloydb.users.list</code></p>
<p><code translate="no" dir="ltr">analyticshub.dataExchanges.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">analyticshub.dataExchanges.list</code></p>
<p><code translate="no" dir="ltr">analyticshub.dataExchanges.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">analyticshub.listings.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">analyticshub.listings.list</code></p>
<p><code translate="no" dir="ltr">analyticshub.listings.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">analyticshub.queryTemplates.list</code></p>
<p><code translate="no" dir="ltr">analyticshub.subscriptions.list</code></p>
<p><code translate="no" dir="ltr">apigateway.apiconfigs.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">apigateway.apiconfigs.list</code></p>
<p><code translate="no" dir="ltr">apigateway.apiconfigs.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">apigateway.apis.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">apigateway.apis.list</code></p>
<p><code translate="no" dir="ltr">apigateway.apis.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">apigateway.gateways.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">apigateway.gateways.list</code></p>
<p><code translate="no" dir="ltr">apigateway.gateways.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">apigateway.locations.list</code></p>
<p><code translate="no" dir="ltr">apigateway.operations.list</code></p>
<p><code translate="no" dir="ltr">apigee.apiproductattributes.list</code></p>
<p><code translate="no" dir="ltr">apigee.apiproducts.list</code></p>
<p><code translate="no" dir="ltr">apigee.appgroupapps.list</code></p>
<p><code translate="no" dir="ltr">apigee.appgroups.list</code></p>
<p><code translate="no" dir="ltr">apigee.appgroupsubscriptions.list</code></p>
<p><code translate="no" dir="ltr">apigee.apps.list</code></p>
<p><code translate="no" dir="ltr">apigee.archivedeployments.list</code></p>
<p><code translate="no" dir="ltr">apigee.caches.list</code></p>
<p><code translate="no" dir="ltr">apigee.datacollectors.list</code></p>
<p><code translate="no" dir="ltr">apigee.datastores.list</code></p>
<p><code translate="no" dir="ltr">apigee.deployments.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">apigee.deployments.list</code></p>
<p><code translate="no" dir="ltr">apigee.deployments.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">apigee.developerappattributes.list</code></p>
<p><code translate="no" dir="ltr">apigee.developerapps.list</code></p>
<p><code translate="no" dir="ltr">apigee.developerattributes.list</code></p>
<p><code translate="no" dir="ltr">apigee.developers.list</code></p>
<p><code translate="no" dir="ltr">apigee.developersubscriptions.list</code></p>
<p><code translate="no" dir="ltr">apigee.dnsZones.list</code></p>
<p><code translate="no" dir="ltr">apigee.endpointattachments.list</code></p>
<p><code translate="no" dir="ltr">apigee.envgroupattachments.list</code></p>
<p><code translate="no" dir="ltr">apigee.envgroups.list</code></p>
<p><code translate="no" dir="ltr">apigee.environments.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">apigee.environments.list</code></p>
<p><code translate="no" dir="ltr">apigee.environments.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">apigee.exports.list</code></p>
<p><code translate="no" dir="ltr">apigee.flowhooks.list</code></p>
<p><code translate="no" dir="ltr">apigee.hostqueries.list</code></p>
<p><code translate="no" dir="ltr">apigee.hostsecurityreports.list</code></p>
<p><code translate="no" dir="ltr">apigee.instanceattachments.list</code></p>
<p><code translate="no" dir="ltr">apigee.instances.list</code></p>
<p><code translate="no" dir="ltr">apigee.keystorealiases.list</code></p>
<p><code translate="no" dir="ltr">apigee.keystores.list</code></p>
<p><code translate="no" dir="ltr">apigee.keyvaluemapentries.list</code></p>
<p><code translate="no" dir="ltr">apigee.keyvaluemaps.list</code></p>
<p><code translate="no" dir="ltr">apigee.nataddresses.list</code></p>
<p><code translate="no" dir="ltr">apigee.operations.list</code></p>
<p><code translate="no" dir="ltr">apigee.organizations.list</code></p>
<p><code translate="no" dir="ltr">apigee.portals.list</code></p>
<p><code translate="no" dir="ltr">apigee.proxies.list</code></p>
<p><code translate="no" dir="ltr">apigee.proxyrevisions.list</code></p>
<p><code translate="no" dir="ltr">apigee.queries.list</code></p>
<p><code translate="no" dir="ltr">apigee.rateplans.list</code></p>
<p><code translate="no" dir="ltr">apigee.references.list</code></p>
<p><code translate="no" dir="ltr">apigee.reports.list</code></p>
<p><code translate="no" dir="ltr">apigee.resourcefiles.list</code></p>
<p><code translate="no" dir="ltr">apigee.securityActions.list</code></p>
<p><code translate="no" dir="ltr">apigee.securityFeedback.list</code></p>
<p><code translate="no" dir="ltr">apigee.securityIncidents.list</code></p>
<p><code translate="no" dir="ltr">apigee.securityMonitoringConditions.list</code></p>
<p><code translate="no" dir="ltr">apigee.securityProfiles.list</code></p>
<p><code translate="no" dir="ltr">apigee.securityProfilesV2.list</code></p>
<p><code translate="no" dir="ltr">apigee.securityreports.list</code></p>
<p><code translate="no" dir="ltr">apigee.sharedflowrevisions.list</code></p>
<p><code translate="no" dir="ltr">apigee.sharedflows.list</code></p>
<p><code translate="no" dir="ltr">apigee.spaces.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">apigee.spaces.list</code></p>
<p><code translate="no" dir="ltr">apigee.spaces.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">apigee.targetservers.list</code></p>
<p><code translate="no" dir="ltr">apigee.traceconfigoverrides.list</code></p>
<p><code translate="no" dir="ltr">apigee.tracesessions.list</code></p>
<p><code translate="no" dir="ltr">apigeeconnect.connections.list</code></p>
<p><code translate="no" dir="ltr">apigeeregistry.apis.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">apigeeregistry.apis.list</code></p>
<p><code translate="no" dir="ltr">apigeeregistry.apis.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">apigeeregistry.artifacts.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">apigeeregistry.artifacts.list</code></p>
<p><code translate="no" dir="ltr">apigeeregistry.artifacts.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">apigeeregistry.deployments.list</code></p>
<p><code translate="no" dir="ltr">apigeeregistry.locations.list</code></p>
<p><code translate="no" dir="ltr">apigeeregistry.operations.list</code></p>
<p><code translate="no" dir="ltr">apigeeregistry.specs.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">apigeeregistry.specs.list</code></p>
<p><code translate="no" dir="ltr">apigeeregistry.specs.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">apigeeregistry.versions.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">apigeeregistry.versions.list</code></p>
<p><code translate="no" dir="ltr">apigeeregistry.versions.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">apihub.addons.list</code></p>
<p><code translate="no" dir="ltr">apihub.apiHubInstances.list</code></p>
<p><code translate="no" dir="ltr">apihub.apiOperations.list</code></p>
<p><code translate="no" dir="ltr">apihub.apis.list</code></p>
<p><code translate="no" dir="ltr">apihub.attributes.list</code></p>
<p><code translate="no" dir="ltr">apihub.curations.list</code></p>
<p><code translate="no" dir="ltr">apihub.definitions.list</code></p>
<p><code translate="no" dir="ltr">apihub.dependencies.list</code></p>
<p><code translate="no" dir="ltr">apihub.deployments.list</code></p>
<p><code translate="no" dir="ltr">apihub.discoveredApiObservations.list</code></p>
<p><code translate="no" dir="ltr">apihub.discoveredApiOperations.list</code></p>
<p><code translate="no" dir="ltr">apihub.externalApis.list</code></p>
<p><code translate="no" dir="ltr">apihub.hostProjectRegistrations.list</code></p>
<p><code translate="no" dir="ltr">apihub.llmEnablements.list</code></p>
<p><code translate="no" dir="ltr">apihub.operations.list</code></p>
<p><code translate="no" dir="ltr">apihub.plugininstances.list</code></p>
<p><code translate="no" dir="ltr">apihub.plugins.list</code></p>
<p><code translate="no" dir="ltr">apihub.runTimeProjectAttachments.list</code></p>
<p><code translate="no" dir="ltr">apihub.specs.list</code></p>
<p><code translate="no" dir="ltr">apihub.versions.list</code></p>
<p><code translate="no" dir="ltr">apikeys.keys.list</code></p>
<p><code translate="no" dir="ltr">apim.apiObservations.list</code></p>
<p><code translate="no" dir="ltr">apim.apiOperations.list</code></p>
<p><code translate="no" dir="ltr">apim.locations.list</code></p>
<p><code translate="no" dir="ltr">apim.observationJobs.list</code></p>
<p><code translate="no" dir="ltr">apim.observationSources.list</code></p>
<p><code translate="no" dir="ltr">apim.operations.list</code></p>
<p><code translate="no" dir="ltr">appengine.instances.list</code></p>
<p><code translate="no" dir="ltr">appengine.memcache.list</code></p>
<p><code translate="no" dir="ltr">appengine.operations.list</code></p>
<p><code translate="no" dir="ltr">appengine.services.list</code></p>
<p><code translate="no" dir="ltr">appengine.versions.list</code></p>
<p><code translate="no" dir="ltr">apphub.applications.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">apphub.applications.list</code></p>
<p><code translate="no" dir="ltr">apphub.applications.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">apphub.discoveredServices.list</code></p>
<p><code translate="no" dir="ltr">apphub.discoveredWorkloads.list</code></p>
<p><code translate="no" dir="ltr">apphub.extendedMetadataSchemas.list</code></p>
<p><code translate="no" dir="ltr">apphub.locations.list</code></p>
<p><code translate="no" dir="ltr">apphub.operations.list</code></p>
<p><code translate="no" dir="ltr">apphub.serviceProjectAttachments.list</code></p>
<p><code translate="no" dir="ltr">apphub.services.list</code></p>
<p><code translate="no" dir="ltr">apphub.workloads.list</code></p>
<p><code translate="no" dir="ltr">applianceactivation.rttCommands.list</code></p>
<p><code translate="no" dir="ltr">appoptimize.locations.list</code></p>
<p><code translate="no" dir="ltr">appoptimize.operations.list</code></p>
<p><code translate="no" dir="ltr">appoptimize.reports.list</code></p>
<p><code translate="no" dir="ltr">apptopology.domains.list</code></p>
<p><code translate="no" dir="ltr">apptopology.locations.list</code></p>
<p><code translate="no" dir="ltr">apptopology.operations.list</code></p>
<p><code translate="no" dir="ltr">apptopology.topologyViews.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.attachments.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.dockerimages.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.files.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.locations.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.mavenartifacts.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.npmpackages.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.packages.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.pythonpackages.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">artifactregistry.rules.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.tags.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.versions.list</code></p>
<p><code translate="no" dir="ltr">assuredoss.locations.list</code></p>
<p><code translate="no" dir="ltr">assuredoss.metadata.list</code></p>
<p><code translate="no" dir="ltr">assuredoss.operations.list</code></p>
<p><code translate="no" dir="ltr">assuredworkloads.dbControlComplianceSummaries.list</code></p>
<p><code translate="no" dir="ltr">assuredworkloads.dbFindingSummaries.list</code></p>
<p><code translate="no" dir="ltr">assuredworkloads.dbFrameworkComplianceSummaries.list</code></p>
<p><code translate="no" dir="ltr">assuredworkloads.operations.list</code></p>
<p><code translate="no" dir="ltr">assuredworkloads.updates.list</code></p>
<p><code translate="no" dir="ltr">assuredworkloads.violations.list</code></p>
<p><code translate="no" dir="ltr">assuredworkloads.workload.list</code></p>
<p><code translate="no" dir="ltr">auditmanager.auditReports.list</code></p>
<p><code translate="no" dir="ltr">auditmanager.auditSchedules.list</code></p>
<p><code translate="no" dir="ltr">auditmanager.controlReports.list</code></p>
<p><code translate="no" dir="ltr">auditmanager.controls.list</code></p>
<p><code translate="no" dir="ltr">auditmanager.customComplianceFrameworks.list</code></p>
<p><code translate="no" dir="ltr">auditmanager.findings.list</code></p>
<p><code translate="no" dir="ltr">auditmanager.locations.list</code></p>
<p><code translate="no" dir="ltr">auditmanager.operations.list</code></p>
<p><code translate="no" dir="ltr">auditmanager.resourceEnrollmentStatuses.list</code></p>
<p><code translate="no" dir="ltr">automl.annotationSpecs.list</code></p>
<p><code translate="no" dir="ltr">automl.annotations.list</code></p>
<p><code translate="no" dir="ltr">automl.columnSpecs.list</code></p>
<p><code translate="no" dir="ltr">automl.datasets.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">automl.datasets.list</code></p>
<p><code translate="no" dir="ltr">automl.datasets.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">automl.examples.list</code></p>
<p><code translate="no" dir="ltr">automl.files.list</code></p>
<p><code translate="no" dir="ltr">automl.humanAnnotationTasks.list</code></p>
<p><code translate="no" dir="ltr">automl.locations.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">automl.locations.list</code></p>
<p><code translate="no" dir="ltr">automl.locations.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">automl.modelEvaluations.list</code></p>
<p><code translate="no" dir="ltr">automl.models.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">automl.models.list</code></p>
<p><code translate="no" dir="ltr">automl.models.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">automl.operations.list</code></p>
<p><code translate="no" dir="ltr">automl.tableSpecs.list</code></p>
<p><code translate="no" dir="ltr">automlrecommendations.apiKeys.list</code></p>
<p><code translate="no" dir="ltr">automlrecommendations.catalogItems.list</code></p>
<p><code translate="no" dir="ltr">automlrecommendations.catalogs.list</code></p>
<p><code translate="no" dir="ltr">automlrecommendations.eventStores.list</code></p>
<p><code translate="no" dir="ltr">automlrecommendations.events.list</code></p>
<p><code translate="no" dir="ltr">automlrecommendations.placements.list</code></p>
<p><code translate="no" dir="ltr">automlrecommendations.recommendations.list</code></p>
<p><code translate="no" dir="ltr">autoscaling.sites.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">autoscaling.sites.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">backupdr.appliedAutoProtectionPolicies.list</code></p>
<p><code translate="no" dir="ltr">backupdr.autoProtectionBindings.list</code></p>
<p><code translate="no" dir="ltr">backupdr.autoProtectionPolicies.list</code></p>
<p><code translate="no" dir="ltr">backupdr.backupPlanAssociations.list</code></p>
<p><code translate="no" dir="ltr">backupdr.backupPlanRevisions.list</code></p>
<p><code translate="no" dir="ltr">backupdr.backupPlans.list</code></p>
<p><code translate="no" dir="ltr">backupdr.backupVaults.list</code></p>
<p><code translate="no" dir="ltr">backupdr.bindingMatchingResources.list</code></p>
<p><code translate="no" dir="ltr">backupdr.bvbackups.list</code></p>
<p><code translate="no" dir="ltr">backupdr.bvdataSources.list</code></p>
<p><code translate="no" dir="ltr">backupdr.dataSourceReferences.list</code></p>
<p><code translate="no" dir="ltr">backupdr.locations.list</code></p>
<p><code translate="no" dir="ltr">backupdr.managementServers.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">backupdr.managementServers.list</code></p>
<p><code translate="no" dir="ltr">backupdr.managementServers.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">backupdr.operations.list</code></p>
<p><code translate="no" dir="ltr">backupdr.resourceBackupConfigs.list</code></p>
<p><code translate="no" dir="ltr">baremetalsolution.instancequotas.list</code></p>
<p><code translate="no" dir="ltr">baremetalsolution.instances.list</code></p>
<p><code translate="no" dir="ltr">baremetalsolution.luns.list</code></p>
<p><code translate="no" dir="ltr">baremetalsolution.maintenanceevents.list</code></p>
<p><code translate="no" dir="ltr">baremetalsolution.networkquotas.list</code></p>
<p><code translate="no" dir="ltr">baremetalsolution.networks.list</code></p>
<p><code translate="no" dir="ltr">baremetalsolution.nfsshares.list</code></p>
<p><code translate="no" dir="ltr">baremetalsolution.osimages.list</code></p>
<p><code translate="no" dir="ltr">baremetalsolution.pods.list</code></p>
<p><code translate="no" dir="ltr">baremetalsolution.procurements.list</code></p>
<p><code translate="no" dir="ltr">baremetalsolution.skus.list</code></p>
<p><code translate="no" dir="ltr">baremetalsolution.snapshotschedulepolicies.list</code></p>
<p><code translate="no" dir="ltr">baremetalsolution.sshKeys.list</code></p>
<p><code translate="no" dir="ltr">baremetalsolution.storageaggregatepools.list</code></p>
<p><code translate="no" dir="ltr">baremetalsolution.volumequotas.list</code></p>
<p><code translate="no" dir="ltr">baremetalsolution.volumes.list</code></p>
<p><code translate="no" dir="ltr">baremetalsolution.volumesnapshots.list</code></p>
<p><code translate="no" dir="ltr">batch.jobs.list</code></p>
<p><code translate="no" dir="ltr">batch.locations.list</code></p>
<p><code translate="no" dir="ltr">batch.operations.list</code></p>
<p><code translate="no" dir="ltr">batch.resourceAllowances.list</code></p>
<p><code translate="no" dir="ltr">batch.tasks.list</code></p>
<p><code translate="no" dir="ltr">beyondcorp.appConnections.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">beyondcorp.appConnections.list</code></p>
<p><code translate="no" dir="ltr">beyondcorp.appConnections.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">beyondcorp.appConnectors.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">beyondcorp.appConnectors.list</code></p>
<p><code translate="no" dir="ltr">beyondcorp.appConnectors.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">beyondcorp.appGateways.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">beyondcorp.appGateways.list</code></p>
<p><code translate="no" dir="ltr">beyondcorp.appGateways.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">beyondcorp.locations.list</code></p>
<p><code translate="no" dir="ltr">beyondcorp.operations.list</code></p>
<p><code translate="no" dir="ltr">beyondcorp.securityGateways.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">beyondcorp.securityGateways.list</code></p>
<p><code translate="no" dir="ltr">beyondcorp.securityGateways.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">beyondcorp.sgApplications.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">beyondcorp.sgApplications.list</code></p>
<p><code translate="no" dir="ltr">beyondcorp.sgApplications.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">beyondcorp.subscriptions.list</code></p>
<p><code translate="no" dir="ltr">biglake.catalogs.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">biglake.catalogs.list</code></p>
<p><code translate="no" dir="ltr">biglake.catalogs.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">biglake.databases.list</code></p>
<p><code translate="no" dir="ltr">biglake.locks.list</code></p>
<p><code translate="no" dir="ltr">biglake.namespaces.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">biglake.namespaces.list</code></p>
<p><code translate="no" dir="ltr">biglake.namespaces.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">biglake.tables.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">biglake.tables.list</code></p>
<p><code translate="no" dir="ltr">biglake.tables.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigquery.capacityCommitments.list</code></p>
<p><code translate="no" dir="ltr">bigquery.connections.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigquery.connections.list</code></p>
<p><code translate="no" dir="ltr">bigquery.connections.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigquery.dataPolicies.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigquery.dataPolicies.list</code></p>
<p><code translate="no" dir="ltr">bigquery.dataPolicies.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigquery.datasets.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigquery.datasets.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigquery.jobs.list</code></p>
<p><code translate="no" dir="ltr">bigquery.models.list</code></p>
<p><code translate="no" dir="ltr">bigquery.propertyGraphs.list</code></p>
<p><code translate="no" dir="ltr">bigquery.reservationAssignments.list</code></p>
<p><code translate="no" dir="ltr">bigquery.reservationGroups.list</code></p>
<p><code translate="no" dir="ltr">bigquery.reservations.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigquery.reservations.list</code></p>
<p><code translate="no" dir="ltr">bigquery.reservations.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigquery.routines.list</code></p>
<p><code translate="no" dir="ltr">bigquery.rowAccessPolicies.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigquery.rowAccessPolicies.list</code></p>
<p><code translate="no" dir="ltr">bigquery.rowAccessPolicies.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigquery.savedqueries.list</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.list</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigquerymigration.subtasks.list</code></p>
<p><code translate="no" dir="ltr">bigquerymigration.workflows.list</code></p>
<p><code translate="no" dir="ltr">bigtable.appProfiles.list</code></p>
<p><code translate="no" dir="ltr">bigtable.authorizedViews.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigtable.authorizedViews.list</code></p>
<p><code translate="no" dir="ltr">bigtable.authorizedViews.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigtable.backups.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigtable.backups.list</code></p>
<p><code translate="no" dir="ltr">bigtable.backups.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigtable.clusters.list</code></p>
<p><code translate="no" dir="ltr">bigtable.hotTablets.list</code></p>
<p><code translate="no" dir="ltr">bigtable.instances.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigtable.instances.list</code></p>
<p><code translate="no" dir="ltr">bigtable.instances.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigtable.keyvisualizer.list</code></p>
<p><code translate="no" dir="ltr">bigtable.locations.list</code></p>
<p><code translate="no" dir="ltr">bigtable.logicalViews.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigtable.logicalViews.list</code></p>
<p><code translate="no" dir="ltr">bigtable.logicalViews.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigtable.materializedViews.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigtable.materializedViews.list</code></p>
<p><code translate="no" dir="ltr">bigtable.materializedViews.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigtable.memoryLayers.list</code></p>
<p><code translate="no" dir="ltr">bigtable.schemaBundles.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigtable.schemaBundles.list</code></p>
<p><code translate="no" dir="ltr">bigtable.schemaBundles.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigtable.tables.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigtable.tables.list</code></p>
<p><code translate="no" dir="ltr">bigtable.tables.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">billing.accounts.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">billing.accounts.list</code></p>
<p><code translate="no" dir="ltr">billing.accounts.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">billing.anomalies.list</code></p>
<p><code translate="no" dir="ltr">billing.billingAccountPrices.list</code></p>
<p><code translate="no" dir="ltr">billing.billingAccountServices.list</code></p>
<p><code translate="no" dir="ltr">billing.billingAccountSkuGroupSkus.list</code></p>
<p><code translate="no" dir="ltr">billing.billingAccountSkuGroups.list</code></p>
<p><code translate="no" dir="ltr">billing.billingAccountSkus.list</code></p>
<p><code translate="no" dir="ltr">billing.budgets.list</code></p>
<p><code translate="no" dir="ltr">billing.credits.list</code></p>
<p><code translate="no" dir="ltr">billing.resourceAssociations.list</code></p>
<p><code translate="no" dir="ltr">billing.subscriptions.list</code></p>
<p><code translate="no" dir="ltr">binaryauthorization.attestors.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">binaryauthorization.attestors.list</code></p>
<p><code translate="no" dir="ltr">binaryauthorization.attestors.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">binaryauthorization.continuousValidationConfig.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">binaryauthorization.continuousValidationConfig.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">binaryauthorization.platformPolicies.list</code></p>
<p><code translate="no" dir="ltr">binaryauthorization.policy.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">binaryauthorization.policy.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">blockchainnodeengine.blockchainNodes.list</code></p>
<p><code translate="no" dir="ltr">blockchainnodeengine.locations.list</code></p>
<p><code translate="no" dir="ltr">blockchainnodeengine.operations.list</code></p>
<p><code translate="no" dir="ltr">blockchainvalidatormanager.blockchainValidatorConfigs.list</code></p>
<p><code translate="no" dir="ltr">blockchainvalidatormanager.locations.list</code></p>
<p><code translate="no" dir="ltr">blockchainvalidatormanager.operations.list</code></p>
<p><code translate="no" dir="ltr">capacityplanner.capacityPlans.list</code></p>
<p><code translate="no" dir="ltr">capacityplanner.forecasts.list</code></p>
<p><code translate="no" dir="ltr">capacityplanner.planAlertInsights.list</code></p>
<p><code translate="no" dir="ltr">capacityplanner.usageAlertInsights.list</code></p>
<p><code translate="no" dir="ltr">capacityplanner.usageHistories.list</code></p>
<p><code translate="no" dir="ltr">carestudio.patients.list</code></p>
<p><code translate="no" dir="ltr">certificatemanager.certissuanceconfigs.list</code></p>
<p><code translate="no" dir="ltr">certificatemanager.certmapentries.list</code></p>
<p><code translate="no" dir="ltr">certificatemanager.certmaps.list</code></p>
<p><code translate="no" dir="ltr">certificatemanager.certs.list</code></p>
<p><code translate="no" dir="ltr">certificatemanager.dnsauthorizations.list</code></p>
<p><code translate="no" dir="ltr">certificatemanager.locations.list</code></p>
<p><code translate="no" dir="ltr">certificatemanager.observedcerts.list</code></p>
<p><code translate="no" dir="ltr">certificatemanager.operations.list</code></p>
<p><code translate="no" dir="ltr">certificatemanager.trustconfigs.list</code></p>
<p><code translate="no" dir="ltr">ces.agents.list</code></p>
<p><code translate="no" dir="ltr">ces.appVersions.list</code></p>
<p><code translate="no" dir="ltr">ces.apps.list</code></p>
<p><code translate="no" dir="ltr">ces.assistantSessions.list</code></p>
<p><code translate="no" dir="ltr">ces.changelogs.list</code></p>
<p><code translate="no" dir="ltr">ces.conversations.list</code></p>
<p><code translate="no" dir="ltr">ces.deployments.list</code></p>
<p><code translate="no" dir="ltr">ces.evaluationDatasets.list</code></p>
<p><code translate="no" dir="ltr">ces.evaluationExpectations.list</code></p>
<p><code translate="no" dir="ltr">ces.evaluationResults.list</code></p>
<p><code translate="no" dir="ltr">ces.evaluationRuns.list</code></p>
<p><code translate="no" dir="ltr">ces.evaluations.list</code></p>
<p><code translate="no" dir="ltr">ces.examples.list</code></p>
<p><code translate="no" dir="ltr">ces.guardrails.list</code></p>
<p><code translate="no" dir="ltr">ces.locations.list</code></p>
<p><code translate="no" dir="ltr">ces.operations.list</code></p>
<p><code translate="no" dir="ltr">ces.tools.list</code></p>
<p><code translate="no" dir="ltr">ces.toolsets.list</code></p>
<p><code translate="no" dir="ltr">chronicle.analyticValues.list</code></p>
<p><code translate="no" dir="ltr">chronicle.analytics.list</code></p>
<p><code translate="no" dir="ltr">chronicle.chatSessionMessages.list</code></p>
<p><code translate="no" dir="ltr">chronicle.chatSessions.list</code></p>
<p><code translate="no" dir="ltr">chronicle.collectors.list</code></p>
<p><code translate="no" dir="ltr">chronicle.conversations.list</code></p>
<p><code translate="no" dir="ltr">chronicle.coverageDetails.list</code></p>
<p><code translate="no" dir="ltr">chronicle.curatedRuleSetCategories.list</code></p>
<p><code translate="no" dir="ltr">chronicle.curatedRuleSetDeployments.list</code></p>
<p><code translate="no" dir="ltr">chronicle.curatedRuleSets.list</code></p>
<p><code translate="no" dir="ltr">chronicle.curatedRules.list</code></p>
<p><code translate="no" dir="ltr">chronicle.dashboardCharts.list</code></p>
<p><code translate="no" dir="ltr">chronicle.dashboardQueries.list</code></p>
<p><code translate="no" dir="ltr">chronicle.dashboardScheduledReports.list</code></p>
<p><code translate="no" dir="ltr">chronicle.dashboards.list</code></p>
<p><code translate="no" dir="ltr">chronicle.dataAccessLabels.list</code></p>
<p><code translate="no" dir="ltr">chronicle.dataAccessScopes.list</code></p>
<p><code translate="no" dir="ltr">chronicle.dataExports.list</code></p>
<p><code translate="no" dir="ltr">chronicle.dataTableRows.list</code></p>
<p><code translate="no" dir="ltr">chronicle.dataTables.list</code></p>
<p><code translate="no" dir="ltr">chronicle.dataTaps.list</code></p>
<p><code translate="no" dir="ltr">chronicle.enrichmentControls.list</code></p>
<p><code translate="no" dir="ltr">chronicle.entities.list</code></p>
<p><code translate="no" dir="ltr">chronicle.extensionValidationReports.list</code></p>
<p><code translate="no" dir="ltr">chronicle.featuredContentNativeDashboards.list</code></p>
<p><code translate="no" dir="ltr">chronicle.featuredContentPlaybooks.list</code></p>
<p><code translate="no" dir="ltr">chronicle.featuredContentRules.list</code></p>
<p><code translate="no" dir="ltr">chronicle.featuredContentSearchQueries.list</code></p>
<p><code translate="no" dir="ltr">chronicle.features.list</code></p>
<p><code translate="no" dir="ltr">chronicle.federationGroups.list</code></p>
<p><code translate="no" dir="ltr">chronicle.feedPacks.list</code></p>
<p><code translate="no" dir="ltr">chronicle.feedSourceTypeSchemas.list</code></p>
<p><code translate="no" dir="ltr">chronicle.feeds.list</code></p>
<p><code translate="no" dir="ltr">chronicle.findingsRefinementDeployments.list</code></p>
<p><code translate="no" dir="ltr">chronicle.findingsRefinements.list</code></p>
<p><code translate="no" dir="ltr">chronicle.forwarders.list</code></p>
<p><code translate="no" dir="ltr">chronicle.ingestionLogLabels.list</code></p>
<p><code translate="no" dir="ltr">chronicle.ingestionLogNamespaces.list</code></p>
<p><code translate="no" dir="ltr">chronicle.investigationComments.list</code></p>
<p><code translate="no" dir="ltr">chronicle.investigationSteps.list</code></p>
<p><code translate="no" dir="ltr">chronicle.investigations.list</code></p>
<p><code translate="no" dir="ltr">chronicle.labsExperimentExecutions.list</code></p>
<p><code translate="no" dir="ltr">chronicle.labsExperiments.list</code></p>
<p><code translate="no" dir="ltr">chronicle.logProcessingPipelines.list</code></p>
<p><code translate="no" dir="ltr">chronicle.logTypeSchemas.list</code></p>
<p><code translate="no" dir="ltr">chronicle.logTypeSettings.list</code></p>
<p><code translate="no" dir="ltr">chronicle.logTypes.list</code></p>
<p><code translate="no" dir="ltr">chronicle.logs.list</code></p>
<p><code translate="no" dir="ltr">chronicle.messages.list</code></p>
<p><code translate="no" dir="ltr">chronicle.nativeDashboards.list</code></p>
<p><code translate="no" dir="ltr">chronicle.notebooks.list</code></p>
<p><code translate="no" dir="ltr">chronicle.operations.list</code></p>
<p><code translate="no" dir="ltr">chronicle.parserExtensions.list</code></p>
<p><code translate="no" dir="ltr">chronicle.parsers.list</code></p>
<p><code translate="no" dir="ltr">chronicle.parsingErrors.list</code></p>
<p><code translate="no" dir="ltr">chronicle.queryMetrics.list</code></p>
<p><code translate="no" dir="ltr">chronicle.referenceLists.list</code></p>
<p><code translate="no" dir="ltr">chronicle.retrohunts.list</code></p>
<p><code translate="no" dir="ltr">chronicle.ruleDeployments.list</code></p>
<p><code translate="no" dir="ltr">chronicle.ruleExecutionErrors.list</code></p>
<p><code translate="no" dir="ltr">chronicle.rules.list</code></p>
<p><code translate="no" dir="ltr">chronicle.savedColumnSets.list</code></p>
<p><code translate="no" dir="ltr">chronicle.searchQueries.list</code></p>
<p><code translate="no" dir="ltr">chronicle.searchedResults.list</code></p>
<p><code translate="no" dir="ltr">chronicle.sharedPreferenceSets.list</code></p>
<p><code translate="no" dir="ltr">chronicle.summaryTables.list</code></p>
<p><code translate="no" dir="ltr">chronicle.tagSubscriptions.list</code></p>
<p><code translate="no" dir="ltr">chronicle.tags.list</code></p>
<p><code translate="no" dir="ltr">chronicle.tenants.list</code></p>
<p><code translate="no" dir="ltr">chronicle.threatCollections.list</code></p>
<p><code translate="no" dir="ltr">chronicle.transformerDefinitions.list</code></p>
<p><code translate="no" dir="ltr">chronicle.validationErrors.list</code></p>
<p><code translate="no" dir="ltr">chronicle.watchlists.list</code></p>
<p><code translate="no" dir="ltr">chroniclesm.gcpAssociations.list</code></p>
<p><code translate="no" dir="ltr">chroniclesm.soarRoleScripts.list</code></p>
<p><code translate="no" dir="ltr">clientauthconfig.brands.list</code></p>
<p><code translate="no" dir="ltr">clientauthconfig.clients.list</code></p>
<p><code translate="no" dir="ltr">cloud.locations.list</code></p>
<p><code translate="no" dir="ltr">cloudaicompanion.aiDevToolsSettings.list</code></p>
<p><code translate="no" dir="ltr">cloudaicompanion.codeRepositoryIndexes.list</code></p>
<p><code translate="no" dir="ltr">cloudaicompanion.codeToolsSettings.list</code></p>
<p><code translate="no" dir="ltr">cloudaicompanion.dataSharingWithGoogleSettings.list</code></p>
<p><code translate="no" dir="ltr">cloudaicompanion.geminiGcpEnablementSettings.list</code></p>
<p><code translate="no" dir="ltr">cloudaicompanion.gibqObservabilitySettings.list</code></p>
<p><code translate="no" dir="ltr">cloudaicompanion.loggingSettings.list</code></p>
<p><code translate="no" dir="ltr">cloudaicompanion.operations.list</code></p>
<p><code translate="no" dir="ltr">cloudaicompanion.releaseChannelSettings.list</code></p>
<p><code translate="no" dir="ltr">cloudaicompanion.repositoryGroups.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudaicompanion.repositoryGroups.list</code></p>
<p><code translate="no" dir="ltr">cloudaicompanion.repositoryGroups.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudaicompanion.topics.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudaicompanion.topics.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudapiregistry.locations.list</code></p>
<p><code translate="no" dir="ltr">cloudapiregistry.mcpServers.list</code></p>
<p><code translate="no" dir="ltr">cloudapiregistry.mcpTools.list</code></p>
<p><code translate="no" dir="ltr">cloudasset.assets.searchAllResources</code></p>
<p><code translate="no" dir="ltr">cloudasset.feeds.list</code></p>
<p><code translate="no" dir="ltr">cloudasset.othercloudconnections.list</code></p>
<p><code translate="no" dir="ltr">cloudasset.savedqueries.list</code></p>
<p><code translate="no" dir="ltr">cloudbuild.builds.list</code></p>
<p><code translate="no" dir="ltr">cloudbuild.connections.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudbuild.connections.list</code></p>
<p><code translate="no" dir="ltr">cloudbuild.connections.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudbuild.integrations.list</code></p>
<p><code translate="no" dir="ltr">cloudbuild.locations.list</code></p>
<p><code translate="no" dir="ltr">cloudbuild.operations.list</code></p>
<p><code translate="no" dir="ltr">cloudbuild.repositories.list</code></p>
<p><code translate="no" dir="ltr">cloudbuild.workerpools.list</code></p>
<p><code translate="no" dir="ltr">cloudcontrolspartner.accessapprovalrequests.list</code></p>
<p><code translate="no" dir="ltr">cloudcontrolspartner.customers.list</code></p>
<p><code translate="no" dir="ltr">cloudcontrolspartner.violations.list</code></p>
<p><code translate="no" dir="ltr">cloudcontrolspartner.workloads.list</code></p>
<p><code translate="no" dir="ltr">clouddebugger.breakpoints.list</code></p>
<p><code translate="no" dir="ltr">clouddebugger.debuggees.list</code></p>
<p><code translate="no" dir="ltr">clouddeploy.automationRuns.list</code></p>
<p><code translate="no" dir="ltr">clouddeploy.automations.list</code></p>
<p><code translate="no" dir="ltr">clouddeploy.customTargetTypes.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">clouddeploy.customTargetTypes.list</code></p>
<p><code translate="no" dir="ltr">clouddeploy.customTargetTypes.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">clouddeploy.deliveryPipelines.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">clouddeploy.deliveryPipelines.list</code></p>
<p><code translate="no" dir="ltr">clouddeploy.deliveryPipelines.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">clouddeploy.deployPolicies.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">clouddeploy.deployPolicies.list</code></p>
<p><code translate="no" dir="ltr">clouddeploy.deployPolicies.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">clouddeploy.jobRuns.list</code></p>
<p><code translate="no" dir="ltr">clouddeploy.locations.list</code></p>
<p><code translate="no" dir="ltr">clouddeploy.operations.list</code></p>
<p><code translate="no" dir="ltr">clouddeploy.releases.list</code></p>
<p><code translate="no" dir="ltr">clouddeploy.rollouts.list</code></p>
<p><code translate="no" dir="ltr">clouddeploy.targets.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">clouddeploy.targets.list</code></p>
<p><code translate="no" dir="ltr">clouddeploy.targets.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudfunctions.functions.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudfunctions.functions.list</code></p>
<p><code translate="no" dir="ltr">cloudfunctions.functions.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudfunctions.locations.list</code></p>
<p><code translate="no" dir="ltr">cloudfunctions.operations.list</code></p>
<p><code translate="no" dir="ltr">cloudjobdiscovery.companies.list</code></p>
<p><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.list</code></p>
<p><code translate="no" dir="ltr">cloudkms.cryptoKeys.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudkms.cryptoKeys.list</code></p>
<p><code translate="no" dir="ltr">cloudkms.cryptoKeys.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudkms.ekmConfigs.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudkms.ekmConfigs.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudkms.ekmConnections.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudkms.ekmConnections.list</code></p>
<p><code translate="no" dir="ltr">cloudkms.ekmConnections.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudkms.importJobs.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudkms.importJobs.list</code></p>
<p><code translate="no" dir="ltr">cloudkms.importJobs.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudkms.keyHandles.list</code></p>
<p><code translate="no" dir="ltr">cloudkms.keyRings.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudkms.keyRings.list</code></p>
<p><code translate="no" dir="ltr">cloudkms.keyRings.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudkms.locations.list</code></p>
<p><code translate="no" dir="ltr">cloudkms.protectableResources.list</code></p>
<p><code translate="no" dir="ltr">cloudkms.retiredResources.list</code></p>
<p><code translate="no" dir="ltr">cloudkms.singleTenantHsmInstanceProposals.list</code></p>
<p><code translate="no" dir="ltr">cloudkms.singleTenantHsmInstances.list</code></p>
<p><code translate="no" dir="ltr">cloudlocationfinder.cloudLocations.list</code></p>
<p><code translate="no" dir="ltr">cloudlocationfinder.locations.list</code></p>
<p><code translate="no" dir="ltr">cloudmessaging.topicSubscriptions.list</code></p>
<p><code translate="no" dir="ltr">cloudnotifications.activities.list</code></p>
<p><code translate="no" dir="ltr">cloudnumberregistry.customRanges.list</code></p>
<p><code translate="no" dir="ltr">cloudnumberregistry.discoveredRanges.list</code></p>
<p><code translate="no" dir="ltr">cloudnumberregistry.ipamAdminScopes.list</code></p>
<p><code translate="no" dir="ltr">cloudnumberregistry.locations.list</code></p>
<p><code translate="no" dir="ltr">cloudnumberregistry.operations.list</code></p>
<p><code translate="no" dir="ltr">cloudnumberregistry.realms.list</code></p>
<p><code translate="no" dir="ltr">cloudnumberregistry.registryBooks.list</code></p>
<p><code translate="no" dir="ltr">cloudonefs.isiloncloud.com/clusters.list</code></p>
<p><code translate="no" dir="ltr">cloudonefs.isiloncloud.com/fileshares.list</code></p>
<p><code translate="no" dir="ltr">cloudprivatecatalogproducer.associations.list</code></p>
<p><code translate="no" dir="ltr">cloudprivatecatalogproducer.catalogAssociations.list</code></p>
<p><code translate="no" dir="ltr">cloudprivatecatalogproducer.catalogs.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudprivatecatalogproducer.catalogs.list</code></p>
<p><code translate="no" dir="ltr">cloudprivatecatalogproducer.catalogs.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudprivatecatalogproducer.producerCatalogs.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudprivatecatalogproducer.producerCatalogs.list</code></p>
<p><code translate="no" dir="ltr">cloudprivatecatalogproducer.producerCatalogs.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudprivatecatalogproducer.products.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudprivatecatalogproducer.products.list</code></p>
<p><code translate="no" dir="ltr">cloudprivatecatalogproducer.products.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudprofiler.profiles.list</code></p>
<p><code translate="no" dir="ltr">cloudscheduler.jobs.list</code></p>
<p><code translate="no" dir="ltr">cloudscheduler.locations.list</code></p>
<p><code translate="no" dir="ltr">cloudsecuritycompliance.auditReports.list</code></p>
<p><code translate="no" dir="ltr">cloudsecuritycompliance.cloudControlDeployments.list</code></p>
<p><code translate="no" dir="ltr">cloudsecuritycompliance.cloudControlPredictions.list</code></p>
<p><code translate="no" dir="ltr">cloudsecuritycompliance.cloudControls.list</code></p>
<p><code translate="no" dir="ltr">cloudsecuritycompliance.controlComplianceSummaries.list</code></p>
<p><code translate="no" dir="ltr">cloudsecuritycompliance.controls.list</code></p>
<p><code translate="no" dir="ltr">cloudsecuritycompliance.findingSummaries.list</code></p>
<p><code translate="no" dir="ltr">cloudsecuritycompliance.findings.list</code></p>
<p><code translate="no" dir="ltr">cloudsecuritycompliance.frameworkAudits.list</code></p>
<p><code translate="no" dir="ltr">cloudsecuritycompliance.frameworkComplianceSummaries.list</code></p>
<p><code translate="no" dir="ltr">cloudsecuritycompliance.frameworkDeployments.list</code></p>
<p><code translate="no" dir="ltr">cloudsecuritycompliance.frameworks.list</code></p>
<p><code translate="no" dir="ltr">cloudsecuritycompliance.locations.list</code></p>
<p><code translate="no" dir="ltr">cloudsecuritycompliance.operations.list</code></p>
<p><code translate="no" dir="ltr">cloudsecuritycompliance.resourceEnrollmentStatuses.list</code></p>
<p><code translate="no" dir="ltr">cloudsecurityscanner.crawledurls.list</code></p>
<p><code translate="no" dir="ltr">cloudsecurityscanner.results.list</code></p>
<p><code translate="no" dir="ltr">cloudsecurityscanner.scanruns.list</code></p>
<p><code translate="no" dir="ltr">cloudsecurityscanner.scans.list</code></p>
<p><code translate="no" dir="ltr">cloudsql.backupRuns.list</code></p>
<p><code translate="no" dir="ltr">cloudsql.blueGreenDeployments.list</code></p>
<p><code translate="no" dir="ltr">cloudsql.databases.list</code></p>
<p><code translate="no" dir="ltr">cloudsql.instances.list</code></p>
<p><code translate="no" dir="ltr">cloudsql.sslCerts.list</code></p>
<p><code translate="no" dir="ltr">cloudsql.users.list</code></p>
<p><code translate="no" dir="ltr">cloudsql.workloadCaptures.list</code></p>
<p><code translate="no" dir="ltr">cloudsupport.accounts.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudsupport.accounts.list</code></p>
<p><code translate="no" dir="ltr">cloudsupport.accounts.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudsupport.techCases.list</code></p>
<p><code translate="no" dir="ltr">cloudtasks.locations.list</code></p>
<p><code translate="no" dir="ltr">cloudtasks.queues.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudtasks.queues.list</code></p>
<p><code translate="no" dir="ltr">cloudtasks.queues.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudtasks.tasks.list</code></p>
<p><code translate="no" dir="ltr">cloudtestservice.devicesession.list</code></p>
<p><code translate="no" dir="ltr">cloudtoolresults.executions.list</code></p>
<p><code translate="no" dir="ltr">cloudtoolresults.histories.list</code></p>
<p><code translate="no" dir="ltr">cloudtoolresults.steps.list</code></p>
<p><code translate="no" dir="ltr">cloudtrace.insights.list</code></p>
<p><code translate="no" dir="ltr">cloudtrace.tasks.list</code></p>
<p><code translate="no" dir="ltr">cloudtrace.traceScopes.list</code></p>
<p><code translate="no" dir="ltr">cloudtrace.traces.list</code></p>
<p><code translate="no" dir="ltr">cloudtranslate.adaptiveMtDatasets.list</code></p>
<p><code translate="no" dir="ltr">cloudtranslate.adaptiveMtFiles.list</code></p>
<p><code translate="no" dir="ltr">cloudtranslate.adaptiveMtSentences.list</code></p>
<p><code translate="no" dir="ltr">cloudtranslate.customModels.list</code></p>
<p><code translate="no" dir="ltr">cloudtranslate.datasets.list</code></p>
<p><code translate="no" dir="ltr">cloudtranslate.glossaries.list</code></p>
<p><code translate="no" dir="ltr">cloudtranslate.glossaryentries.list</code></p>
<p><code translate="no" dir="ltr">cloudtranslate.locations.list</code></p>
<p><code translate="no" dir="ltr">cloudtranslate.operations.list</code></p>
<p><code translate="no" dir="ltr">cloudvolumesgcp-api.netapp.com/activeDirectories.list</code></p>
<p><code translate="no" dir="ltr">cloudvolumesgcp-api.netapp.com/ipRanges.list</code></p>
<p><code translate="no" dir="ltr">cloudvolumesgcp-api.netapp.com/jobs.list</code></p>
<p><code translate="no" dir="ltr">cloudvolumesgcp-api.netapp.com/regions.list</code></p>
<p><code translate="no" dir="ltr">cloudvolumesgcp-api.netapp.com/serviceLevels.list</code></p>
<p><code translate="no" dir="ltr">cloudvolumesgcp-api.netapp.com/snapshots.list</code></p>
<p><code translate="no" dir="ltr">cloudvolumesgcp-api.netapp.com/volumereplication.list</code></p>
<p><code translate="no" dir="ltr">cloudvolumesgcp-api.netapp.com/volumes.list</code></p>
<p><code translate="no" dir="ltr">commerceagreementpublishing.agreements.list</code></p>
<p><code translate="no" dir="ltr">commerceagreementpublishing.documents.list</code></p>
<p><code translate="no" dir="ltr">commercebusinessenablement.operations.list</code></p>
<p><code translate="no" dir="ltr">commercebusinessenablement.partnerAccounts.list</code></p>
<p><code translate="no" dir="ltr">commercebusinessenablement.refunds.list</code></p>
<p><code translate="no" dir="ltr">commercebusinessenablement.resellerDiscountOffers.list</code></p>
<p><code translate="no" dir="ltr">commercebusinessenablement.resellerPrivateOfferPlans.list</code></p>
<p><code translate="no" dir="ltr">commercebusinessenablement.resellerRestrictions.list</code></p>
<p><code translate="no" dir="ltr">commerceoffercatalog.agreements.list</code></p>
<p><code translate="no" dir="ltr">commerceoffercatalog.documents.list</code></p>
<p><code translate="no" dir="ltr">commerceorggovernance.collectionRequestApprovals.list</code></p>
<p><code translate="no" dir="ltr">commerceorggovernance.collections.list</code></p>
<p><code translate="no" dir="ltr">commerceorggovernance.populateCollectionJobs.list</code></p>
<p><code translate="no" dir="ltr">commerceorggovernance.services.list</code></p>
<p><code translate="no" dir="ltr">commerceprice.events.list</code></p>
<p><code translate="no" dir="ltr">commerceprice.privateoffers.list</code></p>
<p><code translate="no" dir="ltr">commerceproducer.analyticsHubListingProductConfigs.list</code></p>
<p><code translate="no" dir="ltr">commerceproducer.consumerEnforcementActions.list</code></p>
<p><code translate="no" dir="ltr">commerceproducer.locations.list</code></p>
<p><code translate="no" dir="ltr">commerceproducer.privateOfferDocuments.list</code></p>
<p><code translate="no" dir="ltr">commerceproducer.privateOffers.list</code></p>
<p><code translate="no" dir="ltr">commerceproducer.products.list</code></p>
<p><code translate="no" dir="ltr">commerceproducer.releases.list</code></p>
<p><code translate="no" dir="ltr">commerceproducer.services.list</code></p>
<p><code translate="no" dir="ltr">commerceproducer.skuGroups.list</code></p>
<p><code translate="no" dir="ltr">commerceproducer.skus.list</code></p>
<p><code translate="no" dir="ltr">commerceproducer.standardOffers.list</code></p>
<p><code translate="no" dir="ltr">composer.dags.list</code></p>
<p><code translate="no" dir="ltr">composer.environments.list</code></p>
<p><code translate="no" dir="ltr">composer.imageversions.list</code></p>
<p><code translate="no" dir="ltr">composer.operations.list</code></p>
<p><code translate="no" dir="ltr">composer.userworkloadsconfigmaps.list</code></p>
<p><code translate="no" dir="ltr">composer.userworkloadssecrets.list</code></p>
<p><code translate="no" dir="ltr">compute.acceleratorTypes.list</code></p>
<p><code translate="no" dir="ltr">compute.addresses.list</code></p>
<p><code translate="no" dir="ltr">compute.autoscalers.list</code></p>
<p><code translate="no" dir="ltr">compute.backendBuckets.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.backendBuckets.list</code></p>
<p><code translate="no" dir="ltr">compute.backendBuckets.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.backendServices.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.backendServices.list</code></p>
<p><code translate="no" dir="ltr">compute.backendServices.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.commitments.list</code></p>
<p><code translate="no" dir="ltr">compute.crossSiteNetworks.list</code></p>
<p><code translate="no" dir="ltr">compute.diskTypes.list</code></p>
<p><code translate="no" dir="ltr">compute.disks.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.disks.list</code></p>
<p><code translate="no" dir="ltr">compute.disks.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.externalVpnGateways.list</code></p>
<p><code translate="no" dir="ltr">compute.firewallPolicies.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.firewallPolicies.list</code></p>
<p><code translate="no" dir="ltr">compute.firewallPolicies.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.firewalls.list</code></p>
<p><code translate="no" dir="ltr">compute.folderRolloutPlans.list</code></p>
<p><code translate="no" dir="ltr">compute.folderRollouts.list</code></p>
<p><code translate="no" dir="ltr">compute.folderVmExtensionPolicies.list</code></p>
<p><code translate="no" dir="ltr">compute.folderVmExtensions.list</code></p>
<p><code translate="no" dir="ltr">compute.forwardingRules.list</code></p>
<p><code translate="no" dir="ltr">compute.futureReservations.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.futureReservations.list</code></p>
<p><code translate="no" dir="ltr">compute.futureReservations.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.globalAddresses.list</code></p>
<p><code translate="no" dir="ltr">compute.globalForwardingRules.list</code></p>
<p><code translate="no" dir="ltr">compute.globalNetworkEndpointGroups.list</code></p>
<p><code translate="no" dir="ltr">compute.globalOperations.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.globalOperations.list</code></p>
<p><code translate="no" dir="ltr">compute.globalOperations.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.globalPublicDelegatedPrefixes.list</code></p>
<p><code translate="no" dir="ltr">compute.healthChecks.list</code></p>
<p><code translate="no" dir="ltr">compute.hosts.list</code></p>
<p><code translate="no" dir="ltr">compute.httpHealthChecks.list</code></p>
<p><code translate="no" dir="ltr">compute.httpsHealthChecks.list</code></p>
<p><code translate="no" dir="ltr">compute.images.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.images.list</code></p>
<p><code translate="no" dir="ltr">compute.images.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.instanceGroupManagers.list</code></p>
<p><code translate="no" dir="ltr">compute.instanceGroups.list</code></p>
<p><code translate="no" dir="ltr">compute.instanceTemplates.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.instanceTemplates.list</code></p>
<p><code translate="no" dir="ltr">compute.instanceTemplates.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.instances.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.instances.list</code></p>
<p><code translate="no" dir="ltr">compute.instances.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.instantSnapshotGroups.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.instantSnapshotGroups.list</code></p>
<p><code translate="no" dir="ltr">compute.instantSnapshotGroups.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.instantSnapshots.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.instantSnapshots.list</code></p>
<p><code translate="no" dir="ltr">compute.instantSnapshots.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.interconnectAttachmentGroups.list</code></p>
<p><code translate="no" dir="ltr">compute.interconnectAttachments.list</code></p>
<p><code translate="no" dir="ltr">compute.interconnectGroups.list</code></p>
<p><code translate="no" dir="ltr">compute.interconnectLocations.list</code></p>
<p><code translate="no" dir="ltr">compute.interconnectRemoteLocations.list</code></p>
<p><code translate="no" dir="ltr">compute.interconnects.list</code></p>
<p><code translate="no" dir="ltr">compute.licenseCodes.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.licenseCodes.list</code></p>
<p><code translate="no" dir="ltr">compute.licenseCodes.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.licenses.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.licenses.list</code></p>
<p><code translate="no" dir="ltr">compute.licenses.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.machineImages.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.machineImages.list</code></p>
<p><code translate="no" dir="ltr">compute.machineImages.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.machineTypes.list</code></p>
<p><code translate="no" dir="ltr">compute.managedRulesets.list</code></p>
<p><code translate="no" dir="ltr">compute.multiMig.list</code></p>
<p><code translate="no" dir="ltr">compute.multiMigMembers.list</code></p>
<p><code translate="no" dir="ltr">compute.networkAttachments.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.networkAttachments.list</code></p>
<p><code translate="no" dir="ltr">compute.networkAttachments.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.networkEdgeSecurityServices.list</code></p>
<p><code translate="no" dir="ltr">compute.networkEndpointGroups.list</code></p>
<p><code translate="no" dir="ltr">compute.networkProfiles.list</code></p>
<p><code translate="no" dir="ltr">compute.networks.list</code></p>
<p><code translate="no" dir="ltr">compute.nodeGroups.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.nodeGroups.list</code></p>
<p><code translate="no" dir="ltr">compute.nodeGroups.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.nodeTemplates.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.nodeTemplates.list</code></p>
<p><code translate="no" dir="ltr">compute.nodeTemplates.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.nodeTypes.list</code></p>
<p><code translate="no" dir="ltr">compute.orgRolloutPlans.list</code></p>
<p><code translate="no" dir="ltr">compute.orgRollouts.list</code></p>
<p><code translate="no" dir="ltr">compute.orgVmExtensionPolicies.list</code></p>
<p><code translate="no" dir="ltr">compute.orgVmExtensions.list</code></p>
<p><code translate="no" dir="ltr">compute.packetMirrorings.list</code></p>
<p><code translate="no" dir="ltr">compute.previewFeatures.list</code></p>
<p><code translate="no" dir="ltr">compute.publicAdvertisedPrefixes.list</code></p>
<p><code translate="no" dir="ltr">compute.publicDelegatedPrefixes.list</code></p>
<p><code translate="no" dir="ltr">compute.recoverableSnapshots.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.recoverableSnapshots.list</code></p>
<p><code translate="no" dir="ltr">compute.recoverableSnapshots.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.regionBackendBuckets.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.regionBackendBuckets.list</code></p>
<p><code translate="no" dir="ltr">compute.regionBackendBuckets.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.regionBackendServices.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.regionBackendServices.list</code></p>
<p><code translate="no" dir="ltr">compute.regionBackendServices.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.regionCompositeHealthChecks.list</code></p>
<p><code translate="no" dir="ltr">compute.regionFirewallPolicies.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.regionFirewallPolicies.list</code></p>
<p><code translate="no" dir="ltr">compute.regionFirewallPolicies.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.regionHealthAggregationPolicies.list</code></p>
<p><code translate="no" dir="ltr">compute.regionHealthCheckServices.list</code></p>
<p><code translate="no" dir="ltr">compute.regionHealthChecks.list</code></p>
<p><code translate="no" dir="ltr">compute.regionHealthSources.list</code></p>
<p><code translate="no" dir="ltr">compute.regionNetworkEndpointGroups.list</code></p>
<p><code translate="no" dir="ltr">compute.regionNetworkPolicies.list</code></p>
<p><code translate="no" dir="ltr">compute.regionNotificationEndpoints.list</code></p>
<p><code translate="no" dir="ltr">compute.regionOperations.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.regionOperations.list</code></p>
<p><code translate="no" dir="ltr">compute.regionOperations.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.regionSecurityPolicies.list</code></p>
<p><code translate="no" dir="ltr">compute.regionSslCertificates.list</code></p>
<p><code translate="no" dir="ltr">compute.regionSslPolicies.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.regionSslPolicies.list</code></p>
<p><code translate="no" dir="ltr">compute.regionSslPolicies.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.regionTargetHttpProxies.list</code></p>
<p><code translate="no" dir="ltr">compute.regionTargetHttpsProxies.list</code></p>
<p><code translate="no" dir="ltr">compute.regionTargetTcpProxies.list</code></p>
<p><code translate="no" dir="ltr">compute.regionUrlMaps.list</code></p>
<p><code translate="no" dir="ltr">compute.regions.list</code></p>
<p><code translate="no" dir="ltr">compute.reliabilityRisks.list</code></p>
<p><code translate="no" dir="ltr">compute.reservationBlocks.list</code></p>
<p><code translate="no" dir="ltr">compute.reservationConsumedInstances.list</code></p>
<p><code translate="no" dir="ltr">compute.reservationSlots.list</code></p>
<p><code translate="no" dir="ltr">compute.reservationSubBlocks.list</code></p>
<p><code translate="no" dir="ltr">compute.reservations.list</code></p>
<p><code translate="no" dir="ltr">compute.resourcePolicies.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.resourcePolicies.list</code></p>
<p><code translate="no" dir="ltr">compute.resourcePolicies.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.rolloutPlans.list</code></p>
<p><code translate="no" dir="ltr">compute.rollouts.list</code></p>
<p><code translate="no" dir="ltr">compute.routers.list</code></p>
<p><code translate="no" dir="ltr">compute.routes.list</code></p>
<p><code translate="no" dir="ltr">compute.securityPolicies.list</code></p>
<p><code translate="no" dir="ltr">compute.serviceAttachments.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.serviceAttachments.list</code></p>
<p><code translate="no" dir="ltr">compute.serviceAttachments.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.snapshotGroups.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.snapshotGroups.list</code></p>
<p><code translate="no" dir="ltr">compute.snapshotGroups.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.snapshots.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.snapshots.list</code></p>
<p><code translate="no" dir="ltr">compute.snapshots.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.sslCertificates.list</code></p>
<p><code translate="no" dir="ltr">compute.sslPolicies.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.sslPolicies.list</code></p>
<p><code translate="no" dir="ltr">compute.sslPolicies.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.storagePools.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.storagePools.list</code></p>
<p><code translate="no" dir="ltr">compute.storagePools.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.subnetworks.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.subnetworks.list</code></p>
<p><code translate="no" dir="ltr">compute.subnetworks.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.targetGrpcProxies.list</code></p>
<p><code translate="no" dir="ltr">compute.targetHttpProxies.list</code></p>
<p><code translate="no" dir="ltr">compute.targetHttpsProxies.list</code></p>
<p><code translate="no" dir="ltr">compute.targetInstances.list</code></p>
<p><code translate="no" dir="ltr">compute.targetPools.list</code></p>
<p><code translate="no" dir="ltr">compute.targetSslProxies.list</code></p>
<p><code translate="no" dir="ltr">compute.targetTcpProxies.list</code></p>
<p><code translate="no" dir="ltr">compute.targetVpnGateways.list</code></p>
<p><code translate="no" dir="ltr">compute.urlMaps.list</code></p>
<p><code translate="no" dir="ltr">compute.vmExtensionPolicies.list</code></p>
<p><code translate="no" dir="ltr">compute.vmExtensions.list</code></p>
<p><code translate="no" dir="ltr">compute.vpnGateways.list</code></p>
<p><code translate="no" dir="ltr">compute.vpnTunnels.list</code></p>
<p><code translate="no" dir="ltr">compute.wireGroups.list</code></p>
<p><code translate="no" dir="ltr">compute.zoneOperations.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.zoneOperations.list</code></p>
<p><code translate="no" dir="ltr">compute.zoneOperations.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.zones.list</code></p>
<p><code translate="no" dir="ltr">confidentialcomputing.locations.list</code></p>
<p><code translate="no" dir="ltr">config.deploymentgrouprevisions.list</code></p>
<p><code translate="no" dir="ltr">config.deploymentgroups.list</code></p>
<p><code translate="no" dir="ltr">config.deployments.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">config.deployments.list</code></p>
<p><code translate="no" dir="ltr">config.deployments.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">config.locations.list</code></p>
<p><code translate="no" dir="ltr">config.operations.list</code></p>
<p><code translate="no" dir="ltr">config.previews.list</code></p>
<p><code translate="no" dir="ltr">config.resourcechanges.list</code></p>
<p><code translate="no" dir="ltr">config.resourcedrifts.list</code></p>
<p><code translate="no" dir="ltr">config.resources.list</code></p>
<p><code translate="no" dir="ltr">config.revisions.list</code></p>
<p><code translate="no" dir="ltr">config.terraformversions.list</code></p>
<p><code translate="no" dir="ltr">configdelivery.fleetPackages.list</code></p>
<p><code translate="no" dir="ltr">configdelivery.locations.list</code></p>
<p><code translate="no" dir="ltr">configdelivery.operations.list</code></p>
<p><code translate="no" dir="ltr">configdelivery.releases.list</code></p>
<p><code translate="no" dir="ltr">configdelivery.resourceBundles.list</code></p>
<p><code translate="no" dir="ltr">configdelivery.rollouts.list</code></p>
<p><code translate="no" dir="ltr">configdelivery.variants.list</code></p>
<p><code translate="no" dir="ltr">connectors.actions.list</code></p>
<p><code translate="no" dir="ltr">connectors.connections.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">connectors.connections.list</code></p>
<p><code translate="no" dir="ltr">connectors.connections.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">connectors.connectors.list</code></p>
<p><code translate="no" dir="ltr">connectors.customConnectorVersions.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">connectors.customConnectorVersions.list</code></p>
<p><code translate="no" dir="ltr">connectors.customConnectorVersions.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">connectors.customConnectors.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">connectors.customConnectors.list</code></p>
<p><code translate="no" dir="ltr">connectors.customConnectors.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">connectors.endpointAttachments.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">connectors.endpointAttachments.list</code></p>
<p><code translate="no" dir="ltr">connectors.endpointAttachments.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">connectors.entities.list</code></p>
<p><code translate="no" dir="ltr">connectors.entityTypes.list</code></p>
<p><code translate="no" dir="ltr">connectors.eventSubscriptions.list</code></p>
<p><code translate="no" dir="ltr">connectors.eventtypes.list</code></p>
<p><code translate="no" dir="ltr">connectors.locations.list</code></p>
<p><code translate="no" dir="ltr">connectors.managedZones.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">connectors.managedZones.list</code></p>
<p><code translate="no" dir="ltr">connectors.managedZones.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">connectors.operations.list</code></p>
<p><code translate="no" dir="ltr">connectors.providers.list</code></p>
<p><code translate="no" dir="ltr">connectors.versions.list</code></p>
<p><code translate="no" dir="ltr">consumerprocurement.accounts.list</code></p>
<p><code translate="no" dir="ltr">consumerprocurement.consents.list</code></p>
<p><code translate="no" dir="ltr">consumerprocurement.entitlements.list</code></p>
<p><code translate="no" dir="ltr">consumerprocurement.events.list</code></p>
<p><code translate="no" dir="ltr">consumerprocurement.freeTrials.list</code></p>
<p><code translate="no" dir="ltr">consumerprocurement.orderAttributions.list</code></p>
<p><code translate="no" dir="ltr">consumerprocurement.orders.list</code></p>
<p><code translate="no" dir="ltr">contactcenteraiplatform.contactCenters.list</code></p>
<p><code translate="no" dir="ltr">contactcenteraiplatform.locations.list</code></p>
<p><code translate="no" dir="ltr">contactcenteraiplatform.operations.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.analyses.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.analysisRules.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.assessmentRules.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.assessments.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.authorizedAnalyses.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.authorizedAssessments.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.authorizedConversations.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.authorizedFeedbackLabels.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.authorizedNotes.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.authorizedOperations.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.authorizedViewSets.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.authorizedViews.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.authorizedViews.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.authorizedViews.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.conversations.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.datasetAnalyses.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.datasetConversations.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.datasetFeedbackLabels.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.datasets.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.diagnostics.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.discoveries.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.discoveryResults.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.discoveryRevisions.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.discoveryWorkspaces.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.faqEntries.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.faqModels.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.feedbackLabels.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.issueModels.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.issues.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.notes.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.operations.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.phraseMatchers.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.qaQuestionTags.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.qaQuestions.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.qaScorecardRevisions.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.qaScorecards.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.views.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.visibilityLabels.list</code></p>
<p><code translate="no" dir="ltr">container.apiServices.list</code></p>
<p><code translate="no" dir="ltr">container.auditSinks.list</code></p>
<p><code translate="no" dir="ltr">container.backendConfigs.list</code></p>
<p><code translate="no" dir="ltr">container.bindings.list</code></p>
<p><code translate="no" dir="ltr">container.certificateSigningRequests.list</code></p>
<p><code translate="no" dir="ltr">container.clusterRoleBindings.list</code></p>
<p><code translate="no" dir="ltr">container.clusterRoles.list</code></p>
<p><code translate="no" dir="ltr">container.clusters.list</code></p>
<p><code translate="no" dir="ltr">container.componentStatuses.list</code></p>
<p><code translate="no" dir="ltr">container.configMaps.list</code></p>
<p><code translate="no" dir="ltr">container.controllerRevisions.list</code></p>
<p><code translate="no" dir="ltr">container.cronJobs.list</code></p>
<p><code translate="no" dir="ltr">container.csiDrivers.list</code></p>
<p><code translate="no" dir="ltr">container.csiNodeInfos.list</code></p>
<p><code translate="no" dir="ltr">container.csiNodes.list</code></p>
<p><code translate="no" dir="ltr">container.customResourceDefinitions.list</code></p>
<p><code translate="no" dir="ltr">container.daemonSets.list</code></p>
<p><code translate="no" dir="ltr">container.deployments.list</code></p>
<p><code translate="no" dir="ltr">container.endpointSlices.list</code></p>
<p><code translate="no" dir="ltr">container.endpoints.list</code></p>
<p><code translate="no" dir="ltr">container.events.list</code></p>
<p><code translate="no" dir="ltr">container.frontendConfigs.list</code></p>
<p><code translate="no" dir="ltr">container.horizontalPodAutoscalers.list</code></p>
<p><code translate="no" dir="ltr">container.ingresses.list</code></p>
<p><code translate="no" dir="ltr">container.initializerConfigurations.list</code></p>
<p><code translate="no" dir="ltr">container.jobs.list</code></p>
<p><code translate="no" dir="ltr">container.leases.list</code></p>
<p><code translate="no" dir="ltr">container.limitRanges.list</code></p>
<p><code translate="no" dir="ltr">container.localSubjectAccessReviews.list</code></p>
<p><code translate="no" dir="ltr">container.managedCertificates.list</code></p>
<p><code translate="no" dir="ltr">container.mutatingWebhookConfigurations.list</code></p>
<p><code translate="no" dir="ltr">container.namespaces.list</code></p>
<p><code translate="no" dir="ltr">container.networkPolicies.list</code></p>
<p><code translate="no" dir="ltr">container.nodes.list</code></p>
<p><code translate="no" dir="ltr">container.operations.list</code></p>
<p><code translate="no" dir="ltr">container.persistentVolumeClaims.list</code></p>
<p><code translate="no" dir="ltr">container.persistentVolumes.list</code></p>
<p><code translate="no" dir="ltr">container.petSets.list</code></p>
<p><code translate="no" dir="ltr">container.podDisruptionBudgets.list</code></p>
<p><code translate="no" dir="ltr">container.podPresets.list</code></p>
<p><code translate="no" dir="ltr">container.podSecurityPolicies.list</code></p>
<p><code translate="no" dir="ltr">container.podTemplates.list</code></p>
<p><code translate="no" dir="ltr">container.pods.list</code></p>
<p><code translate="no" dir="ltr">container.priorityClasses.list</code></p>
<p><code translate="no" dir="ltr">container.replicaSets.list</code></p>
<p><code translate="no" dir="ltr">container.replicationControllers.list</code></p>
<p><code translate="no" dir="ltr">container.resourceQuotas.list</code></p>
<p><code translate="no" dir="ltr">container.roleBindings.list</code></p>
<p><code translate="no" dir="ltr">container.roles.list</code></p>
<p><code translate="no" dir="ltr">container.runtimeClasses.list</code></p>
<p><code translate="no" dir="ltr">container.scheduledJobs.list</code></p>
<p><code translate="no" dir="ltr">container.selfSubjectAccessReviews.list</code></p>
<p><code translate="no" dir="ltr">container.serviceAccounts.list</code></p>
<p><code translate="no" dir="ltr">container.services.list</code></p>
<p><code translate="no" dir="ltr">container.statefulSets.list</code></p>
<p><code translate="no" dir="ltr">container.storageClasses.list</code></p>
<p><code translate="no" dir="ltr">container.storageStates.list</code></p>
<p><code translate="no" dir="ltr">container.storageVersionMigrations.list</code></p>
<p><code translate="no" dir="ltr">container.subjectAccessReviews.list</code></p>
<p><code translate="no" dir="ltr">container.thirdPartyObjects.list</code></p>
<p><code translate="no" dir="ltr">container.thirdPartyResources.list</code></p>
<p><code translate="no" dir="ltr">container.updateInfos.list</code></p>
<p><code translate="no" dir="ltr">container.validatingWebhookConfigurations.list</code></p>
<p><code translate="no" dir="ltr">container.volumeAttachments.list</code></p>
<p><code translate="no" dir="ltr">container.volumeSnapshotClasses.list</code></p>
<p><code translate="no" dir="ltr">container.volumeSnapshotContents.list</code></p>
<p><code translate="no" dir="ltr">container.volumeSnapshots.list</code></p>
<p><code translate="no" dir="ltr">containeranalysis.notes.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">containeranalysis.notes.list</code></p>
<p><code translate="no" dir="ltr">containeranalysis.notes.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">containeranalysis.occurrences.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">containeranalysis.occurrences.list</code></p>
<p><code translate="no" dir="ltr">containeranalysis.occurrences.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">containersecurity.clusterSummaries.list</code></p>
<p><code translate="no" dir="ltr">containersecurity.findings.list</code></p>
<p><code translate="no" dir="ltr">containersecurity.locations.list</code></p>
<p><code translate="no" dir="ltr">contentwarehouse.corpora.list</code></p>
<p><code translate="no" dir="ltr">contentwarehouse.documentSchemas.list</code></p>
<p><code translate="no" dir="ltr">contentwarehouse.documents.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">contentwarehouse.documents.list</code></p>
<p><code translate="no" dir="ltr">contentwarehouse.documents.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">contentwarehouse.ruleSets.list</code></p>
<p><code translate="no" dir="ltr">contentwarehouse.synonymSets.list</code></p>
<p><code translate="no" dir="ltr">databasecenter.databaseGroups.list</code></p>
<p><code translate="no" dir="ltr">databasecenter.fleetHealthStats.list</code></p>
<p><code translate="no" dir="ltr">databasecenter.fleetInsights.list</code></p>
<p><code translate="no" dir="ltr">databasecenter.fleetStats.list</code></p>
<p><code translate="no" dir="ltr">databasecenter.locations.list</code></p>
<p><code translate="no" dir="ltr">databasecenter.products.list</code></p>
<p><code translate="no" dir="ltr">databasecenter.queryStats.list</code></p>
<p><code translate="no" dir="ltr">databasecenter.reportConfigs.list</code></p>
<p><code translate="no" dir="ltr">databasecenter.userLabels.list</code></p>
<p><code translate="no" dir="ltr">databasecenter.userTags.list</code></p>
<p><code translate="no" dir="ltr">databaseinsights.locations.list</code></p>
<p><code translate="no" dir="ltr">databasesconsole.locations.list</code></p>
<p><code translate="no" dir="ltr">databasesconsole.operations.list</code></p>
<p><code translate="no" dir="ltr">databasesconsole.studioQueries.list</code></p>
<p><code translate="no" dir="ltr">datacatalog.categories.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">datacatalog.categories.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">datacatalog.entries.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">datacatalog.entries.list</code></p>
<p><code translate="no" dir="ltr">datacatalog.entries.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">datacatalog.entryGroups.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">datacatalog.entryGroups.list</code></p>
<p><code translate="no" dir="ltr">datacatalog.entryGroups.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">datacatalog.operations.list</code></p>
<p><code translate="no" dir="ltr">datacatalog.relationships.list</code></p>
<p><code translate="no" dir="ltr">datacatalog.tagTemplates.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">datacatalog.tagTemplates.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">datacatalog.taxonomies.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">datacatalog.taxonomies.list</code></p>
<p><code translate="no" dir="ltr">datacatalog.taxonomies.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataconnectors.connectors.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataconnectors.connectors.list</code></p>
<p><code translate="no" dir="ltr">dataconnectors.connectors.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataconnectors.locations.list</code></p>
<p><code translate="no" dir="ltr">dataconnectors.operations.list</code></p>
<p><code translate="no" dir="ltr">dataflow.jobs.list</code></p>
<p><code translate="no" dir="ltr">dataflow.messages.list</code></p>
<p><code translate="no" dir="ltr">dataflow.snapshots.list</code></p>
<p><code translate="no" dir="ltr">dataform.commentThreads.list</code></p>
<p><code translate="no" dir="ltr">dataform.comments.list</code></p>
<p><code translate="no" dir="ltr">dataform.compilationResults.list</code></p>
<p><code translate="no" dir="ltr">dataform.folders.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataform.folders.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataform.locations.list</code></p>
<p><code translate="no" dir="ltr">dataform.operations.list</code></p>
<p><code translate="no" dir="ltr">dataform.releaseConfigs.list</code></p>
<p><code translate="no" dir="ltr">dataform.repositories.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataform.repositories.list</code></p>
<p><code translate="no" dir="ltr">dataform.repositories.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataform.teamFolders.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataform.teamFolders.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataform.workflowConfigs.list</code></p>
<p><code translate="no" dir="ltr">dataform.workflowInvocations.list</code></p>
<p><code translate="no" dir="ltr">dataform.workspaces.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataform.workspaces.list</code></p>
<p><code translate="no" dir="ltr">dataform.workspaces.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">datafusion.artifacts.list</code></p>
<p><code translate="no" dir="ltr">datafusion.instances.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">datafusion.instances.list</code></p>
<p><code translate="no" dir="ltr">datafusion.instances.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">datafusion.locations.list</code></p>
<p><code translate="no" dir="ltr">datafusion.namespaces.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">datafusion.namespaces.list</code></p>
<p><code translate="no" dir="ltr">datafusion.namespaces.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">datafusion.operations.list</code></p>
<p><code translate="no" dir="ltr">datafusion.pipelineConnections.list</code></p>
<p><code translate="no" dir="ltr">datafusion.pipelines.list</code></p>
<p><code translate="no" dir="ltr">datafusion.profiles.list</code></p>
<p><code translate="no" dir="ltr">datafusion.secureKeys.list</code></p>
<p><code translate="no" dir="ltr">datalabeling.annotateddatasets.list</code></p>
<p><code translate="no" dir="ltr">datalabeling.annotationspecsets.list</code></p>
<p><code translate="no" dir="ltr">datalabeling.dataitems.list</code></p>
<p><code translate="no" dir="ltr">datalabeling.datasets.list</code></p>
<p><code translate="no" dir="ltr">datalabeling.examples.list</code></p>
<p><code translate="no" dir="ltr">datalabeling.instructions.list</code></p>
<p><code translate="no" dir="ltr">datalabeling.operations.list</code></p>
<p><code translate="no" dir="ltr">datalineage.events.list</code></p>
<p><code translate="no" dir="ltr">datalineage.processRevisions.list</code></p>
<p><code translate="no" dir="ltr">datalineage.processes.list</code></p>
<p><code translate="no" dir="ltr">datalineage.runs.list</code></p>
<p><code translate="no" dir="ltr">datamigration.connectionprofiles.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">datamigration.connectionprofiles.list</code></p>
<p><code translate="no" dir="ltr">datamigration.connectionprofiles.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">datamigration.conversionworkspaces.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">datamigration.conversionworkspaces.list</code></p>
<p><code translate="no" dir="ltr">datamigration.conversionworkspaces.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">datamigration.locations.list</code></p>
<p><code translate="no" dir="ltr">datamigration.mappingrules.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">datamigration.mappingrules.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">datamigration.migrationjobs.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">datamigration.migrationjobs.list</code></p>
<p><code translate="no" dir="ltr">datamigration.migrationjobs.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">datamigration.objects.list</code></p>
<p><code translate="no" dir="ltr">datamigration.operations.list</code></p>
<p><code translate="no" dir="ltr">datamigration.privateconnections.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">datamigration.privateconnections.list</code></p>
<p><code translate="no" dir="ltr">datamigration.privateconnections.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">datapipelines.jobs.list</code></p>
<p><code translate="no" dir="ltr">datapipelines.pipelines.list</code></p>
<p><code translate="no" dir="ltr">dataplex.agentTasks.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.agentTasks.list</code></p>
<p><code translate="no" dir="ltr">dataplex.agentTasks.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.aspectTypes.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.aspectTypes.list</code></p>
<p><code translate="no" dir="ltr">dataplex.aspectTypes.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.assetActions.list</code></p>
<p><code translate="no" dir="ltr">dataplex.assets.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.assets.list</code></p>
<p><code translate="no" dir="ltr">dataplex.assets.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.changeRequests.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.changeRequests.list</code></p>
<p><code translate="no" dir="ltr">dataplex.changeRequests.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.content.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.content.list</code></p>
<p><code translate="no" dir="ltr">dataplex.content.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.dataAssets.list</code></p>
<p><code translate="no" dir="ltr">dataplex.dataAttributeBindings.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.dataAttributeBindings.list</code></p>
<p><code translate="no" dir="ltr">dataplex.dataAttributeBindings.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.dataAttributes.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.dataAttributes.list</code></p>
<p><code translate="no" dir="ltr">dataplex.dataAttributes.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.dataDomainBindings.list</code></p>
<p><code translate="no" dir="ltr">dataplex.dataDomains.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.dataDomains.list</code></p>
<p><code translate="no" dir="ltr">dataplex.dataDomains.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.dataProducts.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.dataProducts.list</code></p>
<p><code translate="no" dir="ltr">dataplex.dataProducts.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.dataTaxonomies.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.dataTaxonomies.list</code></p>
<p><code translate="no" dir="ltr">dataplex.dataTaxonomies.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.datascans.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.datascans.list</code></p>
<p><code translate="no" dir="ltr">dataplex.datascans.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.encryptionConfig.list</code></p>
<p><code translate="no" dir="ltr">dataplex.entities.list</code></p>
<p><code translate="no" dir="ltr">dataplex.entries.list</code></p>
<p><code translate="no" dir="ltr">dataplex.entryGroups.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.entryGroups.list</code></p>
<p><code translate="no" dir="ltr">dataplex.entryGroups.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.entryLinkTypes.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.entryLinkTypes.list</code></p>
<p><code translate="no" dir="ltr">dataplex.entryLinkTypes.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.entryTypes.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.entryTypes.list</code></p>
<p><code translate="no" dir="ltr">dataplex.entryTypes.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.environments.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.environments.list</code></p>
<p><code translate="no" dir="ltr">dataplex.environments.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.glossaries.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.glossaries.list</code></p>
<p><code translate="no" dir="ltr">dataplex.glossaries.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.glossaryCategories.list</code></p>
<p><code translate="no" dir="ltr">dataplex.glossaryTerms.list</code></p>
<p><code translate="no" dir="ltr">dataplex.lakeActions.list</code></p>
<p><code translate="no" dir="ltr">dataplex.lakes.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.lakes.list</code></p>
<p><code translate="no" dir="ltr">dataplex.lakes.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.locations.list</code></p>
<p><code translate="no" dir="ltr">dataplex.metadataFeeds.list</code></p>
<p><code translate="no" dir="ltr">dataplex.metadataJobs.list</code></p>
<p><code translate="no" dir="ltr">dataplex.operations.list</code></p>
<p><code translate="no" dir="ltr">dataplex.partitions.list</code></p>
<p><code translate="no" dir="ltr">dataplex.tasks.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.tasks.list</code></p>
<p><code translate="no" dir="ltr">dataplex.tasks.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.zoneActions.list</code></p>
<p><code translate="no" dir="ltr">dataplex.zones.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.zones.list</code></p>
<p><code translate="no" dir="ltr">dataplex.zones.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataproc.agents.list</code></p>
<p><code translate="no" dir="ltr">dataproc.autoscalingPolicies.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataproc.autoscalingPolicies.list</code></p>
<p><code translate="no" dir="ltr">dataproc.autoscalingPolicies.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataproc.batches.list</code></p>
<p><code translate="no" dir="ltr">dataproc.clusters.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataproc.clusters.list</code></p>
<p><code translate="no" dir="ltr">dataproc.clusters.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataproc.jobs.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataproc.jobs.list</code></p>
<p><code translate="no" dir="ltr">dataproc.jobs.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataproc.operations.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataproc.operations.list</code></p>
<p><code translate="no" dir="ltr">dataproc.operations.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataproc.sessionTemplates.list</code></p>
<p><code translate="no" dir="ltr">dataproc.sessions.list</code></p>
<p><code translate="no" dir="ltr">dataproc.workflowTemplates.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataproc.workflowTemplates.list</code></p>
<p><code translate="no" dir="ltr">dataproc.workflowTemplates.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataprocessing.datasources.list</code></p>
<p><code translate="no" dir="ltr">dataprocessing.featurecontrols.list</code></p>
<p><code translate="no" dir="ltr">dataprocessing.groupcontrols.list</code></p>
<p><code translate="no" dir="ltr">dataprocrm.locations.list</code></p>
<p><code translate="no" dir="ltr">dataprocrm.nodePools.list</code></p>
<p><code translate="no" dir="ltr">dataprocrm.nodes.list</code></p>
<p><code translate="no" dir="ltr">dataprocrm.operations.list</code></p>
<p><code translate="no" dir="ltr">dataprocrm.workloads.list</code></p>
<p><code translate="no" dir="ltr">datastore.backupSchedules.list</code></p>
<p><code translate="no" dir="ltr">datastore.backups.list</code></p>
<p><code translate="no" dir="ltr">datastore.databases.list</code></p>
<p><code translate="no" dir="ltr">datastore.entities.list</code></p>
<p><code translate="no" dir="ltr">datastore.keyVisualizerScans.list</code></p>
<p><code translate="no" dir="ltr">datastore.locations.list</code></p>
<p><code translate="no" dir="ltr">datastore.namespaces.list</code></p>
<p><code translate="no" dir="ltr">datastore.operations.list</code></p>
<p><code translate="no" dir="ltr">datastore.schemas.list</code></p>
<p><code translate="no" dir="ltr">datastore.statistics.list</code></p>
<p><code translate="no" dir="ltr">datastore.userCreds.list</code></p>
<p><code translate="no" dir="ltr">datastream.connectionProfiles.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">datastream.connectionProfiles.list</code></p>
<p><code translate="no" dir="ltr">datastream.connectionProfiles.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">datastream.locations.list</code></p>
<p><code translate="no" dir="ltr">datastream.objects.list</code></p>
<p><code translate="no" dir="ltr">datastream.operations.list</code></p>
<p><code translate="no" dir="ltr">datastream.privateConnections.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">datastream.privateConnections.list</code></p>
<p><code translate="no" dir="ltr">datastream.privateConnections.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">datastream.routes.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">datastream.routes.list</code></p>
<p><code translate="no" dir="ltr">datastream.routes.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">datastream.streams.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">datastream.streams.list</code></p>
<p><code translate="no" dir="ltr">datastream.streams.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">datastudio.datasources.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">datastudio.datasources.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">datastudio.reports.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">datastudio.reports.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">datastudio.workspaces.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">datastudio.workspaces.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">deploymentmanager.compositeTypes.list</code></p>
<p><code translate="no" dir="ltr">deploymentmanager.deployments.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">deploymentmanager.deployments.list</code></p>
<p><code translate="no" dir="ltr">deploymentmanager.deployments.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">deploymentmanager.manifests.list</code></p>
<p><code translate="no" dir="ltr">deploymentmanager.operations.list</code></p>
<p><code translate="no" dir="ltr">deploymentmanager.resources.list</code></p>
<p><code translate="no" dir="ltr">deploymentmanager.typeProviders.list</code></p>
<p><code translate="no" dir="ltr">deploymentmanager.types.list</code></p>
<p><code translate="no" dir="ltr">designcenter.applicationTemplateRevisions.list</code></p>
<p><code translate="no" dir="ltr">designcenter.applicationTemplates.list</code></p>
<p><code translate="no" dir="ltr">designcenter.applications.list</code></p>
<p><code translate="no" dir="ltr">designcenter.catalogTemplateRevisions.list</code></p>
<p><code translate="no" dir="ltr">designcenter.catalogTemplates.list</code></p>
<p><code translate="no" dir="ltr">designcenter.catalogs.list</code></p>
<p><code translate="no" dir="ltr">designcenter.components.list</code></p>
<p><code translate="no" dir="ltr">designcenter.connections.list</code></p>
<p><code translate="no" dir="ltr">designcenter.locations.list</code></p>
<p><code translate="no" dir="ltr">designcenter.operations.list</code></p>
<p><code translate="no" dir="ltr">designcenter.sharedTemplateRevisions.list</code></p>
<p><code translate="no" dir="ltr">designcenter.sharedTemplates.list</code></p>
<p><code translate="no" dir="ltr">designcenter.shares.list</code></p>
<p><code translate="no" dir="ltr">designcenter.spaces.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">designcenter.spaces.list</code></p>
<p><code translate="no" dir="ltr">designcenter.spaces.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">developerconnect.accountConnectors.list</code></p>
<p><code translate="no" dir="ltr">developerconnect.connections.list</code></p>
<p><code translate="no" dir="ltr">developerconnect.deploymentEvents.list</code></p>
<p><code translate="no" dir="ltr">developerconnect.gitRepositoryLinks.list</code></p>
<p><code translate="no" dir="ltr">developerconnect.insightsConfigs.list</code></p>
<p><code translate="no" dir="ltr">developerconnect.locations.list</code></p>
<p><code translate="no" dir="ltr">developerconnect.operations.list</code></p>
<p><code translate="no" dir="ltr">developerconnect.providers.list</code></p>
<p><code translate="no" dir="ltr">developerconnect.users.list</code></p>
<p><code translate="no" dir="ltr">devicerun.devices.list</code></p>
<p><code translate="no" dir="ltr">devicerun.locations.list</code></p>
<p><code translate="no" dir="ltr">devicerun.operations.list</code></p>
<p><code translate="no" dir="ltr">devicerun.sessions.list</code></p>
<p><code translate="no" dir="ltr">devicerun.softwareVersions.list</code></p>
<p><code translate="no" dir="ltr">devicestreaming.deviceSessions.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.agents.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.answerrecords.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.callMatchers.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.changelogs.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.companionAgents.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.contexts.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.conversationDatasets.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.conversationModels.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.conversationProfiles.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.conversations.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.deployments.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.documents.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.entityTypes.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.environments.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.examples.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.experiments.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.flows.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.generators.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.integrations.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.intents.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.knowledgeBases.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.messages.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.modelEvaluations.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.pages.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.participants.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.phoneNumberOrders.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.phoneNumbers.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.playbooks.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.securitySettings.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.sessionEntityTypes.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.smartMessagingEntries.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.testcases.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.tools.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.transitionRouteGroups.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.versions.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.webhooks.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.agentFiles.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.agentIamProposals.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.agents.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">discoveryengine.agents.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.agents.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">discoveryengine.assistants.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.authorizations.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.billingAccountLicenseConfigs.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.branches.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.cannedQueries.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.cmekConfigs.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.collections.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">discoveryengine.collections.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.collections.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">discoveryengine.connectorRuns.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.controls.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.conversations.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.dataStores.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">discoveryengine.dataStores.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.dataStores.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">discoveryengine.documents.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.engines.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">discoveryengine.engines.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.engines.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">discoveryengine.evaluations.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.identityMappingStores.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.immersiveArtifacts.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.licenseConfigs.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.memories.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.models.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.notebooks.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">discoveryengine.notebooks.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.notebooks.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">discoveryengine.notificationMessages.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.operations.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.sampleQueries.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.sampleQuerySets.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.schemas.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.servingConfigs.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.sessions.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.sharedContents.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.targetSites.list</code></p>
<p><code translate="no" dir="ltr">dlp.analyzeRiskTemplates.list</code></p>
<p><code translate="no" dir="ltr">dlp.columnDataProfiles.list</code></p>
<p><code translate="no" dir="ltr">dlp.connections.list</code></p>
<p><code translate="no" dir="ltr">dlp.contentPolicies.list</code></p>
<p><code translate="no" dir="ltr">dlp.deidentifyTemplates.list</code></p>
<p><code translate="no" dir="ltr">dlp.estimates.list</code></p>
<p><code translate="no" dir="ltr">dlp.fileStoreProfiles.list</code></p>
<p><code translate="no" dir="ltr">dlp.inspectFindings.list</code></p>
<p><code translate="no" dir="ltr">dlp.inspectTemplates.list</code></p>
<p><code translate="no" dir="ltr">dlp.jobTriggers.list</code></p>
<p><code translate="no" dir="ltr">dlp.jobs.list</code></p>
<p><code translate="no" dir="ltr">dlp.locations.list</code></p>
<p><code translate="no" dir="ltr">dlp.projectDataProfiles.list</code></p>
<p><code translate="no" dir="ltr">dlp.storedInfoTypes.list</code></p>
<p><code translate="no" dir="ltr">dlp.subscriptions.list</code></p>
<p><code translate="no" dir="ltr">dlp.tableDataProfiles.list</code></p>
<p><code translate="no" dir="ltr">dns.changes.list</code></p>
<p><code translate="no" dir="ltr">dns.dnsKeys.list</code></p>
<p><code translate="no" dir="ltr">dns.managedZoneOperations.list</code></p>
<p><code translate="no" dir="ltr">dns.managedZones.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dns.managedZones.list</code></p>
<p><code translate="no" dir="ltr">dns.managedZones.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">dns.policies.list</code></p>
<p><code translate="no" dir="ltr">dns.resourceRecordSets.list</code></p>
<p><code translate="no" dir="ltr">dns.responsePolicies.list</code></p>
<p><code translate="no" dir="ltr">dns.responsePolicyRules.list</code></p>
<p><code translate="no" dir="ltr">documentai.dataLabelingJobs.list</code></p>
<p><code translate="no" dir="ltr">documentai.evaluations.list</code></p>
<p><code translate="no" dir="ltr">documentai.labelerPools.list</code></p>
<p><code translate="no" dir="ltr">documentai.locations.list</code></p>
<p><code translate="no" dir="ltr">documentai.processorTypes.list</code></p>
<p><code translate="no" dir="ltr">documentai.processorVersions.list</code></p>
<p><code translate="no" dir="ltr">documentai.processors.list</code></p>
<p><code translate="no" dir="ltr">documentai.rules.list</code></p>
<p><code translate="no" dir="ltr">documentai.schemaVersions.list</code></p>
<p><code translate="no" dir="ltr">documentai.schemas.list</code></p>
<p><code translate="no" dir="ltr">documentai.validators.list</code></p>
<p><code translate="no" dir="ltr">domains.locations.list</code></p>
<p><code translate="no" dir="ltr">domains.operations.list</code></p>
<p><code translate="no" dir="ltr">domains.registrations.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">domains.registrations.list</code></p>
<p><code translate="no" dir="ltr">domains.registrations.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">dspm.locations.list</code></p>
<p><code translate="no" dir="ltr">dspm.operations.list</code></p>
<p><code translate="no" dir="ltr">earthengine.assets.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">earthengine.assets.list</code></p>
<p><code translate="no" dir="ltr">earthengine.assets.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">earthengine.operations.list</code></p>
<p><code translate="no" dir="ltr">edgecontainer.apikeys.list</code></p>
<p><code translate="no" dir="ltr">edgecontainer.clusters.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">edgecontainer.clusters.list</code></p>
<p><code translate="no" dir="ltr">edgecontainer.clusters.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">edgecontainer.identityproviders.list</code></p>
<p><code translate="no" dir="ltr">edgecontainer.locations.list</code></p>
<p><code translate="no" dir="ltr">edgecontainer.machines.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">edgecontainer.machines.list</code></p>
<p><code translate="no" dir="ltr">edgecontainer.machines.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">edgecontainer.nodePools.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">edgecontainer.nodePools.list</code></p>
<p><code translate="no" dir="ltr">edgecontainer.nodePools.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">edgecontainer.operations.list</code></p>
<p><code translate="no" dir="ltr">edgecontainer.serviceaccounts.list</code></p>
<p><code translate="no" dir="ltr">edgecontainer.vpnConnections.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">edgecontainer.vpnConnections.list</code></p>
<p><code translate="no" dir="ltr">edgecontainer.vpnConnections.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">edgecontainer.zonalProjects.list</code></p>
<p><code translate="no" dir="ltr">edgecontainer.zonalservices.list</code></p>
<p><code translate="no" dir="ltr">edgecontainer.zones.list</code></p>
<p><code translate="no" dir="ltr">edgenetwork.interconnectAttachments.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">edgenetwork.interconnectAttachments.list</code></p>
<p><code translate="no" dir="ltr">edgenetwork.interconnectAttachments.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">edgenetwork.interconnects.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">edgenetwork.interconnects.list</code></p>
<p><code translate="no" dir="ltr">edgenetwork.interconnects.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">edgenetwork.locations.list</code></p>
<p><code translate="no" dir="ltr">edgenetwork.networks.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">edgenetwork.networks.list</code></p>
<p><code translate="no" dir="ltr">edgenetwork.networks.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">edgenetwork.operations.list</code></p>
<p><code translate="no" dir="ltr">edgenetwork.routers.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">edgenetwork.routers.list</code></p>
<p><code translate="no" dir="ltr">edgenetwork.routers.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">edgenetwork.routes.list</code></p>
<p><code translate="no" dir="ltr">edgenetwork.subnetworks.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">edgenetwork.subnetworks.list</code></p>
<p><code translate="no" dir="ltr">edgenetwork.subnetworks.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">edgenetwork.zones.list</code></p>
<p><code translate="no" dir="ltr">enterpriseknowledgegraph.entityReconciliationJobs.list</code></p>
<p><code translate="no" dir="ltr">enterprisepurchasing.gcveCuds.list</code></p>
<p><code translate="no" dir="ltr">enterprisepurchasing.gcveNodePricingInfo.list</code></p>
<p><code translate="no" dir="ltr">enterprisepurchasing.licenseKeys.list</code></p>
<p><code translate="no" dir="ltr">enterprisepurchasing.locations.list</code></p>
<p><code translate="no" dir="ltr">enterprisepurchasing.operations.list</code></p>
<p><code translate="no" dir="ltr">errorreporting.applications.list</code></p>
<p><code translate="no" dir="ltr">errorreporting.errorEvents.list</code></p>
<p><code translate="no" dir="ltr">errorreporting.groups.list</code></p>
<p><code translate="no" dir="ltr">essentialcontacts.contacts.list</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.list</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.list</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.enrollments.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.enrollments.list</code></p>
<p><code translate="no" dir="ltr">eventarc.enrollments.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.googleApiSources.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.googleApiSources.list</code></p>
<p><code translate="no" dir="ltr">eventarc.googleApiSources.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.kafkaSources.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.kafkaSources.list</code></p>
<p><code translate="no" dir="ltr">eventarc.kafkaSources.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.locations.list</code></p>
<p><code translate="no" dir="ltr">eventarc.messageBuses.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.messageBuses.list</code></p>
<p><code translate="no" dir="ltr">eventarc.messageBuses.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.operations.list</code></p>
<p><code translate="no" dir="ltr">eventarc.pipelines.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.pipelines.list</code></p>
<p><code translate="no" dir="ltr">eventarc.pipelines.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.providers.list</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.list</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">externalexposure.locations.list</code></p>
<p><code translate="no" dir="ltr">externalexposure.operations.list</code></p>
<p><code translate="no" dir="ltr">faulttesting.affectedResources.list</code></p>
<p><code translate="no" dir="ltr">faulttesting.experimentTemplates.list</code></p>
<p><code translate="no" dir="ltr">faulttesting.experiments.list</code></p>
<p><code translate="no" dir="ltr">faulttesting.locations.list</code></p>
<p><code translate="no" dir="ltr">faulttesting.operations.list</code></p>
<p><code translate="no" dir="ltr">faulttesting.validationResources.list</code></p>
<p><code translate="no" dir="ltr">faulttesting.validations.list</code></p>
<p><code translate="no" dir="ltr">fcmdata.deliverydata.list</code></p>
<p><code translate="no" dir="ltr">file.backups.list</code></p>
<p><code translate="no" dir="ltr">file.instances.list</code></p>
<p><code translate="no" dir="ltr">file.locations.list</code></p>
<p><code translate="no" dir="ltr">file.operations.list</code></p>
<p><code translate="no" dir="ltr">financialservices.locations.list</code></p>
<p><code translate="no" dir="ltr">financialservices.operations.list</code></p>
<p><code translate="no" dir="ltr">financialservices.v1backtests.list</code></p>
<p><code translate="no" dir="ltr">financialservices.v1datasets.list</code></p>
<p><code translate="no" dir="ltr">financialservices.v1engineconfigs.list</code></p>
<p><code translate="no" dir="ltr">financialservices.v1engineversions.list</code></p>
<p><code translate="no" dir="ltr">financialservices.v1instances.list</code></p>
<p><code translate="no" dir="ltr">financialservices.v1models.list</code></p>
<p><code translate="no" dir="ltr">financialservices.v1predictions.list</code></p>
<p><code translate="no" dir="ltr">firebase.clients.list</code></p>
<p><code translate="no" dir="ltr">firebase.links.list</code></p>
<p><code translate="no" dir="ltr">firebase.playLinks.list</code></p>
<p><code translate="no" dir="ltr">firebaseabt.experiments.list</code></p>
<p><code translate="no" dir="ltr">firebaseappcheck.automations.list</code></p>
<p><code translate="no" dir="ltr">firebaseappdistro.groups.list</code></p>
<p><code translate="no" dir="ltr">firebaseappdistro.releases.list</code></p>
<p><code translate="no" dir="ltr">firebaseappdistro.testers.list</code></p>
<p><code translate="no" dir="ltr">firebaseapphosting.backends.list</code></p>
<p><code translate="no" dir="ltr">firebaseapphosting.builds.list</code></p>
<p><code translate="no" dir="ltr">firebaseapphosting.domains.list</code></p>
<p><code translate="no" dir="ltr">firebaseapphosting.locations.list</code></p>
<p><code translate="no" dir="ltr">firebaseapphosting.operations.list</code></p>
<p><code translate="no" dir="ltr">firebaseapphosting.rollouts.list</code></p>
<p><code translate="no" dir="ltr">firebasecrashlytics.issues.list</code></p>
<p><code translate="no" dir="ltr">firebasedatabase.instances.list</code></p>
<p><code translate="no" dir="ltr">firebasedataconnect.connectorRevisions.list</code></p>
<p><code translate="no" dir="ltr">firebasedataconnect.connectors.list</code></p>
<p><code translate="no" dir="ltr">firebasedataconnect.locations.list</code></p>
<p><code translate="no" dir="ltr">firebasedataconnect.operations.list</code></p>
<p><code translate="no" dir="ltr">firebasedataconnect.schemaRevisions.list</code></p>
<p><code translate="no" dir="ltr">firebasedataconnect.schemas.list</code></p>
<p><code translate="no" dir="ltr">firebasedataconnect.services.list</code></p>
<p><code translate="no" dir="ltr">firebasedynamiclinks.destinations.list</code></p>
<p><code translate="no" dir="ltr">firebasedynamiclinks.domains.list</code></p>
<p><code translate="no" dir="ltr">firebasedynamiclinks.links.list</code></p>
<p><code translate="no" dir="ltr">firebaseextensions.configs.list</code></p>
<p><code translate="no" dir="ltr">firebaseextensionspublisher.extensions.list</code></p>
<p><code translate="no" dir="ltr">firebasehosting.sites.list</code></p>
<p><code translate="no" dir="ltr">firebaseinappmessaging.campaigns.list</code></p>
<p><code translate="no" dir="ltr">firebasemessagingcampaigns.campaigns.list</code></p>
<p><code translate="no" dir="ltr">firebaseml.models.list</code></p>
<p><code translate="no" dir="ltr">firebaseml.modelversions.list</code></p>
<p><code translate="no" dir="ltr">firebasenotifications.messages.list</code></p>
<p><code translate="no" dir="ltr">firebaserules.releases.list</code></p>
<p><code translate="no" dir="ltr">firebaserules.rulesets.list</code></p>
<p><code translate="no" dir="ltr">firebasestorage.buckets.list</code></p>
<p><code translate="no" dir="ltr">firebasevertexai.promptTemplates.list</code></p>
<p><code translate="no" dir="ltr">fleetengine.deliveryvehicles.list</code></p>
<p><code translate="no" dir="ltr">fleetengine.tasks.list</code></p>
<p><code translate="no" dir="ltr">fleetengine.vehicles.list</code></p>
<p><code translate="no" dir="ltr">ftp.locations.list</code></p>
<p><code translate="no" dir="ltr">ftp.operations.list</code></p>
<p><code translate="no" dir="ltr">ftp.servers.list</code></p>
<p><code translate="no" dir="ltr">ftp.users.list</code></p>
<p><code translate="no" dir="ltr">gcp.redisenterprise.com/databases.list</code></p>
<p><code translate="no" dir="ltr">gcp.redisenterprise.com/subscriptions.list</code></p>
<p><code translate="no" dir="ltr">gdchardwaremanagement.changeLogEntries.list</code></p>
<p><code translate="no" dir="ltr">gdchardwaremanagement.comments.list</code></p>
<p><code translate="no" dir="ltr">gdchardwaremanagement.hardware.list</code></p>
<p><code translate="no" dir="ltr">gdchardwaremanagement.hardwareGroups.list</code></p>
<p><code translate="no" dir="ltr">gdchardwaremanagement.locations.list</code></p>
<p><code translate="no" dir="ltr">gdchardwaremanagement.operations.list</code></p>
<p><code translate="no" dir="ltr">gdchardwaremanagement.orders.list</code></p>
<p><code translate="no" dir="ltr">gdchardwaremanagement.sites.list</code></p>
<p><code translate="no" dir="ltr">gdchardwaremanagement.skus.list</code></p>
<p><code translate="no" dir="ltr">gdchardwaremanagement.zones.list</code></p>
<p><code translate="no" dir="ltr">geminicloudassist.investigationRevisions.list</code></p>
<p><code translate="no" dir="ltr">geminicloudassist.investigations.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">geminicloudassist.investigations.list</code></p>
<p><code translate="no" dir="ltr">geminicloudassist.investigations.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">geminicloudassist.locations.list</code></p>
<p><code translate="no" dir="ltr">geminicloudassist.operations.list</code></p>
<p><code translate="no" dir="ltr">geminidataanalytics.dataAgents.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">geminidataanalytics.dataAgents.list</code></p>
<p><code translate="no" dir="ltr">geminidataanalytics.dataAgents.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">geminidataanalytics.locations.list</code></p>
<p><code translate="no" dir="ltr">geminidataanalytics.operations.list</code></p>
<p><code translate="no" dir="ltr">genomics.datasets.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">genomics.datasets.list</code></p>
<p><code translate="no" dir="ltr">genomics.datasets.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">genomics.operations.list</code></p>
<p><code translate="no" dir="ltr">gkebackup.backupChannels.list</code></p>
<p><code translate="no" dir="ltr">gkebackup.backupPlanBindings.list</code></p>
<p><code translate="no" dir="ltr">gkebackup.backupPlans.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">gkebackup.backupPlans.list</code></p>
<p><code translate="no" dir="ltr">gkebackup.backupPlans.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">gkebackup.backups.list</code></p>
<p><code translate="no" dir="ltr">gkebackup.locations.list</code></p>
<p><code translate="no" dir="ltr">gkebackup.operations.list</code></p>
<p><code translate="no" dir="ltr">gkebackup.restoreChannels.list</code></p>
<p><code translate="no" dir="ltr">gkebackup.restorePlanBindings.list</code></p>
<p><code translate="no" dir="ltr">gkebackup.restorePlans.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">gkebackup.restorePlans.list</code></p>
<p><code translate="no" dir="ltr">gkebackup.restorePlans.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">gkebackup.restores.list</code></p>
<p><code translate="no" dir="ltr">gkebackup.volumeBackups.list</code></p>
<p><code translate="no" dir="ltr">gkebackup.volumeRestores.list</code></p>
<p><code translate="no" dir="ltr">gkehub.features.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">gkehub.features.list</code></p>
<p><code translate="no" dir="ltr">gkehub.features.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">gkehub.locations.list</code></p>
<p><code translate="no" dir="ltr">gkehub.membershipbindings.list</code></p>
<p><code translate="no" dir="ltr">gkehub.membershipfeatures.list</code></p>
<p><code translate="no" dir="ltr">gkehub.memberships.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">gkehub.memberships.list</code></p>
<p><code translate="no" dir="ltr">gkehub.memberships.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">gkehub.namespaces.list</code></p>
<p><code translate="no" dir="ltr">gkehub.operations.list</code></p>
<p><code translate="no" dir="ltr">gkehub.rbacrolebindings.list</code></p>
<p><code translate="no" dir="ltr">gkehub.scopes.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">gkehub.scopes.list</code></p>
<p><code translate="no" dir="ltr">gkehub.scopes.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">gkemulticloud.attachedClusters.list</code></p>
<p><code translate="no" dir="ltr">gkemulticloud.awsClusters.list</code></p>
<p><code translate="no" dir="ltr">gkemulticloud.awsNodePools.list</code></p>
<p><code translate="no" dir="ltr">gkemulticloud.azureClients.list</code></p>
<p><code translate="no" dir="ltr">gkemulticloud.azureClusters.list</code></p>
<p><code translate="no" dir="ltr">gkemulticloud.azureNodePools.list</code></p>
<p><code translate="no" dir="ltr">gkemulticloud.operations.list</code></p>
<p><code translate="no" dir="ltr">gkeonprem.bareMetalAdminClusters.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">gkeonprem.bareMetalAdminClusters.list</code></p>
<p><code translate="no" dir="ltr">gkeonprem.bareMetalAdminClusters.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">gkeonprem.bareMetalClusters.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">gkeonprem.bareMetalClusters.list</code></p>
<p><code translate="no" dir="ltr">gkeonprem.bareMetalClusters.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">gkeonprem.bareMetalNodePools.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">gkeonprem.bareMetalNodePools.list</code></p>
<p><code translate="no" dir="ltr">gkeonprem.bareMetalNodePools.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">gkeonprem.locations.list</code></p>
<p><code translate="no" dir="ltr">gkeonprem.operations.list</code></p>
<p><code translate="no" dir="ltr">gkeonprem.vmwareAdminClusters.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">gkeonprem.vmwareAdminClusters.list</code></p>
<p><code translate="no" dir="ltr">gkeonprem.vmwareAdminClusters.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">gkeonprem.vmwareClusters.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">gkeonprem.vmwareClusters.list</code></p>
<p><code translate="no" dir="ltr">gkeonprem.vmwareClusters.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">gkeonprem.vmwareNodePools.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">gkeonprem.vmwareNodePools.list</code></p>
<p><code translate="no" dir="ltr">gkeonprem.vmwareNodePools.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">gsuiteaddons.deployments.list</code></p>
<p><code translate="no" dir="ltr">health.subscribers.list</code></p>
<p><code translate="no" dir="ltr">health.subscriptions.list</code></p>
<p><code translate="no" dir="ltr">healthcare.annotationStores.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">healthcare.annotationStores.list</code></p>
<p><code translate="no" dir="ltr">healthcare.annotationStores.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">healthcare.annotations.list</code></p>
<p><code translate="no" dir="ltr">healthcare.attributeDefinitions.list</code></p>
<p><code translate="no" dir="ltr">healthcare.consentArtifacts.list</code></p>
<p><code translate="no" dir="ltr">healthcare.consentStores.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">healthcare.consentStores.list</code></p>
<p><code translate="no" dir="ltr">healthcare.consentStores.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">healthcare.consents.list</code></p>
<p><code translate="no" dir="ltr">healthcare.datasets.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">healthcare.datasets.list</code></p>
<p><code translate="no" dir="ltr">healthcare.datasets.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">healthcare.dicomStores.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">healthcare.dicomStores.list</code></p>
<p><code translate="no" dir="ltr">healthcare.dicomStores.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">healthcare.fhirStores.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">healthcare.fhirStores.list</code></p>
<p><code translate="no" dir="ltr">healthcare.fhirStores.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">healthcare.hl7V2Messages.list</code></p>
<p><code translate="no" dir="ltr">healthcare.hl7V2Stores.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">healthcare.hl7V2Stores.list</code></p>
<p><code translate="no" dir="ltr">healthcare.hl7V2Stores.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">healthcare.locations.list</code></p>
<p><code translate="no" dir="ltr">healthcare.operations.list</code></p>
<p><code translate="no" dir="ltr">healthcare.userDataMappings.list</code></p>
<p><code translate="no" dir="ltr">hypercomputecluster.clusters.list</code></p>
<p><code translate="no" dir="ltr">hypercomputecluster.locations.list</code></p>
<p><code translate="no" dir="ltr">hypercomputecluster.machineLearningRuns.list</code></p>
<p><code translate="no" dir="ltr">hypercomputecluster.operations.list</code></p>
<p><code translate="no" dir="ltr">iam.accesspolicies.list</code></p>
<p><code translate="no" dir="ltr">iam.denypolicies.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/oauthClientCredentials.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/oauthClients.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderKeys.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimGroups.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimUsers.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviders.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolManagedIdentities.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolNamespaces.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolProviderKeys.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolProviders.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPools.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPools.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPools.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">iam.policybindings.list</code></p>
<p><code translate="no" dir="ltr">iam.principalaccessboundarypolicies.list</code></p>
<p><code translate="no" dir="ltr">iam.roles.get</code></p>
<p><code translate="no" dir="ltr">iam.roles.list</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccountKeys.list</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.get</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.list</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">iamconnectors.accessEvents.list</code></p>
<p><code translate="no" dir="ltr">iamconnectors.authorizations.list</code></p>
<p><code translate="no" dir="ltr">iamconnectors.connectors.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">iamconnectors.connectors.list</code></p>
<p><code translate="no" dir="ltr">iamconnectors.connectors.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">iamconnectors.locations.list</code></p>
<p><code translate="no" dir="ltr">iamconnectors.operations.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iap.tunnel.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iap.tunnel.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">iap.tunnel.setIamPolicy</code></li>
</ul>
<p><code translate="no" dir="ltr">iap.tunnelDestGroups.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">iap.tunnelDestGroups.list</code></p>
<p><code translate="no" dir="ltr">iap.tunnelDestGroups.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">iap.tunnelInstances.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">iap.tunnelInstances.setIamPolicy</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iap.tunnelLocations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iap.tunnelLocations.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">iap.tunnelLocations.setIamPolicy</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iap.tunnelZones.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iap.tunnelZones.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">iap.tunnelZones.setIamPolicy</code></li>
</ul>
<p><code translate="no" dir="ltr">iap.web.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">iap.web.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">iap.webServiceVersions.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">iap.webServiceVersions.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">iap.webServices.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">iap.webServices.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">iap.webTypes.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">iap.webTypes.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">identitytoolkit.tenants.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">identitytoolkit.tenants.list</code></p>
<p><code translate="no" dir="ltr">identitytoolkit.tenants.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">ids.endpoints.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">ids.endpoints.list</code></p>
<p><code translate="no" dir="ltr">ids.endpoints.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">ids.locations.list</code></p>
<p><code translate="no" dir="ltr">ids.operations.list</code></p>
<p><code translate="no" dir="ltr">integrations.apigeeAuthConfigs.list</code></p>
<p><code translate="no" dir="ltr">integrations.apigeeCertificates.list</code></p>
<p><code translate="no" dir="ltr">integrations.apigeeExecutions.list</code></p>
<p><code translate="no" dir="ltr">integrations.apigeeIntegrationVers.list</code></p>
<p><code translate="no" dir="ltr">integrations.apigeeIntegrations.list</code></p>
<p><code translate="no" dir="ltr">integrations.apigeeSfdcChannels.list</code></p>
<p><code translate="no" dir="ltr">integrations.apigeeSfdcInstances.list</code></p>
<p><code translate="no" dir="ltr">integrations.apigeeSuspensions.list</code></p>
<p><code translate="no" dir="ltr">integrations.authConfigs.list</code></p>
<p><code translate="no" dir="ltr">integrations.certificates.list</code></p>
<p><code translate="no" dir="ltr">integrations.executions.list</code></p>
<p><code translate="no" dir="ltr">integrations.integrationVersions.list</code></p>
<p><code translate="no" dir="ltr">integrations.integrations.list</code></p>
<p><code translate="no" dir="ltr">integrations.securityAuthConfigs.list</code></p>
<p><code translate="no" dir="ltr">integrations.securityExecutions.list</code></p>
<p><code translate="no" dir="ltr">integrations.securityIntegTempVers.list</code></p>
<p><code translate="no" dir="ltr">integrations.securityIntegrationVers.list</code></p>
<p><code translate="no" dir="ltr">integrations.securityIntegrations.list</code></p>
<p><code translate="no" dir="ltr">integrations.sfdcChannels.list</code></p>
<p><code translate="no" dir="ltr">integrations.sfdcInstances.list</code></p>
<p><code translate="no" dir="ltr">integrations.suspensions.list</code></p>
<p><code translate="no" dir="ltr">integrations.templates.list</code></p>
<p><code translate="no" dir="ltr">integrations.testCases.list</code></p>
<p><code translate="no" dir="ltr">issuerswitch.accountManagerTransactions.list</code></p>
<p><code translate="no" dir="ltr">issuerswitch.complaintTransactions.list</code></p>
<p><code translate="no" dir="ltr">issuerswitch.financialTransactions.list</code></p>
<p><code translate="no" dir="ltr">issuerswitch.mandateTransactions.list</code></p>
<p><code translate="no" dir="ltr">issuerswitch.metadataTransactions.list</code></p>
<p><code translate="no" dir="ltr">issuerswitch.operations.list</code></p>
<p><code translate="no" dir="ltr">issuerswitch.ruleMetadata.list</code></p>
<p><code translate="no" dir="ltr">issuerswitch.ruleMetadataValues.list</code></p>
<p><code translate="no" dir="ltr">issuerswitch.rules.list</code></p>
<p><code translate="no" dir="ltr">krmapihosting.krmApiHosts.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">krmapihosting.krmApiHosts.list</code></p>
<p><code translate="no" dir="ltr">krmapihosting.krmApiHosts.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">krmapihosting.locations.list</code></p>
<p><code translate="no" dir="ltr">krmapihosting.operations.list</code></p>
<p><code translate="no" dir="ltr">licensemanager.configurations.list</code></p>
<p><code translate="no" dir="ltr">licensemanager.instances.list</code></p>
<p><code translate="no" dir="ltr">licensemanager.locations.list</code></p>
<p><code translate="no" dir="ltr">licensemanager.operations.list</code></p>
<p><code translate="no" dir="ltr">licensemanager.products.list</code></p>
<p><code translate="no" dir="ltr">lifesciences.operations.list</code></p>
<p><code translate="no" dir="ltr">livestream.assets.list</code></p>
<p><code translate="no" dir="ltr">livestream.channels.list</code></p>
<p><code translate="no" dir="ltr">livestream.clips.list</code></p>
<p><code translate="no" dir="ltr">livestream.dvrSessions.list</code></p>
<p><code translate="no" dir="ltr">livestream.events.list</code></p>
<p><code translate="no" dir="ltr">livestream.inputs.list</code></p>
<p><code translate="no" dir="ltr">livestream.locations.list</code></p>
<p><code translate="no" dir="ltr">livestream.operations.list</code></p>
<p><code translate="no" dir="ltr">logging.buckets.list</code></p>
<p><code translate="no" dir="ltr">logging.exclusions.list</code></p>
<p><code translate="no" dir="ltr">logging.links.list</code></p>
<p><code translate="no" dir="ltr">logging.locations.list</code></p>
<p><code translate="no" dir="ltr">logging.logEntries.list</code></p>
<p><code translate="no" dir="ltr">logging.logMetrics.list</code></p>
<p><code translate="no" dir="ltr">logging.logScopes.list</code></p>
<p><code translate="no" dir="ltr">logging.logServiceIndexes.list</code></p>
<p><code translate="no" dir="ltr">logging.logServices.list</code></p>
<p><code translate="no" dir="ltr">logging.logs.list</code></p>
<p><code translate="no" dir="ltr">logging.notificationRules.list</code></p>
<p><code translate="no" dir="ltr">logging.operations.list</code></p>
<p><code translate="no" dir="ltr">logging.privateLogEntries.list</code></p>
<p><code translate="no" dir="ltr">logging.queries.usePrivate</code></p>
<p><code translate="no" dir="ltr">logging.sinks.list</code></p>
<p><code translate="no" dir="ltr">logging.views.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">logging.views.list</code></p>
<p><code translate="no" dir="ltr">logging.views.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">looker.backups.list</code></p>
<p><code translate="no" dir="ltr">looker.instances.list</code></p>
<p><code translate="no" dir="ltr">looker.locations.list</code></p>
<p><code translate="no" dir="ltr">looker.operations.list</code></p>
<p><code translate="no" dir="ltr">lustre.instances.list</code></p>
<p><code translate="no" dir="ltr">lustre.locations.list</code></p>
<p><code translate="no" dir="ltr">lustre.operations.list</code></p>
<p><code translate="no" dir="ltr">maintenance.locations.list</code></p>
<p><code translate="no" dir="ltr">maintenance.resourceMaintenances.list</code></p>
<p><code translate="no" dir="ltr">managedflink.deployments.list</code></p>
<p><code translate="no" dir="ltr">managedflink.jobs.list</code></p>
<p><code translate="no" dir="ltr">managedflink.locations.list</code></p>
<p><code translate="no" dir="ltr">managedflink.operations.list</code></p>
<p><code translate="no" dir="ltr">managedflink.sessions.list</code></p>
<p><code translate="no" dir="ltr">managedidentities.backups.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">managedidentities.backups.list</code></p>
<p><code translate="no" dir="ltr">managedidentities.backups.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">managedidentities.domains.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">managedidentities.domains.list</code></p>
<p><code translate="no" dir="ltr">managedidentities.domains.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">managedidentities.locations.list</code></p>
<p><code translate="no" dir="ltr">managedidentities.operations.list</code></p>
<p><code translate="no" dir="ltr">managedidentities.peerings.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">managedidentities.peerings.list</code></p>
<p><code translate="no" dir="ltr">managedidentities.peerings.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">managedidentities.sqlintegrations.list</code></p>
<p><code translate="no" dir="ltr">managedkafka.acls.list</code></p>
<p><code translate="no" dir="ltr">managedkafka.clusters.list</code></p>
<p><code translate="no" dir="ltr">managedkafka.connectClusters.list</code></p>
<p><code translate="no" dir="ltr">managedkafka.connectors.list</code></p>
<p><code translate="no" dir="ltr">managedkafka.consumerGroups.list</code></p>
<p><code translate="no" dir="ltr">managedkafka.contexts.list</code></p>
<p><code translate="no" dir="ltr">managedkafka.locations.list</code></p>
<p><code translate="no" dir="ltr">managedkafka.operations.list</code></p>
<p><code translate="no" dir="ltr">managedkafka.schemaRegistries.list</code></p>
<p><code translate="no" dir="ltr">managedkafka.subjects.list</code></p>
<p><code translate="no" dir="ltr">managedkafka.topics.list</code></p>
<p><code translate="no" dir="ltr">managedkafka.versions.list</code></p>
<p><code translate="no" dir="ltr">mapsadmin.clientMaps.list</code></p>
<p><code translate="no" dir="ltr">mapsadmin.clientStyleSheetSnapshots.list</code></p>
<p><code translate="no" dir="ltr">mapsadmin.clientStyles.list</code></p>
<p><code translate="no" dir="ltr">mapsadmin.mapViews.list</code></p>
<p><code translate="no" dir="ltr">mapsadmin.styleSnapshots.list</code></p>
<p><code translate="no" dir="ltr">mapsanalytics.metricMetadata.list</code></p>
<p><code translate="no" dir="ltr">mapsplatformdatasets.datasets.list</code></p>
<p><code translate="no" dir="ltr">marketplacesolutions.locations.list</code></p>
<p><code translate="no" dir="ltr">marketplacesolutions.operations.list</code></p>
<p><code translate="no" dir="ltr">marketplacesolutions.powerImages.list</code></p>
<p><code translate="no" dir="ltr">marketplacesolutions.powerInstances.list</code></p>
<p><code translate="no" dir="ltr">marketplacesolutions.powerNetworks.list</code></p>
<p><code translate="no" dir="ltr">marketplacesolutions.powerSshKeys.list</code></p>
<p><code translate="no" dir="ltr">marketplacesolutions.powerVolumes.list</code></p>
<p><code translate="no" dir="ltr">memcache.instances.list</code></p>
<p><code translate="no" dir="ltr">memcache.locations.list</code></p>
<p><code translate="no" dir="ltr">memcache.operations.list</code></p>
<p><code translate="no" dir="ltr">memorystore.backupCollections.list</code></p>
<p><code translate="no" dir="ltr">memorystore.backups.list</code></p>
<p><code translate="no" dir="ltr">memorystore.instances.list</code></p>
<p><code translate="no" dir="ltr">memorystore.locations.list</code></p>
<p><code translate="no" dir="ltr">memorystore.operations.list</code></p>
<p><code translate="no" dir="ltr">metastore.backups.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">metastore.backups.list</code></p>
<p><code translate="no" dir="ltr">metastore.backups.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">metastore.databases.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">metastore.databases.list</code></p>
<p><code translate="no" dir="ltr">metastore.databases.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">metastore.federations.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">metastore.federations.list</code></p>
<p><code translate="no" dir="ltr">metastore.federations.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">metastore.imports.list</code></p>
<p><code translate="no" dir="ltr">metastore.locations.list</code></p>
<p><code translate="no" dir="ltr">metastore.migrations.list</code></p>
<p><code translate="no" dir="ltr">metastore.operations.list</code></p>
<p><code translate="no" dir="ltr">metastore.services.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">metastore.services.list</code></p>
<p><code translate="no" dir="ltr">metastore.services.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">metastore.tables.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">metastore.tables.list</code></p>
<p><code translate="no" dir="ltr">metastore.tables.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">migrationcenter.assets.list</code></p>
<p><code translate="no" dir="ltr">migrationcenter.assetsExportJobs.list</code></p>
<p><code translate="no" dir="ltr">migrationcenter.discoveryClients.list</code></p>
<p><code translate="no" dir="ltr">migrationcenter.errorFrames.list</code></p>
<p><code translate="no" dir="ltr">migrationcenter.groups.list</code></p>
<p><code translate="no" dir="ltr">migrationcenter.importDataFiles.list</code></p>
<p><code translate="no" dir="ltr">migrationcenter.importJobs.list</code></p>
<p><code translate="no" dir="ltr">migrationcenter.locations.list</code></p>
<p><code translate="no" dir="ltr">migrationcenter.operations.list</code></p>
<p><code translate="no" dir="ltr">migrationcenter.preferenceSets.list</code></p>
<p><code translate="no" dir="ltr">migrationcenter.relations.list</code></p>
<p><code translate="no" dir="ltr">migrationcenter.reportConfigs.list</code></p>
<p><code translate="no" dir="ltr">migrationcenter.reports.list</code></p>
<p><code translate="no" dir="ltr">migrationcenter.sources.list</code></p>
<p><code translate="no" dir="ltr">ml.jobs.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">ml.jobs.list</code></p>
<p><code translate="no" dir="ltr">ml.jobs.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">ml.locations.list</code></p>
<p><code translate="no" dir="ltr">ml.models.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">ml.models.list</code></p>
<p><code translate="no" dir="ltr">ml.models.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">ml.operations.list</code></p>
<p><code translate="no" dir="ltr">ml.studies.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">ml.studies.list</code></p>
<p><code translate="no" dir="ltr">ml.studies.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">ml.trials.list</code></p>
<p><code translate="no" dir="ltr">ml.versions.list</code></p>
<p><code translate="no" dir="ltr">modelarmor.locations.list</code></p>
<p><code translate="no" dir="ltr">modelarmor.templates.list</code></p>
<p><code translate="no" dir="ltr">monitoring.alertPolicies.list</code></p>
<p><code translate="no" dir="ltr">monitoring.alerts.list</code></p>
<p><code translate="no" dir="ltr">monitoring.dashboards.list</code></p>
<p><code translate="no" dir="ltr">monitoring.groups.list</code></p>
<p><code translate="no" dir="ltr">monitoring.metricDescriptors.list</code></p>
<p><code translate="no" dir="ltr">monitoring.monitoredResourceDescriptors.list</code></p>
<p><code translate="no" dir="ltr">monitoring.notificationChannelDescriptors.list</code></p>
<p><code translate="no" dir="ltr">monitoring.notificationChannels.list</code></p>
<p><code translate="no" dir="ltr">monitoring.services.list</code></p>
<p><code translate="no" dir="ltr">monitoring.slos.list</code></p>
<p><code translate="no" dir="ltr">monitoring.snoozes.list</code></p>
<p><code translate="no" dir="ltr">monitoring.timeSeries.list</code></p>
<p><code translate="no" dir="ltr">monitoring.uptimeCheckConfigs.list</code></p>
<p><code translate="no" dir="ltr">netapp.activeDirectories.list</code></p>
<p><code translate="no" dir="ltr">netapp.backupPolicies.list</code></p>
<p><code translate="no" dir="ltr">netapp.backupVaults.list</code></p>
<p><code translate="no" dir="ltr">netapp.backups.list</code></p>
<p><code translate="no" dir="ltr">netapp.hostGroups.list</code></p>
<p><code translate="no" dir="ltr">netapp.kmsConfigs.list</code></p>
<p><code translate="no" dir="ltr">netapp.locations.list</code></p>
<p><code translate="no" dir="ltr">netapp.operations.list</code></p>
<p><code translate="no" dir="ltr">netapp.quotaRules.list</code></p>
<p><code translate="no" dir="ltr">netapp.replications.list</code></p>
<p><code translate="no" dir="ltr">netapp.snapshots.list</code></p>
<p><code translate="no" dir="ltr">netapp.storagePools.list</code></p>
<p><code translate="no" dir="ltr">netapp.volumes.list</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.gatewayAdvertisedRoutes.list</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.groups.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.groups.list</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.groups.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.hubRouteTables.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.hubRouteTables.list</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.hubRouteTables.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.hubRoutes.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.hubRoutes.list</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.hubRoutes.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.hubs.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.hubs.list</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.hubs.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.internalRanges.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.internalRanges.list</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.internalRanges.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.locations.list</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.multicloudDataTransferConfigs.list</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.multicloudDataTransferDestinations.list</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.multicloudDataTransferSupportedServices.list</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.operations.list</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.policyBasedRoutes.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.policyBasedRoutes.list</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.policyBasedRoutes.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.pscAuthorizationPolicies.list</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.regionalEndpoints.list</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.remoteTransportProfiles.list</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.serviceClasses.list</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.serviceConnectionMaps.list</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.serviceConnectionPolicies.list</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.spokes.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.spokes.list</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.spokes.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.transports.list</code></p>
<p><code translate="no" dir="ltr">networkmanagement.connectivitytests.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">networkmanagement.connectivitytests.list</code></p>
<p><code translate="no" dir="ltr">networkmanagement.connectivitytests.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">networkmanagement.locations.list</code></p>
<p><code translate="no" dir="ltr">networkmanagement.monitoringpoints.list</code></p>
<p><code translate="no" dir="ltr">networkmanagement.networkpaths.list</code></p>
<p><code translate="no" dir="ltr">networkmanagement.operations.list</code></p>
<p><code translate="no" dir="ltr">networkmanagement.providers.list</code></p>
<p><code translate="no" dir="ltr">networkmanagement.vpcflowlogsconfigs.list</code></p>
<p><code translate="no" dir="ltr">networkmanagement.webpaths.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.addressGroups.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">networksecurity.addressGroups.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.addressGroups.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">networksecurity.authorizationPolicies.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">networksecurity.authorizationPolicies.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.authorizationPolicies.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">networksecurity.authzPolicies.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">networksecurity.authzPolicies.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.authzPolicies.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">networksecurity.backendAuthenticationConfigs.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.clientTlsPolicies.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">networksecurity.clientTlsPolicies.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.clientTlsPolicies.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">networksecurity.dnsThreatDetectors.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.firewallEndpointAssociations.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.firewallEndpoints.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.gatewaySecurityPolicies.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.gatewaySecurityPolicyRules.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.interceptDeploymentGroups.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.interceptDeployments.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.interceptEndpointGroupAssociations.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.interceptEndpointGroups.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.locations.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.mirroringDeploymentGroups.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.mirroringDeployments.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.mirroringEndpointGroupAssociations.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.mirroringEndpointGroups.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.operations.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.sacAttachments.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.sacRealms.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.securityProfileGroups.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.securityProfiles.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.serverTlsPolicies.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">networksecurity.serverTlsPolicies.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.serverTlsPolicies.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">networksecurity.tlsInspectionPolicies.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.urlLists.list</code></p>
<p><code translate="no" dir="ltr">networkservices.agentGateways.list</code></p>
<p><code translate="no" dir="ltr">networkservices.authzExtensions.list</code></p>
<p><code translate="no" dir="ltr">networkservices.endpointPolicies.list</code></p>
<p><code translate="no" dir="ltr">networkservices.gateways.list</code></p>
<p><code translate="no" dir="ltr">networkservices.googleTagGatewayPolicies.list</code></p>
<p><code translate="no" dir="ltr">networkservices.grpcRoutes.list</code></p>
<p><code translate="no" dir="ltr">networkservices.httpFilters.list</code></p>
<p><code translate="no" dir="ltr">networkservices.httpRoutes.list</code></p>
<p><code translate="no" dir="ltr">networkservices.httpfilters.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">networkservices.httpfilters.list</code></p>
<p><code translate="no" dir="ltr">networkservices.httpfilters.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">networkservices.lbEdgeExtensions.list</code></p>
<p><code translate="no" dir="ltr">networkservices.lbRouteExtensions.list</code></p>
<p><code translate="no" dir="ltr">networkservices.lbTrafficExtensions.list</code></p>
<p><code translate="no" dir="ltr">networkservices.locations.list</code></p>
<p><code translate="no" dir="ltr">networkservices.meshes.list</code></p>
<p><code translate="no" dir="ltr">networkservices.operations.list</code></p>
<p><code translate="no" dir="ltr">networkservices.route_views.list</code></p>
<p><code translate="no" dir="ltr">networkservices.serviceBindings.list</code></p>
<p><code translate="no" dir="ltr">networkservices.serviceLbPolicies.list</code></p>
<p><code translate="no" dir="ltr">networkservices.swpSecurityExtensions.list</code></p>
<p><code translate="no" dir="ltr">networkservices.tcpRoutes.list</code></p>
<p><code translate="no" dir="ltr">networkservices.tlsRoutes.list</code></p>
<p><code translate="no" dir="ltr">networkservices.wasmPlugins.list</code></p>
<p><code translate="no" dir="ltr">notebooks.environments.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">notebooks.environments.list</code></p>
<p><code translate="no" dir="ltr">notebooks.environments.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">notebooks.executions.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">notebooks.executions.list</code></p>
<p><code translate="no" dir="ltr">notebooks.executions.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">notebooks.instances.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">notebooks.instances.list</code></p>
<p><code translate="no" dir="ltr">notebooks.instances.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">notebooks.locations.list</code></p>
<p><code translate="no" dir="ltr">notebooks.operations.list</code></p>
<p><code translate="no" dir="ltr">notebooks.runtimes.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">notebooks.runtimes.list</code></p>
<p><code translate="no" dir="ltr">notebooks.runtimes.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">notebooks.schedules.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">notebooks.schedules.list</code></p>
<p><code translate="no" dir="ltr">notebooks.schedules.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">observability.analyticsViews.list</code></p>
<p><code translate="no" dir="ltr">observability.buckets.list</code></p>
<p><code translate="no" dir="ltr">observability.datasets.list</code></p>
<p><code translate="no" dir="ltr">observability.links.list</code></p>
<p><code translate="no" dir="ltr">observability.locations.list</code></p>
<p><code translate="no" dir="ltr">observability.operations.list</code></p>
<p><code translate="no" dir="ltr">observability.traceScopes.list</code></p>
<p><code translate="no" dir="ltr">observability.views.list</code></p>
<p><code translate="no" dir="ltr">ondemandscanning.operations.list</code></p>
<p><code translate="no" dir="ltr">opsconfigmonitoring.resourceMetadata.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.autonomousDatabaseBackups.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.autonomousDatabaseCharacterSets.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.autonomousDatabases.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.autonomousDbVersions.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.cloudExadataInfrastructures.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.cloudVmClusters.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.databaseCharacterSets.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.databaseConnections.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.databases.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.dbNodes.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.dbServers.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.dbSystemComputePerformances.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.dbSystemInitialStorageSizes.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.dbSystemShapes.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.dbSystems.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.dbVersions.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.entitlements.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.exadbVmClusters.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.exascaleDbStorageVaults.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.flexComponents.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.giVersions.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.goldenGateConnectionAssignments.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.goldenGateConnectionTypes.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.goldenGateConnections.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.goldenGateDeploymentEnvironments.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.goldenGateDeploymentTypes.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.goldenGateDeploymentVersions.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.goldenGateDeployments.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.locations.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.minorVersions.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.odbDnsZones.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.odbNetworks.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.odbSubnets.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.operations.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.pluggableDatabases.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.serviceIntegrations.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.systemVersions.list</code></p>
<p><code translate="no" dir="ltr">orgpolicy.constraints.list</code></p>
<p><code translate="no" dir="ltr">orgpolicy.customConstraints.list</code></p>
<p><code translate="no" dir="ltr">orgpolicy.policies.list</code></p>
<p><code translate="no" dir="ltr">osconfig.guestPolicies.list</code></p>
<p><code translate="no" dir="ltr">osconfig.instanceOSPoliciesCompliances.list</code></p>
<p><code translate="no" dir="ltr">osconfig.inventories.list</code></p>
<p><code translate="no" dir="ltr">osconfig.locations.list</code></p>
<p><code translate="no" dir="ltr">osconfig.operations.list</code></p>
<p><code translate="no" dir="ltr">osconfig.osPolicyAssignmentReports.list</code></p>
<p><code translate="no" dir="ltr">osconfig.osPolicyAssignments.list</code></p>
<p><code translate="no" dir="ltr">osconfig.patchDeployments.list</code></p>
<p><code translate="no" dir="ltr">osconfig.patchJobs.list</code></p>
<p><code translate="no" dir="ltr">osconfig.policyOrchestrators.list</code></p>
<p><code translate="no" dir="ltr">osconfig.upgradeReports.list</code></p>
<p><code translate="no" dir="ltr">osconfig.vulnerabilityReports.list</code></p>
<p><code translate="no" dir="ltr">parallelstore.instances.list</code></p>
<p><code translate="no" dir="ltr">parallelstore.locations.list</code></p>
<p><code translate="no" dir="ltr">parallelstore.operations.list</code></p>
<p><code translate="no" dir="ltr">parametermanager.locations.list</code></p>
<p><code translate="no" dir="ltr">parametermanager.parameterVersions.list</code></p>
<p><code translate="no" dir="ltr">parametermanager.parameters.list</code></p>
<p><code translate="no" dir="ltr">parametermanager.templateVersions.list</code></p>
<p><code translate="no" dir="ltr">parametermanager.templates.list</code></p>
<p><code translate="no" dir="ltr">paymentsresellersubscription.products.list</code></p>
<p><code translate="no" dir="ltr">paymentsresellersubscription.promotions.list</code></p>
<p><code translate="no" dir="ltr">policyremediatormanager.locations.list</code></p>
<p><code translate="no" dir="ltr">policyremediatormanager.operations.list</code></p>
<p><code translate="no" dir="ltr">policysimulator.accessPolicySimulationResults.list</code></p>
<p><code translate="no" dir="ltr">policysimulator.accessPolicySimulations.list</code></p>
<p><code translate="no" dir="ltr">policysimulator.orgPolicyViolations.list</code></p>
<p><code translate="no" dir="ltr">policysimulator.orgPolicyViolationsPreviews.list</code></p>
<p><code translate="no" dir="ltr">policysimulator.replayResults.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">policysimulator.replays.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">policysimulator.replays.create</code></li>
<li><code translate="no" dir="ltr">policysimulator.replays.get</code></li>
<li><code translate="no" dir="ltr">policysimulator.replays.list</code></li>
<li><code translate="no" dir="ltr">policysimulator.replays.run</code></li>
</ul>
<p><code translate="no" dir="ltr">privateca.caPools.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">privateca.caPools.list</code></p>
<p><code translate="no" dir="ltr">privateca.caPools.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">privateca.certificateAuthorities.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">privateca.certificateAuthorities.list</code></p>
<p><code translate="no" dir="ltr">privateca.certificateAuthorities.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">privateca.certificateRevocationLists.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">privateca.certificateRevocationLists.list</code></p>
<p><code translate="no" dir="ltr">privateca.certificateRevocationLists.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">privateca.certificateTemplates.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">privateca.certificateTemplates.list</code></p>
<p><code translate="no" dir="ltr">privateca.certificateTemplates.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">privateca.certificates.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">privateca.certificates.list</code></p>
<p><code translate="no" dir="ltr">privateca.certificates.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">privateca.locations.list</code></p>
<p><code translate="no" dir="ltr">privateca.operations.list</code></p>
<p><code translate="no" dir="ltr">privateca.reusableConfigs.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">privateca.reusableConfigs.list</code></p>
<p><code translate="no" dir="ltr">privateca.reusableConfigs.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">privilegedaccessmanager.entitlements.list</code></p>
<p><code translate="no" dir="ltr">privilegedaccessmanager.entitlements.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">privilegedaccessmanager.grants.list</code></p>
<p><code translate="no" dir="ltr">privilegedaccessmanager.locations.list</code></p>
<p><code translate="no" dir="ltr">privilegedaccessmanager.operations.list</code></p>
<p><code translate="no" dir="ltr">proximitybeacon.attachments.list</code></p>
<p><code translate="no" dir="ltr">proximitybeacon.beacons.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">proximitybeacon.beacons.list</code></p>
<p><code translate="no" dir="ltr">proximitybeacon.beacons.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">proximitybeacon.namespaces.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">proximitybeacon.namespaces.list</code></p>
<p><code translate="no" dir="ltr">proximitybeacon.namespaces.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">pubsub.schemas.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">pubsub.schemas.list</code></p>
<p><code translate="no" dir="ltr">pubsub.schemas.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">pubsub.snapshots.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">pubsub.snapshots.list</code></p>
<p><code translate="no" dir="ltr">pubsub.snapshots.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">pubsub.subscriptions.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">pubsub.subscriptions.list</code></p>
<p><code translate="no" dir="ltr">pubsub.subscriptions.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">pubsub.topics.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">pubsub.topics.list</code></p>
<p><code translate="no" dir="ltr">pubsub.topics.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">pubsublite.operations.list</code></p>
<p><code translate="no" dir="ltr">pubsublite.reservations.list</code></p>
<p><code translate="no" dir="ltr">pubsublite.subscriptions.list</code></p>
<p><code translate="no" dir="ltr">pubsublite.topics.list</code></p>
<p><code translate="no" dir="ltr">recaptchaenterprise.firewallpolicies.list</code></p>
<p><code translate="no" dir="ltr">recaptchaenterprise.keys.list</code></p>
<p><code translate="no" dir="ltr">recaptchaenterprise.relatedaccountgroupmemberships.list</code></p>
<p><code translate="no" dir="ltr">recaptchaenterprise.relatedaccountgroups.list</code></p>
<p><code translate="no" dir="ltr">recommender.alloydbClusterPerformanceInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.alloydbClusterPerformanceRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.alloydbClusterReliabilityInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.alloydbClusterReliabilityRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.alloydbInstanceSecurityInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.alloydbInstanceSecurityRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.appengineVersionCostInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.appengineVersionCostRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.bigqueryCapacityCommitmentsInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.bigqueryCapacityCommitmentsRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.bigqueryMaterializedViewInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.bigqueryMaterializedViewRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.bigqueryPartitionClusterRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.bigqueryTableStatsInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.bigtableClusterPerformanceInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.bigtableClusterPerformanceRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudAssetInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudCostGeneralInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudCostGeneralRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudDeprecationGeneralInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudDeprecationGeneralRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudFunctionsPerformanceInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudFunctionsPerformanceRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudManageabilityGeneralInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudManageabilityGeneralRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudPerformanceGeneralInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudPerformanceGeneralRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudRecentChangeInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudRecentChangeRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudReliabilityGeneralInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudReliabilityGeneralRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudSecurityGeneralInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudSecurityGeneralRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudsqlIdleInstanceRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudsqlInstanceActivityInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudsqlInstanceCpuUsageInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudsqlInstanceDiskUsageTrendInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudsqlInstanceMemoryUsageInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudsqlInstanceOomProbabilityInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudsqlInstanceOutOfDiskRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudsqlInstancePerformanceInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudsqlInstancePerformanceRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudsqlInstanceReliabilityInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudsqlInstanceReliabilityRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudsqlInstanceSecurityInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudsqlInstanceSecurityRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudsqlInstanceUnderprovisionedCpuUsageInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudsqlInstanceUnderprovisionedMemoryUsageInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudsqlOverprovisionedInstanceRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudsqlUnderProvisionedInstanceRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.commitmentUtilizationInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.computeAddressIdleResourceInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.computeAddressIdleResourceRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.computeDiskIdleResourceInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.computeDiskIdleResourceRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.computeFirewallInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.computeIdleResourceInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.computeIdleResourceRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.computeImageIdleResourceInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.computeImageIdleResourceRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.computeInstanceCpuUsageInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.computeInstanceCpuUsagePredictionInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.computeInstanceCpuUsageTrendInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.computeInstanceGroupManagerCpuUsageInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.computeInstanceGroupManagerCpuUsagePredictionInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.computeInstanceGroupManagerCpuUsageTrendInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.computeInstanceGroupManagerMachineTypeRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.computeInstanceGroupManagerMemoryUsageInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.computeInstanceGroupManagerMemoryUsagePredictionInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.computeInstanceIdleResourceRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.computeInstanceMachineTypeRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.computeInstanceMemoryUsageInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.computeInstanceMemoryUsagePredictionInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.computeInstanceNetworkThroughputInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.containerDiagnosisInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.containerDiagnosisRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.costInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.dataflowDiagnosticsInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.errorReportingInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.errorReportingRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.firestoreDatabaseFirebaseRulesInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.firestoreDatabaseFirebaseRulesRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.firestoreDatabaseReliabilityInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.firestoreDatabaseReliabilityRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.gmpGuidedExperienceInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.gmpGuidedExperienceRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.gmpProjectManagementInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.gmpProjectManagementRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.gmpProjectProductSuggestionsInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.gmpProjectProductSuggestionsRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.iamPolicyChangeRiskInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.iamPolicyChangeRiskRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.iamPolicyInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.iamPolicyLateralMovementInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.iamPolicyRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.iamServiceAccountChangeRiskInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.iamServiceAccountChangeRiskRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.iamServiceAccountInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.locations.list</code></p>
<p><code translate="no" dir="ltr">recommender.loggingProductSuggestionContainerInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.loggingProductSuggestionContainerRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.memorystoreManageabilityInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.memorystoreManageabilityRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.memorystorePerformanceInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.memorystorePerformanceRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.memorystoreReliabilityInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.memorystoreReliabilityRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.memorystoreUtilizationInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.monitoringProductSuggestionComputeInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.monitoringProductSuggestionComputeRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.networkAnalyzerCloudSqlInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.networkAnalyzerDynamicRouteInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.networkAnalyzerGkeConnectivityInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.networkAnalyzerGkeIpAddressInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.networkAnalyzerGkeServiceAccountInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.networkAnalyzerIpAddressInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.networkAnalyzerLoadBalancerInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.networkAnalyzerVpcConnectivityInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.orgPolicyInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.orgPolicyRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.resourcemanagerProjectChangeRiskInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.resourcemanagerProjectChangeRiskRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.resourcemanagerProjectUtilizationInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.resourcemanagerProjectUtilizationRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.resourcemanagerServiceLimitInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.resourcemanagerServiceLimitRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.runServiceCostInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.runServiceCostRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.runServiceIdentityInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.runServiceIdentityRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.runServicePerformanceInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.runServicePerformanceRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.runServiceSecurityInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.runServiceSecurityRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.spannerDatabaseSecurityInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.spannerDatabaseSecurityRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.spannerProjectReliabilityInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.spannerProjectReliabilityRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.spendBasedCommitmentInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.spendBasedCommitmentRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.storageBucketSoftDeleteInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.storageBucketSoftDeleteRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.usageCommitmentRecommendations.list</code></p>
<p><code translate="no" dir="ltr">redis.aclPolicies.list</code></p>
<p><code translate="no" dir="ltr">redis.backupCollections.list</code></p>
<p><code translate="no" dir="ltr">redis.backups.list</code></p>
<p><code translate="no" dir="ltr">redis.clusters.list</code></p>
<p><code translate="no" dir="ltr">redis.instances.list</code></p>
<p><code translate="no" dir="ltr">redis.locations.list</code></p>
<p><code translate="no" dir="ltr">redis.operations.list</code></p>
<p><code translate="no" dir="ltr">remotebuildexecution.instances.list</code></p>
<p><code translate="no" dir="ltr">remotebuildexecution.workerpools.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.boundaries.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.capabilityConfigs.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.folders.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">resourcemanager.folders.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.folders.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">resourcemanager.hierarchyNodes.listTagBindings</code></p>
<p><code translate="no" dir="ltr">resourcemanager.organizations.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">resourcemanager.organizations.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">resourcemanager.tagHolds.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.tagKeys.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">resourcemanager.tagKeys.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.tagKeys.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">resourcemanager.tagValues.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">resourcemanager.tagValues.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.tagValues.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">resourcesettings.settings.list</code></p>
<p><code translate="no" dir="ltr">retail.branches.list</code></p>
<p><code translate="no" dir="ltr">retail.catalogs.list</code></p>
<p><code translate="no" dir="ltr">retail.controls.list</code></p>
<p><code translate="no" dir="ltr">retail.experiments.list</code></p>
<p><code translate="no" dir="ltr">retail.models.list</code></p>
<p><code translate="no" dir="ltr">retail.operations.list</code></p>
<p><code translate="no" dir="ltr">retail.products.list</code></p>
<p><code translate="no" dir="ltr">retail.servingConfigs.list</code></p>
<p><code translate="no" dir="ltr">riskmanager.controlScoreBreakdowns.list</code></p>
<p><code translate="no" dir="ltr">riskmanager.operations.list</code></p>
<p><code translate="no" dir="ltr">riskmanager.policies.list</code></p>
<p><code translate="no" dir="ltr">riskmanager.reports.list</code></p>
<p><code translate="no" dir="ltr">rma.collectors.list</code></p>
<p><code translate="no" dir="ltr">rma.locations.list</code></p>
<p><code translate="no" dir="ltr">rma.operations.list</code></p>
<p><code translate="no" dir="ltr">roads.selectedRoutes.list</code></p>
<p><code translate="no" dir="ltr">run.configurations.list</code></p>
<p><code translate="no" dir="ltr">run.executions.list</code></p>
<p><code translate="no" dir="ltr">run.instances.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">run.instances.list</code></p>
<p><code translate="no" dir="ltr">run.instances.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">run.jobs.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">run.jobs.list</code></p>
<p><code translate="no" dir="ltr">run.jobs.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">run.locations.list</code></p>
<p><code translate="no" dir="ltr">run.operations.list</code></p>
<p><code translate="no" dir="ltr">run.revisions.list</code></p>
<p><code translate="no" dir="ltr">run.routes.list</code></p>
<p><code translate="no" dir="ltr">run.services.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">run.services.list</code></p>
<p><code translate="no" dir="ltr">run.services.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">run.tasks.list</code></p>
<p><code translate="no" dir="ltr">run.workerpools.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">run.workerpools.list</code></p>
<p><code translate="no" dir="ltr">run.workerpools.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">runapps.applications.list</code></p>
<p><code translate="no" dir="ltr">runapps.deployments.list</code></p>
<p><code translate="no" dir="ltr">runapps.locations.list</code></p>
<p><code translate="no" dir="ltr">runapps.operations.list</code></p>
<p><code translate="no" dir="ltr">runtimeconfig.configs.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">runtimeconfig.configs.list</code></p>
<p><code translate="no" dir="ltr">runtimeconfig.configs.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">runtimeconfig.operations.list</code></p>
<p><code translate="no" dir="ltr">runtimeconfig.variables.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">runtimeconfig.variables.list</code></p>
<p><code translate="no" dir="ltr">runtimeconfig.variables.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">runtimeconfig.waiters.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">runtimeconfig.waiters.list</code></p>
<p><code translate="no" dir="ltr">runtimeconfig.waiters.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">saasservicemgmt.flagAttributes.list</code></p>
<p><code translate="no" dir="ltr">saasservicemgmt.flagReleases.list</code></p>
<p><code translate="no" dir="ltr">saasservicemgmt.flagRevisions.list</code></p>
<p><code translate="no" dir="ltr">saasservicemgmt.flags.list</code></p>
<p><code translate="no" dir="ltr">saasservicemgmt.locations.list</code></p>
<p><code translate="no" dir="ltr">saasservicemgmt.operations.list</code></p>
<p><code translate="no" dir="ltr">saasservicemgmt.poolKinds.list</code></p>
<p><code translate="no" dir="ltr">saasservicemgmt.pools.list</code></p>
<p><code translate="no" dir="ltr">saasservicemgmt.releases.list</code></p>
<p><code translate="no" dir="ltr">saasservicemgmt.rolloutKinds.list</code></p>
<p><code translate="no" dir="ltr">saasservicemgmt.rollouts.list</code></p>
<p><code translate="no" dir="ltr">saasservicemgmt.saas.list</code></p>
<p><code translate="no" dir="ltr">saasservicemgmt.saasReleases.list</code></p>
<p><code translate="no" dir="ltr">saasservicemgmt.tenantOperations.list</code></p>
<p><code translate="no" dir="ltr">saasservicemgmt.tenants.list</code></p>
<p><code translate="no" dir="ltr">saasservicemgmt.unitGroupOperations.list</code></p>
<p><code translate="no" dir="ltr">saasservicemgmt.unitGroups.list</code></p>
<p><code translate="no" dir="ltr">saasservicemgmt.unitKinds.list</code></p>
<p><code translate="no" dir="ltr">saasservicemgmt.unitOperations.list</code></p>
<p><code translate="no" dir="ltr">saasservicemgmt.units.list</code></p>
<p><code translate="no" dir="ltr">secretmanager.locations.list</code></p>
<p><code translate="no" dir="ltr">secretmanager.secrets.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">secretmanager.secrets.list</code></p>
<p><code translate="no" dir="ltr">secretmanager.secrets.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">secretmanager.versions.list</code></p>
<p><code translate="no" dir="ltr">securedlandingzone.overwatches.list</code></p>
<p><code translate="no" dir="ltr">securesourcemanager.branchRules.list</code></p>
<p><code translate="no" dir="ltr">securesourcemanager.hooks.list</code></p>
<p><code translate="no" dir="ltr">securesourcemanager.instances.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">securesourcemanager.instances.list</code></p>
<p><code translate="no" dir="ltr">securesourcemanager.instances.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">securesourcemanager.issuecomments.list</code></p>
<p><code translate="no" dir="ltr">securesourcemanager.issues.list</code></p>
<p><code translate="no" dir="ltr">securesourcemanager.locations.list</code></p>
<p><code translate="no" dir="ltr">securesourcemanager.operations.list</code></p>
<p><code translate="no" dir="ltr">securesourcemanager.prcomments.list</code></p>
<p><code translate="no" dir="ltr">securesourcemanager.pullRequests.list</code></p>
<p><code translate="no" dir="ltr">securesourcemanager.repositories.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">securesourcemanager.repositories.list</code></p>
<p><code translate="no" dir="ltr">securesourcemanager.repositories.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">securesourcemanager.sshkeys.list</code></p>
<p><code translate="no" dir="ltr">securitycenter.assets.list</code></p>
<p><code translate="no" dir="ltr">securitycenter.attackpaths.list</code></p>
<p><code translate="no" dir="ltr">securitycenter.bigQueryExports.list</code></p>
<p><code translate="no" dir="ltr">securitycenter.compliancesnapshots.list</code></p>
<p><code translate="no" dir="ltr">securitycenter.effectivesecurityhealthanalyticscustommodules.list</code></p>
<p><code translate="no" dir="ltr">securitycenter.findings.list</code></p>
<p><code translate="no" dir="ltr">securitycenter.issues.list</code></p>
<p><code translate="no" dir="ltr">securitycenter.muteconfigs.list</code></p>
<p><code translate="no" dir="ltr">securitycenter.notificationconfig.list</code></p>
<p><code translate="no" dir="ltr">securitycenter.resourcevalueconfigs.list</code></p>
<p><code translate="no" dir="ltr">securitycenter.riskreports.list</code></p>
<p><code translate="no" dir="ltr">securitycenter.securityhealthanalyticscustommodules.list</code></p>
<p><code translate="no" dir="ltr">securitycenter.sources.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">securitycenter.sources.list</code></p>
<p><code translate="no" dir="ltr">securitycenter.sources.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">securitycenter.valuedresources.list</code></p>
<p><code translate="no" dir="ltr">securitycenter.vulnerabilitysnapshots.list</code></p>
<p><code translate="no" dir="ltr">securitycentermanagement.effectiveEventThreatDetectionCustomModules.list</code></p>
<p><code translate="no" dir="ltr">securitycentermanagement.effectiveSecurityHealthAnalyticsCustomModules.list</code></p>
<p><code translate="no" dir="ltr">securitycentermanagement.eventThreatDetectionCustomModules.list</code></p>
<p><code translate="no" dir="ltr">securitycentermanagement.locations.list</code></p>
<p><code translate="no" dir="ltr">securitycentermanagement.operations.list</code></p>
<p><code translate="no" dir="ltr">securitycentermanagement.securityCenterServices.list</code></p>
<p><code translate="no" dir="ltr">securitycentermanagement.securityHealthAnalyticsCustomModules.list</code></p>
<p><code translate="no" dir="ltr">securityposture.locations.list</code></p>
<p><code translate="no" dir="ltr">securityposture.operations.list</code></p>
<p><code translate="no" dir="ltr">securityposture.postureDeployments.list</code></p>
<p><code translate="no" dir="ltr">securityposture.postureTemplates.list</code></p>
<p><code translate="no" dir="ltr">securityposture.postures.list</code></p>
<p><code translate="no" dir="ltr">securityposture.reports.list</code></p>
<p><code translate="no" dir="ltr">servicebroker.bindingoperations.list</code></p>
<p><code translate="no" dir="ltr">servicebroker.bindings.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">servicebroker.bindings.list</code></p>
<p><code translate="no" dir="ltr">servicebroker.bindings.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">servicebroker.catalogs.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">servicebroker.catalogs.list</code></p>
<p><code translate="no" dir="ltr">servicebroker.catalogs.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">servicebroker.instanceoperations.list</code></p>
<p><code translate="no" dir="ltr">servicebroker.instances.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">servicebroker.instances.list</code></p>
<p><code translate="no" dir="ltr">servicebroker.instances.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">serviceconsumermanagement.tenancyu.list</code></p>
<p><code translate="no" dir="ltr">servicedirectory.endpoints.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">servicedirectory.endpoints.list</code></p>
<p><code translate="no" dir="ltr">servicedirectory.endpoints.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">servicedirectory.locations.list</code></p>
<p><code translate="no" dir="ltr">servicedirectory.namespaces.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">servicedirectory.namespaces.list</code></p>
<p><code translate="no" dir="ltr">servicedirectory.namespaces.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">servicedirectory.services.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">servicedirectory.services.list</code></p>
<p><code translate="no" dir="ltr">servicedirectory.services.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">serviceextensions.locations.list</code></p>
<p><code translate="no" dir="ltr">servicehealth.artifacts.list</code></p>
<p><code translate="no" dir="ltr">servicehealth.events.list</code></p>
<p><code translate="no" dir="ltr">servicehealth.locations.list</code></p>
<p><code translate="no" dir="ltr">servicehealth.organizationEvents.list</code></p>
<p><code translate="no" dir="ltr">servicehealth.organizationImpacts.list</code></p>
<p><code translate="no" dir="ltr">servicemanagement.services.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">servicemanagement.services.list</code></p>
<p><code translate="no" dir="ltr">servicemanagement.services.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">servicenetworking.operations.list</code></p>
<p><code translate="no" dir="ltr">servicesecurityinsights.clusterSecurityInfo.list</code></p>
<p><code translate="no" dir="ltr">servicesecurityinsights.securityInfo.list</code></p>
<p><code translate="no" dir="ltr">servicesecurityinsights.workloadPolicies.list</code></p>
<p><code translate="no" dir="ltr">serviceusage.groups.list</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.list</code></p>
<p><code translate="no" dir="ltr">source.repos.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">source.repos.list</code></p>
<p><code translate="no" dir="ltr">source.repos.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">spanner.backupOperations.list</code></p>
<p><code translate="no" dir="ltr">spanner.backupSchedules.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">spanner.backupSchedules.list</code></p>
<p><code translate="no" dir="ltr">spanner.backupSchedules.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">spanner.backups.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">spanner.backups.list</code></p>
<p><code translate="no" dir="ltr">spanner.backups.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">spanner.databaseOperations.list</code></p>
<p><code translate="no" dir="ltr">spanner.databaseRoles.list</code></p>
<p><code translate="no" dir="ltr">spanner.databases.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">spanner.databases.list</code></p>
<p><code translate="no" dir="ltr">spanner.databases.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">spanner.instanceConfigOperations.list</code></p>
<p><code translate="no" dir="ltr">spanner.instanceConfigs.list</code></p>
<p><code translate="no" dir="ltr">spanner.instanceOperations.list</code></p>
<p><code translate="no" dir="ltr">spanner.instancePartitionOperations.list</code></p>
<p><code translate="no" dir="ltr">spanner.instancePartitions.list</code></p>
<p><code translate="no" dir="ltr">spanner.instances.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">spanner.instances.list</code></p>
<p><code translate="no" dir="ltr">spanner.instances.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">spanner.sessions.list</code></p>
<p><code translate="no" dir="ltr">speakerid.phrases.list</code></p>
<p><code translate="no" dir="ltr">speakerid.speakers.list</code></p>
<p><code translate="no" dir="ltr">speech.customClasses.list</code></p>
<p><code translate="no" dir="ltr">speech.locations.list</code></p>
<p><code translate="no" dir="ltr">speech.operations.list</code></p>
<p><code translate="no" dir="ltr">speech.phraseSets.list</code></p>
<p><code translate="no" dir="ltr">speech.recognizers.list</code></p>
<p><code translate="no" dir="ltr">stackdriver.resourceMetadata.list</code></p>
<p><code translate="no" dir="ltr">storage.anywhereCaches.list</code></p>
<p><code translate="no" dir="ltr">storage.bucketOperations.list</code></p>
<p><code translate="no" dir="ltr">storage.buckets.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">storage.buckets.list</code></p>
<p><code translate="no" dir="ltr">storage.buckets.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">storage.featureConfigs.list</code></p>
<p><code translate="no" dir="ltr">storage.folders.list</code></p>
<p><code translate="no" dir="ltr">storage.hmacKeys.list</code></p>
<p><code translate="no" dir="ltr">storage.managedFolders.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">storage.managedFolders.list</code></p>
<p><code translate="no" dir="ltr">storage.managedFolders.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">storage.multipartUploads.list</code></p>
<p><code translate="no" dir="ltr">storage.objects.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">storage.objects.list</code></p>
<p><code translate="no" dir="ltr">storage.objects.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">storagebatchoperations.bucketOperations.list</code></p>
<p><code translate="no" dir="ltr">storagebatchoperations.jobs.list</code></p>
<p><code translate="no" dir="ltr">storagebatchoperations.locations.list</code></p>
<p><code translate="no" dir="ltr">storagebatchoperations.operations.list</code></p>
<p><code translate="no" dir="ltr">storageinsights.datasetConfigs.list</code></p>
<p><code translate="no" dir="ltr">storageinsights.locations.list</code></p>
<p><code translate="no" dir="ltr">storageinsights.operations.list</code></p>
<p><code translate="no" dir="ltr">storageinsights.reportConfigs.list</code></p>
<p><code translate="no" dir="ltr">storageinsights.reportDetails.list</code></p>
<p><code translate="no" dir="ltr">storagetransfer.agentpools.list</code></p>
<p><code translate="no" dir="ltr">storagetransfer.jobs.list</code></p>
<p><code translate="no" dir="ltr">storagetransfer.operations.list</code></p>
<p><code translate="no" dir="ltr">stream.locations.list</code></p>
<p><code translate="no" dir="ltr">stream.operations.list</code></p>
<p><code translate="no" dir="ltr">stream.streamContents.list</code></p>
<p><code translate="no" dir="ltr">stream.streamInstances.list</code></p>
<p><code translate="no" dir="ltr">telcoautomation.blueprints.list</code></p>
<p><code translate="no" dir="ltr">telcoautomation.deployments.list</code></p>
<p><code translate="no" dir="ltr">telcoautomation.edgeSlms.list</code></p>
<p><code translate="no" dir="ltr">telcoautomation.hydratedDeployments.list</code></p>
<p><code translate="no" dir="ltr">telcoautomation.locations.list</code></p>
<p><code translate="no" dir="ltr">telcoautomation.operations.list</code></p>
<p><code translate="no" dir="ltr">telcoautomation.orchestrationClusters.list</code></p>
<p><code translate="no" dir="ltr">telcoautomation.publicBlueprints.list</code></p>
<p><code translate="no" dir="ltr">telemetry.consumers.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">telemetry.consumers.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">threatintelligence.alerts.list</code></p>
<p><code translate="no" dir="ltr">threatintelligence.configurations.list</code></p>
<p><code translate="no" dir="ltr">threatintelligence.findings.list</code></p>
<p><code translate="no" dir="ltr">tpu.acceleratortypes.list</code></p>
<p><code translate="no" dir="ltr">tpu.locations.list</code></p>
<p><code translate="no" dir="ltr">tpu.nodes.list</code></p>
<p><code translate="no" dir="ltr">tpu.operations.list</code></p>
<p><code translate="no" dir="ltr">tpu.runtimeversions.list</code></p>
<p><code translate="no" dir="ltr">tpu.tensorflowversions.list</code></p>
<p><code translate="no" dir="ltr">transcoder.jobTemplates.list</code></p>
<p><code translate="no" dir="ltr">transcoder.jobs.list</code></p>
<p><code translate="no" dir="ltr">transferappliance.appliances.list</code></p>
<p><code translate="no" dir="ltr">transferappliance.locations.list</code></p>
<p><code translate="no" dir="ltr">transferappliance.operations.list</code></p>
<p><code translate="no" dir="ltr">transferappliance.orders.list</code></p>
<p><code translate="no" dir="ltr">transferappliance.savedAddresses.list</code></p>
<p><code translate="no" dir="ltr">translationhub.portals.list</code></p>
<p><code translate="no" dir="ltr">universalledger.endpoints.list</code></p>
<p><code translate="no" dir="ltr">universalledger.locations.list</code></p>
<p><code translate="no" dir="ltr">vectorsearch.collections.list</code></p>
<p><code translate="no" dir="ltr">vectorsearch.indexes.list</code></p>
<p><code translate="no" dir="ltr">vectorsearch.locations.list</code></p>
<p><code translate="no" dir="ltr">vectorsearch.operations.list</code></p>
<p><code translate="no" dir="ltr">videostitcher.cdnKeys.list</code></p>
<p><code translate="no" dir="ltr">videostitcher.liveAdTagDetails.list</code></p>
<p><code translate="no" dir="ltr">videostitcher.liveConfigs.list</code></p>
<p><code translate="no" dir="ltr">videostitcher.operations.list</code></p>
<p><code translate="no" dir="ltr">videostitcher.slates.list</code></p>
<p><code translate="no" dir="ltr">videostitcher.vodAdTagDetails.list</code></p>
<p><code translate="no" dir="ltr">videostitcher.vodConfigs.list</code></p>
<p><code translate="no" dir="ltr">videostitcher.vodStitchDetails.list</code></p>
<p><code translate="no" dir="ltr">visionai.analyses.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">visionai.analyses.list</code></p>
<p><code translate="no" dir="ltr">visionai.analyses.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">visionai.annotations.list</code></p>
<p><code translate="no" dir="ltr">visionai.applications.list</code></p>
<p><code translate="no" dir="ltr">visionai.assets.list</code></p>
<p><code translate="no" dir="ltr">visionai.clusters.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">visionai.clusters.list</code></p>
<p><code translate="no" dir="ltr">visionai.clusters.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">visionai.corpora.list</code></p>
<p><code translate="no" dir="ltr">visionai.dataSchemas.list</code></p>
<p><code translate="no" dir="ltr">visionai.drafts.list</code></p>
<p><code translate="no" dir="ltr">visionai.events.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">visionai.events.list</code></p>
<p><code translate="no" dir="ltr">visionai.events.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">visionai.indexEndpoints.list</code></p>
<p><code translate="no" dir="ltr">visionai.indexes.list</code></p>
<p><code translate="no" dir="ltr">visionai.instances.list</code></p>
<p><code translate="no" dir="ltr">visionai.locations.list</code></p>
<p><code translate="no" dir="ltr">visionai.operations.list</code></p>
<p><code translate="no" dir="ltr">visionai.operators.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">visionai.operators.list</code></p>
<p><code translate="no" dir="ltr">visionai.operators.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">visionai.processors.list</code></p>
<p><code translate="no" dir="ltr">visionai.searchConfigs.list</code></p>
<p><code translate="no" dir="ltr">visionai.series.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">visionai.series.list</code></p>
<p><code translate="no" dir="ltr">visionai.series.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">visionai.streams.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">visionai.streams.list</code></p>
<p><code translate="no" dir="ltr">visionai.streams.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">visionai.uistreams.list</code></p>
<p><code translate="no" dir="ltr">visualinspection.annotationSets.list</code></p>
<p><code translate="no" dir="ltr">visualinspection.annotationSpecs.list</code></p>
<p><code translate="no" dir="ltr">visualinspection.annotations.list</code></p>
<p><code translate="no" dir="ltr">visualinspection.datasets.list</code></p>
<p><code translate="no" dir="ltr">visualinspection.images.list</code></p>
<p><code translate="no" dir="ltr">visualinspection.locations.list</code></p>
<p><code translate="no" dir="ltr">visualinspection.modelEvaluations.list</code></p>
<p><code translate="no" dir="ltr">visualinspection.models.list</code></p>
<p><code translate="no" dir="ltr">visualinspection.modules.list</code></p>
<p><code translate="no" dir="ltr">visualinspection.operations.list</code></p>
<p><code translate="no" dir="ltr">visualinspection.solutionArtifacts.list</code></p>
<p><code translate="no" dir="ltr">visualinspection.solutions.list</code></p>
<p><code translate="no" dir="ltr">vmmigration.cloneJobs.list</code></p>
<p><code translate="no" dir="ltr">vmmigration.cutoverJobs.list</code></p>
<p><code translate="no" dir="ltr">vmmigration.datacenterConnectors.list</code></p>
<p><code translate="no" dir="ltr">vmmigration.deployments.list</code></p>
<p><code translate="no" dir="ltr">vmmigration.groups.list</code></p>
<p><code translate="no" dir="ltr">vmmigration.imageImportJobs.list</code></p>
<p><code translate="no" dir="ltr">vmmigration.imageImports.list</code></p>
<p><code translate="no" dir="ltr">vmmigration.locations.list</code></p>
<p><code translate="no" dir="ltr">vmmigration.migratingVms.list</code></p>
<p><code translate="no" dir="ltr">vmmigration.operations.list</code></p>
<p><code translate="no" dir="ltr">vmmigration.replicationCycles.list</code></p>
<p><code translate="no" dir="ltr">vmmigration.sources.list</code></p>
<p><code translate="no" dir="ltr">vmmigration.targets.list</code></p>
<p><code translate="no" dir="ltr">vmmigration.utilizationReports.list</code></p>
<p><code translate="no" dir="ltr">vmwareengine.clusters.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">vmwareengine.clusters.list</code></p>
<p><code translate="no" dir="ltr">vmwareengine.clusters.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">vmwareengine.datastores.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">vmwareengine.datastores.list</code></p>
<p><code translate="no" dir="ltr">vmwareengine.datastores.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">vmwareengine.externalAccessRules.list</code></p>
<p><code translate="no" dir="ltr">vmwareengine.externalAddresses.list</code></p>
<p><code translate="no" dir="ltr">vmwareengine.hcxActivationKeys.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">vmwareengine.hcxActivationKeys.list</code></p>
<p><code translate="no" dir="ltr">vmwareengine.hcxActivationKeys.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">vmwareengine.locations.list</code></p>
<p><code translate="no" dir="ltr">vmwareengine.loggingServers.list</code></p>
<p><code translate="no" dir="ltr">vmwareengine.managementDnsZoneBindings.list</code></p>
<p><code translate="no" dir="ltr">vmwareengine.networkPeerings.list</code></p>
<p><code translate="no" dir="ltr">vmwareengine.networkPolicies.list</code></p>
<p><code translate="no" dir="ltr">vmwareengine.nodeTypes.list</code></p>
<p><code translate="no" dir="ltr">vmwareengine.nodes.list</code></p>
<p><code translate="no" dir="ltr">vmwareengine.operations.list</code></p>
<p><code translate="no" dir="ltr">vmwareengine.privateClouds.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">vmwareengine.privateClouds.list</code></p>
<p><code translate="no" dir="ltr">vmwareengine.privateClouds.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">vmwareengine.privateConnections.list</code></p>
<p><code translate="no" dir="ltr">vmwareengine.subnets.list</code></p>
<p><code translate="no" dir="ltr">vmwareengine.vmwareEngineNetworks.list</code></p>
<p><code translate="no" dir="ltr">vpcaccess.connectors.list</code></p>
<p><code translate="no" dir="ltr">vpcaccess.locations.list</code></p>
<p><code translate="no" dir="ltr">vpcaccess.operations.list</code></p>
<p><code translate="no" dir="ltr">workflows.callbacks.list</code></p>
<p><code translate="no" dir="ltr">workflows.executions.list</code></p>
<p><code translate="no" dir="ltr">workflows.locations.list</code></p>
<p><code translate="no" dir="ltr">workflows.operations.list</code></p>
<p><code translate="no" dir="ltr">workflows.stepEntries.list</code></p>
<p><code translate="no" dir="ltr">workflows.workflows.list</code></p>
<p><code translate="no" dir="ltr">workloadcertificate.locations.list</code></p>
<p><code translate="no" dir="ltr">workloadcertificate.operations.list</code></p>
<p><code translate="no" dir="ltr">workloadcertificate.workloadRegistrations.list</code></p>
<p><code translate="no" dir="ltr">workloadidentity.locations.list</code></p>
<p><code translate="no" dir="ltr">workloadidentity.operations.list</code></p>
<p><code translate="no" dir="ltr">workloadmanager.actuations.list</code></p>
<p><code translate="no" dir="ltr">workloadmanager.deployments.list</code></p>
<p><code translate="no" dir="ltr">workloadmanager.discoveredprofiles.list</code></p>
<p><code translate="no" dir="ltr">workloadmanager.evaluations.list</code></p>
<p><code translate="no" dir="ltr">workloadmanager.executions.list</code></p>
<p><code translate="no" dir="ltr">workloadmanager.findings.list</code></p>
<p><code translate="no" dir="ltr">workloadmanager.locations.list</code></p>
<p><code translate="no" dir="ltr">workloadmanager.operations.list</code></p>
<p><code translate="no" dir="ltr">workloadmanager.results.list</code></p>
<p><code translate="no" dir="ltr">workloadmanager.rules.list</code></p>
<p><code translate="no" dir="ltr">workloadmanager.workloads.list</code></p>
<p><code translate="no" dir="ltr">workstations.operations.list</code></p>
<p><code translate="no" dir="ltr">workstations.workstationClusters.list</code></p>
<p><code translate="no" dir="ltr">workstations.workstationConfigs.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">workstations.workstationConfigs.list</code></p>
<p><code translate="no" dir="ltr">workstations.workstationConfigs.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">workstations.workstations.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">workstations.workstations.list</code></p>
<p><code translate="no" dir="ltr">workstations.workstations.setIamPolicy</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="iam.securityReviewer" class="role-title add-link" data-text="Security Reviewer " tabindex="-1">Security Reviewer</h4>
<p>(<code translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<span class="role-description custom"> </span>
<p>Provides permissions to list all resources and allow policies on them.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">accessapproval.requests.list</code></p>
<p><code translate="no" dir="ltr">accesscontextmanager.accessLevels.list</code></p>
<p><code translate="no" dir="ltr">accesscontextmanager.authorizedOrgsDescs.list</code></p>
<p><code translate="no" dir="ltr">accesscontextmanager.gcpUserAccessBindings.list</code></p>
<p><code translate="no" dir="ltr">accesscontextmanager.policies.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">accesscontextmanager.policies.list</code></p>
<p><code translate="no" dir="ltr">accesscontextmanager.servicePerimeters.list</code></p>
<p><code translate="no" dir="ltr">actions.agentVersions.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">advisorynotifications.notifications.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">advisorynotifications.notifications.get</code></li>
<li><code translate="no" dir="ltr">advisorynotifications.notifications.list</code></li>
</ul>
<p><code translate="no" dir="ltr">agentidentity.accessSummaries.list</code></p>
<p><code translate="no" dir="ltr">agentidentity.authProviders.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">agentidentity.authProviders.list</code></p>
<p><code translate="no" dir="ltr">agentidentity.authorizations.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">agentidentity.authorizations.list</code></p>
<p><code translate="no" dir="ltr">agentidentity.locations.list</code></p>
<p><code translate="no" dir="ltr">agentregistry.agents.list</code></p>
<p><code translate="no" dir="ltr">agentregistry.bindings.list</code></p>
<p><code translate="no" dir="ltr">agentregistry.endpoints.list</code></p>
<p><code translate="no" dir="ltr">agentregistry.locations.list</code></p>
<p><code translate="no" dir="ltr">agentregistry.mcpServers.list</code></p>
<p><code translate="no" dir="ltr">agentregistry.operations.list</code></p>
<p><code translate="no" dir="ltr">agentregistry.publishers.list</code></p>
<p><code translate="no" dir="ltr">agentregistry.services.list</code></p>
<p><code translate="no" dir="ltr">agentregistry.skillRevisions.list</code></p>
<p><code translate="no" dir="ltr">agentregistry.skills.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">agentregistry.skills.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.agentAnomalyDetectionScopes.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.agentExamples.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.agentMemories.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.agents.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">aiplatform.agents.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.analyzedInvocations.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.analyzedSessions.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.annotationSpecs.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.annotations.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.apps.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.artifacts.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.batchPredictionJobs.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.cachedContents.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.contexts.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.customJobs.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.dataItems.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.dataLabelingJobs.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.datasetVersions.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.datasets.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.deploymentResourcePools.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.edgeDeploymentJobs.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.edgeDevices.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.endpoints.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">aiplatform.endpoints.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.entityTypes.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">aiplatform.entityTypes.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.evaluationExperiments.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.evaluationItems.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.evaluationMetrics.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.evaluationRuns.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.evaluationSets.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.exampleStores.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.executions.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.extensions.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.featureGroups.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">aiplatform.featureGroups.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.featureMonitorJobs.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.featureMonitors.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.featureOnlineStores.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">aiplatform.featureOnlineStores.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.featureViewSyncs.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.featureViews.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">aiplatform.featureViews.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.features.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.featurestores.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">aiplatform.featurestores.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.humanInTheLoops.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.hyperparameterTuningJobs.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.indexEndpoints.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.indexes.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.interactions.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.locations.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.memories.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.memoryRevisions.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.metadataSchemas.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.metadataStores.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.modelDeploymentMonitoringJobs.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.modelEvaluationSlices.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.modelEvaluations.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.modelMonitoringJobs.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.modelMonitors.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.models.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.monitoredAgents.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.nasJobs.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.nasTrialDetails.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.notebookExecutionJobs.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.notebookRuntimeTemplates.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">aiplatform.notebookRuntimeTemplates.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.notebookRuntimes.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.onlineEvaluators.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.operations.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.persistentResources.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.pipelineJobs.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.provisionedThroughputRevisions.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.provisionedThroughputs.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.ragCorpora.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.ragFiles.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.reasoningEngineRuntimeRevisions.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.reasoningEngines.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">aiplatform.reasoningEngines.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.sandboxEnvironments.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.schedules.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.semanticGovernancePolicies.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.sessionEvents.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.sessions.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.specialistPools.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.studies.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.tasks.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.tensorboardExperiments.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.tensorboardRuns.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.tensorboardTimeSeries.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.tensorboards.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.trainingPipelines.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.trials.list</code></p>
<p><code translate="no" dir="ltr">aiplatform.tuningJobs.list</code></p>
<p><code translate="no" dir="ltr">alloydb.backups.list</code></p>
<p><code translate="no" dir="ltr">alloydb.clusters.list</code></p>
<p><code translate="no" dir="ltr">alloydb.databases.list</code></p>
<p><code translate="no" dir="ltr">alloydb.instances.list</code></p>
<p><code translate="no" dir="ltr">alloydb.locations.list</code></p>
<p><code translate="no" dir="ltr">alloydb.operations.list</code></p>
<p><code translate="no" dir="ltr">alloydb.supportedDatabaseFlags.list</code></p>
<p><code translate="no" dir="ltr">alloydb.users.list</code></p>
<p><code translate="no" dir="ltr">analyticshub.dataExchanges.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">analyticshub.dataExchanges.list</code></p>
<p><code translate="no" dir="ltr">analyticshub.listings.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">analyticshub.listings.list</code></p>
<p><code translate="no" dir="ltr">analyticshub.queryTemplates.list</code></p>
<p><code translate="no" dir="ltr">analyticshub.subscriptions.list</code></p>
<p><code translate="no" dir="ltr">apigateway.apiconfigs.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">apigateway.apiconfigs.list</code></p>
<p><code translate="no" dir="ltr">apigateway.apis.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">apigateway.apis.list</code></p>
<p><code translate="no" dir="ltr">apigateway.gateways.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">apigateway.gateways.list</code></p>
<p><code translate="no" dir="ltr">apigateway.locations.list</code></p>
<p><code translate="no" dir="ltr">apigateway.operations.list</code></p>
<p><code translate="no" dir="ltr">apigee.apiproductattributes.list</code></p>
<p><code translate="no" dir="ltr">apigee.apiproducts.list</code></p>
<p><code translate="no" dir="ltr">apigee.appgroupapps.list</code></p>
<p><code translate="no" dir="ltr">apigee.appgroups.list</code></p>
<p><code translate="no" dir="ltr">apigee.appgroupsubscriptions.list</code></p>
<p><code translate="no" dir="ltr">apigee.apps.list</code></p>
<p><code translate="no" dir="ltr">apigee.archivedeployments.list</code></p>
<p><code translate="no" dir="ltr">apigee.caches.list</code></p>
<p><code translate="no" dir="ltr">apigee.datacollectors.list</code></p>
<p><code translate="no" dir="ltr">apigee.datastores.list</code></p>
<p><code translate="no" dir="ltr">apigee.deployments.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">apigee.deployments.list</code></p>
<p><code translate="no" dir="ltr">apigee.developerappattributes.list</code></p>
<p><code translate="no" dir="ltr">apigee.developerapps.list</code></p>
<p><code translate="no" dir="ltr">apigee.developerattributes.list</code></p>
<p><code translate="no" dir="ltr">apigee.developers.list</code></p>
<p><code translate="no" dir="ltr">apigee.developersubscriptions.list</code></p>
<p><code translate="no" dir="ltr">apigee.dnsZones.list</code></p>
<p><code translate="no" dir="ltr">apigee.endpointattachments.list</code></p>
<p><code translate="no" dir="ltr">apigee.envgroupattachments.list</code></p>
<p><code translate="no" dir="ltr">apigee.envgroups.list</code></p>
<p><code translate="no" dir="ltr">apigee.environments.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">apigee.environments.list</code></p>
<p><code translate="no" dir="ltr">apigee.exports.list</code></p>
<p><code translate="no" dir="ltr">apigee.flowhooks.list</code></p>
<p><code translate="no" dir="ltr">apigee.hostqueries.list</code></p>
<p><code translate="no" dir="ltr">apigee.hostsecurityreports.list</code></p>
<p><code translate="no" dir="ltr">apigee.instanceattachments.list</code></p>
<p><code translate="no" dir="ltr">apigee.instances.list</code></p>
<p><code translate="no" dir="ltr">apigee.keystorealiases.list</code></p>
<p><code translate="no" dir="ltr">apigee.keystores.list</code></p>
<p><code translate="no" dir="ltr">apigee.keyvaluemapentries.list</code></p>
<p><code translate="no" dir="ltr">apigee.keyvaluemaps.list</code></p>
<p><code translate="no" dir="ltr">apigee.nataddresses.list</code></p>
<p><code translate="no" dir="ltr">apigee.operations.list</code></p>
<p><code translate="no" dir="ltr">apigee.organizations.list</code></p>
<p><code translate="no" dir="ltr">apigee.portals.list</code></p>
<p><code translate="no" dir="ltr">apigee.proxies.list</code></p>
<p><code translate="no" dir="ltr">apigee.proxyrevisions.list</code></p>
<p><code translate="no" dir="ltr">apigee.queries.list</code></p>
<p><code translate="no" dir="ltr">apigee.rateplans.list</code></p>
<p><code translate="no" dir="ltr">apigee.references.list</code></p>
<p><code translate="no" dir="ltr">apigee.reports.list</code></p>
<p><code translate="no" dir="ltr">apigee.resourcefiles.list</code></p>
<p><code translate="no" dir="ltr">apigee.securityActions.list</code></p>
<p><code translate="no" dir="ltr">apigee.securityFeedback.list</code></p>
<p><code translate="no" dir="ltr">apigee.securityIncidents.list</code></p>
<p><code translate="no" dir="ltr">apigee.securityMonitoringConditions.list</code></p>
<p><code translate="no" dir="ltr">apigee.securityProfiles.list</code></p>
<p><code translate="no" dir="ltr">apigee.securityProfilesV2.list</code></p>
<p><code translate="no" dir="ltr">apigee.securityreports.list</code></p>
<p><code translate="no" dir="ltr">apigee.sharedflowrevisions.list</code></p>
<p><code translate="no" dir="ltr">apigee.sharedflows.list</code></p>
<p><code translate="no" dir="ltr">apigee.spaces.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">apigee.spaces.list</code></p>
<p><code translate="no" dir="ltr">apigee.targetservers.list</code></p>
<p><code translate="no" dir="ltr">apigee.traceconfigoverrides.list</code></p>
<p><code translate="no" dir="ltr">apigee.tracesessions.list</code></p>
<p><code translate="no" dir="ltr">apigeeconnect.connections.list</code></p>
<p><code translate="no" dir="ltr">apigeeregistry.apis.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">apigeeregistry.apis.list</code></p>
<p><code translate="no" dir="ltr">apigeeregistry.artifacts.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">apigeeregistry.artifacts.list</code></p>
<p><code translate="no" dir="ltr">apigeeregistry.deployments.list</code></p>
<p><code translate="no" dir="ltr">apigeeregistry.locations.list</code></p>
<p><code translate="no" dir="ltr">apigeeregistry.operations.list</code></p>
<p><code translate="no" dir="ltr">apigeeregistry.specs.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">apigeeregistry.specs.list</code></p>
<p><code translate="no" dir="ltr">apigeeregistry.versions.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">apigeeregistry.versions.list</code></p>
<p><code translate="no" dir="ltr">apihub.addons.list</code></p>
<p><code translate="no" dir="ltr">apihub.apiHubInstances.list</code></p>
<p><code translate="no" dir="ltr">apihub.apiOperations.list</code></p>
<p><code translate="no" dir="ltr">apihub.apis.list</code></p>
<p><code translate="no" dir="ltr">apihub.attributes.list</code></p>
<p><code translate="no" dir="ltr">apihub.curations.list</code></p>
<p><code translate="no" dir="ltr">apihub.definitions.list</code></p>
<p><code translate="no" dir="ltr">apihub.dependencies.list</code></p>
<p><code translate="no" dir="ltr">apihub.deployments.list</code></p>
<p><code translate="no" dir="ltr">apihub.discoveredApiObservations.list</code></p>
<p><code translate="no" dir="ltr">apihub.discoveredApiOperations.list</code></p>
<p><code translate="no" dir="ltr">apihub.externalApis.list</code></p>
<p><code translate="no" dir="ltr">apihub.hostProjectRegistrations.list</code></p>
<p><code translate="no" dir="ltr">apihub.llmEnablements.list</code></p>
<p><code translate="no" dir="ltr">apihub.operations.list</code></p>
<p><code translate="no" dir="ltr">apihub.plugininstances.list</code></p>
<p><code translate="no" dir="ltr">apihub.plugins.list</code></p>
<p><code translate="no" dir="ltr">apihub.runTimeProjectAttachments.list</code></p>
<p><code translate="no" dir="ltr">apihub.specs.list</code></p>
<p><code translate="no" dir="ltr">apihub.versions.list</code></p>
<p><code translate="no" dir="ltr">apikeys.keys.list</code></p>
<p><code translate="no" dir="ltr">apim.apiObservations.list</code></p>
<p><code translate="no" dir="ltr">apim.apiOperations.list</code></p>
<p><code translate="no" dir="ltr">apim.locations.list</code></p>
<p><code translate="no" dir="ltr">apim.observationJobs.list</code></p>
<p><code translate="no" dir="ltr">apim.observationSources.list</code></p>
<p><code translate="no" dir="ltr">apim.operations.list</code></p>
<p><code translate="no" dir="ltr">appengine.instances.list</code></p>
<p><code translate="no" dir="ltr">appengine.memcache.list</code></p>
<p><code translate="no" dir="ltr">appengine.operations.list</code></p>
<p><code translate="no" dir="ltr">appengine.services.list</code></p>
<p><code translate="no" dir="ltr">appengine.versions.list</code></p>
<p><code translate="no" dir="ltr">apphub.applications.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">apphub.applications.list</code></p>
<p><code translate="no" dir="ltr">apphub.discoveredServices.list</code></p>
<p><code translate="no" dir="ltr">apphub.discoveredWorkloads.list</code></p>
<p><code translate="no" dir="ltr">apphub.extendedMetadataSchemas.list</code></p>
<p><code translate="no" dir="ltr">apphub.locations.list</code></p>
<p><code translate="no" dir="ltr">apphub.operations.list</code></p>
<p><code translate="no" dir="ltr">apphub.serviceProjectAttachments.list</code></p>
<p><code translate="no" dir="ltr">apphub.services.list</code></p>
<p><code translate="no" dir="ltr">apphub.workloads.list</code></p>
<p><code translate="no" dir="ltr">applianceactivation.rttCommands.list</code></p>
<p><code translate="no" dir="ltr">appoptimize.locations.list</code></p>
<p><code translate="no" dir="ltr">appoptimize.operations.list</code></p>
<p><code translate="no" dir="ltr">appoptimize.reports.list</code></p>
<p><code translate="no" dir="ltr">apptopology.domains.list</code></p>
<p><code translate="no" dir="ltr">apptopology.locations.list</code></p>
<p><code translate="no" dir="ltr">apptopology.operations.list</code></p>
<p><code translate="no" dir="ltr">apptopology.topologyViews.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.attachments.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.dockerimages.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.files.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.locations.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.mavenartifacts.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.npmpackages.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.packages.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.pythonpackages.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">artifactregistry.repositories.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.rules.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.tags.list</code></p>
<p><code translate="no" dir="ltr">artifactregistry.versions.list</code></p>
<p><code translate="no" dir="ltr">assuredoss.locations.list</code></p>
<p><code translate="no" dir="ltr">assuredoss.metadata.list</code></p>
<p><code translate="no" dir="ltr">assuredoss.operations.list</code></p>
<p><code translate="no" dir="ltr">assuredworkloads.dbControlComplianceSummaries.list</code></p>
<p><code translate="no" dir="ltr">assuredworkloads.dbFindingSummaries.list</code></p>
<p><code translate="no" dir="ltr">assuredworkloads.dbFrameworkComplianceSummaries.list</code></p>
<p><code translate="no" dir="ltr">assuredworkloads.operations.list</code></p>
<p><code translate="no" dir="ltr">assuredworkloads.updates.list</code></p>
<p><code translate="no" dir="ltr">assuredworkloads.violations.list</code></p>
<p><code translate="no" dir="ltr">assuredworkloads.workload.list</code></p>
<p><code translate="no" dir="ltr">auditmanager.auditReports.list</code></p>
<p><code translate="no" dir="ltr">auditmanager.auditSchedules.list</code></p>
<p><code translate="no" dir="ltr">auditmanager.controlReports.list</code></p>
<p><code translate="no" dir="ltr">auditmanager.controls.list</code></p>
<p><code translate="no" dir="ltr">auditmanager.customComplianceFrameworks.list</code></p>
<p><code translate="no" dir="ltr">auditmanager.findings.list</code></p>
<p><code translate="no" dir="ltr">auditmanager.locations.list</code></p>
<p><code translate="no" dir="ltr">auditmanager.operations.list</code></p>
<p><code translate="no" dir="ltr">auditmanager.resourceEnrollmentStatuses.list</code></p>
<p><code translate="no" dir="ltr">automl.annotationSpecs.list</code></p>
<p><code translate="no" dir="ltr">automl.annotations.list</code></p>
<p><code translate="no" dir="ltr">automl.columnSpecs.list</code></p>
<p><code translate="no" dir="ltr">automl.datasets.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">automl.datasets.list</code></p>
<p><code translate="no" dir="ltr">automl.examples.list</code></p>
<p><code translate="no" dir="ltr">automl.files.list</code></p>
<p><code translate="no" dir="ltr">automl.humanAnnotationTasks.list</code></p>
<p><code translate="no" dir="ltr">automl.locations.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">automl.locations.list</code></p>
<p><code translate="no" dir="ltr">automl.modelEvaluations.list</code></p>
<p><code translate="no" dir="ltr">automl.models.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">automl.models.list</code></p>
<p><code translate="no" dir="ltr">automl.operations.list</code></p>
<p><code translate="no" dir="ltr">automl.tableSpecs.list</code></p>
<p><code translate="no" dir="ltr">automlrecommendations.apiKeys.list</code></p>
<p><code translate="no" dir="ltr">automlrecommendations.catalogItems.list</code></p>
<p><code translate="no" dir="ltr">automlrecommendations.catalogs.list</code></p>
<p><code translate="no" dir="ltr">automlrecommendations.eventStores.list</code></p>
<p><code translate="no" dir="ltr">automlrecommendations.events.list</code></p>
<p><code translate="no" dir="ltr">automlrecommendations.placements.list</code></p>
<p><code translate="no" dir="ltr">automlrecommendations.recommendations.list</code></p>
<p><code translate="no" dir="ltr">autoscaling.sites.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">backupdr.appliedAutoProtectionPolicies.list</code></p>
<p><code translate="no" dir="ltr">backupdr.autoProtectionBindings.list</code></p>
<p><code translate="no" dir="ltr">backupdr.autoProtectionPolicies.list</code></p>
<p><code translate="no" dir="ltr">backupdr.backupPlanAssociations.list</code></p>
<p><code translate="no" dir="ltr">backupdr.backupPlanRevisions.list</code></p>
<p><code translate="no" dir="ltr">backupdr.backupPlans.list</code></p>
<p><code translate="no" dir="ltr">backupdr.backupVaults.list</code></p>
<p><code translate="no" dir="ltr">backupdr.bindingMatchingResources.list</code></p>
<p><code translate="no" dir="ltr">backupdr.bvbackups.list</code></p>
<p><code translate="no" dir="ltr">backupdr.bvdataSources.list</code></p>
<p><code translate="no" dir="ltr">backupdr.dataSourceReferences.list</code></p>
<p><code translate="no" dir="ltr">backupdr.locations.list</code></p>
<p><code translate="no" dir="ltr">backupdr.managementServers.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">backupdr.managementServers.list</code></p>
<p><code translate="no" dir="ltr">backupdr.operations.list</code></p>
<p><code translate="no" dir="ltr">backupdr.resourceBackupConfigs.list</code></p>
<p><code translate="no" dir="ltr">baremetalsolution.instancequotas.list</code></p>
<p><code translate="no" dir="ltr">baremetalsolution.instances.list</code></p>
<p><code translate="no" dir="ltr">baremetalsolution.luns.list</code></p>
<p><code translate="no" dir="ltr">baremetalsolution.maintenanceevents.list</code></p>
<p><code translate="no" dir="ltr">baremetalsolution.networkquotas.list</code></p>
<p><code translate="no" dir="ltr">baremetalsolution.networks.list</code></p>
<p><code translate="no" dir="ltr">baremetalsolution.nfsshares.list</code></p>
<p><code translate="no" dir="ltr">baremetalsolution.osimages.list</code></p>
<p><code translate="no" dir="ltr">baremetalsolution.pods.list</code></p>
<p><code translate="no" dir="ltr">baremetalsolution.procurements.list</code></p>
<p><code translate="no" dir="ltr">baremetalsolution.skus.list</code></p>
<p><code translate="no" dir="ltr">baremetalsolution.snapshotschedulepolicies.list</code></p>
<p><code translate="no" dir="ltr">baremetalsolution.sshKeys.list</code></p>
<p><code translate="no" dir="ltr">baremetalsolution.storageaggregatepools.list</code></p>
<p><code translate="no" dir="ltr">baremetalsolution.volumequotas.list</code></p>
<p><code translate="no" dir="ltr">baremetalsolution.volumes.list</code></p>
<p><code translate="no" dir="ltr">baremetalsolution.volumesnapshots.list</code></p>
<p><code translate="no" dir="ltr">batch.jobs.list</code></p>
<p><code translate="no" dir="ltr">batch.locations.list</code></p>
<p><code translate="no" dir="ltr">batch.operations.list</code></p>
<p><code translate="no" dir="ltr">batch.resourceAllowances.list</code></p>
<p><code translate="no" dir="ltr">batch.tasks.list</code></p>
<p><code translate="no" dir="ltr">beyondcorp.appConnections.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">beyondcorp.appConnections.list</code></p>
<p><code translate="no" dir="ltr">beyondcorp.appConnectors.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">beyondcorp.appConnectors.list</code></p>
<p><code translate="no" dir="ltr">beyondcorp.appGateways.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">beyondcorp.appGateways.list</code></p>
<p><code translate="no" dir="ltr">beyondcorp.locations.list</code></p>
<p><code translate="no" dir="ltr">beyondcorp.operations.list</code></p>
<p><code translate="no" dir="ltr">beyondcorp.securityGateways.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">beyondcorp.securityGateways.list</code></p>
<p><code translate="no" dir="ltr">beyondcorp.sgApplications.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">beyondcorp.sgApplications.list</code></p>
<p><code translate="no" dir="ltr">beyondcorp.subscriptions.list</code></p>
<p><code translate="no" dir="ltr">biglake.catalogs.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">biglake.catalogs.list</code></p>
<p><code translate="no" dir="ltr">biglake.databases.list</code></p>
<p><code translate="no" dir="ltr">biglake.locks.list</code></p>
<p><code translate="no" dir="ltr">biglake.namespaces.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">biglake.namespaces.list</code></p>
<p><code translate="no" dir="ltr">biglake.tables.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">biglake.tables.list</code></p>
<p><code translate="no" dir="ltr">bigquery.capacityCommitments.list</code></p>
<p><code translate="no" dir="ltr">bigquery.connections.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigquery.connections.list</code></p>
<p><code translate="no" dir="ltr">bigquery.dataPolicies.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigquery.dataPolicies.list</code></p>
<p><code translate="no" dir="ltr">bigquery.datasets.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigquery.jobs.list</code></p>
<p><code translate="no" dir="ltr">bigquery.models.list</code></p>
<p><code translate="no" dir="ltr">bigquery.propertyGraphs.list</code></p>
<p><code translate="no" dir="ltr">bigquery.reservationAssignments.list</code></p>
<p><code translate="no" dir="ltr">bigquery.reservationGroups.list</code></p>
<p><code translate="no" dir="ltr">bigquery.reservations.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigquery.reservations.list</code></p>
<p><code translate="no" dir="ltr">bigquery.routines.list</code></p>
<p><code translate="no" dir="ltr">bigquery.rowAccessPolicies.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigquery.rowAccessPolicies.list</code></p>
<p><code translate="no" dir="ltr">bigquery.savedqueries.list</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigquery.tables.list</code></p>
<p><code translate="no" dir="ltr">bigquerymigration.subtasks.list</code></p>
<p><code translate="no" dir="ltr">bigquerymigration.workflows.list</code></p>
<p><code translate="no" dir="ltr">bigtable.appProfiles.list</code></p>
<p><code translate="no" dir="ltr">bigtable.authorizedViews.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigtable.authorizedViews.list</code></p>
<p><code translate="no" dir="ltr">bigtable.backups.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigtable.backups.list</code></p>
<p><code translate="no" dir="ltr">bigtable.clusters.list</code></p>
<p><code translate="no" dir="ltr">bigtable.hotTablets.list</code></p>
<p><code translate="no" dir="ltr">bigtable.instances.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigtable.instances.list</code></p>
<p><code translate="no" dir="ltr">bigtable.keyvisualizer.list</code></p>
<p><code translate="no" dir="ltr">bigtable.locations.list</code></p>
<p><code translate="no" dir="ltr">bigtable.logicalViews.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigtable.logicalViews.list</code></p>
<p><code translate="no" dir="ltr">bigtable.materializedViews.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigtable.materializedViews.list</code></p>
<p><code translate="no" dir="ltr">bigtable.memoryLayers.list</code></p>
<p><code translate="no" dir="ltr">bigtable.schemaBundles.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigtable.schemaBundles.list</code></p>
<p><code translate="no" dir="ltr">bigtable.tables.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">bigtable.tables.list</code></p>
<p><code translate="no" dir="ltr">billing.accounts.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">billing.accounts.list</code></p>
<p><code translate="no" dir="ltr">billing.anomalies.list</code></p>
<p><code translate="no" dir="ltr">billing.billingAccountPrices.list</code></p>
<p><code translate="no" dir="ltr">billing.billingAccountServices.list</code></p>
<p><code translate="no" dir="ltr">billing.billingAccountSkuGroupSkus.list</code></p>
<p><code translate="no" dir="ltr">billing.billingAccountSkuGroups.list</code></p>
<p><code translate="no" dir="ltr">billing.billingAccountSkus.list</code></p>
<p><code translate="no" dir="ltr">billing.budgets.list</code></p>
<p><code translate="no" dir="ltr">billing.credits.list</code></p>
<p><code translate="no" dir="ltr">billing.resourceAssociations.list</code></p>
<p><code translate="no" dir="ltr">billing.subscriptions.list</code></p>
<p><code translate="no" dir="ltr">binaryauthorization.attestors.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">binaryauthorization.attestors.list</code></p>
<p><code translate="no" dir="ltr">binaryauthorization.continuousValidationConfig.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">binaryauthorization.platformPolicies.list</code></p>
<p><code translate="no" dir="ltr">binaryauthorization.policy.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">blockchainnodeengine.blockchainNodes.list</code></p>
<p><code translate="no" dir="ltr">blockchainnodeengine.locations.list</code></p>
<p><code translate="no" dir="ltr">blockchainnodeengine.operations.list</code></p>
<p><code translate="no" dir="ltr">blockchainvalidatormanager.blockchainValidatorConfigs.list</code></p>
<p><code translate="no" dir="ltr">blockchainvalidatormanager.locations.list</code></p>
<p><code translate="no" dir="ltr">blockchainvalidatormanager.operations.list</code></p>
<p><code translate="no" dir="ltr">capacityplanner.capacityPlans.list</code></p>
<p><code translate="no" dir="ltr">capacityplanner.forecasts.list</code></p>
<p><code translate="no" dir="ltr">capacityplanner.planAlertInsights.list</code></p>
<p><code translate="no" dir="ltr">capacityplanner.usageAlertInsights.list</code></p>
<p><code translate="no" dir="ltr">capacityplanner.usageHistories.list</code></p>
<p><code translate="no" dir="ltr">carestudio.patients.list</code></p>
<p><code translate="no" dir="ltr">certificatemanager.certissuanceconfigs.list</code></p>
<p><code translate="no" dir="ltr">certificatemanager.certmapentries.list</code></p>
<p><code translate="no" dir="ltr">certificatemanager.certmaps.list</code></p>
<p><code translate="no" dir="ltr">certificatemanager.certs.list</code></p>
<p><code translate="no" dir="ltr">certificatemanager.dnsauthorizations.list</code></p>
<p><code translate="no" dir="ltr">certificatemanager.locations.list</code></p>
<p><code translate="no" dir="ltr">certificatemanager.observedcerts.list</code></p>
<p><code translate="no" dir="ltr">certificatemanager.operations.list</code></p>
<p><code translate="no" dir="ltr">certificatemanager.trustconfigs.list</code></p>
<p><code translate="no" dir="ltr">ces.agents.list</code></p>
<p><code translate="no" dir="ltr">ces.appVersions.list</code></p>
<p><code translate="no" dir="ltr">ces.apps.list</code></p>
<p><code translate="no" dir="ltr">ces.assistantSessions.list</code></p>
<p><code translate="no" dir="ltr">ces.changelogs.list</code></p>
<p><code translate="no" dir="ltr">ces.conversations.list</code></p>
<p><code translate="no" dir="ltr">ces.deployments.list</code></p>
<p><code translate="no" dir="ltr">ces.evaluationDatasets.list</code></p>
<p><code translate="no" dir="ltr">ces.evaluationExpectations.list</code></p>
<p><code translate="no" dir="ltr">ces.evaluationResults.list</code></p>
<p><code translate="no" dir="ltr">ces.evaluationRuns.list</code></p>
<p><code translate="no" dir="ltr">ces.evaluations.list</code></p>
<p><code translate="no" dir="ltr">ces.examples.list</code></p>
<p><code translate="no" dir="ltr">ces.guardrails.list</code></p>
<p><code translate="no" dir="ltr">ces.locations.list</code></p>
<p><code translate="no" dir="ltr">ces.operations.list</code></p>
<p><code translate="no" dir="ltr">ces.tools.list</code></p>
<p><code translate="no" dir="ltr">ces.toolsets.list</code></p>
<p><code translate="no" dir="ltr">chronicle.analyticValues.list</code></p>
<p><code translate="no" dir="ltr">chronicle.analytics.list</code></p>
<p><code translate="no" dir="ltr">chronicle.chatSessionMessages.list</code></p>
<p><code translate="no" dir="ltr">chronicle.chatSessions.list</code></p>
<p><code translate="no" dir="ltr">chronicle.collectors.list</code></p>
<p><code translate="no" dir="ltr">chronicle.conversations.list</code></p>
<p><code translate="no" dir="ltr">chronicle.coverageDetails.list</code></p>
<p><code translate="no" dir="ltr">chronicle.curatedRuleSetCategories.list</code></p>
<p><code translate="no" dir="ltr">chronicle.curatedRuleSetDeployments.list</code></p>
<p><code translate="no" dir="ltr">chronicle.curatedRuleSets.list</code></p>
<p><code translate="no" dir="ltr">chronicle.curatedRules.list</code></p>
<p><code translate="no" dir="ltr">chronicle.dashboardCharts.list</code></p>
<p><code translate="no" dir="ltr">chronicle.dashboardQueries.list</code></p>
<p><code translate="no" dir="ltr">chronicle.dashboardScheduledReports.list</code></p>
<p><code translate="no" dir="ltr">chronicle.dashboards.list</code></p>
<p><code translate="no" dir="ltr">chronicle.dataAccessLabels.list</code></p>
<p><code translate="no" dir="ltr">chronicle.dataAccessScopes.list</code></p>
<p><code translate="no" dir="ltr">chronicle.dataExports.list</code></p>
<p><code translate="no" dir="ltr">chronicle.dataTableRows.list</code></p>
<p><code translate="no" dir="ltr">chronicle.dataTables.list</code></p>
<p><code translate="no" dir="ltr">chronicle.dataTaps.list</code></p>
<p><code translate="no" dir="ltr">chronicle.enrichmentControls.list</code></p>
<p><code translate="no" dir="ltr">chronicle.entities.list</code></p>
<p><code translate="no" dir="ltr">chronicle.extensionValidationReports.list</code></p>
<p><code translate="no" dir="ltr">chronicle.featuredContentNativeDashboards.list</code></p>
<p><code translate="no" dir="ltr">chronicle.featuredContentPlaybooks.list</code></p>
<p><code translate="no" dir="ltr">chronicle.featuredContentRules.list</code></p>
<p><code translate="no" dir="ltr">chronicle.featuredContentSearchQueries.list</code></p>
<p><code translate="no" dir="ltr">chronicle.features.list</code></p>
<p><code translate="no" dir="ltr">chronicle.federationGroups.list</code></p>
<p><code translate="no" dir="ltr">chronicle.feedPacks.list</code></p>
<p><code translate="no" dir="ltr">chronicle.feedSourceTypeSchemas.list</code></p>
<p><code translate="no" dir="ltr">chronicle.feeds.list</code></p>
<p><code translate="no" dir="ltr">chronicle.findingsRefinementDeployments.list</code></p>
<p><code translate="no" dir="ltr">chronicle.findingsRefinements.list</code></p>
<p><code translate="no" dir="ltr">chronicle.forwarders.list</code></p>
<p><code translate="no" dir="ltr">chronicle.ingestionLogLabels.list</code></p>
<p><code translate="no" dir="ltr">chronicle.ingestionLogNamespaces.list</code></p>
<p><code translate="no" dir="ltr">chronicle.investigationComments.list</code></p>
<p><code translate="no" dir="ltr">chronicle.investigationSteps.list</code></p>
<p><code translate="no" dir="ltr">chronicle.investigations.list</code></p>
<p><code translate="no" dir="ltr">chronicle.labsExperimentExecutions.list</code></p>
<p><code translate="no" dir="ltr">chronicle.labsExperiments.list</code></p>
<p><code translate="no" dir="ltr">chronicle.logProcessingPipelines.list</code></p>
<p><code translate="no" dir="ltr">chronicle.logTypeSchemas.list</code></p>
<p><code translate="no" dir="ltr">chronicle.logTypeSettings.list</code></p>
<p><code translate="no" dir="ltr">chronicle.logTypes.list</code></p>
<p><code translate="no" dir="ltr">chronicle.logs.list</code></p>
<p><code translate="no" dir="ltr">chronicle.messages.list</code></p>
<p><code translate="no" dir="ltr">chronicle.nativeDashboards.list</code></p>
<p><code translate="no" dir="ltr">chronicle.notebooks.list</code></p>
<p><code translate="no" dir="ltr">chronicle.operations.list</code></p>
<p><code translate="no" dir="ltr">chronicle.parserExtensions.list</code></p>
<p><code translate="no" dir="ltr">chronicle.parsers.list</code></p>
<p><code translate="no" dir="ltr">chronicle.parsingErrors.list</code></p>
<p><code translate="no" dir="ltr">chronicle.queryMetrics.list</code></p>
<p><code translate="no" dir="ltr">chronicle.referenceLists.list</code></p>
<p><code translate="no" dir="ltr">chronicle.retrohunts.list</code></p>
<p><code translate="no" dir="ltr">chronicle.ruleDeployments.list</code></p>
<p><code translate="no" dir="ltr">chronicle.ruleExecutionErrors.list</code></p>
<p><code translate="no" dir="ltr">chronicle.rules.list</code></p>
<p><code translate="no" dir="ltr">chronicle.savedColumnSets.list</code></p>
<p><code translate="no" dir="ltr">chronicle.searchQueries.list</code></p>
<p><code translate="no" dir="ltr">chronicle.searchedResults.list</code></p>
<p><code translate="no" dir="ltr">chronicle.sharedPreferenceSets.list</code></p>
<p><code translate="no" dir="ltr">chronicle.summaryTables.list</code></p>
<p><code translate="no" dir="ltr">chronicle.tagSubscriptions.list</code></p>
<p><code translate="no" dir="ltr">chronicle.tags.list</code></p>
<p><code translate="no" dir="ltr">chronicle.tenants.list</code></p>
<p><code translate="no" dir="ltr">chronicle.threatCollections.list</code></p>
<p><code translate="no" dir="ltr">chronicle.transformerDefinitions.list</code></p>
<p><code translate="no" dir="ltr">chronicle.validationErrors.list</code></p>
<p><code translate="no" dir="ltr">chronicle.watchlists.list</code></p>
<p><code translate="no" dir="ltr">chroniclesm.gcpAssociations.list</code></p>
<p><code translate="no" dir="ltr">chroniclesm.soarRoleScripts.list</code></p>
<p><code translate="no" dir="ltr">clientauthconfig.brands.list</code></p>
<p><code translate="no" dir="ltr">clientauthconfig.clients.list</code></p>
<p><code translate="no" dir="ltr">cloud.locations.list</code></p>
<p><code translate="no" dir="ltr">cloudaicompanion.aiDevToolsSettings.list</code></p>
<p><code translate="no" dir="ltr">cloudaicompanion.codeRepositoryIndexes.list</code></p>
<p><code translate="no" dir="ltr">cloudaicompanion.codeToolsSettings.list</code></p>
<p><code translate="no" dir="ltr">cloudaicompanion.dataSharingWithGoogleSettings.list</code></p>
<p><code translate="no" dir="ltr">cloudaicompanion.geminiGcpEnablementSettings.list</code></p>
<p><code translate="no" dir="ltr">cloudaicompanion.gibqObservabilitySettings.list</code></p>
<p><code translate="no" dir="ltr">cloudaicompanion.loggingSettings.list</code></p>
<p><code translate="no" dir="ltr">cloudaicompanion.operations.list</code></p>
<p><code translate="no" dir="ltr">cloudaicompanion.releaseChannelSettings.list</code></p>
<p><code translate="no" dir="ltr">cloudaicompanion.repositoryGroups.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudaicompanion.repositoryGroups.list</code></p>
<p><code translate="no" dir="ltr">cloudaicompanion.topics.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudapiregistry.locations.list</code></p>
<p><code translate="no" dir="ltr">cloudapiregistry.mcpServers.list</code></p>
<p><code translate="no" dir="ltr">cloudapiregistry.mcpTools.list</code></p>
<p><code translate="no" dir="ltr">cloudasset.feeds.list</code></p>
<p><code translate="no" dir="ltr">cloudasset.othercloudconnections.list</code></p>
<p><code translate="no" dir="ltr">cloudasset.savedqueries.list</code></p>
<p><code translate="no" dir="ltr">cloudbuild.builds.list</code></p>
<p><code translate="no" dir="ltr">cloudbuild.connections.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudbuild.connections.list</code></p>
<p><code translate="no" dir="ltr">cloudbuild.integrations.list</code></p>
<p><code translate="no" dir="ltr">cloudbuild.locations.list</code></p>
<p><code translate="no" dir="ltr">cloudbuild.operations.list</code></p>
<p><code translate="no" dir="ltr">cloudbuild.repositories.list</code></p>
<p><code translate="no" dir="ltr">cloudbuild.workerpools.list</code></p>
<p><code translate="no" dir="ltr">cloudcontrolspartner.accessapprovalrequests.list</code></p>
<p><code translate="no" dir="ltr">cloudcontrolspartner.customers.list</code></p>
<p><code translate="no" dir="ltr">cloudcontrolspartner.violations.list</code></p>
<p><code translate="no" dir="ltr">cloudcontrolspartner.workloads.list</code></p>
<p><code translate="no" dir="ltr">clouddebugger.breakpoints.list</code></p>
<p><code translate="no" dir="ltr">clouddebugger.debuggees.list</code></p>
<p><code translate="no" dir="ltr">clouddeploy.automationRuns.list</code></p>
<p><code translate="no" dir="ltr">clouddeploy.automations.list</code></p>
<p><code translate="no" dir="ltr">clouddeploy.customTargetTypes.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">clouddeploy.customTargetTypes.list</code></p>
<p><code translate="no" dir="ltr">clouddeploy.deliveryPipelines.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">clouddeploy.deliveryPipelines.list</code></p>
<p><code translate="no" dir="ltr">clouddeploy.deployPolicies.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">clouddeploy.deployPolicies.list</code></p>
<p><code translate="no" dir="ltr">clouddeploy.jobRuns.list</code></p>
<p><code translate="no" dir="ltr">clouddeploy.locations.list</code></p>
<p><code translate="no" dir="ltr">clouddeploy.operations.list</code></p>
<p><code translate="no" dir="ltr">clouddeploy.releases.list</code></p>
<p><code translate="no" dir="ltr">clouddeploy.rollouts.list</code></p>
<p><code translate="no" dir="ltr">clouddeploy.targets.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">clouddeploy.targets.list</code></p>
<p><code translate="no" dir="ltr">cloudfunctions.functions.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudfunctions.functions.list</code></p>
<p><code translate="no" dir="ltr">cloudfunctions.locations.list</code></p>
<p><code translate="no" dir="ltr">cloudfunctions.operations.list</code></p>
<p><code translate="no" dir="ltr">cloudjobdiscovery.companies.list</code></p>
<p><code translate="no" dir="ltr">cloudkms.cryptoKeyVersions.list</code></p>
<p><code translate="no" dir="ltr">cloudkms.cryptoKeys.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudkms.cryptoKeys.list</code></p>
<p><code translate="no" dir="ltr">cloudkms.ekmConfigs.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudkms.ekmConnections.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudkms.ekmConnections.list</code></p>
<p><code translate="no" dir="ltr">cloudkms.importJobs.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudkms.importJobs.list</code></p>
<p><code translate="no" dir="ltr">cloudkms.keyHandles.list</code></p>
<p><code translate="no" dir="ltr">cloudkms.keyRings.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudkms.keyRings.list</code></p>
<p><code translate="no" dir="ltr">cloudkms.locations.list</code></p>
<p><code translate="no" dir="ltr">cloudkms.protectableResources.list</code></p>
<p><code translate="no" dir="ltr">cloudkms.retiredResources.list</code></p>
<p><code translate="no" dir="ltr">cloudkms.singleTenantHsmInstanceProposals.list</code></p>
<p><code translate="no" dir="ltr">cloudkms.singleTenantHsmInstances.list</code></p>
<p><code translate="no" dir="ltr">cloudlocationfinder.cloudLocations.list</code></p>
<p><code translate="no" dir="ltr">cloudlocationfinder.locations.list</code></p>
<p><code translate="no" dir="ltr">cloudmessaging.topicSubscriptions.list</code></p>
<p><code translate="no" dir="ltr">cloudnotifications.activities.list</code></p>
<p><code translate="no" dir="ltr">cloudnumberregistry.customRanges.list</code></p>
<p><code translate="no" dir="ltr">cloudnumberregistry.discoveredRanges.list</code></p>
<p><code translate="no" dir="ltr">cloudnumberregistry.ipamAdminScopes.list</code></p>
<p><code translate="no" dir="ltr">cloudnumberregistry.locations.list</code></p>
<p><code translate="no" dir="ltr">cloudnumberregistry.operations.list</code></p>
<p><code translate="no" dir="ltr">cloudnumberregistry.realms.list</code></p>
<p><code translate="no" dir="ltr">cloudnumberregistry.registryBooks.list</code></p>
<p><code translate="no" dir="ltr">cloudonefs.isiloncloud.com/clusters.list</code></p>
<p><code translate="no" dir="ltr">cloudonefs.isiloncloud.com/fileshares.list</code></p>
<p><code translate="no" dir="ltr">cloudprivatecatalogproducer.associations.list</code></p>
<p><code translate="no" dir="ltr">cloudprivatecatalogproducer.catalogAssociations.list</code></p>
<p><code translate="no" dir="ltr">cloudprivatecatalogproducer.catalogs.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudprivatecatalogproducer.catalogs.list</code></p>
<p><code translate="no" dir="ltr">cloudprivatecatalogproducer.producerCatalogs.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudprivatecatalogproducer.producerCatalogs.list</code></p>
<p><code translate="no" dir="ltr">cloudprivatecatalogproducer.products.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudprivatecatalogproducer.products.list</code></p>
<p><code translate="no" dir="ltr">cloudprofiler.profiles.list</code></p>
<p><code translate="no" dir="ltr">cloudscheduler.jobs.list</code></p>
<p><code translate="no" dir="ltr">cloudscheduler.locations.list</code></p>
<p><code translate="no" dir="ltr">cloudsecuritycompliance.auditReports.list</code></p>
<p><code translate="no" dir="ltr">cloudsecuritycompliance.cloudControlDeployments.list</code></p>
<p><code translate="no" dir="ltr">cloudsecuritycompliance.cloudControlPredictions.list</code></p>
<p><code translate="no" dir="ltr">cloudsecuritycompliance.cloudControls.list</code></p>
<p><code translate="no" dir="ltr">cloudsecuritycompliance.controlComplianceSummaries.list</code></p>
<p><code translate="no" dir="ltr">cloudsecuritycompliance.controls.list</code></p>
<p><code translate="no" dir="ltr">cloudsecuritycompliance.findingSummaries.list</code></p>
<p><code translate="no" dir="ltr">cloudsecuritycompliance.findings.list</code></p>
<p><code translate="no" dir="ltr">cloudsecuritycompliance.frameworkAudits.list</code></p>
<p><code translate="no" dir="ltr">cloudsecuritycompliance.frameworkComplianceSummaries.list</code></p>
<p><code translate="no" dir="ltr">cloudsecuritycompliance.frameworkDeployments.list</code></p>
<p><code translate="no" dir="ltr">cloudsecuritycompliance.frameworks.list</code></p>
<p><code translate="no" dir="ltr">cloudsecuritycompliance.locations.list</code></p>
<p><code translate="no" dir="ltr">cloudsecuritycompliance.operations.list</code></p>
<p><code translate="no" dir="ltr">cloudsecuritycompliance.resourceEnrollmentStatuses.list</code></p>
<p><code translate="no" dir="ltr">cloudsecurityscanner.crawledurls.list</code></p>
<p><code translate="no" dir="ltr">cloudsecurityscanner.results.list</code></p>
<p><code translate="no" dir="ltr">cloudsecurityscanner.scanruns.list</code></p>
<p><code translate="no" dir="ltr">cloudsecurityscanner.scans.list</code></p>
<p><code translate="no" dir="ltr">cloudsql.backupRuns.list</code></p>
<p><code translate="no" dir="ltr">cloudsql.blueGreenDeployments.list</code></p>
<p><code translate="no" dir="ltr">cloudsql.databases.list</code></p>
<p><code translate="no" dir="ltr">cloudsql.instances.list</code></p>
<p><code translate="no" dir="ltr">cloudsql.sslCerts.list</code></p>
<p><code translate="no" dir="ltr">cloudsql.users.list</code></p>
<p><code translate="no" dir="ltr">cloudsql.workloadCaptures.list</code></p>
<p><code translate="no" dir="ltr">cloudsupport.accounts.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudsupport.accounts.list</code></p>
<p><code translate="no" dir="ltr">cloudsupport.techCases.list</code></p>
<p><code translate="no" dir="ltr">cloudtasks.locations.list</code></p>
<p><code translate="no" dir="ltr">cloudtasks.queues.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">cloudtasks.queues.list</code></p>
<p><code translate="no" dir="ltr">cloudtasks.tasks.list</code></p>
<p><code translate="no" dir="ltr">cloudtestservice.devicesession.list</code></p>
<p><code translate="no" dir="ltr">cloudtoolresults.executions.list</code></p>
<p><code translate="no" dir="ltr">cloudtoolresults.histories.list</code></p>
<p><code translate="no" dir="ltr">cloudtoolresults.steps.list</code></p>
<p><code translate="no" dir="ltr">cloudtrace.insights.list</code></p>
<p><code translate="no" dir="ltr">cloudtrace.tasks.list</code></p>
<p><code translate="no" dir="ltr">cloudtrace.traceScopes.list</code></p>
<p><code translate="no" dir="ltr">cloudtrace.traces.list</code></p>
<p><code translate="no" dir="ltr">cloudtranslate.adaptiveMtDatasets.list</code></p>
<p><code translate="no" dir="ltr">cloudtranslate.adaptiveMtFiles.list</code></p>
<p><code translate="no" dir="ltr">cloudtranslate.adaptiveMtSentences.list</code></p>
<p><code translate="no" dir="ltr">cloudtranslate.customModels.list</code></p>
<p><code translate="no" dir="ltr">cloudtranslate.datasets.list</code></p>
<p><code translate="no" dir="ltr">cloudtranslate.glossaries.list</code></p>
<p><code translate="no" dir="ltr">cloudtranslate.glossaryentries.list</code></p>
<p><code translate="no" dir="ltr">cloudtranslate.locations.list</code></p>
<p><code translate="no" dir="ltr">cloudtranslate.operations.list</code></p>
<p><code translate="no" dir="ltr">cloudvolumesgcp-api.netapp.com/activeDirectories.list</code></p>
<p><code translate="no" dir="ltr">cloudvolumesgcp-api.netapp.com/ipRanges.list</code></p>
<p><code translate="no" dir="ltr">cloudvolumesgcp-api.netapp.com/jobs.list</code></p>
<p><code translate="no" dir="ltr">cloudvolumesgcp-api.netapp.com/regions.list</code></p>
<p><code translate="no" dir="ltr">cloudvolumesgcp-api.netapp.com/serviceLevels.list</code></p>
<p><code translate="no" dir="ltr">cloudvolumesgcp-api.netapp.com/snapshots.list</code></p>
<p><code translate="no" dir="ltr">cloudvolumesgcp-api.netapp.com/volumereplication.list</code></p>
<p><code translate="no" dir="ltr">cloudvolumesgcp-api.netapp.com/volumes.list</code></p>
<p><code translate="no" dir="ltr">commerceagreementpublishing.agreements.list</code></p>
<p><code translate="no" dir="ltr">commerceagreementpublishing.documents.list</code></p>
<p><code translate="no" dir="ltr">commercebusinessenablement.operations.list</code></p>
<p><code translate="no" dir="ltr">commercebusinessenablement.partnerAccounts.list</code></p>
<p><code translate="no" dir="ltr">commercebusinessenablement.refunds.list</code></p>
<p><code translate="no" dir="ltr">commercebusinessenablement.resellerDiscountOffers.list</code></p>
<p><code translate="no" dir="ltr">commercebusinessenablement.resellerPrivateOfferPlans.list</code></p>
<p><code translate="no" dir="ltr">commercebusinessenablement.resellerRestrictions.list</code></p>
<p><code translate="no" dir="ltr">commerceoffercatalog.agreements.list</code></p>
<p><code translate="no" dir="ltr">commerceoffercatalog.documents.list</code></p>
<p><code translate="no" dir="ltr">commerceorggovernance.collectionRequestApprovals.list</code></p>
<p><code translate="no" dir="ltr">commerceorggovernance.collections.list</code></p>
<p><code translate="no" dir="ltr">commerceorggovernance.populateCollectionJobs.list</code></p>
<p><code translate="no" dir="ltr">commerceorggovernance.services.list</code></p>
<p><code translate="no" dir="ltr">commerceprice.events.list</code></p>
<p><code translate="no" dir="ltr">commerceprice.privateoffers.list</code></p>
<p><code translate="no" dir="ltr">commerceproducer.analyticsHubListingProductConfigs.list</code></p>
<p><code translate="no" dir="ltr">commerceproducer.consumerEnforcementActions.list</code></p>
<p><code translate="no" dir="ltr">commerceproducer.locations.list</code></p>
<p><code translate="no" dir="ltr">commerceproducer.privateOfferDocuments.list</code></p>
<p><code translate="no" dir="ltr">commerceproducer.privateOffers.list</code></p>
<p><code translate="no" dir="ltr">commerceproducer.products.list</code></p>
<p><code translate="no" dir="ltr">commerceproducer.releases.list</code></p>
<p><code translate="no" dir="ltr">commerceproducer.services.list</code></p>
<p><code translate="no" dir="ltr">commerceproducer.skuGroups.list</code></p>
<p><code translate="no" dir="ltr">commerceproducer.skus.list</code></p>
<p><code translate="no" dir="ltr">commerceproducer.standardOffers.list</code></p>
<p><code translate="no" dir="ltr">composer.dags.list</code></p>
<p><code translate="no" dir="ltr">composer.environments.list</code></p>
<p><code translate="no" dir="ltr">composer.imageversions.list</code></p>
<p><code translate="no" dir="ltr">composer.operations.list</code></p>
<p><code translate="no" dir="ltr">composer.userworkloadsconfigmaps.list</code></p>
<p><code translate="no" dir="ltr">composer.userworkloadssecrets.list</code></p>
<p><code translate="no" dir="ltr">compute.acceleratorTypes.list</code></p>
<p><code translate="no" dir="ltr">compute.addresses.list</code></p>
<p><code translate="no" dir="ltr">compute.autoscalers.list</code></p>
<p><code translate="no" dir="ltr">compute.backendBuckets.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.backendBuckets.list</code></p>
<p><code translate="no" dir="ltr">compute.backendServices.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.backendServices.list</code></p>
<p><code translate="no" dir="ltr">compute.commitments.list</code></p>
<p><code translate="no" dir="ltr">compute.crossSiteNetworks.list</code></p>
<p><code translate="no" dir="ltr">compute.diskTypes.list</code></p>
<p><code translate="no" dir="ltr">compute.disks.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.disks.list</code></p>
<p><code translate="no" dir="ltr">compute.externalVpnGateways.list</code></p>
<p><code translate="no" dir="ltr">compute.firewallPolicies.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.firewallPolicies.list</code></p>
<p><code translate="no" dir="ltr">compute.firewalls.list</code></p>
<p><code translate="no" dir="ltr">compute.folderRolloutPlans.list</code></p>
<p><code translate="no" dir="ltr">compute.folderRollouts.list</code></p>
<p><code translate="no" dir="ltr">compute.folderVmExtensionPolicies.list</code></p>
<p><code translate="no" dir="ltr">compute.folderVmExtensions.list</code></p>
<p><code translate="no" dir="ltr">compute.forwardingRules.list</code></p>
<p><code translate="no" dir="ltr">compute.futureReservations.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.futureReservations.list</code></p>
<p><code translate="no" dir="ltr">compute.globalAddresses.list</code></p>
<p><code translate="no" dir="ltr">compute.globalForwardingRules.list</code></p>
<p><code translate="no" dir="ltr">compute.globalNetworkEndpointGroups.list</code></p>
<p><code translate="no" dir="ltr">compute.globalOperations.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.globalOperations.list</code></p>
<p><code translate="no" dir="ltr">compute.globalPublicDelegatedPrefixes.list</code></p>
<p><code translate="no" dir="ltr">compute.healthChecks.list</code></p>
<p><code translate="no" dir="ltr">compute.hosts.list</code></p>
<p><code translate="no" dir="ltr">compute.httpHealthChecks.list</code></p>
<p><code translate="no" dir="ltr">compute.httpsHealthChecks.list</code></p>
<p><code translate="no" dir="ltr">compute.images.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.images.list</code></p>
<p><code translate="no" dir="ltr">compute.instanceGroupManagers.list</code></p>
<p><code translate="no" dir="ltr">compute.instanceGroups.list</code></p>
<p><code translate="no" dir="ltr">compute.instanceTemplates.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.instanceTemplates.list</code></p>
<p><code translate="no" dir="ltr">compute.instances.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.instances.list</code></p>
<p><code translate="no" dir="ltr">compute.instantSnapshotGroups.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.instantSnapshotGroups.list</code></p>
<p><code translate="no" dir="ltr">compute.instantSnapshots.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.instantSnapshots.list</code></p>
<p><code translate="no" dir="ltr">compute.interconnectAttachmentGroups.list</code></p>
<p><code translate="no" dir="ltr">compute.interconnectAttachments.list</code></p>
<p><code translate="no" dir="ltr">compute.interconnectGroups.list</code></p>
<p><code translate="no" dir="ltr">compute.interconnectLocations.list</code></p>
<p><code translate="no" dir="ltr">compute.interconnectRemoteLocations.list</code></p>
<p><code translate="no" dir="ltr">compute.interconnects.list</code></p>
<p><code translate="no" dir="ltr">compute.licenseCodes.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.licenseCodes.list</code></p>
<p><code translate="no" dir="ltr">compute.licenses.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.licenses.list</code></p>
<p><code translate="no" dir="ltr">compute.machineImages.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.machineImages.list</code></p>
<p><code translate="no" dir="ltr">compute.machineTypes.list</code></p>
<p><code translate="no" dir="ltr">compute.managedRulesets.list</code></p>
<p><code translate="no" dir="ltr">compute.multiMig.list</code></p>
<p><code translate="no" dir="ltr">compute.multiMigMembers.list</code></p>
<p><code translate="no" dir="ltr">compute.networkAttachments.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.networkAttachments.list</code></p>
<p><code translate="no" dir="ltr">compute.networkEdgeSecurityServices.list</code></p>
<p><code translate="no" dir="ltr">compute.networkEndpointGroups.list</code></p>
<p><code translate="no" dir="ltr">compute.networkProfiles.list</code></p>
<p><code translate="no" dir="ltr">compute.networks.list</code></p>
<p><code translate="no" dir="ltr">compute.nodeGroups.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.nodeGroups.list</code></p>
<p><code translate="no" dir="ltr">compute.nodeTemplates.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.nodeTemplates.list</code></p>
<p><code translate="no" dir="ltr">compute.nodeTypes.list</code></p>
<p><code translate="no" dir="ltr">compute.orgRolloutPlans.list</code></p>
<p><code translate="no" dir="ltr">compute.orgRollouts.list</code></p>
<p><code translate="no" dir="ltr">compute.orgVmExtensionPolicies.list</code></p>
<p><code translate="no" dir="ltr">compute.orgVmExtensions.list</code></p>
<p><code translate="no" dir="ltr">compute.packetMirrorings.list</code></p>
<p><code translate="no" dir="ltr">compute.previewFeatures.list</code></p>
<p><code translate="no" dir="ltr">compute.publicAdvertisedPrefixes.list</code></p>
<p><code translate="no" dir="ltr">compute.publicDelegatedPrefixes.list</code></p>
<p><code translate="no" dir="ltr">compute.recoverableSnapshots.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.recoverableSnapshots.list</code></p>
<p><code translate="no" dir="ltr">compute.regionBackendBuckets.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.regionBackendBuckets.list</code></p>
<p><code translate="no" dir="ltr">compute.regionBackendServices.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.regionBackendServices.list</code></p>
<p><code translate="no" dir="ltr">compute.regionCompositeHealthChecks.list</code></p>
<p><code translate="no" dir="ltr">compute.regionFirewallPolicies.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.regionFirewallPolicies.list</code></p>
<p><code translate="no" dir="ltr">compute.regionHealthAggregationPolicies.list</code></p>
<p><code translate="no" dir="ltr">compute.regionHealthCheckServices.list</code></p>
<p><code translate="no" dir="ltr">compute.regionHealthChecks.list</code></p>
<p><code translate="no" dir="ltr">compute.regionHealthSources.list</code></p>
<p><code translate="no" dir="ltr">compute.regionNetworkEndpointGroups.list</code></p>
<p><code translate="no" dir="ltr">compute.regionNetworkPolicies.list</code></p>
<p><code translate="no" dir="ltr">compute.regionNotificationEndpoints.list</code></p>
<p><code translate="no" dir="ltr">compute.regionOperations.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.regionOperations.list</code></p>
<p><code translate="no" dir="ltr">compute.regionSecurityPolicies.list</code></p>
<p><code translate="no" dir="ltr">compute.regionSslCertificates.list</code></p>
<p><code translate="no" dir="ltr">compute.regionSslPolicies.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.regionSslPolicies.list</code></p>
<p><code translate="no" dir="ltr">compute.regionTargetHttpProxies.list</code></p>
<p><code translate="no" dir="ltr">compute.regionTargetHttpsProxies.list</code></p>
<p><code translate="no" dir="ltr">compute.regionTargetTcpProxies.list</code></p>
<p><code translate="no" dir="ltr">compute.regionUrlMaps.list</code></p>
<p><code translate="no" dir="ltr">compute.regions.list</code></p>
<p><code translate="no" dir="ltr">compute.reliabilityRisks.list</code></p>
<p><code translate="no" dir="ltr">compute.reservationBlocks.list</code></p>
<p><code translate="no" dir="ltr">compute.reservationConsumedInstances.list</code></p>
<p><code translate="no" dir="ltr">compute.reservationSlots.list</code></p>
<p><code translate="no" dir="ltr">compute.reservationSubBlocks.list</code></p>
<p><code translate="no" dir="ltr">compute.reservations.list</code></p>
<p><code translate="no" dir="ltr">compute.resourcePolicies.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.resourcePolicies.list</code></p>
<p><code translate="no" dir="ltr">compute.rolloutPlans.list</code></p>
<p><code translate="no" dir="ltr">compute.rollouts.list</code></p>
<p><code translate="no" dir="ltr">compute.routers.list</code></p>
<p><code translate="no" dir="ltr">compute.routes.list</code></p>
<p><code translate="no" dir="ltr">compute.securityPolicies.list</code></p>
<p><code translate="no" dir="ltr">compute.serviceAttachments.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.serviceAttachments.list</code></p>
<p><code translate="no" dir="ltr">compute.snapshotGroups.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.snapshotGroups.list</code></p>
<p><code translate="no" dir="ltr">compute.snapshots.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.snapshots.list</code></p>
<p><code translate="no" dir="ltr">compute.sslCertificates.list</code></p>
<p><code translate="no" dir="ltr">compute.sslPolicies.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.sslPolicies.list</code></p>
<p><code translate="no" dir="ltr">compute.storagePools.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.storagePools.list</code></p>
<p><code translate="no" dir="ltr">compute.subnetworks.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.subnetworks.list</code></p>
<p><code translate="no" dir="ltr">compute.targetGrpcProxies.list</code></p>
<p><code translate="no" dir="ltr">compute.targetHttpProxies.list</code></p>
<p><code translate="no" dir="ltr">compute.targetHttpsProxies.list</code></p>
<p><code translate="no" dir="ltr">compute.targetInstances.list</code></p>
<p><code translate="no" dir="ltr">compute.targetPools.list</code></p>
<p><code translate="no" dir="ltr">compute.targetSslProxies.list</code></p>
<p><code translate="no" dir="ltr">compute.targetTcpProxies.list</code></p>
<p><code translate="no" dir="ltr">compute.targetVpnGateways.list</code></p>
<p><code translate="no" dir="ltr">compute.urlMaps.list</code></p>
<p><code translate="no" dir="ltr">compute.vmExtensionPolicies.list</code></p>
<p><code translate="no" dir="ltr">compute.vmExtensions.list</code></p>
<p><code translate="no" dir="ltr">compute.vpnGateways.list</code></p>
<p><code translate="no" dir="ltr">compute.vpnTunnels.list</code></p>
<p><code translate="no" dir="ltr">compute.wireGroups.list</code></p>
<p><code translate="no" dir="ltr">compute.zoneOperations.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">compute.zoneOperations.list</code></p>
<p><code translate="no" dir="ltr">compute.zones.list</code></p>
<p><code translate="no" dir="ltr">confidentialcomputing.locations.list</code></p>
<p><code translate="no" dir="ltr">config.deploymentgrouprevisions.list</code></p>
<p><code translate="no" dir="ltr">config.deploymentgroups.list</code></p>
<p><code translate="no" dir="ltr">config.deployments.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">config.deployments.list</code></p>
<p><code translate="no" dir="ltr">config.locations.list</code></p>
<p><code translate="no" dir="ltr">config.operations.list</code></p>
<p><code translate="no" dir="ltr">config.previews.list</code></p>
<p><code translate="no" dir="ltr">config.resourcechanges.list</code></p>
<p><code translate="no" dir="ltr">config.resourcedrifts.list</code></p>
<p><code translate="no" dir="ltr">config.resources.list</code></p>
<p><code translate="no" dir="ltr">config.revisions.list</code></p>
<p><code translate="no" dir="ltr">config.terraformversions.list</code></p>
<p><code translate="no" dir="ltr">configdelivery.fleetPackages.list</code></p>
<p><code translate="no" dir="ltr">configdelivery.locations.list</code></p>
<p><code translate="no" dir="ltr">configdelivery.operations.list</code></p>
<p><code translate="no" dir="ltr">configdelivery.releases.list</code></p>
<p><code translate="no" dir="ltr">configdelivery.resourceBundles.list</code></p>
<p><code translate="no" dir="ltr">configdelivery.rollouts.list</code></p>
<p><code translate="no" dir="ltr">configdelivery.variants.list</code></p>
<p><code translate="no" dir="ltr">connectors.actions.list</code></p>
<p><code translate="no" dir="ltr">connectors.connections.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">connectors.connections.list</code></p>
<p><code translate="no" dir="ltr">connectors.connectors.list</code></p>
<p><code translate="no" dir="ltr">connectors.customConnectorVersions.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">connectors.customConnectorVersions.list</code></p>
<p><code translate="no" dir="ltr">connectors.customConnectors.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">connectors.customConnectors.list</code></p>
<p><code translate="no" dir="ltr">connectors.endpointAttachments.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">connectors.endpointAttachments.list</code></p>
<p><code translate="no" dir="ltr">connectors.entities.list</code></p>
<p><code translate="no" dir="ltr">connectors.entityTypes.list</code></p>
<p><code translate="no" dir="ltr">connectors.eventSubscriptions.list</code></p>
<p><code translate="no" dir="ltr">connectors.eventtypes.list</code></p>
<p><code translate="no" dir="ltr">connectors.locations.list</code></p>
<p><code translate="no" dir="ltr">connectors.managedZones.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">connectors.managedZones.list</code></p>
<p><code translate="no" dir="ltr">connectors.operations.list</code></p>
<p><code translate="no" dir="ltr">connectors.providers.list</code></p>
<p><code translate="no" dir="ltr">connectors.versions.list</code></p>
<p><code translate="no" dir="ltr">consumerprocurement.accounts.list</code></p>
<p><code translate="no" dir="ltr">consumerprocurement.consents.list</code></p>
<p><code translate="no" dir="ltr">consumerprocurement.entitlements.list</code></p>
<p><code translate="no" dir="ltr">consumerprocurement.events.list</code></p>
<p><code translate="no" dir="ltr">consumerprocurement.freeTrials.list</code></p>
<p><code translate="no" dir="ltr">consumerprocurement.orderAttributions.list</code></p>
<p><code translate="no" dir="ltr">consumerprocurement.orders.list</code></p>
<p><code translate="no" dir="ltr">contactcenteraiplatform.contactCenters.list</code></p>
<p><code translate="no" dir="ltr">contactcenteraiplatform.locations.list</code></p>
<p><code translate="no" dir="ltr">contactcenteraiplatform.operations.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.analyses.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.analysisRules.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.assessmentRules.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.assessments.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.authorizedAnalyses.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.authorizedAssessments.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.authorizedConversations.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.authorizedFeedbackLabels.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.authorizedNotes.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.authorizedOperations.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.authorizedViewSets.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.authorizedViews.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.authorizedViews.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.conversations.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.datasetAnalyses.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.datasetConversations.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.datasetFeedbackLabels.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.datasets.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.diagnostics.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.discoveries.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.discoveryResults.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.discoveryRevisions.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.discoveryWorkspaces.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.faqEntries.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.faqModels.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.feedbackLabels.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.issueModels.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.issues.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.notes.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.operations.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.phraseMatchers.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.qaQuestionTags.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.qaQuestions.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.qaScorecardRevisions.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.qaScorecards.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.views.list</code></p>
<p><code translate="no" dir="ltr">contactcenterinsights.visibilityLabels.list</code></p>
<p><code translate="no" dir="ltr">container.apiServices.list</code></p>
<p><code translate="no" dir="ltr">container.auditSinks.list</code></p>
<p><code translate="no" dir="ltr">container.backendConfigs.list</code></p>
<p><code translate="no" dir="ltr">container.bindings.list</code></p>
<p><code translate="no" dir="ltr">container.certificateSigningRequests.list</code></p>
<p><code translate="no" dir="ltr">container.clusterRoleBindings.list</code></p>
<p><code translate="no" dir="ltr">container.clusterRoles.list</code></p>
<p><code translate="no" dir="ltr">container.clusters.list</code></p>
<p><code translate="no" dir="ltr">container.componentStatuses.list</code></p>
<p><code translate="no" dir="ltr">container.configMaps.list</code></p>
<p><code translate="no" dir="ltr">container.controllerRevisions.list</code></p>
<p><code translate="no" dir="ltr">container.cronJobs.list</code></p>
<p><code translate="no" dir="ltr">container.csiDrivers.list</code></p>
<p><code translate="no" dir="ltr">container.csiNodeInfos.list</code></p>
<p><code translate="no" dir="ltr">container.csiNodes.list</code></p>
<p><code translate="no" dir="ltr">container.customResourceDefinitions.list</code></p>
<p><code translate="no" dir="ltr">container.daemonSets.list</code></p>
<p><code translate="no" dir="ltr">container.deployments.list</code></p>
<p><code translate="no" dir="ltr">container.endpointSlices.list</code></p>
<p><code translate="no" dir="ltr">container.endpoints.list</code></p>
<p><code translate="no" dir="ltr">container.events.list</code></p>
<p><code translate="no" dir="ltr">container.frontendConfigs.list</code></p>
<p><code translate="no" dir="ltr">container.horizontalPodAutoscalers.list</code></p>
<p><code translate="no" dir="ltr">container.ingresses.list</code></p>
<p><code translate="no" dir="ltr">container.initializerConfigurations.list</code></p>
<p><code translate="no" dir="ltr">container.jobs.list</code></p>
<p><code translate="no" dir="ltr">container.leases.list</code></p>
<p><code translate="no" dir="ltr">container.limitRanges.list</code></p>
<p><code translate="no" dir="ltr">container.localSubjectAccessReviews.list</code></p>
<p><code translate="no" dir="ltr">container.managedCertificates.list</code></p>
<p><code translate="no" dir="ltr">container.mutatingWebhookConfigurations.list</code></p>
<p><code translate="no" dir="ltr">container.namespaces.list</code></p>
<p><code translate="no" dir="ltr">container.networkPolicies.list</code></p>
<p><code translate="no" dir="ltr">container.nodes.list</code></p>
<p><code translate="no" dir="ltr">container.operations.list</code></p>
<p><code translate="no" dir="ltr">container.persistentVolumeClaims.list</code></p>
<p><code translate="no" dir="ltr">container.persistentVolumes.list</code></p>
<p><code translate="no" dir="ltr">container.petSets.list</code></p>
<p><code translate="no" dir="ltr">container.podDisruptionBudgets.list</code></p>
<p><code translate="no" dir="ltr">container.podPresets.list</code></p>
<p><code translate="no" dir="ltr">container.podSecurityPolicies.list</code></p>
<p><code translate="no" dir="ltr">container.podTemplates.list</code></p>
<p><code translate="no" dir="ltr">container.pods.list</code></p>
<p><code translate="no" dir="ltr">container.priorityClasses.list</code></p>
<p><code translate="no" dir="ltr">container.replicaSets.list</code></p>
<p><code translate="no" dir="ltr">container.replicationControllers.list</code></p>
<p><code translate="no" dir="ltr">container.resourceQuotas.list</code></p>
<p><code translate="no" dir="ltr">container.roleBindings.list</code></p>
<p><code translate="no" dir="ltr">container.roles.list</code></p>
<p><code translate="no" dir="ltr">container.runtimeClasses.list</code></p>
<p><code translate="no" dir="ltr">container.scheduledJobs.list</code></p>
<p><code translate="no" dir="ltr">container.selfSubjectAccessReviews.list</code></p>
<p><code translate="no" dir="ltr">container.serviceAccounts.list</code></p>
<p><code translate="no" dir="ltr">container.services.list</code></p>
<p><code translate="no" dir="ltr">container.statefulSets.list</code></p>
<p><code translate="no" dir="ltr">container.storageClasses.list</code></p>
<p><code translate="no" dir="ltr">container.storageStates.list</code></p>
<p><code translate="no" dir="ltr">container.storageVersionMigrations.list</code></p>
<p><code translate="no" dir="ltr">container.subjectAccessReviews.list</code></p>
<p><code translate="no" dir="ltr">container.thirdPartyObjects.list</code></p>
<p><code translate="no" dir="ltr">container.thirdPartyResources.list</code></p>
<p><code translate="no" dir="ltr">container.updateInfos.list</code></p>
<p><code translate="no" dir="ltr">container.validatingWebhookConfigurations.list</code></p>
<p><code translate="no" dir="ltr">container.volumeAttachments.list</code></p>
<p><code translate="no" dir="ltr">container.volumeSnapshotClasses.list</code></p>
<p><code translate="no" dir="ltr">container.volumeSnapshotContents.list</code></p>
<p><code translate="no" dir="ltr">container.volumeSnapshots.list</code></p>
<p><code translate="no" dir="ltr">containeranalysis.notes.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">containeranalysis.notes.list</code></p>
<p><code translate="no" dir="ltr">containeranalysis.occurrences.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">containeranalysis.occurrences.list</code></p>
<p><code translate="no" dir="ltr">containersecurity.clusterSummaries.list</code></p>
<p><code translate="no" dir="ltr">containersecurity.findings.list</code></p>
<p><code translate="no" dir="ltr">containersecurity.locations.list</code></p>
<p><code translate="no" dir="ltr">contentwarehouse.corpora.list</code></p>
<p><code translate="no" dir="ltr">contentwarehouse.documentSchemas.list</code></p>
<p><code translate="no" dir="ltr">contentwarehouse.documents.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">contentwarehouse.documents.list</code></p>
<p><code translate="no" dir="ltr">contentwarehouse.ruleSets.list</code></p>
<p><code translate="no" dir="ltr">contentwarehouse.synonymSets.list</code></p>
<p><code translate="no" dir="ltr">databasecenter.databaseGroups.list</code></p>
<p><code translate="no" dir="ltr">databasecenter.fleetHealthStats.list</code></p>
<p><code translate="no" dir="ltr">databasecenter.fleetInsights.list</code></p>
<p><code translate="no" dir="ltr">databasecenter.fleetStats.list</code></p>
<p><code translate="no" dir="ltr">databasecenter.locations.list</code></p>
<p><code translate="no" dir="ltr">databasecenter.products.list</code></p>
<p><code translate="no" dir="ltr">databasecenter.queryStats.list</code></p>
<p><code translate="no" dir="ltr">databasecenter.reportConfigs.list</code></p>
<p><code translate="no" dir="ltr">databasecenter.userLabels.list</code></p>
<p><code translate="no" dir="ltr">databasecenter.userTags.list</code></p>
<p><code translate="no" dir="ltr">databaseinsights.locations.list</code></p>
<p><code translate="no" dir="ltr">databasesconsole.locations.list</code></p>
<p><code translate="no" dir="ltr">databasesconsole.operations.list</code></p>
<p><code translate="no" dir="ltr">databasesconsole.studioQueries.list</code></p>
<p><code translate="no" dir="ltr">datacatalog.categories.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">datacatalog.entries.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">datacatalog.entries.list</code></p>
<p><code translate="no" dir="ltr">datacatalog.entryGroups.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">datacatalog.entryGroups.list</code></p>
<p><code translate="no" dir="ltr">datacatalog.operations.list</code></p>
<p><code translate="no" dir="ltr">datacatalog.relationships.list</code></p>
<p><code translate="no" dir="ltr">datacatalog.tagTemplates.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">datacatalog.taxonomies.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">datacatalog.taxonomies.list</code></p>
<p><code translate="no" dir="ltr">dataconnectors.connectors.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataconnectors.connectors.list</code></p>
<p><code translate="no" dir="ltr">dataconnectors.locations.list</code></p>
<p><code translate="no" dir="ltr">dataconnectors.operations.list</code></p>
<p><code translate="no" dir="ltr">dataflow.jobs.list</code></p>
<p><code translate="no" dir="ltr">dataflow.messages.list</code></p>
<p><code translate="no" dir="ltr">dataflow.snapshots.list</code></p>
<p><code translate="no" dir="ltr">dataform.commentThreads.list</code></p>
<p><code translate="no" dir="ltr">dataform.comments.list</code></p>
<p><code translate="no" dir="ltr">dataform.compilationResults.list</code></p>
<p><code translate="no" dir="ltr">dataform.folders.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataform.locations.list</code></p>
<p><code translate="no" dir="ltr">dataform.operations.list</code></p>
<p><code translate="no" dir="ltr">dataform.releaseConfigs.list</code></p>
<p><code translate="no" dir="ltr">dataform.repositories.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataform.repositories.list</code></p>
<p><code translate="no" dir="ltr">dataform.teamFolders.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataform.workflowConfigs.list</code></p>
<p><code translate="no" dir="ltr">dataform.workflowInvocations.list</code></p>
<p><code translate="no" dir="ltr">dataform.workspaces.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataform.workspaces.list</code></p>
<p><code translate="no" dir="ltr">datafusion.artifacts.list</code></p>
<p><code translate="no" dir="ltr">datafusion.instances.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">datafusion.instances.list</code></p>
<p><code translate="no" dir="ltr">datafusion.locations.list</code></p>
<p><code translate="no" dir="ltr">datafusion.namespaces.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">datafusion.namespaces.list</code></p>
<p><code translate="no" dir="ltr">datafusion.operations.list</code></p>
<p><code translate="no" dir="ltr">datafusion.pipelineConnections.list</code></p>
<p><code translate="no" dir="ltr">datafusion.pipelines.list</code></p>
<p><code translate="no" dir="ltr">datafusion.profiles.list</code></p>
<p><code translate="no" dir="ltr">datafusion.secureKeys.list</code></p>
<p><code translate="no" dir="ltr">datalabeling.annotateddatasets.list</code></p>
<p><code translate="no" dir="ltr">datalabeling.annotationspecsets.list</code></p>
<p><code translate="no" dir="ltr">datalabeling.dataitems.list</code></p>
<p><code translate="no" dir="ltr">datalabeling.datasets.list</code></p>
<p><code translate="no" dir="ltr">datalabeling.examples.list</code></p>
<p><code translate="no" dir="ltr">datalabeling.instructions.list</code></p>
<p><code translate="no" dir="ltr">datalabeling.operations.list</code></p>
<p><code translate="no" dir="ltr">datalineage.events.list</code></p>
<p><code translate="no" dir="ltr">datalineage.processRevisions.list</code></p>
<p><code translate="no" dir="ltr">datalineage.processes.list</code></p>
<p><code translate="no" dir="ltr">datalineage.runs.list</code></p>
<p><code translate="no" dir="ltr">datamigration.connectionprofiles.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">datamigration.connectionprofiles.list</code></p>
<p><code translate="no" dir="ltr">datamigration.conversionworkspaces.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">datamigration.conversionworkspaces.list</code></p>
<p><code translate="no" dir="ltr">datamigration.locations.list</code></p>
<p><code translate="no" dir="ltr">datamigration.mappingrules.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">datamigration.migrationjobs.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">datamigration.migrationjobs.list</code></p>
<p><code translate="no" dir="ltr">datamigration.objects.list</code></p>
<p><code translate="no" dir="ltr">datamigration.operations.list</code></p>
<p><code translate="no" dir="ltr">datamigration.privateconnections.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">datamigration.privateconnections.list</code></p>
<p><code translate="no" dir="ltr">datapipelines.jobs.list</code></p>
<p><code translate="no" dir="ltr">datapipelines.pipelines.list</code></p>
<p><code translate="no" dir="ltr">dataplex.agentTasks.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.agentTasks.list</code></p>
<p><code translate="no" dir="ltr">dataplex.aspectTypes.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.aspectTypes.list</code></p>
<p><code translate="no" dir="ltr">dataplex.assetActions.list</code></p>
<p><code translate="no" dir="ltr">dataplex.assets.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.assets.list</code></p>
<p><code translate="no" dir="ltr">dataplex.changeRequests.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.changeRequests.list</code></p>
<p><code translate="no" dir="ltr">dataplex.content.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.content.list</code></p>
<p><code translate="no" dir="ltr">dataplex.dataAssets.list</code></p>
<p><code translate="no" dir="ltr">dataplex.dataAttributeBindings.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.dataAttributeBindings.list</code></p>
<p><code translate="no" dir="ltr">dataplex.dataAttributes.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.dataAttributes.list</code></p>
<p><code translate="no" dir="ltr">dataplex.dataDomainBindings.list</code></p>
<p><code translate="no" dir="ltr">dataplex.dataDomains.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.dataDomains.list</code></p>
<p><code translate="no" dir="ltr">dataplex.dataProducts.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.dataProducts.list</code></p>
<p><code translate="no" dir="ltr">dataplex.dataTaxonomies.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.dataTaxonomies.list</code></p>
<p><code translate="no" dir="ltr">dataplex.datascans.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.datascans.list</code></p>
<p><code translate="no" dir="ltr">dataplex.encryptionConfig.list</code></p>
<p><code translate="no" dir="ltr">dataplex.entities.list</code></p>
<p><code translate="no" dir="ltr">dataplex.entries.list</code></p>
<p><code translate="no" dir="ltr">dataplex.entryGroups.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.entryGroups.list</code></p>
<p><code translate="no" dir="ltr">dataplex.entryLinkTypes.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.entryLinkTypes.list</code></p>
<p><code translate="no" dir="ltr">dataplex.entryTypes.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.entryTypes.list</code></p>
<p><code translate="no" dir="ltr">dataplex.environments.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.environments.list</code></p>
<p><code translate="no" dir="ltr">dataplex.glossaries.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.glossaries.list</code></p>
<p><code translate="no" dir="ltr">dataplex.glossaryCategories.list</code></p>
<p><code translate="no" dir="ltr">dataplex.glossaryTerms.list</code></p>
<p><code translate="no" dir="ltr">dataplex.lakeActions.list</code></p>
<p><code translate="no" dir="ltr">dataplex.lakes.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.lakes.list</code></p>
<p><code translate="no" dir="ltr">dataplex.locations.list</code></p>
<p><code translate="no" dir="ltr">dataplex.metadataFeeds.list</code></p>
<p><code translate="no" dir="ltr">dataplex.metadataJobs.list</code></p>
<p><code translate="no" dir="ltr">dataplex.operations.list</code></p>
<p><code translate="no" dir="ltr">dataplex.partitions.list</code></p>
<p><code translate="no" dir="ltr">dataplex.tasks.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.tasks.list</code></p>
<p><code translate="no" dir="ltr">dataplex.zoneActions.list</code></p>
<p><code translate="no" dir="ltr">dataplex.zones.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataplex.zones.list</code></p>
<p><code translate="no" dir="ltr">dataproc.agents.list</code></p>
<p><code translate="no" dir="ltr">dataproc.autoscalingPolicies.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataproc.autoscalingPolicies.list</code></p>
<p><code translate="no" dir="ltr">dataproc.batches.list</code></p>
<p><code translate="no" dir="ltr">dataproc.clusters.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataproc.clusters.list</code></p>
<p><code translate="no" dir="ltr">dataproc.jobs.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataproc.jobs.list</code></p>
<p><code translate="no" dir="ltr">dataproc.operations.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataproc.operations.list</code></p>
<p><code translate="no" dir="ltr">dataproc.sessionTemplates.list</code></p>
<p><code translate="no" dir="ltr">dataproc.sessions.list</code></p>
<p><code translate="no" dir="ltr">dataproc.workflowTemplates.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dataproc.workflowTemplates.list</code></p>
<p><code translate="no" dir="ltr">dataprocessing.datasources.list</code></p>
<p><code translate="no" dir="ltr">dataprocessing.featurecontrols.list</code></p>
<p><code translate="no" dir="ltr">dataprocessing.groupcontrols.list</code></p>
<p><code translate="no" dir="ltr">dataprocrm.locations.list</code></p>
<p><code translate="no" dir="ltr">dataprocrm.nodePools.list</code></p>
<p><code translate="no" dir="ltr">dataprocrm.nodes.list</code></p>
<p><code translate="no" dir="ltr">dataprocrm.operations.list</code></p>
<p><code translate="no" dir="ltr">dataprocrm.workloads.list</code></p>
<p><code translate="no" dir="ltr">datastore.backupSchedules.list</code></p>
<p><code translate="no" dir="ltr">datastore.backups.list</code></p>
<p><code translate="no" dir="ltr">datastore.databases.list</code></p>
<p><code translate="no" dir="ltr">datastore.entities.list</code></p>
<p><code translate="no" dir="ltr">datastore.keyVisualizerScans.list</code></p>
<p><code translate="no" dir="ltr">datastore.locations.list</code></p>
<p><code translate="no" dir="ltr">datastore.namespaces.list</code></p>
<p><code translate="no" dir="ltr">datastore.operations.list</code></p>
<p><code translate="no" dir="ltr">datastore.schemas.list</code></p>
<p><code translate="no" dir="ltr">datastore.statistics.list</code></p>
<p><code translate="no" dir="ltr">datastore.userCreds.list</code></p>
<p><code translate="no" dir="ltr">datastream.connectionProfiles.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">datastream.connectionProfiles.list</code></p>
<p><code translate="no" dir="ltr">datastream.locations.list</code></p>
<p><code translate="no" dir="ltr">datastream.objects.list</code></p>
<p><code translate="no" dir="ltr">datastream.operations.list</code></p>
<p><code translate="no" dir="ltr">datastream.privateConnections.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">datastream.privateConnections.list</code></p>
<p><code translate="no" dir="ltr">datastream.routes.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">datastream.routes.list</code></p>
<p><code translate="no" dir="ltr">datastream.streams.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">datastream.streams.list</code></p>
<p><code translate="no" dir="ltr">datastudio.datasources.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">datastudio.reports.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">datastudio.workspaces.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">deploymentmanager.compositeTypes.list</code></p>
<p><code translate="no" dir="ltr">deploymentmanager.deployments.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">deploymentmanager.deployments.list</code></p>
<p><code translate="no" dir="ltr">deploymentmanager.manifests.list</code></p>
<p><code translate="no" dir="ltr">deploymentmanager.operations.list</code></p>
<p><code translate="no" dir="ltr">deploymentmanager.resources.list</code></p>
<p><code translate="no" dir="ltr">deploymentmanager.typeProviders.list</code></p>
<p><code translate="no" dir="ltr">deploymentmanager.types.list</code></p>
<p><code translate="no" dir="ltr">designcenter.applicationTemplateRevisions.list</code></p>
<p><code translate="no" dir="ltr">designcenter.applicationTemplates.list</code></p>
<p><code translate="no" dir="ltr">designcenter.applications.list</code></p>
<p><code translate="no" dir="ltr">designcenter.catalogTemplateRevisions.list</code></p>
<p><code translate="no" dir="ltr">designcenter.catalogTemplates.list</code></p>
<p><code translate="no" dir="ltr">designcenter.catalogs.list</code></p>
<p><code translate="no" dir="ltr">designcenter.components.list</code></p>
<p><code translate="no" dir="ltr">designcenter.connections.list</code></p>
<p><code translate="no" dir="ltr">designcenter.locations.list</code></p>
<p><code translate="no" dir="ltr">designcenter.operations.list</code></p>
<p><code translate="no" dir="ltr">designcenter.sharedTemplateRevisions.list</code></p>
<p><code translate="no" dir="ltr">designcenter.sharedTemplates.list</code></p>
<p><code translate="no" dir="ltr">designcenter.shares.list</code></p>
<p><code translate="no" dir="ltr">designcenter.spaces.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">designcenter.spaces.list</code></p>
<p><code translate="no" dir="ltr">developerconnect.accountConnectors.list</code></p>
<p><code translate="no" dir="ltr">developerconnect.connections.list</code></p>
<p><code translate="no" dir="ltr">developerconnect.deploymentEvents.list</code></p>
<p><code translate="no" dir="ltr">developerconnect.gitRepositoryLinks.list</code></p>
<p><code translate="no" dir="ltr">developerconnect.insightsConfigs.list</code></p>
<p><code translate="no" dir="ltr">developerconnect.locations.list</code></p>
<p><code translate="no" dir="ltr">developerconnect.operations.list</code></p>
<p><code translate="no" dir="ltr">developerconnect.providers.list</code></p>
<p><code translate="no" dir="ltr">developerconnect.users.list</code></p>
<p><code translate="no" dir="ltr">devicerun.devices.list</code></p>
<p><code translate="no" dir="ltr">devicerun.locations.list</code></p>
<p><code translate="no" dir="ltr">devicerun.operations.list</code></p>
<p><code translate="no" dir="ltr">devicerun.sessions.list</code></p>
<p><code translate="no" dir="ltr">devicerun.softwareVersions.list</code></p>
<p><code translate="no" dir="ltr">devicestreaming.deviceSessions.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.agents.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.answerrecords.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.callMatchers.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.changelogs.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.companionAgents.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.contexts.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.conversationDatasets.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.conversationModels.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.conversationProfiles.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.conversations.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.deployments.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.documents.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.entityTypes.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.environments.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.examples.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.experiments.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.flows.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.generators.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.integrations.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.intents.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.knowledgeBases.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.messages.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.modelEvaluations.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.pages.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.participants.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.phoneNumberOrders.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.phoneNumbers.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.playbooks.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.securitySettings.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.sessionEntityTypes.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.smartMessagingEntries.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.testcases.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.tools.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.transitionRouteGroups.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.versions.list</code></p>
<p><code translate="no" dir="ltr">dialogflow.webhooks.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.agentFiles.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.agentIamProposals.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.agents.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">discoveryengine.agents.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.assistants.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.authorizations.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.billingAccountLicenseConfigs.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.branches.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.cannedQueries.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.cmekConfigs.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.collections.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">discoveryengine.collections.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.connectorRuns.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.controls.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.conversations.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.dataStores.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">discoveryengine.dataStores.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.documents.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.engines.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">discoveryengine.engines.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.evaluations.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.identityMappingStores.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.immersiveArtifacts.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.licenseConfigs.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.memories.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.models.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.notebooks.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">discoveryengine.notebooks.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.notificationMessages.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.operations.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.sampleQueries.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.sampleQuerySets.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.schemas.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.servingConfigs.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.sessions.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.sharedContents.list</code></p>
<p><code translate="no" dir="ltr">discoveryengine.targetSites.list</code></p>
<p><code translate="no" dir="ltr">dlp.analyzeRiskTemplates.list</code></p>
<p><code translate="no" dir="ltr">dlp.columnDataProfiles.list</code></p>
<p><code translate="no" dir="ltr">dlp.connections.list</code></p>
<p><code translate="no" dir="ltr">dlp.contentPolicies.list</code></p>
<p><code translate="no" dir="ltr">dlp.deidentifyTemplates.list</code></p>
<p><code translate="no" dir="ltr">dlp.estimates.list</code></p>
<p><code translate="no" dir="ltr">dlp.fileStoreProfiles.list</code></p>
<p><code translate="no" dir="ltr">dlp.inspectFindings.list</code></p>
<p><code translate="no" dir="ltr">dlp.inspectTemplates.list</code></p>
<p><code translate="no" dir="ltr">dlp.jobTriggers.list</code></p>
<p><code translate="no" dir="ltr">dlp.jobs.list</code></p>
<p><code translate="no" dir="ltr">dlp.locations.list</code></p>
<p><code translate="no" dir="ltr">dlp.projectDataProfiles.list</code></p>
<p><code translate="no" dir="ltr">dlp.storedInfoTypes.list</code></p>
<p><code translate="no" dir="ltr">dlp.subscriptions.list</code></p>
<p><code translate="no" dir="ltr">dlp.tableDataProfiles.list</code></p>
<p><code translate="no" dir="ltr">dns.changes.list</code></p>
<p><code translate="no" dir="ltr">dns.dnsKeys.list</code></p>
<p><code translate="no" dir="ltr">dns.managedZoneOperations.list</code></p>
<p><code translate="no" dir="ltr">dns.managedZones.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">dns.managedZones.list</code></p>
<p><code translate="no" dir="ltr">dns.policies.list</code></p>
<p><code translate="no" dir="ltr">dns.resourceRecordSets.list</code></p>
<p><code translate="no" dir="ltr">dns.responsePolicies.list</code></p>
<p><code translate="no" dir="ltr">dns.responsePolicyRules.list</code></p>
<p><code translate="no" dir="ltr">documentai.dataLabelingJobs.list</code></p>
<p><code translate="no" dir="ltr">documentai.evaluations.list</code></p>
<p><code translate="no" dir="ltr">documentai.labelerPools.list</code></p>
<p><code translate="no" dir="ltr">documentai.locations.list</code></p>
<p><code translate="no" dir="ltr">documentai.processorTypes.list</code></p>
<p><code translate="no" dir="ltr">documentai.processorVersions.list</code></p>
<p><code translate="no" dir="ltr">documentai.processors.list</code></p>
<p><code translate="no" dir="ltr">documentai.rules.list</code></p>
<p><code translate="no" dir="ltr">documentai.schemaVersions.list</code></p>
<p><code translate="no" dir="ltr">documentai.schemas.list</code></p>
<p><code translate="no" dir="ltr">documentai.validators.list</code></p>
<p><code translate="no" dir="ltr">domains.locations.list</code></p>
<p><code translate="no" dir="ltr">domains.operations.list</code></p>
<p><code translate="no" dir="ltr">domains.registrations.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">domains.registrations.list</code></p>
<p><code translate="no" dir="ltr">dspm.locations.list</code></p>
<p><code translate="no" dir="ltr">dspm.operations.list</code></p>
<p><code translate="no" dir="ltr">earthengine.assets.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">earthengine.assets.list</code></p>
<p><code translate="no" dir="ltr">earthengine.operations.list</code></p>
<p><code translate="no" dir="ltr">edgecontainer.apikeys.list</code></p>
<p><code translate="no" dir="ltr">edgecontainer.clusters.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">edgecontainer.clusters.list</code></p>
<p><code translate="no" dir="ltr">edgecontainer.identityproviders.list</code></p>
<p><code translate="no" dir="ltr">edgecontainer.locations.list</code></p>
<p><code translate="no" dir="ltr">edgecontainer.machines.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">edgecontainer.machines.list</code></p>
<p><code translate="no" dir="ltr">edgecontainer.nodePools.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">edgecontainer.nodePools.list</code></p>
<p><code translate="no" dir="ltr">edgecontainer.operations.list</code></p>
<p><code translate="no" dir="ltr">edgecontainer.serviceaccounts.list</code></p>
<p><code translate="no" dir="ltr">edgecontainer.vpnConnections.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">edgecontainer.vpnConnections.list</code></p>
<p><code translate="no" dir="ltr">edgecontainer.zonalProjects.list</code></p>
<p><code translate="no" dir="ltr">edgecontainer.zonalservices.list</code></p>
<p><code translate="no" dir="ltr">edgecontainer.zones.list</code></p>
<p><code translate="no" dir="ltr">edgenetwork.interconnectAttachments.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">edgenetwork.interconnectAttachments.list</code></p>
<p><code translate="no" dir="ltr">edgenetwork.interconnects.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">edgenetwork.interconnects.list</code></p>
<p><code translate="no" dir="ltr">edgenetwork.locations.list</code></p>
<p><code translate="no" dir="ltr">edgenetwork.networks.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">edgenetwork.networks.list</code></p>
<p><code translate="no" dir="ltr">edgenetwork.operations.list</code></p>
<p><code translate="no" dir="ltr">edgenetwork.routers.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">edgenetwork.routers.list</code></p>
<p><code translate="no" dir="ltr">edgenetwork.routes.list</code></p>
<p><code translate="no" dir="ltr">edgenetwork.subnetworks.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">edgenetwork.subnetworks.list</code></p>
<p><code translate="no" dir="ltr">edgenetwork.zones.list</code></p>
<p><code translate="no" dir="ltr">enterpriseknowledgegraph.entityReconciliationJobs.list</code></p>
<p><code translate="no" dir="ltr">enterprisepurchasing.gcveCuds.list</code></p>
<p><code translate="no" dir="ltr">enterprisepurchasing.gcveNodePricingInfo.list</code></p>
<p><code translate="no" dir="ltr">enterprisepurchasing.licenseKeys.list</code></p>
<p><code translate="no" dir="ltr">enterprisepurchasing.locations.list</code></p>
<p><code translate="no" dir="ltr">enterprisepurchasing.operations.list</code></p>
<p><code translate="no" dir="ltr">errorreporting.applications.list</code></p>
<p><code translate="no" dir="ltr">errorreporting.errorEvents.list</code></p>
<p><code translate="no" dir="ltr">errorreporting.groups.list</code></p>
<p><code translate="no" dir="ltr">essentialcontacts.contacts.list</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.channelConnections.list</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.channels.list</code></p>
<p><code translate="no" dir="ltr">eventarc.enrollments.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.enrollments.list</code></p>
<p><code translate="no" dir="ltr">eventarc.googleApiSources.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.googleApiSources.list</code></p>
<p><code translate="no" dir="ltr">eventarc.kafkaSources.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.kafkaSources.list</code></p>
<p><code translate="no" dir="ltr">eventarc.locations.list</code></p>
<p><code translate="no" dir="ltr">eventarc.messageBuses.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.messageBuses.list</code></p>
<p><code translate="no" dir="ltr">eventarc.operations.list</code></p>
<p><code translate="no" dir="ltr">eventarc.pipelines.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.pipelines.list</code></p>
<p><code translate="no" dir="ltr">eventarc.providers.list</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">eventarc.triggers.list</code></p>
<p><code translate="no" dir="ltr">externalexposure.locations.list</code></p>
<p><code translate="no" dir="ltr">externalexposure.operations.list</code></p>
<p><code translate="no" dir="ltr">faulttesting.affectedResources.list</code></p>
<p><code translate="no" dir="ltr">faulttesting.experimentTemplates.list</code></p>
<p><code translate="no" dir="ltr">faulttesting.experiments.list</code></p>
<p><code translate="no" dir="ltr">faulttesting.locations.list</code></p>
<p><code translate="no" dir="ltr">faulttesting.operations.list</code></p>
<p><code translate="no" dir="ltr">faulttesting.validationResources.list</code></p>
<p><code translate="no" dir="ltr">faulttesting.validations.list</code></p>
<p><code translate="no" dir="ltr">fcmdata.deliverydata.list</code></p>
<p><code translate="no" dir="ltr">file.backups.list</code></p>
<p><code translate="no" dir="ltr">file.instances.list</code></p>
<p><code translate="no" dir="ltr">file.locations.list</code></p>
<p><code translate="no" dir="ltr">file.operations.list</code></p>
<p><code translate="no" dir="ltr">financialservices.locations.list</code></p>
<p><code translate="no" dir="ltr">financialservices.operations.list</code></p>
<p><code translate="no" dir="ltr">financialservices.v1backtests.list</code></p>
<p><code translate="no" dir="ltr">financialservices.v1datasets.list</code></p>
<p><code translate="no" dir="ltr">financialservices.v1engineconfigs.list</code></p>
<p><code translate="no" dir="ltr">financialservices.v1engineversions.list</code></p>
<p><code translate="no" dir="ltr">financialservices.v1instances.list</code></p>
<p><code translate="no" dir="ltr">financialservices.v1models.list</code></p>
<p><code translate="no" dir="ltr">financialservices.v1predictions.list</code></p>
<p><code translate="no" dir="ltr">firebase.clients.list</code></p>
<p><code translate="no" dir="ltr">firebase.links.list</code></p>
<p><code translate="no" dir="ltr">firebase.playLinks.list</code></p>
<p><code translate="no" dir="ltr">firebaseabt.experiments.list</code></p>
<p><code translate="no" dir="ltr">firebaseappcheck.automations.list</code></p>
<p><code translate="no" dir="ltr">firebaseappdistro.groups.list</code></p>
<p><code translate="no" dir="ltr">firebaseappdistro.releases.list</code></p>
<p><code translate="no" dir="ltr">firebaseappdistro.testers.list</code></p>
<p><code translate="no" dir="ltr">firebaseapphosting.backends.list</code></p>
<p><code translate="no" dir="ltr">firebaseapphosting.builds.list</code></p>
<p><code translate="no" dir="ltr">firebaseapphosting.domains.list</code></p>
<p><code translate="no" dir="ltr">firebaseapphosting.locations.list</code></p>
<p><code translate="no" dir="ltr">firebaseapphosting.operations.list</code></p>
<p><code translate="no" dir="ltr">firebaseapphosting.rollouts.list</code></p>
<p><code translate="no" dir="ltr">firebasecrashlytics.issues.list</code></p>
<p><code translate="no" dir="ltr">firebasedatabase.instances.list</code></p>
<p><code translate="no" dir="ltr">firebasedataconnect.connectorRevisions.list</code></p>
<p><code translate="no" dir="ltr">firebasedataconnect.connectors.list</code></p>
<p><code translate="no" dir="ltr">firebasedataconnect.locations.list</code></p>
<p><code translate="no" dir="ltr">firebasedataconnect.operations.list</code></p>
<p><code translate="no" dir="ltr">firebasedataconnect.schemaRevisions.list</code></p>
<p><code translate="no" dir="ltr">firebasedataconnect.schemas.list</code></p>
<p><code translate="no" dir="ltr">firebasedataconnect.services.list</code></p>
<p><code translate="no" dir="ltr">firebasedynamiclinks.destinations.list</code></p>
<p><code translate="no" dir="ltr">firebasedynamiclinks.domains.list</code></p>
<p><code translate="no" dir="ltr">firebasedynamiclinks.links.list</code></p>
<p><code translate="no" dir="ltr">firebaseextensions.configs.list</code></p>
<p><code translate="no" dir="ltr">firebaseextensionspublisher.extensions.list</code></p>
<p><code translate="no" dir="ltr">firebasehosting.sites.list</code></p>
<p><code translate="no" dir="ltr">firebaseinappmessaging.campaigns.list</code></p>
<p><code translate="no" dir="ltr">firebasemessagingcampaigns.campaigns.list</code></p>
<p><code translate="no" dir="ltr">firebaseml.models.list</code></p>
<p><code translate="no" dir="ltr">firebaseml.modelversions.list</code></p>
<p><code translate="no" dir="ltr">firebasenotifications.messages.list</code></p>
<p><code translate="no" dir="ltr">firebaserules.releases.list</code></p>
<p><code translate="no" dir="ltr">firebaserules.rulesets.list</code></p>
<p><code translate="no" dir="ltr">firebasestorage.buckets.list</code></p>
<p><code translate="no" dir="ltr">firebasevertexai.promptTemplates.list</code></p>
<p><code translate="no" dir="ltr">fleetengine.deliveryvehicles.list</code></p>
<p><code translate="no" dir="ltr">fleetengine.tasks.list</code></p>
<p><code translate="no" dir="ltr">fleetengine.vehicles.list</code></p>
<p><code translate="no" dir="ltr">ftp.locations.list</code></p>
<p><code translate="no" dir="ltr">ftp.operations.list</code></p>
<p><code translate="no" dir="ltr">ftp.servers.list</code></p>
<p><code translate="no" dir="ltr">ftp.users.list</code></p>
<p><code translate="no" dir="ltr">gcp.redisenterprise.com/databases.list</code></p>
<p><code translate="no" dir="ltr">gcp.redisenterprise.com/subscriptions.list</code></p>
<p><code translate="no" dir="ltr">gdchardwaremanagement.changeLogEntries.list</code></p>
<p><code translate="no" dir="ltr">gdchardwaremanagement.comments.list</code></p>
<p><code translate="no" dir="ltr">gdchardwaremanagement.hardware.list</code></p>
<p><code translate="no" dir="ltr">gdchardwaremanagement.hardwareGroups.list</code></p>
<p><code translate="no" dir="ltr">gdchardwaremanagement.locations.list</code></p>
<p><code translate="no" dir="ltr">gdchardwaremanagement.operations.list</code></p>
<p><code translate="no" dir="ltr">gdchardwaremanagement.orders.list</code></p>
<p><code translate="no" dir="ltr">gdchardwaremanagement.sites.list</code></p>
<p><code translate="no" dir="ltr">gdchardwaremanagement.skus.list</code></p>
<p><code translate="no" dir="ltr">gdchardwaremanagement.zones.list</code></p>
<p><code translate="no" dir="ltr">geminicloudassist.investigationRevisions.list</code></p>
<p><code translate="no" dir="ltr">geminicloudassist.investigations.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">geminicloudassist.investigations.list</code></p>
<p><code translate="no" dir="ltr">geminicloudassist.locations.list</code></p>
<p><code translate="no" dir="ltr">geminicloudassist.operations.list</code></p>
<p><code translate="no" dir="ltr">geminidataanalytics.dataAgents.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">geminidataanalytics.dataAgents.list</code></p>
<p><code translate="no" dir="ltr">geminidataanalytics.locations.list</code></p>
<p><code translate="no" dir="ltr">geminidataanalytics.operations.list</code></p>
<p><code translate="no" dir="ltr">genomics.datasets.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">genomics.datasets.list</code></p>
<p><code translate="no" dir="ltr">genomics.operations.list</code></p>
<p><code translate="no" dir="ltr">gkebackup.backupChannels.list</code></p>
<p><code translate="no" dir="ltr">gkebackup.backupPlanBindings.list</code></p>
<p><code translate="no" dir="ltr">gkebackup.backupPlans.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">gkebackup.backupPlans.list</code></p>
<p><code translate="no" dir="ltr">gkebackup.backups.list</code></p>
<p><code translate="no" dir="ltr">gkebackup.locations.list</code></p>
<p><code translate="no" dir="ltr">gkebackup.operations.list</code></p>
<p><code translate="no" dir="ltr">gkebackup.restoreChannels.list</code></p>
<p><code translate="no" dir="ltr">gkebackup.restorePlanBindings.list</code></p>
<p><code translate="no" dir="ltr">gkebackup.restorePlans.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">gkebackup.restorePlans.list</code></p>
<p><code translate="no" dir="ltr">gkebackup.restores.list</code></p>
<p><code translate="no" dir="ltr">gkebackup.volumeBackups.list</code></p>
<p><code translate="no" dir="ltr">gkebackup.volumeRestores.list</code></p>
<p><code translate="no" dir="ltr">gkehub.features.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">gkehub.features.list</code></p>
<p><code translate="no" dir="ltr">gkehub.locations.list</code></p>
<p><code translate="no" dir="ltr">gkehub.membershipbindings.list</code></p>
<p><code translate="no" dir="ltr">gkehub.membershipfeatures.list</code></p>
<p><code translate="no" dir="ltr">gkehub.memberships.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">gkehub.memberships.list</code></p>
<p><code translate="no" dir="ltr">gkehub.namespaces.list</code></p>
<p><code translate="no" dir="ltr">gkehub.operations.list</code></p>
<p><code translate="no" dir="ltr">gkehub.rbacrolebindings.list</code></p>
<p><code translate="no" dir="ltr">gkehub.scopes.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">gkehub.scopes.list</code></p>
<p><code translate="no" dir="ltr">gkemulticloud.attachedClusters.list</code></p>
<p><code translate="no" dir="ltr">gkemulticloud.awsClusters.list</code></p>
<p><code translate="no" dir="ltr">gkemulticloud.awsNodePools.list</code></p>
<p><code translate="no" dir="ltr">gkemulticloud.azureClients.list</code></p>
<p><code translate="no" dir="ltr">gkemulticloud.azureClusters.list</code></p>
<p><code translate="no" dir="ltr">gkemulticloud.azureNodePools.list</code></p>
<p><code translate="no" dir="ltr">gkemulticloud.operations.list</code></p>
<p><code translate="no" dir="ltr">gkeonprem.bareMetalAdminClusters.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">gkeonprem.bareMetalAdminClusters.list</code></p>
<p><code translate="no" dir="ltr">gkeonprem.bareMetalClusters.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">gkeonprem.bareMetalClusters.list</code></p>
<p><code translate="no" dir="ltr">gkeonprem.bareMetalNodePools.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">gkeonprem.bareMetalNodePools.list</code></p>
<p><code translate="no" dir="ltr">gkeonprem.locations.list</code></p>
<p><code translate="no" dir="ltr">gkeonprem.operations.list</code></p>
<p><code translate="no" dir="ltr">gkeonprem.vmwareAdminClusters.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">gkeonprem.vmwareAdminClusters.list</code></p>
<p><code translate="no" dir="ltr">gkeonprem.vmwareClusters.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">gkeonprem.vmwareClusters.list</code></p>
<p><code translate="no" dir="ltr">gkeonprem.vmwareNodePools.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">gkeonprem.vmwareNodePools.list</code></p>
<p><code translate="no" dir="ltr">gsuiteaddons.deployments.list</code></p>
<p><code translate="no" dir="ltr">health.subscribers.list</code></p>
<p><code translate="no" dir="ltr">health.subscriptions.list</code></p>
<p><code translate="no" dir="ltr">healthcare.annotationStores.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">healthcare.annotationStores.list</code></p>
<p><code translate="no" dir="ltr">healthcare.annotations.list</code></p>
<p><code translate="no" dir="ltr">healthcare.attributeDefinitions.list</code></p>
<p><code translate="no" dir="ltr">healthcare.consentArtifacts.list</code></p>
<p><code translate="no" dir="ltr">healthcare.consentStores.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">healthcare.consentStores.list</code></p>
<p><code translate="no" dir="ltr">healthcare.consents.list</code></p>
<p><code translate="no" dir="ltr">healthcare.datasets.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">healthcare.datasets.list</code></p>
<p><code translate="no" dir="ltr">healthcare.dicomStores.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">healthcare.dicomStores.list</code></p>
<p><code translate="no" dir="ltr">healthcare.fhirStores.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">healthcare.fhirStores.list</code></p>
<p><code translate="no" dir="ltr">healthcare.hl7V2Messages.list</code></p>
<p><code translate="no" dir="ltr">healthcare.hl7V2Stores.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">healthcare.hl7V2Stores.list</code></p>
<p><code translate="no" dir="ltr">healthcare.locations.list</code></p>
<p><code translate="no" dir="ltr">healthcare.operations.list</code></p>
<p><code translate="no" dir="ltr">healthcare.userDataMappings.list</code></p>
<p><code translate="no" dir="ltr">hypercomputecluster.clusters.list</code></p>
<p><code translate="no" dir="ltr">hypercomputecluster.locations.list</code></p>
<p><code translate="no" dir="ltr">hypercomputecluster.machineLearningRuns.list</code></p>
<p><code translate="no" dir="ltr">hypercomputecluster.operations.list</code></p>
<p><code translate="no" dir="ltr">iam.accesspolicies.list</code></p>
<p><code translate="no" dir="ltr">iam.denypolicies.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/oauthClientCredentials.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/oauthClients.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderKeys.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimGroups.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimUsers.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviders.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolManagedIdentities.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolNamespaces.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolProviderKeys.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolProviders.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPools.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPools.list</code></p>
<p><code translate="no" dir="ltr">iam.policybindings.list</code></p>
<p><code translate="no" dir="ltr">iam.principalaccessboundarypolicies.list</code></p>
<p><code translate="no" dir="ltr">iam.roles.get</code></p>
<p><code translate="no" dir="ltr">iam.roles.list</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccountKeys.list</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.get</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.list</code></p>
<p><code translate="no" dir="ltr">iamconnectors.accessEvents.list</code></p>
<p><code translate="no" dir="ltr">iamconnectors.authorizations.list</code></p>
<p><code translate="no" dir="ltr">iamconnectors.connectors.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">iamconnectors.connectors.list</code></p>
<p><code translate="no" dir="ltr">iamconnectors.locations.list</code></p>
<p><code translate="no" dir="ltr">iamconnectors.operations.list</code></p>
<p><code translate="no" dir="ltr">iap.tunnel.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">iap.tunnelDestGroups.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">iap.tunnelDestGroups.list</code></p>
<p><code translate="no" dir="ltr">iap.tunnelInstances.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">iap.tunnelLocations.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">iap.tunnelZones.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">iap.web.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">iap.webServiceVersions.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">iap.webServices.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">iap.webTypes.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">identitytoolkit.tenants.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">identitytoolkit.tenants.list</code></p>
<p><code translate="no" dir="ltr">ids.endpoints.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">ids.endpoints.list</code></p>
<p><code translate="no" dir="ltr">ids.locations.list</code></p>
<p><code translate="no" dir="ltr">ids.operations.list</code></p>
<p><code translate="no" dir="ltr">integrations.apigeeAuthConfigs.list</code></p>
<p><code translate="no" dir="ltr">integrations.apigeeCertificates.list</code></p>
<p><code translate="no" dir="ltr">integrations.apigeeExecutions.list</code></p>
<p><code translate="no" dir="ltr">integrations.apigeeIntegrationVers.list</code></p>
<p><code translate="no" dir="ltr">integrations.apigeeIntegrations.list</code></p>
<p><code translate="no" dir="ltr">integrations.apigeeSfdcChannels.list</code></p>
<p><code translate="no" dir="ltr">integrations.apigeeSfdcInstances.list</code></p>
<p><code translate="no" dir="ltr">integrations.apigeeSuspensions.list</code></p>
<p><code translate="no" dir="ltr">integrations.authConfigs.list</code></p>
<p><code translate="no" dir="ltr">integrations.certificates.list</code></p>
<p><code translate="no" dir="ltr">integrations.executions.list</code></p>
<p><code translate="no" dir="ltr">integrations.integrationVersions.list</code></p>
<p><code translate="no" dir="ltr">integrations.integrations.list</code></p>
<p><code translate="no" dir="ltr">integrations.securityAuthConfigs.list</code></p>
<p><code translate="no" dir="ltr">integrations.securityExecutions.list</code></p>
<p><code translate="no" dir="ltr">integrations.securityIntegTempVers.list</code></p>
<p><code translate="no" dir="ltr">integrations.securityIntegrationVers.list</code></p>
<p><code translate="no" dir="ltr">integrations.securityIntegrations.list</code></p>
<p><code translate="no" dir="ltr">integrations.sfdcChannels.list</code></p>
<p><code translate="no" dir="ltr">integrations.sfdcInstances.list</code></p>
<p><code translate="no" dir="ltr">integrations.suspensions.list</code></p>
<p><code translate="no" dir="ltr">integrations.templates.list</code></p>
<p><code translate="no" dir="ltr">integrations.testCases.list</code></p>
<p><code translate="no" dir="ltr">issuerswitch.accountManagerTransactions.list</code></p>
<p><code translate="no" dir="ltr">issuerswitch.complaintTransactions.list</code></p>
<p><code translate="no" dir="ltr">issuerswitch.financialTransactions.list</code></p>
<p><code translate="no" dir="ltr">issuerswitch.mandateTransactions.list</code></p>
<p><code translate="no" dir="ltr">issuerswitch.metadataTransactions.list</code></p>
<p><code translate="no" dir="ltr">issuerswitch.operations.list</code></p>
<p><code translate="no" dir="ltr">issuerswitch.ruleMetadata.list</code></p>
<p><code translate="no" dir="ltr">issuerswitch.ruleMetadataValues.list</code></p>
<p><code translate="no" dir="ltr">issuerswitch.rules.list</code></p>
<p><code translate="no" dir="ltr">krmapihosting.krmApiHosts.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">krmapihosting.krmApiHosts.list</code></p>
<p><code translate="no" dir="ltr">krmapihosting.locations.list</code></p>
<p><code translate="no" dir="ltr">krmapihosting.operations.list</code></p>
<p><code translate="no" dir="ltr">licensemanager.configurations.list</code></p>
<p><code translate="no" dir="ltr">licensemanager.instances.list</code></p>
<p><code translate="no" dir="ltr">licensemanager.locations.list</code></p>
<p><code translate="no" dir="ltr">licensemanager.operations.list</code></p>
<p><code translate="no" dir="ltr">licensemanager.products.list</code></p>
<p><code translate="no" dir="ltr">lifesciences.operations.list</code></p>
<p><code translate="no" dir="ltr">livestream.assets.list</code></p>
<p><code translate="no" dir="ltr">livestream.channels.list</code></p>
<p><code translate="no" dir="ltr">livestream.clips.list</code></p>
<p><code translate="no" dir="ltr">livestream.dvrSessions.list</code></p>
<p><code translate="no" dir="ltr">livestream.events.list</code></p>
<p><code translate="no" dir="ltr">livestream.inputs.list</code></p>
<p><code translate="no" dir="ltr">livestream.locations.list</code></p>
<p><code translate="no" dir="ltr">livestream.operations.list</code></p>
<p><code translate="no" dir="ltr">logging.buckets.list</code></p>
<p><code translate="no" dir="ltr">logging.exclusions.list</code></p>
<p><code translate="no" dir="ltr">logging.links.list</code></p>
<p><code translate="no" dir="ltr">logging.locations.list</code></p>
<p><code translate="no" dir="ltr">logging.logEntries.list</code></p>
<p><code translate="no" dir="ltr">logging.logMetrics.list</code></p>
<p><code translate="no" dir="ltr">logging.logScopes.list</code></p>
<p><code translate="no" dir="ltr">logging.logServiceIndexes.list</code></p>
<p><code translate="no" dir="ltr">logging.logServices.list</code></p>
<p><code translate="no" dir="ltr">logging.logs.list</code></p>
<p><code translate="no" dir="ltr">logging.notificationRules.list</code></p>
<p><code translate="no" dir="ltr">logging.operations.list</code></p>
<p><code translate="no" dir="ltr">logging.privateLogEntries.list</code></p>
<p><code translate="no" dir="ltr">logging.queries.usePrivate</code></p>
<p><code translate="no" dir="ltr">logging.sinks.list</code></p>
<p><code translate="no" dir="ltr">logging.views.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">logging.views.list</code></p>
<p><code translate="no" dir="ltr">looker.backups.list</code></p>
<p><code translate="no" dir="ltr">looker.instances.list</code></p>
<p><code translate="no" dir="ltr">looker.locations.list</code></p>
<p><code translate="no" dir="ltr">looker.operations.list</code></p>
<p><code translate="no" dir="ltr">lustre.instances.list</code></p>
<p><code translate="no" dir="ltr">lustre.locations.list</code></p>
<p><code translate="no" dir="ltr">lustre.operations.list</code></p>
<p><code translate="no" dir="ltr">maintenance.locations.list</code></p>
<p><code translate="no" dir="ltr">maintenance.resourceMaintenances.list</code></p>
<p><code translate="no" dir="ltr">managedflink.deployments.list</code></p>
<p><code translate="no" dir="ltr">managedflink.jobs.list</code></p>
<p><code translate="no" dir="ltr">managedflink.locations.list</code></p>
<p><code translate="no" dir="ltr">managedflink.operations.list</code></p>
<p><code translate="no" dir="ltr">managedflink.sessions.list</code></p>
<p><code translate="no" dir="ltr">managedidentities.backups.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">managedidentities.backups.list</code></p>
<p><code translate="no" dir="ltr">managedidentities.domains.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">managedidentities.domains.list</code></p>
<p><code translate="no" dir="ltr">managedidentities.locations.list</code></p>
<p><code translate="no" dir="ltr">managedidentities.operations.list</code></p>
<p><code translate="no" dir="ltr">managedidentities.peerings.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">managedidentities.peerings.list</code></p>
<p><code translate="no" dir="ltr">managedidentities.sqlintegrations.list</code></p>
<p><code translate="no" dir="ltr">managedkafka.acls.list</code></p>
<p><code translate="no" dir="ltr">managedkafka.clusters.list</code></p>
<p><code translate="no" dir="ltr">managedkafka.connectClusters.list</code></p>
<p><code translate="no" dir="ltr">managedkafka.connectors.list</code></p>
<p><code translate="no" dir="ltr">managedkafka.consumerGroups.list</code></p>
<p><code translate="no" dir="ltr">managedkafka.contexts.list</code></p>
<p><code translate="no" dir="ltr">managedkafka.locations.list</code></p>
<p><code translate="no" dir="ltr">managedkafka.operations.list</code></p>
<p><code translate="no" dir="ltr">managedkafka.schemaRegistries.list</code></p>
<p><code translate="no" dir="ltr">managedkafka.subjects.list</code></p>
<p><code translate="no" dir="ltr">managedkafka.topics.list</code></p>
<p><code translate="no" dir="ltr">managedkafka.versions.list</code></p>
<p><code translate="no" dir="ltr">mapsadmin.clientMaps.list</code></p>
<p><code translate="no" dir="ltr">mapsadmin.clientStyleSheetSnapshots.list</code></p>
<p><code translate="no" dir="ltr">mapsadmin.clientStyles.list</code></p>
<p><code translate="no" dir="ltr">mapsadmin.mapViews.list</code></p>
<p><code translate="no" dir="ltr">mapsadmin.styleSnapshots.list</code></p>
<p><code translate="no" dir="ltr">mapsanalytics.metricMetadata.list</code></p>
<p><code translate="no" dir="ltr">mapsplatformdatasets.datasets.list</code></p>
<p><code translate="no" dir="ltr">marketplacesolutions.locations.list</code></p>
<p><code translate="no" dir="ltr">marketplacesolutions.operations.list</code></p>
<p><code translate="no" dir="ltr">marketplacesolutions.powerImages.list</code></p>
<p><code translate="no" dir="ltr">marketplacesolutions.powerInstances.list</code></p>
<p><code translate="no" dir="ltr">marketplacesolutions.powerNetworks.list</code></p>
<p><code translate="no" dir="ltr">marketplacesolutions.powerSshKeys.list</code></p>
<p><code translate="no" dir="ltr">marketplacesolutions.powerVolumes.list</code></p>
<p><code translate="no" dir="ltr">memcache.instances.list</code></p>
<p><code translate="no" dir="ltr">memcache.locations.list</code></p>
<p><code translate="no" dir="ltr">memcache.operations.list</code></p>
<p><code translate="no" dir="ltr">memorystore.backupCollections.list</code></p>
<p><code translate="no" dir="ltr">memorystore.backups.list</code></p>
<p><code translate="no" dir="ltr">memorystore.instances.list</code></p>
<p><code translate="no" dir="ltr">memorystore.locations.list</code></p>
<p><code translate="no" dir="ltr">memorystore.operations.list</code></p>
<p><code translate="no" dir="ltr">metastore.backups.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">metastore.backups.list</code></p>
<p><code translate="no" dir="ltr">metastore.databases.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">metastore.databases.list</code></p>
<p><code translate="no" dir="ltr">metastore.federations.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">metastore.federations.list</code></p>
<p><code translate="no" dir="ltr">metastore.imports.list</code></p>
<p><code translate="no" dir="ltr">metastore.locations.list</code></p>
<p><code translate="no" dir="ltr">metastore.migrations.list</code></p>
<p><code translate="no" dir="ltr">metastore.operations.list</code></p>
<p><code translate="no" dir="ltr">metastore.services.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">metastore.services.list</code></p>
<p><code translate="no" dir="ltr">metastore.tables.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">metastore.tables.list</code></p>
<p><code translate="no" dir="ltr">migrationcenter.assets.list</code></p>
<p><code translate="no" dir="ltr">migrationcenter.assetsExportJobs.list</code></p>
<p><code translate="no" dir="ltr">migrationcenter.discoveryClients.list</code></p>
<p><code translate="no" dir="ltr">migrationcenter.errorFrames.list</code></p>
<p><code translate="no" dir="ltr">migrationcenter.groups.list</code></p>
<p><code translate="no" dir="ltr">migrationcenter.importDataFiles.list</code></p>
<p><code translate="no" dir="ltr">migrationcenter.importJobs.list</code></p>
<p><code translate="no" dir="ltr">migrationcenter.locations.list</code></p>
<p><code translate="no" dir="ltr">migrationcenter.operations.list</code></p>
<p><code translate="no" dir="ltr">migrationcenter.preferenceSets.list</code></p>
<p><code translate="no" dir="ltr">migrationcenter.relations.list</code></p>
<p><code translate="no" dir="ltr">migrationcenter.reportConfigs.list</code></p>
<p><code translate="no" dir="ltr">migrationcenter.reports.list</code></p>
<p><code translate="no" dir="ltr">migrationcenter.sources.list</code></p>
<p><code translate="no" dir="ltr">ml.jobs.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">ml.jobs.list</code></p>
<p><code translate="no" dir="ltr">ml.locations.list</code></p>
<p><code translate="no" dir="ltr">ml.models.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">ml.models.list</code></p>
<p><code translate="no" dir="ltr">ml.operations.list</code></p>
<p><code translate="no" dir="ltr">ml.studies.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">ml.studies.list</code></p>
<p><code translate="no" dir="ltr">ml.trials.list</code></p>
<p><code translate="no" dir="ltr">ml.versions.list</code></p>
<p><code translate="no" dir="ltr">modelarmor.locations.list</code></p>
<p><code translate="no" dir="ltr">modelarmor.templates.list</code></p>
<p><code translate="no" dir="ltr">monitoring.alertPolicies.list</code></p>
<p><code translate="no" dir="ltr">monitoring.alerts.list</code></p>
<p><code translate="no" dir="ltr">monitoring.dashboards.list</code></p>
<p><code translate="no" dir="ltr">monitoring.groups.list</code></p>
<p><code translate="no" dir="ltr">monitoring.metricDescriptors.list</code></p>
<p><code translate="no" dir="ltr">monitoring.monitoredResourceDescriptors.list</code></p>
<p><code translate="no" dir="ltr">monitoring.notificationChannelDescriptors.list</code></p>
<p><code translate="no" dir="ltr">monitoring.notificationChannels.list</code></p>
<p><code translate="no" dir="ltr">monitoring.services.list</code></p>
<p><code translate="no" dir="ltr">monitoring.slos.list</code></p>
<p><code translate="no" dir="ltr">monitoring.snoozes.list</code></p>
<p><code translate="no" dir="ltr">monitoring.timeSeries.list</code></p>
<p><code translate="no" dir="ltr">monitoring.uptimeCheckConfigs.list</code></p>
<p><code translate="no" dir="ltr">netapp.activeDirectories.list</code></p>
<p><code translate="no" dir="ltr">netapp.backupPolicies.list</code></p>
<p><code translate="no" dir="ltr">netapp.backupVaults.list</code></p>
<p><code translate="no" dir="ltr">netapp.backups.list</code></p>
<p><code translate="no" dir="ltr">netapp.hostGroups.list</code></p>
<p><code translate="no" dir="ltr">netapp.kmsConfigs.list</code></p>
<p><code translate="no" dir="ltr">netapp.locations.list</code></p>
<p><code translate="no" dir="ltr">netapp.operations.list</code></p>
<p><code translate="no" dir="ltr">netapp.quotaRules.list</code></p>
<p><code translate="no" dir="ltr">netapp.replications.list</code></p>
<p><code translate="no" dir="ltr">netapp.snapshots.list</code></p>
<p><code translate="no" dir="ltr">netapp.storagePools.list</code></p>
<p><code translate="no" dir="ltr">netapp.volumes.list</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.gatewayAdvertisedRoutes.list</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.groups.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.groups.list</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.hubRouteTables.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.hubRouteTables.list</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.hubRoutes.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.hubRoutes.list</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.hubs.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.hubs.list</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.internalRanges.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.internalRanges.list</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.locations.list</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.multicloudDataTransferConfigs.list</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.multicloudDataTransferDestinations.list</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.multicloudDataTransferSupportedServices.list</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.operations.list</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.policyBasedRoutes.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.policyBasedRoutes.list</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.pscAuthorizationPolicies.list</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.regionalEndpoints.list</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.remoteTransportProfiles.list</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.serviceClasses.list</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.serviceConnectionMaps.list</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.serviceConnectionPolicies.list</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.spokes.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.spokes.list</code></p>
<p><code translate="no" dir="ltr">networkconnectivity.transports.list</code></p>
<p><code translate="no" dir="ltr">networkmanagement.connectivitytests.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">networkmanagement.connectivitytests.list</code></p>
<p><code translate="no" dir="ltr">networkmanagement.locations.list</code></p>
<p><code translate="no" dir="ltr">networkmanagement.monitoringpoints.list</code></p>
<p><code translate="no" dir="ltr">networkmanagement.networkpaths.list</code></p>
<p><code translate="no" dir="ltr">networkmanagement.operations.list</code></p>
<p><code translate="no" dir="ltr">networkmanagement.providers.list</code></p>
<p><code translate="no" dir="ltr">networkmanagement.vpcflowlogsconfigs.list</code></p>
<p><code translate="no" dir="ltr">networkmanagement.webpaths.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.addressGroups.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">networksecurity.addressGroups.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.authorizationPolicies.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">networksecurity.authorizationPolicies.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.authzPolicies.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">networksecurity.authzPolicies.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.backendAuthenticationConfigs.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.clientTlsPolicies.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">networksecurity.clientTlsPolicies.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.dnsThreatDetectors.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.firewallEndpointAssociations.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.firewallEndpoints.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.gatewaySecurityPolicies.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.gatewaySecurityPolicyRules.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.interceptDeploymentGroups.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.interceptDeployments.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.interceptEndpointGroupAssociations.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.interceptEndpointGroups.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.locations.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.mirroringDeploymentGroups.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.mirroringDeployments.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.mirroringEndpointGroupAssociations.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.mirroringEndpointGroups.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.operations.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.sacAttachments.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.sacRealms.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.securityProfileGroups.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.securityProfiles.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.serverTlsPolicies.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">networksecurity.serverTlsPolicies.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.tlsInspectionPolicies.list</code></p>
<p><code translate="no" dir="ltr">networksecurity.urlLists.list</code></p>
<p><code translate="no" dir="ltr">networkservices.agentGateways.list</code></p>
<p><code translate="no" dir="ltr">networkservices.authzExtensions.list</code></p>
<p><code translate="no" dir="ltr">networkservices.endpointPolicies.list</code></p>
<p><code translate="no" dir="ltr">networkservices.gateways.list</code></p>
<p><code translate="no" dir="ltr">networkservices.googleTagGatewayPolicies.list</code></p>
<p><code translate="no" dir="ltr">networkservices.grpcRoutes.list</code></p>
<p><code translate="no" dir="ltr">networkservices.httpFilters.list</code></p>
<p><code translate="no" dir="ltr">networkservices.httpRoutes.list</code></p>
<p><code translate="no" dir="ltr">networkservices.httpfilters.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">networkservices.httpfilters.list</code></p>
<p><code translate="no" dir="ltr">networkservices.lbEdgeExtensions.list</code></p>
<p><code translate="no" dir="ltr">networkservices.lbRouteExtensions.list</code></p>
<p><code translate="no" dir="ltr">networkservices.lbTrafficExtensions.list</code></p>
<p><code translate="no" dir="ltr">networkservices.locations.list</code></p>
<p><code translate="no" dir="ltr">networkservices.meshes.list</code></p>
<p><code translate="no" dir="ltr">networkservices.operations.list</code></p>
<p><code translate="no" dir="ltr">networkservices.route_views.list</code></p>
<p><code translate="no" dir="ltr">networkservices.serviceBindings.list</code></p>
<p><code translate="no" dir="ltr">networkservices.serviceLbPolicies.list</code></p>
<p><code translate="no" dir="ltr">networkservices.swpSecurityExtensions.list</code></p>
<p><code translate="no" dir="ltr">networkservices.tcpRoutes.list</code></p>
<p><code translate="no" dir="ltr">networkservices.tlsRoutes.list</code></p>
<p><code translate="no" dir="ltr">networkservices.wasmPlugins.list</code></p>
<p><code translate="no" dir="ltr">notebooks.environments.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">notebooks.environments.list</code></p>
<p><code translate="no" dir="ltr">notebooks.executions.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">notebooks.executions.list</code></p>
<p><code translate="no" dir="ltr">notebooks.instances.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">notebooks.instances.list</code></p>
<p><code translate="no" dir="ltr">notebooks.locations.list</code></p>
<p><code translate="no" dir="ltr">notebooks.operations.list</code></p>
<p><code translate="no" dir="ltr">notebooks.runtimes.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">notebooks.runtimes.list</code></p>
<p><code translate="no" dir="ltr">notebooks.schedules.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">notebooks.schedules.list</code></p>
<p><code translate="no" dir="ltr">observability.analyticsViews.list</code></p>
<p><code translate="no" dir="ltr">observability.buckets.list</code></p>
<p><code translate="no" dir="ltr">observability.datasets.list</code></p>
<p><code translate="no" dir="ltr">observability.links.list</code></p>
<p><code translate="no" dir="ltr">observability.locations.list</code></p>
<p><code translate="no" dir="ltr">observability.operations.list</code></p>
<p><code translate="no" dir="ltr">observability.traceScopes.list</code></p>
<p><code translate="no" dir="ltr">observability.views.list</code></p>
<p><code translate="no" dir="ltr">ondemandscanning.operations.list</code></p>
<p><code translate="no" dir="ltr">opsconfigmonitoring.resourceMetadata.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.autonomousDatabaseBackups.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.autonomousDatabaseCharacterSets.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.autonomousDatabases.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.autonomousDbVersions.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.cloudExadataInfrastructures.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.cloudVmClusters.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.databaseCharacterSets.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.databaseConnections.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.databases.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.dbNodes.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.dbServers.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.dbSystemComputePerformances.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.dbSystemInitialStorageSizes.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.dbSystemShapes.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.dbSystems.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.dbVersions.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.entitlements.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.exadbVmClusters.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.exascaleDbStorageVaults.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.flexComponents.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.giVersions.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.goldenGateConnectionAssignments.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.goldenGateConnectionTypes.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.goldenGateConnections.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.goldenGateDeploymentEnvironments.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.goldenGateDeploymentTypes.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.goldenGateDeploymentVersions.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.goldenGateDeployments.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.locations.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.minorVersions.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.odbDnsZones.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.odbNetworks.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.odbSubnets.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.operations.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.pluggableDatabases.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.serviceIntegrations.list</code></p>
<p><code translate="no" dir="ltr">oracledatabase.systemVersions.list</code></p>
<p><code translate="no" dir="ltr">orgpolicy.constraints.list</code></p>
<p><code translate="no" dir="ltr">orgpolicy.customConstraints.list</code></p>
<p><code translate="no" dir="ltr">orgpolicy.policies.list</code></p>
<p><code translate="no" dir="ltr">osconfig.guestPolicies.list</code></p>
<p><code translate="no" dir="ltr">osconfig.instanceOSPoliciesCompliances.list</code></p>
<p><code translate="no" dir="ltr">osconfig.inventories.list</code></p>
<p><code translate="no" dir="ltr">osconfig.locations.list</code></p>
<p><code translate="no" dir="ltr">osconfig.operations.list</code></p>
<p><code translate="no" dir="ltr">osconfig.osPolicyAssignmentReports.list</code></p>
<p><code translate="no" dir="ltr">osconfig.osPolicyAssignments.list</code></p>
<p><code translate="no" dir="ltr">osconfig.patchDeployments.list</code></p>
<p><code translate="no" dir="ltr">osconfig.patchJobs.list</code></p>
<p><code translate="no" dir="ltr">osconfig.policyOrchestrators.list</code></p>
<p><code translate="no" dir="ltr">osconfig.upgradeReports.list</code></p>
<p><code translate="no" dir="ltr">osconfig.vulnerabilityReports.list</code></p>
<p><code translate="no" dir="ltr">parallelstore.instances.list</code></p>
<p><code translate="no" dir="ltr">parallelstore.locations.list</code></p>
<p><code translate="no" dir="ltr">parallelstore.operations.list</code></p>
<p><code translate="no" dir="ltr">parametermanager.locations.list</code></p>
<p><code translate="no" dir="ltr">parametermanager.parameterVersions.list</code></p>
<p><code translate="no" dir="ltr">parametermanager.parameters.list</code></p>
<p><code translate="no" dir="ltr">parametermanager.templateVersions.list</code></p>
<p><code translate="no" dir="ltr">parametermanager.templates.list</code></p>
<p><code translate="no" dir="ltr">paymentsresellersubscription.products.list</code></p>
<p><code translate="no" dir="ltr">paymentsresellersubscription.promotions.list</code></p>
<p><code translate="no" dir="ltr">policyremediatormanager.locations.list</code></p>
<p><code translate="no" dir="ltr">policyremediatormanager.operations.list</code></p>
<p><code translate="no" dir="ltr">policysimulator.accessPolicySimulationResults.list</code></p>
<p><code translate="no" dir="ltr">policysimulator.accessPolicySimulations.list</code></p>
<p><code translate="no" dir="ltr">policysimulator.orgPolicyViolations.list</code></p>
<p><code translate="no" dir="ltr">policysimulator.orgPolicyViolationsPreviews.list</code></p>
<p><code translate="no" dir="ltr">policysimulator.replayResults.list</code></p>
<p><code translate="no" dir="ltr">policysimulator.replays.list</code></p>
<p><code translate="no" dir="ltr">privateca.caPools.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">privateca.caPools.list</code></p>
<p><code translate="no" dir="ltr">privateca.certificateAuthorities.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">privateca.certificateAuthorities.list</code></p>
<p><code translate="no" dir="ltr">privateca.certificateRevocationLists.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">privateca.certificateRevocationLists.list</code></p>
<p><code translate="no" dir="ltr">privateca.certificateTemplates.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">privateca.certificateTemplates.list</code></p>
<p><code translate="no" dir="ltr">privateca.certificates.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">privateca.certificates.list</code></p>
<p><code translate="no" dir="ltr">privateca.locations.list</code></p>
<p><code translate="no" dir="ltr">privateca.operations.list</code></p>
<p><code translate="no" dir="ltr">privateca.reusableConfigs.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">privateca.reusableConfigs.list</code></p>
<p><code translate="no" dir="ltr">privilegedaccessmanager.entitlements.list</code></p>
<p><code translate="no" dir="ltr">privilegedaccessmanager.grants.list</code></p>
<p><code translate="no" dir="ltr">privilegedaccessmanager.locations.list</code></p>
<p><code translate="no" dir="ltr">privilegedaccessmanager.operations.list</code></p>
<p><code translate="no" dir="ltr">proximitybeacon.attachments.list</code></p>
<p><code translate="no" dir="ltr">proximitybeacon.beacons.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">proximitybeacon.beacons.list</code></p>
<p><code translate="no" dir="ltr">proximitybeacon.namespaces.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">proximitybeacon.namespaces.list</code></p>
<p><code translate="no" dir="ltr">pubsub.schemas.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">pubsub.schemas.list</code></p>
<p><code translate="no" dir="ltr">pubsub.snapshots.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">pubsub.snapshots.list</code></p>
<p><code translate="no" dir="ltr">pubsub.subscriptions.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">pubsub.subscriptions.list</code></p>
<p><code translate="no" dir="ltr">pubsub.topics.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">pubsub.topics.list</code></p>
<p><code translate="no" dir="ltr">pubsublite.operations.list</code></p>
<p><code translate="no" dir="ltr">pubsublite.reservations.list</code></p>
<p><code translate="no" dir="ltr">pubsublite.subscriptions.list</code></p>
<p><code translate="no" dir="ltr">pubsublite.topics.list</code></p>
<p><code translate="no" dir="ltr">recaptchaenterprise.firewallpolicies.list</code></p>
<p><code translate="no" dir="ltr">recaptchaenterprise.keys.list</code></p>
<p><code translate="no" dir="ltr">recaptchaenterprise.relatedaccountgroupmemberships.list</code></p>
<p><code translate="no" dir="ltr">recaptchaenterprise.relatedaccountgroups.list</code></p>
<p><code translate="no" dir="ltr">recommender.alloydbClusterPerformanceInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.alloydbClusterPerformanceRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.alloydbClusterReliabilityInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.alloydbClusterReliabilityRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.alloydbInstanceSecurityInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.alloydbInstanceSecurityRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.appengineVersionCostInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.appengineVersionCostRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.bigqueryCapacityCommitmentsInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.bigqueryCapacityCommitmentsRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.bigqueryMaterializedViewInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.bigqueryMaterializedViewRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.bigqueryPartitionClusterRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.bigqueryTableStatsInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.bigtableClusterPerformanceInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.bigtableClusterPerformanceRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudAssetInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudCostGeneralInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudCostGeneralRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudDeprecationGeneralInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudDeprecationGeneralRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudFunctionsPerformanceInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudFunctionsPerformanceRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudManageabilityGeneralInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudManageabilityGeneralRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudPerformanceGeneralInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudPerformanceGeneralRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudRecentChangeInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudRecentChangeRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudReliabilityGeneralInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudReliabilityGeneralRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudSecurityGeneralInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudSecurityGeneralRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudsqlIdleInstanceRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudsqlInstanceActivityInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudsqlInstanceCpuUsageInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudsqlInstanceDiskUsageTrendInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudsqlInstanceMemoryUsageInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudsqlInstanceOomProbabilityInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudsqlInstanceOutOfDiskRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudsqlInstancePerformanceInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudsqlInstancePerformanceRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudsqlInstanceReliabilityInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudsqlInstanceReliabilityRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudsqlInstanceSecurityInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudsqlInstanceSecurityRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudsqlInstanceUnderprovisionedCpuUsageInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudsqlInstanceUnderprovisionedMemoryUsageInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudsqlOverprovisionedInstanceRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.cloudsqlUnderProvisionedInstanceRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.commitmentUtilizationInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.computeAddressIdleResourceInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.computeAddressIdleResourceRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.computeDiskIdleResourceInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.computeDiskIdleResourceRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.computeFirewallInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.computeIdleResourceInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.computeIdleResourceRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.computeImageIdleResourceInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.computeImageIdleResourceRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.computeInstanceCpuUsageInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.computeInstanceCpuUsagePredictionInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.computeInstanceCpuUsageTrendInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.computeInstanceGroupManagerCpuUsageInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.computeInstanceGroupManagerCpuUsagePredictionInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.computeInstanceGroupManagerCpuUsageTrendInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.computeInstanceGroupManagerMachineTypeRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.computeInstanceGroupManagerMemoryUsageInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.computeInstanceGroupManagerMemoryUsagePredictionInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.computeInstanceIdleResourceRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.computeInstanceMachineTypeRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.computeInstanceMemoryUsageInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.computeInstanceMemoryUsagePredictionInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.computeInstanceNetworkThroughputInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.containerDiagnosisInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.containerDiagnosisRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.costInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.dataflowDiagnosticsInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.errorReportingInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.errorReportingRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.firestoreDatabaseFirebaseRulesInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.firestoreDatabaseFirebaseRulesRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.firestoreDatabaseReliabilityInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.firestoreDatabaseReliabilityRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.gmpGuidedExperienceInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.gmpGuidedExperienceRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.gmpProjectManagementInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.gmpProjectManagementRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.gmpProjectProductSuggestionsInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.gmpProjectProductSuggestionsRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.iamPolicyChangeRiskInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.iamPolicyChangeRiskRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.iamPolicyInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.iamPolicyLateralMovementInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.iamPolicyRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.iamServiceAccountChangeRiskInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.iamServiceAccountChangeRiskRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.iamServiceAccountInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.locations.list</code></p>
<p><code translate="no" dir="ltr">recommender.loggingProductSuggestionContainerInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.loggingProductSuggestionContainerRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.memorystoreManageabilityInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.memorystoreManageabilityRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.memorystorePerformanceInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.memorystorePerformanceRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.memorystoreReliabilityInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.memorystoreReliabilityRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.memorystoreUtilizationInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.monitoringProductSuggestionComputeInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.monitoringProductSuggestionComputeRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.networkAnalyzerCloudSqlInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.networkAnalyzerDynamicRouteInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.networkAnalyzerGkeConnectivityInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.networkAnalyzerGkeIpAddressInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.networkAnalyzerGkeServiceAccountInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.networkAnalyzerIpAddressInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.networkAnalyzerLoadBalancerInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.networkAnalyzerVpcConnectivityInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.orgPolicyInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.orgPolicyRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.resourcemanagerProjectChangeRiskInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.resourcemanagerProjectChangeRiskRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.resourcemanagerProjectUtilizationInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.resourcemanagerProjectUtilizationRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.resourcemanagerServiceLimitInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.resourcemanagerServiceLimitRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.runServiceCostInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.runServiceCostRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.runServiceIdentityInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.runServiceIdentityRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.runServicePerformanceInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.runServicePerformanceRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.runServiceSecurityInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.runServiceSecurityRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.spannerDatabaseSecurityInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.spannerDatabaseSecurityRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.spannerProjectReliabilityInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.spannerProjectReliabilityRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.spendBasedCommitmentInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.spendBasedCommitmentRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.storageBucketSoftDeleteInsights.list</code></p>
<p><code translate="no" dir="ltr">recommender.storageBucketSoftDeleteRecommendations.list</code></p>
<p><code translate="no" dir="ltr">recommender.usageCommitmentRecommendations.list</code></p>
<p><code translate="no" dir="ltr">redis.aclPolicies.list</code></p>
<p><code translate="no" dir="ltr">redis.backupCollections.list</code></p>
<p><code translate="no" dir="ltr">redis.backups.list</code></p>
<p><code translate="no" dir="ltr">redis.clusters.list</code></p>
<p><code translate="no" dir="ltr">redis.instances.list</code></p>
<p><code translate="no" dir="ltr">redis.locations.list</code></p>
<p><code translate="no" dir="ltr">redis.operations.list</code></p>
<p><code translate="no" dir="ltr">remotebuildexecution.instances.list</code></p>
<p><code translate="no" dir="ltr">remotebuildexecution.workerpools.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.boundaries.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.capabilityConfigs.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.folders.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">resourcemanager.folders.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.hierarchyNodes.listTagBindings</code></p>
<p><code translate="no" dir="ltr">resourcemanager.organizations.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.tagHolds.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.tagKeys.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">resourcemanager.tagKeys.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.tagValues.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">resourcemanager.tagValues.list</code></p>
<p><code translate="no" dir="ltr">resourcesettings.settings.list</code></p>
<p><code translate="no" dir="ltr">retail.branches.list</code></p>
<p><code translate="no" dir="ltr">retail.catalogs.list</code></p>
<p><code translate="no" dir="ltr">retail.controls.list</code></p>
<p><code translate="no" dir="ltr">retail.experiments.list</code></p>
<p><code translate="no" dir="ltr">retail.models.list</code></p>
<p><code translate="no" dir="ltr">retail.operations.list</code></p>
<p><code translate="no" dir="ltr">retail.products.list</code></p>
<p><code translate="no" dir="ltr">retail.servingConfigs.list</code></p>
<p><code translate="no" dir="ltr">riskmanager.controlScoreBreakdowns.list</code></p>
<p><code translate="no" dir="ltr">riskmanager.operations.list</code></p>
<p><code translate="no" dir="ltr">riskmanager.policies.list</code></p>
<p><code translate="no" dir="ltr">riskmanager.reports.list</code></p>
<p><code translate="no" dir="ltr">rma.collectors.list</code></p>
<p><code translate="no" dir="ltr">rma.locations.list</code></p>
<p><code translate="no" dir="ltr">rma.operations.list</code></p>
<p><code translate="no" dir="ltr">roads.selectedRoutes.list</code></p>
<p><code translate="no" dir="ltr">run.configurations.list</code></p>
<p><code translate="no" dir="ltr">run.executions.list</code></p>
<p><code translate="no" dir="ltr">run.instances.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">run.instances.list</code></p>
<p><code translate="no" dir="ltr">run.jobs.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">run.jobs.list</code></p>
<p><code translate="no" dir="ltr">run.locations.list</code></p>
<p><code translate="no" dir="ltr">run.operations.list</code></p>
<p><code translate="no" dir="ltr">run.revisions.list</code></p>
<p><code translate="no" dir="ltr">run.routes.list</code></p>
<p><code translate="no" dir="ltr">run.services.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">run.services.list</code></p>
<p><code translate="no" dir="ltr">run.tasks.list</code></p>
<p><code translate="no" dir="ltr">run.workerpools.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">run.workerpools.list</code></p>
<p><code translate="no" dir="ltr">runapps.applications.list</code></p>
<p><code translate="no" dir="ltr">runapps.deployments.list</code></p>
<p><code translate="no" dir="ltr">runapps.locations.list</code></p>
<p><code translate="no" dir="ltr">runapps.operations.list</code></p>
<p><code translate="no" dir="ltr">runtimeconfig.configs.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">runtimeconfig.configs.list</code></p>
<p><code translate="no" dir="ltr">runtimeconfig.operations.list</code></p>
<p><code translate="no" dir="ltr">runtimeconfig.variables.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">runtimeconfig.variables.list</code></p>
<p><code translate="no" dir="ltr">runtimeconfig.waiters.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">runtimeconfig.waiters.list</code></p>
<p><code translate="no" dir="ltr">saasservicemgmt.flagAttributes.list</code></p>
<p><code translate="no" dir="ltr">saasservicemgmt.flagReleases.list</code></p>
<p><code translate="no" dir="ltr">saasservicemgmt.flagRevisions.list</code></p>
<p><code translate="no" dir="ltr">saasservicemgmt.flags.list</code></p>
<p><code translate="no" dir="ltr">saasservicemgmt.locations.list</code></p>
<p><code translate="no" dir="ltr">saasservicemgmt.operations.list</code></p>
<p><code translate="no" dir="ltr">saasservicemgmt.poolKinds.list</code></p>
<p><code translate="no" dir="ltr">saasservicemgmt.pools.list</code></p>
<p><code translate="no" dir="ltr">saasservicemgmt.releases.list</code></p>
<p><code translate="no" dir="ltr">saasservicemgmt.rolloutKinds.list</code></p>
<p><code translate="no" dir="ltr">saasservicemgmt.rollouts.list</code></p>
<p><code translate="no" dir="ltr">saasservicemgmt.saas.list</code></p>
<p><code translate="no" dir="ltr">saasservicemgmt.saasReleases.list</code></p>
<p><code translate="no" dir="ltr">saasservicemgmt.tenantOperations.list</code></p>
<p><code translate="no" dir="ltr">saasservicemgmt.tenants.list</code></p>
<p><code translate="no" dir="ltr">saasservicemgmt.unitGroupOperations.list</code></p>
<p><code translate="no" dir="ltr">saasservicemgmt.unitGroups.list</code></p>
<p><code translate="no" dir="ltr">saasservicemgmt.unitKinds.list</code></p>
<p><code translate="no" dir="ltr">saasservicemgmt.unitOperations.list</code></p>
<p><code translate="no" dir="ltr">saasservicemgmt.units.list</code></p>
<p><code translate="no" dir="ltr">secretmanager.locations.list</code></p>
<p><code translate="no" dir="ltr">secretmanager.secrets.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">secretmanager.secrets.list</code></p>
<p><code translate="no" dir="ltr">secretmanager.versions.list</code></p>
<p><code translate="no" dir="ltr">securedlandingzone.overwatches.list</code></p>
<p><code translate="no" dir="ltr">securesourcemanager.branchRules.list</code></p>
<p><code translate="no" dir="ltr">securesourcemanager.hooks.list</code></p>
<p><code translate="no" dir="ltr">securesourcemanager.instances.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">securesourcemanager.instances.list</code></p>
<p><code translate="no" dir="ltr">securesourcemanager.issuecomments.list</code></p>
<p><code translate="no" dir="ltr">securesourcemanager.issues.list</code></p>
<p><code translate="no" dir="ltr">securesourcemanager.locations.list</code></p>
<p><code translate="no" dir="ltr">securesourcemanager.operations.list</code></p>
<p><code translate="no" dir="ltr">securesourcemanager.prcomments.list</code></p>
<p><code translate="no" dir="ltr">securesourcemanager.pullRequests.list</code></p>
<p><code translate="no" dir="ltr">securesourcemanager.repositories.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">securesourcemanager.repositories.list</code></p>
<p><code translate="no" dir="ltr">securesourcemanager.sshkeys.list</code></p>
<p><code translate="no" dir="ltr">securitycenter.assets.list</code></p>
<p><code translate="no" dir="ltr">securitycenter.attackpaths.list</code></p>
<p><code translate="no" dir="ltr">securitycenter.bigQueryExports.list</code></p>
<p><code translate="no" dir="ltr">securitycenter.compliancesnapshots.list</code></p>
<p><code translate="no" dir="ltr">securitycenter.effectivesecurityhealthanalyticscustommodules.list</code></p>
<p><code translate="no" dir="ltr">securitycenter.findings.list</code></p>
<p><code translate="no" dir="ltr">securitycenter.issues.list</code></p>
<p><code translate="no" dir="ltr">securitycenter.muteconfigs.list</code></p>
<p><code translate="no" dir="ltr">securitycenter.notificationconfig.list</code></p>
<p><code translate="no" dir="ltr">securitycenter.resourcevalueconfigs.list</code></p>
<p><code translate="no" dir="ltr">securitycenter.riskreports.list</code></p>
<p><code translate="no" dir="ltr">securitycenter.securityhealthanalyticscustommodules.list</code></p>
<p><code translate="no" dir="ltr">securitycenter.sources.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">securitycenter.sources.list</code></p>
<p><code translate="no" dir="ltr">securitycenter.valuedresources.list</code></p>
<p><code translate="no" dir="ltr">securitycenter.vulnerabilitysnapshots.list</code></p>
<p><code translate="no" dir="ltr">securitycentermanagement.effectiveEventThreatDetectionCustomModules.list</code></p>
<p><code translate="no" dir="ltr">securitycentermanagement.effectiveSecurityHealthAnalyticsCustomModules.list</code></p>
<p><code translate="no" dir="ltr">securitycentermanagement.eventThreatDetectionCustomModules.list</code></p>
<p><code translate="no" dir="ltr">securitycentermanagement.locations.list</code></p>
<p><code translate="no" dir="ltr">securitycentermanagement.operations.list</code></p>
<p><code translate="no" dir="ltr">securitycentermanagement.securityCenterServices.list</code></p>
<p><code translate="no" dir="ltr">securitycentermanagement.securityHealthAnalyticsCustomModules.list</code></p>
<p><code translate="no" dir="ltr">securityposture.locations.list</code></p>
<p><code translate="no" dir="ltr">securityposture.operations.list</code></p>
<p><code translate="no" dir="ltr">securityposture.postureDeployments.list</code></p>
<p><code translate="no" dir="ltr">securityposture.postureTemplates.list</code></p>
<p><code translate="no" dir="ltr">securityposture.postures.list</code></p>
<p><code translate="no" dir="ltr">securityposture.reports.list</code></p>
<p><code translate="no" dir="ltr">servicebroker.bindingoperations.list</code></p>
<p><code translate="no" dir="ltr">servicebroker.bindings.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">servicebroker.bindings.list</code></p>
<p><code translate="no" dir="ltr">servicebroker.catalogs.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">servicebroker.catalogs.list</code></p>
<p><code translate="no" dir="ltr">servicebroker.instanceoperations.list</code></p>
<p><code translate="no" dir="ltr">servicebroker.instances.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">servicebroker.instances.list</code></p>
<p><code translate="no" dir="ltr">serviceconsumermanagement.tenancyu.list</code></p>
<p><code translate="no" dir="ltr">servicedirectory.endpoints.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">servicedirectory.endpoints.list</code></p>
<p><code translate="no" dir="ltr">servicedirectory.locations.list</code></p>
<p><code translate="no" dir="ltr">servicedirectory.namespaces.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">servicedirectory.namespaces.list</code></p>
<p><code translate="no" dir="ltr">servicedirectory.services.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">servicedirectory.services.list</code></p>
<p><code translate="no" dir="ltr">serviceextensions.locations.list</code></p>
<p><code translate="no" dir="ltr">servicehealth.artifacts.list</code></p>
<p><code translate="no" dir="ltr">servicehealth.events.list</code></p>
<p><code translate="no" dir="ltr">servicehealth.locations.list</code></p>
<p><code translate="no" dir="ltr">servicehealth.organizationEvents.list</code></p>
<p><code translate="no" dir="ltr">servicehealth.organizationImpacts.list</code></p>
<p><code translate="no" dir="ltr">servicemanagement.services.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">servicemanagement.services.list</code></p>
<p><code translate="no" dir="ltr">servicenetworking.operations.list</code></p>
<p><code translate="no" dir="ltr">servicesecurityinsights.clusterSecurityInfo.list</code></p>
<p><code translate="no" dir="ltr">servicesecurityinsights.securityInfo.list</code></p>
<p><code translate="no" dir="ltr">servicesecurityinsights.workloadPolicies.list</code></p>
<p><code translate="no" dir="ltr">serviceusage.groups.list</code></p>
<p><code translate="no" dir="ltr">serviceusage.services.list</code></p>
<p><code translate="no" dir="ltr">source.repos.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">source.repos.list</code></p>
<p><code translate="no" dir="ltr">spanner.backupOperations.list</code></p>
<p><code translate="no" dir="ltr">spanner.backupSchedules.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">spanner.backupSchedules.list</code></p>
<p><code translate="no" dir="ltr">spanner.backups.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">spanner.backups.list</code></p>
<p><code translate="no" dir="ltr">spanner.databaseOperations.list</code></p>
<p><code translate="no" dir="ltr">spanner.databaseRoles.list</code></p>
<p><code translate="no" dir="ltr">spanner.databases.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">spanner.databases.list</code></p>
<p><code translate="no" dir="ltr">spanner.instanceConfigOperations.list</code></p>
<p><code translate="no" dir="ltr">spanner.instanceConfigs.list</code></p>
<p><code translate="no" dir="ltr">spanner.instanceOperations.list</code></p>
<p><code translate="no" dir="ltr">spanner.instancePartitionOperations.list</code></p>
<p><code translate="no" dir="ltr">spanner.instancePartitions.list</code></p>
<p><code translate="no" dir="ltr">spanner.instances.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">spanner.instances.list</code></p>
<p><code translate="no" dir="ltr">spanner.sessions.list</code></p>
<p><code translate="no" dir="ltr">speakerid.phrases.list</code></p>
<p><code translate="no" dir="ltr">speakerid.speakers.list</code></p>
<p><code translate="no" dir="ltr">speech.customClasses.list</code></p>
<p><code translate="no" dir="ltr">speech.locations.list</code></p>
<p><code translate="no" dir="ltr">speech.operations.list</code></p>
<p><code translate="no" dir="ltr">speech.phraseSets.list</code></p>
<p><code translate="no" dir="ltr">speech.recognizers.list</code></p>
<p><code translate="no" dir="ltr">stackdriver.resourceMetadata.list</code></p>
<p><code translate="no" dir="ltr">storage.anywhereCaches.list</code></p>
<p><code translate="no" dir="ltr">storage.bucketOperations.list</code></p>
<p><code translate="no" dir="ltr">storage.buckets.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">storage.buckets.list</code></p>
<p><code translate="no" dir="ltr">storage.featureConfigs.list</code></p>
<p><code translate="no" dir="ltr">storage.folders.list</code></p>
<p><code translate="no" dir="ltr">storage.hmacKeys.list</code></p>
<p><code translate="no" dir="ltr">storage.managedFolders.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">storage.managedFolders.list</code></p>
<p><code translate="no" dir="ltr">storage.multipartUploads.list</code></p>
<p><code translate="no" dir="ltr">storage.objects.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">storage.objects.list</code></p>
<p><code translate="no" dir="ltr">storagebatchoperations.bucketOperations.list</code></p>
<p><code translate="no" dir="ltr">storagebatchoperations.jobs.list</code></p>
<p><code translate="no" dir="ltr">storagebatchoperations.locations.list</code></p>
<p><code translate="no" dir="ltr">storagebatchoperations.operations.list</code></p>
<p><code translate="no" dir="ltr">storageinsights.datasetConfigs.list</code></p>
<p><code translate="no" dir="ltr">storageinsights.locations.list</code></p>
<p><code translate="no" dir="ltr">storageinsights.operations.list</code></p>
<p><code translate="no" dir="ltr">storageinsights.reportConfigs.list</code></p>
<p><code translate="no" dir="ltr">storageinsights.reportDetails.list</code></p>
<p><code translate="no" dir="ltr">storagetransfer.agentpools.list</code></p>
<p><code translate="no" dir="ltr">storagetransfer.jobs.list</code></p>
<p><code translate="no" dir="ltr">storagetransfer.operations.list</code></p>
<p><code translate="no" dir="ltr">stream.locations.list</code></p>
<p><code translate="no" dir="ltr">stream.operations.list</code></p>
<p><code translate="no" dir="ltr">stream.streamContents.list</code></p>
<p><code translate="no" dir="ltr">stream.streamInstances.list</code></p>
<p><code translate="no" dir="ltr">telcoautomation.blueprints.list</code></p>
<p><code translate="no" dir="ltr">telcoautomation.deployments.list</code></p>
<p><code translate="no" dir="ltr">telcoautomation.edgeSlms.list</code></p>
<p><code translate="no" dir="ltr">telcoautomation.hydratedDeployments.list</code></p>
<p><code translate="no" dir="ltr">telcoautomation.locations.list</code></p>
<p><code translate="no" dir="ltr">telcoautomation.operations.list</code></p>
<p><code translate="no" dir="ltr">telcoautomation.orchestrationClusters.list</code></p>
<p><code translate="no" dir="ltr">telcoautomation.publicBlueprints.list</code></p>
<p><code translate="no" dir="ltr">telemetry.consumers.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">threatintelligence.alerts.list</code></p>
<p><code translate="no" dir="ltr">threatintelligence.configurations.list</code></p>
<p><code translate="no" dir="ltr">threatintelligence.findings.list</code></p>
<p><code translate="no" dir="ltr">tpu.acceleratortypes.list</code></p>
<p><code translate="no" dir="ltr">tpu.locations.list</code></p>
<p><code translate="no" dir="ltr">tpu.nodes.list</code></p>
<p><code translate="no" dir="ltr">tpu.operations.list</code></p>
<p><code translate="no" dir="ltr">tpu.runtimeversions.list</code></p>
<p><code translate="no" dir="ltr">tpu.tensorflowversions.list</code></p>
<p><code translate="no" dir="ltr">transcoder.jobTemplates.list</code></p>
<p><code translate="no" dir="ltr">transcoder.jobs.list</code></p>
<p><code translate="no" dir="ltr">transferappliance.appliances.list</code></p>
<p><code translate="no" dir="ltr">transferappliance.locations.list</code></p>
<p><code translate="no" dir="ltr">transferappliance.operations.list</code></p>
<p><code translate="no" dir="ltr">transferappliance.orders.list</code></p>
<p><code translate="no" dir="ltr">transferappliance.savedAddresses.list</code></p>
<p><code translate="no" dir="ltr">translationhub.portals.list</code></p>
<p><code translate="no" dir="ltr">universalledger.endpoints.list</code></p>
<p><code translate="no" dir="ltr">universalledger.locations.list</code></p>
<p><code translate="no" dir="ltr">vectorsearch.collections.list</code></p>
<p><code translate="no" dir="ltr">vectorsearch.indexes.list</code></p>
<p><code translate="no" dir="ltr">vectorsearch.locations.list</code></p>
<p><code translate="no" dir="ltr">vectorsearch.operations.list</code></p>
<p><code translate="no" dir="ltr">videostitcher.cdnKeys.list</code></p>
<p><code translate="no" dir="ltr">videostitcher.liveAdTagDetails.list</code></p>
<p><code translate="no" dir="ltr">videostitcher.liveConfigs.list</code></p>
<p><code translate="no" dir="ltr">videostitcher.operations.list</code></p>
<p><code translate="no" dir="ltr">videostitcher.slates.list</code></p>
<p><code translate="no" dir="ltr">videostitcher.vodAdTagDetails.list</code></p>
<p><code translate="no" dir="ltr">videostitcher.vodConfigs.list</code></p>
<p><code translate="no" dir="ltr">videostitcher.vodStitchDetails.list</code></p>
<p><code translate="no" dir="ltr">visionai.analyses.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">visionai.analyses.list</code></p>
<p><code translate="no" dir="ltr">visionai.annotations.list</code></p>
<p><code translate="no" dir="ltr">visionai.applications.list</code></p>
<p><code translate="no" dir="ltr">visionai.assets.list</code></p>
<p><code translate="no" dir="ltr">visionai.clusters.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">visionai.clusters.list</code></p>
<p><code translate="no" dir="ltr">visionai.corpora.list</code></p>
<p><code translate="no" dir="ltr">visionai.dataSchemas.list</code></p>
<p><code translate="no" dir="ltr">visionai.drafts.list</code></p>
<p><code translate="no" dir="ltr">visionai.events.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">visionai.events.list</code></p>
<p><code translate="no" dir="ltr">visionai.indexEndpoints.list</code></p>
<p><code translate="no" dir="ltr">visionai.indexes.list</code></p>
<p><code translate="no" dir="ltr">visionai.instances.list</code></p>
<p><code translate="no" dir="ltr">visionai.locations.list</code></p>
<p><code translate="no" dir="ltr">visionai.operations.list</code></p>
<p><code translate="no" dir="ltr">visionai.operators.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">visionai.operators.list</code></p>
<p><code translate="no" dir="ltr">visionai.processors.list</code></p>
<p><code translate="no" dir="ltr">visionai.searchConfigs.list</code></p>
<p><code translate="no" dir="ltr">visionai.series.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">visionai.series.list</code></p>
<p><code translate="no" dir="ltr">visionai.streams.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">visionai.streams.list</code></p>
<p><code translate="no" dir="ltr">visionai.uistreams.list</code></p>
<p><code translate="no" dir="ltr">visualinspection.annotationSets.list</code></p>
<p><code translate="no" dir="ltr">visualinspection.annotationSpecs.list</code></p>
<p><code translate="no" dir="ltr">visualinspection.annotations.list</code></p>
<p><code translate="no" dir="ltr">visualinspection.datasets.list</code></p>
<p><code translate="no" dir="ltr">visualinspection.images.list</code></p>
<p><code translate="no" dir="ltr">visualinspection.locations.list</code></p>
<p><code translate="no" dir="ltr">visualinspection.modelEvaluations.list</code></p>
<p><code translate="no" dir="ltr">visualinspection.models.list</code></p>
<p><code translate="no" dir="ltr">visualinspection.modules.list</code></p>
<p><code translate="no" dir="ltr">visualinspection.operations.list</code></p>
<p><code translate="no" dir="ltr">visualinspection.solutionArtifacts.list</code></p>
<p><code translate="no" dir="ltr">visualinspection.solutions.list</code></p>
<p><code translate="no" dir="ltr">vmmigration.cloneJobs.list</code></p>
<p><code translate="no" dir="ltr">vmmigration.cutoverJobs.list</code></p>
<p><code translate="no" dir="ltr">vmmigration.datacenterConnectors.list</code></p>
<p><code translate="no" dir="ltr">vmmigration.deployments.list</code></p>
<p><code translate="no" dir="ltr">vmmigration.groups.list</code></p>
<p><code translate="no" dir="ltr">vmmigration.imageImportJobs.list</code></p>
<p><code translate="no" dir="ltr">vmmigration.imageImports.list</code></p>
<p><code translate="no" dir="ltr">vmmigration.locations.list</code></p>
<p><code translate="no" dir="ltr">vmmigration.migratingVms.list</code></p>
<p><code translate="no" dir="ltr">vmmigration.operations.list</code></p>
<p><code translate="no" dir="ltr">vmmigration.replicationCycles.list</code></p>
<p><code translate="no" dir="ltr">vmmigration.sources.list</code></p>
<p><code translate="no" dir="ltr">vmmigration.targets.list</code></p>
<p><code translate="no" dir="ltr">vmmigration.utilizationReports.list</code></p>
<p><code translate="no" dir="ltr">vmwareengine.clusters.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">vmwareengine.clusters.list</code></p>
<p><code translate="no" dir="ltr">vmwareengine.datastores.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">vmwareengine.datastores.list</code></p>
<p><code translate="no" dir="ltr">vmwareengine.externalAccessRules.list</code></p>
<p><code translate="no" dir="ltr">vmwareengine.externalAddresses.list</code></p>
<p><code translate="no" dir="ltr">vmwareengine.hcxActivationKeys.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">vmwareengine.hcxActivationKeys.list</code></p>
<p><code translate="no" dir="ltr">vmwareengine.locations.list</code></p>
<p><code translate="no" dir="ltr">vmwareengine.loggingServers.list</code></p>
<p><code translate="no" dir="ltr">vmwareengine.managementDnsZoneBindings.list</code></p>
<p><code translate="no" dir="ltr">vmwareengine.networkPeerings.list</code></p>
<p><code translate="no" dir="ltr">vmwareengine.networkPolicies.list</code></p>
<p><code translate="no" dir="ltr">vmwareengine.nodeTypes.list</code></p>
<p><code translate="no" dir="ltr">vmwareengine.nodes.list</code></p>
<p><code translate="no" dir="ltr">vmwareengine.operations.list</code></p>
<p><code translate="no" dir="ltr">vmwareengine.privateClouds.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">vmwareengine.privateClouds.list</code></p>
<p><code translate="no" dir="ltr">vmwareengine.privateConnections.list</code></p>
<p><code translate="no" dir="ltr">vmwareengine.subnets.list</code></p>
<p><code translate="no" dir="ltr">vmwareengine.vmwareEngineNetworks.list</code></p>
<p><code translate="no" dir="ltr">vpcaccess.connectors.list</code></p>
<p><code translate="no" dir="ltr">vpcaccess.locations.list</code></p>
<p><code translate="no" dir="ltr">vpcaccess.operations.list</code></p>
<p><code translate="no" dir="ltr">workflows.callbacks.list</code></p>
<p><code translate="no" dir="ltr">workflows.executions.list</code></p>
<p><code translate="no" dir="ltr">workflows.locations.list</code></p>
<p><code translate="no" dir="ltr">workflows.operations.list</code></p>
<p><code translate="no" dir="ltr">workflows.stepEntries.list</code></p>
<p><code translate="no" dir="ltr">workflows.workflows.list</code></p>
<p><code translate="no" dir="ltr">workloadcertificate.locations.list</code></p>
<p><code translate="no" dir="ltr">workloadcertificate.operations.list</code></p>
<p><code translate="no" dir="ltr">workloadcertificate.workloadRegistrations.list</code></p>
<p><code translate="no" dir="ltr">workloadidentity.locations.list</code></p>
<p><code translate="no" dir="ltr">workloadidentity.operations.list</code></p>
<p><code translate="no" dir="ltr">workloadmanager.actuations.list</code></p>
<p><code translate="no" dir="ltr">workloadmanager.deployments.list</code></p>
<p><code translate="no" dir="ltr">workloadmanager.discoveredprofiles.list</code></p>
<p><code translate="no" dir="ltr">workloadmanager.evaluations.list</code></p>
<p><code translate="no" dir="ltr">workloadmanager.executions.list</code></p>
<p><code translate="no" dir="ltr">workloadmanager.findings.list</code></p>
<p><code translate="no" dir="ltr">workloadmanager.locations.list</code></p>
<p><code translate="no" dir="ltr">workloadmanager.operations.list</code></p>
<p><code translate="no" dir="ltr">workloadmanager.results.list</code></p>
<p><code translate="no" dir="ltr">workloadmanager.rules.list</code></p>
<p><code translate="no" dir="ltr">workloadmanager.workloads.list</code></p>
<p><code translate="no" dir="ltr">workstations.operations.list</code></p>
<p><code translate="no" dir="ltr">workstations.workstationClusters.list</code></p>
<p><code translate="no" dir="ltr">workstations.workstationConfigs.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">workstations.workstationConfigs.list</code></p>
<p><code translate="no" dir="ltr">workstations.workstations.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">workstations.workstations.list</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="iam.serviceAccountAdmin" class="role-title add-link" data-text="Service Account Admin " tabindex="-1">Service Account Admin</h4>
<p>(<code translate="no" dir="ltr">roles/iam.serviceAccountAdmin</code>)</p>
<span class="role-description"> </span>
<p>Create and manage service accounts.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Service Account</li>
</ul></td>
<td class="role-permissions"><p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iam.serviceAccountApiKeyBindings.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iam.serviceAccountApiKeyBindings.create</code></li>
<li><code translate="no" dir="ltr">iam.serviceAccountApiKeyBindings.delete</code></li>
<li><code translate="no" dir="ltr">iam.serviceAccountApiKeyBindings.undelete</code></li>
</ul>
<p><code translate="no" dir="ltr">iam.serviceAccounts.create</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.createTagBinding</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.delete</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.deleteTagBinding</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.disable</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.enable</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.get</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.list</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.listTagBindings</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.setIamPolicy</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.undelete</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.update</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="iam.serviceAccountCreator" class="role-title add-link" data-text="Create Service Accounts " tabindex="-1">Create Service Accounts</h4>
<p>(<code translate="no" dir="ltr">roles/iam.serviceAccountCreator</code>)</p>
<span class="role-description"> </span>
<p>Access to create service accounts.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">iam.serviceAccounts.create</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.get</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="iam.serviceAccountKeyAdmin" class="role-title add-link" data-text="Service Account Key Admin " tabindex="-1">Service Account Key Admin</h4>
<p>(<code translate="no" dir="ltr">roles/iam.serviceAccountKeyAdmin</code>)</p>
<span class="role-description"> </span>
<p>Create and manage (and rotate) service account keys.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Service Account</li>
</ul></td>
<td class="role-permissions"><p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iam.serviceAccountKeys.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iam.serviceAccountKeys.create</code></li>
<li><code translate="no" dir="ltr">iam.serviceAccountKeys.delete</code></li>
<li><code translate="no" dir="ltr">iam.serviceAccountKeys.disable</code></li>
<li><code translate="no" dir="ltr">iam.serviceAccountKeys.enable</code></li>
<li><code translate="no" dir="ltr">iam.serviceAccountKeys.get</code></li>
<li><code translate="no" dir="ltr">iam.serviceAccountKeys.list</code></li>
</ul>
<p><code translate="no" dir="ltr">iam.serviceAccounts.get</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="iam.serviceAccountTokenCreator" class="role-title add-link" data-text="Service Account Token Creator " tabindex="-1">Service Account Token Creator</h4>
<p>(<code translate="no" dir="ltr">roles/iam.serviceAccountTokenCreator</code>)</p>
<span class="role-description"> </span>
<p>Impersonate service accounts (create OAuth2 access tokens, sign blobs or JWTs, etc).</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Service Account</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">iam.serviceAccounts.get</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.getAccessToken</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.getOpenIdToken</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.implicitDelegation</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.list</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.signBlob</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.signJwt</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="iam.serviceAccountUser" class="role-title add-link" data-text="Service Account User " tabindex="-1">Service Account User</h4>
<p>(<code translate="no" dir="ltr">roles/iam.serviceAccountUser</code>)</p>
<span class="role-description"> </span>
<p>Run operations as the service account.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Service Account</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">iam.serviceAccounts.actAs</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.get</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="iam.serviceAccountViewer" class="role-title add-link" data-text="View Service Accounts " tabindex="-1">View Service Accounts</h4>
<p>(<code translate="no" dir="ltr">roles/iam.serviceAccountViewer</code>)</p>
<span class="role-description"> </span>
<p>Read access to service accounts, metadata, and keys.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">iam.serviceAccountKeys.get</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccountKeys.list</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.get</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.list</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.listTagBindings</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="iam.viewer" class="role-title add-link" data-text="Iam Viewer " tabindex="-1">Iam Viewer</h4>
<p>(<code translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<span class="role-description"> </span>
<p>Viewer role for iam</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">iam.accesspolicies.get</code></p>
<p><code translate="no" dir="ltr">iam.accesspolicies.list</code></p>
<p><code translate="no" dir="ltr">iam.accesspolicies.searchPolicyBindings</code></p>
<p><code translate="no" dir="ltr">iam.denypolicies.get</code></p>
<p><code translate="no" dir="ltr">iam.denypolicies.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/oauthClientCredentials.get</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/oauthClientCredentials.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/oauthClients.get</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/oauthClients.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderKeys.get</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderKeys.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimGroups.get</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimGroups.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimUsers.get</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimUsers.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviders.computeUserAttributes</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviders.get</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviders.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.get</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.searchPolicyBindings</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolManagedIdentities.get</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolManagedIdentities.getAttestationRules</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolManagedIdentities.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolNamespaces.get</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolNamespaces.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolProviderKeys.get</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolProviderKeys.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolProviders.get</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolProviders.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPools.get</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPools.getAttestationRules</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPools.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPools.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workspacePools.searchPolicyBindings</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iam.policybindings.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iam.policybindings.get</code></li>
<li><code translate="no" dir="ltr">iam.policybindings.list</code></li>
</ul>
<p><code translate="no" dir="ltr">iam.principalaccessboundarypolicies.get</code></p>
<p><code translate="no" dir="ltr">iam.principalaccessboundarypolicies.list</code></p>
<p><code translate="no" dir="ltr">iam.principalaccessboundarypolicies.searchPolicyBindings</code></p>
<p><code translate="no" dir="ltr">iam.roles.get</code></p>
<p><code translate="no" dir="ltr">iam.roles.list</code></p>
<p><code translate="no" dir="ltr">iam.roles.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">iam.roles.listTagBindings</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccountKeys.get</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccountKeys.list</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.get</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.list</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.listTagBindings</code></p>
<p><code translate="no" dir="ltr">iam.workloadIdentityPools.searchPolicyBindings</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="iam.workloadIdentityUser" class="role-title add-link" data-text="Workload Identity User " tabindex="-1">Workload Identity User</h4>
<p>(<code translate="no" dir="ltr">roles/iam.workloadIdentityUser</code>)</p>
<span class="role-description custom"> </span>
<p>Impersonate service accounts from federated workloads.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">iam.serviceAccounts.get</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.getAccessToken</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.getOpenIdToken</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.list</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="iam.accessPolicyUser" class="role-title add-link" data-text="Access Policy User Beta " tabindex="-1">Access Policy User <sup>Beta</sup></h4>
<p>(<code translate="no" dir="ltr">roles/iam.accessPolicyUser</code>)</p>
<span class="role-description custom"> </span>
<p>Access Policies user role, with permissions to view access policies, and to bind and unbind access policies to targets.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">iam.accesspolicies.bind</code></p>
<p><code translate="no" dir="ltr">iam.accesspolicies.get</code></p>
<p><code translate="no" dir="ltr">iam.accesspolicies.list</code></p>
<p><code translate="no" dir="ltr">iam.accesspolicies.unbind</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="iam.accessPolicyViewer" class="role-title add-link" data-text="Access Policy Viewer Beta " tabindex="-1">Access Policy Viewer <sup>Beta</sup></h4>
<p>(<code translate="no" dir="ltr">roles/iam.accessPolicyViewer</code>)</p>
<span class="role-description custom"> </span>
<p>Access Policy Viewer role, with permissions to read access policies and view associated policy bindings.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">iam.accesspolicies.get</code></p>
<p><code translate="no" dir="ltr">iam.accesspolicies.list</code></p>
<p><code translate="no" dir="ltr">iam.accesspolicies.searchPolicyBindings</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="iam.denyAdmin" class="role-title add-link" data-text="Deny Admin " tabindex="-1">Deny Admin</h4>
<p>(<code translate="no" dir="ltr">roles/iam.denyAdmin</code>)</p>
<span class="role-description"> </span>
<p>Deny admin role, with permissions to read and modify deny policies</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Organization</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudasset.assets.listResource</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iam.denypolicies.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iam.denypolicies.create</code></li>
<li><code translate="no" dir="ltr">iam.denypolicies.delete</code></li>
<li><code translate="no" dir="ltr">iam.denypolicies.get</code></li>
<li><code translate="no" dir="ltr">iam.denypolicies.list</code></li>
<li><code translate="no" dir="ltr">iam.denypolicies.update</code></li>
</ul>
<p><code translate="no" dir="ltr">policyanalyzer.resourceAuthorizationActivities.query</code></p>
<p><code translate="no" dir="ltr">policysimulator.accessPolicySimulationResults.list</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">policysimulator.accessPolicySimulations.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">policysimulator.accessPolicySimulations.create</code></li>
<li><code translate="no" dir="ltr">policysimulator.accessPolicySimulations.get</code></li>
<li><code translate="no" dir="ltr">policysimulator.accessPolicySimulations.list</code></li>
</ul></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="iam.denyReviewer" class="role-title add-link" data-text="Deny Reviewer " tabindex="-1">Deny Reviewer</h4>
<p>(<code translate="no" dir="ltr">roles/iam.denyReviewer</code>)</p>
<span class="role-description"> </span>
<p>Deny Reviewer role, with permissions to read deny policies</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Organization</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">iam.denypolicies.get</code></p>
<p><code translate="no" dir="ltr">iam.denypolicies.list</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="iam.oauthClientAdmin" class="role-title add-link" data-text="IAM OAuth Client Admin " tabindex="-1">IAM OAuth Client Admin</h4>
<p>(<code translate="no" dir="ltr">roles/iam.oauthClientAdmin</code>)</p>
<span class="role-description"> </span>
<p>Full rights to create and manage OAuth clients.</p></td>
<td class="role-permissions"><p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iam.oauthClientCredentials.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iam.googleapis.com/oauthClientCredentials.create</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/oauthClientCredentials.delete</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/oauthClientCredentials.get</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/oauthClientCredentials.list</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/oauthClientCredentials.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iam.oauthClients.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iam.googleapis.com/oauthClients.create</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/oauthClients.delete</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/oauthClients.get</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/oauthClients.list</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/oauthClients.undelete</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/oauthClients.update</code></li>
</ul>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="iam.oauthClientViewer" class="role-title add-link" data-text="IAM OAuth Client Viewer " tabindex="-1">IAM OAuth Client Viewer</h4>
<p>(<code translate="no" dir="ltr">roles/iam.oauthClientViewer</code>)</p>
<span class="role-description"> </span>
<p>Read access to a particular instance of an OAuth client.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">iam.googleapis.com/oauthClientCredentials.get</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/oauthClientCredentials.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/oauthClients.get</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/oauthClients.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="iam.operationViewer" class="role-title add-link" data-text="IAM Operation Viewer " tabindex="-1">IAM Operation Viewer</h4>
<p>(<code translate="no" dir="ltr">roles/iam.operationViewer</code>)</p>
<span class="role-description"> </span>
<p>Operation user role, with permissions to view and list operations in IAM v3</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">iam.operations.get</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="iam.organizationRoleAdmin" class="role-title add-link" data-text="Organization Role Administrator " tabindex="-1">Organization Role Administrator</h4>
<p>(<code translate="no" dir="ltr">roles/iam.organizationRoleAdmin</code>)</p>
<span class="role-description custom"> </span>
<p>Provides access to administer all custom roles in the organization and the projects below it.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Organization</li>
</ul></td>
<td class="role-permissions"><p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iam.roles.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iam.roles.create</code></li>
<li><code translate="no" dir="ltr">iam.roles.createTagBinding</code></li>
<li><code translate="no" dir="ltr">iam.roles.delete</code></li>
<li><code translate="no" dir="ltr">iam.roles.deleteTagBinding</code></li>
<li><code translate="no" dir="ltr">iam.roles.get</code></li>
<li><code translate="no" dir="ltr">iam.roles.list</code></li>
<li><code translate="no" dir="ltr">iam.roles.listEffectiveTags</code></li>
<li><code translate="no" dir="ltr">iam.roles.listTagBindings</code></li>
<li><code translate="no" dir="ltr">iam.roles.undelete</code></li>
<li><code translate="no" dir="ltr">iam.roles.update</code></li>
</ul>
<p><code translate="no" dir="ltr">resourcemanager.organizations.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.organizations.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="iam.organizationRoleViewer" class="role-title add-link" data-text="Organization Role Viewer " tabindex="-1">Organization Role Viewer</h4>
<p>(<code translate="no" dir="ltr">roles/iam.organizationRoleViewer</code>)</p>
<span class="role-description custom"> </span>
<p>Provides read access to all custom roles in the organization and the projects below it.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Organization</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">iam.roles.get</code></p>
<p><code translate="no" dir="ltr">iam.roles.list</code></p>
<p><code translate="no" dir="ltr">iam.roles.listEffectiveTags</code></p>
<p><code translate="no" dir="ltr">iam.roles.listTagBindings</code></p>
<p><code translate="no" dir="ltr">resourcemanager.organizations.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.organizations.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="iam.principalAccessBoundaryAdmin" class="role-title add-link" data-text="Principal Access Boundary Policy Admin " tabindex="-1">Principal Access Boundary Policy Admin</h4>
<p>(<code translate="no" dir="ltr">roles/iam.principalAccessBoundaryAdmin</code>)</p>
<span class="role-description"> </span>
<p>Full management of Principal Access Boundary policies and their bindings to principal sets, including the ability to simulate policy impacts.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">cloudasset.assets.listResource</code></p>
<p><code translate="no" dir="ltr">cloudasset.assets.searchAllResources</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iam.principalaccessboundarypolicies.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iam.principalaccessboundarypolicies.bind</code></li>
<li><code translate="no" dir="ltr">iam.principalaccessboundarypolicies.create</code></li>
<li><code translate="no" dir="ltr">iam.principalaccessboundarypolicies.delete</code></li>
<li><code translate="no" dir="ltr">iam.principalaccessboundarypolicies.get</code></li>
<li><code translate="no" dir="ltr">iam.principalaccessboundarypolicies.list</code></li>
<li><code translate="no" dir="ltr">iam.principalaccessboundarypolicies.searchPolicyBindings</code></li>
<li><code translate="no" dir="ltr">iam.principalaccessboundarypolicies.unbind</code></li>
<li><code translate="no" dir="ltr">iam.principalaccessboundarypolicies.update</code></li>
</ul></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="iam.principalAccessBoundaryUser" class="role-title add-link" data-text="Principal Access Boundary Policy User " tabindex="-1">Principal Access Boundary Policy User</h4>
<p>(<code translate="no" dir="ltr">roles/iam.principalAccessBoundaryUser</code>)</p>
<span class="role-description"> </span>
<p>View Principal Access Boundary policies and manage policy bindings to associate them with principal sets.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">iam.principalaccessboundarypolicies.bind</code></p>
<p><code translate="no" dir="ltr">iam.principalaccessboundarypolicies.get</code></p>
<p><code translate="no" dir="ltr">iam.principalaccessboundarypolicies.list</code></p>
<p><code translate="no" dir="ltr">iam.principalaccessboundarypolicies.unbind</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="iam.scimSyncer" class="role-title add-link" data-text="SCIM Data Syncer " tabindex="-1">SCIM Data Syncer</h4>
<p>(<code translate="no" dir="ltr">roles/iam.scimSyncer</code>)</p>
<span class="role-description"> </span>
<p>Rights to sync users and groups from external identity providers.</p></td>
<td class="role-permissions"><p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iam.workforcePoolProviderScimGroups.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimGroups.create</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimGroups.delete</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimGroups.get</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimGroups.list</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimGroups.patch</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimGroups.put</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iam.workforcePoolProviderScimUsers.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimUsers.create</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimUsers.delete</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimUsers.get</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimUsers.list</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimUsers.patch</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimUsers.put</code></li>
</ul></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="iam.serviceAccountApiKeyBindingAdmin" class="role-title add-link" data-text="Service Account API Key Binding Admin " tabindex="-1">Service Account API Key Binding Admin</h4>
<p>(<code translate="no" dir="ltr">roles/iam.serviceAccountApiKeyBindingAdmin</code>)</p>
<span class="role-description"> </span>
<p>Create and delete service account API Key bindings</p></td>
<td class="role-permissions"><p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iam.serviceAccountApiKeyBindings.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iam.serviceAccountApiKeyBindings.create</code></li>
<li><code translate="no" dir="ltr">iam.serviceAccountApiKeyBindings.delete</code></li>
<li><code translate="no" dir="ltr">iam.serviceAccountApiKeyBindings.undelete</code></li>
</ul></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="iam.serviceAccountDeleter" class="role-title add-link" data-text="Delete Service Accounts " tabindex="-1">Delete Service Accounts</h4>
<p>(<code translate="no" dir="ltr">roles/iam.serviceAccountDeleter</code>)</p>
<span class="role-description"> </span>
<p>Access to delete service accounts.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">iam.serviceAccounts.delete</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.get</code></p>
<p><code translate="no" dir="ltr">iam.serviceAccounts.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="iam.serviceAccountOpenIdTokenCreator" class="role-title add-link" data-text="Service Account OpenID Connect Identity Token Creator " tabindex="-1">Service Account OpenID Connect Identity Token Creator</h4>
<p>(<code translate="no" dir="ltr">roles/iam.serviceAccountOpenIdTokenCreator</code>)</p>
<span class="role-description"> </span>
<p>Create OpenID Connect (OIDC) identity tokens</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">iam.serviceAccounts.getOpenIdToken</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="iam.workforcePoolAdmin" class="role-title add-link" data-text="IAM Workforce Pool Admin " tabindex="-1">IAM Workforce Pool Admin</h4>
<p>(<code translate="no" dir="ltr">roles/iam.workforcePoolAdmin</code>)</p>
<span class="role-description"> </span>
<p>Full rights to create and manage all workforce pools in the org, along with the ability to delegate permissions to other admins.</p></td>
<td class="role-permissions"><p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iam.workforcePoolProviderKeys.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderKeys.create</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderKeys.delete</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderKeys.get</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderKeys.list</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderKeys.undelete</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iam.workforcePoolProviderScimGroups.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimGroups.create</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimGroups.delete</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimGroups.get</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimGroups.list</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimGroups.patch</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimGroups.put</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iam.workforcePoolProviderScimUsers.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimUsers.create</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimUsers.delete</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimUsers.get</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimUsers.list</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimUsers.patch</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimUsers.put</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iam.workforcePoolProviders.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviders.computeUserAttributes</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviders.create</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviders.delete</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviders.get</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviders.list</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviders.undelete</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviders.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iam.workforcePoolSubjects.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolSubjects.delete</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolSubjects.revokeSessions</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolSubjects.undelete</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iam.workforcePools.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.create</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.createPolicyBinding</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.delete</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.deletePolicyBinding</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.get</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.list</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.searchPolicyBindings</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.undelete</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.update</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.updatePolicyBinding</code></li>
</ul></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="iam.workforcePoolEditor" class="role-title add-link" data-text="IAM Workforce Pool Editor " tabindex="-1">IAM Workforce Pool Editor</h4>
<p>(<code translate="no" dir="ltr">roles/iam.workforcePoolEditor</code>)</p>
<span class="role-description"> </span>
<p>Gives permission to edit workforce pools.</p>
<p>Lowest-level resources where you can grant this role:</p>
<ul>
<li>Workforce pool</li>
</ul></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderKeys.get</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderKeys.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.get</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.update</code></p>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iam.workforcePoolProviders.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviders.computeUserAttributes</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviders.create</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviders.delete</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviders.get</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviders.list</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviders.undelete</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviders.update</code></li>
</ul></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="iam.workforcePoolViewer" class="role-title add-link" data-text="IAM Workforce Pool Viewer " tabindex="-1">IAM Workforce Pool Viewer</h4>
<p>(<code translate="no" dir="ltr">roles/iam.workforcePoolViewer</code>)</p>
<span class="role-description"> </span>
<p>Rights to read workforce pool.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderKeys.get</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderKeys.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviders.computeUserAttributes</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviders.get</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviders.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.get</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.list</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="iam.workloadIdentityPoolAdmin" class="role-title add-link" data-text="IAM Workload Identity Pool Admin Beta " tabindex="-1">IAM Workload Identity Pool Admin <sup>Beta</sup></h4>
<p>(<code translate="no" dir="ltr">roles/iam.workloadIdentityPoolAdmin</code>)</p>
<span class="role-description"> </span>
<p>Full rights to create and manage workload identity pools.</p></td>
<td class="role-permissions"><p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iam.workloadIdentityPoolManagedIdentities.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolManagedIdentities.create</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolManagedIdentities.delete</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolManagedIdentities.get</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolManagedIdentities.getAttestationRules</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolManagedIdentities.list</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolManagedIdentities.setAttestationRules</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolManagedIdentities.undelete</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolManagedIdentities.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iam.workloadIdentityPoolNamespaces.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolNamespaces.create</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolNamespaces.delete</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolNamespaces.get</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolNamespaces.list</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolNamespaces.undelete</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolNamespaces.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iam.workloadIdentityPoolProviderKeys.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolProviderKeys.create</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolProviderKeys.delete</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolProviderKeys.get</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolProviderKeys.list</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolProviderKeys.undelete</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iam.workloadIdentityPoolProviders.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolProviders.create</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolProviders.delete</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolProviders.get</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolProviders.list</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolProviders.undelete</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolProviders.update</code></li>
</ul>
<p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iam.workloadIdentityPools.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPools.create</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPools.delete</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPools.get</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPools.getAttestationRules</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPools.getIamPolicy</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPools.list</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPools.setAttestationRules</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPools.setIamPolicy</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPools.undelete</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPools.update</code></li>
<li><code translate="no" dir="ltr">iam.workloadIdentityPools.createPolicyBinding</code></li>
<li><code translate="no" dir="ltr">iam.workloadIdentityPools.deletePolicyBinding</code></li>
<li><code translate="no" dir="ltr">iam.workloadIdentityPools.searchPolicyBindings</code></li>
<li><code translate="no" dir="ltr">iam.workloadIdentityPools.updatePolicyBinding</code></li>
</ul>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="even">
<td class="role-description"><h4 id="iam.workloadIdentityPoolViewer" class="role-title add-link" data-text="IAM Workload Identity Pool Viewer Beta " tabindex="-1">IAM Workload Identity Pool Viewer <sup>Beta</sup></h4>
<p>(<code translate="no" dir="ltr">roles/iam.workloadIdentityPoolViewer</code>)</p>
<span class="role-description"> </span>
<p>Read access to workload identity pools.</p></td>
<td class="role-permissions"><p><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolManagedIdentities.get</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolManagedIdentities.getAttestationRules</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolManagedIdentities.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolNamespaces.get</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolNamespaces.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolProviderKeys.get</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolProviderKeys.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolProviders.get</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolProviders.list</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPools.get</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPools.getAttestationRules</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPools.getIamPolicy</code></p>
<p><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPools.list</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.get</code></p>
<p><code translate="no" dir="ltr">resourcemanager.projects.list</code></p></td>
</tr>
<tr class="odd">
<td class="role-description"><h4 id="iam.workspacePoolAdmin" class="role-title add-link" data-text="Workspace Pool IAM Admin " tabindex="-1">Workspace Pool IAM Admin</h4>
<p>(<code translate="no" dir="ltr">roles/iam.workspacePoolAdmin</code>)</p>
<span class="role-description"> </span>
<p>IAM workspace pool admin able to bind IAM policies to Dasher accounts.</p></td>
<td class="role-permissions"><p><span class="iamperm-wildcard"><code translate="no" dir="ltr">iam.workspacePools.*</code></span></p>
<ul>
<li><code translate="no" dir="ltr">iam.googleapis.com/workspacePools.createPolicyBinding</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workspacePools.deletePolicyBinding</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workspacePools.searchPolicyBindings</code></li>
<li><code translate="no" dir="ltr">iam.googleapis.com/workspacePools.updatePolicyBinding</code></li>
</ul></td>
</tr>
</tbody>
</table>

## Identity and Access Management permissions

<div results-count-container="">

</div>

<table class="permissions-table fixed">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th width="45%">Permission</th>
<th>Included in roles</th>
</tr>
</thead>
<tbody class="list">
<tr class="odd">
<td><h4 id="iam.accesspolicies.bind" class="permission-name add-link" data-text="iam.accesspolicies.bind" tabindex="-1"><code translate="no" dir="ltr">iam.accesspolicies.bind</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.accessPolicyAdmin">Access Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.accessPolicyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.accessPolicyUser">Access Policy User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.accessPolicyUser</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.accesspolicies.create" class="permission-name add-link" data-text="iam.accesspolicies.create" tabindex="-1"><code translate="no" dir="ltr">iam.accesspolicies.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.accessPolicyAdmin">Access Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.accessPolicyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.accesspolicies.delete" class="permission-name add-link" data-text="iam.accesspolicies.delete" tabindex="-1"><code translate="no" dir="ltr">iam.accesspolicies.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.accessPolicyAdmin">Access Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.accessPolicyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.accesspolicies.get" class="permission-name add-link" data-text="iam.accesspolicies.get" tabindex="-1"><code translate="no" dir="ltr">iam.accesspolicies.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.accessPolicyAdmin">Access Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.accessPolicyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.accessPolicyUser">Access Policy User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.accessPolicyUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.accessPolicyViewer">Access Policy Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.accessPolicyViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.accesspolicies.list" class="permission-name add-link" data-text="iam.accesspolicies.list" tabindex="-1"><code translate="no" dir="ltr">iam.accesspolicies.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.accessPolicyAdmin">Access Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.accessPolicyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.accessPolicyUser">Access Policy User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.accessPolicyUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.accessPolicyViewer">Access Policy Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.accessPolicyViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.accesspolicies.searchPolicyBindings" class="permission-name add-link" data-text="iam.accesspolicies.searchPolicyBindings" tabindex="-1"><code translate="no" dir="ltr">iam.accesspolicies.searchPolicyBindings</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.accessPolicyAdmin">Access Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.accessPolicyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.accessPolicyViewer">Access Policy Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.accessPolicyViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.accesspolicies.unbind" class="permission-name add-link" data-text="iam.accesspolicies.unbind" tabindex="-1"><code translate="no" dir="ltr">iam.accesspolicies.unbind</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.accessPolicyAdmin">Access Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.accessPolicyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.accessPolicyUser">Access Policy User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.accessPolicyUser</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.accesspolicies.update" class="permission-name add-link" data-text="iam.accesspolicies.update" tabindex="-1"><code translate="no" dir="ltr">iam.accesspolicies.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.accessPolicyAdmin">Access Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.accessPolicyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.denypolicies.create" class="permission-name add-link" data-text="iam.denypolicies.create" tabindex="-1"><code translate="no" dir="ltr">iam.denypolicies.create</code></h4></td>
<td><p><a href="/iam/docs/roles-permissions/iam#iam.denyAdmin">Deny Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.denyAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.denypolicies.delete" class="permission-name add-link" data-text="iam.denypolicies.delete" tabindex="-1"><code translate="no" dir="ltr">iam.denypolicies.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-permissions/iam#iam.denyAdmin">Deny Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.denyAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.denypolicies.get" class="permission-name add-link" data-text="iam.denypolicies.get" tabindex="-1"><code translate="no" dir="ltr">iam.denypolicies.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.denyAdmin">Deny Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.denyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.denyReviewer">Deny Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.denyReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.controlServiceAgent">Security Center Control Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.controlServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.serviceAgent">Security Center Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="iam.denypolicies.list" class="permission-name add-link" data-text="iam.denypolicies.list" tabindex="-1"><code translate="no" dir="ltr">iam.denypolicies.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.denyAdmin">Deny Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.denyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.denyReviewer">Deny Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.denyReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.controlServiceAgent">Security Center Control Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.controlServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.serviceAgent">Security Center Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="iam.denypolicies.update" class="permission-name add-link" data-text="iam.denypolicies.update" tabindex="-1"><code translate="no" dir="ltr">iam.denypolicies.update</code></h4></td>
<td><p><a href="/iam/docs/roles-permissions/iam#iam.denyAdmin">Deny Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.denyAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.googleapis.com_oauthClientCredentials.create" class="permission-name add-link" data-text="iam.googleapis.com/oauthClientCredentials.create" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/oauthClientCredentials.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.oauthClientAdmin">IAM OAuth Client Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.oauthClientAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.googleapis.com_oauthClientCredentials.delete" class="permission-name add-link" data-text="iam.googleapis.com/oauthClientCredentials.delete" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/oauthClientCredentials.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.oauthClientAdmin">IAM OAuth Client Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.oauthClientAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.googleapis.com_oauthClientCredentials.get" class="permission-name add-link" data-text="iam.googleapis.com/oauthClientCredentials.get" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/oauthClientCredentials.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.oauthClientAdmin">IAM OAuth Client Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.oauthClientAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.oauthClientViewer">IAM OAuth Client Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.oauthClientViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.googleapis.com_oauthClientCredentials.list" class="permission-name add-link" data-text="iam.googleapis.com/oauthClientCredentials.list" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/oauthClientCredentials.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.oauthClientAdmin">IAM OAuth Client Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.oauthClientAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.oauthClientViewer">IAM OAuth Client Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.oauthClientViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.googleapis.com_oauthClientCredentials.update" class="permission-name add-link" data-text="iam.googleapis.com/oauthClientCredentials.update" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/oauthClientCredentials.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.oauthClientAdmin">IAM OAuth Client Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.oauthClientAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.googleapis.com_oauthClients.create" class="permission-name add-link" data-text="iam.googleapis.com/oauthClients.create" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/oauthClients.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.oauthClientAdmin">IAM OAuth Client Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.oauthClientAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.googleapis.com_oauthClients.delete" class="permission-name add-link" data-text="iam.googleapis.com/oauthClients.delete" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/oauthClients.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.oauthClientAdmin">IAM OAuth Client Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.oauthClientAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.googleapis.com_oauthClients.get" class="permission-name add-link" data-text="iam.googleapis.com/oauthClients.get" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/oauthClients.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.oauthClientAdmin">IAM OAuth Client Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.oauthClientAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.oauthClientViewer">IAM OAuth Client Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.oauthClientViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.googleapis.com_oauthClients.list" class="permission-name add-link" data-text="iam.googleapis.com/oauthClients.list" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/oauthClients.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.oauthClientAdmin">IAM OAuth Client Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.oauthClientAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.oauthClientViewer">IAM OAuth Client Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.oauthClientViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.googleapis.com_oauthClients.undelete" class="permission-name add-link" data-text="iam.googleapis.com/oauthClients.undelete" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/oauthClients.undelete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.oauthClientAdmin">IAM OAuth Client Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.oauthClientAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.googleapis.com_oauthClients.update" class="permission-name add-link" data-text="iam.googleapis.com/oauthClients.update" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/oauthClients.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.oauthClientAdmin">IAM OAuth Client Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.oauthClientAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.googleapis.com_workforcePoolProviderKeys.create" class="permission-name add-link" data-text="iam.googleapis.com/workforcePoolProviderKeys.create" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderKeys.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolAdmin">IAM Workforce Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.googleapis.com_workforcePoolProviderKeys.delete" class="permission-name add-link" data-text="iam.googleapis.com/workforcePoolProviderKeys.delete" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderKeys.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolAdmin">IAM Workforce Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.googleapis.com_workforcePoolProviderKeys.get" class="permission-name add-link" data-text="iam.googleapis.com/workforcePoolProviderKeys.get" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderKeys.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolAdmin">IAM Workforce Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolEditor">IAM Workforce Pool Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolViewer">IAM Workforce Pool Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolViewer</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.googleapis.com_workforcePoolProviderKeys.list" class="permission-name add-link" data-text="iam.googleapis.com/workforcePoolProviderKeys.list" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderKeys.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolAdmin">IAM Workforce Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolEditor">IAM Workforce Pool Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolViewer">IAM Workforce Pool Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolViewer</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.googleapis.com_workforcePoolProviderKeys.undelete" class="permission-name add-link" data-text="iam.googleapis.com/workforcePoolProviderKeys.undelete" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderKeys.undelete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolAdmin">IAM Workforce Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.googleapis.com_workforcePoolProviderScimGroups.create" class="permission-name add-link" data-text="iam.googleapis.com/workforcePoolProviderScimGroups.create" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimGroups.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.scimSyncer">SCIM Data Syncer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.scimSyncer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolAdmin">IAM Workforce Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.googleapis.com_workforcePoolProviderScimGroups.delete" class="permission-name add-link" data-text="iam.googleapis.com/workforcePoolProviderScimGroups.delete" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimGroups.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.scimSyncer">SCIM Data Syncer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.scimSyncer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolAdmin">IAM Workforce Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.googleapis.com_workforcePoolProviderScimGroups.get" class="permission-name add-link" data-text="iam.googleapis.com/workforcePoolProviderScimGroups.get" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimGroups.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.scimSyncer">SCIM Data Syncer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.scimSyncer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolAdmin">IAM Workforce Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.googleapis.com_workforcePoolProviderScimGroups.list" class="permission-name add-link" data-text="iam.googleapis.com/workforcePoolProviderScimGroups.list" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimGroups.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.scimSyncer">SCIM Data Syncer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.scimSyncer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolAdmin">IAM Workforce Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.googleapis.com_workforcePoolProviderScimGroups.patch" class="permission-name add-link" data-text="iam.googleapis.com/workforcePoolProviderScimGroups.patch" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimGroups.patch</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.scimSyncer">SCIM Data Syncer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.scimSyncer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolAdmin">IAM Workforce Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.googleapis.com_workforcePoolProviderScimGroups.put" class="permission-name add-link" data-text="iam.googleapis.com/workforcePoolProviderScimGroups.put" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimGroups.put</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.scimSyncer">SCIM Data Syncer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.scimSyncer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolAdmin">IAM Workforce Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.googleapis.com_workforcePoolProviderScimUsers.create" class="permission-name add-link" data-text="iam.googleapis.com/workforcePoolProviderScimUsers.create" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimUsers.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.scimSyncer">SCIM Data Syncer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.scimSyncer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolAdmin">IAM Workforce Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.googleapis.com_workforcePoolProviderScimUsers.delete" class="permission-name add-link" data-text="iam.googleapis.com/workforcePoolProviderScimUsers.delete" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimUsers.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.scimSyncer">SCIM Data Syncer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.scimSyncer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolAdmin">IAM Workforce Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.googleapis.com_workforcePoolProviderScimUsers.get" class="permission-name add-link" data-text="iam.googleapis.com/workforcePoolProviderScimUsers.get" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimUsers.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.scimSyncer">SCIM Data Syncer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.scimSyncer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolAdmin">IAM Workforce Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.googleapis.com_workforcePoolProviderScimUsers.list" class="permission-name add-link" data-text="iam.googleapis.com/workforcePoolProviderScimUsers.list" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimUsers.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.scimSyncer">SCIM Data Syncer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.scimSyncer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolAdmin">IAM Workforce Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.googleapis.com_workforcePoolProviderScimUsers.patch" class="permission-name add-link" data-text="iam.googleapis.com/workforcePoolProviderScimUsers.patch" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimUsers.patch</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.scimSyncer">SCIM Data Syncer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.scimSyncer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolAdmin">IAM Workforce Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.googleapis.com_workforcePoolProviderScimUsers.put" class="permission-name add-link" data-text="iam.googleapis.com/workforcePoolProviderScimUsers.put" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviderScimUsers.put</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.scimSyncer">SCIM Data Syncer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.scimSyncer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolAdmin">IAM Workforce Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.googleapis.com_workforcePoolProviders.computeUserAttributes" class="permission-name add-link" data-text="iam.googleapis.com/workforcePoolProviders.computeUserAttributes" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviders.computeUserAttributes</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolAdmin">IAM Workforce Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolEditor">IAM Workforce Pool Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolViewer">IAM Workforce Pool Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolViewer</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.googleapis.com_workforcePoolProviders.create" class="permission-name add-link" data-text="iam.googleapis.com/workforcePoolProviders.create" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviders.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolAdmin">IAM Workforce Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolEditor">IAM Workforce Pool Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolEditor</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.googleapis.com_workforcePoolProviders.delete" class="permission-name add-link" data-text="iam.googleapis.com/workforcePoolProviders.delete" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviders.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolAdmin">IAM Workforce Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolEditor">IAM Workforce Pool Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolEditor</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.googleapis.com_workforcePoolProviders.get" class="permission-name add-link" data-text="iam.googleapis.com/workforcePoolProviders.get" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviders.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolAdmin">IAM Workforce Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolEditor">IAM Workforce Pool Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolViewer">IAM Workforce Pool Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolViewer</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.googleapis.com_workforcePoolProviders.list" class="permission-name add-link" data-text="iam.googleapis.com/workforcePoolProviders.list" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviders.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolAdmin">IAM Workforce Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolEditor">IAM Workforce Pool Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolViewer">IAM Workforce Pool Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.googleapis.com_workforcePoolProviders.undelete" class="permission-name add-link" data-text="iam.googleapis.com/workforcePoolProviders.undelete" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviders.undelete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolAdmin">IAM Workforce Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolEditor">IAM Workforce Pool Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolEditor</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.googleapis.com_workforcePoolProviders.update" class="permission-name add-link" data-text="iam.googleapis.com/workforcePoolProviders.update" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolProviders.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolAdmin">IAM Workforce Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolEditor">IAM Workforce Pool Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolEditor</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.googleapis.com_workforcePoolSubjects.delete" class="permission-name add-link" data-text="iam.googleapis.com/workforcePoolSubjects.delete" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolSubjects.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolAdmin">IAM Workforce Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.googleapis.com_workforcePoolSubjects.revokeSessions" class="permission-name add-link" data-text="iam.googleapis.com/workforcePoolSubjects.revokeSessions" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolSubjects.revokeSessions</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolAdmin">IAM Workforce Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.googleapis.com_workforcePoolSubjects.undelete" class="permission-name add-link" data-text="iam.googleapis.com/workforcePoolSubjects.undelete" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workforcePoolSubjects.undelete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolAdmin">IAM Workforce Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.googleapis.com_workforcePools.create" class="permission-name add-link" data-text="iam.googleapis.com/workforcePools.create" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolAdmin">IAM Workforce Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.googleapis.com_workforcePools.createPolicyBinding" class="permission-name add-link" data-text="iam.googleapis.com/workforcePools.createPolicyBinding" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.createPolicyBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolAdmin">IAM Workforce Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.googleapis.com_workforcePools.delete" class="permission-name add-link" data-text="iam.googleapis.com/workforcePools.delete" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolAdmin">IAM Workforce Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.googleapis.com_workforcePools.deletePolicyBinding" class="permission-name add-link" data-text="iam.googleapis.com/workforcePools.deletePolicyBinding" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.deletePolicyBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolAdmin">IAM Workforce Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.googleapis.com_workforcePools.get" class="permission-name add-link" data-text="iam.googleapis.com/workforcePools.get" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolAdmin">IAM Workforce Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolEditor">IAM Workforce Pool Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolViewer">IAM Workforce Pool Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolViewer</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.googleapis.com_workforcePools.getIamPolicy" class="permission-name add-link" data-text="iam.googleapis.com/workforcePools.getIamPolicy" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.getIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolAdmin">IAM Workforce Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.googleapis.com_workforcePools.list" class="permission-name add-link" data-text="iam.googleapis.com/workforcePools.list" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolAdmin">IAM Workforce Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolEditor">IAM Workforce Pool Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolEditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolViewer">IAM Workforce Pool Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.googleapis.com_workforcePools.searchPolicyBindings" class="permission-name add-link" data-text="iam.googleapis.com/workforcePools.searchPolicyBindings" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.searchPolicyBindings</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolAdmin">IAM Workforce Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.googleapis.com_workforcePools.setIamPolicy" class="permission-name add-link" data-text="iam.googleapis.com/workforcePools.setIamPolicy" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.setIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolAdmin">IAM Workforce Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.googleapis.com_workforcePools.undelete" class="permission-name add-link" data-text="iam.googleapis.com/workforcePools.undelete" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.undelete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolAdmin">IAM Workforce Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.googleapis.com_workforcePools.update" class="permission-name add-link" data-text="iam.googleapis.com/workforcePools.update" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolAdmin">IAM Workforce Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolEditor">IAM Workforce Pool Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolEditor</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.googleapis.com_workforcePools.updatePolicyBinding" class="permission-name add-link" data-text="iam.googleapis.com/workforcePools.updatePolicyBinding" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workforcePools.updatePolicyBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workforcePoolAdmin">IAM Workforce Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workforcePoolAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.googleapis.com_workloadIdentityPoolManagedIdentities.create" class="permission-name add-link" data-text="iam.googleapis.com/workloadIdentityPoolManagedIdentities.create" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolManagedIdentities.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolAdmin">IAM Workload Identity Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.googleapis.com_workloadIdentityPoolManagedIdentities.delete" class="permission-name add-link" data-text="iam.googleapis.com/workloadIdentityPoolManagedIdentities.delete" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolManagedIdentities.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolAdmin">IAM Workload Identity Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.googleapis.com_workloadIdentityPoolManagedIdentities.get" class="permission-name add-link" data-text="iam.googleapis.com/workloadIdentityPoolManagedIdentities.get" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolManagedIdentities.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolAdmin">IAM Workload Identity Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolViewer">IAM Workload Identity Pool Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolViewer</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.googleapis.com_workloadIdentityPoolManagedIdentities.getAttestationRules" class="permission-name add-link" data-text="iam.googleapis.com/workloadIdentityPoolManagedIdentities.getAttestationRules" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolManagedIdentities.getAttestationRules</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolAdmin">IAM Workload Identity Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolViewer">IAM Workload Identity Pool Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolViewer</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.googleapis.com_workloadIdentityPoolManagedIdentities.list" class="permission-name add-link" data-text="iam.googleapis.com/workloadIdentityPoolManagedIdentities.list" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolManagedIdentities.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolAdmin">IAM Workload Identity Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolViewer">IAM Workload Identity Pool Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolViewer</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.googleapis.com_workloadIdentityPoolManagedIdentities.setAttestationRules" class="permission-name add-link" data-text="iam.googleapis.com/workloadIdentityPoolManagedIdentities.setAttestationRules" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolManagedIdentities.setAttestationRules</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolAdmin">IAM Workload Identity Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.googleapis.com_workloadIdentityPoolManagedIdentities.undelete" class="permission-name add-link" data-text="iam.googleapis.com/workloadIdentityPoolManagedIdentities.undelete" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolManagedIdentities.undelete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolAdmin">IAM Workload Identity Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.googleapis.com_workloadIdentityPoolManagedIdentities.update" class="permission-name add-link" data-text="iam.googleapis.com/workloadIdentityPoolManagedIdentities.update" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolManagedIdentities.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolAdmin">IAM Workload Identity Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.googleapis.com_workloadIdentityPoolNamespaces.create" class="permission-name add-link" data-text="iam.googleapis.com/workloadIdentityPoolNamespaces.create" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolNamespaces.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolAdmin">IAM Workload Identity Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.googleapis.com_workloadIdentityPoolNamespaces.delete" class="permission-name add-link" data-text="iam.googleapis.com/workloadIdentityPoolNamespaces.delete" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolNamespaces.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolAdmin">IAM Workload Identity Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.googleapis.com_workloadIdentityPoolNamespaces.get" class="permission-name add-link" data-text="iam.googleapis.com/workloadIdentityPoolNamespaces.get" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolNamespaces.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolAdmin">IAM Workload Identity Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolViewer">IAM Workload Identity Pool Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolViewer</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.googleapis.com_workloadIdentityPoolNamespaces.list" class="permission-name add-link" data-text="iam.googleapis.com/workloadIdentityPoolNamespaces.list" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolNamespaces.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolAdmin">IAM Workload Identity Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolViewer">IAM Workload Identity Pool Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolViewer</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.googleapis.com_workloadIdentityPoolNamespaces.undelete" class="permission-name add-link" data-text="iam.googleapis.com/workloadIdentityPoolNamespaces.undelete" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolNamespaces.undelete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolAdmin">IAM Workload Identity Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.googleapis.com_workloadIdentityPoolNamespaces.update" class="permission-name add-link" data-text="iam.googleapis.com/workloadIdentityPoolNamespaces.update" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolNamespaces.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolAdmin">IAM Workload Identity Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.googleapis.com_workloadIdentityPoolProviderKeys.create" class="permission-name add-link" data-text="iam.googleapis.com/workloadIdentityPoolProviderKeys.create" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolProviderKeys.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolAdmin">IAM Workload Identity Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.googleapis.com_workloadIdentityPoolProviderKeys.delete" class="permission-name add-link" data-text="iam.googleapis.com/workloadIdentityPoolProviderKeys.delete" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolProviderKeys.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolAdmin">IAM Workload Identity Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.googleapis.com_workloadIdentityPoolProviderKeys.get" class="permission-name add-link" data-text="iam.googleapis.com/workloadIdentityPoolProviderKeys.get" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolProviderKeys.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolAdmin">IAM Workload Identity Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolViewer">IAM Workload Identity Pool Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolViewer</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.googleapis.com_workloadIdentityPoolProviderKeys.list" class="permission-name add-link" data-text="iam.googleapis.com/workloadIdentityPoolProviderKeys.list" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolProviderKeys.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolAdmin">IAM Workload Identity Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolViewer">IAM Workload Identity Pool Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.googleapis.com_workloadIdentityPoolProviderKeys.undelete" class="permission-name add-link" data-text="iam.googleapis.com/workloadIdentityPoolProviderKeys.undelete" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolProviderKeys.undelete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolAdmin">IAM Workload Identity Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.googleapis.com_workloadIdentityPoolProviders.create" class="permission-name add-link" data-text="iam.googleapis.com/workloadIdentityPoolProviders.create" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolProviders.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolAdmin">IAM Workload Identity Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.googleapis.com_workloadIdentityPoolProviders.delete" class="permission-name add-link" data-text="iam.googleapis.com/workloadIdentityPoolProviders.delete" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolProviders.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolAdmin">IAM Workload Identity Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.googleapis.com_workloadIdentityPoolProviders.get" class="permission-name add-link" data-text="iam.googleapis.com/workloadIdentityPoolProviders.get" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolProviders.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolAdmin">IAM Workload Identity Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolViewer">IAM Workload Identity Pool Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolViewer</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.googleapis.com_workloadIdentityPoolProviders.list" class="permission-name add-link" data-text="iam.googleapis.com/workloadIdentityPoolProviders.list" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolProviders.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolAdmin">IAM Workload Identity Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolViewer">IAM Workload Identity Pool Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.controlServiceAgent">Security Center Control Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.controlServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.serviceAgent">Security Center Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="iam.googleapis.com_workloadIdentityPoolProviders.undelete" class="permission-name add-link" data-text="iam.googleapis.com/workloadIdentityPoolProviders.undelete" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolProviders.undelete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolAdmin">IAM Workload Identity Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.googleapis.com_workloadIdentityPoolProviders.update" class="permission-name add-link" data-text="iam.googleapis.com/workloadIdentityPoolProviders.update" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPoolProviders.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolAdmin">IAM Workload Identity Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.googleapis.com_workloadIdentityPools.create" class="permission-name add-link" data-text="iam.googleapis.com/workloadIdentityPools.create" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPools.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolAdmin">IAM Workload Identity Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.googleapis.com_workloadIdentityPools.delete" class="permission-name add-link" data-text="iam.googleapis.com/workloadIdentityPools.delete" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPools.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolAdmin">IAM Workload Identity Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.googleapis.com_workloadIdentityPools.get" class="permission-name add-link" data-text="iam.googleapis.com/workloadIdentityPools.get" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPools.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolAdmin">IAM Workload Identity Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolViewer">IAM Workload Identity Pool Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolViewer</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.googleapis.com_workloadIdentityPools.getAttestationRules" class="permission-name add-link" data-text="iam.googleapis.com/workloadIdentityPools.getAttestationRules" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPools.getAttestationRules</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolAdmin">IAM Workload Identity Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolViewer">IAM Workload Identity Pool Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolViewer</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.googleapis.com_workloadIdentityPools.getIamPolicy" class="permission-name add-link" data-text="iam.googleapis.com/workloadIdentityPools.getIamPolicy" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPools.getIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolAdmin">IAM Workload Identity Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolViewer">IAM Workload Identity Pool Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolViewer</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.googleapis.com_workloadIdentityPools.list" class="permission-name add-link" data-text="iam.googleapis.com/workloadIdentityPools.list" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPools.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolAdmin">IAM Workload Identity Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolViewer">IAM Workload Identity Pool Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.controlServiceAgent">Security Center Control Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.controlServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.serviceAgent">Security Center Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="iam.googleapis.com_workloadIdentityPools.setAttestationRules" class="permission-name add-link" data-text="iam.googleapis.com/workloadIdentityPools.setAttestationRules" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPools.setAttestationRules</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolAdmin">IAM Workload Identity Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.googleapis.com_workloadIdentityPools.setIamPolicy" class="permission-name add-link" data-text="iam.googleapis.com/workloadIdentityPools.setIamPolicy" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPools.setIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolAdmin">IAM Workload Identity Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.googleapis.com_workloadIdentityPools.undelete" class="permission-name add-link" data-text="iam.googleapis.com/workloadIdentityPools.undelete" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPools.undelete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolAdmin">IAM Workload Identity Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.googleapis.com_workloadIdentityPools.update" class="permission-name add-link" data-text="iam.googleapis.com/workloadIdentityPools.update" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workloadIdentityPools.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolAdmin">IAM Workload Identity Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.googleapis.com_workspacePools.createPolicyBinding" class="permission-name add-link" data-text="iam.googleapis.com/workspacePools.createPolicyBinding" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workspacePools.createPolicyBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workspacePoolAdmin">Workspace Pool IAM Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workspacePoolAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.googleapis.com_workspacePools.deletePolicyBinding" class="permission-name add-link" data-text="iam.googleapis.com/workspacePools.deletePolicyBinding" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workspacePools.deletePolicyBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workspacePoolAdmin">Workspace Pool IAM Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workspacePoolAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.googleapis.com_workspacePools.searchPolicyBindings" class="permission-name add-link" data-text="iam.googleapis.com/workspacePools.searchPolicyBindings" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workspacePools.searchPolicyBindings</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workspacePoolAdmin">Workspace Pool IAM Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workspacePoolAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.googleapis.com_workspacePools.updatePolicyBinding" class="permission-name add-link" data-text="iam.googleapis.com/workspacePools.updatePolicyBinding" tabindex="-1"><code translate="no" dir="ltr">iam.googleapis.com/workspacePools.updatePolicyBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workspacePoolAdmin">Workspace Pool IAM Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workspacePoolAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.operations.get" class="permission-name add-link" data-text="iam.operations.get" tabindex="-1"><code translate="no" dir="ltr">iam.operations.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.operationViewer">IAM Operation Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.operationViewer</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.policybindings.get" class="permission-name add-link" data-text="iam.policybindings.get" tabindex="-1"><code translate="no" dir="ltr">iam.policybindings.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderAdmin">Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.organizationAdmin">Organization Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.organizationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.projectIamAdmin">Project IAM Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.projectIamAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderIamAdmin">Folder IAM Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderIamAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.policybindings.list" class="permission-name add-link" data-text="iam.policybindings.list" tabindex="-1"><code translate="no" dir="ltr">iam.policybindings.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderAdmin">Folder Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.organizationAdmin">Organization Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.organizationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.projectIamAdmin">Project IAM Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.projectIamAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.folderIamAdmin">Folder IAM Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.folderIamAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.principalaccessboundarypolicies.bind" class="permission-name add-link" data-text="iam.principalaccessboundarypolicies.bind" tabindex="-1"><code translate="no" dir="ltr">iam.principalaccessboundarypolicies.bind</code></h4></td>
<td><p><a href="/iam/docs/roles-permissions/iam#iam.principalAccessBoundaryAdmin">Principal Access Boundary Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.principalAccessBoundaryAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.principalAccessBoundaryUser">Principal Access Boundary Policy User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.principalAccessBoundaryUser</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.principalaccessboundarypolicies.create" class="permission-name add-link" data-text="iam.principalaccessboundarypolicies.create" tabindex="-1"><code translate="no" dir="ltr">iam.principalaccessboundarypolicies.create</code></h4></td>
<td><p><a href="/iam/docs/roles-permissions/iam#iam.principalAccessBoundaryAdmin">Principal Access Boundary Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.principalAccessBoundaryAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.principalaccessboundarypolicies.delete" class="permission-name add-link" data-text="iam.principalaccessboundarypolicies.delete" tabindex="-1"><code translate="no" dir="ltr">iam.principalaccessboundarypolicies.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-permissions/iam#iam.principalAccessBoundaryAdmin">Principal Access Boundary Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.principalAccessBoundaryAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.principalaccessboundarypolicies.get" class="permission-name add-link" data-text="iam.principalaccessboundarypolicies.get" tabindex="-1"><code translate="no" dir="ltr">iam.principalaccessboundarypolicies.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.principalAccessBoundaryViewer">Principal Access Boundary Policy Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.principalAccessBoundaryViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.principalAccessBoundaryAdmin">Principal Access Boundary Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.principalAccessBoundaryAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.principalAccessBoundaryUser">Principal Access Boundary Policy User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.principalAccessBoundaryUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.principalaccessboundarypolicies.list" class="permission-name add-link" data-text="iam.principalaccessboundarypolicies.list" tabindex="-1"><code translate="no" dir="ltr">iam.principalaccessboundarypolicies.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.principalAccessBoundaryViewer">Principal Access Boundary Policy Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.principalAccessBoundaryViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.principalAccessBoundaryAdmin">Principal Access Boundary Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.principalAccessBoundaryAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.principalAccessBoundaryUser">Principal Access Boundary Policy User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.principalAccessBoundaryUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.principalaccessboundarypolicies.searchPolicyBindings" class="permission-name add-link" data-text="iam.principalaccessboundarypolicies.searchPolicyBindings" tabindex="-1"><code translate="no" dir="ltr">iam.principalaccessboundarypolicies.searchPolicyBindings</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.principalAccessBoundaryViewer">Principal Access Boundary Policy Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.principalAccessBoundaryViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.principalAccessBoundaryAdmin">Principal Access Boundary Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.principalAccessBoundaryAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.principalaccessboundarypolicies.unbind" class="permission-name add-link" data-text="iam.principalaccessboundarypolicies.unbind" tabindex="-1"><code translate="no" dir="ltr">iam.principalaccessboundarypolicies.unbind</code></h4></td>
<td><p><a href="/iam/docs/roles-permissions/iam#iam.principalAccessBoundaryAdmin">Principal Access Boundary Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.principalAccessBoundaryAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.principalAccessBoundaryUser">Principal Access Boundary Policy User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.principalAccessBoundaryUser</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.principalaccessboundarypolicies.update" class="permission-name add-link" data-text="iam.principalaccessboundarypolicies.update" tabindex="-1"><code translate="no" dir="ltr">iam.principalaccessboundarypolicies.update</code></h4></td>
<td><p><a href="/iam/docs/roles-permissions/iam#iam.principalAccessBoundaryAdmin">Principal Access Boundary Policy Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.principalAccessBoundaryAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.roles.create" class="permission-name add-link" data-text="iam.roles.create" tabindex="-1"><code translate="no" dir="ltr">iam.roles.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.roleAdmin">Role Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.roleAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.organizationRoleAdmin">Organization Role Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.organizationRoleAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="iam.roles.createTagBinding" class="permission-name add-link" data-text="iam.roles.createTagBinding" tabindex="-1"><code translate="no" dir="ltr">iam.roles.createTagBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.roleAdmin">Role Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.roleAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.organizationRoleAdmin">Organization Role Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.organizationRoleAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.roles.delete" class="permission-name add-link" data-text="iam.roles.delete" tabindex="-1"><code translate="no" dir="ltr">iam.roles.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.roleAdmin">Role Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.roleAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.organizationRoleAdmin">Organization Role Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.organizationRoleAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="iam.roles.deleteTagBinding" class="permission-name add-link" data-text="iam.roles.deleteTagBinding" tabindex="-1"><code translate="no" dir="ltr">iam.roles.deleteTagBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.roleAdmin">Role Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.roleAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.organizationRoleAdmin">Organization Role Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.organizationRoleAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.roles.get" class="permission-name add-link" data-text="iam.roles.get" tabindex="-1"><code translate="no" dir="ltr">iam.roles.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.roleAdmin">Role Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.roleAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.roleViewer">Role Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.roleViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/accesscontextmanager#accesscontextmanager.vpcScTroubleshooterViewer">VPC Service Controls Troubleshooter Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/accesscontextmanager.vpcScTroubleshooterViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/artifactregistry#artifactregistry.containerRegistryMigrationAdmin">Container Registry -&gt; Artifact Registry Migration Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/artifactregistry.containerRegistryMigrationAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.organizationRoleAdmin">Organization Role Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.organizationRoleAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.organizationRoleViewer">Organization Role Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.organizationRoleViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.orgServiceAgent">Chronicle Organization Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.orgServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.managementServiceAgent">Firebase Service Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.managementServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/privilegedaccessmanager#privilegedaccessmanager.organizationServiceAgent">Privileged Access Manager Organization Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/privilegedaccessmanager.organizationServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/privilegedaccessmanager#privilegedaccessmanager.projectServiceAgent">Privileged Access Manager Project Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/privilegedaccessmanager.projectServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/privilegedaccessmanager#privilegedaccessmanager.serviceAgent">Privileged Access Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/privilegedaccessmanager.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="iam.roles.list" class="permission-name add-link" data-text="iam.roles.list" tabindex="-1"><code translate="no" dir="ltr">iam.roles.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.roleAdmin">Role Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.roleAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.roleViewer">Role Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.roleViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.organizationRoleAdmin">Organization Role Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.organizationRoleAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.organizationRoleViewer">Organization Role Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.organizationRoleViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="iam.roles.listEffectiveTags" class="permission-name add-link" data-text="iam.roles.listEffectiveTags" tabindex="-1"><code translate="no" dir="ltr">iam.roles.listEffectiveTags</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.roleAdmin">Role Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.roleAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.roleViewer">Role Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.roleViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagViewer">Tag Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.organizationRoleAdmin">Organization Role Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.organizationRoleAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.organizationRoleViewer">Organization Role Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.organizationRoleViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.roles.listTagBindings" class="permission-name add-link" data-text="iam.roles.listTagBindings" tabindex="-1"><code translate="no" dir="ltr">iam.roles.listTagBindings</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.roleAdmin">Role Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.roleAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.roleViewer">Role Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.roleViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagViewer">Tag Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.organizationRoleAdmin">Organization Role Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.organizationRoleAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.organizationRoleViewer">Organization Role Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.organizationRoleViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.roles.undelete" class="permission-name add-link" data-text="iam.roles.undelete" tabindex="-1"><code translate="no" dir="ltr">iam.roles.undelete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.roleAdmin">Role Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.roleAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.organizationRoleAdmin">Organization Role Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.organizationRoleAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.roles.update" class="permission-name add-link" data-text="iam.roles.update" tabindex="-1"><code translate="no" dir="ltr">iam.roles.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.roleAdmin">Role Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.roleAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.organizationRoleAdmin">Organization Role Administrator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.organizationRoleAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="iam.serviceAccountApiKeyBindings.create" class="permission-name add-link" data-text="iam.serviceAccountApiKeyBindings.create" tabindex="-1"><code translate="no" dir="ltr">iam.serviceAccountApiKeyBindings.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountAdmin">Service Account Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountApiKeyBindingAdmin">Service Account API Key Binding Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountApiKeyBindingAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.serviceAccountApiKeyBindings.delete" class="permission-name add-link" data-text="iam.serviceAccountApiKeyBindings.delete" tabindex="-1"><code translate="no" dir="ltr">iam.serviceAccountApiKeyBindings.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountAdmin">Service Account Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountApiKeyBindingAdmin">Service Account API Key Binding Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountApiKeyBindingAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.serviceAccountApiKeyBindings.undelete" class="permission-name add-link" data-text="iam.serviceAccountApiKeyBindings.undelete" tabindex="-1"><code translate="no" dir="ltr">iam.serviceAccountApiKeyBindings.undelete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountAdmin">Service Account Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountApiKeyBindingAdmin">Service Account API Key Binding Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountApiKeyBindingAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.serviceAccountKeys.create" class="permission-name add-link" data-text="iam.serviceAccountKeys.create" tabindex="-1"><code translate="no" dir="ltr">iam.serviceAccountKeys.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountKeyAdmin">Service Account Key Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountKeyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.serviceAccountKeys.delete" class="permission-name add-link" data-text="iam.serviceAccountKeys.delete" tabindex="-1"><code translate="no" dir="ltr">iam.serviceAccountKeys.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountKeyAdmin">Service Account Key Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountKeyAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="iam.serviceAccountKeys.disable" class="permission-name add-link" data-text="iam.serviceAccountKeys.disable" tabindex="-1"><code translate="no" dir="ltr">iam.serviceAccountKeys.disable</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountKeyAdmin">Service Account Key Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountKeyAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.serviceAccountKeys.enable" class="permission-name add-link" data-text="iam.serviceAccountKeys.enable" tabindex="-1"><code translate="no" dir="ltr">iam.serviceAccountKeys.enable</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountKeyAdmin">Service Account Key Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountKeyAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.serviceAccountKeys.get" class="permission-name add-link" data-text="iam.serviceAccountKeys.get" tabindex="-1"><code translate="no" dir="ltr">iam.serviceAccountKeys.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountKeyAdmin">Service Account Key Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountKeyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountViewer">View Service Accounts</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="iam.serviceAccountKeys.list" class="permission-name add-link" data-text="iam.serviceAccountKeys.list" tabindex="-1"><code translate="no" dir="ltr">iam.serviceAccountKeys.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountKeyAdmin">Service Account Key Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountKeyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountViewer">View Service Accounts</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.serviceAgent">Audit Manager Auditing Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.serviceAgent">Cloud Security Compliance Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="iam.serviceAccounts.actAs" class="permission-name add-link" data-text="iam.serviceAccounts.actAs" tabindex="-1"><code translate="no" dir="ltr">iam.serviceAccounts.actAs</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountUser">Service Account User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/backupdr#backupdr.computeEngineOperator">Backup and DR Compute Engine Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/backupdr.computeEngineOperator</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.hubAgent">Dataproc Hub Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.hubAgent</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.colabServiceAgent">Vertex AI Colab Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.colabServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengineflex#appengineflex.serviceAgent">App Engine flexible environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengineflex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/backupdr#backupdr.serviceAgent">Backup and DR Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/backupdr.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/batch#batch.serviceAgent">Google Batch Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/batch.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudconfig#cloudconfig.serviceAgent">Infrastructure Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudconfig.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/clouddeploy#clouddeploy.serviceAgent">Cloud Deploy Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploy.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/tpu#cloudtpu.serviceAgent">Cloud TPU V2 API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtpu.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/compute#compute.instanceGroupManagerServiceAgent">Instance Group Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.instanceGroupManagerServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/compute#compute.serviceAgent">Compute Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/configdelivery#configdelivery.serviceAgent">Config Delivery Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/configdelivery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataplex#dataplex.serviceAgent">Cloud Dataplex Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataplex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/eventarc#eventarc.serviceAgent">Eventarc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/eventarc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebaseapphosting#firebaseapphosting.serviceAgent">Firebase App Hosting Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebaseapphosting.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasemods#firebasemods.serviceAgent">Firebase Extensions API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasemods.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/gameservices#gameservices.serviceAgent">Game Services Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/gameservices.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/lifesciences#genomics.serviceAgent">Genomics Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/genomics.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.serviceAgent">Cluster Director Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/krmapihosting#krmapihosting.anthosApiEndpointServiceAgent">KRM API Hosting AnthosApiEndpoint Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/krmapihosting.anthosApiEndpointServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/krmapihosting#krmapihosting.serviceAgent">KRM API Hosting Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/krmapihosting.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/lifesciences#lifesciences.serviceAgent">Cloud Life Sciences Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/lifesciences.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/notebooks#notebooks.serviceAgent">AI Platform Notebooks Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/osconfig#osconfig.serviceAgent">Cloud OS Config Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/osconfig.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/runapps#runapps.serviceAgent">Serverless Integrations Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/runapps.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.securityResponseServiceAgent">Google Cloud Security Response Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.securityResponseServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/workstations#workstations.serviceAgent">Workstations Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/workstations.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="iam.serviceAccounts.create" class="permission-name add-link" data-text="iam.serviceAccounts.create" tabindex="-1"><code translate="no" dir="ltr">iam.serviceAccounts.create</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountAdmin">Service Account Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountCreator">Create Service Accounts</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountCreator</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.projectAdmin">Assured OSS Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.projectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/earthengine#earthengine.appsPublisher">Earth Engine Apps Publisher</a> (<code class="role-name" translate="no" dir="ltr">roles/earthengine.appsPublisher</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.managementServiceAgent">Firebase Service Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.managementServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasemods#firebasemods.serviceAgent">Firebase Extensions API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasemods.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="iam.serviceAccounts.createTagBinding" class="permission-name add-link" data-text="iam.serviceAccounts.createTagBinding" tabindex="-1"><code translate="no" dir="ltr">iam.serviceAccounts.createTagBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountAdmin">Service Account Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.serviceAccounts.delete" class="permission-name add-link" data-text="iam.serviceAccounts.delete" tabindex="-1"><code translate="no" dir="ltr">iam.serviceAccounts.delete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountAdmin">Service Account Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountDeleter">Delete Service Accounts</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountDeleter</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="iam.serviceAccounts.deleteTagBinding" class="permission-name add-link" data-text="iam.serviceAccounts.deleteTagBinding" tabindex="-1"><code translate="no" dir="ltr">iam.serviceAccounts.deleteTagBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountAdmin">Service Account Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.serviceAccounts.disable" class="permission-name add-link" data-text="iam.serviceAccounts.disable" tabindex="-1"><code translate="no" dir="ltr">iam.serviceAccounts.disable</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountAdmin">Service Account Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/earthengine#earthengine.appsPublisher">Earth Engine Apps Publisher</a> (<code class="role-name" translate="no" dir="ltr">roles/earthengine.appsPublisher</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.soarServiceAgent">Chronicle SOAR Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.soarServiceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="iam.serviceAccounts.enable" class="permission-name add-link" data-text="iam.serviceAccounts.enable" tabindex="-1"><code translate="no" dir="ltr">iam.serviceAccounts.enable</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountAdmin">Service Account Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/earthengine#earthengine.appsPublisher">Earth Engine Apps Publisher</a> (<code class="role-name" translate="no" dir="ltr">roles/earthengine.appsPublisher</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.serviceAccounts.get" class="permission-name add-link" data-text="iam.serviceAccounts.get" tabindex="-1"><code translate="no" dir="ltr">iam.serviceAccounts.get</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.admin">Assured OSS Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountAdmin">Service Account Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountCreator">Create Service Accounts</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountCreator</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountKeyAdmin">Service Account Key Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountKeyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountTokenCreator">Service Account Token Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountTokenCreator</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountUser">Service Account User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountViewer">View Service Accounts</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityUser">Workload Identity User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/securitycenter#securitycenter.admin">Security Center Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/securitycenter.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/workstations#workstations.admin">Cloud Workstations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workstations.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/assuredoss#assuredoss.projectAdmin">Assured OSS Project Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/assuredoss.projectAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/backupdr#backupdr.computeEngineOperator">Backup and DR Compute Engine Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/backupdr.computeEngineOperator</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudmigration#cloudmigration.inframanager">Velostrata Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudmigration.inframanager</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.hubAgent">Dataproc Hub Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.hubAgent</code>)</p>
<p><a href="/iam/docs/roles-permissions/earthengine#earthengine.appsPublisher">Earth Engine Apps Publisher</a> (<code class="role-name" translate="no" dir="ltr">roles/earthengine.appsPublisher</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountDeleter">Delete Service Accounts</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountDeleter</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.customCodeServiceAgent">Vertex AI Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.customCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/apigateway#apigateway_management.serviceAgent">Cloud API Gateway Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway_management.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengineflex#appengineflex.serviceAgent">App Engine flexible environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengineflex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.serviceAgent">Audit Manager Auditing Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/backupdr#backupdr.serviceAgent">Backup and DR Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/backupdr.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.serviceAgent">Cloud Security Compliance Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/tpu#cloudtpu.serviceAgent">Cloud TPU V2 API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtpu.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/container#container.serviceAgent">Kubernetes Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/container.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.managementServiceAgent">Firebase Service Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.managementServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasemods#firebasemods.serviceAgent">Firebase Extensions API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasemods.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/notebooks#notebooks.serviceAgent">AI Platform Notebooks Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/pubsub#pubsub.serviceAgent">Cloud Pub/Sub Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/workflows#workflows.serviceAgent">Cloud Workflows Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/workflows.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/workstations#workstations.serviceAgent">Workstations Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/workstations.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="iam.serviceAccounts.getAccessToken" class="permission-name add-link" data-text="iam.serviceAccounts.getAccessToken" tabindex="-1"><code translate="no" dir="ltr">iam.serviceAccounts.getAccessToken</code></h4></td>
<td><p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountTokenCreator">Service Account Token Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountTokenCreator</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityUser">Workload Identity User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityUser</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.customCodeServiceAgent">Vertex AI Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.customCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.extensionServiceAgent">Vertex AI Extension Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.extensionServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/apigateway#apigateway.serviceAgent">Cloud API Gateway Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/apigee#apigee.serviceAgent">Apigee Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAgent">App Engine Standard Environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengineflex#appengineflex.serviceAgent">App Engine flexible environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengineflex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/bigquerycontinuousquery#bigquerycontinuousquery.serviceAgent">BigQuery Continuous Query Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerycontinuousquery.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/bigquerydatatransfer#bigquerydatatransfer.serviceAgent">BigQuery Data Transfer Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/bigquerydatatransfer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/bigqueryspark#bigqueryspark.serviceAgent">BigQuery Spark Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/bigqueryspark.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudconfig#cloudconfig.serviceAgent">Infrastructure Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudconfig.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/clouddeploy#clouddeploy.serviceAgent">Cloud Deploy Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploy.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.serviceAgent">Cloud Scheduler Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.serviceAgent">Cloud Tasks Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/compute#compute.serviceAgent">Compute Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/connectors#connectors.serviceAgent">Connectors Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/connectors.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataproc#dataproc.serviceAgent">Dataproc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/eventarc#eventarc.serviceAgent">Eventarc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/eventarc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/hypercomputecluster#hypercomputecluster.serviceAgent">Cluster Director Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/hypercomputecluster.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/integrations#integrations.serviceAgent">Application Integration Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/notebooks#notebooks.serviceAgent">AI Platform Notebooks Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/pubsub#pubsub.serviceAgent">Cloud Pub/Sub Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/source#sourcerepo.serviceAgent">Cloud Source Repositories Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/sourcerepo.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/workflows#workflows.serviceAgent">Cloud Workflows Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/workflows.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="iam.serviceAccounts.getIamPolicy" class="permission-name add-link" data-text="iam.serviceAccounts.getIamPolicy" tabindex="-1"><code translate="no" dir="ltr">iam.serviceAccounts.getIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountAdmin">Service Account Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountViewer">View Service Accounts</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.ServiceAgentV2Ext">Cloud Composer v2 API Service Agent Extension</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.ServiceAgentV2Ext</code>)</p>
<p><a href="/iam/docs/roles-permissions/earthengine#earthengine.appsPublisher">Earth Engine Apps Publisher</a> (<code class="role-name" translate="no" dir="ltr">roles/earthengine.appsPublisher</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/auditmanager#auditmanager.serviceAgent">Audit Manager Auditing Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/auditmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudsecuritycompliance#cloudsecuritycompliance.serviceAgent">Cloud Security Compliance Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudsecuritycompliance.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="iam.serviceAccounts.getOpenIdToken" class="permission-name add-link" data-text="iam.serviceAccounts.getOpenIdToken" tabindex="-1"><code translate="no" dir="ltr">iam.serviceAccounts.getOpenIdToken</code></h4></td>
<td><p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountTokenCreator">Service Account Token Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountTokenCreator</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityUser">Workload Identity User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountOpenIdTokenCreator">Service Account OpenID Connect Identity Token Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountOpenIdTokenCreator</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.customCodeServiceAgent">Vertex AI Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.customCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.extensionServiceAgent">Vertex AI Extension Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.extensionServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.serviceAgent">Vertex AI Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/apigateway#apigateway.serviceAgent">Cloud API Gateway Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/apigateway.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/apigee#apigee.serviceAgent">Apigee Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/apigee.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAgent">App Engine Standard Environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudbuild#cloudbuild.serviceAgent">Cloud Build Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudbuild.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudscheduler#cloudscheduler.serviceAgent">Cloud Scheduler Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudscheduler.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudtasks#cloudtasks.serviceAgent">Cloud Tasks Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtasks.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/compute#compute.serviceAgent">Compute Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/connectors#connectors.serviceAgent">Connectors Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/connectors.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/eventarc#eventarc.serviceAgent">Eventarc Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/eventarc.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/integrations#integrations.serviceAgent">Application Integration Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/integrations.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/pubsub#pubsub.serviceAgent">Cloud Pub/Sub Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/workflows#workflows.serviceAgent">Cloud Workflows Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/workflows.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="iam.serviceAccounts.implicitDelegation" class="permission-name add-link" data-text="iam.serviceAccounts.implicitDelegation" tabindex="-1"><code translate="no" dir="ltr">iam.serviceAccounts.implicitDelegation</code></h4></td>
<td><p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountTokenCreator">Service Account Token Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountTokenCreator</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.customCodeServiceAgent">Vertex AI Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.customCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/compute#compute.serviceAgent">Compute Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/connectors#connectors.serviceAgent">Connectors Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/connectors.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/pubsub#pubsub.serviceAgent">Cloud Pub/Sub Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="iam.serviceAccounts.list" class="permission-name add-link" data-text="iam.serviceAccounts.list" tabindex="-1"><code translate="no" dir="ltr">iam.serviceAccounts.list</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudjobdiscovery#cloudjobdiscovery.admin">Cloud Talent Solution Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudjobdiscovery.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityReviewer">Security Reviewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityReviewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountAdmin">Service Account Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountCreator">Create Service Accounts</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountCreator</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountKeyAdmin">Service Account Key Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountKeyAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountTokenCreator">Service Account Token Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountTokenCreator</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountUser">Service Account User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountViewer">View Service Accounts</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityUser">Workload Identity User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.admin">Workload Manager Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/workstations#workstations.admin">Cloud Workstations Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workstations.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/backupdr#backupdr.computeEngineOperator">Backup and DR Compute Engine Operator</a> (<code class="role-name" translate="no" dir="ltr">roles/backupdr.computeEngineOperator</code>)</p>
<p><a href="/iam/docs/roles-permissions/cloudmigration#cloudmigration.inframanager">Velostrata Manager</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudmigration.inframanager</code>)</p>
<p><a href="/iam/docs/roles-permissions/dataproc#dataproc.hubAgent">Dataproc Hub Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataproc.hubAgent</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.dataScientist">Data Scientist</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.dataScientist</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.databasesAdmin">Databases Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.databasesAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountDeleter">Delete Service Accounts</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountDeleter</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/wiz#wiz.cloudInventoryViewer">Wiz Cloud Inventory Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/wiz.cloudInventoryViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/workloadmanager#workloadmanager.deploymentAdmin">Workload Manager Deployment Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/workloadmanager.deploymentAdmin</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.customCodeServiceAgent">Vertex AI Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.customCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/backupdr#backupdr.serviceAgent">Backup and DR Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/backupdr.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/chronicle#chronicle.soarServiceAgent">Chronicle SOAR Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/chronicle.soarServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/tpu#cloudtpu.serviceAgent">Cloud TPU V2 API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudtpu.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/composer#composer.serviceAgent">Cloud Composer API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/datapipelines#datapipelines.serviceAgent">Datapipelines Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/datapipelines.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataprep#dataprep.serviceAgent">Dataprep Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataprep.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebase#firebase.managementServiceAgent">Firebase Service Management Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebase.managementServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/firebasemods#firebasemods.serviceAgent">Firebase Extensions API Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/firebasemods.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/notebooks#notebooks.serviceAgent">AI Platform Notebooks Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/notebooks.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/pubsub#pubsub.serviceAgent">Cloud Pub/Sub Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/workstations#workstations.serviceAgent">Workstations Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/workstations.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="iam.serviceAccounts.listEffectiveTags" class="permission-name add-link" data-text="iam.serviceAccounts.listEffectiveTags" tabindex="-1"><code translate="no" dir="ltr">iam.serviceAccounts.listEffectiveTags</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountAdmin">Service Account Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountViewer">View Service Accounts</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagViewer">Tag Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.serviceAccounts.listTagBindings" class="permission-name add-link" data-text="iam.serviceAccounts.listTagBindings" tabindex="-1"><code translate="no" dir="ltr">iam.serviceAccounts.listTagBindings</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountAdmin">Service Account Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountViewer">View Service Accounts</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagUser">Tag User</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/resourcemanager#resourcemanager.tagViewer">Tag Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/resourcemanager.tagViewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.orgdriver">DLP Organization Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.orgdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/dlp#dlp.projectdriver">DLP Project Data Profiles Driver</a> (<code class="role-name" translate="no" dir="ltr">roles/dlp.projectdriver</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.securityAuditor">Security Auditor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAuditor</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.serviceAccounts.setIamPolicy" class="permission-name add-link" data-text="iam.serviceAccounts.setIamPolicy" tabindex="-1"><code translate="no" dir="ltr">iam.serviceAccounts.setIamPolicy</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.securityAdmin">Security Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.securityAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountAdmin">Service Account Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/composer#composer.ServiceAgentV2Ext">Cloud Composer v2 API Service Agent Extension</a> (<code class="role-name" translate="no" dir="ltr">roles/composer.ServiceAgentV2Ext</code>)</p>
<p><a href="/iam/docs/roles-permissions/earthengine#earthengine.appsPublisher">Earth Engine Apps Publisher</a> (<code class="role-name" translate="no" dir="ltr">roles/earthengine.appsPublisher</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.serviceAccounts.signBlob" class="permission-name add-link" data-text="iam.serviceAccounts.signBlob" tabindex="-1"><code translate="no" dir="ltr">iam.serviceAccounts.signBlob</code></h4></td>
<td><p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountTokenCreator">Service Account Token Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountTokenCreator</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.customCodeServiceAgent">Vertex AI Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.customCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengine#appengine.serviceAgent">App Engine Standard Environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengine.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengineflex#appengineflex.serviceAgent">App Engine flexible environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengineflex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/cloudfunctions#cloudfunctions.serviceAgent">(Deprecated) Cloud Functions Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/cloudfunctions.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/pubsub#pubsub.serviceAgent">Cloud Pub/Sub Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/run#run.serviceAgent">Cloud Run Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/run.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="even">
<td><h4 id="iam.serviceAccounts.signJwt" class="permission-name add-link" data-text="iam.serviceAccounts.signJwt" tabindex="-1"><code translate="no" dir="ltr">iam.serviceAccounts.signJwt</code></h4></td>
<td><p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountTokenCreator">Service Account Token Creator</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountTokenCreator</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/aiplatform#aiplatform.customCodeServiceAgent">Vertex AI Custom Code Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/aiplatform.customCodeServiceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/appengineflex#appengineflex.serviceAgent">App Engine flexible environment Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/appengineflex.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/compute#compute.serviceAgent">Compute Engine Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/compute.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/dataflow#dataflow.serviceAgent">Cloud Dataflow Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/dataflow.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/ml#ml.serviceAgent">AI Platform Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/ml.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/pubsub#pubsub.serviceAgent">Cloud Pub/Sub Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/pubsub.serviceAgent</code>)</li>
<li><a href="/iam/docs/roles-permissions/securesourcemanager#securesourcemanager.serviceAgent">Secure Source Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/securesourcemanager.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="iam.serviceAccounts.undelete" class="permission-name add-link" data-text="iam.serviceAccounts.undelete" tabindex="-1"><code translate="no" dir="ltr">iam.serviceAccounts.undelete</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountAdmin">Service Account Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.serviceAccounts.update" class="permission-name add-link" data-text="iam.serviceAccounts.update" tabindex="-1"><code translate="no" dir="ltr">iam.serviceAccounts.update</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.serviceAccountAdmin">Service Account Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.serviceAccountAdmin</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.devOps">Dev Ops</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.devOps</code>)</p>
<p><span class="serviceagentrole">Service agent roles</span></p>
<strong>Warning:</strong> Don't grant service agent roles to any principals except <a href="/iam/docs/service-agents">service agents</a>.
<ul>
<li><a href="/iam/docs/roles-permissions/deploymentmanager#clouddeploymentmanager.serviceAgent">Cloud Deployment Manager Service Agent</a> (<code class="role-name" translate="no" dir="ltr">roles/clouddeploymentmanager.serviceAgent</code>)</li>
</ul></td>
</tr>
<tr class="odd">
<td><h4 id="iam.workloadIdentityPools.createPolicyBinding" class="permission-name add-link" data-text="iam.workloadIdentityPools.createPolicyBinding" tabindex="-1"><code translate="no" dir="ltr">iam.workloadIdentityPools.createPolicyBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolAdmin">IAM Workload Identity Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.workloadIdentityPools.deletePolicyBinding" class="permission-name add-link" data-text="iam.workloadIdentityPools.deletePolicyBinding" tabindex="-1"><code translate="no" dir="ltr">iam.workloadIdentityPools.deletePolicyBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolAdmin">IAM Workload Identity Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolAdmin</code>)</p></td>
</tr>
<tr class="odd">
<td><h4 id="iam.workloadIdentityPools.searchPolicyBindings" class="permission-name add-link" data-text="iam.workloadIdentityPools.searchPolicyBindings" tabindex="-1"><code translate="no" dir="ltr">iam.workloadIdentityPools.searchPolicyBindings</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Writer</a> (<code class="role-name" translate="no" dir="ltr">roles/writer</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/editor</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Reader</a> (<code class="role-name" translate="no" dir="ltr">roles/reader</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.editor">Iam Editor</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.editor</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.viewer">Iam Viewer</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.viewer</code>)</p>
<p><a href="/iam/docs/roles-permissions/jobfunctions#iam.supportUser">Support User</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.supportUser</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolAdmin">IAM Workload Identity Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolAdmin</code>)</p></td>
</tr>
<tr class="even">
<td><h4 id="iam.workloadIdentityPools.updatePolicyBinding" class="permission-name add-link" data-text="iam.workloadIdentityPools.updatePolicyBinding" tabindex="-1"><code translate="no" dir="ltr">iam.workloadIdentityPools.updatePolicyBinding</code></h4></td>
<td><p><a href="/iam/docs/roles-overview#basic">Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/admin</code>)</p>
<p><a href="/iam/docs/roles-overview#basic">Owner</a> (<code class="role-name" translate="no" dir="ltr">roles/owner</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.admin">Iam Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.admin</code>)</p>
<p><a href="/iam/docs/roles-permissions/iam#iam.workloadIdentityPoolAdmin">IAM Workload Identity Pool Admin</a> (<code class="role-name" translate="no" dir="ltr">roles/iam.workloadIdentityPoolAdmin</code>)</p></td>
</tr>
</tbody>
</table>

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
