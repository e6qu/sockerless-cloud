# Debugging Functions Reference

<div class="devsite-article-body clearfix devsite-no-page-title">

# Debugging Functions Reference

## **Debugging Functions**

|                           |                                                                             |
|---------------------------|-----------------------------------------------------------------------------|
| Name                      | Description                                                                 |
| [`EXISTS`](#exists)       | Returns `TRUE` if the value is not an absent value                          |
| [`IS_ABSENT`](#is_absent) | Returns `TRUE` if the value is an absent value                              |
| [`IF_ABSENT`](#if_absent) | Replaces the value with an expression if it is absent                       |
| [`IS_ERROR`](#is_error)   | Catches and checks if an error has been thrown by the underlying expression |
| [`IF_ERROR`](#if_error)   | Replaces the value with an expression if it has thrown an error             |
| [`ERROR`](#error)         | Terminates evaluation and returns an error with the specified message       |

### EXISTS

**Syntax:**

<div>

</div>

``` devsite-click-to-copy
exists(value: ANY) -> BOOLEAN
```

**Description:**

Returns `TRUE` if `value` is not the absent value.

**Examples:**

| `value`  | `exists(value)` |
|:---------|:----------------|
| 0L       | `TRUE`          |
| "foo"    | `TRUE`          |
| `NULL`   | `TRUE`          |
| `ABSENT` | `FALSE`         |

<div class="ds-selector-tabs" ds-scope="lang">

<div class="section">

##### Node.js

<div>

</div>

``` devsite-click-to-copy
const result = await db.pipeline()
  .collection("books")
  .select(field("rating").exists().as("hasRating"))
  .execute();test.firestore.js
```

</div>

<div class="section">

### <span class="two-line-tab"><span tab-label="modular API"></span>Web</span>

**Example:**

<div>

</div>

``` devsite-click-to-copy
const result = await execute(db.pipeline()
  .collection("books")
  .select(field("rating").exists().as("hasRating"))
);test.firestore.js
```

</div>

<div class="section">

##### Swift

<div>

</div>

``` devsite-click-to-copy
let result = try await db.pipeline()
  .collection("books")
  .select([Field("rating").exists().as("hasRating")])
  .execute()PipelineSnippets.swift
```

</div>

<div class="section">

##### <span class="two-line-tab">Kotlin <span class="firebase-platform-label">Android</span></span>

**Example:**

<div>

</div>

``` devsite-click-to-copy
val result = db.pipeline()
    .collection("books")
    .select(field("rating").exists().alias("hasRating"))
    .execute()DocSnippets.kt
```

</div>

<div class="section">

##### <span class="two-line-tab">Java <span class="firebase-platform-label">Android</span></span>

**Example:**

<div>

</div>

``` devsite-click-to-copy
Task<Pipeline.Snapshot> result = db.pipeline()
    .collection("books")
    .select(field("rating").exists().alias("hasRating"))
    .execute();DocSnippets.java
```

</div>

<div class="section">

##### Python

<div>

</div>

``` devsite-click-to-copy
from google.cloud.firestore_v1.pipeline_expressions import Field

result = (
    client.pipeline()
    .collection("books")
    .select(Field.of("rating").exists().as_("hasRating"))
    .execute()
)firestore_pipelines.py
```

</div>

<div class="section">

##### Java

<div>

</div>

``` devsite-click-to-copy
Pipeline.Snapshot result =
    firestore
        .pipeline()
        .collection("books")
        .select(exists(field("rating")).as("hasRating"))
        .execute()
        .get();PipelineSnippets.java
```

</div>

<div class="section">

##### Go

<div>

</div>

``` devsite-click-to-copy
snapshot := client.Pipeline().
 Collection("books").
 Select(firestore.Fields(
     firestore.FieldExists(firestore.FieldOf("rating")).As("hasRating"),
 )).
 Execute(ctx)pipeline_snippets_logical.go
```

</div>

</div>

### IS_ABSENT

**Syntax:**

<div>

</div>

``` devsite-click-to-copy
is_absent(value: ANY) -> BOOLEAN
```

**Description:**

Returns `TRUE` if `value` is the absent value, and `FALSE` otherwise. Absent values are values that are missing from the input, such as a missing document field.

**Examples:**

| `value`  | `is_absent(value)` |
|:---------|:-------------------|
| 0L       | `FALSE`            |
| "foo"    | `FALSE`            |
| `NULL`   | `FALSE`            |
| `ABSENT` | `TRUE`             |

### IF_ABSENT

**Syntax:**

<div>

</div>

``` devsite-click-to-copy
if_absent(value: ANY, replacement: ANY) -> ANY
```

**Description:**

If `value` is an absent value, evaluates and returns `replacement`. Otherwise returns `value`.

**Examples:**

| `value`  | `replacement` | `if_absent(value, replacement)` |
|:---------|:--------------|:--------------------------------|
| 5L       | 0L            | 5L                              |
| `NULL`   | 0L            | `NULL`                          |
| `ABSENT` | 0L            | 0L                              |

### IS_ERROR

**Syntax:**

<div>

</div>

``` devsite-click-to-copy
is_error(try: ANY) -> BOOLEAN
```

**Description:**

Returns `TRUE` if an error is thrown during the evaluation of `try`. Returns `FALSE` otherwise.

### IF_ERROR

**Syntax:**

<div>

</div>

``` devsite-click-to-copy
if_error(try: ANY, catch: ANY) -> ANY
```

**Description:**

If an error is thrown during the evaluation of `try`, evaluates and returns `replacement`. Otherwise returns the resolved value of `try`.

### ERROR

**Syntax:**

<div>

</div>

``` devsite-click-to-copy
error(message: STRING) -> ANY
```

**Description:**

Evaluation of the `error` function results in the evaluation of the pipeline to terminate with an error. The given `message` is included in the error.

**Examples:**

| `cond`  | `res` | `switch_on(cond, res, error("no condition matched"))` |
|:--------|:------|:------------------------------------------------------|
| `TRUE`  | 1L    | 1L                                                    |
| `FALSE` | 1L    | `ERROR ("no condition matched")`                      |

## What's next

- See the [Pipeline Queries overview](/firestore/docs/pipeline/overview)

</div>

Send feedback

<div class="devsite-floating-action-buttons">

</div>
