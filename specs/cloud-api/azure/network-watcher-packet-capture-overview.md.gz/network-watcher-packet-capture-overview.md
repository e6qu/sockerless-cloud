---
layout: Conceptual
title: Packet Capture Overview - Azure Network Watcher | Microsoft Learn
canonicalUrl: https://learn.microsoft.com/en-us/azure/network-watcher/packet-capture-overview
breadcrumb_path: /azure/bread/toc.json
feedback_help_link_url: https://learn.microsoft.com/answers/tags/183/azure-network-watcher/
feedback_help_link_type: get-help-at-qna
feedback_product_url: https://feedback.azure.com/d365community/forum/8ae9bf04-8326-ec11-b6e6-000d3a4f0789?c=cd276b66-8326-ec11-b6e6-000d3a4f0789
feedback_system: Standard
permissioned-type: public
recommendations: true
recommendation_types:
- Training
- Certification
uhfHeaderId: azure
ms.suite: office
adobe-target: true
author: halkazwini
learn_banner_products:
- azure
manager: kumud
ms.collection: networking
ms.reviewer: halkazwini
description: Learn about Azure Network Watcher packet capture tool, supported resources, available configurations, limits, and considerations.
ms.author: halkazwini
ms.service: azure-network-watcher
ms.topic: concept-article
ms.date: 2026-02-24T00:00:00.0000000Z
locale: en-us
document_id: 3fd2822b-e627-5344-1bdf-87760bee43bf
document_version_independent_id: 0b3053b5-8d15-ffeb-a8ac-f54d923b69aa
updated_at: 2026-10-27T17:14:00.0000000Z
original_content_git_url: https://github.com/MicrosoftDocs/azure-docs-pr/blob/live/articles/network-watcher/packet-capture-overview.md
gitcommit: https://github.com/MicrosoftDocs/azure-docs-pr/blob/608c76b13343ae6c6bfc7a97eb7779dc210ae23c/articles/network-watcher/packet-capture-overview.md
git_commit_id: 608c76b13343ae6c6bfc7a97eb7779dc210ae23c
site_name: Docs
depot_name: Azure.azure-documents
page_type: conceptual
toc_rel: toc.json
pdf_url_template: https://learn.microsoft.com/pdfstore/en-us/Azure.azure-documents/{branchName}{pdfName}
word_count: 874
asset_id: network-watcher/packet-capture-overview
moniker_range_name: 
monikers: []
item_type: Content
source_path: articles/network-watcher/packet-capture-overview.md
cmProducts:
- https://authoring-docs-microsoft.poolparty.biz/devrel/9ab7b147-9278-4652-bbde-e237576868d3
- https://authoring-docs-microsoft.poolparty.biz/devrel/2ed91286-6cf7-4b83-810d-75d0ee3b09dd
spProducts:
- https://authoring-docs-microsoft.poolparty.biz/devrel/ca63c609-701c-447f-92ec-5bd502638556
- https://authoring-docs-microsoft.poolparty.biz/devrel/6735bd7e-4f7b-457d-b58c-29e6f0198677
platformId: 4fc8646a-6364-80a2-af16-52189ead42ec
---

# Packet Capture Overview - Azure Network Watcher | Microsoft Learn

Azure Network Watcher packet capture allows you to create packet capture sessions to track traffic to and from a virtual machine (VM) or a scale set. Packet capture helps to diagnose network anomalies both reactively and proactively. Other uses include gathering network statistics, gaining information on network intrusions, debugging client-server communications, and more.

Packet capture is an extension that is remotely started through Network Watcher. This capability saves time and eases the burden of running a packet capture manually on the desired virtual machine or virtual machine scale set instances.

You can trigger packet captures through the portal, PowerShell, Azure CLI, or REST API. You can also use virtual machine alerts to trigger packet captures. You can choose to save captured data in the local disk or in Azure storage blob.

Important

Packet capture requires the Network Watcher agent VM extension `AzureNetworkWatcherExtension`. For more information, see [Manage Network Watcher Agent VM extension](network-watcher-agent-manage).

## Continuous packet capture

Continuous packet capture allows you to persistently monitor network traffic using a ring buffer–based mechanism. Unlike standard packet captures that stop after reaching a specific time or file size, continuous capture is designed to run over extended durations, making it ideal for diagnosing intermittent or long-tail issues. Currently, you can configure continuous packet capture using the [Azure portal](packet-capture-manage?tabs=portal#start-a-packet-capture).

### How it works

When continuous packet capture is enabled:

- Captured packets are written to a rotating set of files on the target VM's local storage or storage account.
- You can configure the maximum number of files and the size of each file.
- Once the file count limit is reached, the oldest file is automatically deleted to allow space for new packets, maintaining a continuous stream of recent data.
- The capture runs for the user-specified time duration, or a maximum of seven days, whichever is earlier.

This ring buffer–style storage helps reduce manual intervention and avoid excessive storage consumption while ensuring that recent traffic is always available for review.

## Capture configuration

To control the size of captured data, use the following options:

| Property | Description |
| --- | --- |
| **Maximum bytes per packet (bytes)** | The number of bytes from each packet. All bytes are captured if left blank. Enter 34 if you only need to capture IPv4 header. |
| **Time limit per session (seconds)** | Packet capture session time limit. Once the value is reached, the session ends. The default value is 18000 seconds (5 hours). |

If you're using continuous capture (preview), use the following options to control the size of captured data:

| Property | Description |
| --- | --- |
| **Maximum bytes per packet (bytes)** | The number of bytes from each packet. All bytes are captured if left blank or set to 0. Enter 34 if you only need to capture IPv4 header. |
| **New files created** | Total files that can be created. The default value is 10. The maximum value is 10,000. |
| **Bytes per file** | Total number of bytes per file. The default value is 100 MB. The maximum value is 4 GB. |
| **Time limit per session (seconds)** | Packet capture session time limit. Once the value is reached, the session ends. The default value is 86400 seconds (1 day). The maximum value is 604800 seconds (7 days). |

## Filtering (optional)

Use filters to capture only the traffic that you want to monitor. Filters are based on 5-tuple (protocol, local IP address, remote IP address, local port, and remote port) information:

| Property | Description |
| --- | --- |
| **Protocol** | The protocol to filter for the packet capture. The available values are TCP, UDP, and All. |
| **Local IP address** | This value filters the packet capture to packets where the local IP address matches this filter value. |
| **Local port** | This value filters the packet capture to packets where the local port matches this filter value. |
| **Remote IP address** | This value filters the packet capture to packets where the remote IP matches this filter value. |
| **Remote port** | This value filters the packet capture to packets where the remote port matches this filter value. |

## Considerations

- There's a limit of 10,000 parallel packet capture sessions per region per subscription. This limit applies only to the sessions and doesn't apply to the saved packet capture files either locally on the VM or in a storage account. See the [Network Watcher service limits page](../azure-resource-manager/management/azure-subscription-service-limits#azure-network-watcher-limits) for a full list of limits.
- Packet capture uses shared access signature (SAS) tokens to access the storage account. Key access must be enabled on the storage account to authorize packet capture's SAS tokens. If key access isn't enabled, packet captures can only be saved to the virtual machine's local disk.
- When using filters, ensure that relevant ports, IPs, and protocols are captured to optimize storage and analysis.

### Continuous capture considerations

In addition to the previous considerations, keep the following considerations in mind when using continuous packet capture:

- Continuous capture is available only for supported VM and virtual machine scale set SKUs and regions.
- The target VM must have sufficient space, or the connected storage account must have appropriate quota to accommodate capture data.
- Captures with high packet volumes might generate large data sizes quickly. Choose file size and count accordingly to manage buffer length and retention.