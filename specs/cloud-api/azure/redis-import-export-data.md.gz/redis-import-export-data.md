---
layout: Conceptual
title: Import and export data - Azure Cache for Redis | Microsoft Learn
canonicalUrl: https://learn.microsoft.com/en-us/azure/azure-cache-for-redis/cache-how-to-import-export-data
uhfHeaderId: MSDocsHeader-NoSQL
permissioned-type: public
recommendations: true
recommendation_types:
- Training
- Certification
breadcrumb_path: ../breadcrumb/azure-nosql/toc.json
feedback_system: Standard
feedback_product_url: https://feedback.azure.com/d365community/forum/a96a82f3-0c25-ec11-b6e6-000d3a4f07b8
feedback_help_link_url: https://learn.microsoft.com/answers/tags/10/azure-blueprints/
feedback_help_link_type: get-help-at-qna
ms.service: azure-cache-redis
ms.author: sidandrews
author: flang-msft
ms.update-cycle: 1095-days
description: Learn how to import and export data to and from blob storage with your premium Azure Cache for Redis instances.
ms.topic: how-to
ms.custom:
- ignite-2024
ms.date: 2025-04-29T00:00:00.0000000Z
locale: en-us
document_id: 34c5024c-e06a-c4ea-bb22-0a9b8fe1850c
document_version_independent_id: 34c5024c-e06a-c4ea-bb22-0a9b8fe1850c
updated_at: 2026-08-18T17:12:00.0000000Z
original_content_git_url: https://github.com/MicrosoftDocs/nosql-docs-pr/blob/live/azure/azure-cache-for-redis/cache-how-to-import-export-data.md
gitcommit: https://github.com/MicrosoftDocs/nosql-docs-pr/blob/c4a5f38e5b3cb2bba81f50b3b0ea12099b487cd7/azure/azure-cache-for-redis/cache-how-to-import-export-data.md
git_commit_id: c4a5f38e5b3cb2bba81f50b3b0ea12099b487cd7
site_name: Docs
depot_name: Learn.azure-nosql
page_type: conceptual
toc_rel: toc.json
word_count: 2047
asset_id: azure-cache-for-redis/cache-how-to-import-export-data
moniker_range_name: 
monikers: []
item_type: Content
source_path: azure/azure-cache-for-redis/cache-how-to-import-export-data.md
cmProducts:
- https://authoring-docs-microsoft.poolparty.biz/devrel/f80a1aa9-ec39-45c7-bff1-e6916def6921
- https://authoring-docs-microsoft.poolparty.biz/devrel/68ec7f3a-2bc6-459f-b959-19beb729907d
spProducts:
- https://authoring-docs-microsoft.poolparty.biz/devrel/b47bd505-a970-48d0-a7c0-cc58500975e6
- https://authoring-docs-microsoft.poolparty.biz/devrel/90370425-aca4-4a39-9533-d52e5e002a5d
platformId: 36abe33d-2e00-b0dc-e8d1-ba187728a211
---

# Import and export data - Azure Cache for Redis | Microsoft Learn

Important

Azure Cache for Redis announced its retirement timeline for all SKUs. We recommend moving your existing Azure Cache for Redis instances to Azure Managed Redis as soon as you can.

Migration guidance:

- [Migrate Basic, Standard, and Premium tiers to Azure Managed Redis](/en-us/azure/redis/migrate/migrate-basic-standard-premium-overview)
- [Migrate Enterprise tier to Azure Managed Redis](/en-us/azure/redis/migrate/migrate-redis-enterprise-overview)

For more details about the retirement:

- [Azure Cache for Redis Retirement: What to Know and How to Prepare](https://techcommunity.microsoft.com/blog/azure-managed-redis/azure-cache-for-redis-retirement-what-to-know-and-how-to-prepare/4458721)
- [Azure Cache for Redis Retirement FAQ](/en-us/azure/azure-cache-for-redis/retirement-faq)

Azure Cache for Redis import and export functionality imports or exports data to or from Azure Redis cache instances as Redis Database (RDB) snapshots. The snapshots are imported or exported using a blob in an Azure Storage account.

You can use Azure Redis import and export functionality for data management, to migrate between different cache instances, or to populate a cache with data before use. This article describes how to import and export data in Azure Redis, and answers commonly asked questions.

## Scope of availability

| Tier | Basic, Standard | Premium | Enterprise, Enterprise Flash |
| --- | --- | --- | --- |
| Available | No | Yes | Yes |

Import and export are supported in the Premium, Enterprise, and Enterprise Flash tiers.

## Compatibility

**Import**

- You can import your RDB snapshots from either page blobs or block blobs.
- You can import RDB files from Premium tier caches into Enterprise and Enterprise Flash tier caches.
- You can't import from Redis Enterprise and Enterprise Flash tier caches into Premium tier caches.

**Export**

- You can export your snapshots as RDB page blobs in Premium tier, or as `.gz` block blobs in Enterprise tiers.
- Blob storage accounts don't support export.

**Versions**

- Redis 4.0 caches support RDB version 8 and below. Redis 6.0 caches support RDB version 9 and below.
- You can't import exported backups from newer Redis versions like Redis 6.0 into older versions like Redis 4.0.

## Prerequisites

- A Premium, Enterprise, or Enterprise Flash tier cache in Azure Cache for Redis.
- To import files, an RDB file or files uploaded into page or block blobs in Azure Storage, in the same region and subscription as your Azure Redis cache. 
    Note

    If you use managed identity for storage account authentication, the storage account can be in a different subscription.

## Import

You can use import to bring Redis-compatible RDB files from any Redis server running in any cloud or environment, including Linux, Windows, or other cloud providers such as Amazon Web Services. Importing data is an easy way to create a cache with prepopulated data.

During the import process, Azure Redis loads the RDB files from Azure Storage into memory and then inserts the keys into the cache.

Important

Importing data deletes preexisting cache data, and the cache isn't accessible by cache clients during the import process.

Important

Importing from Redis Enterprise tiers to Premium tier isn't supported.

Note

Before importing, ensure that your RDB file or files are uploaded into page or block blobs in Azure Storage. If you follow the Export procedure first, your RDB file is already stored in a page blob and is ready for importing.

1. To import one or more cache blobs, on your Redis cache page in the Azure portal, select **Import data** under **Administration** on the left navigation menu.
2. On the **Import data** page, select an **Authentication Method**, and then select **Choose Blob(s)**.

    ![Screenshot showing the Import data page with Choose Blob(s) selected.](media/cache-how-to-import-export-data/cache-import-data.png)
3. On the **Storage accounts** page, select the storage account that contains the data to import.

    ![Screenshot showing a list of storage accounts.](media/cache-how-to-import-export-data/cache-import-choose-storage-account.png)
4. On the **Containers** page, select the container within the storage account that contains the data to import.

    ![Screenshot showing a list of containers in the storage account.](media/cache-how-to-import-export-data/cache-import-choose-container.png)
5. On the container page, select the checkboxes next to one or more blobs to import, and then select **Select**.

    ![Screenshot that shows selecting blobs from the container. ](media/cache-how-to-import-export-data/cache-import-choose-blobs.png)
6. On the **Import data** page, select **Import** to begin the import process.

    ![Screenshot showing the Import button to select to begin the import.](media/cache-how-to-import-export-data/cache-import-blobs.png)

You can monitor import progress by following the notifications from the Azure portal, or by viewing events in the [Activity log](/en-us/azure/azure-monitor/essentials/activity-log).

![Screenshot showing the import progress in the Notifications pane.](media/cache-how-to-import-export-data/cache-import-data-import-complete.png)

## Export

The export process exports the data stored in your Azure Redis cache to RDB files. You can use this feature to move data from one Azure Redis cache or server to another.

During the export process, a temporary file is created on the virtual machine that hosts the Azure Redis server instance. The file is then uploaded to the chosen storage account. When the export operation completes with either success or failure, the temporary file is deleted.

Important

- Azure Redis doesn't support exporting to Azure Data Lake Storage Gen2 storage accounts.
- Blob storage accounts don't support Azure Redis export.
- Enterprise and Enterprise Flash don't support importing or exporting to or from to storage accounts that use firewalls or private endpoints. The storage account must have public network access.

If your export to a firewall-enabled storage account fails, see What if I have firewall enabled on my storage account? For more information, see [Azure storage account overview](/en-us/azure/storage/common/storage-account-overview).

1. To export the current contents of the cache to storage, on your Redis cache page in the Azure portal, select **Export data** under **Administration** on the left navigation menu.
2. On the **Export data** page, for **Blob name prefix**, enter a prefix for names of files generated by this export operation. Select an **Authentication Method**, and then select **Choose Storage Container**.

    ![Screenshot showing Export data and Choose Storage Container selected.](media/cache-how-to-import-export-data/cache-export-data-choose-account.png)
3. On the **Storage accounts** page, select the storage account that contains the data to export.

    ![Screenshot showing a list of storage accounts.](media/cache-how-to-import-export-data/cache-import-choose-storage-account.png)
4. On the **Containers** page, if you want to create a new container for the export, select **Container**, and on the **New Container** page, enter a name for the container and select **Create**. Otherwise, select the existing container you want to use.

    ![Screenshot showing Export data selected in the Resource menu](media/cache-how-to-import-export-data/cache-export-data-choose-storage-container.png)
5. On the **Containers** page, select the container you want to use for the export, and select **Select**.

    ![Screenshot showing the selected storage container and Select button.](media/cache-how-to-import-export-data/cache-export-data.png)
6. On the **Export data** page, select **Export**.

    ![Screenshot showing the Export button.](media/cache-how-to-import-export-data/cache-export-data-container.png)

You can monitor the progress of the export operation by following the notifications from the Azure portal, or by viewing the events in the [Activity log](/en-us/azure/azure-monitor/essentials/activity-log). Caches remain available for use during the export process.

![Screenshot showing the export progress in the Notification pane.](media/cache-how-to-import-export-data/cache-export-data-export-complete.png)

## Import-export FAQ

This section contains frequently asked questions about the import and export features.

- Can I automate import-export using Azure PowerShell or Azure CLI?
- Can I import data from any Redis server?
- Can I import or export data from a storage account in a different subscription than my cache?
- Can I use import-export with Redis clustering?
- How does import-export work with custom database settings?
- How is import-export different from Redis data persistence?
- Is my cache available during an import-export operation?
- What if I have a firewall enabled on my storage account?
- What RDB versions can I import?
- Which Azure Redis tiers support import-export?
- Which permissions does the storage account container shared access signature (SAS) token need to allow export?
- Why did I get an error when exporting my data to Azure Blob Storage?

### Which tiers support import-export?

The import and export features are available only in the Premium, Enterprise, and Enterprise Flash tiers.

### Can I import data from any Redis server?

Yes, you can import data that was exported from Azure Redis instances. You can import RDB files from any Redis server running in any cloud or environment, including Linux, Windows, or other cloud providers like Amazon Web Services.

To import this data, upload the RDB file from the Redis server into a page or block blob in an Azure Storage account. Then import it into your Azure Redis cache instance.

For example, you might want to export the data from your production cache, and then import it into a cache that's part of a staging environment for testing or migration.

Important

To successfully import page blob data exported from non-Azure Redis servers, the page blob size must be aligned on a 512-byte boundary. For sample code to perform any required byte padding, see [Sample page blob upload](https://github.com/JimRoberts-MS/SamplePageBlobUpload).

### What RDB versions can I import?

For more information on supported RDB versions for import, see Compatibility.

### Is my cache available during an import-export operation?

- Caches remain available during *export*, and you can continue to use your cache during an export operation.
- Caches become unavailable when an *import* operation starts and become available again when the import operation completes.

### Can I use import-export with Redis clustering?

Yes, and you can import and export between a clustered cache and a nonclustered cache. Since Redis cluster [only supports database 0](cache-how-to-scale#do-i-need-to-make-any-changes-to-my-client-application-to-use-clustering), any data in databases other than 0 isn't imported. When clustered cache data is imported, the keys are redistributed among the shards of the cluster.

### How does import-export work with custom database settings?

Some pricing tiers have different [database limits](cache-configure#databases). If you configured a custom value for the `databases` setting during cache creation, there are some considerations when importing.

When you import to a pricing tier with a lower `databases` limit than the tier you exported from:

- If you use the default number of `databases`, which is 16 for all pricing tiers, no data is lost.
- If you use a custom number of `databases` that falls within the limits for the tier you're importing to, no data is lost.
- If your exported data is from a database that exceeds the limits of the new tier, the data from the excess databases isn't imported.

### How is import-export different from Redis data persistence?

The Azure Cache for Redis data persistence feature is primarily for data durability, while the import-export functionality is designed for making periodic data backups for point-in-time recovery (PITR).

When you configure data persistence, your cache persists a snapshot of the data to disk, based on a configurable backup frequency. The data is written with a Redis-proprietary binary format.

On the Premium tier, the data persistence file is stored in Azure Storage, but you can't import the file into a different cache. On the Enterprise tiers, the data persistence file is stored in a mounted disk that isn't user-accessible.

If a catastrophic event disables both the primary and the replica caches, the persisted cache data is restored automatically using the most recent snapshot. Data persistence is designed for disaster recovery, and isn't intended as a PITR mechanism.

To make periodic data backups for PITR, use the import-export functionality. For more information, see [How to configure data persistence for Azure Cache for Redis](cache-how-to-premium-persistence).

### Can I automate import-export using Azure PowerShell or Azure CLI?

Yes. For the Premium tier, see the following content:

- [Import a Premium Azure Redis cache using Azure PowerShell](../redis/how-to-manage-redis-cache-powershell#to-import-an-azure-cache-for-redis)
- [Export a Premium Azure Redis cache using Azure PowerShell](../redis/how-to-manage-redis-cache-powershell#to-export-an-azure-cache-for-redis)
- [Import a Premium Azure Redis cache using Azure CLI](/en-us/cli/azure/redis#az-redis-import)
- [Export a Premium Azure Redis cache using Azure CLI](/en-us/cli/azure/redis#az-redis-export)

For the Enterprise and Enterprise Flash tiers, see the following content:

- [Import an Enterprise Azure Redis cache using Azure PowerShell](/en-us/powershell/module/az.redisenterprisecache/import-azredisenterprisecache)
- [Export an Enterprise Azure Redis cache using Azure PowerShell](/en-us/powershell/module/az.redisenterprisecache/export-azredisenterprisecache)
- [Import an Enterprise Azure Redis cache using Azure CLI](/en-us/cli/azure/redisenterprise/database#az-redisenterprise-database-import)
- [Export an Enterprise Azure Redis cache using Azure CLI](/en-us/cli/azure/redisenterprise/database#az-redisenterprise-database-export)

### Why did I get an error when exporting my data to Azure Blob Storage?

Export works only with RDB files stored as page blobs. Other blob types aren't supported, including blob storage accounts with hot and cool tiers. For more information, see [Azure storage account overview](/en-us/azure/storage/common/storage-account-overview).

If you use an access key to authenticate a storage account, having firewall exceptions on the storage account can cause the import-export processes to fail.

### What if I have firewall enabled on my storage account?

For a Premium tier instance, you must select **Allow Azure services on the trusted services list to access this storage account** in your storage account settings. Then use the system-assigned or user-assigned managed identity and provision the **Storage Blob Data Contributor** role-based access control (RBAC) role for that object ID. For more information, see [Managed identity for storage accounts](cache-managed-identity).

Enterprise and Enterprise Flash instances don't support importing or exporting to or from to storage accounts that use firewalls or private endpoints. The storage account must have public network access.

### Can I import or export data from a storage account in a different subscription than my cache?

In the Premium tier, you can import and export data from a storage account in a different subscription than your cache if you use [managed identity](cache-managed-identity) as the authentication method. You need to select the subscription holding the storage account when you configure the import or export.

### Which permissions need to be granted to the storage account container shared access signature (SAS) token to allow export?

For export to an Azure Storage account to work successfully, the [shared access signature (SAS) token](/en-us/azure/storage/common/storage-sas-overview) must have the following permissions:

- `read`
- `add`
- `create`
- `write`
- `delete`
- `tag`
- `move`