---
layout: Conceptual
title: Manage Packet Captures - Azure Network Watcher | Microsoft Learn
canonicalUrl: https://learn.microsoft.com/en-us/azure/network-watcher/packet-capture-manage
breadcrumb_path: /azure/bread/toc.json
feedback_help_link_url: https://learn.microsoft.com/answers/tags/183/azure-network-watcher/
feedback_help_link_type: get-help-at-qna
feedback_product_url: https://feedback.azure.com/d365community/forum/8ae9bf04-8326-ec11-b6e6-000d3a4f0789?c=cd276b66-8326-ec11-b6e6-000d3a4f0789
feedback_system: Standard
permissioned-type: public
recommendations: true
recommendation_types:
- Training
- Certification
uhfHeaderId: azure
ms.suite: office
adobe-target: true
author: halkazwini
learn_banner_products:
- azure
manager: kumud
ms.collection: networking
ms.reviewer: halkazwini
description: Learn how to start, stop, download, and delete Azure virtual machines packet captures with the packet capture feature of Network Watcher.
ms.author: halkazwini
ms.service: azure-network-watcher
ms.topic: how-to
ms.date: 2026-02-24T00:00:00.0000000Z
locale: en-us
document_id: 0995aacb-a06b-2f6a-265d-09b1ebc09379
document_version_independent_id: 64cb47f8-df56-2400-9be1-f56d29fa0350
updated_at: 2026-10-27T17:14:00.0000000Z
original_content_git_url: https://github.com/MicrosoftDocs/azure-docs-pr/blob/live/articles/network-watcher/packet-capture-manage.md
gitcommit: https://github.com/MicrosoftDocs/azure-docs-pr/blob/c32c6285d9f6c16ff94a113a610c157a33dfca52/articles/network-watcher/packet-capture-manage.md
git_commit_id: c32c6285d9f6c16ff94a113a610c157a33dfca52
site_name: Docs
depot_name: Azure.azure-documents
page_type: conceptual
interactive_type: azurepowershell,azurecli
toc_rel: toc.json
pdf_url_template: https://learn.microsoft.com/pdfstore/en-us/Azure.azure-documents/{branchName}{pdfName}
word_count: 2820
asset_id: network-watcher/packet-capture-manage
moniker_range_name: 
monikers: []
item_type: Content
source_path: articles/network-watcher/packet-capture-manage.md
cmProducts:
- https://authoring-docs-microsoft.poolparty.biz/devrel/9ab7b147-9278-4652-bbde-e237576868d3
- https://authoring-docs-microsoft.poolparty.biz/devrel/2ed91286-6cf7-4b83-810d-75d0ee3b09dd
- https://authoring-docs-microsoft.poolparty.biz/devrel/cdc80360-921e-4b45-947f-2719acf06f23
spProducts:
- https://authoring-docs-microsoft.poolparty.biz/devrel/ca63c609-701c-447f-92ec-5bd502638556
- https://authoring-docs-microsoft.poolparty.biz/devrel/6735bd7e-4f7b-457d-b58c-29e6f0198677
- https://authoring-docs-microsoft.poolparty.biz/devrel/539badf0-028a-4e3e-bda6-770b2552b4d8
platformId: 71cc5d65-6b73-2440-8279-07cb8dd73449
---

# Manage Packet Captures - Azure Network Watcher | Microsoft Learn

In this article, you learn how to use the Azure Network Watcher [packet capture](packet-capture-overview) feature to remotely configure, start, stop, download, and delete packet captures.

## Prerequisites

# [Portal](#tab/portal)
- An Azure account with an active subscription. [Create an account for free](https://azure.microsoft.com/pricing/purchase-options/azure-account?cid=msft_learn).
- A virtual machine (VM) or virtual machine scale set with outbound TCP connectivity to: `169.254.169.254` over port `80` and `168.63.129.16` over port `8037`. The Network Watcher agent VM extension uses these IP addresses to communicate with the Azure platform.
- Network Watcher Agent VM extension installed on the target virtual machine. Whenever you use Network Watcher packet capture in the Azure portal, the agent is automatically installed on the target VM or scale set if it wasn't previously installed. To update an already installed agent, see [Update Network Watcher Agent VM extension](network-watcher-agent-manage#update-network-watcher-agent-vm-extension).
- An Azure storage account with VM outbound TCP connectivity to it over port `443`. If you don't have a storage account, see [Create a storage account using the Azure portal](../storage/common/storage-account-create?tabs=azure-portal&amp;toc=/azure/network-watcher/toc.json).

    - The storage account must be accessible from the subnet of the target virtual machine or scale set. For more information, see [Configure Azure Storage firewalls and virtual networks](../storage/common/storage-network-security?tabs=azure-portal&amp;toc=/azure/network-watcher/toc.json).
    - The storage account key access must be enabled to allow requests from Network Watcher using shared access signature (SAS) tokens.
- Sign in to the [Azure portal](https://portal.azure.com) with your Azure account.

# [PowerShell](#tab/powershell)
- An Azure account with an active subscription. [Create an account for free](https://azure.microsoft.com/pricing/purchase-options/azure-account?cid=msft_learn).
- A virtual machine (VM) with outbound TCP connectivity to: `169.254.169.254` over port `80` and `168.63.129.16` over port `8037`. The Network Watcher agent VM extension uses these IP addresses to communicate with the Azure platform.
- Network Watcher Agent VM extension installed on the target virtual machine. For more information, see [Manage Network Watcher Agent VM extension](network-watcher-agent-manage?tabs=powershell).
- An Azure storage account with VM outbound TCP connectivity to it over port `443`. If you don't have a storage account, see [Create a storage account using PowerShell](../storage/common/storage-account-create?tabs=azure-powershell&amp;toc=/azure/network-watcher/toc.json).

    - The storage account must be accessible from the subnet of the target virtual machine or scale set. For more information, see [Configure Azure Storage firewalls and virtual networks](../storage/common/storage-network-security?tabs=azure-powershell&amp;toc=/azure/network-watcher/toc.json).
    - The storage account key access must be enabled to allow requests from Network Watcher using shared access signature (SAS) tokens.
- Azure Cloud Shell or Azure PowerShell.

    The steps in this article run the Azure PowerShell cmdlets interactively in [Azure Cloud Shell](/en-us/azure/cloud-shell/overview). To run the commands in the Cloud Shell, select **Open Cloud Shell** at the upper-right corner of a code block. Select **Copy** to copy the code and then paste it into Cloud Shell to run it. You can also run the Cloud Shell from within the Azure portal.

    You can also install Azure PowerShell locally to run the cmdlets. This article requires the Az PowerShell module. For more information, see [How to install Azure PowerShell](/en-us/powershell/azure/install-azure-powershell). If you run PowerShell locally, sign in to Azure using the [Connect-AzAccount](/en-us/powershell/module/az.accounts/connect-azaccount) cmdlet.

# [Azure CLI](#tab/cli)
- An Azure account with an active subscription. [Create an account for free](https://azure.microsoft.com/pricing/purchase-options/azure-account?cid=msft_learn).
- A virtual machine (VM) with outbound TCP connectivity to: `169.254.169.254` over port `80` and `168.63.129.16` over port `8037`. The Network Watcher agent VM extension uses these IP addresses to communicate with the Azure platform.
- Network Watcher Agent VM extension installed on the target virtual machine. For more information, see [Manage Network Watcher Agent VM extension](network-watcher-agent-manage?tabs=cli).
- An Azure storage account with VM outbound TCP connectivity to it over port `443`. If you don't have a storage account, see [Create a storage account using the Azure CLI](../storage/common/storage-account-create?tabs=azure-cli&amp;toc=/azure/network-watcher/toc.json).

    - The storage account must be accessible from the subnet of the target virtual machine or scale set. For more information, see [Configure Azure Storage firewalls and virtual networks](../storage/common/storage-network-security?tabs=azure-cli&amp;toc=/azure/network-watcher/toc.json).
    - The storage account key access must be enabled to allow requests from Network Watcher using shared access signature (SAS) tokens.
- Azure Cloud Shell or Azure CLI.

    The steps in this article run the Azure CLI commands interactively in [Azure Cloud Shell](/en-us/azure/cloud-shell/overview). To run the commands in the Cloud Shell, select **Open Cloud Shell** at the upper-right corner of a code block. Select **Copy** to copy the code, and paste it into Cloud Shell to run it. You can also run the Cloud Shell from within the Azure portal.

    You can also [install Azure CLI locally](/en-us/cli/azure/install-azure-cli) to run the commands. If you run Azure CLI locally, sign in to Azure using the [az login](/en-us/cli/azure/reference-index#az-login) command.

---

Note

- Azure creates a Network Watcher instance in the virtual machine's region if Network Watcher wasn't enabled for that region. For more information, see [Enable or disable Azure Network Watcher](network-watcher-create).
- If a network security group is associated to the virtual machine's network interface, or subnet that the network interface is in, ensure that rules exist to allow outbound connectivity. Similarly, ensure outbound connectivity when adding user-defined routes to your network.

## Start a packet capture

# [Portal](#tab/portal)
To start a capture session, use the following steps:

1. In the search box at the top of the portal, enter ***Network Watcher***. Select **Network Watcher** from the search results.

    [![Screenshot shows how to search for Network Watcher in the Azure portal.](media/network-watcher-portal-search.png)](media/network-watcher-portal-search.png#lightbox)
2. Select **Packet capture** under **Network diagnostic tools**, then select **+ Add** to create a packet capture.

    [![Screenshot that shows Network Watcher packet capture in the Azure portal.](media/packet-capture-manage/packet-capture.png)](media/packet-capture-manage/packet-capture.png#lightbox)
3. In **Add packet capture**, enter or select values for the following settings:

    | Setting | Value |
    | --- | --- |
    | **Basic Details** |  |
    | Subscription | Select the Azure subscription of the virtual machine. |
    | Resource group | Select the resource group of the virtual machine. |
    | Target type | Select **Virtual machine** or **Virtual machine scale set**. |
    | Target virtual machine | Select the virtual machine.  This option is available if you select **Virtual machine** as the target type. |
    | Target virtual machine scale set | Select the virtual machine scale set.  This option is available if you select **Virtual machine scale set** as the target type. |
    | Target instance | Select the virtual machine scale set instance.  This option is available if you select **Virtual machine scale set** as the target type. |
    | Packet capture name | Enter a name or leave the default name. |
    | **Packet capture storage** |  |
    | Capture location | Select **in storage account** (default option), **in local file storage**, or **Both**. |
    | Storage accounts | Select your **Standard** storage account^1^.  This option is available if you select **in storage account** or **Both** as the capture location.  The storage account must be in the same region as the target instance. |
    | Local file path | Enter a valid local file path where you want the capture to be saved in the target virtual machine. If you're using a Linux machine, the path can start with `/var/captures`. If you're using a Windows machine, the path can start with `C:\Captures`.  This option is available if you select **in local file storage** or **Both** as the capture location. |
    | **Packet capture configuration** |  |
    | Enable continuous capture^3^ | Select this checkbox to enable continuous packet capture. For more information, see [Continuous packet capture](packet-capture-overview#continuous-packet-capture). |
    | Maximum bytes per packet | Enter the maximum number of bytes to be captured per each packet. All bytes are captured if left blank or 0 entered. |
    | New files created^3^ | Enter the maximum number of files created. The default value is 100 MB and the maximum value is 4 GB.  This option is available if you enable **continuous capture**. |
    | Bytes per file^3^ | Enter the number of bytes per file. Once the value is reached, a new file is created. |
    | Time limit (seconds) | Enter the time limit of the packet capture session in seconds. Once the value is reached the packet capture stops. If left blank:  - Up to 5 hours (18,000 seconds) is captured without enabling continuous capture.  - Up to 1 day (86,400 seconds) is captured if you enable continuous capture. The maximum value is 604,800 seconds (7 days). |
    | **Packet filtering (optional)** |  |
    | Packet filtering | Select **Enable packet filtering** to enable packet filtering. |
    | Add a filter | Select **Add filter criteria** to add a new filter. You can define as many filters as you need. |
    | Protocol | Filters the packet capture based on the selected protocol. Available values are **TCP**, **UDP**, or **Any**. |
    | Local IP address^2^ | Filters the packet capture for packets where the local IP address matches this value. |
    | Local port^2^ | Filters the packet capture for packets where the local port matches this value. |
    | Remote IP address^2^ | Filters the packet capture for packets where the remote IP address matches this value. |
    | Remote port^2^ | Filters the packet capture for packets where the remote port matches this value. |

    ^1^ Premium storage accounts are currently not supported for storing packet captures.

    ^2^ Port and IP address values can be a single value, a range such as 80-1024, or multiple values such as 80, 443.

    ^3^ See [Continuous packet capture](packet-capture-overview#continuous-packet-capture).
4. Select **Start packet capture**.

    [![Screenshot of Add packet capture in the Azure portal showing available options.](media/packet-capture-manage/add-packet-capture.png)](media/packet-capture-manage/add-packet-capture.png#lightbox)
5. The packet capture stops once the time limit is reached.

# [PowerShell](#tab/powershell)
To start a capture session, use [New-AzNetworkWatcherPacketCapture](/en-us/powershell/module/az.network/new-aznetworkwatcherpacketcapture) cmdlet:

```azurepowershell
# Place the virtual machine configuration into a variable.
$vm = Get-AzVM -ResourceGroupName 'myResourceGroup' -Name 'myVM'

# Place the storage account configuration into a variable.
$storageAccount = Get-AzStorageAccount -ResourceGroupName 'myResourceGroup' -Name 'mystorageaccount'

# Start the Network Watcher capture session.
New-AzNetworkWatcherPacketCapture -Location 'eastus' -PacketCaptureName 'myVM_1' -TargetVirtualMachineId $vm.Id  -StorageAccountId $storageAccount.Id 
```

Once the capture session is started, you see the following output:

```output
ProvisioningState Name   BytesToCapturePerPacket TotalBytesPerSession TimeLimitInSeconds
----------------- ----   ----------------------- -------------------- ------------------
Succeeded         myVM_1 0                       1073741824           18000
```

The following table describes the optional parameters that you can use with the [New-AzNetworkWatcherPacketCapture](/en-us/powershell/module/az.network/new-aznetworkwatcherpacketcapture) cmdlet:

| Parameter | description |
| --- | --- |
| `-Filter` | Add filter(s) to capture only the traffic you want. For example, you can capture only TCP traffic from a specific IP address to a specific port. |
| `-TimeLimitInSeconds` | Set the maximum duration of the capture session. The default value is 18000 seconds (5 hours). |
| `-BytesToCapturePerPacket` | Set the maximum number of bytes to be captured per each packet. All bytes are captured if not used or 0 entered. |
| `-TotalBytesPerSession` | Set the total number of bytes that are captured. Once the value is reached the packet capture stops. Up to 1 GB (1,073,741,824 bytes) is captured if not used. |
| `-LocalFilePath` | Enter a valid local file path if you want the capture to be saved in the target virtual machine (For example, C:\Capture\myVM\_1.cap). If you're using a Linux machine, the path must start with /var/captures. |

The packet capture stops once the time limit or the file size (maximum bytes per session) is reached.

# [Azure CLI](#tab/cli)
To start a capture session, use [az network watcher packet-capture create](/en-us/cli/azure/network/watcher/packet-capture#az-network-watcher-packet-capture-create) command:

```azurecli
# Start the Network Watcher capture session.
az network watcher packet-capture create --name 'myVM_1' --resource-group 'myResourceGroup' --vm 'myVM' --storage-account 'mystorageaccount'
```

```azurecli
# Start the Network Watcher capture session (storage account is in different resource group from the VM).
az network watcher packet-capture create --name 'myVM_1' --resource-group 'myResourceGroup' --vm 'myVM' --storage-account '/subscriptions/aaaa0a0a-bb1b-cc2c-dd3d-eeeeee4e4e4e/resourceGroups/myResourceGroup2/providers/Microsoft.Storage/storageAccounts/mystorageaccount'
```

Once the capture session is started, you see the following output:

```output
{
  "bytesToCapturePerPacket": 0,
  "etag": "W/\"aaaaaaaa-0000-1111-2222-bbbbbbbbbbbb\"",
  "filters": [],
  "id": "/subscriptions/aaaa0a0a-bb1b-cc2c-dd3d-eeeeee4e4e4e/resourceGroups/NetworkWatcherRG/providers/Microsoft.Network/networkWatchers/NetworkWatcher_eastus/packetCaptures/myVM_1",
  "name": "myVM_1",
  "provisioningState": "Succeeded",
  "resourceGroup": "NetworkWatcherRG",
  "scope": {
    "exclude": [],
    "include": []
  },
  "storageLocation": {
    "storageId": "/subscriptions/aaaa0a0a-bb1b-cc2c-dd3d-eeeeee4e4e4e/resourceGroups/myResourceGroup/providers/Microsoft.Storage/storageAccounts/mystorageaccount",
    "storagePath": "https://mystorageaccount.blob.core.windows.net/network-watcher-logs/subscriptions/aaaa0a0a-bb1b-cc2c-dd3d-eeeeee4e4e4e/resourcegroups/myresourcegroup/providers/microsoft.compute/virtualmachines/myvm/2025/01/31/packetcapture_16_39_41_077.cap"
  },
  "target": "/subscriptions/aaaa0a0a-bb1b-cc2c-dd3d-eeeeee4e4e4e/resourceGroups/myResourceGroup/providers/Microsoft.Compute/virtualMachines/myVM",
  "targetType": "AzureVM",
  "timeLimitInSeconds": 18000,
  "totalBytesPerSession": 1073741824
}
```

The following table describes the optional parameters that you can use with the [az network watcher packet-capture create](/en-us/cli/azure/network/watcher/packet-capture#az-network-watcher-packet-capture-create) command:

| Parameter | description |
| --- | --- |
| `--filters` | Add filter(s) to capture only the traffic you want. For example, you can capture only TCP traffic from a specific IP address to a specific port. |
| `--time-limit` | Set the maximum duration of the capture session. The default value is 18000 seconds (5 hours). |
| `--capture-size` | Set the maximum number of bytes to be captured per each packet. All bytes are captured if not used or 0 entered. |
| `--capture-limit` | Set the total number of bytes that are captured. Once the value is reached the packet capture stops. Up to 1 GB (1,073,741,824 bytes) is captured if not used. |
| `--file-path` | Enter a valid local file path if you want the capture to be saved in the target virtual machine (For example, C:\Capture\myVM\_1.cap). If you're using a Linux machine, the path must start with /var/captures. |

The packet capture stops once the time limit or the file size (maximum bytes per session) is reached.

---

## Stop a packet capture

# [Portal](#tab/portal)
To manually stop a packet capture session before it reaches its time or file size limits, select the ellipsis **...** on the right-side of the packet capture, or right-click it, then select **Stop**.

[![Screenshot that shows how to stop a packet capture in the Azure portal.](media/packet-capture-manage/stop-packet-capture.png)](media/packet-capture-manage/stop-packet-capture.png#lightbox)

# [PowerShell](#tab/powershell)
To manually stop a packet capture session before it reaches its time or file size limits, use the [Stop-AzNetworkWatcherPacketCapture](/en-us/powershell/module/az.network/stop-aznetworkwatcherpacketcapture) cmdlet.

```azurepowershell
# Manually stop a packet capture session.
Stop-AzNetworkWatcherPacketCapture -Location 'eastus' -PacketCaptureName 'myVM_1'
```

Note

The cmdlet doesn't return a response whether ran on a currently running capture session or a session that has already stopped.

# [Azure CLI](#tab/cli)
To manually stop a packet capture session before it reaches its time or file size limits, use the [az network watcher packet-capture stop](/en-us/cli/azure/network/watcher/packet-capture#az-network-watcher-packet-capture-stop) command.

```azurecli
# Manually stop a packet capture session.
az network watcher packet-capture stop --location 'eastus' --name 'myVM_1'
```

Note

The command doesn't return a response whether ran on a currently running capture session or a session that has already stopped.

---

## View packet capture status

# [Portal](#tab/portal)
Go to the **Packet capture** page of Network Watcher to list existing packet captures regardless of their status.

[![Screenshot that shows how to list and see packet captures in the Azure portal.](media/packet-capture-manage/view-packet-capture.png)](media/packet-capture-manage/view-packet-capture.png#lightbox)

# [PowerShell](#tab/powershell)
Use [Get-AzNetworkWatcherPacketCapture](/en-us/powershell/module/az.network/get-aznetworkwatcherpacketcapture) cmdlet to retrieve the status of a packet capture (running or completed).

```azurepowershell
# Get information, properties, and status of a packet capture.
Get-AzNetworkWatcherPacketCapture -Location 'eastus' -PacketCaptureName 'myVM_1'
```

The following output is an example of the output from the `Get-AzNetworkWatcherPacketCapture` cmdlet. The following example is after the capture is complete. The PacketCaptureStatus value is Stopped, with a StopReason of TimeExceeded. This value shows that the packet capture was successful and ran its time.

```output
ProvisioningState Name   Target                                                                                                                              BytesToCapturePerPacket TotalBytesPerSession TimeLimitInSeconds
----------------- ----   ------                                                                                                                              ----------------------- -------------------- ------------------
Succeeded         myVM_1 /subscriptions/aaaa0a0a-bb1b-cc2c-dd3d-eeeeee4e4e4e/resourceGroups/myResourceGroup/providers/Microsoft.Compute/virtualMachines/myVM 0                       1073741824           18000
```

Note

To get more details in the output, add `| Format-List` to the end of the command.

# [Azure CLI](#tab/cli)
Use [az network watcher packet-capture show-status](/en-us/cli/azure/network/watcher/packet-capture#az-network-watcher-packet-capture-show-status) command to retrieve the status of a packet capture (running or completed).

```azurecli
# Get information, properties, and status of a packet capture.
az network watcher packet-capture show-status --location 'eastus' --name 'myVM_1'
```

The following example is the output from the `az network watcher packet-capture show-status` command. You can see that packetCaptureStatus value is **Stopped**, with a StopReason value of **TimeExceeded**:

```output
{
  "additionalProperties": {
    "status": "Succeeded"
  },
  "captureStartTime": "2016-12-06T17:20:01.5671279Z",
  "id": "/subscriptions/aaaa0a0a-bb1b-cc2c-dd3d-eeeeee4e4e4e/resourceGroups/NetworkWatcherRG/providers/Microsoft.Network/networkWatchers/NetworkWatcher_eastus/packetCaptures/myVM_1",
  "name": "packetCaptureName",
  "packetCaptureError": [],
  "packetCaptureStatus": "Stopped",
  "stopReason": "TimeExceeded"
}
```

---

## Download a packet capture

After your packet capture session completes, the resulting capture file is saved to Azure Storage, a local file on the target virtual machine, or both. The storage destination for the packet capture is specified during its creation. For more information, see Start a packet capture section.

# [Portal](#tab/portal)
To download a packet capture file saved to Azure storage, follow these steps:

1. In the **Packet capture** page, select the packet capture that you want to download its file.
2. In the **Details** section, select the packet capture file link.

    [![Screenshot that shows how to select the packet capture file in the Azure portal.](media/packet-capture-manage/packet-capture-file.png)](media/packet-capture-manage/packet-capture-file.png#lightbox)
3. In the blob page, select **Download**.

You can also download capture files by directly going to the storage account container at the following path:

```
https://{storageAccountName}.blob.core.windows.net/network-watcher-logs/subscriptions/{subscriptionId}/resourcegroups/{storageAccountResourceGroup}/providers/microsoft.compute/virtualmachines/{virtualMachineName}/{year}/{month}/{day}/packetcapture_{UTCcreationTime}.cap
```

# [PowerShell](#tab/powershell)
If a storage account is specified, capture files are saved to the storage account at the following path:

```url
https://{storageAccountName}.blob.core.windows.net/network-watcher-logs/subscriptions/{subscriptionId}/resourcegroups/{storageAccountResourceGroup}/providers/microsoft.compute/virtualmachines/{virtualMachineName}/{year}/{month}/{day}/packetcapture_{UTCcreationTime}.cap
```

To download a packet capture from Azure storage to the local disk, use [Get-AzStorageBlobContent](/en-us/powershell/module/az.storage/get-azstorageblobcontent) cmdlet:

```azurepowershell
# Download the packet capture file from Azure storage container.
Get-AzStorageBlobContent -Container 'network-watcher-logs' -Blob '/subscriptions/aaaa0a0a-bb1b-cc2c-dd3d-eeeeee4e4e4e/resourcegroups/myresourcegroup/providers/microsoft.compute/virtualmachines/myvm/2024/01/25/packetcapture_22_44_54_342.cap' -Destination 'C:\Capture\myVM_1.cap'
```

# [Azure CLI](#tab/cli)
If a storage account is specified, capture files are saved to the storage account at the following path:

```url
https://{storageAccountName}.blob.core.windows.net/network-watcher-logs/subscriptions/{subscriptionId}/resourcegroups/{storageAccountResourceGroup}/providers/microsoft.compute/virtualmachines/{virtualMachineName}/{year}/{month}/{day}/packetcapture_{UTCcreationTime}.cap
```

To download a packet capture from Azure storage to the local disk, use [az storage blob download](/en-us/cli/azure/storage/blob#az-storage-blob-download) command:

```azurecli
# Download the packet capture file from Azure storage container.
az storage blob download --container-name 'network-watcher-logs' --blob-url '/subscriptions/aaaa0a0a-bb1b-cc2c-dd3d-eeeeee4e4e4e/resourcegroups/myresourcegroup/providers/microsoft.compute/virtualmachines/myvm/2024/01/25/packetcapture_22_44_54_342.cap' --file 'C:\Capture\myVM_1.cap'
```

---

Note

You can use Azure Storage Explorer to download capture files from the storage account container. Storage Explorer is a standalone app that you can conveniently use to access and work with Azure Storage data. For more information, see [Get started with Storage Explorer](../vs-azure-tools-storage-manage-with-storage-explorer).

Important

During the packet capture session, the capture file might not immediately appear in the storage account container because it's initially saved to a temporary location. The file is transferred to its final location after the capture session is completed.

To download a packet capture file saved to the virtual machine (VM), connect to the VM and download the file from the local path specified during the packet capture creation.

## Delete a packet capture

# [Portal](#tab/portal)
1. In the **Packet capture** page, select **...** on the right-side of the packet capture that you want to delete, or right-click it, then select **Delete**.

    [![Screenshot that shows how to delete a packet capture from Network Watcher in Azure portal.](media/packet-capture-manage/delete-packet-capture.png)](media/packet-capture-manage/delete-packet-capture.png#lightbox)
2. Select **Yes**.

# [PowerShell](#tab/powershell)
Use [Remove-AzNetworkWatcherPacketCapture](/en-us/powershell/module/az.network/remove-aznetworkwatcherpacketcapture) to delete a packet capture resource.

```azurepowershell
# Delete a packet capture resource.
Remove-AzNetworkWatcherPacketCapture -Location 'eastus' -PacketCaptureName 'myVM_1'
```

# [Azure CLI](#tab/cli)
Use [az network watcher packet-capture delete](/en-us/cli/azure/network/watcher/packet-capture#az-network-watcher-packet-capture-delete) to delete a packet capture resource.

```azurecli
# Delete a packet capture resource.
az network watcher packet-capture delete --location 'eastus' --name 'myVM_1'
```

---

Important

Deleting the packet capture resource in Network Watcher doesn't delete the capture file from the storage account or the virtual machine. If you don't need the capture file anymore, you must manually delete it from the storage account or virtual machine.