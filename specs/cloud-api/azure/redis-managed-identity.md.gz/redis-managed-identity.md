---
layout: Conceptual
title: Managed identity for storage accounts - Azure Cache for Redis | Microsoft Learn
canonicalUrl: https://learn.microsoft.com/en-us/azure/azure-cache-for-redis/cache-managed-identity
uhfHeaderId: MSDocsHeader-NoSQL
permissioned-type: public
recommendations: true
recommendation_types:
- Training
- Certification
breadcrumb_path: ../breadcrumb/azure-nosql/toc.json
feedback_system: Standard
feedback_product_url: https://feedback.azure.com/d365community/forum/a96a82f3-0c25-ec11-b6e6-000d3a4f07b8
feedback_help_link_url: https://learn.microsoft.com/answers/tags/10/azure-blueprints/
feedback_help_link_type: get-help-at-qna
ms.service: azure-cache-redis
ms.author: sidandrews
author: flang-msft
ms.update-cycle: 1095-days
description: Learn to Azure Cache for Redis
ms.topic: how-to
ms.date: 2025-04-21T00:00:00.0000000Z
ms.custom:
- devx-track-azurepowershell
- devx-track-azurecli
- ignite-2024
- sfi-image-nochange
locale: en-us
document_id: 52c9b8b3-b2ef-2dc8-4b89-5c25100dc97b
document_version_independent_id: 52c9b8b3-b2ef-2dc8-4b89-5c25100dc97b
updated_at: 2026-09-02T15:23:00.0000000Z
original_content_git_url: https://github.com/MicrosoftDocs/nosql-docs-pr/blob/live/azure/azure-cache-for-redis/cache-managed-identity.md
gitcommit: https://github.com/MicrosoftDocs/nosql-docs-pr/blob/9bd51d6aa6c5f3cb3ee6da16a4fb04cf396cd53d/azure/azure-cache-for-redis/cache-managed-identity.md
git_commit_id: 9bd51d6aa6c5f3cb3ee6da16a4fb04cf396cd53d
site_name: Docs
depot_name: Learn.azure-nosql
page_type: conceptual
interactive_type: azurecli,powershell
toc_rel: toc.json
word_count: 1436
asset_id: azure-cache-for-redis/cache-managed-identity
moniker_range_name: 
monikers: []
item_type: Content
source_path: azure/azure-cache-for-redis/cache-managed-identity.md
cmProducts:
- https://authoring-docs-microsoft.poolparty.biz/devrel/f80a1aa9-ec39-45c7-bff1-e6916def6921
- https://authoring-docs-microsoft.poolparty.biz/devrel/68ec7f3a-2bc6-459f-b959-19beb729907d
spProducts:
- https://authoring-docs-microsoft.poolparty.biz/devrel/b47bd505-a970-48d0-a7c0-cc58500975e6
- https://authoring-docs-microsoft.poolparty.biz/devrel/90370425-aca4-4a39-9533-d52e5e002a5d
platformId: 2cc9a913-87a7-1c10-8552-0d677cb60239
---

# Managed identity for storage accounts - Azure Cache for Redis | Microsoft Learn

Important

Azure Cache for Redis announced its retirement timeline for all SKUs. We recommend moving your existing Azure Cache for Redis instances to Azure Managed Redis as soon as you can.

Migration guidance:

- [Migrate Basic, Standard, and Premium tiers to Azure Managed Redis](/en-us/azure/redis/migrate/migrate-basic-standard-premium-overview)
- [Migrate Enterprise tier to Azure Managed Redis](/en-us/azure/redis/migrate/migrate-redis-enterprise-overview)

For more details about the retirement:

- [Azure Cache for Redis Retirement: What to Know and How to Prepare](https://techcommunity.microsoft.com/blog/azure-managed-redis/azure-cache-for-redis-retirement-what-to-know-and-how-to-prepare/4458721)
- [Azure Cache for Redis Retirement FAQ](/en-us/azure/azure-cache-for-redis/retirement-faq)

A [managed identity](/en-us/entra/identity/managed-identities-azure-resources/overview) helps Azure services connect to each other by making authentication more streamlined and secure. Instead of managing authorization between the services, a managed identity uses [Microsoft Entra ID](/en-us/entra/fundamentals/whatis) to provide authentication. This article describes how to use managed identity to connect Azure Cache for Redis caches to Azure Storage accounts.

A managed identity lets you simplify the process of securely connecting to an Azure Storage account for the following Azure Redis scenarios:

- [Data persistence](cache-how-to-premium-persistence) to back up the data in your cache.
- [Import or export](cache-how-to-import-export-data) to save snapshots of cache data or import data from a saved file.

Note

Only the Azure Redis data persistence and import-export features use managed identity. These features are available only in Azure Redis Premium tier, so managed identity is available only in Azure Redis Premium tier.

Azure Cache for Redis supports both *system-assigned* and *user-assigned* managed identities. Each type of managed identity has advantages, but the functionality is the same in Azure Cache for Redis.

- **System-assigned identity** is specific to the cache resource. If the cache is deleted, the identity is deleted.
- **User-assigned identity** is specific to a user. You can assign this identity to any resource, such as a storage account, that supports managed identity. This assignment remains even if you delete the specific cache resource.

Configuring managed identity for Azure Redis Premium data persistence or import-export features consists of several parts:

- Enable the managed identity in the Azure Redis cache.
- Configure the Azure Storage account to use the managed identity.
- Configure the data persistence or import-export features to use the managed identity.

All the parts must be completed correctly before Azure Redis data persistence or import-export can access the storage account. Otherwise, you see errors or no data written.

## Scope of availability

| Tier | Basic, Standard | Premium | Enterprise, Enterprise Flash |
| --- | --- | --- | --- |
| Available | Yes | Yes | No |

## Prerequisites

- Ability to create and configure a Premium-tier Azure Redis cache and an Azure Storage account in an Azure subscription.
- To assign a user-assigned managed identity: A [managed identity created](/en-us/entra/identity/managed-identities-azure-resources/how-manage-user-assigned-managed-identities) in the same Azure subscription as the Azure Redis cache and Storage account.

## Enable managed identity

You can enable managed identity for your Azure Redis cache by using the Azure portal, Azure CLI, or Azure PowerShell. You can enable managed identity when you create a cache instance, or afterwards.

### Enable managed identity in the Azure portal

During cache creation, you can assign only system-assigned managed identity. You can add either system-assigned or a user-assigned identity to an existing cache.

#### Create a new cache with managed identity

1. In the [Azure portal](https://portal.azure.com), choose to [create an Azure Cache for Redis cache](quickstart-create-redis). On the **Basics** tab, select **Premium** for the **Cache SKU**, and complete the rest of the required information.

    ![Screenshot of creating a Premium cache.](media/cache-managed-identity/basics.png)
2. Select the **Advanced** tab, and under **System assigned managed identity**, set **Status** to **On**.

    ![Screenshot that shows setting System assigned managed identity to On.](media/cache-managed-identity/system-assigned.png)
3. Complete the cache creation process.
4. Once the cache is deployed, go to the cache page and select **Identity** under **Settings** in the left navigation menu. Verify that an **Object (principal) ID** appears on the **System assigned** tab of the **Identity** page.

    ![Screenshot showing Identity in the Resource menu.](media/cache-managed-identity/identity-resource.png)

#### Add system-assigned identity to an existing cache

1. On the Azure portal page for your Azure Redis Premium cache, select **Identity** under **Settings** in the left navigation menu.
2. On the **System assigned** tab, set **Status** to **On**, and then select **Save**.

    ![Screenshot showing System Assigned selected and Status is on.](media/cache-managed-identity/identity-save.png)
3. Respond **Yes** to the **Enable system assigned managed identity** prompt.
4. Once the identity is assigned, verify that an **Object (principal) ID** appears on the **System assigned** tab of the **Identity** page.

    ![Screenshot showing the Object (principal) ID.](media/cache-managed-identity/identity-resource.png)

#### Add a user-assigned identity to an existing cache

1. On the Azure portal page for your Azure Redis Premium cache, select **Identity** under **Settings** in the left navigation menu.
2. Select the **User assigned** tab, and then select **Add**.

    ![User assigned identity status is on.](media/cache-managed-identity/identity-add.png)
3. On the **Add user assigned managed identity** screen, select a managed identity from your subscription, and select **Add**. For more information on user assigned managed identities, see [manage user-assigned identity](/en-us/azure/active-directory/managed-identities-azure-resources/how-manage-user-assigned-managed-identities).

    ![Screenshot showing a user-assigned managed identity.](media/cache-managed-identity/choose-identity.png)
4. Once the user-assigned identity is added, verify that it appears on the **User assigned** tab of the **Identity** page.

    ![Screenshot showing the user-assigned identity on the Identity page.](media/cache-managed-identity/identity-list.png)

### Enable managed identity using Azure CLI

You can use the Azure CLI for creating a new cache with managed identity by using [az redis create](/en-us/cli/azure/redis?view=azure-cli-latest.md&amp;preserve-view=true). You can update an existing cache to use managed identity by using [az redis identity](/en-us/cli/azure/redis/identity?view=azure-cli-latest&amp;preserve-view=true).

For example, to update a cache to use system-managed identity, use the following Azure CLI command:

```azurecli

az redis identity assign \--mi-system-assigned \--name MyCacheName \--resource-group MyResource Group
```

### Enable managed identity using Azure PowerShell

You can use Azure PowerShell for creating a new cache with managed identity by using [New-AzRedisCache](/en-us/powershell/module/az.rediscache/new-azrediscache). You can update an existing cache to use managed identity by using [Set-AzRedisCache](/en-us/powershell/module/az.rediscache/set-azrediscache).

For example, to update a cache to use system-managed identity, use the following Azure PowerShell command:

```powershell
Set-AzRedisCache -ResourceGroupName \"MyGroup\" -Name \"MyCache\" -IdentityType "SystemAssigned"
```

## Configure the storage account to use managed identity

1. In the Azure portal, create a new storage account or open an existing storage account that you want to connect to your cache instance.
2. Select **Access control (IAM)** from the left navigation menu.
3. On the **Access control (IAM)** page, select **Add** &gt; **Add role assignment**.

    ![Screenshot showing the Access Control (IAM) settings.](media/cache-managed-identity/demo-storage.png)
4. On the **Role** tab of the **Add Role Assignment** page, search for and select **Storage Blob Data Contributor**, and then select **Next**.

    ![Screenshot showing Add role assignment form with list of roles.](media/cache-managed-identity/role-assignment.png)
5. On the **Members** tab, for **Assign access to**, select **Managed Identity**, and then select **Select members**.

    ![Screenshot showing add role assignment form with members pane.](media/cache-managed-identity/select-members.png)
6. In the **Select managed identities** pane, select the dropdown arrow under **Managed identity** to see all your available user-assigned and system-assigned managed identities. If you have many managed identities, you can search for the one you want. Choose the managed identities you want, and then select **Select**.

    ![Screenshot showing add Select managed identities pane.](media/cache-managed-identity/user-assigned.png)
7. On the **Add role assignment** page, select **Review + assign**, and then select **Review + assign** again to confirm.

    ![Screenshot showing Managed Identity form with managed identities assigned.](media/cache-managed-identity/review-assign.png)
8. On the storage account's **Access control (IAM)** page, select **View** under **View access to this resource**, and then search for **Storage Blob Data Contributor** on the **Role Assignments** tab to verify that the managed identities are added.

    ![Screenshot of Storage Blob Data Contributor list.](media/cache-managed-identity/blob-data.png)

Important

For export to work with a storage account with firewall exceptions, you must:

- Add the Azure Redis cache as a **Storage Blob Data Contributor** through system-assigned identity, and
- On the storage account **Networking** page, select [Allow Azure services on the trusted services list to access this storage account](/en-us/azure/storage/common/storage-network-security#grant-access-to-trusted-azure-services).

If you don't use managed identity and instead authorize a storage account with a key, having firewall exceptions on the storage account breaks the persistence process and the import-export processes.

## Use managed identity with data persistence

1. On the Azure portal page for your Azure Redis Premium cache that has the **Storage Blob Data Contributor** role, select **Data persistence** under **Settings** in the left navigation menu.
2. Ensure that **Authentication Method** is set to **Managed Identity**.

    Important

    The selection defaults to the system-assigned identity if enabled. Otherwise, it uses the first listed user-assigned identity.
3. Under **Storage Account**, select the storage account you configured to use managed identity, if not already selected, and select **Save** if necessary.

    ![Screenshot showing data persistence pane with authentication method selected.](media/cache-managed-identity/data-persistence.png)

You can now save data persistence backups to the storage account using managed identity authentication.

## Use managed identity to import and export cache data

1. On the Azure portal page for your Azure Redis Premium cache that has the **Storage Blob Data Contributor** role, select **Import data** or **Export data** under **Administration** in the left navigation menu.
2. On the **Import data** or **Export data** screen, select **Managed Identity** for **Authentication Method**.
3. To import data, on the **Import data** screen, select **Choose Blob(s)** next to **RDB File(s)**. Select your Redis Database (RDB) file or files from the blob storage location, and select **Select**.
4. To export data, on the **Export data** screen, enter a **Blob name prefix**, and then select **Choose Storage Container** next to **Export output**. Select or create a container to hold the exported data, and select **Select**.

    ![Screenshot showing Managed Identity selected.](media/cache-managed-identity/export-data.png)
5. On the **Import data** or **Export data** screen, select **Import** or **Export** respectively.

    Note

    It takes a few minutes to import or export the data.

Important

If you see an export or import failure, double check that your storage account has been configured with your cache's system-assigned or user-assigned identity. The identity used defaults to system-assigned identity if enabled. Otherwise, it uses the first listed user-assigned identity.