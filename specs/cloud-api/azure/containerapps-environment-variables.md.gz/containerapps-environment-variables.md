---
layout: Conceptual
title: Manage environment variables on Azure Container Apps | Microsoft Learn
canonicalUrl: https://learn.microsoft.com/en-us/azure/container-apps/environment-variables
breadcrumb_path: /azure/bread/toc.json
feedback_help_link_url: https://learn.microsoft.com/answers/tags/418/azure-container-apps/
feedback_help_link_type: get-help-at-qna
feedback_product_url: https://feedback.azure.com/d365community/forum/79b1327d-d925-ec11-b6e6-000d3a4f06a4
feedback_system: Standard
permissioned-type: public
recommendations: true
recommendation_types:
- Training
- Certification
uhfHeaderId: azure
ms.suite: office
adobe-target: true
learn_banner_products:
- azure
description: Learn to manage environment variables in Azure Container Apps.
services: container-apps
author: fred-cardoso
ms.service: azure-container-apps
ms.custom: devx-track-azurecli, devx-track-azurepowershell
ms.topic: how-to
ms.date: 2026-03-31T00:00:00.0000000Z
ms.author: fredcardoso
locale: en-us
document_id: edf9571c-8b04-0e3a-2e2b-9decd3994cd2
document_version_independent_id: f6118b88-d828-c862-ff79-649a18864a1b
updated_at: 2026-04-03T17:16:00.0000000Z
original_content_git_url: https://github.com/MicrosoftDocs/azure-docs-pr/blob/live/articles/container-apps/environment-variables.md
gitcommit: https://github.com/MicrosoftDocs/azure-docs-pr/blob/ad6d65108a25d453de4b264a824f054521e73d99/articles/container-apps/environment-variables.md
git_commit_id: ad6d65108a25d453de4b264a824f054521e73d99
site_name: Docs
depot_name: Azure.azure-documents
page_type: conceptual
toc_rel: toc.json
pdf_url_template: https://learn.microsoft.com/pdfstore/en-us/Azure.azure-documents/{branchName}{pdfName}
word_count: 932
asset_id: container-apps/environment-variables
moniker_range_name: 
monikers: []
item_type: Content
source_path: articles/container-apps/environment-variables.md
cmProducts:
- https://microsoft-devrel.poolparty.biz/DevRelOfferingOntology/32e8f006-5597-4144-9ccc-778e20833eca
spProducts:
- https://microsoft-devrel.poolparty.biz/DevRelOfferingOntology/bfbda2e5-bc4e-4e83-8c2a-41b7c4914a07
platformId: b540a84e-c279-7d7d-a03c-a707a0e2844a
---

# Manage environment variables on Azure Container Apps | Microsoft Learn

In Azure Container Apps, you're able to set runtime environment variables. These variables can be set as manually entries or as references to [secrets](manage-secrets). These environment variables are loaded onto your Container App during runtime.

## Configure environment variables

You can configure the Environment Variables upon the creation of the Container App or later by creating a new revision.

Note

To avoid confusion, it is not recommended to duplicate environment variables. When multiple environment variables have the same name, the last one in the list takes effect.

# [Azure portal](#tab/portal)
If you're creating a new Container App through the [Azure portal](https://portal.azure.com), you can set up the environment variables on the Container section:

![Screenshot of Container App creation page.](media/environment-variables/creating-a-container-app.png)

# [Azure CLI](#tab/cli)
You can create your Container App with environment variables using the [az containerapp create](/en-us/cli/azure/containerapp#az-containerapp-create) command by passing the environment variables as space-separated 'key=value' entries using the `--env-vars` parameter.

```azurecli
az containerapp create -n my-containerapp -g MyResourceGroup \
    --image my-app:v1.0 --environment MyContainerappEnv \
    --secrets mysecret=secretvalue1 anothersecret="secret value 2" \
    --env-vars GREETING="Hello, world" ANOTHERENV=anotherenv
```

If you want to reference a secret, you have to ensure that the secret you want to reference is already created, see [Manage secrets](manage-secrets). You can use the secret name and pass it to the value field but starting with `secretref:`

```azurecli
az containerapp update \
    -n <APP NAME> 
    -g <RESOURCE_GROUP_NAME> 
    --set-env-vars <VAR_NAME>=secretref:<SECRET_NAME>
```

# [PowerShell](#tab/powershell)
If you want to use PowerShell you have to, first, create an in-memory object called [EnvironmentVar](/en-us/dotnet/api/Microsoft.Azure.PowerShell.Cmdlets.App.Models.EnvironmentVar) using the [New-AzContainerAppEnvironmentVarObject](/en-us/powershell/module/az.app/new-azcontainerappenvironmentvarobject) PowerShell cmdlet.

To use this cmdlet, you have to pass the name of the environment variable using the `-Name` parameter and the value using the `-Value` parameter, respectively.

```azurepowershell
$envVar = New-AzContainerAppEnvironmentVarObject -Name "envVarName" -Value "envVarvalue"
```

If you want to reference a secret, you have to ensure that the secret you want to reference is already created, see [Manage secrets](manage-secrets). You can use the secret name and pass it to the `-SecretRef` parameter:

```azurepowershell
$envVar = New-AzContainerAppEnvironmentVarObject -Name "envVarName" -SecretRef "secretName"
```

Then you have to create another in-memory object called [Container](/en-us/dotnet/api/Microsoft.Azure.PowerShell.Cmdlets.App.Models.Container) using the [New-AzContainerAppTemplateObject](/en-us/powershell/module/az.app/new-azcontainerapptemplateobject) PowerShell cmdlet.

On this cmdlet, you have to pass the name of your container image (not the container app!) you desire using the `-Name` parameter, the fully qualified image name using the `-Image` parameter and reference the environment object you defined previously on the variable `$envVar`.

```azurepowershell
$containerTemplate = New-AzContainerAppTemplateObject -Name "container-app-name" -Image "repo/imagename:tag" -Env $envVar
```

Note

Please note that there are other settings that you might need to define inside the template object to avoid overriding them like resources, volume mounts, etc. Please check the full documentation about this template on [New-AzContainerAppTemplateObject](/en-us/powershell/module/az.app/new-azcontainerapptemplateobject).

Finally, you can update your Container App based on the new template object you created using the [Update-AzContainerApp](/en-us/powershell/module/az.app/update-azcontainerapp) PowerShell cmdlet.

In this last cmdlet, you only need to pass the template object you defined on the `$containerTemplate` variable on the previous step using the `-TemplateContainer` parameter.

```azurepowershell
Update-AzContainerApp -TemplateContainer $containerTemplate
```

---

## Add environment variables on existing container apps

After the Container App is created, the only way to update the Container App environment variables is by creating a new revision with the needed changes.

# [Azure portal](#tab/portal)
1. In the [Azure portal](https://portal.azure.com), search for Container Apps and then select your app.

    ![Screenshot of the Azure portal search bar with Container App as one of the results.](media/environment-variables/container-apps-portal.png)
2. In the app's left menu, select Revisions and replicas &gt; Create new revision

    ![Screenshot of Container App Revision creation page.](media/environment-variables/create-new-revision.png)
3. Then you have to edit the current existing container image:

    ![Screenshot of Container App Revision container image settings page.](media/environment-variables/edit-revision.png)
4. In the Environment variables section, you can Add new Environment variables by clicking on Add.
5. Then set the Name of your Environment variable and the Source (it can be a reference to a [secret](manage-secrets)).

    ![Screenshot of Container App Revision container image environment settings section.](media/environment-variables/secret-env-var.png)

    1. If you select the Source as manual, you can manually input the Environment variable value.

        ![Screenshot of Container App Revision container image environment settings section with one of the environments source selected as Manual.](media/environment-variables/manual-env-var.png)

# [Azure CLI](#tab/cli)
You can update your Container App with the [az containerapp update](/en-us/cli/azure/containerapp#az-containerapp-update) command.

This example creates an environment variable with a manual value (not referencing a secret). Replace the &lt;PLACEHOLDERS&gt; with your values.

```azurecli
az containerapp update \
    -n <APP NAME> 
    -g <RESOURCE_GROUP_NAME> 
    --set-env-vars <VAR_NAME>=<VAR_VALUE>
```

If you want to create multiple environment variables, you can insert space-separated values in the 'key=value' format.

If you want to reference a secret, you have to ensure that the secret you want to reference is already created, see [Manage secrets](manage-secrets). You can use the secret name and pass it to the value field but starting with `secretref:`, see the following example:

```azurecli
az containerapp update \
    -n <APP NAME> 
    -g <RESOURCE_GROUP_NAME> 
    --set-env-vars <VAR_NAME>=secretref:<SECRET_NAME>
```

# [PowerShell](#tab/powershell)
Similarly to what you need to do upon creating a new Container App you have to create an object called [EnvironmentVar](/en-us/dotnet/api/Microsoft.Azure.PowerShell.Cmdlets.App.Models.EnvironmentVar), which is contained within a [Container](/en-us/dotnet/api/Microsoft.Azure.PowerShell.Cmdlets.App.Models.Container). This [Container](/en-us/dotnet/api/Microsoft.Azure.PowerShell.Cmdlets.App.Models.Container) is then used with the [New-AzContainerApp](/en-us/powershell/module/az.app/new-azcontainerapp) PowerShell cmdlet.

In this cmdlet, you only need to pass the template object you defined previously as described in the Configure environment variables section.

```azurepowershell
Update-AzContainerApp -TemplateContainer $containerTemplate
```

---

## Built-in environment variables

Azure Container Apps automatically adds environment variables that your apps and jobs can use to obtain platform metadata at run-time.

### Apps

The following variables are available to container apps:

| Variable name | Description | Example value |
| --- | --- | --- |
| `CONTAINER_APP_NAME` | The name of the container app. | `my-containerapp` |
| `CONTAINER_APP_REVISION` | The name of the container app revision. | `my-containerapp--20mh1s9` |
| `CONTAINER_APP_HOSTNAME` | The revision-specific hostname of the container app. | `my-containerapp--20mh1s9.<DEFAULT_HOSTNAME>.<REGION>.azurecontainerapps.io` |
| `CONTAINER_APP_ENV_DNS_SUFFIX` | The DNS suffix for the Container Apps environment. To obtain the fully qualified domain name (FQDN) of the app, append the app name to the DNS suffix in the format `$CONTAINER_APP_NAME.$CONTAINER_APP_ENV_DNS_SUFFIX`. | `<DEFAULT_HOSTNAME>.<REGION>.azurecontainerapps.io` |
| `CONTAINER_APP_PORT` | The target port of the container app. | `8080` |
| `CONTAINER_APP_REPLICA_NAME` | The name of the container app replica. | `my-containerapp--20mh1s9-86c8c4b497-zx9bq` |
| `CONTAINER_NAME` | The name of the replica. Available for managed function apps and logic apps. | `my-containerapp--20mh1s9-86c8c4b497-zx9bq` |

### Jobs

The following variables are available to Container Apps jobs:

| Variable name | Description | Example value |
| --- | --- | --- |
| `CONTAINER_APP_JOB_NAME` | The name of the job. | `my-job` |
| `CONTAINER_APP_JOB_EXECUTION_NAME` | The name of the job execution. | `my-job-iwpi4il` |